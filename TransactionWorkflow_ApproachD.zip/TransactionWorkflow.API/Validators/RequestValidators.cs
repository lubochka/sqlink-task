using FluentValidation;
using TransactionWorkflow.Application.DTOs;

namespace TransactionWorkflow.API.Validators;

public class CreateTransactionValidator : AbstractValidator<CreateTransactionRequest>
{
    public CreateTransactionValidator()
    {
        RuleFor(x => x.Amount)
            .GreaterThan(0)
            .WithMessage("Amount must be greater than 0.");

        RuleFor(x => x.Currency)
            .NotEmpty()
            .Length(3)
            .Matches("^[A-Z]{3}$")
            .WithMessage("Currency must be a 3-letter uppercase ISO code (e.g., USD, EUR).");

        RuleFor(x => x.Description)
            .MaximumLength(500)
            .Matches(@"^[a-zA-Z0-9 \.\-\#\,\:\;\/\(\)]*$")
            .When(x => !string.IsNullOrEmpty(x.Description))
            .WithMessage("Description contains invalid characters.");
    }
}

public class TransitionRequestValidator : AbstractValidator<TransitionRequest>
{
    public TransitionRequestValidator()
    {
        RuleFor(x => x.TargetStatus)
            .NotEmpty()
            .MaximumLength(50)
            .Matches(@"^[A-Za-z_]+$")
            .WithMessage("TargetStatus must contain only letters and underscores.");

        RuleFor(x => x.Reason)
            .MaximumLength(500)
            .When(x => x.Reason is not null);
    }
}

public class AddStatusRequestValidator : AbstractValidator<AddStatusRequest>
{
    public AddStatusRequestValidator()
    {
        RuleFor(x => x.Name)
            .NotEmpty()
            .MaximumLength(50)
            .Matches(@"^[A-Za-z_]+$")
            .WithMessage("Status name must contain only letters and underscores.");
    }
}

public class AddTransitionRequestValidator : AbstractValidator<AddTransitionRequest>
{
    public AddTransitionRequestValidator()
    {
        RuleFor(x => x.FromStatus)
            .NotEmpty()
            .MaximumLength(50);

        RuleFor(x => x.ToStatus)
            .NotEmpty()
            .MaximumLength(50)
            .NotEqual(x => x.FromStatus)
            .WithMessage("FromStatus and ToStatus must be different.");
    }
}
