using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TransactionWorkflow.API.Extensions;
using TransactionWorkflow.Application.DTOs;
using TransactionWorkflow.Application.Interfaces;

namespace TransactionWorkflow.API.Controllers;

[Authorize(Policy = "AdminOnly")]
[ApiController]
[Route("admin/workflow")]
[Produces("application/json")]
public class AdminController : ControllerBase
{
    private readonly IWorkflowAdminService _adminService;

    public AdminController(IWorkflowAdminService adminService) => _adminService = adminService;

    /// <summary>Get all workflow statuses</summary>
    [HttpGet("statuses")]
    public async Task<IActionResult> GetStatuses(CancellationToken ct)
        => (await _adminService.GetAllStatusesAsync(ct)).ToActionResult();

    /// <summary>Add a new workflow status</summary>
    [HttpPost("statuses")]
    [ProducesResponseType(typeof(WorkflowStatusDto), StatusCodes.Status201Created)]
    public async Task<IActionResult> AddStatus([FromBody] AddStatusRequest request, CancellationToken ct)
    {
        var result = await _adminService.AddStatusAsync(request, ct);
        return result.IsSuccess
            ? Created($"/admin/workflow/statuses/{result.Data!.Id}", result.Data)
            : result.ToActionResult();
    }

    /// <summary>Get all workflow transitions</summary>
    [HttpGet("transitions")]
    public async Task<IActionResult> GetTransitions(CancellationToken ct)
        => (await _adminService.GetAllTransitionsAsync(ct)).ToActionResult();

    /// <summary>Add a new workflow transition (supports dynamic rules via metadata)</summary>
    [HttpPost("transitions")]
    [ProducesResponseType(typeof(WorkflowTransitionDto), StatusCodes.Status201Created)]
    public async Task<IActionResult> AddTransition([FromBody] AddTransitionRequest request, CancellationToken ct)
    {
        var result = await _adminService.AddTransitionAsync(request, ct);
        return result.IsSuccess
            ? Created($"/admin/workflow/transitions/{result.Data!.Id}", result.Data)
            : result.ToActionResult();
    }

    /// <summary>Get workflow as Mermaid.js diagram for visualization</summary>
    [HttpGet("visualize")]
    [Produces("text/plain")]
    [ProducesResponseType(typeof(string), StatusCodes.Status200OK)]
    public async Task<IActionResult> Visualize(CancellationToken ct)
    {
        var result = await _adminService.GetWorkflowVisualizationAsync(ct);
        return result.IsSuccess
            ? Content(result.Data!, "text/plain")
            : result.ToActionResult();
    }
}
