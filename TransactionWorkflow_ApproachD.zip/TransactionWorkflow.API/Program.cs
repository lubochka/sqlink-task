using System.Reflection;
using FluentValidation;
using FluentValidation.AspNetCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;
using TransactionWorkflow.API.Middleware;
using TransactionWorkflow.API.Security;
using TransactionWorkflow.Application.Interfaces;
using TransactionWorkflow.Application.Services;
using TransactionWorkflow.Domain.Interfaces;
using TransactionWorkflow.Domain.Services;
using TransactionWorkflow.Infrastructure.Caching;
using TransactionWorkflow.Infrastructure.Data;
using TransactionWorkflow.Infrastructure.Repositories;

var builder = WebApplication.CreateBuilder(args);

// === Database ===
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("DefaultConnection"),
        sql => sql.MigrationsAssembly("TransactionWorkflow.Infrastructure")));

// === Memory Cache ===
builder.Services.AddMemoryCache();

// === Repositories (with caching decorator) ===
builder.Services.AddScoped<WorkflowRepository>();
builder.Services.AddScoped<IWorkflowRepository>(sp =>
    new CachedWorkflowRepository(
        sp.GetRequiredService<WorkflowRepository>(),
        sp.GetRequiredService<Microsoft.Extensions.Caching.Memory.IMemoryCache>()));
builder.Services.AddScoped<ITransactionRepository, TransactionRepository>();

// === Domain Services ===
builder.Services.AddScoped<IWorkflowEngine, WorkflowEngine>();

// === Application Services ===
builder.Services.AddScoped<ITransactionService, TransactionService>();
builder.Services.AddScoped<IWorkflowAdminService, WorkflowAdminService>();

// === Authentication ===
builder.Services.AddAuthentication(ApiKeyAuthenticationDefaults.AuthenticationScheme)
    .AddScheme<ApiKeyAuthenticationOptions, ApiKeyAuthenticationHandler>(
        ApiKeyAuthenticationDefaults.AuthenticationScheme, options =>
        {
            options.ApiKey = builder.Configuration["Authentication:ApiKey"];
        });

builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("AdminOnly", policy => policy.RequireRole("Admin"));
});

// === CORS ===
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowConfigured", policy =>
    {
        var origins = builder.Configuration.GetSection("Cors:AllowedOrigins").Get<string[]>()
            ?? ["http://localhost:3000", "http://localhost:5173"];
        policy.WithOrigins(origins)
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

// === API ===
builder.Services.AddControllers()
    .AddJsonOptions(opts =>
    {
        opts.JsonSerializerOptions.PropertyNamingPolicy = System.Text.Json.JsonNamingPolicy.CamelCase;
    });

// === Health Checks ===
builder.Services.AddHealthChecks()
    .AddDbContextCheck<AppDbContext>("database");

// === Input Validation ===
builder.Services.AddFluentValidationAutoValidation();
builder.Services.AddValidatorsFromAssemblyContaining<Program>();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new()
    {
        Title = "Transaction Workflow Engine",
        Version = "v1",
        Description = "Data-driven workflow engine with dynamic metadata support. " +
                      "Statuses, transitions, and business rules are all configurable at runtime."
    });

    var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
    var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
    if (File.Exists(xmlPath))
        c.IncludeXmlComments(xmlPath);

    c.AddSecurityDefinition("ApiKey", new OpenApiSecurityScheme
    {
        Name = "X-Api-Key",
        In = ParameterLocation.Header,
        Type = SecuritySchemeType.ApiKey,
        Description = "API Key authentication. Leave empty in Development mode."
    });
    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "ApiKey" }
            },
            Array.Empty<string>()
        }
    });
});

var app = builder.Build();

// === Middleware Pipeline ===
app.UseMiddleware<GlobalExceptionMiddleware>();
app.UseCors("AllowConfigured");

app.UseSwagger();
app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "Transaction Workflow v1"));

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();
app.MapHealthChecks("/health").AllowAnonymous();

// === Database initialization ===
// EnsureCreated() for demo — creates tables + seed data from OnModelCreating.
// For production: replace with db.Database.Migrate() after generating migrations:
//   dotnet ef migrations add Initial -p TransactionWorkflow.Infrastructure -s TransactionWorkflow.API
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    db.Database.EnsureCreated();
}

app.Run();

public partial class Program { }
