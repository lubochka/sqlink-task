using System.Text.Json;
using Microsoft.AspNetCore.Mvc;

namespace TransactionWorkflow.API.Middleware;

/// <summary>
/// Safety net for unexpected exceptions that bypass DataProcessResult.
///
/// In Approach D, all expected business outcomes flow through DataProcessResult → ResultMapper.
/// This middleware catches truly unexpected failures (database crashes, network timeouts,
/// null reference bugs) and returns a structured RFC 7807 ProblemDetails response
/// instead of an empty 500 or a raw stack trace.
/// </summary>
public class GlobalExceptionMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<GlobalExceptionMiddleware> _logger;

    public GlobalExceptionMiddleware(RequestDelegate next, ILogger<GlobalExceptionMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unhandled exception: {Message}", ex.Message);

            if (context.Response.HasStarted)
            {
                _logger.LogWarning("Response already started — cannot write ProblemDetails");
                throw; // Let Kestrel handle it
            }

            context.Response.StatusCode = StatusCodes.Status500InternalServerError;
            context.Response.ContentType = "application/problem+json";

            var problem = new ProblemDetails
            {
                Type = "https://httpstatuses.io/500",
                Title = "Internal Server Error",
                Status = 500,
                Detail = "An unexpected error occurred. Please try again later."
            };

            var json = JsonSerializer.Serialize(problem, new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase
            });

            await context.Response.WriteAsync(json);
        }
    }
}
