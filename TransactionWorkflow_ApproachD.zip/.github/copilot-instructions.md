# Transaction Workflow Engine — Copilot Instructions (Approach D: Strategic Hybrid)

You are an expert .NET 8 Developer specializing in the "V17 Freedom Machine" architecture.
This project uses the "Strategic Hybrid" approach — standard .NET outside, generic engine inside.

## Critical Rules

1. **No Exceptions:** Never throw exceptions for flow control. Always return `DataProcessResult<T>.Fail()`.
2. **Generic Engine:** The `WorkflowEngine` must NOT depend on `ITransactionRepository`. It depends only on `IWorkflowRepository`. The `priorTransitionCount` for rule evaluation is passed from the service layer.
3. **JSON Rules:** If a new business rule is needed (e.g., "MinAmount"), do NOT hardcode it in the service.
   - Add a "minAmount" key to the `WorkflowTransition.Rules` JSON column
   - Add a generic evaluator block in `WorkflowEngine.EvaluateTransitionRules()`
4. **Metadata:** Transactions support `Dictionary<string, object>` metadata for arbitrary JSON. Use this for extensibility rather than adding columns.
5. **ResultMapper:** Controllers call `result.ToActionResult()` — never manually construct HTTP responses for errors.

## Code Style

- Use `record` for all DTOs
- `CancellationToken ct = default` on every async method
- `DataProcessResult<T>` as return type for ALL service methods
- Engine methods prefixed with `Try` (e.g., `TryTransitionAsync`)
- `ILogger<T>` with structured `{Placeholders}`
- FluentValidation for input validation
- Concurrency via RowVersion (optimistic locking)

## File Map

- DataProcessResult → `TransactionWorkflow.Domain/Core/DataProcessResult.cs`
- Generic engine → `TransactionWorkflow.Domain/Services/WorkflowEngine.cs`
- ResultMapper → `TransactionWorkflow.API/Extensions/ResultMapper.cs`
- Safety net → `TransactionWorkflow.API/Middleware/GlobalExceptionMiddleware.cs`
- Adapter service → `TransactionWorkflow.Application/Services/TransactionService.cs`
- Tests → `TransactionWorkflow.Tests/`

## When Adding Features

- New business rule → Add JSON rule key to transition + add evaluator in engine
- New status → INSERT into WorkflowStatuses table
- New endpoint → Add to controller, return `result.ToActionResult()`
- New metadata field → Just include it in Transaction.Metadata dictionary
