using FluentValidation;
using FluentValidation.AspNetCore;
using Microsoft.EntityFrameworkCore;
using TransactionWorkflow.Application.Interfaces;
using TransactionWorkflow.Application.Services;
using TransactionWorkflow.Domain.Interfaces;
using TransactionWorkflow.Domain.Services;
using TransactionWorkflow.Infrastructure.Caching;
using TransactionWorkflow.Infrastructure.Data;
using TransactionWorkflow.Infrastructure.Repositories;

var builder = WebApplication.CreateBuilder(args);

// === Database ===
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("DefaultConnection"),
        sql => sql.MigrationsAssembly("TransactionWorkflow.Infrastructure")));

// === Memory Cache ===
builder.Services.AddMemoryCache();

// === Repositories (with caching decorator) ===
builder.Services.AddScoped<WorkflowRepository>();
builder.Services.AddScoped<IWorkflowRepository>(sp =>
    new CachedWorkflowRepository(
        sp.GetRequiredService<WorkflowRepository>(),
        sp.GetRequiredService<Microsoft.Extensions.Caching.Memory.IMemoryCache>()));
builder.Services.AddScoped<ITransactionRepository, TransactionRepository>();

// === Domain Services ===
builder.Services.AddScoped<IWorkflowEngine, WorkflowEngine>();

// === Application Services ===
builder.Services.AddScoped<ITransactionService, TransactionService>();
builder.Services.AddScoped<IWorkflowAdminService, WorkflowAdminService>();

// === API ===
builder.Services.AddControllers()
    .AddJsonOptions(opts =>
    {
        opts.JsonSerializerOptions.PropertyNamingPolicy = System.Text.Json.JsonNamingPolicy.CamelCase;
    });

// === Input Validation ===
builder.Services.AddFluentValidationAutoValidation();
builder.Services.AddValidatorsFromAssemblyContaining<Program>();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new() { Title = "Transaction Workflow Engine", Version = "v1",
        Description = "Data-driven workflow engine with dynamic metadata support. " +
                      "Statuses, transitions, and business rules are all configurable at runtime." });
});

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "Transaction Workflow v1"));
app.MapControllers();

// Auto-migrate on startup (dev convenience)
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    db.Database.Migrate();
}

app.Run();

// Make Program accessible for integration tests
public partial class Program { }
