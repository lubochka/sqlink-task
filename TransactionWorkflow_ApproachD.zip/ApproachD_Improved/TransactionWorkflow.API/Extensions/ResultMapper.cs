using Microsoft.AspNetCore.Mvc;
using TransactionWorkflow.Domain.Core;

namespace TransactionWorkflow.API.Extensions;

/// <summary>
/// Maps DataProcessResult to IActionResult using RFC 7807 ProblemDetails.
/// 
/// This is Approach D's alternative to exception-based middleware:
///   - Approach A: Service throws → Middleware catches → Maps to HTTP code
///   - Approach D: Service returns DataProcessResult → Controller calls ToActionResult()
/// 
/// Benefits:
///   - Explicit flow — no hidden control paths through exceptions
///   - Standardized error format (RFC 7807)
///   - Single mapping point — declarative, testable
/// </summary>
public static class ResultMapper
{
    public static IActionResult ToActionResult<T>(this DataProcessResult<T> result)
    {
        if (result.IsSuccess)
            return new OkObjectResult(result.Data);

        return BuildProblemResult(result);
    }

    public static IActionResult ToCreatedResult<T>(
        this DataProcessResult<T> result, string routeName, object routeValues)
    {
        if (result.IsSuccess)
            return new CreatedAtActionResult(routeName, null, routeValues, result.Data);
        return BuildProblemResult(result);
    }

    private static IActionResult BuildProblemResult<T>(DataProcessResult<T> result)
    {
        var statusCode = result.Status switch
        {
            OperationStatus.NotFound => 404,
            OperationStatus.ValidationError => 400,
            OperationStatus.Conflict => 409,
            OperationStatus.ConfigurationError => 500,
            _ => 500
        };

        var problem = new ProblemDetails
        {
            Type = $"https://httpstatuses.io/{statusCode}",
            Title = result.Status.ToString(),
            Status = statusCode,
            Detail = result.Message
        };

        // Attach metadata (e.g., allowed transitions list) as extensions
        if (result.Metadata is not null)
        {
            foreach (var (key, value) in result.Metadata)
                problem.Extensions[key] = value;
        }

        return new ObjectResult(problem) { StatusCode = statusCode };
    }
}
