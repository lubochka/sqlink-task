namespace TransactionWorkflow.Domain.Models;

/// <summary>
/// Transaction entity. Note the Metadata dictionary — inspired by V17's DNA-1 pattern
/// (schema-free dynamic documents). Any extra fields the client sends are stored here
/// without schema changes, migrations, or code modifications.
/// </summary>
public class Transaction
{
    public int Id { get; set; }
    public string ReferenceNumber { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    public string Currency { get; set; } = "USD";
    public string Description { get; set; } = string.Empty;

    // Current status — FK to WorkflowStatus
    public int StatusId { get; set; }
    public WorkflowStatus Status { get; set; } = null!;

    /// <summary>
    /// Dynamic metadata — extensible without schema changes (V17 DNA-1).
    /// Examples: {"merchantId": "M-123", "channel": "web", "priority": "high"}
    /// Stored as JSON column in SQL Server.
    /// </summary>
    public Dictionary<string, object> Metadata { get; set; } = new();

    // Optimistic concurrency
    public byte[] RowVersion { get; set; } = null!;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

    public ICollection<TransactionHistory> History { get; set; } = new List<TransactionHistory>();
}

public class WorkflowStatus
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public bool IsInitial { get; set; }
    public bool IsFinal { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public ICollection<WorkflowTransition> OutgoingTransitions { get; set; } = new List<WorkflowTransition>();
    public ICollection<WorkflowTransition> IncomingTransitions { get; set; } = new List<WorkflowTransition>();
}

public class WorkflowTransition
{
    public int Id { get; set; }
    public int FromStatusId { get; set; }
    public WorkflowStatus FromStatus { get; set; } = null!;
    public int ToStatusId { get; set; }
    public WorkflowStatus ToStatus { get; set; } = null!;
    public string? Description { get; set; }

    /// <summary>
    /// Dynamic transition metadata (V17 DNA-1).
    /// Examples: {"requiresApproval": true, "maxRetries": 3, "slaMinutes": 60}
    /// Enables configuring transition behavior without code changes.
    /// </summary>
    public Dictionary<string, object> Rules { get; set; } = new();

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

public class TransactionHistory
{
    public int Id { get; set; }
    public int TransactionId { get; set; }
    public Transaction Transaction { get; set; } = null!;
    public string FromStatus { get; set; } = string.Empty;
    public string ToStatus { get; set; } = string.Empty;
    public string? Reason { get; set; }

    /// <summary>
    /// Snapshot of any transition-relevant context at time of change.
    /// </summary>
    public Dictionary<string, object> Context { get; set; } = new();

    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
}
