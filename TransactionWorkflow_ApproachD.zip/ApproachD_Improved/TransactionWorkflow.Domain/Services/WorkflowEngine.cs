using TransactionWorkflow.Domain.Core;
using TransactionWorkflow.Domain.Interfaces;
using TransactionWorkflow.Domain.Models;

namespace TransactionWorkflow.Domain.Services;

/// <summary>
/// The single place that handles all workflow transition logic.
///
/// Design philosophy (V17 Freedom Machine):
///   - This class is MACHINE — generic, reusable, entity-agnostic.
///   - It doesn't know what a "transaction" is. It only knows statuses and transitions.
///   - The workflow configuration in the database is FREEDOM — changeable at runtime.
///   - All business results flow through DataProcessResult — no exceptions for expected outcomes.
///
/// To use this engine for a different entity type (orders, tickets, etc.):
///   - Add new statuses and transitions to the database
///   - Create a thin service layer similar to TransactionService
///   - Zero changes to this engine
/// </summary>
public class WorkflowEngine : IWorkflowEngine
{
    private readonly IWorkflowRepository _workflowRepo;
    private readonly ITransactionRepository _transactionRepo;

    public WorkflowEngine(IWorkflowRepository workflowRepo, ITransactionRepository transactionRepo)
    {
        _workflowRepo = workflowRepo;
        _transactionRepo = transactionRepo;
    }

    public async Task<DataProcessResult<TransitionOutcome>> TryTransitionAsync(
        int currentStatusId,
        string targetStatusName,
        string? reason = null,
        Dictionary<string, object>? context = null,
        CancellationToken ct = default)
    {
        // Resolve current status name from ID — single source of truth, no caller inconsistency
        var currentStatus = await _workflowRepo.GetStatusByIdAsync(currentStatusId, ct);
        if (currentStatus is null)
            return DataProcessResult<TransitionOutcome>.Fail(
                $"Current status with ID {currentStatusId} not found.",
                OperationStatus.ConfigurationError);

        var currentStatusName = currentStatus.Name;

        // Get allowed transitions from current status
        var allowedTransitions = await _workflowRepo.GetAllowedTransitionsAsync(currentStatusId, ct);
        var allowedTargets = allowedTransitions.Select(t => t.ToStatus).ToList();

        // Find the target among allowed
        var targetStatus = allowedTargets.FirstOrDefault(
            s => s.Name.Equals(targetStatusName, StringComparison.OrdinalIgnoreCase));

        if (targetStatus is null)
        {
            // Return structured failure with allowed list — not an exception
            var allowedNames = allowedTargets.Select(s => s.Name).ToArray();
            return DataProcessResult<TransitionOutcome>
                .Fail(
                    $"Transition from '{currentStatusName}' to '{targetStatusName}' is not allowed. " +
                    $"Allowed transitions: [{string.Join(", ", allowedNames)}]")
                .WithMeta("allowedTransitions", allowedNames)
                .WithMeta("currentStatus", currentStatusName)
                .WithMeta("attemptedStatus", targetStatusName);
        }

        // Evaluate dynamic rules on the matching transition (e.g., maxRetries)
        var matchingTransition = allowedTransitions.First(t => t.ToStatusId == targetStatus.Id);
        var ruleResult = await EvaluateRulesAsync(matchingTransition, currentStatusName, targetStatus.Name, context, ct);
        if (!ruleResult.IsSuccess)
            return ruleResult;

        // Build the successful outcome
        var outcome = new TransitionOutcome(
            TargetStatusId: targetStatus.Id,
            FromStatusName: currentStatusName,
            ToStatusName: targetStatus.Name,
            Reason: reason,
            Context: context ?? new Dictionary<string, object>(),
            TransitionedAt: DateTime.UtcNow);

        return DataProcessResult<TransitionOutcome>.Ok(outcome);
    }

    /// <summary>
    /// Evaluates dynamic rules attached to a transition (e.g., maxRetries).
    /// Rules are stored as JSON metadata on WorkflowTransition — this demonstrates
    /// that the JSON data we store is actually used, not just decorative.
    /// 
    /// Override point: add new rule types here without changing the engine flow.
    /// </summary>
    private async Task<DataProcessResult<TransitionOutcome>> EvaluateRulesAsync(
        WorkflowTransition transition,
        string fromStatusName,
        string toStatusName,
        Dictionary<string, object>? context,
        CancellationToken ct)
    {
        if (transition.Rules is null || transition.Rules.Count == 0)
            return DataProcessResult<TransitionOutcome>.Ok(null!); // No rules — pass through

        // Rule: maxRetries — limits how many times this specific transition can be taken
        if (transition.Rules.TryGetValue("maxRetries", out var maxRetriesObj))
        {
            var maxRetries = Convert.ToInt32(maxRetriesObj);

            // Count existing transitions matching this exact path in context
            // Context must include transactionId for this check
            if (context != null && context.TryGetValue("_transactionId", out var txnIdObj))
            {
                var transactionId = Convert.ToInt32(txnIdObj);
                var previousCount = await _transactionRepo.GetTransitionCountAsync(
                    transactionId, fromStatusName, toStatusName, ct);

                if (previousCount >= maxRetries)
                {
                    return DataProcessResult<TransitionOutcome>
                        .Fail(
                            $"Maximum retries exceeded for transition '{fromStatusName}' → '{toStatusName}'. " +
                            $"Limit: {maxRetries}, Attempts: {previousCount}.")
                        .WithMeta("rule", "maxRetries")
                        .WithMeta("limit", maxRetries)
                        .WithMeta("attempts", previousCount);
                }
            }
        }

        return DataProcessResult<TransitionOutcome>.Ok(null!); // All rules passed
    }

    public async Task<DataProcessResult<List<AvailableTarget>>> GetAvailableTargetsAsync(
        int statusId, CancellationToken ct = default)
    {
        var transitions = await _workflowRepo.GetAllowedTransitionsAsync(statusId, ct);

        var targets = transitions.Select(t => new AvailableTarget(
            StatusId: t.ToStatus.Id,
            StatusName: t.ToStatus.Name,
            Description: t.Description,
            Rules: t.Rules)).ToList();

        return DataProcessResult<List<AvailableTarget>>.Ok(targets);
    }

    public async Task<DataProcessResult<WorkflowStatus>> GetInitialStatusAsync(CancellationToken ct = default)
    {
        var initial = await _workflowRepo.GetInitialStatusAsync(ct);

        return initial is not null
            ? DataProcessResult<WorkflowStatus>.Ok(initial)
            : DataProcessResult<WorkflowStatus>.Fail(
                "No initial workflow status configured. Ensure seed data has been applied.",
                OperationStatus.ConfigurationError);
    }
}
