using TransactionWorkflow.Domain.Core;
using TransactionWorkflow.Domain.Models;

namespace TransactionWorkflow.Domain.Interfaces;

/// <summary>
/// Generic workflow engine interface — the MACHINE in Freedom Machine terms.
/// 
/// This engine doesn't know about "transactions" specifically. It validates
/// whether a status transition is allowed based on data-driven rules, and
/// returns a structured result. The same engine can power workflows for
/// transactions, orders, support tickets, or any entity with a status.
///
/// MACHINE (static, generic):  The engine, the validation, the transition logic.
/// FREEDOM (dynamic, data):    The statuses, transitions, and rules in the database.
///
/// Adding a new entity type with its own workflow requires:
///   - New rows in WorkflowStatuses and WorkflowTransitions tables
///   - Zero code changes, zero deployments
/// </summary>
public interface IWorkflowEngine
{
    /// <summary>
    /// Attempts a status transition. Returns Ok with outcome if valid,
    /// or ValidationError with allowed transitions list if invalid.
    /// Never throws for business logic — uses DataProcessResult instead.
    /// 
    /// Note: Only the current status ID is required. The engine resolves
    /// the status name internally, preventing caller-side inconsistencies
    /// (e.g., passing ID=1 "CREATED" but Name="COMPLETED").
    /// </summary>
    Task<DataProcessResult<TransitionOutcome>> TryTransitionAsync(
        int currentStatusId,
        string targetStatusName,
        string? reason = null,
        Dictionary<string, object>? context = null,
        CancellationToken ct = default);

    /// <summary>
    /// Returns the list of statuses reachable from the given status.
    /// </summary>
    Task<DataProcessResult<List<AvailableTarget>>> GetAvailableTargetsAsync(
        int statusId,
        CancellationToken ct = default);

    /// <summary>
    /// Returns the initial status for new entities entering the workflow.
    /// </summary>
    Task<DataProcessResult<WorkflowStatus>> GetInitialStatusAsync(CancellationToken ct = default);
}

/// <summary>
/// The outcome of a successful transition — contains everything needed
/// to update the entity and record history.
/// </summary>
public record TransitionOutcome(
    int TargetStatusId,
    string FromStatusName,
    string ToStatusName,
    string? Reason,
    Dictionary<string, object> Context,
    DateTime TransitionedAt);

/// <summary>
/// A status that can be reached from the current status.
/// </summary>
public record AvailableTarget(
    int StatusId,
    string StatusName,
    string? Description,
    Dictionary<string, object> Rules);
