using Moq;
using TransactionWorkflow.Domain.Core;
using TransactionWorkflow.Domain.Interfaces;
using TransactionWorkflow.Domain.Models;
using TransactionWorkflow.Domain.Services;

namespace TransactionWorkflow.Tests;

public class WorkflowEngineTests
{
    private readonly Mock<IWorkflowRepository> _mockRepo;
    private readonly Mock<ITransactionRepository> _mockTxnRepo;
    private readonly WorkflowEngine _engine;

    public WorkflowEngineTests()
    {
        _mockRepo = new Mock<IWorkflowRepository>();
        _mockTxnRepo = new Mock<ITransactionRepository>();
        _engine = new WorkflowEngine(_mockRepo.Object, _mockTxnRepo.Object);
    }

    private static WorkflowStatus MakeStatus(int id, string name, bool isInitial = false) =>
        new() { Id = id, Name = name, IsInitial = isInitial };

    private static WorkflowTransition MakeTransition(int fromId, WorkflowStatus toStatus,
        Dictionary<string, object>? rules = null) =>
        new() { FromStatusId = fromId, ToStatusId = toStatus.Id, ToStatus = toStatus,
                Rules = rules ?? new() };

    private void SetupStatusById(int id, string name)
    {
        _mockRepo.Setup(r => r.GetStatusByIdAsync(id, It.IsAny<CancellationToken>()))
            .ReturnsAsync(MakeStatus(id, name));
    }

    // ===== Valid Transitions =====

    [Fact]
    public async Task TryTransition_ValidPath_ReturnsOkWithOutcome()
    {
        SetupStatusById(1, "CREATED");
        var validated = MakeStatus(2, "VALIDATED");
        _mockRepo.Setup(r => r.GetAllowedTransitionsAsync(1, It.IsAny<CancellationToken>()))
            .ReturnsAsync([MakeTransition(1, validated)]);

        var result = await _engine.TryTransitionAsync(1, "VALIDATED", "Auto-validated");

        Assert.True(result.IsSuccess);
        Assert.Equal("CREATED", result.Data!.FromStatusName);
        Assert.Equal("VALIDATED", result.Data.ToStatusName);
        Assert.Equal(2, result.Data.TargetStatusId);
        Assert.Equal("Auto-validated", result.Data.Reason);
    }

    [Fact]
    public async Task TryTransition_CaseInsensitive_Works()
    {
        SetupStatusById(1, "CREATED");
        var validated = MakeStatus(2, "VALIDATED");
        _mockRepo.Setup(r => r.GetAllowedTransitionsAsync(1, It.IsAny<CancellationToken>()))
            .ReturnsAsync([MakeTransition(1, validated)]);

        var result = await _engine.TryTransitionAsync(1, "validated"); // lowercase

        Assert.True(result.IsSuccess);
        Assert.Equal("VALIDATED", result.Data!.ToStatusName);
    }

    [Fact]
    public async Task TryTransition_BackwardRetry_WorksWhenAllowed()
    {
        SetupStatusById(5, "FAILED");
        var validated = MakeStatus(2, "VALIDATED");
        _mockRepo.Setup(r => r.GetAllowedTransitionsAsync(5, It.IsAny<CancellationToken>()))
            .ReturnsAsync([MakeTransition(5, validated, new() { ["maxRetries"] = 3 })]);
        _mockTxnRepo.Setup(r => r.GetTransitionCountAsync(1, "FAILED", "VALIDATED", It.IsAny<CancellationToken>()))
            .ReturnsAsync(0);

        var context = new Dictionary<string, object> { ["_transactionId"] = 1 };
        var result = await _engine.TryTransitionAsync(5, "VALIDATED", "Retrying after fix", context);

        Assert.True(result.IsSuccess);
        Assert.Equal("FAILED", result.Data!.FromStatusName);
        Assert.Equal("VALIDATED", result.Data.ToStatusName);
        Assert.Equal("Retrying after fix", result.Data.Reason);
    }

    [Fact]
    public async Task TryTransition_WithContext_PreservesMetadata()
    {
        SetupStatusById(1, "CREATED");
        var validated = MakeStatus(2, "VALIDATED");
        _mockRepo.Setup(r => r.GetAllowedTransitionsAsync(1, It.IsAny<CancellationToken>()))
            .ReturnsAsync([MakeTransition(1, validated)]);

        var context = new Dictionary<string, object> { ["validatedBy"] = "system", ["score"] = 95 };
        var result = await _engine.TryTransitionAsync(1, "VALIDATED", context: context);

        Assert.True(result.IsSuccess);
        Assert.Equal("system", result.Data!.Context["validatedBy"]);
    }

    // ===== Invalid Transitions — Returns Failure, Not Exception =====

    [Fact]
    public async Task TryTransition_InvalidPath_ReturnsValidationErrorWithAllowed()
    {
        SetupStatusById(1, "CREATED");
        var validated = MakeStatus(2, "VALIDATED");
        _mockRepo.Setup(r => r.GetAllowedTransitionsAsync(1, It.IsAny<CancellationToken>()))
            .ReturnsAsync([MakeTransition(1, validated)]);

        var result = await _engine.TryTransitionAsync(1, "COMPLETED");

        Assert.False(result.IsSuccess);
        Assert.Equal(OperationStatus.ValidationError, result.Status);
        Assert.Contains("VALIDATED", result.Message);
        Assert.Contains("COMPLETED", result.Message);

        // Metadata includes structured error info
        Assert.NotNull(result.Metadata);
        var allowed = result.Metadata!["allowedTransitions"] as string[];
        Assert.NotNull(allowed);
        Assert.Contains("VALIDATED", allowed!);
    }

    [Fact]
    public async Task TryTransition_FinalStatus_NoTransitionsAvailable_ReturnsFail()
    {
        SetupStatusById(4, "COMPLETED");
        _mockRepo.Setup(r => r.GetAllowedTransitionsAsync(4, It.IsAny<CancellationToken>()))
            .ReturnsAsync([]);

        var result = await _engine.TryTransitionAsync(4, "PROCESSING");

        Assert.False(result.IsSuccess);
        Assert.Equal(OperationStatus.ValidationError, result.Status);
        var allowed = result.Metadata!["allowedTransitions"] as string[];
        Assert.Empty(allowed!);
    }

    [Fact]
    public async Task TryTransition_UnknownStatus_ReturnsFail()
    {
        SetupStatusById(1, "CREATED");
        var validated = MakeStatus(2, "VALIDATED");
        _mockRepo.Setup(r => r.GetAllowedTransitionsAsync(1, It.IsAny<CancellationToken>()))
            .ReturnsAsync([MakeTransition(1, validated)]);

        var result = await _engine.TryTransitionAsync(1, "NONEXISTENT");

        Assert.False(result.IsSuccess);
        Assert.Contains("NONEXISTENT", result.Message);
    }

    // ===== Rule Evaluation: maxRetries =====

    [Fact]
    public async Task TryTransition_MaxRetriesExceeded_ReturnsFail()
    {
        SetupStatusById(5, "FAILED");
        var validated = MakeStatus(2, "VALIDATED");
        _mockRepo.Setup(r => r.GetAllowedTransitionsAsync(5, It.IsAny<CancellationToken>()))
            .ReturnsAsync([MakeTransition(5, validated, new() { ["maxRetries"] = 3 })]);
        _mockTxnRepo.Setup(r => r.GetTransitionCountAsync(42, "FAILED", "VALIDATED", It.IsAny<CancellationToken>()))
            .ReturnsAsync(3); // Already retried 3 times — at the limit

        var context = new Dictionary<string, object> { ["_transactionId"] = 42 };
        var result = await _engine.TryTransitionAsync(5, "VALIDATED", "Retry attempt", context);

        Assert.False(result.IsSuccess);
        Assert.Equal(OperationStatus.ValidationError, result.Status);
        Assert.Contains("Maximum retries exceeded", result.Message);
        Assert.Equal("maxRetries", result.Metadata!["rule"]);
        Assert.Equal(3, result.Metadata!["limit"]);
    }

    [Fact]
    public async Task TryTransition_MaxRetriesWithinLimit_Succeeds()
    {
        SetupStatusById(5, "FAILED");
        var validated = MakeStatus(2, "VALIDATED");
        _mockRepo.Setup(r => r.GetAllowedTransitionsAsync(5, It.IsAny<CancellationToken>()))
            .ReturnsAsync([MakeTransition(5, validated, new() { ["maxRetries"] = 3 })]);
        _mockTxnRepo.Setup(r => r.GetTransitionCountAsync(42, "FAILED", "VALIDATED", It.IsAny<CancellationToken>()))
            .ReturnsAsync(2); // 2 out of 3 — still within limit

        var context = new Dictionary<string, object> { ["_transactionId"] = 42 };
        var result = await _engine.TryTransitionAsync(5, "VALIDATED", "Retry attempt", context);

        Assert.True(result.IsSuccess);
    }

    // ===== Available Targets =====

    [Fact]
    public async Task GetAvailableTargets_ReturnsAllWithRules()
    {
        var completed = MakeStatus(4, "COMPLETED");
        var failed = MakeStatus(5, "FAILED");
        _mockRepo.Setup(r => r.GetAllowedTransitionsAsync(3, It.IsAny<CancellationToken>()))
            .ReturnsAsync([
                MakeTransition(3, completed),
                MakeTransition(3, failed, new() { ["autoRetry"] = true })
            ]);

        var result = await _engine.GetAvailableTargetsAsync(3);

        Assert.True(result.IsSuccess);
        Assert.Equal(2, result.Data!.Count);
        Assert.Contains(result.Data, t => t.StatusName == "COMPLETED");
        Assert.Contains(result.Data, t => t.StatusName == "FAILED" && t.Rules.ContainsKey("autoRetry"));
    }

    // ===== Initial Status =====

    [Fact]
    public async Task GetInitialStatus_WhenConfigured_ReturnsOk()
    {
        _mockRepo.Setup(r => r.GetInitialStatusAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(MakeStatus(1, "CREATED", isInitial: true));

        var result = await _engine.GetInitialStatusAsync();

        Assert.True(result.IsSuccess);
        Assert.Equal("CREATED", result.Data!.Name);
    }

    [Fact]
    public async Task GetInitialStatus_NotConfigured_ReturnsConfigError()
    {
        _mockRepo.Setup(r => r.GetInitialStatusAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync((WorkflowStatus?)null);

        var result = await _engine.GetInitialStatusAsync();

        Assert.False(result.IsSuccess);
        Assert.Equal(OperationStatus.ConfigurationError, result.Status);
        Assert.Contains("initial", result.Message, StringComparison.OrdinalIgnoreCase);
    }
}
