# Transaction Workflow Engine — Approach D (Strategic Hybrid)

The **recommended approach** — balances standard .NET patterns with robust internal architecture. Uses `DataProcessResult` for explicit error handling, JSON metadata for extensibility, and keeps complexity manageable for teams of all levels.

## Quick Start

```bash
./start.sh
# ✅ Systems GO! API running at http://localhost:5000/swagger
```

### Run Tests

```bash
dotnet test
```

---

## API Endpoints

### Transactions

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/transactions` | Create a new transaction |
| `GET` | `/transactions/{id}` | Get transaction by ID |
| `POST` | `/transactions/{id}/transition` | Transition to a new status |
| `GET` | `/transactions/{id}/available-transitions` | List valid next statuses |
| `GET` | `/transactions/{id}/history` | Get status change history |

### Admin — Workflow Management

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/admin/workflow/statuses` | List all workflow statuses |
| `POST` | `/admin/workflow/statuses` | Add a new status |
| `GET` | `/admin/workflow/transitions` | List all transitions |
| `POST` | `/admin/workflow/transitions` | Add transition (supports JSON rules) |
| `GET` | `/admin/workflow/visualize` | **NEW** Mermaid.js workflow diagram |

### Seeded Workflow

```
CREATED → VALIDATED → PROCESSING → COMPLETED
                                 ↘ FAILED → VALIDATED (retry, max 3 retries)
```

### Example: Dynamic Metadata

```bash
curl -X POST http://localhost:5000/transactions \
  -H "Content-Type: application/json" \
  -d '{"amount":250,"currency":"USD","metadata":{"merchantId":"M-123","channel":"web"}}'
```

### Example: Transition Rules (maxRetries)

The FAILED → VALIDATED transition has `{"maxRetries":3}`. After 3 retry attempts, the engine blocks further retries and returns a structured error explaining why.

---

## Architecture

```
TransactionWorkflow.API          → Controllers, ResultMapper, validators
TransactionWorkflow.Application  → Services (thin orchestration layer)
TransactionWorkflow.Domain       → WorkflowEngine, DataProcessResult, models
TransactionWorkflow.Infrastructure → EF Core, repositories, caching
TransactionWorkflow.Tests        → Unit + integration tests
```

### Why D Is the Recommended Approach

| Concern | A (Vanilla) | B (Multi-Tenant) | **D (Hybrid)** |
|---------|-------------|-------------------|----------------|
| Error handling | Exceptions | DataProcessResult | **DataProcessResult** |
| Extensibility | Low | Maximum | **High (JSON rules)** |
| Complexity | Low | High | **Medium** |
| Team accessibility | Any level | Senior+ | **Any level** |
| Error format | Custom JSON | ProblemDetails | **ProblemDetails (RFC 7807)** |

### Key Design Decisions

1. **DataProcessResult** — no exceptions for expected business outcomes
2. **RFC 7807 ProblemDetails** — standardized, machine-readable errors
3. **JSON metadata** — Transaction.Metadata and WorkflowTransition.Rules stored as JSON columns
4. **Rule evaluation engine** — JSON rules are actually enforced (maxRetries), not just decorative
5. **FluentValidation** — input sanitization at the gateway
6. **Docker health checks** — reliable startup with secret management

### Security

- Secrets in `.env` file (git-ignored)
- FluentValidation on all inputs
- Mass assignment protection via DTOs
- Optimistic concurrency → 409 Conflict via DataProcessResult
- DbUpdateConcurrencyException handled in repository, returned as structured result

---

## Time Spent

~5 hours total (including bonus features, tests, and improvements).
