using TransactionWorkflow.Domain.Core;
using TransactionWorkflow.Domain.Interfaces;
using TransactionWorkflow.Domain.Models;

namespace TransactionWorkflow.Domain.Services;

/// <summary>
/// The single place that handles all workflow transition logic.
///
/// Design philosophy (V17 Freedom Machine):
///   - This class is MACHINE — generic, reusable, entity-agnostic.
///   - It doesn't know what a "transaction" is. It only knows statuses and transitions.
///   - The workflow configuration in the database is FREEDOM — changeable at runtime.
///   - All business results flow through DataProcessResult — no exceptions for expected outcomes.
///
/// To use this engine for a different entity type (orders, tickets, etc.):
///   - Add new statuses and transitions to the database
///   - Create a thin service layer similar to TransactionService
///   - Zero changes to this engine
///
/// Note: The engine does NOT depend on any entity-specific repository.
///       History-based data (e.g., prior transition counts for maxRetries) is passed
///       in from the calling service layer, keeping the engine truly generic.
/// </summary>
public class WorkflowEngine : IWorkflowEngine
{
    private readonly IWorkflowRepository _workflowRepo;

    public WorkflowEngine(IWorkflowRepository workflowRepo)
    {
        _workflowRepo = workflowRepo;
    }

    public async Task<DataProcessResult<TransitionOutcome>> TryTransitionAsync(
        int currentStatusId,
        string targetStatusName,
        string? reason = null,
        Dictionary<string, object>? context = null,
        int priorTransitionCount = 0,
        CancellationToken ct = default)
    {
        // Resolve current status name from ID — single source of truth, no caller inconsistency
        var currentStatus = await _workflowRepo.GetStatusByIdAsync(currentStatusId, ct);
        if (currentStatus is null)
            return DataProcessResult<TransitionOutcome>.Fail(
                $"Current status with ID {currentStatusId} not found.",
                OperationStatus.ConfigurationError);

        var currentStatusName = currentStatus.Name;

        // Get allowed transitions from current status
        var allowedTransitions = await _workflowRepo.GetAllowedTransitionsAsync(currentStatusId, ct);
        var allowedTargets = allowedTransitions.Select(t => t.ToStatus).ToList();

        // Find the target among allowed
        var targetStatus = allowedTargets.FirstOrDefault(
            s => s.Name.Equals(targetStatusName, StringComparison.OrdinalIgnoreCase));

        if (targetStatus is null)
        {
            // Return structured failure with allowed list — not an exception
            var allowedNames = allowedTargets.Select(s => s.Name).ToArray();
            return DataProcessResult<TransitionOutcome>
                .Fail(
                    $"Transition from '{currentStatusName}' to '{targetStatusName}' is not allowed. " +
                    $"Allowed transitions: [{string.Join(", ", allowedNames)}]")
                .WithMeta("allowedTransitions", allowedNames)
                .WithMeta("currentStatus", currentStatusName)
                .WithMeta("attemptedStatus", targetStatusName);
        }

        // Evaluate dynamic rules on the matching transition (e.g., maxRetries)
        var matchingTransition = allowedTransitions.First(t => t.ToStatusId == targetStatus.Id);
        var ruleResult = EvaluateTransitionRules(
            matchingTransition.Rules, priorTransitionCount,
            currentStatusName, targetStatus.Name);
        if (!ruleResult.IsSuccess)
            return ruleResult;

        // Build the successful outcome
        var outcome = new TransitionOutcome(
            TargetStatusId: targetStatus.Id,
            FromStatusName: currentStatusName,
            ToStatusName: targetStatus.Name,
            Reason: reason,
            Context: context ?? new Dictionary<string, object>(),
            TransitionedAt: DateTime.UtcNow);

        return DataProcessResult<TransitionOutcome>.Ok(outcome);
    }

    // ═══════════════════════════════════════════════════════════════════
    // RULE EVALUATION ENGINE
    //
    // Transition rules are stored as Dictionary<string,object> in the DB
    // (FREEDOM — changeable at runtime). The evaluation logic is MACHINE.
    //
    // Currently supported rules:
    //   maxRetries (int) — maximum times this specific transition can occur.
    //                      Prevents infinite retry loops.
    //
    // Adding new rule types (e.g., "requiresApproval", "slaMinutes"):
    //   1. Add the rule key+value to the transition in the DB
    //   2. Add evaluation logic here
    //   3. Zero interface changes
    // ═══════════════════════════════════════════════════════════════════
    private static DataProcessResult<TransitionOutcome> EvaluateTransitionRules(
        Dictionary<string, object> rules,
        int priorTransitionCount,
        string fromStatus,
        string toStatus)
    {
        if (rules is null || rules.Count == 0)
            return DataProcessResult<TransitionOutcome>.Ok(null!); // No rules — pass through

        if (rules.TryGetValue("maxRetries", out var maxRetriesObj))
        {
            var maxRetries = Convert.ToInt32(maxRetriesObj);
            if (priorTransitionCount >= maxRetries)
            {
                return DataProcessResult<TransitionOutcome>
                    .Fail(
                        $"Maximum retries exceeded for transition '{fromStatus}' → '{toStatus}'. " +
                        $"Limit: {maxRetries}, Attempts: {priorTransitionCount}.")
                    .WithMeta("rule", "maxRetries")
                    .WithMeta("limit", maxRetries)
                    .WithMeta("attempts", priorTransitionCount);
            }
        }

        // Future rules: requiresApproval, slaMinutes, minimumAmount, etc.

        return DataProcessResult<TransitionOutcome>.Ok(null!); // All rules passed
    }

    public async Task<DataProcessResult<List<AvailableTarget>>> GetAvailableTargetsAsync(
        int statusId, CancellationToken ct = default)
    {
        var transitions = await _workflowRepo.GetAllowedTransitionsAsync(statusId, ct);

        var targets = transitions.Select(t => new AvailableTarget(
            StatusId: t.ToStatus.Id,
            StatusName: t.ToStatus.Name,
            Description: t.Description,
            Rules: t.Rules)).ToList();

        return DataProcessResult<List<AvailableTarget>>.Ok(targets);
    }

    public async Task<DataProcessResult<WorkflowStatus>> GetInitialStatusAsync(CancellationToken ct = default)
    {
        var initial = await _workflowRepo.GetInitialStatusAsync(ct);

        return initial is not null
            ? DataProcessResult<WorkflowStatus>.Ok(initial)
            : DataProcessResult<WorkflowStatus>.Fail(
                "No initial workflow status configured. Ensure seed data has been applied.",
                OperationStatus.ConfigurationError);
    }
}
