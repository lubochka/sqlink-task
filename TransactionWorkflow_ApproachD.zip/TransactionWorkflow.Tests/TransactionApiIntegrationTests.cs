using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using TransactionWorkflow.Application.DTOs;
using TransactionWorkflow.Infrastructure.Data;

namespace TransactionWorkflow.Tests;

public class TransactionApiIntegrationTests : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly HttpClient _client;
    private static readonly JsonSerializerOptions JsonOpts = new() { PropertyNameCaseInsensitive = true };

    public TransactionApiIntegrationTests(WebApplicationFactory<Program> factory)
    {
        _client = factory.WithWebHostBuilder(builder =>
        {
            builder.ConfigureServices(services =>
            {
                var desc = services.SingleOrDefault(d => d.ServiceType == typeof(DbContextOptions<AppDbContext>));
                if (desc != null) services.Remove(desc);

                services.AddDbContext<AppDbContext>(opts =>
                    opts.UseInMemoryDatabase("TestDb_" + Guid.NewGuid()));

                var sp = services.BuildServiceProvider();
                using var scope = sp.CreateScope();
                var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
                db.Database.EnsureCreated();
            });
        }).CreateClient();
    }

    // ===== Create Transaction =====

    [Fact]
    public async Task Create_ReturnsCreatedWithInitialStatus()
    {
        var request = new CreateTransactionRequest(250.50m, "USD", "Test payment",
            new Dictionary<string, object> { ["merchantId"] = "M-789" });
        var response = await _client.PostAsJsonAsync("/transactions", request);

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var txn = await response.Content.ReadFromJsonAsync<TransactionDto>(JsonOpts);
        Assert.NotNull(txn);
        Assert.Equal("CREATED", txn.Status);
        Assert.Equal(250.50m, txn.Amount);
        Assert.StartsWith("TXN-", txn.ReferenceNumber);
    }

    [Fact]
    public async Task Create_WithMetadata_PreservesMetadata()
    {
        var meta = new Dictionary<string, object> { ["channel"] = "web", ["priority"] = "high" };
        var request = new CreateTransactionRequest(100m, Metadata: meta);
        var response = await _client.PostAsJsonAsync("/transactions", request);

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var txn = await response.Content.ReadFromJsonAsync<TransactionDto>(JsonOpts);
        Assert.NotNull(txn?.Metadata);
    }

    // ===== Get Transaction =====

    [Fact]
    public async Task Get_ExistingId_ReturnsOk()
    {
        var createResp = await _client.PostAsJsonAsync("/transactions", new CreateTransactionRequest(100m));
        var created = await createResp.Content.ReadFromJsonAsync<TransactionDto>(JsonOpts);

        var response = await _client.GetAsync($"/transactions/{created!.Id}");
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
    }

    [Fact]
    public async Task Get_NonExistent_Returns404()
    {
        var response = await _client.GetAsync("/transactions/99999");
        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);

        var body = await response.Content.ReadAsStringAsync();
        Assert.Contains("not found", body, StringComparison.OrdinalIgnoreCase);
    }

    // ===== Valid Transitions =====

    [Fact]
    public async Task Transition_ValidPath_ReturnsUpdatedStatus()
    {
        var createResp = await _client.PostAsJsonAsync("/transactions", new CreateTransactionRequest(100m));
        var txn = await createResp.Content.ReadFromJsonAsync<TransactionDto>(JsonOpts);

        var transResp = await _client.PostAsJsonAsync(
            $"/transactions/{txn!.Id}/transition",
            new TransitionRequest("VALIDATED", "All checks passed"));

        Assert.Equal(HttpStatusCode.OK, transResp.StatusCode);
        var updated = await transResp.Content.ReadFromJsonAsync<TransactionDto>(JsonOpts);
        Assert.Equal("VALIDATED", updated!.Status);
    }

    // ===== Invalid Transitions — Structured Error Response =====

    [Fact]
    public async Task Transition_InvalidPath_Returns400WithAllowedList()
    {
        var createResp = await _client.PostAsJsonAsync("/transactions", new CreateTransactionRequest(100m));
        var txn = await createResp.Content.ReadFromJsonAsync<TransactionDto>(JsonOpts);

        var transResp = await _client.PostAsJsonAsync(
            $"/transactions/{txn!.Id}/transition",
            new TransitionRequest("COMPLETED"));

        Assert.Equal(HttpStatusCode.BadRequest, transResp.StatusCode);

        // Error response includes structured metadata with allowed transitions
        var body = await transResp.Content.ReadAsStringAsync();
        Assert.Contains("VALIDATED", body);
        Assert.Contains("allowedTransitions", body);
    }

    // ===== Full Workflow Paths =====

    [Fact]
    public async Task FullWorkflow_HappyPath_CreatedToCompleted()
    {
        var resp = await _client.PostAsJsonAsync("/transactions", new CreateTransactionRequest(500m));
        var txn = await resp.Content.ReadFromJsonAsync<TransactionDto>(JsonOpts);
        Assert.Equal("CREATED", txn!.Status);

        resp = await _client.PostAsJsonAsync($"/transactions/{txn.Id}/transition", new TransitionRequest("VALIDATED"));
        txn = await resp.Content.ReadFromJsonAsync<TransactionDto>(JsonOpts);
        Assert.Equal("VALIDATED", txn!.Status);

        resp = await _client.PostAsJsonAsync($"/transactions/{txn.Id}/transition", new TransitionRequest("PROCESSING"));
        txn = await resp.Content.ReadFromJsonAsync<TransactionDto>(JsonOpts);
        Assert.Equal("PROCESSING", txn!.Status);

        resp = await _client.PostAsJsonAsync($"/transactions/{txn.Id}/transition", new TransitionRequest("COMPLETED"));
        txn = await resp.Content.ReadFromJsonAsync<TransactionDto>(JsonOpts);
        Assert.Equal("COMPLETED", txn!.Status);
    }

    [Fact]
    public async Task FullWorkflow_FailureRetryPath()
    {
        var resp = await _client.PostAsJsonAsync("/transactions", new CreateTransactionRequest(200m));
        var txn = await resp.Content.ReadFromJsonAsync<TransactionDto>(JsonOpts);

        await _client.PostAsJsonAsync($"/transactions/{txn!.Id}/transition", new TransitionRequest("VALIDATED"));
        await _client.PostAsJsonAsync($"/transactions/{txn.Id}/transition", new TransitionRequest("PROCESSING"));
        resp = await _client.PostAsJsonAsync($"/transactions/{txn.Id}/transition",
            new TransitionRequest("FAILED", "Gateway timeout"));
        txn = await resp.Content.ReadFromJsonAsync<TransactionDto>(JsonOpts);
        Assert.Equal("FAILED", txn!.Status);

        // Retry: FAILED → VALIDATED (backward transition)
        resp = await _client.PostAsJsonAsync($"/transactions/{txn.Id}/transition",
            new TransitionRequest("VALIDATED", "Retrying"));
        txn = await resp.Content.ReadFromJsonAsync<TransactionDto>(JsonOpts);
        Assert.Equal("VALIDATED", txn!.Status);
    }

    // ===== Available Transitions =====

    [Fact]
    public async Task AvailableTransitions_ReturnsCorrectOptions()
    {
        var resp = await _client.PostAsJsonAsync("/transactions", new CreateTransactionRequest(100m));
        var txn = await resp.Content.ReadFromJsonAsync<TransactionDto>(JsonOpts);

        var transResp = await _client.GetAsync($"/transactions/{txn!.Id}/available-transitions");
        Assert.Equal(HttpStatusCode.OK, transResp.StatusCode);

        var available = await transResp.Content.ReadFromJsonAsync<List<AvailableTransitionDto>>(JsonOpts);
        Assert.Single(available!);
        Assert.Equal("VALIDATED", available[0].StatusName);
    }

    // ===== History =====

    [Fact]
    public async Task History_RecordsAllTransitions()
    {
        var resp = await _client.PostAsJsonAsync("/transactions", new CreateTransactionRequest(100m));
        var txn = await resp.Content.ReadFromJsonAsync<TransactionDto>(JsonOpts);

        await _client.PostAsJsonAsync($"/transactions/{txn!.Id}/transition",
            new TransitionRequest("VALIDATED", "Auto-validated"));
        await _client.PostAsJsonAsync($"/transactions/{txn.Id}/transition",
            new TransitionRequest("PROCESSING"));

        var histResp = await _client.GetAsync($"/transactions/{txn.Id}/history");
        var history = await histResp.Content.ReadFromJsonAsync<List<TransactionHistoryDto>>(JsonOpts);

        Assert.Equal(2, history!.Count);
        Assert.Equal("CREATED", history[0].FromStatus);
        Assert.Equal("VALIDATED", history[0].ToStatus);
        Assert.Equal("Auto-validated", history[0].Reason);
        Assert.Equal("VALIDATED", history[1].FromStatus);
        Assert.Equal("PROCESSING", history[1].ToStatus);
    }

    // ===== Admin =====

    [Fact]
    public async Task Admin_AddStatusAndTransition_WorksAtRuntime()
    {
        // Add new status
        var statusResp = await _client.PostAsJsonAsync("/admin/workflow/statuses",
            new AddStatusRequest("REVIEW", "Manual review required"));
        Assert.Equal(HttpStatusCode.Created, statusResp.StatusCode);

        // Add transition: VALIDATED → REVIEW
        var transResp = await _client.PostAsJsonAsync("/admin/workflow/transitions",
            new AddTransitionRequest("VALIDATED", "REVIEW", "Route to manual review",
                new Dictionary<string, object> { ["slaMinutes"] = 120 }));
        Assert.Equal(HttpStatusCode.Created, transResp.StatusCode);

        // Verify the new transition is available
        var resp = await _client.PostAsJsonAsync("/transactions", new CreateTransactionRequest(100m));
        var txn = await resp.Content.ReadFromJsonAsync<TransactionDto>(JsonOpts);
        await _client.PostAsJsonAsync($"/transactions/{txn!.Id}/transition", new TransitionRequest("VALIDATED"));

        var available = await _client.GetFromJsonAsync<List<AvailableTransitionDto>>(
            $"/transactions/{txn.Id}/available-transitions", JsonOpts);

        // Should now have PROCESSING and REVIEW as options
        Assert.Contains(available!, a => a.StatusName == "REVIEW");
        Assert.Contains(available!, a => a.StatusName == "PROCESSING");
    }
}
