using TransactionWorkflow.Domain.Core;

namespace TransactionWorkflow.Tests;

public class DataProcessResultTests
{
    [Fact]
    public void Ok_IsSuccess_True()
    {
        var result = DataProcessResult<string>.Ok("hello");
        Assert.True(result.IsSuccess);
        Assert.Equal("hello", result.Data);
        Assert.Equal(OperationStatus.Success, result.Status);
    }

    [Fact]
    public void Fail_IsSuccess_False()
    {
        var result = DataProcessResult<string>.Fail("bad input");
        Assert.False(result.IsSuccess);
        Assert.Equal(OperationStatus.ValidationError, result.Status);
        Assert.Equal("bad input", result.Message);
    }

    [Fact]
    public void NotFound_Status_Correct()
    {
        var result = DataProcessResult<int>.NotFound("Item 42 not found");
        Assert.Equal(OperationStatus.NotFound, result.Status);
    }

    [Fact]
    public void Conflict_Status_Correct()
    {
        var result = DataProcessResult<object>.Conflict("Already modified");
        Assert.Equal(OperationStatus.Conflict, result.Status);
    }

    [Fact]
    public void WithMeta_AddsMetadataToResult()
    {
        var result = DataProcessResult<string>.Fail("invalid")
            .WithMeta("allowed", new[] { "A", "B" })
            .WithMeta("current", "C");

        Assert.NotNull(result.Metadata);
        Assert.Equal(2, result.Metadata!.Count);
        Assert.Equal("C", result.Metadata["current"]);
    }

    [Fact]
    public void WithMetadata_PreservesDataAndMetadata()
    {
        var meta = new Dictionary<string, object> { ["key"] = "value" };
        var result = DataProcessResult<int>.WithMetadata(42, meta);

        Assert.True(result.IsSuccess);
        Assert.Equal(42, result.Data);
        Assert.Equal("value", result.Metadata!["key"]);
    }
}
