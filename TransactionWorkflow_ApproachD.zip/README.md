# Transaction Workflow Engine — Approach D (Strategic Hybrid)

The **recommended approach** — balances standard .NET patterns with robust internal architecture. Uses `DataProcessResult` for explicit error handling, JSON metadata for extensibility, and keeps complexity manageable for teams of all levels.

> **Philosophy:** Standard .NET outside, Freedom Machine inside. 80% of the benefits with 20% of the complexity.

---

## 🗺️ Document Map & Project Structure

```text
TransactionWorkflow/
├── .ai-config/                              # 🧠 AI Agent Context
│   ├── project-architecture.md              # Hybrid philosophy
│   ├── coding-standards.md                  # DataProcessResult + engine purity
│   └── v17-skill-map.md                     # V17 skill → file mapping
├── .github/copilot-instructions.md          # GitHub Copilot rules
├── CLAUDE.md                                # Claude Code instructions
├── TransactionWorkflow.Domain/              # 🟡 THE MACHINE
│   ├── Core/
│   │   └── DataProcessResult.cs             # [Skill 01] Universal return type
│   ├── Models/                              # Transaction (with Metadata), WorkflowStatus/Transition
│   ├── Interfaces/
│   │   ├── IWorkflowEngine.cs              # [Skill 09] Generic engine (no entity repos)
│   │   └── IRepositories.cs                # Repository contracts
│   └── Services/
│       └── WorkflowEngine.cs                # [Skill 09] Generic orchestrator
│                                            # [Skill 02] EvaluateTransitionRules (JSON)
├── TransactionWorkflow.Application/         # 🟠 ADAPTER LAYER
│   └── Services/
│       └── TransactionService.cs            # Bridges Transaction → WorkflowEngine
│                                            # Provides priorTransitionCount to engine
├── TransactionWorkflow.Infrastructure/      # 🔵 PERSISTENCE [Skill 05]
│   ├── Data/AppDbContext.cs                 # EF Core + JSON value converters
│   ├── Repositories/                        # Concrete repos
│   └── Caching/CachedWorkflowRepository.cs  # [Skill 45] Decorator pattern
├── TransactionWorkflow.API/                 # 🟣 GATEWAY [Skill 15]
│   ├── Controllers/                         # Transactions + Admin
│   ├── Extensions/ResultMapper.cs           # DataProcessResult → ProblemDetails
│   └── Middleware/GlobalExceptionMiddleware.cs  # Safety net for unexpected errors
├── TransactionWorkflow.Tests/               # 🟢 TESTING [Skill 29]
├── docker-compose.yml
└── start.sh
```

---

## 🚀 Quick Start

```bash
./start.sh
# ✅ API at http://localhost:5000/swagger
```

### Run Tests
```bash
dotnet test
```

---

## 📡 API Endpoints

### Transactions

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/transactions` | Create transaction (supports JSON metadata) |
| `GET` | `/transactions/{id}` | Get transaction by ID |
| `POST` | `/transactions/{id}/transition` | Transition to a new status |
| `GET` | `/transactions/{id}/available-transitions` | List valid next statuses |
| `GET` | `/transactions/{id}/history` | Get status change history |

### Admin

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/admin/workflow/statuses` | List all statuses |
| `POST` | `/admin/workflow/statuses` | Add a status |
| `GET` | `/admin/workflow/transitions` | List all transitions |
| `POST` | `/admin/workflow/transitions` | Add transition (supports JSON rules) |
| `GET` | `/admin/workflow/visualize` | Mermaid.js workflow diagram |

### Seeded Workflow
```
CREATED → VALIDATED → PROCESSING → COMPLETED
                               ↘ FAILED → VALIDATED (retry, maxRetries: 3)
```

### Dynamic Metadata Example
```bash
curl -X POST http://localhost:5000/transactions \
  -H "Content-Type: application/json" \
  -d '{"amount": 500, "currency": "USD", "metadata": {"priority": "high", "department": "sales"}}'
```

---

## 📖 How-To Guides

### Add a New Status (Data Only)
```sql
INSERT INTO WorkflowStatuses (Name, IsInitial, IsFinal)
VALUES ('REVIEW_PENDING', 0, 0);
```

### Add a New Business Rule
**Step 1 — Database (Freedom):** Add rule to transition's JSON:
```sql
UPDATE WorkflowTransitions SET Rules = '{"maxRetries": 3, "minAmount": 100}'
WHERE Id = @transitionId;
```
**Step 2 — Engine (Machine):** Add evaluator in `WorkflowEngine.EvaluateTransitionRules()`:
```csharp
if (rules.TryGetValue("minAmount", out var minObj))
{
    // Generic evaluation — works for any entity
}
```

---

## 🛠️ V17 Skill Integration

| V17 Skill | Implementation | Key File |
|-----------|----------------|----------|
| **Skill 01** (Core Interfaces) | DataProcessResult + Metadata + `.WithMeta()` | `Domain/Core/DataProcessResult.cs` |
| **Skill 02** (Object Processor) | JSON rule evaluation (maxRetries) | `Domain/Services/WorkflowEngine.cs` |
| **Skill 05** (Database Fabric) | EF Core + JSON value converters | `Infrastructure/Data/AppDbContext.cs` |
| **Skill 08** (Flow Definition) | DB-driven statuses/transitions + Mermaid | `Domain/Models/` |
| **Skill 09** (Flow Orchestrator) | Generic engine (no entity repo deps) | `Domain/Services/WorkflowEngine.cs` |
| **Skill 15** (API Gateway) | ResultMapper → ProblemDetails (RFC 7807) | `API/Extensions/ResultMapper.cs` |
| **Skill 29** (Testing) | Engine tests without entity dependencies | `Tests/WorkflowEngineTests.cs` |
| **Skill 45** (Design Patterns) | Decorator, Adapter, Strategy | Multiple files |

---

## 🧠 AI Agent Configuration

| Agent | Config File |
|-------|-------------|
| GitHub Copilot | `.github/copilot-instructions.md` |
| Claude Code | `CLAUDE.md` |
| General | `.ai-config/project-architecture.md` |

**Key Rules:**
1. Never throw exceptions — use `DataProcessResult<T>`
2. WorkflowEngine depends ONLY on `IWorkflowRepository`
3. `priorTransitionCount` passed from service, not looked up by engine
4. Prefer JSON rules + DB data over C# code changes
