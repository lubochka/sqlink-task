# V17 Skill Map — Approach D (Strategic Hybrid)

Maps XIIGen V17 skills to actual implementations in this codebase.
Approach D uses a **balanced** V17 skill set — full DataProcessResult and JSON rules,
but without multi-tenant EntityType scoping.

## Skill Mapping

### ✅ Active Skills

| V17 Skill | File(s) | How It's Applied |
|-----------|---------|------------------|
| **Skill 01: Core Interfaces** | `Domain/Core/DataProcessResult.cs` | Universal return type with OperationStatus, Metadata dictionary, `.WithMeta()` fluent API. Never throw for business logic. |
| **Skill 02: Object Processor** | `Domain/Services/WorkflowEngine.cs` → `EvaluateTransitionRules()` | JSON rules (e.g., `{"maxRetries": 3}`) on WorkflowTransition parsed and evaluated generically. Adding new rules requires zero interface changes. |
| **Skill 05: Database Fabric** | `Infrastructure/Data/AppDbContext.cs`, `Infrastructure/Repositories/` | EF Core with JSON value converters for `Dictionary<string,object>` columns (Rules, Metadata). ValueComparer for change tracking. |
| **Skill 08: Flow Definition** | `Domain/Models/WorkflowStatus.cs`, `WorkflowTransition.cs` | Workflow defined as DB rows. Mermaid visualization via `/admin/workflow/visualize`. Transitions carry JSON Rules and Description. |
| **Skill 09: Flow Orchestrator** | `Domain/Services/WorkflowEngine.cs` | Generic engine depends only on `IWorkflowRepository`. Validates transitions, evaluates JSON rules, returns TransitionOutcome. `priorTransitionCount` passed from service (not looked up). |
| **Skill 15: API Gateway** | `API/Extensions/ResultMapper.cs`, `API/Middleware/GlobalExceptionMiddleware.cs` | ResultMapper: DataProcessResult → ProblemDetails (RFC 7807). GlobalExceptionMiddleware: safety net for unexpected failures. |
| **Skill 29: Testing** | `Tests/WorkflowEngineTests.cs`, `Tests/DataProcessResultTests.cs` | Unit tests verify engine without ITransactionRepository dependency. Tests for valid/invalid transitions, rule evaluation, edge cases. |
| **Skill 45: Design Patterns** | Multiple files | **Decorator:** CachedWorkflowRepository. **Adapter:** TransactionService (specific→generic). **Strategy:** JSON rule evaluators. |

### ❌ Not Used

| V17 Skill | Why |
|-----------|-----|
| EntityType scoping (B-specific) | D is single-tenant by design — simpler |
| Skill 06/07: AI Providers | Not applicable to workflow assignment |
| Skill 10: Figma Parser | Not applicable |
| Skill 27: K8s Deployment | Docker Compose only |

## Pattern Alignment

| V17 Pattern | Approach D Implementation |
|------------|--------------------------|
| `DataProcessResult<T>` | Exact match — `Domain/Core/DataProcessResult.cs` |
| `ParseObjectAlternative` | JSON rule/metadata parsing via System.Text.Json + Dictionary |
| `Dictionary<string,object>` | Transaction.Metadata + WorkflowTransition.Rules + DataProcessResult.Metadata |
| Engine purity | WorkflowEngine depends only on IWorkflowRepository (no entity repos) |
| `ResultMapper` | `API/Extensions/ResultMapper.cs` — single mapping point |
| Decorator pattern | `CachedWorkflowRepository` wraps `WorkflowRepository` |

## How to Extend (V17 Way)

### Adding a New Business Rule

**Step 1 — Freedom (Data):**
```sql
UPDATE WorkflowTransitions
SET Rules = '{"maxRetries": 3, "minAmount": 100}'
WHERE FromStatusId = @processingId AND ToStatusId = @completedId;
```

**Step 2 — Machine (Code):**
```csharp
// Add to WorkflowEngine.EvaluateTransitionRules()
if (rules.TryGetValue("minAmount", out var minObj))
{
    var min = Convert.ToDecimal(minObj);
    if (context != null && context.TryGetValue("amount", out var amtObj))
    {
        if (Convert.ToDecimal(amtObj) < min)
            return DataProcessResult<TransitionOutcome>.Fail($"Amount below {min}")
                .WithMeta("rule", "minAmount").WithMeta("limit", min);
    }
}
```

### Adding Transaction Metadata

```bash
# No code changes needed — metadata is already dynamic
curl -X POST http://localhost:5000/transactions \
  -H "Content-Type: application/json" \
  -d '{"amount": 500, "currency": "USD", "metadata": {"priority": "high", "department": "sales"}}'
```
