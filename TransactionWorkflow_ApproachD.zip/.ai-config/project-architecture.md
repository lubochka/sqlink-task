# Approach D: Strategic Hybrid (Recommended)

## Philosophy

Standard .NET Clean Architecture on the outside, powered by a generic **Freedom Machine** on
the inside. Uses `DataProcessResult` for robust error handling and JSON metadata for extensibility,
but keeps complexity manageable by staying single-tenant (no EntityType scoping).

### Guiding Principle

> **Balance:** Get 80% of the Freedom Machine's benefits with 20% of its complexity.
> The engine is generic in behavior but scoped to a single deployment context.

## Architecture Pattern

```
API Layer (Controllers + ResultMapper)      ← Skill 15: Gateway
    ↓ Returns DataProcessResult<T>
Application Layer (TransactionService)      ← Adapter: thin bridge to engine
    ↓ Calls engine + provides priorTransitionCount
Domain Layer (WorkflowEngine + DataProcessResult)  ← Skills 01, 02, 09: Generic Machine
    ↓ Persisted by
Infrastructure Layer (EF Core + Caching)    ← Skill 05: Database Fabric
```

## Error Handling Strategy

Like Approach B, Approach D uses **DataProcessResult<T>** for ALL business outcomes:

- `DataProcessResult.Fail(msg, ValidationError)` → ResultMapper → 400 ProblemDetails
- `DataProcessResult.NotFound(msg)` → ResultMapper → 404 ProblemDetails
- `DataProcessResult.Conflict(msg)` → ResultMapper → 409 ProblemDetails
- Unexpected exceptions → GlobalExceptionMiddleware → 500 ProblemDetails

## What Makes D Different from B?

| Feature | Approach B | Approach D |
|---------|------------|------------|
| EntityType scoping | ✅ Multi-tenant | ❌ Single-tenant |
| DataProcessResult | ✅ | ✅ |
| JSON Rules (maxRetries) | ✅ | ✅ |
| Transaction.Metadata | ❌ | ✅ JSON extensibility |
| Engine complexity | Higher (entityType everywhere) | Lower (no entityType) |
| Adding new entity types | SQL only | Requires engine awareness |

## V17 Skill Set Mapping

| V17 Skill | Used? | Implementation |
|-----------|-------|----------------|
| **Skill 01** (Core Interfaces) | ✅ Full | `DataProcessResult<T>` with Metadata, `.WithMeta()` fluent API |
| **Skill 02** (Object Processor) | ✅ | JSON rule evaluation in `WorkflowEngine.EvaluateTransitionRules()` |
| **Skill 05** (Database Fabric) | ✅ | EF Core + JSON value converters for Rules and Metadata columns |
| **Skill 08** (Flow Definition) | ✅ | DB-driven statuses/transitions with Mermaid visualization |
| **Skill 09** (Flow Orchestrator) | ✅ | Generic WorkflowEngine — no ITransactionRepository dependency |
| **Skill 15** (API Gateway) | ✅ | ResultMapper (DataProcessResult → ProblemDetails) |
| **Skill 29** (Testing) | ✅ | xUnit + Moq + InMemoryDB |
| **Skill 45** (Design Patterns) | ✅ | Decorator (caching), Adapter (service), Strategy (rules) |

## Key Rules for AI Agents

1. **Never throw exceptions** for business logic — always return `DataProcessResult<T>`
2. **WorkflowEngine is generic** — depends only on `IWorkflowRepository`, NOT `ITransactionRepository`
3. **priorTransitionCount** is passed FROM TransactionService to engine (not looked up by engine)
4. **JSON Rules** on WorkflowTransition are evaluated by `EvaluateTransitionRules()`
5. **Transaction.Metadata** stores arbitrary JSON — use `Dictionary<string, object>`
6. **CancellationToken** on all async methods

## Machine vs Freedom

| Layer | Classification | Why |
|-------|---------------|-----|
| WorkflowEngine | MACHINE | Generic transition validator + rule evaluator |
| DataProcessResult | MACHINE | Universal return type |
| ResultMapper | MACHINE | DataProcessResult → HTTP translation |
| EvaluateTransitionRules() | MACHINE | Static rule evaluation logic |
| WorkflowStatus rows | FREEDOM | Changeable at runtime |
| WorkflowTransition rows + Rules JSON | FREEDOM | Rules, descriptions changeable at runtime |
| Transaction.Metadata | FREEDOM | Arbitrary JSON per transaction |
| TransactionService | ADAPTER | Bridges specific entity to generic engine |
