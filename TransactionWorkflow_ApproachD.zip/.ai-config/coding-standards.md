# Coding Standards — Approach D (Strategic Hybrid)

## Core Pattern: DataProcessResult<T>

```csharp
// ALWAYS return DataProcessResult — never throw
public async Task<DataProcessResult<TransactionDto>> TransitionAsync(
    int id, TransitionRequest request, CancellationToken ct = default)
{
    var transaction = await _transactionRepo.GetByIdAsync(id, ct);
    if (transaction is null)
        return DataProcessResult<TransactionDto>.NotFound($"Transaction {id} not found.");

    // Service provides priorTransitionCount — engine stays generic
    var priorCount = await _transactionRepo.GetTransitionCountAsync(
        transaction.Id, transaction.Status?.Name ?? "", request.TargetStatus, ct);

    var result = await _workflowEngine.TryTransitionAsync(
        currentStatusId: transaction.StatusId,
        targetStatusName: request.TargetStatus,
        reason: request.Reason,
        context: request.Context,
        priorTransitionCount: priorCount,
        ct: ct);

    if (!result.IsSuccess)
        return DataProcessResult<TransactionDto>.Fail(result.Message, result.Status)
            with { Metadata = result.Metadata };

    // ... apply transition
    return DataProcessResult<TransactionDto>.Ok(MapToDto(updated));
}
```

## Engine Signature (Generic — No Entity Dependencies)

```csharp
// The engine depends ONLY on IWorkflowRepository — never ITransactionRepository
public class WorkflowEngine : IWorkflowEngine
{
    private readonly IWorkflowRepository _workflowRepo;
    // NO: private readonly ITransactionRepository _transactionRepo;

    public WorkflowEngine(IWorkflowRepository workflowRepo) { _workflowRepo = workflowRepo; }

    public async Task<DataProcessResult<TransitionOutcome>> TryTransitionAsync(
        int currentStatusId,
        string targetStatusName,
        string? reason = null,
        Dictionary<string, object>? context = null,
        int priorTransitionCount = 0,    // ← Passed from service, not looked up
        CancellationToken ct = default) { ... }
}
```

## ResultMapper: DataProcessResult → HTTP

```csharp
[HttpPost("{id}/transition")]
public async Task<IActionResult> Transition(int id, TransitionRequest request)
{
    var result = await _service.TransitionAsync(id, request);
    return result.ToActionResult();  // Single mapping point
}
```

## JSON Metadata on Transactions

```csharp
// Transactions can carry arbitrary metadata
public record CreateTransactionRequest(
    decimal Amount,
    string Currency,
    string? Description = null,
    Dictionary<string, object>? Metadata = null  // ← Freedom: any JSON
);

// Stored via EF Core JSON value converter
builder.Property(t => t.Metadata)
    .HasConversion(jsonConverter, jsonComparer)
    .HasColumnType("nvarchar(max)");
```

## JSON Rule Evaluation

```csharp
// Rules are stored as: {"maxRetries": 3} on WorkflowTransition
// Engine evaluates generically — no entity-specific logic
private static DataProcessResult<TransitionOutcome> EvaluateTransitionRules(
    Dictionary<string, object> rules, int priorTransitionCount,
    string fromStatus, string toStatus)
{
    if (rules.TryGetValue("maxRetries", out var maxRetriesObj))
    {
        if (priorTransitionCount >= Convert.ToInt32(maxRetriesObj))
            return DataProcessResult<TransitionOutcome>.Fail("Max retries exceeded")
                .WithMeta("rule", "maxRetries");
    }
    return DataProcessResult<TransitionOutcome>.Ok(default!);
}
```

## Naming Conventions

- Async methods: `{Verb}Async` with `CancellationToken ct = default`
- Engine methods: `Try{Verb}Async` (no-throw semantics)
- Results: `DataProcessResult<T>` everywhere
- DTOs: `record` types
- Tests: `{Class}Tests.{Method}_{Scenario}_{Expected}`
