# CLAUDE.md — Transaction Workflow Engine (Approach D: Strategic Hybrid)

The **recommended approach** — standard .NET Clean Architecture outside, V17 Freedom Machine
inside. Uses `DataProcessResult` for explicit error handling, JSON metadata for extensibility,
and a generic WorkflowEngine that doesn't depend on entity-specific repositories.

## Read First
- `.ai-config/project-architecture.md` — Hybrid philosophy and Machine vs Freedom
- `.ai-config/coding-standards.md` — DataProcessResult, engine purity, JSON rules
- `.ai-config/v17-skill-map.md` — Maps V17 skills to actual files
- `TransactionWorkflow.Domain/Core/DataProcessResult.cs` — Universal return type
- `TransactionWorkflow.Domain/Services/WorkflowEngine.cs` — The generic engine

## Rules
1. ALL service methods return `DataProcessResult<T>` — never throw exceptions
2. ALL async methods take `CancellationToken ct = default`
3. WorkflowEngine depends ONLY on `IWorkflowRepository` — never entity-specific repos
4. `priorTransitionCount` passed from TransactionService to engine (not looked up by engine)
5. ResultMapper maps DataProcessResult → RFC 7807 ProblemDetails
6. GlobalExceptionMiddleware catches only unexpected failures
7. Transaction.Metadata stores arbitrary JSON via `Dictionary<string, object>`
8. JSON Rules on WorkflowTransition are actually evaluated by the engine

## Tech Stack
.NET 8, EF Core 8, SQL Server (Docker), xUnit, Moq, FluentValidation

## Quick Reference
| What | Where |
|------|-------|
| DataProcessResult | `Domain/Core/DataProcessResult.cs` |
| Generic engine | `Domain/Services/WorkflowEngine.cs` |
| Engine interface | `Domain/Interfaces/IWorkflowEngine.cs` |
| Repositories | `Domain/Interfaces/IRepositories.cs` |
| Adapter service | `Application/Services/TransactionService.cs` |
| ResultMapper | `API/Extensions/ResultMapper.cs` |
| Exception safety net | `API/Middleware/GlobalExceptionMiddleware.cs` |
| Controllers | `API/Controllers/` |
| Validators | `API/Validators/RequestValidators.cs` |
| Caching decorator | `Infrastructure/Caching/CachedWorkflowRepository.cs` |
| DB Context (JSON converters) | `Infrastructure/Data/AppDbContext.cs` |
| Tests | `Tests/` |

## V17 Alignment
This is the recommended balance of V17 patterns:
- Skill 01 (DataProcessResult), Skill 02 (JSON rule evaluation),
- Skill 05 (DB Fabric with JSON converters), Skill 08/09 (Flow Definition/Orchestrator),
- Skill 15 (API Gateway via ResultMapper), Skill 29 (Testing), Skill 45 (Design Patterns)

Key difference from B: No EntityType scoping — simpler but single-tenant.
Key difference from A: DataProcessResult instead of exceptions.
