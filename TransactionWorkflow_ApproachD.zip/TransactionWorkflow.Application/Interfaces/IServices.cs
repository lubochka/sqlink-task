using TransactionWorkflow.Application.DTOs;
using TransactionWorkflow.Domain.Core;

namespace TransactionWorkflow.Application.Interfaces;

/// <summary>
/// All service methods return DataProcessResult — the controller
/// maps the OperationStatus to HTTP codes via a single extension method.
/// No exceptions cross the service boundary for expected business outcomes.
/// </summary>
public interface ITransactionService
{
    Task<DataProcessResult<TransactionDto>> CreateAsync(CreateTransactionRequest request, CancellationToken ct = default);
    Task<DataProcessResult<TransactionDto>> GetByIdAsync(int id, CancellationToken ct = default);
    Task<DataProcessResult<TransactionDto>> TransitionAsync(int id, TransitionRequest request, CancellationToken ct = default);
    Task<DataProcessResult<List<AvailableTransitionDto>>> GetAvailableTransitionsAsync(int id, CancellationToken ct = default);
    Task<DataProcessResult<List<TransactionHistoryDto>>> GetHistoryAsync(int id, CancellationToken ct = default);
}

public interface IWorkflowAdminService
{
    Task<DataProcessResult<WorkflowStatusDto>> AddStatusAsync(AddStatusRequest request, CancellationToken ct = default);
    Task<DataProcessResult<WorkflowTransitionDto>> AddTransitionAsync(AddTransitionRequest request, CancellationToken ct = default);
    Task<DataProcessResult<List<WorkflowStatusDto>>> GetAllStatusesAsync(CancellationToken ct = default);
    Task<DataProcessResult<List<WorkflowTransitionDto>>> GetAllTransitionsAsync(CancellationToken ct = default);
    Task<DataProcessResult<string>> GetWorkflowVisualizationAsync(CancellationToken ct = default);
}
