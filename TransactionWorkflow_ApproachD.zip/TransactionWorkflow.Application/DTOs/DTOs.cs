namespace TransactionWorkflow.Application.DTOs;

// === Responses ===

public record TransactionDto(
    int Id,
    string ReferenceNumber,
    decimal Amount,
    string Currency,
    string Description,
    string Status,
    Dictionary<string, object>? Metadata,
    DateTime CreatedAt,
    DateTime UpdatedAt);

public record AvailableTransitionDto(
    int StatusId,
    string StatusName,
    string? Description,
    Dictionary<string, object>? Rules);

public record TransactionHistoryDto(
    string FromStatus,
    string ToStatus,
    string? Reason,
    Dictionary<string, object>? Context,
    DateTime Timestamp);

public record WorkflowStatusDto(
    int Id,
    string Name,
    string? Description,
    bool IsInitial,
    bool IsFinal);

public record WorkflowTransitionDto(
    int Id,
    string FromStatus,
    string ToStatus,
    string? Description,
    Dictionary<string, object>? Rules);

// === Requests ===

public record CreateTransactionRequest(
    decimal Amount,
    string Currency = "USD",
    string Description = "",
    Dictionary<string, object>? Metadata = null);

public record TransitionRequest(
    string TargetStatus,
    string? Reason = null,
    Dictionary<string, object>? Context = null);

public record AddStatusRequest(
    string Name,
    string? Description = null,
    bool IsInitial = false,
    bool IsFinal = false);

public record AddTransitionRequest(
    string FromStatus,
    string ToStatus,
    string? Description = null,
    Dictionary<string, object>? Rules = null);
