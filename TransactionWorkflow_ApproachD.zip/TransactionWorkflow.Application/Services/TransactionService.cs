using TransactionWorkflow.Application.DTOs;
using TransactionWorkflow.Application.Interfaces;
using TransactionWorkflow.Domain.Core;
using TransactionWorkflow.Domain.Interfaces;
using TransactionWorkflow.Domain.Models;

namespace TransactionWorkflow.Application.Services;

public class TransactionService : ITransactionService
{
    private readonly ITransactionRepository _transactionRepo;
    private readonly IWorkflowEngine _workflowEngine;

    public TransactionService(
        ITransactionRepository transactionRepo,
        IWorkflowEngine workflowEngine)
    {
        _transactionRepo = transactionRepo;
        _workflowEngine = workflowEngine;
    }

    public async Task<DataProcessResult<TransactionDto>> CreateAsync(
        CreateTransactionRequest request, CancellationToken ct = default)
    {
        // Get initial status — engine returns result, not exception
        var initialResult = await _workflowEngine.GetInitialStatusAsync(ct);
        if (!initialResult.IsSuccess)
            return DataProcessResult<TransactionDto>.Fail(initialResult.Message, initialResult.Status);

        var initialStatus = initialResult.Data!;
        var transaction = new Transaction
        {
            ReferenceNumber = $"TXN-{DateTime.UtcNow:yyyyMMdd}-{Guid.NewGuid().ToString("N")[..8].ToUpper()}",
            Amount = request.Amount,
            Currency = request.Currency,
            Description = request.Description,
            StatusId = initialStatus.Id,
            // Note: Do NOT set Status navigation here.
            // The cached entity may be from a previous DbContext scope
            // (IMemoryCache is singleton, DbContext is scoped). Setting
            // the navigation causes Add() to cascade and mark the
            // WorkflowStatus as Added → duplicate INSERT attempt.
            Metadata = request.Metadata ?? new Dictionary<string, object>(),
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow
        };

        var created = await _transactionRepo.CreateAsync(transaction, ct);

        // Reload with Status navigation for DTO mapping
        var refreshed = await _transactionRepo.GetByIdAsync(created.Id, ct);
        return DataProcessResult<TransactionDto>.Ok(MapToDto(refreshed!));
    }

    public async Task<DataProcessResult<TransactionDto>> GetByIdAsync(
        int id, CancellationToken ct = default)
    {
        var transaction = await _transactionRepo.GetByIdAsync(id, ct);
        return transaction is null
            ? DataProcessResult<TransactionDto>.NotFound($"Transaction with ID {id} not found.")
            : DataProcessResult<TransactionDto>.Ok(MapToDto(transaction));
    }

    public async Task<DataProcessResult<TransactionDto>> TransitionAsync(
        int id, TransitionRequest request, CancellationToken ct = default)
    {
        var transaction = await _transactionRepo.GetByIdAsync(id, ct);
        if (transaction is null)
            return DataProcessResult<TransactionDto>.NotFound($"Transaction with ID {id} not found.");

        // Count prior transitions for this specific path (needed for maxRetries rule evaluation).
        // The service layer owns this query — the engine stays entity-agnostic.
        var priorCount = await _transactionRepo.GetTransitionCountAsync(
            transaction.Id, transaction.Status?.Name ?? "", request.TargetStatus, ct);

        // Delegate ALL transition validation to the generic engine
        var transitionResult = await _workflowEngine.TryTransitionAsync(
            currentStatusId: transaction.StatusId,
            targetStatusName: request.TargetStatus,
            reason: request.Reason,
            context: request.Context,
            priorTransitionCount: priorCount,
            ct: ct);

        // If engine says no — propagate its structured failure (with allowed list)
        if (!transitionResult.IsSuccess)
            return DataProcessResult<TransactionDto>.Fail(transitionResult.Message, transitionResult.Status)
                with { Metadata = transitionResult.Metadata };

        var outcome = transitionResult.Data!;

        // Apply the transition to the entity
        var history = new TransactionHistory
        {
            TransactionId = transaction.Id,
            FromStatus = outcome.FromStatusName,
            ToStatus = outcome.ToStatusName,
            Reason = outcome.Reason,
            Context = outcome.Context,
            Timestamp = outcome.TransitionedAt
        };

        transaction.StatusId = outcome.TargetStatusId;
        transaction.UpdatedAt = outcome.TransitionedAt;

        // Persist — repository handles concurrency
        var updateResult = await _transactionRepo.UpdateAsync(transaction, ct);
        if (!updateResult.IsSuccess)
            return DataProcessResult<TransactionDto>.Fail(updateResult.Message, updateResult.Status);

        await _transactionRepo.AddHistoryAsync(history, ct);

        // Reload to get fresh Status navigation
        var refreshed = await _transactionRepo.GetByIdAsync(id, ct);
        return DataProcessResult<TransactionDto>.Ok(MapToDto(refreshed!));
    }

    public async Task<DataProcessResult<List<AvailableTransitionDto>>> GetAvailableTransitionsAsync(
        int id, CancellationToken ct = default)
    {
        var transaction = await _transactionRepo.GetByIdAsync(id, ct);
        if (transaction is null)
            return DataProcessResult<List<AvailableTransitionDto>>.NotFound(
                $"Transaction with ID {id} not found.");

        var targetsResult = await _workflowEngine.GetAvailableTargetsAsync(transaction.StatusId, ct);
        if (!targetsResult.IsSuccess)
            return DataProcessResult<List<AvailableTransitionDto>>.Fail(targetsResult.Message, targetsResult.Status);

        var dtos = targetsResult.Data!.Select(t =>
            new AvailableTransitionDto(t.StatusId, t.StatusName, t.Description, t.Rules)).ToList();

        return DataProcessResult<List<AvailableTransitionDto>>.Ok(dtos);
    }

    public async Task<DataProcessResult<List<TransactionHistoryDto>>> GetHistoryAsync(
        int id, CancellationToken ct = default)
    {
        var transaction = await _transactionRepo.GetByIdAsync(id, ct);
        if (transaction is null)
            return DataProcessResult<List<TransactionHistoryDto>>.NotFound(
                $"Transaction with ID {id} not found.");

        var history = await _transactionRepo.GetHistoryAsync(id, ct);
        var dtos = history.Select(h =>
            new TransactionHistoryDto(h.FromStatus, h.ToStatus, h.Reason, h.Context, h.Timestamp)).ToList();

        return DataProcessResult<List<TransactionHistoryDto>>.Ok(dtos);
    }

    private static TransactionDto MapToDto(Transaction t) => new(
        t.Id, t.ReferenceNumber, t.Amount, t.Currency, t.Description,
        t.Status?.Name ?? "Unknown", t.Metadata, t.CreatedAt, t.UpdatedAt);
}
