using TransactionWorkflow.Application.DTOs;
using TransactionWorkflow.Application.Interfaces;
using TransactionWorkflow.Domain.Core;
using TransactionWorkflow.Domain.Interfaces;
using TransactionWorkflow.Domain.Models;

namespace TransactionWorkflow.Application.Services;

public class WorkflowAdminService : IWorkflowAdminService
{
    private readonly IWorkflowRepository _workflowRepo;

    public WorkflowAdminService(IWorkflowRepository workflowRepo)
    {
        _workflowRepo = workflowRepo;
    }

    public async Task<DataProcessResult<WorkflowStatusDto>> AddStatusAsync(
        AddStatusRequest request, CancellationToken ct = default)
    {
        var existing = await _workflowRepo.GetStatusByNameAsync(request.Name, ct);
        if (existing is not null)
            return DataProcessResult<WorkflowStatusDto>.Fail(
                $"Status '{request.Name}' already exists.",
                OperationStatus.Conflict);

        var status = new WorkflowStatus
        {
            Name = request.Name.ToUpperInvariant(),
            Description = request.Description,
            IsInitial = request.IsInitial,
            IsFinal = request.IsFinal
        };

        var created = await _workflowRepo.AddStatusAsync(status, ct);
        return DataProcessResult<WorkflowStatusDto>.Ok(
            new WorkflowStatusDto(created.Id, created.Name, created.Description, created.IsInitial, created.IsFinal));
    }

    public async Task<DataProcessResult<WorkflowTransitionDto>> AddTransitionAsync(
        AddTransitionRequest request, CancellationToken ct = default)
    {
        var fromStatus = await _workflowRepo.GetStatusByNameAsync(request.FromStatus, ct);
        if (fromStatus is null)
            return DataProcessResult<WorkflowTransitionDto>.NotFound(
                $"Source status '{request.FromStatus}' not found.");

        var toStatus = await _workflowRepo.GetStatusByNameAsync(request.ToStatus, ct);
        if (toStatus is null)
            return DataProcessResult<WorkflowTransitionDto>.NotFound(
                $"Target status '{request.ToStatus}' not found.");

        var transition = new WorkflowTransition
        {
            FromStatusId = fromStatus.Id,
            ToStatusId = toStatus.Id,
            Description = request.Description,
            Rules = request.Rules ?? new Dictionary<string, object>()
        };

        var created = await _workflowRepo.AddTransitionAsync(transition, ct);
        return DataProcessResult<WorkflowTransitionDto>.Ok(
            new WorkflowTransitionDto(created.Id, fromStatus.Name, toStatus.Name, created.Description, created.Rules));
    }

    public async Task<DataProcessResult<List<WorkflowStatusDto>>> GetAllStatusesAsync(CancellationToken ct = default)
    {
        var statuses = await _workflowRepo.GetAllStatusesAsync(ct);
        var dtos = statuses.Select(s =>
            new WorkflowStatusDto(s.Id, s.Name, s.Description, s.IsInitial, s.IsFinal)).ToList();
        return DataProcessResult<List<WorkflowStatusDto>>.Ok(dtos);
    }

    public async Task<DataProcessResult<List<WorkflowTransitionDto>>> GetAllTransitionsAsync(CancellationToken ct = default)
    {
        var transitions = await _workflowRepo.GetAllTransitionsAsync(ct);
        var dtos = transitions.Select(t =>
            new WorkflowTransitionDto(t.Id, t.FromStatus.Name, t.ToStatus.Name, t.Description, t.Rules)).ToList();
        return DataProcessResult<List<WorkflowTransitionDto>>.Ok(dtos);
    }

    public async Task<DataProcessResult<string>> GetWorkflowVisualizationAsync(CancellationToken ct = default)
    {
        var transitions = await _workflowRepo.GetAllTransitionsAsync(ct);
        var statuses = await _workflowRepo.GetAllStatusesAsync(ct);

        var lines = new List<string> { "graph TD" };

        foreach (var t in transitions)
        {
            var label = t.Description ?? $"{t.FromStatus.Name} → {t.ToStatus.Name}";
            lines.Add($"    {t.FromStatus.Name} -->|\"{label}\"| {t.ToStatus.Name}");
        }

        foreach (var s in statuses.Where(s => s.IsFinal))
            lines.Add($"    style {s.Name} fill:#22c55e,color:#fff");
        foreach (var s in statuses.Where(s => s.IsInitial))
            lines.Add($"    style {s.Name} fill:#3b82f6,color:#fff");

        return DataProcessResult<string>.Ok(string.Join("\n", lines));
    }
}
