#!/bin/bash
set -e
echo "🚀 Starting Transaction Workflow Engine (Approach D — Strategic Hybrid)..."
echo ""
if [ -f .env ]; then
    export $(cat .env | grep -v '^#' | xargs)
fi
docker-compose down --remove-orphans 2>/dev/null || true
docker-compose up --build -d
echo ""
echo "⏳ Waiting for SQL Server health check..."
until docker inspect --format='{{.State.Health.Status}}' txn-workflow-db 2>/dev/null | grep -q "healthy"; do
    sleep 2; printf "."
done
echo ""
echo "✅ Systems GO! API running at http://localhost:5000/swagger"
