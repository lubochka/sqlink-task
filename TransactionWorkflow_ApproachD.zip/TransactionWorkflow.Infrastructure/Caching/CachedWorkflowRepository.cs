using Microsoft.Extensions.Caching.Memory;
using TransactionWorkflow.Domain.Interfaces;
using TransactionWorkflow.Domain.Models;

namespace TransactionWorkflow.Infrastructure.Caching;

/// <summary>
/// Decorator that caches workflow configuration in memory (V17 DNA-8 cache-aside pattern).
/// The domain layer is unaware of caching — it uses the same IWorkflowRepository interface.
/// Admin writes invalidate the cache immediately.
/// </summary>
public class CachedWorkflowRepository : IWorkflowRepository
{
    private readonly IWorkflowRepository _inner;
    private readonly IMemoryCache _cache;
    private static readonly TimeSpan CacheTtl = TimeSpan.FromMinutes(30);

    // Track per-status cache keys so we can invalidate them on admin writes
    private readonly HashSet<string> _trackedKeys = new();
    private readonly object _keyLock = new();

    public CachedWorkflowRepository(IWorkflowRepository inner, IMemoryCache cache)
    {
        _inner = inner;
        _cache = cache;
    }

    public async Task<WorkflowStatus?> GetStatusByIdAsync(int id, CancellationToken ct = default)
        => await GetOrCreate($"wf:status:{id}", () => _inner.GetStatusByIdAsync(id, ct));

    public Task<WorkflowStatus?> GetStatusByNameAsync(string name, CancellationToken ct = default)
        => _inner.GetStatusByNameAsync(name, ct); // admin-only, pass through

    public async Task<WorkflowStatus?> GetInitialStatusAsync(CancellationToken ct = default)
        => await GetOrCreate("wf:initial", () => _inner.GetInitialStatusAsync(ct));

    public async Task<List<WorkflowTransition>> GetAllowedTransitionsAsync(
        int fromStatusId, CancellationToken ct = default)
        => await GetOrCreate($"wf:trans:{fromStatusId}",
            () => _inner.GetAllowedTransitionsAsync(fromStatusId, ct)) ?? [];

    public async Task<List<WorkflowStatus>> GetAllStatusesAsync(CancellationToken ct = default)
        => await GetOrCreate("wf:statuses", () => _inner.GetAllStatusesAsync(ct)) ?? [];

    public async Task<List<WorkflowTransition>> GetAllTransitionsAsync(CancellationToken ct = default)
        => await GetOrCreate("wf:transitions", () => _inner.GetAllTransitionsAsync(ct)) ?? [];

    public async Task<WorkflowStatus> AddStatusAsync(WorkflowStatus status, CancellationToken ct = default)
    {
        var result = await _inner.AddStatusAsync(status, ct);
        InvalidateAll();
        return result;
    }

    public async Task<WorkflowTransition> AddTransitionAsync(
        WorkflowTransition transition, CancellationToken ct = default)
    {
        var result = await _inner.AddTransitionAsync(transition, ct);
        InvalidateAll();
        return result;
    }

    private async Task<T?> GetOrCreate<T>(string key, Func<Task<T?>> factory)
    {
        lock (_keyLock) _trackedKeys.Add(key);
        return await _cache.GetOrCreateAsync(key, async e =>
        {
            e.AbsoluteExpirationRelativeToNow = CacheTtl;
            return await factory();
        });
    }

    private void InvalidateAll()
    {
        lock (_keyLock)
        {
            foreach (var key in _trackedKeys)
                _cache.Remove(key);
            _trackedKeys.Clear();
        }
    }
}
