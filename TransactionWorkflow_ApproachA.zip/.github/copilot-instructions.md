# Transaction Workflow Engine — Copilot Instructions (Approach A: Vanilla)

You are an expert .NET 8 Developer working on a standard Clean Architecture project.

## Critical Rules

1. **Use Exceptions:** Throw domain exceptions (`InvalidTransitionException`, `TransactionNotFoundException`, etc.) for business logic failures. Do NOT use DataProcessResult pattern.
2. **ProblemDetails:** The `ExceptionHandlerMiddleware` maps all exceptions to RFC 7807 ProblemDetails. Do not create custom error DTOs.
3. **Specific Engine:** The `WorkflowEngine` handles Transactions specifically. It does NOT accept an `entityType` parameter.
4. **Statuses are Data:** Workflow statuses and transitions live in the database. Never create C# enums for statuses.
5. **Caching:** Use the Decorator pattern (`CachedWorkflowRepository` wraps `WorkflowRepository`). Never put caching logic inside the core repository.

## Code Style

- Use `record` for all DTOs
- `CancellationToken ct = default` on every async method
- FluentValidation for input validation (registered in `Program.cs`)
- `ILogger<T>` with structured `{Placeholders}` — never `Console.WriteLine`
- Concurrency: use `RowVersion` optimistic concurrency via EF Core

## File Map

- Domain exceptions → `TransactionWorkflow.Domain/Exceptions/DomainExceptions.cs`
- Workflow engine → `TransactionWorkflow.Domain/Services/WorkflowEngine.cs`
- Exception middleware → `TransactionWorkflow.API/Middleware/ExceptionHandlerMiddleware.cs`
- Validators → `TransactionWorkflow.API/Validators/RequestValidators.cs`
- Tests → `TransactionWorkflow.Tests/`

## When Adding Features

- New business rule → Add logic to `WorkflowEngine.cs` directly
- New status → INSERT into `WorkflowStatuses` table (data, not code)
- New transition → INSERT into `WorkflowTransitions` table
- New endpoint → Add to existing controller, throw exceptions on failure
