namespace TransactionWorkflow.Domain.Models;

public class WorkflowTransition
{
    public int Id { get; set; }

    public int FromStatusId { get; set; }
    public WorkflowStatus FromStatus { get; set; } = null!;

    public int ToStatusId { get; set; }
    public WorkflowStatus ToStatus { get; set; } = null!;

    public string? Description { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
