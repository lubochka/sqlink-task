namespace TransactionWorkflow.Domain.Models;

public class Transaction
{
    public int Id { get; set; }
    public string ReferenceNumber { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    public string Currency { get; set; } = "USD";
    public string Description { get; set; } = string.Empty;

    // Current status — FK to WorkflowStatus
    public int StatusId { get; set; }
    public WorkflowStatus Status { get; set; } = null!;

    // Optimistic concurrency
    public byte[] RowVersion { get; set; } = null!;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

    public ICollection<TransactionHistory> History { get; set; } = new List<TransactionHistory>();
}
