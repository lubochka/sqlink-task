namespace TransactionWorkflow.Domain.Exceptions;

public class InvalidTransitionException : Exception
{
    public string CurrentStatus { get; }
    public string AttemptedStatus { get; }
    public IReadOnlyList<string> AllowedStatuses { get; }

    public InvalidTransitionException(string currentStatus, string attemptedStatus, IEnumerable<string> allowedStatuses)
        : base($"Transition from '{currentStatus}' to '{attemptedStatus}' is not allowed. " +
               $"Allowed transitions: [{string.Join(", ", allowedStatuses)}]")
    {
        CurrentStatus = currentStatus;
        AttemptedStatus = attemptedStatus;
        AllowedStatuses = allowedStatuses.ToList().AsReadOnly();
    }
}

public class TransactionNotFoundException : Exception
{
    public int TransactionId { get; }

    public TransactionNotFoundException(int transactionId)
        : base($"Transaction with ID {transactionId} was not found.")
    {
        TransactionId = transactionId;
    }
}

public class WorkflowConfigurationException : Exception
{
    public WorkflowConfigurationException(string message) : base(message) { }
}

public class DuplicateEntityException : Exception
{
    public DuplicateEntityException(string message) : base(message) { }
}

public class StatusNotFoundException : Exception
{
    public string StatusName { get; }
    public StatusNotFoundException(string statusName)
        : base($"Workflow status '{statusName}' not found.")
    {
        StatusName = statusName;
    }
}

public class ConcurrencyConflictException : Exception
{
    public ConcurrencyConflictException(int transactionId)
        : base($"Transaction {transactionId} was modified by another request. Please retry.") { }
}
