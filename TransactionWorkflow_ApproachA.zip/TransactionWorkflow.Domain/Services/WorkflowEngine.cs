using TransactionWorkflow.Domain.Exceptions;
using TransactionWorkflow.Domain.Interfaces;
using TransactionWorkflow.Domain.Models;

namespace TransactionWorkflow.Domain.Services;

/// <summary>
/// The single place that handles all workflow transition logic.
/// All status changes go through this engine — controllers and services
/// never modify transaction status directly.
/// </summary>
public class WorkflowEngine
{
    private readonly IWorkflowRepository _workflowRepo;

    public WorkflowEngine(IWorkflowRepository workflowRepo)
    {
        _workflowRepo = workflowRepo;
    }

    /// <summary>
    /// Validates and executes a status transition on a transaction.
    /// Returns a TransactionHistory record for the change.
    /// Throws InvalidTransitionException if the transition is not allowed.
    /// </summary>
    public async Task<TransactionHistory> TransitionAsync(
        Transaction transaction,
        string targetStatusName,
        string? reason = null,
        CancellationToken ct = default)
    {
        var currentStatus = transaction.Status
            ?? throw new WorkflowConfigurationException(
                $"Transaction {transaction.Id} has no loaded status. Ensure Status navigation is included.");

        // Get allowed transitions from current status
        var allowedTransitions = await _workflowRepo.GetAllowedTransitionsAsync(currentStatus.Id, ct);
        var allowedTargets = allowedTransitions.Select(t => t.ToStatus).ToList();

        // Find the target status among allowed transitions
        var targetStatus = allowedTargets.FirstOrDefault(
            s => s.Name.Equals(targetStatusName, StringComparison.OrdinalIgnoreCase));

        if (targetStatus is null)
        {
            throw new InvalidTransitionException(
                currentStatus.Name,
                targetStatusName,
                allowedTargets.Select(s => s.Name));
        }

        // Build history record
        var history = new TransactionHistory
        {
            TransactionId = transaction.Id,
            FromStatus = currentStatus.Name,
            ToStatus = targetStatus.Name,
            Reason = reason,
            Timestamp = DateTime.UtcNow
        };

        // Apply the transition — set FK only, NOT navigation property.
        // The cached targetStatus may be from a different DbContext scope
        // (IMemoryCache is singleton, DbContext is scoped). Setting the
        // navigation would cause EF to track two WorkflowStatus instances
        // with the same key → InvalidOperationException.
        transaction.StatusId = targetStatus.Id;
        transaction.UpdatedAt = DateTime.UtcNow;

        return history;
    }

    /// <summary>
    /// Gets the list of statuses this transaction can transition to.
    /// </summary>
    public async Task<List<WorkflowStatus>> GetAvailableTransitionsAsync(
        Transaction transaction,
        CancellationToken ct = default)
    {
        var currentStatus = transaction.Status
            ?? throw new WorkflowConfigurationException(
                $"Transaction {transaction.Id} has no loaded status.");

        var transitions = await _workflowRepo.GetAllowedTransitionsAsync(currentStatus.Id, ct);
        return transitions.Select(t => t.ToStatus).ToList();
    }

    /// <summary>
    /// Gets the initial status for new transactions.
    /// </summary>
    public async Task<WorkflowStatus> GetInitialStatusAsync(CancellationToken ct = default)
    {
        return await _workflowRepo.GetInitialStatusAsync(ct)
            ?? throw new WorkflowConfigurationException(
                "No initial workflow status configured. Ensure seed data has been applied.");
    }
}
