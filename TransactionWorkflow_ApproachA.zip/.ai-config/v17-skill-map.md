# V17 Skill Map — Approach A (Vanilla)

Maps XIIGen V17 skills to actual implementations in this codebase.
Approach A uses a **minimal** subset — standard .NET patterns without the full Freedom Machine.

## Skill Mapping

### ✅ Active Skills

| V17 Skill | File(s) | Adaptation |
|-----------|---------|------------|
| **Skill 05: Database Fabric** | `Infrastructure/Repositories/TransactionRepository.cs`, `WorkflowRepository.cs` | EF Core specific repos (not generic IDatabaseProvider) |
| **Skill 08: Flow Definition** | `Domain/Models/WorkflowStatus.cs`, `WorkflowTransition.cs`, `Infrastructure/Data/AppDbContext.cs` (seed data) | Workflow defined as DB rows. Mermaid visualization via `/admin/workflow/visualize` |
| **Skill 09: Flow Orchestrator** | `Domain/Services/WorkflowEngine.cs` | Transaction-specific engine. Validates transitions, throws on invalid |
| **Skill 15: API Gateway** | `API/Controllers/TransactionsController.cs`, `AdminController.cs`, `API/Middleware/ExceptionHandlerMiddleware.cs` | Exception → ProblemDetails mapping |
| **Skill 29: Unit Testing** | `Tests/WorkflowEngineTests.cs`, `Tests/IntegrationTests/` | xUnit + Moq + WebApplicationFactory + InMemoryDB |
| **Skill 45: Design Patterns** | `Infrastructure/Caching/CachedWorkflowRepository.cs` | Decorator pattern for caching |

### ❌ Not Used (by design)

| V17 Skill | Why Excluded |
|-----------|-------------|
| **Skill 01: Core Interfaces (DataProcessResult)** | A uses exceptions instead of result objects |
| **Skill 02: Object Processor** | No dynamic JSON rule evaluation |
| **Skill 06/07: AI Providers/Dispatcher** | Not applicable to this assignment |
| **Skill 22: Logger Service** | Uses standard `ILogger<T>` only |
| **Skill 34: Swagger/OpenAPI** | Basic Swagger, no enriched docs |

## Pattern Comparison: A vs V17

| V17 Pattern | Approach A Equivalent |
|------------|----------------------|
| `DataProcessResult<T>.Fail()` | `throw new InvalidTransitionException()` |
| `ResultMapper.ToActionResult()` | `ExceptionHandlerMiddleware.HandleExceptionAsync()` |
| `ParseObjectAlternative` | N/A — typed models only |
| `BuildSearchFilter` | LINQ queries with explicit conditions |
| `Dictionary<string,object>` metadata | N/A — no metadata fields |
