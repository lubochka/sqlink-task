# Approach A: Textbook Clean Architecture (Vanilla)

## Philosophy

Standard .NET 8 Clean Architecture — explicit, specific, easy to understand.
No generic engines. No complex JSON rules. Direct domain services for Transactions.

### Guiding Principle

> **KISS:** Keep it simple and specific. Write code that a junior developer can read in 15 minutes.

## Architecture Pattern

```
API Layer (Controllers + Middleware)
    ↓ Calls
Application Layer (Services + DTOs)
    ↓ Uses
Domain Layer (Entities + Exceptions + WorkflowEngine)
    ↓ Persisted by
Infrastructure Layer (EF Core + Repositories + Caching)
```

## Error Handling Strategy

Approach A uses **domain exceptions** for flow control:

- `InvalidTransitionException` → 400 Bad Request
- `TransactionNotFoundException` → 404 Not Found
- `ConcurrencyConflictException` → 409 Conflict
- `WorkflowConfigurationException` → 500 Server Error

The `ExceptionHandlerMiddleware` catches ALL exceptions and maps them
to RFC 7807 ProblemDetails responses.

## V17 Skill Set Mapping (Minimal)

| V17 Skill | Used? | Implementation |
|-----------|-------|----------------|
| Skill 01 (Core Interfaces) | ❌ No DataProcessResult | Custom exceptions instead |
| Skill 02 (Object Processor) | ❌ | No JSON rule evaluation |
| Skill 05 (Database Fabric) | ✅ Partial | EF Core specific repos |
| Skill 08 (Flow Definition) | ✅ | DB-driven statuses/transitions |
| Skill 09 (Flow Orchestrator) | ✅ Specific | WorkflowEngine for Transactions only |
| Skill 15 (API Gateway) | ✅ | Controllers + ExceptionHandlerMiddleware |
| Skill 29 (Testing) | ✅ | xUnit + Moq + InMemoryDB |
| Skill 45 (Design Patterns) | ✅ | Decorator (CachedWorkflowRepo) |

## Key Rules for AI Agents

1. **Use Exceptions** for business logic failures — NOT DataProcessResult
2. **WorkflowEngine** is specific to Transactions — no `entityType` parameter
3. **No JSON Rules** — transition logic is in C# code, not stored in JSON columns
4. **Statuses are data** — defined in DB rows, not C# enums
5. **CancellationToken** on all async methods
6. **ProblemDetails** (RFC 7807) for all error responses

## Machine vs Freedom

| Layer | Classification | Why |
|-------|---------------|-----|
| WorkflowEngine | MACHINE | Reusable transition validator |
| ExceptionHandlerMiddleware | MACHINE | Maps exceptions to HTTP |
| CachedWorkflowRepository | MACHINE | Decorator pattern |
| WorkflowStatus rows | FREEDOM | Changeable at runtime |
| WorkflowTransition rows | FREEDOM | Changeable at runtime |
| Transaction.Metadata | ❌ N/A | Not implemented in A |
