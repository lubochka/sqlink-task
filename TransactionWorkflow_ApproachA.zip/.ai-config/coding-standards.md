# Coding Standards — Approach A (Vanilla)

## Error Handling: Exceptions → ProblemDetails

```csharp
// Domain layer: THROW domain exceptions
public async Task<Transaction> TransitionAsync(Transaction transaction, string targetStatus, ...)
{
    var allowed = await _repo.GetAllowedTransitionsAsync(transaction.StatusId, ct);
    var target = allowed.FirstOrDefault(t => t.ToStatus.Name == targetStatus);

    if (target is null)
        throw new InvalidTransitionException(
            currentStatus, targetStatus, allowed.Select(t => t.ToStatus.Name));
    // ...
}

// API layer: Middleware catches and maps to ProblemDetails
catch (InvalidTransitionException e) => (400, new ProblemDetails
{
    Type = "https://httpstatuses.io/400",
    Title = "InvalidTransition",
    Detail = e.Message,
    Extensions = { ["allowedTransitions"] = e.AllowedStatuses.ToArray() }
})
```

## Controller Pattern

```csharp
[HttpPost("{id}/transition")]
public async Task<IActionResult> Transition(int id, TransitionRequest request)
{
    // Service throws on invalid — middleware handles it
    var result = await _service.TransitionAsync(id, request);
    return Ok(result);
}
```

## Repository Pattern

```csharp
public interface ITransactionRepository
{
    Task<Transaction?> GetByIdAsync(int id, CancellationToken ct = default);
    Task<Transaction> CreateAsync(Transaction transaction, CancellationToken ct = default);
    Task UpdateAsync(Transaction transaction, CancellationToken ct = default);
}
```

## Caching (Decorator Pattern)

```csharp
// Register: real repo, then wrap
builder.Services.AddScoped<WorkflowRepository>();
builder.Services.AddScoped<IWorkflowRepository>(sp =>
    new CachedWorkflowRepository(
        sp.GetRequiredService<WorkflowRepository>(),
        sp.GetRequiredService<IMemoryCache>()));
```

## DTOs (Records)

```csharp
public record TransactionDto(int Id, string ReferenceNumber, decimal Amount,
    string Currency, string? Description, string CurrentStatus,
    DateTime CreatedAt, DateTime UpdatedAt);

public record TransitionRequest(string TargetStatus, string? Reason = null);

// ErrorResponse is DEPRECATED — use ProblemDetails instead
```

## FluentValidation

```csharp
public class CreateTransactionRequestValidator : AbstractValidator<CreateTransactionRequest>
{
    public CreateTransactionRequestValidator()
    {
        RuleFor(x => x.Amount).GreaterThan(0);
        RuleFor(x => x.Currency).NotEmpty().Length(3);
    }
}
```

## Naming Conventions

- Async methods: `{Verb}Async` (e.g., `TransitionAsync`, `GetByIdAsync`)
- Repositories: `I{Entity}Repository`
- Services: `I{Entity}Service`
- DTOs: `{Entity}Dto`, `{Action}Request`
- Tests: `{Class}Tests.{Method}_{Scenario}_{Expected}`
