using System.Text.Json;
using TransactionWorkflow.Application.DTOs;
using TransactionWorkflow.Domain.Exceptions;

namespace TransactionWorkflow.API.Middleware;

public class ExceptionHandlerMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<ExceptionHandlerMiddleware> _logger;

    public ExceptionHandlerMiddleware(RequestDelegate next, ILogger<ExceptionHandlerMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (Exception ex)
        {
            await HandleExceptionAsync(context, ex);
        }
    }

    private async Task HandleExceptionAsync(HttpContext context, Exception exception)
    {
        var (statusCode, response) = exception switch
        {
            InvalidTransitionException e => (
                StatusCodes.Status400BadRequest,
                new ErrorResponse(
                    "Invalid transition",
                    e.Message,
                    e.AllowedStatuses.ToArray())),

            TransactionNotFoundException e => (
                StatusCodes.Status404NotFound,
                new ErrorResponse("Transaction not found", e.Message)),

            StatusNotFoundException e => (
                StatusCodes.Status404NotFound,
                new ErrorResponse("Status not found", e.Message)),

            DuplicateEntityException e => (
                StatusCodes.Status409Conflict,
                new ErrorResponse("Duplicate entity", e.Message)),

            WorkflowConfigurationException e => (
                StatusCodes.Status500InternalServerError,
                new ErrorResponse("Workflow configuration error", e.Message)),

            ConcurrencyConflictException e => (
                StatusCodes.Status409Conflict,
                new ErrorResponse("Concurrency conflict", e.Message)),

            _ => (
                StatusCodes.Status500InternalServerError,
                new ErrorResponse("Internal server error", "An unexpected error occurred."))
        };

        if (statusCode == StatusCodes.Status500InternalServerError)
            _logger.LogError(exception, "Unhandled exception: {Message}", exception.Message);
        else
            _logger.LogWarning("Domain exception: {Type} — {Message}", exception.GetType().Name, exception.Message);

        context.Response.StatusCode = statusCode;
        context.Response.ContentType = "application/json";

        var json = JsonSerializer.Serialize(response, new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase
        });

        await context.Response.WriteAsync(json);
    }
}
