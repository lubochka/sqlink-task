using Microsoft.AspNetCore.Mvc;
using TransactionWorkflow.Application.DTOs;
using TransactionWorkflow.Application.Interfaces;

namespace TransactionWorkflow.API.Controllers;

[ApiController]
[Route("admin/workflow")]
[Produces("application/json")]
public class AdminController : ControllerBase
{
    private readonly IWorkflowAdminService _adminService;

    public AdminController(IWorkflowAdminService adminService) => _adminService = adminService;

    /// <summary>Get all workflow statuses</summary>
    [HttpGet("statuses")]
    [ProducesResponseType(typeof(List<WorkflowStatusDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetStatuses(CancellationToken ct)
    {
        return Ok(await _adminService.GetAllStatusesAsync(ct));
    }

    /// <summary>Add a new workflow status</summary>
    [HttpPost("statuses")]
    [ProducesResponseType(typeof(WorkflowStatusDto), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> AddStatus(
        [FromBody] AddStatusRequest request, CancellationToken ct)
    {
        var status = await _adminService.AddStatusAsync(request, ct);
        return Created($"/admin/workflow/statuses/{status.Id}", status);
    }

    /// <summary>Get all workflow transitions</summary>
    [HttpGet("transitions")]
    [ProducesResponseType(typeof(List<WorkflowTransitionDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetTransitions(CancellationToken ct)
    {
        return Ok(await _adminService.GetAllTransitionsAsync(ct));
    }

    /// <summary>Add a new workflow transition</summary>
    [HttpPost("transitions")]
    [ProducesResponseType(typeof(WorkflowTransitionDto), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> AddTransition(
        [FromBody] AddTransitionRequest request, CancellationToken ct)
    {
        var transition = await _adminService.AddTransitionAsync(request, ct);
        return Created($"/admin/workflow/transitions/{transition.Id}", transition);
    }

    /// <summary>Get workflow as Mermaid.js diagram for visualization</summary>
    [HttpGet("visualize")]
    [Produces("text/plain")]
    [ProducesResponseType(typeof(string), StatusCodes.Status200OK)]
    public async Task<IActionResult> Visualize(CancellationToken ct)
    {
        var mermaid = await _adminService.GetWorkflowVisualizationAsync(ct);
        return Content(mermaid, "text/plain");
    }
}
