# Transaction Workflow Engine — Approach A (Vanilla)

A backend service that manages customer transactions with a **configurable, data-driven workflow** — similar to Jira's workflow system where statuses and transitions are defined in the database, not in code.

## Quick Start

### Prerequisites
- [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0)
- [Docker](https://www.docker.com/) (for SQL Server)

### Option 1: One-Command Start (Recommended)

```bash
./start.sh
```

API available at: `http://localhost:5000/swagger`

> The start script uses Docker health checks to ensure SQL Server is fully ready before the API starts — no more race condition crashes.

### Option 2: Docker Compose

```bash
docker-compose up --build
```

### Option 3: Manual

```bash
docker run -e "ACCEPT_EULA=Y" -e "SA_PASSWORD=YourStrong!Passw0rd" \
  -p 1433:1433 -d mcr.microsoft.com/mssql/server:2022-latest

cd TransactionWorkflow.API
dotnet run
```

### Run Tests

```bash
dotnet test
```

---

## API Endpoints

### Transactions

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/transactions` | Create a new transaction |
| `GET` | `/transactions/{id}` | Get transaction by ID |
| `POST` | `/transactions/{id}/transition` | Transition to a new status |
| `GET` | `/transactions/{id}/available-transitions` | List valid next statuses |
| `GET` | `/transactions/{id}/history` | Get status change history |

### Admin — Workflow Management

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/admin/workflow/statuses` | List all workflow statuses |
| `POST` | `/admin/workflow/statuses` | Add a new status |
| `GET` | `/admin/workflow/transitions` | List all transitions |
| `POST` | `/admin/workflow/transitions` | Add a new transition |
| `GET` | `/admin/workflow/visualize` | **NEW** Export workflow as Mermaid.js diagram |

### Seeded Workflow

```
CREATED → VALIDATED → PROCESSING → COMPLETED
                                 ↘ FAILED → VALIDATED (retry)
```

### Example: Workflow Visualization

```bash
curl http://localhost:5000/admin/workflow/visualize
# Returns Mermaid.js syntax you can paste into any Mermaid renderer
```

### Example: Input Validation

```bash
curl -X POST http://localhost:5000/transactions \
  -H "Content-Type: application/json" \
  -d '{"amount": -50, "currency": "x"}'
# Returns 400 with validation errors:
# { "Amount": ["Amount must be greater than 0."], "Currency": ["..."] }
```

---

## Architecture

```
TransactionWorkflow.API          → Controllers, validators, middleware, DI setup
TransactionWorkflow.Application  → Service interfaces, DTOs, orchestration
TransactionWorkflow.Domain       → Models, WorkflowEngine, domain exceptions
TransactionWorkflow.Infrastructure → EF Core, repositories, caching
TransactionWorkflow.Tests        → Unit tests + integration tests
```

### Key Design Decisions

1. **WorkflowEngine** — single source of truth for all transition logic
2. **Data-driven workflow** — no enums, no hardcoded statuses
3. **Exception-to-HTTP mapping** via middleware (domain exceptions → HTTP codes)
4. **Caching decorator** — in-memory cache with auto-invalidation on admin writes
5. **Optimistic concurrency** — RowVersion prevents race conditions
6. **FluentValidation** — input sanitization at the API gateway layer
7. **Docker health checks** — API waits for SQL Server readiness

### Security Improvements

- **Secret management**: Passwords in `.env` file (git-ignored), not hardcoded
- **Input validation**: FluentValidation rejects invalid amounts, currencies, XSS attempts
- **Mass assignment protection**: DTOs prevent injecting properties like `Status=COMPLETED`
- **Concurrency control**: RowVersion + `DbUpdateConcurrencyException` → 409 Conflict

---

## Time Spent

~5 hours total (including bonus features, tests, and improvements).
