using TransactionWorkflow.Domain.Models;

namespace TransactionWorkflow.Domain.Interfaces;

public interface ITransactionRepository
{
    Task<Transaction?> GetByIdAsync(int id, CancellationToken ct = default);
    Task<Transaction> CreateAsync(Transaction transaction, CancellationToken ct = default);
    Task UpdateAsync(Transaction transaction, CancellationToken ct = default);
    Task<List<TransactionHistory>> GetHistoryAsync(int transactionId, CancellationToken ct = default);
    Task AddHistoryAsync(TransactionHistory history, CancellationToken ct = default);
}

public interface IWorkflowRepository
{
    Task<WorkflowStatus?> GetStatusByNameAsync(string name, CancellationToken ct = default);
    Task<WorkflowStatus?> GetInitialStatusAsync(CancellationToken ct = default);
    Task<List<WorkflowTransition>> GetAllowedTransitionsAsync(int fromStatusId, CancellationToken ct = default);
    Task<List<WorkflowStatus>> GetAllStatusesAsync(CancellationToken ct = default);
    Task<List<WorkflowTransition>> GetAllTransitionsAsync(CancellationToken ct = default);
    Task<WorkflowStatus> AddStatusAsync(WorkflowStatus status, CancellationToken ct = default);
    Task<WorkflowTransition> AddTransitionAsync(WorkflowTransition transition, CancellationToken ct = default);
}
