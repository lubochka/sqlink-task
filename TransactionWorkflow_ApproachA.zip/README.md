# Transaction Workflow Engine — Approach A (Vanilla)

A backend service that manages customer transactions with a **configurable, data-driven workflow** — similar to Jira's workflow system where statuses and transitions are defined in the database, not in code.

> **Philosophy:** Standard .NET Clean Architecture. Explicit, specific, easy to understand.

---

## 🗺️ Document Map & Project Structure

```text
TransactionWorkflow/
├── .ai-config/                              # 🧠 AI Agent Context
│   ├── project-architecture.md              # Architecture philosophy
│   ├── coding-standards.md                  # Code examples & patterns
│   └── v17-skill-map.md                     # V17 skill → file mapping
├── .github/copilot-instructions.md          # GitHub Copilot rules
├── CLAUDE.md                                # Claude Code instructions
├── TransactionWorkflow.Domain/              # 🟡 CORE LOGIC
│   ├── Models/                              # Transaction, WorkflowStatus, WorkflowTransition
│   ├── Exceptions/DomainExceptions.cs       # [A-specific] Domain exceptions
│   ├── Interfaces/                          # Repository contracts
│   └── Services/WorkflowEngine.cs           # [Skill 09] Transaction-specific engine
├── TransactionWorkflow.Application/         # 🟠 ADAPTER LAYER
│   ├── DTOs/                                # Request/Response records
│   └── Services/                            # TransactionService, WorkflowAdminService
├── TransactionWorkflow.Infrastructure/      # 🔵 PERSISTENCE [Skill 05]
│   ├── Data/AppDbContext.cs                 # EF Core config + seed data
│   ├── Repositories/                        # Concrete repos
│   └── Caching/CachedWorkflowRepository.cs  # [Skill 45] Decorator pattern
├── TransactionWorkflow.API/                 # 🟣 GATEWAY [Skill 15]
│   ├── Controllers/                         # Transactions + Admin
│   ├── Middleware/ExceptionHandlerMiddleware.cs  # Exception → ProblemDetails
│   └── Validators/                          # FluentValidation
├── TransactionWorkflow.Tests/               # 🟢 TESTING [Skill 29]
├── docker-compose.yml                       # SQL Server + API
└── start.sh                                 # One-command startup
```

---

## 🚀 Quick Start

```bash
./start.sh
# ✅ API at http://localhost:5000/swagger
```

### Run Tests
```bash
dotnet test
```

---

## 📡 API Endpoints

### Transactions

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/transactions` | Create a new transaction |
| `GET` | `/transactions/{id}` | Get transaction by ID |
| `POST` | `/transactions/{id}/transition` | Transition to a new status |
| `GET` | `/transactions/{id}/available-transitions` | List valid next statuses |
| `GET` | `/transactions/{id}/history` | Get status change history |

### Admin

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/admin/workflow/statuses` | List all statuses |
| `POST` | `/admin/workflow/statuses` | Add a status |
| `GET` | `/admin/workflow/transitions` | List all transitions |
| `POST` | `/admin/workflow/transitions` | Add a transition |
| `GET` | `/admin/workflow/visualize` | Mermaid.js workflow diagram |

### Seeded Workflow
```
CREATED → VALIDATED → PROCESSING → COMPLETED
                               ↘ FAILED → VALIDATED (retry)
```

---

## 🛠️ V17 Skill Integration

| V17 Skill | Implementation | Key File |
|-----------|----------------|----------|
| Skill 05 (Database Fabric) | EF Core repositories | `Infrastructure/Repositories/` |
| Skill 08 (Flow Definition) | DB-driven statuses/transitions | `Infrastructure/Data/AppDbContext.cs` |
| Skill 09 (Flow Orchestrator) | Transaction-specific engine | `Domain/Services/WorkflowEngine.cs` |
| Skill 15 (API Gateway) | Exception → ProblemDetails | `API/Middleware/ExceptionHandlerMiddleware.cs` |
| Skill 29 (Testing) | xUnit + Moq + InMemoryDB | `Tests/` |
| Skill 45 (Design Patterns) | Decorator (caching) | `Infrastructure/Caching/CachedWorkflowRepository.cs` |

---

## 🧠 AI Agent Configuration

| Agent | Config File |
|-------|-------------|
| GitHub Copilot | `.github/copilot-instructions.md` |
| Claude Code | `CLAUDE.md` |
| General | `.ai-config/project-architecture.md` |

**Key Rule:** Approach A uses domain exceptions (not DataProcessResult). Statuses are data, not enums.
