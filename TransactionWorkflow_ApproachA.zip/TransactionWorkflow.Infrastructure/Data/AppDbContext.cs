using Microsoft.EntityFrameworkCore;
using TransactionWorkflow.Domain.Models;

namespace TransactionWorkflow.Infrastructure.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<Transaction> Transactions => Set<Transaction>();
    public DbSet<WorkflowStatus> WorkflowStatuses => Set<WorkflowStatus>();
    public DbSet<WorkflowTransition> WorkflowTransitions => Set<WorkflowTransition>();
    public DbSet<TransactionHistory> TransactionHistory => Set<TransactionHistory>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // === Transaction ===
        modelBuilder.Entity<Transaction>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.ReferenceNumber).HasMaxLength(50).IsRequired();
            entity.HasIndex(e => e.ReferenceNumber).IsUnique();
            entity.Property(e => e.Amount).HasPrecision(18, 2);
            entity.Property(e => e.Currency).HasMaxLength(3).IsRequired();
            entity.Property(e => e.Description).HasMaxLength(500);

            // Optimistic concurrency via RowVersion
            entity.Property(e => e.RowVersion).IsRowVersion();

            entity.HasOne(e => e.Status)
                  .WithMany()
                  .HasForeignKey(e => e.StatusId)
                  .OnDelete(DeleteBehavior.Restrict);
        });

        // === WorkflowStatus ===
        modelBuilder.Entity<WorkflowStatus>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Name).HasMaxLength(50).IsRequired();
            entity.HasIndex(e => e.Name).IsUnique();
            entity.Property(e => e.Description).HasMaxLength(200);
        });

        // === WorkflowTransition ===
        modelBuilder.Entity<WorkflowTransition>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Description).HasMaxLength(200);

            // Unique constraint: only one transition per from→to pair
            entity.HasIndex(e => new { e.FromStatusId, e.ToStatusId }).IsUnique();

            entity.HasOne(e => e.FromStatus)
                  .WithMany(s => s.OutgoingTransitions)
                  .HasForeignKey(e => e.FromStatusId)
                  .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne(e => e.ToStatus)
                  .WithMany(s => s.IncomingTransitions)
                  .HasForeignKey(e => e.ToStatusId)
                  .OnDelete(DeleteBehavior.Restrict);
        });

        // === TransactionHistory ===
        modelBuilder.Entity<TransactionHistory>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.FromStatus).HasMaxLength(50).IsRequired();
            entity.Property(e => e.ToStatus).HasMaxLength(50).IsRequired();
            entity.Property(e => e.Reason).HasMaxLength(500);

            entity.HasOne(e => e.Transaction)
                  .WithMany(t => t.History)
                  .HasForeignKey(e => e.TransactionId)
                  .OnDelete(DeleteBehavior.Cascade);

            entity.HasIndex(e => e.TransactionId);
        });

        // === Seed Data ===
        SeedWorkflowData(modelBuilder);
    }

    private static void SeedWorkflowData(ModelBuilder modelBuilder)
    {
        // Statuses
        var created    = new WorkflowStatus { Id = 1, Name = "CREATED",    Description = "Transaction created, pending validation", IsInitial = true,  IsFinal = false };
        var validated  = new WorkflowStatus { Id = 2, Name = "VALIDATED",  Description = "Validation passed",                      IsInitial = false, IsFinal = false };
        var processing = new WorkflowStatus { Id = 3, Name = "PROCESSING", Description = "Transaction being processed",             IsInitial = false, IsFinal = false };
        var completed  = new WorkflowStatus { Id = 4, Name = "COMPLETED",  Description = "Transaction completed successfully",      IsInitial = false, IsFinal = true  };
        var failed     = new WorkflowStatus { Id = 5, Name = "FAILED",     Description = "Transaction failed",                      IsInitial = false, IsFinal = false };

        modelBuilder.Entity<WorkflowStatus>().HasData(created, validated, processing, completed, failed);

        // Transitions (matching the assignment diagram):
        // CREATED → VALIDATED → PROCESSING → COMPLETED
        //                                  ↘ FAILED → VALIDATED
        modelBuilder.Entity<WorkflowTransition>().HasData(
            new WorkflowTransition { Id = 1, FromStatusId = 1, ToStatusId = 2, Description = "Validate transaction" },      // CREATED → VALIDATED
            new WorkflowTransition { Id = 2, FromStatusId = 2, ToStatusId = 3, Description = "Begin processing" },          // VALIDATED → PROCESSING
            new WorkflowTransition { Id = 3, FromStatusId = 3, ToStatusId = 4, Description = "Complete transaction" },       // PROCESSING → COMPLETED
            new WorkflowTransition { Id = 4, FromStatusId = 3, ToStatusId = 5, Description = "Processing failed" },          // PROCESSING → FAILED
            new WorkflowTransition { Id = 5, FromStatusId = 5, ToStatusId = 2, Description = "Retry after failure" }         // FAILED → VALIDATED (retry/rollback)
        );
    }
}
