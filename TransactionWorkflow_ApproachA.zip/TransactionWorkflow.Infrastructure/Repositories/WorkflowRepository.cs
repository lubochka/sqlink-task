using Microsoft.EntityFrameworkCore;
using TransactionWorkflow.Domain.Interfaces;
using TransactionWorkflow.Domain.Models;
using TransactionWorkflow.Infrastructure.Data;

namespace TransactionWorkflow.Infrastructure.Repositories;

public class WorkflowRepository : IWorkflowRepository
{
    private readonly AppDbContext _db;

    public WorkflowRepository(AppDbContext db) => _db = db;

    public async Task<WorkflowStatus?> GetStatusByNameAsync(string name, CancellationToken ct = default)
    {
        return await _db.WorkflowStatuses
            .AsNoTracking()
            .FirstOrDefaultAsync(s => s.Name == name.ToUpperInvariant(), ct);
    }

    public async Task<WorkflowStatus?> GetInitialStatusAsync(CancellationToken ct = default)
    {
        return await _db.WorkflowStatuses
            .AsNoTracking()
            .FirstOrDefaultAsync(s => s.IsInitial, ct);
    }

    public async Task<List<WorkflowTransition>> GetAllowedTransitionsAsync(
        int fromStatusId, CancellationToken ct = default)
    {
        return await _db.WorkflowTransitions
            .Include(t => t.ToStatus)
            .AsNoTracking()
            .Where(t => t.FromStatusId == fromStatusId)
            .ToListAsync(ct);
    }

    public async Task<List<WorkflowStatus>> GetAllStatusesAsync(CancellationToken ct = default)
    {
        return await _db.WorkflowStatuses
            .AsNoTracking()
            .OrderBy(s => s.Id)
            .ToListAsync(ct);
    }

    public async Task<List<WorkflowTransition>> GetAllTransitionsAsync(CancellationToken ct = default)
    {
        return await _db.WorkflowTransitions
            .Include(t => t.FromStatus)
            .Include(t => t.ToStatus)
            .AsNoTracking()
            .OrderBy(t => t.Id)
            .ToListAsync(ct);
    }

    public async Task<WorkflowStatus> AddStatusAsync(WorkflowStatus status, CancellationToken ct = default)
    {
        _db.WorkflowStatuses.Add(status);
        await _db.SaveChangesAsync(ct);
        return status;
    }

    public async Task<WorkflowTransition> AddTransitionAsync(
        WorkflowTransition transition, CancellationToken ct = default)
    {
        _db.WorkflowTransitions.Add(transition);
        await _db.SaveChangesAsync(ct);

        // Reload with navigation properties
        await _db.Entry(transition).Reference(t => t.FromStatus).LoadAsync(ct);
        await _db.Entry(transition).Reference(t => t.ToStatus).LoadAsync(ct);

        return transition;
    }
}
