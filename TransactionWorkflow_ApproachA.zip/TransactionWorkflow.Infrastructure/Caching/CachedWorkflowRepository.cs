using Microsoft.Extensions.Caching.Memory;
using TransactionWorkflow.Domain.Interfaces;
using TransactionWorkflow.Domain.Models;

namespace TransactionWorkflow.Infrastructure.Caching;

/// <summary>
/// Decorator that caches workflow configuration in memory.
/// Avoids DB lookup on every transition request.
/// Cache is invalidated when admin adds new statuses/transitions.
/// </summary>
public class CachedWorkflowRepository : IWorkflowRepository
{
    private readonly IWorkflowRepository _inner;
    private readonly IMemoryCache _cache;
    private static readonly TimeSpan CacheDuration = TimeSpan.FromMinutes(30);

    private const string AllStatusesKey = "workflow:statuses:all";
    private const string AllTransitionsKey = "workflow:transitions:all";
    private const string InitialStatusKey = "workflow:status:initial";

    // Track per-status cache keys so we can invalidate them on admin writes
    private readonly HashSet<string> _trackedKeys = new();
    private readonly object _keyLock = new();

    public CachedWorkflowRepository(IWorkflowRepository inner, IMemoryCache cache)
    {
        _inner = inner;
        _cache = cache;
    }

    public async Task<WorkflowStatus?> GetStatusByNameAsync(string name, CancellationToken ct = default)
    {
        // Status lookups by name are infrequent (admin only), pass through
        return await _inner.GetStatusByNameAsync(name, ct);
    }

    public async Task<WorkflowStatus?> GetInitialStatusAsync(CancellationToken ct = default)
    {
        return await GetOrCreate(InitialStatusKey,
            () => _inner.GetInitialStatusAsync(ct));
    }

    public async Task<List<WorkflowTransition>> GetAllowedTransitionsAsync(
        int fromStatusId, CancellationToken ct = default)
    {
        var key = $"workflow:transitions:from:{fromStatusId}";
        return await GetOrCreate(key,
            () => _inner.GetAllowedTransitionsAsync(fromStatusId, ct)) ?? [];
    }

    public async Task<List<WorkflowStatus>> GetAllStatusesAsync(CancellationToken ct = default)
    {
        return await GetOrCreate(AllStatusesKey,
            () => _inner.GetAllStatusesAsync(ct)) ?? [];
    }

    public async Task<List<WorkflowTransition>> GetAllTransitionsAsync(CancellationToken ct = default)
    {
        return await GetOrCreate(AllTransitionsKey,
            () => _inner.GetAllTransitionsAsync(ct)) ?? [];
    }

    public async Task<WorkflowStatus> AddStatusAsync(WorkflowStatus status, CancellationToken ct = default)
    {
        var result = await _inner.AddStatusAsync(status, ct);
        InvalidateAll();
        return result;
    }

    public async Task<WorkflowTransition> AddTransitionAsync(
        WorkflowTransition transition, CancellationToken ct = default)
    {
        var result = await _inner.AddTransitionAsync(transition, ct);
        InvalidateAll();
        return result;
    }

    private async Task<T?> GetOrCreate<T>(string key, Func<Task<T?>> factory)
    {
        lock (_keyLock) _trackedKeys.Add(key);
        return await _cache.GetOrCreateAsync(key, async entry =>
        {
            entry.AbsoluteExpirationRelativeToNow = CacheDuration;
            return await factory();
        });
    }

    private void InvalidateAll()
    {
        lock (_keyLock)
        {
            foreach (var key in _trackedKeys)
                _cache.Remove(key);
            _trackedKeys.Clear();
        }
    }
}
