using TransactionWorkflow.Application.DTOs;
using TransactionWorkflow.Application.Interfaces;
using TransactionWorkflow.Domain.Exceptions;
using TransactionWorkflow.Domain.Interfaces;
using TransactionWorkflow.Domain.Models;

namespace TransactionWorkflow.Application.Services;

public class WorkflowAdminService : IWorkflowAdminService
{
    private readonly IWorkflowRepository _workflowRepo;

    public WorkflowAdminService(IWorkflowRepository workflowRepo)
    {
        _workflowRepo = workflowRepo;
    }

    public async Task<WorkflowStatusDto> AddStatusAsync(
        AddStatusRequest request, CancellationToken ct = default)
    {
        // Check for duplicate name
        var existing = await _workflowRepo.GetStatusByNameAsync(request.Name, ct);
        if (existing is not null)
            throw new DuplicateEntityException($"Status '{request.Name}' already exists.");

        var status = new WorkflowStatus
        {
            Name = request.Name.ToUpperInvariant(),
            Description = request.Description,
            IsInitial = request.IsInitial,
            IsFinal = request.IsFinal
        };

        var created = await _workflowRepo.AddStatusAsync(status, ct);
        return new WorkflowStatusDto(created.Id, created.Name, created.Description, created.IsInitial, created.IsFinal);
    }

    public async Task<WorkflowTransitionDto> AddTransitionAsync(
        AddTransitionRequest request, CancellationToken ct = default)
    {
        var fromStatus = await _workflowRepo.GetStatusByNameAsync(request.FromStatus, ct)
            ?? throw new StatusNotFoundException(request.FromStatus);

        var toStatus = await _workflowRepo.GetStatusByNameAsync(request.ToStatus, ct)
            ?? throw new StatusNotFoundException(request.ToStatus);

        var transition = new WorkflowTransition
        {
            FromStatusId = fromStatus.Id,
            ToStatusId = toStatus.Id,
            Description = request.Description
        };

        var created = await _workflowRepo.AddTransitionAsync(transition, ct);
        return new WorkflowTransitionDto(created.Id, fromStatus.Name, toStatus.Name, created.Description);
    }

    public async Task<List<WorkflowStatusDto>> GetAllStatusesAsync(CancellationToken ct = default)
    {
        var statuses = await _workflowRepo.GetAllStatusesAsync(ct);
        return statuses.Select(s =>
            new WorkflowStatusDto(s.Id, s.Name, s.Description, s.IsInitial, s.IsFinal)).ToList();
    }

    public async Task<List<WorkflowTransitionDto>> GetAllTransitionsAsync(CancellationToken ct = default)
    {
        var transitions = await _workflowRepo.GetAllTransitionsAsync(ct);
        return transitions.Select(t =>
            new WorkflowTransitionDto(t.Id, t.FromStatus.Name, t.ToStatus.Name, t.Description)).ToList();
    }

    public async Task<string> GetWorkflowVisualizationAsync(CancellationToken ct = default)
    {
        var transitions = await _workflowRepo.GetAllTransitionsAsync(ct);
        var lines = new List<string> { "graph TD" };

        foreach (var t in transitions)
        {
            var label = t.Description ?? $"{t.FromStatus.Name} → {t.ToStatus.Name}";
            lines.Add($"    {t.FromStatus.Name} -->|\"{label}\"| {t.ToStatus.Name}");
        }

        // Style final states
        var statuses = await _workflowRepo.GetAllStatusesAsync(ct);
        foreach (var s in statuses.Where(s => s.IsFinal))
            lines.Add($"    style {s.Name} fill:#22c55e,color:#fff");
        foreach (var s in statuses.Where(s => s.IsInitial))
            lines.Add($"    style {s.Name} fill:#3b82f6,color:#fff");

        return string.Join("\n", lines);
    }
}
