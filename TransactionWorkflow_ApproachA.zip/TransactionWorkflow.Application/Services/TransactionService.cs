using TransactionWorkflow.Application.DTOs;
using TransactionWorkflow.Application.Interfaces;
using TransactionWorkflow.Domain.Interfaces;
using TransactionWorkflow.Domain.Models;
using TransactionWorkflow.Domain.Services;

namespace TransactionWorkflow.Application.Services;

public class TransactionService : ITransactionService
{
    private readonly ITransactionRepository _transactionRepo;
    private readonly WorkflowEngine _workflowEngine;

    public TransactionService(
        ITransactionRepository transactionRepo,
        WorkflowEngine workflowEngine)
    {
        _transactionRepo = transactionRepo;
        _workflowEngine = workflowEngine;
    }

    public async Task<TransactionDto> CreateTransactionAsync(
        CreateTransactionRequest request, CancellationToken ct = default)
    {
        var initialStatus = await _workflowEngine.GetInitialStatusAsync(ct);

        var transaction = new Transaction
        {
            ReferenceNumber = GenerateReferenceNumber(),
            Amount = request.Amount,
            Currency = request.Currency,
            Description = request.Description,
            StatusId = initialStatus.Id,
            // Note: Do NOT set Status = initialStatus here.
            // The cached entity may be from a previous DbContext scope
            // (IMemoryCache is singleton, DbContext is scoped). Setting
            // the navigation causes Add() to cascade and mark the
            // WorkflowStatus as Added → duplicate INSERT attempt.
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow
        };

        var created = await _transactionRepo.CreateAsync(transaction, ct);

        // Reload with navigation for the DTO
        var refreshed = await _transactionRepo.GetByIdAsync(created.Id, ct);
        return MapToDto(refreshed!);
    }

    public async Task<TransactionDto?> GetTransactionAsync(int id, CancellationToken ct = default)
    {
        var transaction = await _transactionRepo.GetByIdAsync(id, ct);
        return transaction is null ? null : MapToDto(transaction);
    }

    public async Task<TransactionDto> TransitionAsync(
        int id, TransitionRequest request, CancellationToken ct = default)
    {
        var transaction = await _transactionRepo.GetByIdAsync(id, ct)
            ?? throw new Domain.Exceptions.TransactionNotFoundException(id);

        // Delegate ALL transition logic to WorkflowEngine (single responsibility)
        var history = await _workflowEngine.TransitionAsync(
            transaction, request.TargetStatus, request.Reason, ct);

        // Persist both the updated transaction and the history record
        await _transactionRepo.UpdateAsync(transaction, ct);
        await _transactionRepo.AddHistoryAsync(history, ct);

        // Reload to get fresh Status navigation (we only updated StatusId above)
        var refreshed = await _transactionRepo.GetByIdAsync(id, ct);
        return MapToDto(refreshed!);
    }

    public async Task<List<AvailableTransitionDto>> GetAvailableTransitionsAsync(
        int id, CancellationToken ct = default)
    {
        var transaction = await _transactionRepo.GetByIdAsync(id, ct)
            ?? throw new Domain.Exceptions.TransactionNotFoundException(id);

        var available = await _workflowEngine.GetAvailableTransitionsAsync(transaction, ct);

        return available.Select(s => new AvailableTransitionDto(
            s.Id, s.Name, s.Description)).ToList();
    }

    public async Task<List<TransactionHistoryDto>> GetHistoryAsync(
        int id, CancellationToken ct = default)
    {
        // Verify transaction exists
        _ = await _transactionRepo.GetByIdAsync(id, ct)
            ?? throw new Domain.Exceptions.TransactionNotFoundException(id);

        var history = await _transactionRepo.GetHistoryAsync(id, ct);

        return history.Select(h => new TransactionHistoryDto(
            h.FromStatus, h.ToStatus, h.Reason, h.Timestamp)).ToList();
    }

    private static TransactionDto MapToDto(Transaction t) => new(
        t.Id,
        t.ReferenceNumber,
        t.Amount,
        t.Currency,
        t.Description,
        t.Status?.Name ?? "Unknown",
        t.CreatedAt,
        t.UpdatedAt);

    private static string GenerateReferenceNumber() =>
        $"TXN-{DateTime.UtcNow:yyyyMMdd}-{Guid.NewGuid().ToString("N")[..8].ToUpper()}";
}
