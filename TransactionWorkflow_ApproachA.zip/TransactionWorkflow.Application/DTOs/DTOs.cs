namespace TransactionWorkflow.Application.DTOs;

// === Responses ===

public record TransactionDto(
    int Id,
    string ReferenceNumber,
    decimal Amount,
    string Currency,
    string Description,
    string Status,
    DateTime CreatedAt,
    DateTime UpdatedAt);

public record AvailableTransitionDto(
    int StatusId,
    string StatusName,
    string? Description);

public record TransactionHistoryDto(
    string FromStatus,
    string ToStatus,
    string? Reason,
    DateTime Timestamp);

public record WorkflowStatusDto(
    int Id,
    string Name,
    string? Description,
    bool IsInitial,
    bool IsFinal);

public record WorkflowTransitionDto(
    int Id,
    string FromStatus,
    string ToStatus,
    string? Description);

// === Requests ===

public record CreateTransactionRequest(
    decimal Amount,
    string Currency = "USD",
    string Description = "");

public record TransitionRequest(
    string TargetStatus,
    string? Reason = null);

public record AddStatusRequest(
    string Name,
    string? Description = null,
    bool IsInitial = false,
    bool IsFinal = false);

public record AddTransitionRequest(
    string FromStatus,
    string ToStatus,
    string? Description = null);

// === Error Response ===

public record ErrorResponse(
    string Error,
    string? Detail = null,
    string[]? AllowedTransitions = null);
