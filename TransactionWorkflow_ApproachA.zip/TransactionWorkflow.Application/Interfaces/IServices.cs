using TransactionWorkflow.Application.DTOs;

namespace TransactionWorkflow.Application.Interfaces;

public interface ITransactionService
{
    Task<TransactionDto> CreateTransactionAsync(CreateTransactionRequest request, CancellationToken ct = default);
    Task<TransactionDto?> GetTransactionAsync(int id, CancellationToken ct = default);
    Task<TransactionDto> TransitionAsync(int id, TransitionRequest request, CancellationToken ct = default);
    Task<List<AvailableTransitionDto>> GetAvailableTransitionsAsync(int id, CancellationToken ct = default);
    Task<List<TransactionHistoryDto>> GetHistoryAsync(int id, CancellationToken ct = default);
}

public interface IWorkflowAdminService
{
    Task<WorkflowStatusDto> AddStatusAsync(AddStatusRequest request, CancellationToken ct = default);
    Task<WorkflowTransitionDto> AddTransitionAsync(AddTransitionRequest request, CancellationToken ct = default);
    Task<List<WorkflowStatusDto>> GetAllStatusesAsync(CancellationToken ct = default);
    Task<List<WorkflowTransitionDto>> GetAllTransitionsAsync(CancellationToken ct = default);
    Task<string> GetWorkflowVisualizationAsync(CancellationToken ct = default);
}
