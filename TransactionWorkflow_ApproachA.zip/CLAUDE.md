# CLAUDE.md — Transaction Workflow Engine (Approach A: Vanilla)

A standard .NET 8 Clean Architecture transaction workflow engine with configurable, data-driven
status transitions. Statuses and transitions are defined in the database, not in code.

## Read First
- `.ai-config/project-architecture.md` — Architecture philosophy and V17 skill mapping
- `.ai-config/coding-standards.md` — Code examples and patterns
- `TransactionWorkflow.Domain/Services/WorkflowEngine.cs` — The core engine
- `TransactionWorkflow.Domain/Exceptions/DomainExceptions.cs` — Business exceptions

## Rules
1. ALL business failures use domain exceptions — never return error objects
2. ALL async methods take `CancellationToken ct = default` as last param
3. `ExceptionHandlerMiddleware` maps exceptions to RFC 7807 ProblemDetails
4. Statuses/transitions are DB rows — never C# enums
5. WorkflowEngine is Transaction-specific (not generic)
6. Caching uses Decorator pattern (CachedWorkflowRepository)
7. FluentValidation for input validation
8. Concurrency via RowVersion (optimistic locking)

## Tech Stack
.NET 8, EF Core 8, SQL Server (Docker), xUnit, Moq, FluentValidation

## Quick Reference
| What | Where |
|------|-------|
| Domain entities | `TransactionWorkflow.Domain/Models/` |
| Workflow engine | `TransactionWorkflow.Domain/Services/WorkflowEngine.cs` |
| Exceptions | `TransactionWorkflow.Domain/Exceptions/DomainExceptions.cs` |
| Repositories | `TransactionWorkflow.Infrastructure/Repositories/` |
| Caching | `TransactionWorkflow.Infrastructure/Caching/CachedWorkflowRepository.cs` |
| DB Context | `TransactionWorkflow.Infrastructure/Data/AppDbContext.cs` |
| Controllers | `TransactionWorkflow.API/Controllers/` |
| Error mapping | `TransactionWorkflow.API/Middleware/ExceptionHandlerMiddleware.cs` |
| Validators | `TransactionWorkflow.API/Validators/RequestValidators.cs` |
| Tests | `TransactionWorkflow.Tests/` |
