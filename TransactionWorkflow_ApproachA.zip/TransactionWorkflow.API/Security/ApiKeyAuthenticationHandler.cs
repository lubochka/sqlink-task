using System.Security.Claims;
using System.Text.Encodings.Web;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Options;

namespace TransactionWorkflow.API.Security;

/// <summary>
/// API Key authentication handler.
/// 
/// Validates the X-Api-Key header against the configured key.
/// In Development mode, if no key is configured, authentication is bypassed
/// to allow frictionless local testing.
/// 
/// Production usage:
///   1. Set Authentication__ApiKey in environment/config
///   2. All requests must include: X-Api-Key: {your-key}
///   3. Admin endpoints additionally require the "Admin" role claim
/// </summary>
public class ApiKeyAuthenticationHandler : AuthenticationHandler<ApiKeyAuthenticationOptions>
{
    private const string ApiKeyHeaderName = "X-Api-Key";

    public ApiKeyAuthenticationHandler(
        IOptionsMonitor<ApiKeyAuthenticationOptions> options,
        ILoggerFactory logger,
        UrlEncoder encoder) : base(options, logger, encoder)
    {
    }

    protected override Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        // If no API key is configured (dev mode), allow all requests
        if (string.IsNullOrEmpty(Options.ApiKey))
        {
            var devClaims = new[]
            {
                new Claim(ClaimTypes.Name, "dev-user"),
                new Claim(ClaimTypes.Role, "Admin"),
                new Claim(ClaimTypes.Role, "User")
            };
            var devIdentity = new ClaimsIdentity(devClaims, Scheme.Name);
            return Task.FromResult(AuthenticateResult.Success(
                new AuthenticationTicket(new ClaimsPrincipal(devIdentity), Scheme.Name)));
        }

        // Validate API key header
        if (!Request.Headers.TryGetValue(ApiKeyHeaderName, out var extractedKey))
        {
            return Task.FromResult(AuthenticateResult.Fail(
                $"Missing {ApiKeyHeaderName} header. Include it in your request."));
        }

        if (!string.Equals(extractedKey, Options.ApiKey, StringComparison.Ordinal))
        {
            return Task.FromResult(AuthenticateResult.Fail("Invalid API key."));
        }

        // Determine role from key prefix convention (admin- prefix = Admin role)
        var roles = new List<Claim>
        {
            new(ClaimTypes.Name, "api-client"),
            new(ClaimTypes.Role, "User")
        };

        // In a real system, you'd look up the key in a database to determine roles.
        // For this demo, all valid keys get Admin access.
        roles.Add(new Claim(ClaimTypes.Role, "Admin"));

        var identity = new ClaimsIdentity(roles, Scheme.Name);
        var ticket = new AuthenticationTicket(new ClaimsPrincipal(identity), Scheme.Name);
        return Task.FromResult(AuthenticateResult.Success(ticket));
    }
}

public class ApiKeyAuthenticationOptions : AuthenticationSchemeOptions
{
    public string? ApiKey { get; set; }
}

public static class ApiKeyAuthenticationDefaults
{
    public const string AuthenticationScheme = "ApiKey";
}
