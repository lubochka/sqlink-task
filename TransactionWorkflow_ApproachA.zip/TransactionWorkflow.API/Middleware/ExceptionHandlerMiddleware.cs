using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using TransactionWorkflow.Domain.Exceptions;

namespace TransactionWorkflow.API.Middleware;

/// <summary>
/// Maps domain exceptions to RFC 7807 ProblemDetails HTTP responses.
///
/// Approach A uses exceptions for business logic flow control.
/// This middleware is the single translation layer from those exceptions
/// to structured, standardized HTTP error responses.
/// </summary>
public class ExceptionHandlerMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<ExceptionHandlerMiddleware> _logger;
    private readonly IHostEnvironment _env;

    public ExceptionHandlerMiddleware(RequestDelegate next, ILogger<ExceptionHandlerMiddleware> logger, IHostEnvironment env)
    {
        _next = next;
        _logger = logger;
        _env = env;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (Exception ex)
        {
            if (context.Response.HasStarted)
            {
                _logger.LogWarning("Response already started — cannot write ProblemDetails for: {Message}", ex.Message);
                throw; // Let Kestrel handle it
            }

            await HandleExceptionAsync(context, ex);
        }
    }

    private async Task HandleExceptionAsync(HttpContext context, Exception exception)
    {
        var (statusCode, problem) = exception switch
        {
            InvalidTransitionException e => (
                StatusCodes.Status400BadRequest,
                new ProblemDetails
                {
                    Type = "https://httpstatuses.io/400",
                    Title = "InvalidTransition",
                    Status = 400,
                    Detail = e.Message,
                    Extensions =
                    {
                        ["allowedTransitions"] = e.AllowedStatuses.ToArray(),
                        ["currentStatus"] = e.CurrentStatus
                    }
                }),

            TransactionNotFoundException e => (
                StatusCodes.Status404NotFound,
                new ProblemDetails
                {
                    Type = "https://httpstatuses.io/404",
                    Title = "TransactionNotFound",
                    Status = 404,
                    Detail = e.Message
                }),

            StatusNotFoundException e => (
                StatusCodes.Status404NotFound,
                new ProblemDetails
                {
                    Type = "https://httpstatuses.io/404",
                    Title = "StatusNotFound",
                    Status = 404,
                    Detail = e.Message
                }),

            DuplicateEntityException e => (
                StatusCodes.Status409Conflict,
                new ProblemDetails
                {
                    Type = "https://httpstatuses.io/409",
                    Title = "DuplicateEntity",
                    Status = 409,
                    Detail = e.Message
                }),

            WorkflowConfigurationException e => (
                StatusCodes.Status500InternalServerError,
                new ProblemDetails
                {
                    Type = "https://httpstatuses.io/500",
                    Title = "WorkflowConfigurationError",
                    Status = 500,
                    Detail = e.Message
                }),

            ConcurrencyConflictException e => (
                StatusCodes.Status409Conflict,
                new ProblemDetails
                {
                    Type = "https://httpstatuses.io/409",
                    Title = "ConcurrencyConflict",
                    Status = 409,
                    Detail = e.Message
                }),

            _ => (
                StatusCodes.Status500InternalServerError,
                new ProblemDetails
                {
                    Type = "https://httpstatuses.io/500",
                    Title = "Internal Server Error",
                    Status = 500,
                    Detail = _env.IsDevelopment()
                        ? $"{exception.GetType().Name}: {exception.Message}"
                        : "An unexpected error occurred."
                })
        };

        if (statusCode == StatusCodes.Status500InternalServerError)
            _logger.LogError(exception, "Unhandled exception [{ExType}]: {Message}\n{Stack}",
                exception.GetType().FullName, exception.Message, exception.StackTrace);
        else
            _logger.LogWarning("Domain exception: {Type} — {Message}", exception.GetType().Name, exception.Message);

        context.Response.StatusCode = statusCode;
        context.Response.ContentType = "application/problem+json";

        var json = JsonSerializer.Serialize(problem, new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase
        });

        await context.Response.WriteAsync(json);
    }
}
