using Microsoft.AspNetCore.Mvc;
using TransactionWorkflow.Application.DTOs;
using TransactionWorkflow.Application.Interfaces;

namespace TransactionWorkflow.API.Controllers;

[ApiController]
[Route("transactions")]
[Produces("application/json")]
public class TransactionsController : ControllerBase
{
    private readonly ITransactionService _service;

    public TransactionsController(ITransactionService service) => _service = service;

    /// <summary>Create a new transaction (starts at initial workflow status)</summary>
    [HttpPost]
    [ProducesResponseType(typeof(TransactionDto), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> Create(
        [FromBody] CreateTransactionRequest request, CancellationToken ct)
    {
        var transaction = await _service.CreateTransactionAsync(request, ct);
        return CreatedAtAction(nameof(GetById), new { id = transaction.Id }, transaction);
    }

    /// <summary>Get a transaction by ID</summary>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(TransactionDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetById(int id, CancellationToken ct)
    {
        var transaction = await _service.GetTransactionAsync(id, ct);
        return transaction is null
            ? NotFound(new ErrorResponse("Transaction not found", $"No transaction with ID {id}"))
            : Ok(transaction);
    }

    /// <summary>Transition a transaction to a new status</summary>
    [HttpPost("{id:int}/transition")]
    [ProducesResponseType(typeof(TransactionDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Transition(
        int id, [FromBody] TransitionRequest request, CancellationToken ct)
    {
        var transaction = await _service.TransitionAsync(id, request, ct);
        return Ok(transaction);
    }

    /// <summary>Get available transitions for a transaction</summary>
    [HttpGet("{id:int}/available-transitions")]
    [ProducesResponseType(typeof(List<AvailableTransitionDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetAvailableTransitions(int id, CancellationToken ct)
    {
        var transitions = await _service.GetAvailableTransitionsAsync(id, ct);
        return Ok(transitions);
    }

    /// <summary>Get status change history for a transaction</summary>
    [HttpGet("{id:int}/history")]
    [ProducesResponseType(typeof(List<TransactionHistoryDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetHistory(int id, CancellationToken ct)
    {
        var history = await _service.GetHistoryAsync(id, ct);
        return Ok(history);
    }
}
