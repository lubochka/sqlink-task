using Moq;
using TransactionWorkflow.Domain.Exceptions;
using TransactionWorkflow.Domain.Interfaces;
using TransactionWorkflow.Domain.Models;
using TransactionWorkflow.Domain.Services;

namespace TransactionWorkflow.Tests;

public class WorkflowEngineTests
{
    private readonly Mock<IWorkflowRepository> _mockRepo;
    private readonly WorkflowEngine _engine;

    public WorkflowEngineTests()
    {
        _mockRepo = new Mock<IWorkflowRepository>();
        _engine = new WorkflowEngine(_mockRepo.Object);
    }

    private static WorkflowStatus MakeStatus(int id, string name, bool isInitial = false) =>
        new() { Id = id, Name = name, IsInitial = isInitial };

    private static Transaction MakeTransaction(WorkflowStatus status) =>
        new() { Id = 1, StatusId = status.Id, Status = status, Amount = 100m, ReferenceNumber = "TXN-001" };

    // === Valid Transitions ===

    [Fact]
    public async Task TransitionAsync_ValidTransition_ReturnsHistory()
    {
        // Arrange: CREATED → VALIDATED is allowed
        var created = MakeStatus(1, "CREATED", isInitial: true);
        var validated = MakeStatus(2, "VALIDATED");
        var transaction = MakeTransaction(created);

        _mockRepo.Setup(r => r.GetAllowedTransitionsAsync(1, It.IsAny<CancellationToken>()))
            .ReturnsAsync([new WorkflowTransition { Id = 1, FromStatusId = 1, ToStatusId = 2, ToStatus = validated }]);

        // Act
        var history = await _engine.TransitionAsync(transaction, "VALIDATED");

        // Assert
        Assert.Equal("CREATED", history.FromStatus);
        Assert.Equal("VALIDATED", history.ToStatus);
        Assert.Equal(2, transaction.StatusId);
        Assert.Equal(validated, transaction.Status);
    }

    [Fact]
    public async Task TransitionAsync_CaseInsensitive_Works()
    {
        var created = MakeStatus(1, "CREATED");
        var validated = MakeStatus(2, "VALIDATED");
        var transaction = MakeTransaction(created);

        _mockRepo.Setup(r => r.GetAllowedTransitionsAsync(1, It.IsAny<CancellationToken>()))
            .ReturnsAsync([new WorkflowTransition { Id = 1, FromStatusId = 1, ToStatusId = 2, ToStatus = validated }]);

        var history = await _engine.TransitionAsync(transaction, "validated"); // lowercase

        Assert.Equal("VALIDATED", history.ToStatus);
    }

    [Fact]
    public async Task TransitionAsync_BackwardTransition_WorksWhenAllowed()
    {
        // FAILED → VALIDATED (retry/rollback) is allowed per seed data
        var failed = MakeStatus(5, "FAILED");
        var validated = MakeStatus(2, "VALIDATED");
        var transaction = MakeTransaction(failed);

        _mockRepo.Setup(r => r.GetAllowedTransitionsAsync(5, It.IsAny<CancellationToken>()))
            .ReturnsAsync([new WorkflowTransition { Id = 5, FromStatusId = 5, ToStatusId = 2, ToStatus = validated }]);

        var history = await _engine.TransitionAsync(transaction, "VALIDATED", "Retrying after fix");

        Assert.Equal("FAILED", history.FromStatus);
        Assert.Equal("VALIDATED", history.ToStatus);
        Assert.Equal("Retrying after fix", history.Reason);
    }

    // === Invalid Transitions ===

    [Fact]
    public async Task TransitionAsync_InvalidTransition_ThrowsWithAllowedList()
    {
        // CREATED → COMPLETED is NOT allowed (must go through VALIDATED → PROCESSING first)
        var created = MakeStatus(1, "CREATED");
        var validated = MakeStatus(2, "VALIDATED");
        var transaction = MakeTransaction(created);

        _mockRepo.Setup(r => r.GetAllowedTransitionsAsync(1, It.IsAny<CancellationToken>()))
            .ReturnsAsync([new WorkflowTransition { Id = 1, FromStatusId = 1, ToStatusId = 2, ToStatus = validated }]);

        var ex = await Assert.ThrowsAsync<InvalidTransitionException>(
            () => _engine.TransitionAsync(transaction, "COMPLETED"));

        Assert.Equal("CREATED", ex.CurrentStatus);
        Assert.Equal("COMPLETED", ex.AttemptedStatus);
        Assert.Contains("VALIDATED", ex.AllowedStatuses);
        Assert.DoesNotContain("COMPLETED", ex.AllowedStatuses);
    }

    [Fact]
    public async Task TransitionAsync_NoTransitionsAvailable_ThrowsWithEmptyList()
    {
        // COMPLETED is a final state — no outgoing transitions
        var completed = MakeStatus(4, "COMPLETED");
        var transaction = MakeTransaction(completed);

        _mockRepo.Setup(r => r.GetAllowedTransitionsAsync(4, It.IsAny<CancellationToken>()))
            .ReturnsAsync([]);

        var ex = await Assert.ThrowsAsync<InvalidTransitionException>(
            () => _engine.TransitionAsync(transaction, "PROCESSING"));

        Assert.Empty(ex.AllowedStatuses);
    }

    [Fact]
    public async Task TransitionAsync_UnknownTargetStatus_Throws()
    {
        var created = MakeStatus(1, "CREATED");
        var validated = MakeStatus(2, "VALIDATED");
        var transaction = MakeTransaction(created);

        _mockRepo.Setup(r => r.GetAllowedTransitionsAsync(1, It.IsAny<CancellationToken>()))
            .ReturnsAsync([new WorkflowTransition { Id = 1, FromStatusId = 1, ToStatusId = 2, ToStatus = validated }]);

        await Assert.ThrowsAsync<InvalidTransitionException>(
            () => _engine.TransitionAsync(transaction, "NONEXISTENT"));
    }

    // === Available Transitions ===

    [Fact]
    public async Task GetAvailableTransitionsAsync_ReturnsTargetStatuses()
    {
        var processing = MakeStatus(3, "PROCESSING");
        var completed = MakeStatus(4, "COMPLETED");
        var failed = MakeStatus(5, "FAILED");
        var transaction = MakeTransaction(processing);

        _mockRepo.Setup(r => r.GetAllowedTransitionsAsync(3, It.IsAny<CancellationToken>()))
            .ReturnsAsync([
                new WorkflowTransition { Id = 3, FromStatusId = 3, ToStatusId = 4, ToStatus = completed },
                new WorkflowTransition { Id = 4, FromStatusId = 3, ToStatusId = 5, ToStatus = failed }
            ]);

        var available = await _engine.GetAvailableTransitionsAsync(transaction);

        Assert.Equal(2, available.Count);
        Assert.Contains(available, s => s.Name == "COMPLETED");
        Assert.Contains(available, s => s.Name == "FAILED");
    }

    // === Initial Status ===

    [Fact]
    public async Task GetInitialStatusAsync_ReturnsInitialStatus()
    {
        var created = MakeStatus(1, "CREATED", isInitial: true);
        _mockRepo.Setup(r => r.GetInitialStatusAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(created);

        var initial = await _engine.GetInitialStatusAsync();

        Assert.Equal("CREATED", initial.Name);
        Assert.True(initial.IsInitial);
    }

    [Fact]
    public async Task GetInitialStatusAsync_NoInitialConfigured_Throws()
    {
        _mockRepo.Setup(r => r.GetInitialStatusAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync((WorkflowStatus?)null);

        await Assert.ThrowsAsync<WorkflowConfigurationException>(
            () => _engine.GetInitialStatusAsync());
    }

    // === Edge: Transaction Without Loaded Status ===

    [Fact]
    public async Task TransitionAsync_NullStatus_ThrowsConfigException()
    {
        var transaction = new Transaction { Id = 1, StatusId = 1, Status = null! };

        await Assert.ThrowsAsync<WorkflowConfigurationException>(
            () => _engine.TransitionAsync(transaction, "VALIDATED"));
    }
}
