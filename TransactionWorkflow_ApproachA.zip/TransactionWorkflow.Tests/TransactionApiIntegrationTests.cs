using System.Net;
using System.Net.Http.Json;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using TransactionWorkflow.Application.DTOs;
using TransactionWorkflow.Infrastructure.Data;

namespace TransactionWorkflow.Tests;

public class TransactionApiIntegrationTests : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly HttpClient _client;

    public TransactionApiIntegrationTests(WebApplicationFactory<Program> factory)
    {
        _client = factory.WithWebHostBuilder(builder =>
        {
            builder.ConfigureServices(services =>
            {
                // Replace SQL Server with in-memory DB for tests
                var descriptor = services.SingleOrDefault(
                    d => d.ServiceType == typeof(DbContextOptions<AppDbContext>));
                if (descriptor != null) services.Remove(descriptor);

                services.AddDbContext<AppDbContext>(options =>
                    options.UseInMemoryDatabase("TestDb_" + Guid.NewGuid()));

                // Ensure DB is seeded
                var sp = services.BuildServiceProvider();
                using var scope = sp.CreateScope();
                var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
                db.Database.EnsureCreated();
            });
        }).CreateClient();
    }

    // === Create Transaction ===

    [Fact]
    public async Task CreateTransaction_ReturnsCreatedWithInitialStatus()
    {
        var request = new CreateTransactionRequest(Amount: 250.50m, Currency: "USD", Description: "Test payment");
        var response = await _client.PostAsJsonAsync("/transactions", request);

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var transaction = await response.Content.ReadFromJsonAsync<TransactionDto>();
        Assert.NotNull(transaction);
        Assert.Equal("CREATED", transaction.Status);
        Assert.Equal(250.50m, transaction.Amount);
        Assert.StartsWith("TXN-", transaction.ReferenceNumber);
    }

    // === Get Transaction ===

    [Fact]
    public async Task GetTransaction_ExistingId_ReturnsTransaction()
    {
        // Create first
        var createReq = new CreateTransactionRequest(100m);
        var createResp = await _client.PostAsJsonAsync("/transactions", createReq);
        var created = await createResp.Content.ReadFromJsonAsync<TransactionDto>();

        // Get
        var response = await _client.GetAsync($"/transactions/{created!.Id}");
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        var transaction = await response.Content.ReadFromJsonAsync<TransactionDto>();
        Assert.Equal(created.Id, transaction!.Id);
        Assert.Equal("CREATED", transaction.Status);
    }

    [Fact]
    public async Task GetTransaction_NonExistentId_Returns404()
    {
        var response = await _client.GetAsync("/transactions/99999");
        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    // === Valid Transition ===

    [Fact]
    public async Task Transition_ValidPath_UpdatesStatus()
    {
        // Create
        var createResp = await _client.PostAsJsonAsync("/transactions", new CreateTransactionRequest(100m));
        var created = await createResp.Content.ReadFromJsonAsync<TransactionDto>();

        // Transition: CREATED → VALIDATED
        var transResp = await _client.PostAsJsonAsync(
            $"/transactions/{created!.Id}/transition",
            new TransitionRequest("VALIDATED", "Validation passed"));

        Assert.Equal(HttpStatusCode.OK, transResp.StatusCode);
        var updated = await transResp.Content.ReadFromJsonAsync<TransactionDto>();
        Assert.Equal("VALIDATED", updated!.Status);
    }

    // === Invalid Transition ===

    [Fact]
    public async Task Transition_InvalidPath_Returns400WithAllowedList()
    {
        // Create (status = CREATED)
        var createResp = await _client.PostAsJsonAsync("/transactions", new CreateTransactionRequest(100m));
        var created = await createResp.Content.ReadFromJsonAsync<TransactionDto>();

        // Try invalid: CREATED → COMPLETED (should fail)
        var transResp = await _client.PostAsJsonAsync(
            $"/transactions/{created!.Id}/transition",
            new TransitionRequest("COMPLETED"));

        Assert.Equal(HttpStatusCode.BadRequest, transResp.StatusCode);
        var error = await transResp.Content.ReadFromJsonAsync<ErrorResponse>();
        Assert.NotNull(error);
        Assert.Equal("Invalid transition", error.Error);
        Assert.Contains("VALIDATED", error.AllowedTransitions!);
    }

    // === Full Workflow Path ===

    [Fact]
    public async Task FullWorkflow_HappyPath_CREATED_to_COMPLETED()
    {
        // Create
        var resp = await _client.PostAsJsonAsync("/transactions", new CreateTransactionRequest(500m));
        var txn = await resp.Content.ReadFromJsonAsync<TransactionDto>();
        Assert.Equal("CREATED", txn!.Status);

        // CREATED → VALIDATED
        resp = await _client.PostAsJsonAsync($"/transactions/{txn.Id}/transition", new TransitionRequest("VALIDATED"));
        txn = await resp.Content.ReadFromJsonAsync<TransactionDto>();
        Assert.Equal("VALIDATED", txn!.Status);

        // VALIDATED → PROCESSING
        resp = await _client.PostAsJsonAsync($"/transactions/{txn.Id}/transition", new TransitionRequest("PROCESSING"));
        txn = await resp.Content.ReadFromJsonAsync<TransactionDto>();
        Assert.Equal("PROCESSING", txn!.Status);

        // PROCESSING → COMPLETED
        resp = await _client.PostAsJsonAsync($"/transactions/{txn.Id}/transition", new TransitionRequest("COMPLETED"));
        txn = await resp.Content.ReadFromJsonAsync<TransactionDto>();
        Assert.Equal("COMPLETED", txn!.Status);
    }

    [Fact]
    public async Task FullWorkflow_FailureAndRetry_Path()
    {
        // Create → Validate → Process → FAIL → Retry (back to VALIDATED)
        var resp = await _client.PostAsJsonAsync("/transactions", new CreateTransactionRequest(200m));
        var txn = await resp.Content.ReadFromJsonAsync<TransactionDto>();

        await _client.PostAsJsonAsync($"/transactions/{txn!.Id}/transition", new TransitionRequest("VALIDATED"));
        await _client.PostAsJsonAsync($"/transactions/{txn.Id}/transition", new TransitionRequest("PROCESSING"));
        resp = await _client.PostAsJsonAsync($"/transactions/{txn.Id}/transition", new TransitionRequest("FAILED", "Payment gateway timeout"));
        txn = await resp.Content.ReadFromJsonAsync<TransactionDto>();
        Assert.Equal("FAILED", txn!.Status);

        // Retry: FAILED → VALIDATED
        resp = await _client.PostAsJsonAsync($"/transactions/{txn.Id}/transition", new TransitionRequest("VALIDATED", "Retrying"));
        txn = await resp.Content.ReadFromJsonAsync<TransactionDto>();
        Assert.Equal("VALIDATED", txn!.Status);
    }

    // === Available Transitions ===

    [Fact]
    public async Task GetAvailableTransitions_ReturnsCorrectOptions()
    {
        var resp = await _client.PostAsJsonAsync("/transactions", new CreateTransactionRequest(100m));
        var txn = await resp.Content.ReadFromJsonAsync<TransactionDto>();

        var transResp = await _client.GetAsync($"/transactions/{txn!.Id}/available-transitions");
        Assert.Equal(HttpStatusCode.OK, transResp.StatusCode);

        var available = await transResp.Content.ReadFromJsonAsync<List<AvailableTransitionDto>>();
        Assert.Single(available!);
        Assert.Equal("VALIDATED", available[0].StatusName);
    }

    // === History ===

    [Fact]
    public async Task GetHistory_ReturnsStatusChanges()
    {
        var resp = await _client.PostAsJsonAsync("/transactions", new CreateTransactionRequest(100m));
        var txn = await resp.Content.ReadFromJsonAsync<TransactionDto>();

        // Make two transitions
        await _client.PostAsJsonAsync($"/transactions/{txn!.Id}/transition", new TransitionRequest("VALIDATED", "Auto-validated"));
        await _client.PostAsJsonAsync($"/transactions/{txn.Id}/transition", new TransitionRequest("PROCESSING"));

        var histResp = await _client.GetAsync($"/transactions/{txn.Id}/history");
        var history = await histResp.Content.ReadFromJsonAsync<List<TransactionHistoryDto>>();

        Assert.Equal(2, history!.Count);
        Assert.Equal("CREATED", history[0].FromStatus);
        Assert.Equal("VALIDATED", history[0].ToStatus);
        Assert.Equal("Auto-validated", history[0].Reason);
        Assert.Equal("VALIDATED", history[1].FromStatus);
        Assert.Equal("PROCESSING", history[1].ToStatus);
    }

    // === Admin — Runtime Workflow Changes ===

    [Fact]
    public async Task Admin_AddStatusAndTransition_WorksAtRuntime()
    {
        // Add new status
        var statusResp = await _client.PostAsJsonAsync("/admin/workflow/statuses",
            new AddStatusRequest("REVIEW", "Manual review required"));
        Assert.Equal(HttpStatusCode.Created, statusResp.StatusCode);

        // Add transition: VALIDATED → REVIEW
        var transResp = await _client.PostAsJsonAsync("/admin/workflow/transitions",
            new AddTransitionRequest("VALIDATED", "REVIEW", "Route to manual review"));
        Assert.Equal(HttpStatusCode.Created, transResp.StatusCode);

        // Verify the new transition is available
        var resp = await _client.PostAsJsonAsync("/transactions", new CreateTransactionRequest(100m));
        var txn = await resp.Content.ReadFromJsonAsync<TransactionDto>();
        await _client.PostAsJsonAsync($"/transactions/{txn!.Id}/transition", new TransitionRequest("VALIDATED"));

        var available = await _client.GetFromJsonAsync<List<AvailableTransitionDto>>(
            $"/transactions/{txn.Id}/available-transitions");

        // Should now have PROCESSING and REVIEW as options
        Assert.Contains(available!, a => a.StatusName == "REVIEW");
        Assert.Contains(available!, a => a.StatusName == "PROCESSING");
    }
}
