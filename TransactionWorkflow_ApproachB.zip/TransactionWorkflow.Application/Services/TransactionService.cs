using TransactionWorkflow.Application.DTOs;
using TransactionWorkflow.Application.Interfaces;
using TransactionWorkflow.Domain.Core;
using TransactionWorkflow.Domain.Interfaces;
using TransactionWorkflow.Domain.Models;

namespace TransactionWorkflow.Application.Services;

// ═══════════════════════════════════════════════════════════════════════
// This service is the THIN ADAPTER between the HTTP world and the
// generic workflow engine. It passes EntityTypes.Transaction to every
// engine call. To support a new entity type (e.g., "order"), you'd
// create an OrderService that passes EntityTypes.Order instead.
// The engine and repository code remain completely unchanged.
// ═══════════════════════════════════════════════════════════════════════

public class TransactionService : ITransactionService
{
    private readonly ITransactionRepository _transactionRepo;
    private readonly IWorkflowEngine _workflowEngine;

    public TransactionService(
        ITransactionRepository transactionRepo,
        IWorkflowEngine workflowEngine)
    {
        _transactionRepo = transactionRepo;
        _workflowEngine = workflowEngine;
    }

    public async Task<DataProcessResult<TransactionDto>> CreateAsync(
        CreateTransactionRequest request, CancellationToken ct = default)
    {
        // Engine resolves initial status for entity type "transaction"
        var initialResult = await _workflowEngine.GetInitialStatusAsync(EntityTypes.Transaction, ct);
        if (!initialResult.IsSuccess)
            return DataProcessResult<TransactionDto>.Fail(initialResult.Message, initialResult.Status);

        var transaction = new Transaction
        {
            ReferenceNumber = $"TXN-{DateTime.UtcNow:yyyyMMdd}-{Guid.NewGuid().ToString("N")[..8].ToUpper()}",
            Amount = request.Amount,
            Currency = request.Currency,
            Description = request.Description,
            StatusId = initialResult.Data!.Id,
            // Note: Do NOT set Status navigation here.
            // The cached entity may be from a previous DbContext scope
            // (IMemoryCache is singleton, DbContext is scoped). Setting
            // the navigation causes Add() to cascade and mark the
            // WorkflowStatus as Added → duplicate INSERT attempt.
            Metadata = request.Metadata ?? new Dictionary<string, object>(),
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow
        };

        var created = await _transactionRepo.CreateAsync(transaction, ct);

        // Reload with Status navigation for DTO mapping
        var refreshed = await _transactionRepo.GetByIdAsync(created.Id, ct);
        return DataProcessResult<TransactionDto>.Ok(MapToDto(refreshed!));
    }

    public async Task<DataProcessResult<TransactionDto>> GetByIdAsync(
        int id, CancellationToken ct = default)
    {
        var transaction = await _transactionRepo.GetByIdAsync(id, ct);
        return transaction is null
            ? DataProcessResult<TransactionDto>.NotFound($"Transaction {id} not found.")
            : DataProcessResult<TransactionDto>.Ok(MapToDto(transaction));
    }

    public async Task<DataProcessResult<TransactionDto>> TransitionAsync(
        int id, TransitionRequest request, CancellationToken ct = default)
    {
        var transaction = await _transactionRepo.GetByIdAsync(id, ct);
        if (transaction is null)
            return DataProcessResult<TransactionDto>.NotFound($"Transaction {id} not found.");

        // Count prior transitions to the same target (for maxRetries rule evaluation)
        var priorHistory = await _transactionRepo.GetHistoryAsync(id, ct);
        var priorTransitionCount = priorHistory.Count(h =>
            h.ToStatus.Equals(request.TargetStatus, StringComparison.OrdinalIgnoreCase));

        // Delegate to generic engine — passes "transaction" as entity type.
        // Note: we pass only the StatusId, NOT the name. The engine resolves
        // the name internally to prevent caller mismatch (ID=1 but Name="COMPLETED").
        var result = await _workflowEngine.TryTransitionAsync(
            entityType: EntityTypes.Transaction,
            currentStatusId: transaction.StatusId,
            targetStatusName: request.TargetStatus,
            reason: request.Reason,
            context: request.Context,
            priorTransitionCount: priorTransitionCount,
            ct: ct);

        if (!result.IsSuccess)
            return DataProcessResult<TransactionDto>.Fail(result.Message, result.Status)
                with { Metadata = result.Metadata };

        var outcome = result.Data!;

        // Record history
        var history = new TransactionHistory
        {
            TransactionId = transaction.Id,
            FromStatus = outcome.FromStatusName,
            ToStatus = outcome.ToStatusName,
            Reason = outcome.Reason,
            Context = outcome.Context,
            Timestamp = outcome.TransitionedAt
        };

        // Apply transition
        transaction.StatusId = outcome.TargetStatusId;
        transaction.UpdatedAt = outcome.TransitionedAt;

        var updateResult = await _transactionRepo.UpdateAsync(transaction, ct);
        if (!updateResult.IsSuccess)
            return DataProcessResult<TransactionDto>.Fail(updateResult.Message, updateResult.Status);

        await _transactionRepo.AddHistoryAsync(history, ct);

        var refreshed = await _transactionRepo.GetByIdAsync(id, ct);
        return DataProcessResult<TransactionDto>.Ok(MapToDto(refreshed!));
    }

    public async Task<DataProcessResult<List<AvailableTransitionDto>>> GetAvailableTransitionsAsync(
        int id, CancellationToken ct = default)
    {
        var transaction = await _transactionRepo.GetByIdAsync(id, ct);
        if (transaction is null)
            return DataProcessResult<List<AvailableTransitionDto>>.NotFound($"Transaction {id} not found.");

        var result = await _workflowEngine.GetAvailableTargetsAsync(
            EntityTypes.Transaction, transaction.StatusId, ct);

        if (!result.IsSuccess)
            return DataProcessResult<List<AvailableTransitionDto>>.Fail(result.Message, result.Status);

        var dtos = result.Data!.Select(t =>
            new AvailableTransitionDto(t.StatusId, t.StatusName, t.Description, t.Rules)).ToList();

        return DataProcessResult<List<AvailableTransitionDto>>.Ok(dtos);
    }

    public async Task<DataProcessResult<List<TransactionHistoryDto>>> GetHistoryAsync(
        int id, CancellationToken ct = default)
    {
        var transaction = await _transactionRepo.GetByIdAsync(id, ct);
        if (transaction is null)
            return DataProcessResult<List<TransactionHistoryDto>>.NotFound($"Transaction {id} not found.");

        var history = await _transactionRepo.GetHistoryAsync(id, ct);
        var dtos = history.Select(h =>
            new TransactionHistoryDto(h.FromStatus, h.ToStatus, h.Reason, h.Context, h.Timestamp)).ToList();

        return DataProcessResult<List<TransactionHistoryDto>>.Ok(dtos);
    }

    private static TransactionDto MapToDto(Transaction t) => new(
        t.Id, t.ReferenceNumber, t.Amount, t.Currency, t.Description,
        t.Status?.Name ?? "Unknown", t.Metadata, t.CreatedAt, t.UpdatedAt);
}
