using TransactionWorkflow.Application.DTOs;
using TransactionWorkflow.Application.Interfaces;
using TransactionWorkflow.Domain.Core;
using TransactionWorkflow.Domain.Interfaces;
using TransactionWorkflow.Domain.Models;

namespace TransactionWorkflow.Application.Services;

public class WorkflowAdminService : IWorkflowAdminService
{
    private readonly IWorkflowRepository _workflowRepo;

    public WorkflowAdminService(IWorkflowRepository workflowRepo)
    {
        _workflowRepo = workflowRepo;
    }

    public async Task<DataProcessResult<WorkflowStatusDto>> AddStatusAsync(
        AddStatusRequest request, CancellationToken ct = default)
    {
        var entityType = request.EntityType.ToLowerInvariant();
        var existing = await _workflowRepo.GetStatusByNameAsync(entityType, request.Name, ct);
        if (existing is not null)
            return DataProcessResult<WorkflowStatusDto>.Fail(
                $"Status '{request.Name}' already exists for entity type '{entityType}'.",
                OperationStatus.Conflict);

        var status = new WorkflowStatus
        {
            EntityType = entityType,
            Name = request.Name.ToUpperInvariant(),
            Description = request.Description,
            IsInitial = request.IsInitial,
            IsFinal = request.IsFinal
        };

        var created = await _workflowRepo.AddStatusAsync(status, ct);
        return DataProcessResult<WorkflowStatusDto>.Ok(MapStatusDto(created));
    }

    public async Task<DataProcessResult<WorkflowTransitionDto>> AddTransitionAsync(
        AddTransitionRequest request, CancellationToken ct = default)
    {
        var entityType = request.EntityType.ToLowerInvariant();

        var fromStatus = await _workflowRepo.GetStatusByNameAsync(entityType, request.FromStatus, ct);
        if (fromStatus is null)
            return DataProcessResult<WorkflowTransitionDto>.NotFound(
                $"Source status '{request.FromStatus}' not found for entity type '{entityType}'.");

        var toStatus = await _workflowRepo.GetStatusByNameAsync(entityType, request.ToStatus, ct);
        if (toStatus is null)
            return DataProcessResult<WorkflowTransitionDto>.NotFound(
                $"Target status '{request.ToStatus}' not found for entity type '{entityType}'.");

        var transition = new WorkflowTransition
        {
            EntityType = entityType,
            FromStatusId = fromStatus.Id,
            ToStatusId = toStatus.Id,
            Description = request.Description,
            Rules = request.Rules ?? new Dictionary<string, object>()
        };

        var created = await _workflowRepo.AddTransitionAsync(transition, ct);
        return DataProcessResult<WorkflowTransitionDto>.Ok(
            new WorkflowTransitionDto(created.Id, entityType, fromStatus.Name, toStatus.Name,
                created.Description, created.Rules));
    }

    public async Task<DataProcessResult<List<WorkflowStatusDto>>> GetStatusesAsync(
        string entityType, CancellationToken ct = default)
    {
        var statuses = await _workflowRepo.GetAllStatusesAsync(entityType.ToLowerInvariant(), ct);
        return DataProcessResult<List<WorkflowStatusDto>>.Ok(
            statuses.Select(MapStatusDto).ToList());
    }

    public async Task<DataProcessResult<List<WorkflowTransitionDto>>> GetTransitionsAsync(
        string entityType, CancellationToken ct = default)
    {
        var transitions = await _workflowRepo.GetAllTransitionsAsync(entityType.ToLowerInvariant(), ct);
        return DataProcessResult<List<WorkflowTransitionDto>>.Ok(
            transitions.Select(t => new WorkflowTransitionDto(
                t.Id, t.EntityType, t.FromStatus.Name, t.ToStatus.Name,
                t.Description, t.Rules)).ToList());
    }

    public async Task<DataProcessResult<List<string>>> GetEntityTypesAsync(CancellationToken ct = default)
    {
        var types = await _workflowRepo.GetAllEntityTypesAsync(ct);
        return DataProcessResult<List<string>>.Ok(types);
    }

    public async Task<DataProcessResult<string>> GetWorkflowVisualizationAsync(
        string entityType, CancellationToken ct = default)
    {
        var et = entityType.ToLowerInvariant();
        var transitions = await _workflowRepo.GetAllTransitionsAsync(et, ct);
        var statuses = await _workflowRepo.GetAllStatusesAsync(et, ct);

        if (!transitions.Any() && !statuses.Any())
            return DataProcessResult<string>.NotFound(
                $"No workflow found for entity type '{et}'.");

        var lines = new List<string> { $"graph TD" };

        foreach (var t in transitions)
        {
            var label = t.Description ?? $"{t.FromStatus.Name} → {t.ToStatus.Name}";
            lines.Add($"    {t.FromStatus.Name} -->|\"{label}\"| {t.ToStatus.Name}");
        }

        foreach (var s in statuses.Where(s => s.IsFinal))
            lines.Add($"    style {s.Name} fill:#22c55e,color:#fff");
        foreach (var s in statuses.Where(s => s.IsInitial))
            lines.Add($"    style {s.Name} fill:#3b82f6,color:#fff");

        return DataProcessResult<string>.Ok(string.Join("\n", lines));
    }

    private static WorkflowStatusDto MapStatusDto(WorkflowStatus s) =>
        new(s.Id, s.EntityType, s.Name, s.Description, s.IsInitial, s.IsFinal);
}
