using TransactionWorkflow.Application.DTOs;
using TransactionWorkflow.Domain.Core;

namespace TransactionWorkflow.Application.Interfaces;

public interface ITransactionService
{
    Task<DataProcessResult<TransactionDto>> CreateAsync(CreateTransactionRequest request, CancellationToken ct = default);
    Task<DataProcessResult<TransactionDto>> GetByIdAsync(int id, CancellationToken ct = default);
    Task<DataProcessResult<TransactionDto>> TransitionAsync(int id, TransitionRequest request, CancellationToken ct = default);
    Task<DataProcessResult<List<AvailableTransitionDto>>> GetAvailableTransitionsAsync(int id, CancellationToken ct = default);
    Task<DataProcessResult<List<TransactionHistoryDto>>> GetHistoryAsync(int id, CancellationToken ct = default);
}

/// <summary>
/// Admin service — all operations require explicit entityType.
/// This is B's differentiator: you can manage workflows for
/// "transaction", "order", "ticket" — all from the same API.
/// </summary>
public interface IWorkflowAdminService
{
    Task<DataProcessResult<WorkflowStatusDto>> AddStatusAsync(AddStatusRequest request, CancellationToken ct = default);
    Task<DataProcessResult<WorkflowTransitionDto>> AddTransitionAsync(AddTransitionRequest request, CancellationToken ct = default);
    Task<DataProcessResult<List<WorkflowStatusDto>>> GetStatusesAsync(string entityType, CancellationToken ct = default);
    Task<DataProcessResult<List<WorkflowTransitionDto>>> GetTransitionsAsync(string entityType, CancellationToken ct = default);
    Task<DataProcessResult<List<string>>> GetEntityTypesAsync(CancellationToken ct = default);
    Task<DataProcessResult<string>> GetWorkflowVisualizationAsync(string entityType, CancellationToken ct = default);
}
