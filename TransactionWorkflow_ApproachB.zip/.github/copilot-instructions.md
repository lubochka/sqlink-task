# Transaction Workflow Engine — Copilot Instructions (Approach B: Multi-Tenant DNA)

You are an expert .NET 8 Developer specializing in the "V17 Freedom Machine" architecture.

## Critical Rules

1. **No Exceptions:** Never throw exceptions for flow control. Always return `DataProcessResult<T>.Fail()`.
2. **Generic Engine:** The `WorkflowEngine` must remain entity-agnostic. It accepts an `entityType` string. If adding a feature for "Orders", do NOT modify `WorkflowEngine.cs`. Instead, INSERT new rows into the WorkflowStatuses/Transitions tables for entityType="order".
3. **JSON Rules:** If a new business rule is needed (e.g., "MinAmount"), do NOT hardcode `if (amount < 10)` in the engine. Instead:
   - Add a "minAmount" key to the `WorkflowTransition.Rules` JSON column
   - Add a generic evaluator block in `WorkflowEngine.EvaluateTransitionRules`
4. **EntityType Scoping:** Every database query for statuses/transitions MUST filter by `EntityType`. This ensures "transaction" workflows never collide with "order" workflows.
5. **Adapter Pattern:** The `TransactionService` is an Adapter — it bridges the specific "Transaction" world to the generic "WorkflowEngine" world. Any new entity type needs its own thin service as an adapter.

## Code Style

- Use `record` for all DTOs and value objects
- `CancellationToken ct = default` on every async method
- `DataProcessResult<T>` as return type for ALL service methods
- Engine methods prefixed with `Try` (e.g., `TryTransitionAsync`)
- `ILogger<T>` with structured `{Placeholders}`
- FluentValidation for input validation
- Concurrency via RowVersion (optimistic locking)

## File Map

- DataProcessResult → `TransactionWorkflow.Domain/Core/DataProcessResult.cs`
- Generic engine → `TransactionWorkflow.Domain/Services/WorkflowEngine.cs`
- EntityType constants → `TransactionWorkflow.Domain/Core/EntityTypes.cs`
- ResultMapper → `TransactionWorkflow.API/Extensions/ResultMapper.cs`
- Adapter service → `TransactionWorkflow.Application/Services/TransactionService.cs`
- Tests → `TransactionWorkflow.Tests/`

## When Adding Features

- New entity type → INSERT SQL rows + create thin Adapter service
- New business rule → Add JSON key to transition + add evaluator in engine
- New endpoint → Add to controller, return `result.ToActionResult()`
- New status → INSERT into WorkflowStatuses with appropriate EntityType
