namespace TransactionWorkflow.Domain.Models;

// ═══════════════════════════════════════════════════════════════════════
// FREEDOM MACHINE CLASSIFICATION:
//
// MACHINE (static, generic — built once, works for all entity types):
//   - The WorkflowEngine that validates transitions
//   - The Repository interfaces
//   - The DataProcessResult pattern
//   - The API controllers and ResultMapper
//
// FREEDOM (dynamic, data-driven — changeable at runtime without code):
//   - WorkflowStatus rows (which statuses exist per entity type)
//   - WorkflowTransition rows (which transitions are allowed)
//   - Transaction.Metadata (client-defined extensible fields)
//   - WorkflowTransition.Rules (configurable business rules)
//   - TransactionHistory.Context (audit snapshot data)
//
// Adding a new entity type (e.g., "order") requires:
//   1. INSERT new WorkflowStatus rows with EntityType = "order"
//   2. INSERT new WorkflowTransition rows linking those statuses
//   3. ZERO code changes, ZERO deployments
// ═══════════════════════════════════════════════════════════════════════

/// <summary>
/// Transaction entity — the primary domain object for this assignment.
/// Metadata dictionary enables schema-free extensibility (V17 DNA-1).
/// </summary>
public class Transaction
{
    public int Id { get; set; }
    public string ReferenceNumber { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    public string Currency { get; set; } = "USD";
    public string Description { get; set; } = string.Empty;

    // FK to current workflow status
    public int StatusId { get; set; }
    public WorkflowStatus Status { get; set; } = null!;

    /// <summary>
    /// Schema-free dynamic metadata (V17 DNA-1: Dynamic Documents).
    /// Clients send any JSON fields; we store them without schema changes.
    /// Examples: {"merchantId":"M-123", "channel":"web", "riskScore":85}
    /// </summary>
    public Dictionary<string, object> Metadata { get; set; } = new();

    // Optimistic concurrency token
    public byte[] RowVersion { get; set; } = null!;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

    public ICollection<TransactionHistory> History { get; set; } = new List<TransactionHistory>();
}

/// <summary>
/// Workflow status — scoped by EntityType.
/// The same database can hold completely different workflow definitions
/// for "transaction", "order", "support-ticket", etc.
/// </summary>
public class WorkflowStatus
{
    public int Id { get; set; }

    /// <summary>
    /// ⭐ B's KEY DIFFERENTIATOR: EntityType scoping.
    /// Each entity type has its own independent set of statuses.
    /// "transaction" might have CREATED→VALIDATED→PROCESSING→COMPLETED,
    /// while "order" could have PENDING→CONFIRMED→SHIPPED→DELIVERED.
    /// </summary>
    public string EntityType { get; set; } = string.Empty;

    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public bool IsInitial { get; set; }
    public bool IsFinal { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public ICollection<WorkflowTransition> OutgoingTransitions { get; set; } = new List<WorkflowTransition>();
    public ICollection<WorkflowTransition> IncomingTransitions { get; set; } = new List<WorkflowTransition>();
}

/// <summary>
/// Allowed transition between two statuses — scoped by EntityType.
/// The Rules dictionary enables configurable business logic per transition
/// without code changes (V17 DNA-1).
/// </summary>
public class WorkflowTransition
{
    public int Id { get; set; }

    /// <summary>EntityType scoping — must match both FromStatus and ToStatus.</summary>
    public string EntityType { get; set; } = string.Empty;

    public int FromStatusId { get; set; }
    public WorkflowStatus FromStatus { get; set; } = null!;
    public int ToStatusId { get; set; }
    public WorkflowStatus ToStatus { get; set; } = null!;
    public string? Description { get; set; }

    /// <summary>
    /// Dynamic transition rules (V17 DNA-1: Dynamic Documents).
    /// Examples: {"maxRetries":3, "requiresApproval":true, "slaMinutes":60}
    /// The engine stores these; consuming code interprets them.
    /// </summary>
    public Dictionary<string, object> Rules { get; set; } = new();

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

/// <summary>
/// Immutable audit record of every status change.
/// Context dictionary captures the snapshot at transition time.
/// </summary>
public class TransactionHistory
{
    public int Id { get; set; }
    public int TransactionId { get; set; }
    public Transaction Transaction { get; set; } = null!;
    public string FromStatus { get; set; } = string.Empty;
    public string ToStatus { get; set; } = string.Empty;
    public string? Reason { get; set; }

    /// <summary>Transition-time context snapshot.</summary>
    public Dictionary<string, object> Context { get; set; } = new();

    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
}
