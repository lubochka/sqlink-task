using Microsoft.AspNetCore.Mvc;
using TransactionWorkflow.API.Extensions;
using TransactionWorkflow.Application.DTOs;
using TransactionWorkflow.Application.Interfaces;

namespace TransactionWorkflow.API.Controllers;

[ApiController]
[Route("transactions")]
[Produces("application/json")]
public class TransactionsController : ControllerBase
{
    private readonly ITransactionService _service;
    public TransactionsController(ITransactionService service) => _service = service;

    /// <summary>Create a new transaction (starts at initial workflow status)</summary>
    [HttpPost]
    [ProducesResponseType(typeof(TransactionDto), StatusCodes.Status201Created)]
    public async Task<IActionResult> Create(
        [FromBody] CreateTransactionRequest request, CancellationToken ct)
    {
        var result = await _service.CreateAsync(request, ct);
        return result.ToCreatedResult(nameof(GetById), new { id = result.Data?.Id });
    }

    /// <summary>Get a transaction by ID</summary>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(TransactionDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetById(int id, CancellationToken ct)
        => (await _service.GetByIdAsync(id, ct)).ToActionResult();

    /// <summary>Transition a transaction to a new status</summary>
    [HttpPost("{id:int}/transition")]
    [ProducesResponseType(typeof(TransactionDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Transition(
        int id, [FromBody] TransitionRequest request, CancellationToken ct)
        => (await _service.TransitionAsync(id, request, ct)).ToActionResult();

    /// <summary>Get available transitions for a transaction</summary>
    [HttpGet("{id:int}/available-transitions")]
    [ProducesResponseType(typeof(List<AvailableTransitionDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetAvailableTransitions(int id, CancellationToken ct)
        => (await _service.GetAvailableTransitionsAsync(id, ct)).ToActionResult();

    /// <summary>Get status change history for a transaction</summary>
    [HttpGet("{id:int}/history")]
    [ProducesResponseType(typeof(List<TransactionHistoryDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetHistory(int id, CancellationToken ct)
        => (await _service.GetHistoryAsync(id, ct)).ToActionResult();
}
