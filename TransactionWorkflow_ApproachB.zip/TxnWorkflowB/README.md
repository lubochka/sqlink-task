# Transaction Workflow Engine — Approach B (Multi-Tenant DNA)

A **platform-level** workflow engine that manages statuses and transitions for **any entity type** — transactions, orders, support tickets — all from one deployment. New workflows are added via database rows, not code.

## Quick Start

```bash
./start.sh
# ✅ Systems GO! API running at http://localhost:5000/swagger
```

> Uses Docker health checks to ensure SQL Server is ready before the API starts.

### Run Tests

```bash
dotnet test
```

---

## What Makes B Different?

The core differentiator is **EntityType scoping**. Every status and transition belongs to an entity type (e.g., `"transaction"`, `"order"`). The engine itself doesn't know what a "transaction" is — it just validates transitions for whatever entity type you pass.

**To add "Orders" workflow — zero code changes:**

```bash
# Add statuses
curl -X POST http://localhost:5000/admin/workflow/statuses \
  -H "Content-Type: application/json" \
  -d '{"entityType":"order","name":"PENDING","isInitial":true}'

curl -X POST http://localhost:5000/admin/workflow/statuses \
  -H "Content-Type: application/json" \
  -d '{"entityType":"order","name":"SHIPPED"}'

# Add transition
curl -X POST http://localhost:5000/admin/workflow/transitions \
  -H "Content-Type: application/json" \
  -d '{"entityType":"order","fromStatus":"PENDING","toStatus":"SHIPPED"}'
```

---

## API Endpoints

### Transactions

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/transactions` | Create a new transaction |
| `GET` | `/transactions/{id}` | Get transaction by ID |
| `POST` | `/transactions/{id}/transition` | Transition to a new status |
| `GET` | `/transactions/{id}/available-transitions` | List valid next statuses |
| `GET` | `/transactions/{id}/history` | Get status change history |

### Admin — Workflow Management (Entity-Type Scoped)

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/admin/workflow/entity-types` | List all configured entity types |
| `GET` | `/admin/workflow/{entityType}/statuses` | Statuses for entity type |
| `POST` | `/admin/workflow/statuses` | Add status (entityType in body) |
| `GET` | `/admin/workflow/{entityType}/transitions` | Transitions for entity type |
| `POST` | `/admin/workflow/transitions` | Add transition (entityType in body) |
| `GET` | `/admin/workflow/{entityType}/visualize` | **NEW** Mermaid.js diagram |

---

## Architecture — Freedom Machine Philosophy

```
MACHINE (static, generic — built once):
  ├── WorkflowEngine       — validates transitions for ANY entity type
  ├── DataProcessResult<T>  — no exceptions for business outcomes
  ├── ResultMapper          — RFC 7807 ProblemDetails error format
  └── CachedWorkflowRepository

FREEDOM (dynamic, data-driven — changeable at runtime):
  ├── WorkflowStatus rows   — which statuses exist per entity type
  ├── WorkflowTransition rows — which transitions are allowed + JSON rules
  ├── Transaction.Metadata   — client-defined extensible fields
  └── TransitionHistory.Context — audit snapshot data
```

### Key Design Decisions

1. **EntityType discriminator** — single DB serves multiple workflows
2. **DataProcessResult pattern** — no exceptions for expected outcomes
3. **RFC 7807 ProblemDetails** — standardized error responses
4. **JSON rules on transitions** — `{"maxRetries":3}` enforced by engine
5. **FluentValidation** — input sanitization with EntityType validation
6. **Docker health checks** — reliable one-command startup

### Security

- Secrets in `.env` file (git-ignored)
- FluentValidation on all request DTOs
- Mass assignment protection via DTOs
- Optimistic concurrency with RowVersion → 409 Conflict (via DataProcessResult, not exceptions)

---

## Time Spent

~6 hours total (multi-tenant architecture adds complexity but zero future code changes).
