using TransactionWorkflow.Domain.Core;

namespace TransactionWorkflow.Tests;

public class DataProcessResultTests
{
    [Fact]
    public void Ok_IsSuccess_True() =>
        Assert.True(DataProcessResult<string>.Ok("hello").IsSuccess);

    [Fact]
    public void Fail_IsSuccess_False()
    {
        var result = DataProcessResult<string>.Fail("bad");
        Assert.False(result.IsSuccess);
        Assert.Equal(OperationStatus.ValidationError, result.Status);
    }

    [Fact]
    public void NotFound_Status_Correct() =>
        Assert.Equal(OperationStatus.NotFound, DataProcessResult<int>.NotFound().Status);

    [Fact]
    public void Conflict_Status_Correct() =>
        Assert.Equal(OperationStatus.Conflict, DataProcessResult<object>.Conflict("x").Status);

    [Fact]
    public void WithMeta_ChainsMetadata()
    {
        var result = DataProcessResult<string>.Fail("x")
            .WithMeta("allowed", new[] { "A" })
            .WithMeta("current", "B");
        Assert.Equal(2, result.Metadata!.Count);
    }
}
