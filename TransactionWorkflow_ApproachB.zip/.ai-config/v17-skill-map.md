# V17 Skill Map — Approach B (Multi-Tenant DNA)

Maps XIIGen V17 skills to actual implementations in this codebase.
Approach B uses the **maximum** V17 skill set — full Freedom Machine with EntityType scoping.

## Skill Mapping

### ✅ Active Skills (Full Implementation)

| V17 Skill | File(s) | How It's Applied |
|-----------|---------|------------------|
| **Skill 01: Core Interfaces** | `Domain/Core/DataProcessResult.cs`, `Domain/Core/EntityTypes.cs` | DataProcessResult is the universal return type. OperationStatus enum maps to HTTP codes. Metadata dictionary carries structured error context. |
| **Skill 02: Object Processor** | `Domain/Services/WorkflowEngine.cs` → `EvaluateTransitionRules()` | JSON rules (e.g., `{"maxRetries": 3}`) stored in `WorkflowTransition.Rules` are parsed and evaluated generically. New rule types added without interface changes. |
| **Skill 05: Database Fabric** | `Infrastructure/Data/AppDbContext.cs`, `Infrastructure/Repositories/` | EF Core with JSON value converters for Dictionary columns. EntityType-scoped queries filter statuses/transitions per entity. |
| **Skill 08: Flow Definition** | `Domain/Models/WorkflowStatus.cs`, `WorkflowTransition.cs` | Workflow is a DAG defined in DB rows, scoped by EntityType. Mermaid visualization via `/admin/workflow/visualize`. |
| **Skill 09: Flow Orchestrator** | `Domain/Services/WorkflowEngine.cs` | Generic state machine. Accepts `(entityType, statusId, target)` → validates transition → evaluates rules → returns outcome. Entity-agnostic. |
| **Skill 15: API Gateway** | `API/Extensions/ResultMapper.cs`, `API/Controllers/` | ResultMapper translates DataProcessResult to ProblemDetails. Controllers are thin — call service, return `result.ToActionResult()`. |
| **Skill 29: Testing** | `Tests/WorkflowEngineTests.cs`, `Tests/DataProcessResultTests.cs`, `Tests/IntegrationTests/` | Unit tests verify engine isolation. Multi-entity isolation tests ensure "transaction" workflows don't leak into "order" workflows. |
| **Skill 45: Design Patterns** | Multiple files | **Decorator:** CachedWorkflowRepository wraps WorkflowRepository. **Adapter:** TransactionService bridges specific→generic. **Strategy:** Rule evaluation is extensible via JSON keys. |

### ❌ Not Used (out of scope)

| V17 Skill | Why |
|-----------|-----|
| Skill 06/07: AI Providers/Dispatcher | Not applicable to workflow assignment |
| Skill 10: Figma Parser | Not applicable |
| Skill 22: Logger Service | Standard ILogger<T> suffices |
| Skill 27: K8s Deployment | Docker Compose only for this scope |

## Pattern Alignment

| V17 Pattern | Approach B Implementation |
|------------|--------------------------|
| `DataProcessResult<T>` | Exact match — `Domain/Core/DataProcessResult.cs` |
| `ParseObjectAlternative` | JSON rule parsing in `EvaluateTransitionRules()` |
| `BuildSearchFilter` (empty-field skipping) | Implicit via EF Core LINQ (nullable conditions) |
| `Dictionary<string,object>` metadata | `WorkflowTransition.Rules`, `Transaction.Metadata`, `DataProcessResult.Metadata` |
| `MicroserviceBase` (19 components) | Adapted — DI registration in `Program.cs` instead |
| EntityType scoping | Full — every query filters by `EntityType` column |

## How to Extend (V17 Way)

### Adding "Orders" Entity Type
```sql
INSERT INTO WorkflowStatuses (EntityType, Name, IsInitial) VALUES ('order', 'PENDING', 1);
INSERT INTO WorkflowStatuses (EntityType, Name) VALUES ('order', 'SHIPPED');
INSERT INTO WorkflowStatuses (EntityType, Name, IsFinal) VALUES ('order', 'DELIVERED', 1);
-- Add transitions between them
```
Then create `OrderService.cs` as a thin Adapter (like TransactionService).

### Adding "requiresApproval" Rule
```sql
UPDATE WorkflowTransitions SET Rules = '{"requiresApproval": true, "approverRole": "manager"}'
WHERE FromStatus='PROCESSING' AND ToStatus='COMPLETED';
```
Then add evaluation block in `WorkflowEngine.EvaluateTransitionRules()`.
