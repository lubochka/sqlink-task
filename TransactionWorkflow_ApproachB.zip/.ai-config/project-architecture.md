# Approach B: The Freedom Machine (Multi-Tenant DNA)

## Philosophy

A **platform-level** workflow engine that manages statuses and transitions for **any entity type** —
transactions, orders, support tickets — all from one deployment. New workflows are added via
database rows, not code. This is the full V17 "God Mode" approach.

### Guiding Principle

> **Freedom Machine:** If business users might want to change it, it must be dynamic.
> The engine doesn't know what a "Transaction" is — it only knows entity types, statuses, and rules.

## Architecture Pattern

```
API Layer (Controllers + ResultMapper)    ← Skill 15: Gateway
    ↓ Returns DataProcessResult<T>
Application Layer (TransactionService)    ← Adapter: bridges specific → generic
    ↓ Calls with entityType
Domain Layer (WorkflowEngine + DataProcessResult)  ← Skills 01, 02, 09: Core Machine
    ↓ Persisted by
Infrastructure Layer (EF Core + Caching)  ← Skill 05: Database Fabric
```

## Error Handling Strategy

Approach B uses **DataProcessResult<T>** for ALL business outcomes:

- `DataProcessResult.Fail(msg, ValidationError)` → ResultMapper → 400 ProblemDetails
- `DataProcessResult.NotFound(msg)` → ResultMapper → 404 ProblemDetails
- `DataProcessResult.Conflict(msg)` → ResultMapper → 409 ProblemDetails
- Unexpected exceptions → GlobalExceptionMiddleware → 500 ProblemDetails

**No exceptions are thrown for business logic. Ever.**

## Multi-Tenant Design

The key differentiator is **EntityType scoping**:

```sql
-- Same tables serve ALL entity types
SELECT * FROM WorkflowStatuses WHERE EntityType = 'transaction' AND IsInitial = 1
SELECT * FROM WorkflowStatuses WHERE EntityType = 'order' AND IsInitial = 1
-- Zero code changes to add "order" workflow
```

```csharp
// Engine signature — entityType is the scope discriminator
Task<DataProcessResult<TransitionOutcome>> TryTransitionAsync(
    string entityType,       // ← THE KEY DIFFERENTIATOR
    int currentStatusId,
    string targetStatusName,
    int priorTransitionCount = 0, ...);
```

## V17 Skill Set Mapping (Maximum)

| V17 Skill | Used? | Implementation |
|-----------|-------|----------------|
| **Skill 01** (Core Interfaces) | ✅ Full | `DataProcessResult<T>` — universal return type |
| **Skill 02** (Object Processor) | ✅ | JSON rule evaluation in `WorkflowEngine.EvaluateTransitionRules()` |
| **Skill 05** (Database Fabric) | ✅ | EF Core + JSON value converters for Rules column |
| **Skill 08** (Flow Definition) | ✅ | DB-driven statuses/transitions scoped by EntityType |
| **Skill 09** (Flow Orchestrator) | ✅ Full | Generic WorkflowEngine — entity-agnostic |
| **Skill 15** (API Gateway) | ✅ | ResultMapper (DataProcessResult → ProblemDetails) |
| **Skill 29** (Testing) | ✅ | xUnit + Moq + multi-entity isolation tests |
| **Skill 45** (Design Patterns) | ✅ | Decorator (caching), Adapter (TransactionService), Factory (result mapping) |

## Key Rules for AI Agents

1. **Never throw exceptions** for business logic — always return `DataProcessResult<T>`
2. **WorkflowEngine must remain entity-agnostic** — it accepts `entityType` string
3. **To add a new entity type** (e.g., "orders") — INSERT rows, zero code changes
4. **JSON Rules** are actually evaluated by the engine (e.g., `maxRetries`)
5. **TransactionService** is an Adapter — bridges "I am a Transaction" → "entity type 'transaction'"
6. **CancellationToken** on all async methods

## Machine vs Freedom

| Layer | Classification | Why |
|-------|---------------|-----|
| WorkflowEngine | MACHINE | Generic, entity-agnostic orchestrator |
| DataProcessResult | MACHINE | Universal return type |
| ResultMapper | MACHINE | DataProcessResult → HTTP translation |
| EvaluateTransitionRules() | MACHINE | Static rule evaluation logic |
| WorkflowStatus rows | FREEDOM | Any entity type, changeable at runtime |
| WorkflowTransition rows | FREEDOM | Rules stored as JSON, changeable at runtime |
| EntityType values | FREEDOM | New entity types via data, not code |
| TransactionService | ADAPTER | Thin bridge between specific entity and generic engine |
