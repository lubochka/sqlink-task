# Coding Standards — Approach B (Multi-Tenant DNA)

## Core Pattern: DataProcessResult<T>

```csharp
// ALWAYS return DataProcessResult — never throw
public async Task<DataProcessResult<TransactionDto>> TransitionAsync(
    int id, TransitionRequest request, CancellationToken ct = default)
{
    var transaction = await _transactionRepo.GetByIdAsync(id, ct);
    if (transaction is null)
        return DataProcessResult<TransactionDto>.NotFound($"Transaction {id} not found.");

    var result = await _workflowEngine.TryTransitionAsync(
        entityType: EntityTypes.Transaction,  // scoped to entity type
        currentStatusId: transaction.StatusId,
        targetStatusName: request.TargetStatus,
        priorTransitionCount: priorCount,
        ct: ct);

    if (!result.IsSuccess)
        return DataProcessResult<TransactionDto>.Fail(result.Message, result.Status)
            with { Metadata = result.Metadata };

    // ... apply transition, return Ok
    return DataProcessResult<TransactionDto>.Ok(MapToDto(updated));
}
```

## ResultMapper: DataProcessResult → HTTP

```csharp
// Controller uses ResultMapper extension method
[HttpPost("{id}/transition")]
public async Task<IActionResult> Transition(int id, TransitionRequest request)
{
    var result = await _service.TransitionAsync(id, request);
    return result.ToActionResult();  // ← Single mapping point
}

// ResultMapper maps OperationStatus to HTTP status codes:
// Success → 200, NotFound → 404, ValidationError → 400,
// Conflict → 409, ConfigurationError → 500
```

## Engine Signature (Entity-Agnostic)

```csharp
// The engine NEVER knows about "transactions" directly
public interface IWorkflowEngine
{
    Task<DataProcessResult<TransitionOutcome>> TryTransitionAsync(
        string entityType,           // "transaction", "order", "ticket"
        int currentStatusId,
        string targetStatusName,
        string? reason = null,
        Dictionary<string, object>? context = null,
        int priorTransitionCount = 0,
        CancellationToken ct = default);
}
```

## JSON Rule Evaluation

```csharp
// Rules are stored in DB as JSON: {"maxRetries": 3}
// Engine evaluates them generically:
private static DataProcessResult<TransitionOutcome> EvaluateTransitionRules(
    Dictionary<string, object> rules,
    int priorTransitionCount,
    string entityType, string fromStatus, string toStatus)
{
    if (rules.TryGetValue("maxRetries", out var maxRetriesObj))
    {
        var maxRetries = Convert.ToInt32(maxRetriesObj);
        if (priorTransitionCount >= maxRetries)
            return DataProcessResult<TransitionOutcome>.Fail(
                $"[{entityType}] Max retries ({maxRetries}) exceeded.")
                .WithMeta("rule", "maxRetries");
    }
    return DataProcessResult<TransitionOutcome>.Ok(default!);
}
```

## EntityType Constants

```csharp
public static class EntityTypes
{
    public const string Transaction = "transaction";
    // Future: Order = "order", Ticket = "ticket"
}
```

## Adding a New Entity Type (Zero Code Changes)

```sql
-- Step 1: Add statuses
INSERT INTO WorkflowStatuses (EntityType, Name, IsInitial) VALUES ('order', 'PENDING', 1);
INSERT INTO WorkflowStatuses (EntityType, Name, IsInitial) VALUES ('order', 'SHIPPED', 0);

-- Step 2: Add transition
INSERT INTO WorkflowTransitions (EntityType, FromStatusId, ToStatusId)
    SELECT 'order', s1.Id, s2.Id
    FROM WorkflowStatuses s1, WorkflowStatuses s2
    WHERE s1.Name='PENDING' AND s2.Name='SHIPPED' AND s1.EntityType='order';

-- Step 3: Create thin OrderService (C#) as Adapter to WorkflowEngine — done.
```

## Naming Conventions

- Async methods: `{Verb}Async` with `CancellationToken ct = default`
- Engine methods: `Try{Verb}Async` (indicates no-throw semantics)
- Results: `DataProcessResult<T>` everywhere
- DTOs: `record` types
- Tests: `{Class}Tests.{Method}_{Scenario}_{Expected}`
