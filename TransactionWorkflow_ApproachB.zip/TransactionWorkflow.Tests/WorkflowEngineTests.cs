using Moq;
using TransactionWorkflow.Domain.Core;
using TransactionWorkflow.Domain.Interfaces;
using TransactionWorkflow.Domain.Models;
using TransactionWorkflow.Domain.Services;

namespace TransactionWorkflow.Tests;

public class WorkflowEngineTests
{
    private readonly Mock<IWorkflowRepository> _mockRepo;
    private readonly WorkflowEngine _engine;

    public WorkflowEngineTests()
    {
        _mockRepo = new Mock<IWorkflowRepository>();
        _engine = new WorkflowEngine(_mockRepo.Object);
    }

    private static WorkflowStatus MakeStatus(int id, string name, string entityType = "transaction") =>
        new() { Id = id, Name = name, EntityType = entityType, IsInitial = id == 1 };

    private static WorkflowTransition MakeTransition(
        int fromId, WorkflowStatus toStatus, string entityType = "transaction",
        Dictionary<string, object>? rules = null) =>
        new() { FromStatusId = fromId, ToStatusId = toStatus.Id, ToStatus = toStatus,
                EntityType = entityType, Rules = rules ?? new() };

    private void SetupStatusLookup(WorkflowStatus status) =>
        _mockRepo.Setup(r => r.GetStatusByIdAsync(status.Id, It.IsAny<CancellationToken>()))
            .ReturnsAsync(status);

    // ===== Valid Transitions =====

    [Fact]
    public async Task TryTransition_ValidPath_ReturnsOkWithOutcome()
    {
        var created = MakeStatus(1, "CREATED");
        var validated = MakeStatus(2, "VALIDATED");
        SetupStatusLookup(created);
        _mockRepo.Setup(r => r.GetAllowedTransitionsAsync("transaction", 1, It.IsAny<CancellationToken>()))
            .ReturnsAsync([MakeTransition(1, validated)]);

        var result = await _engine.TryTransitionAsync(
            "transaction", 1, "VALIDATED", "Auto-validated");

        Assert.True(result.IsSuccess);
        Assert.Equal("CREATED", result.Data!.FromStatusName);
        Assert.Equal("VALIDATED", result.Data.ToStatusName);
        Assert.Equal("Auto-validated", result.Data.Reason);
    }

    [Fact]
    public async Task TryTransition_CaseInsensitive_Works()
    {
        var created = MakeStatus(1, "CREATED");
        var validated = MakeStatus(2, "VALIDATED");
        SetupStatusLookup(created);
        _mockRepo.Setup(r => r.GetAllowedTransitionsAsync("transaction", 1, It.IsAny<CancellationToken>()))
            .ReturnsAsync([MakeTransition(1, validated)]);

        var result = await _engine.TryTransitionAsync("transaction", 1, "validated");

        Assert.True(result.IsSuccess);
        Assert.Equal("VALIDATED", result.Data!.ToStatusName);
    }

    [Fact]
    public async Task TryTransition_BackwardRetry_WorksWhenAllowed()
    {
        var failed = MakeStatus(5, "FAILED");
        var validated = MakeStatus(2, "VALIDATED");
        SetupStatusLookup(failed);
        _mockRepo.Setup(r => r.GetAllowedTransitionsAsync("transaction", 5, It.IsAny<CancellationToken>()))
            .ReturnsAsync([MakeTransition(5, validated, rules: new() { ["maxRetries"] = 3 })]);

        // priorTransitionCount=0, so maxRetries=3 is not exceeded
        var result = await _engine.TryTransitionAsync(
            "transaction", 5, "VALIDATED", "Retrying", priorTransitionCount: 0);

        Assert.True(result.IsSuccess);
        Assert.Equal("FAILED", result.Data!.FromStatusName);
        Assert.Equal("VALIDATED", result.Data.ToStatusName);
        Assert.Equal(3, Convert.ToInt32(result.Data.TransitionRules["maxRetries"]));
    }

    [Fact]
    public async Task TryTransition_WithContext_PreservesMetadata()
    {
        var created = MakeStatus(1, "CREATED");
        var validated = MakeStatus(2, "VALIDATED");
        SetupStatusLookup(created);
        _mockRepo.Setup(r => r.GetAllowedTransitionsAsync("transaction", 1, It.IsAny<CancellationToken>()))
            .ReturnsAsync([MakeTransition(1, validated)]);

        var ctx = new Dictionary<string, object> { ["validatedBy"] = "system" };
        var result = await _engine.TryTransitionAsync("transaction", 1, "VALIDATED", context: ctx);

        Assert.True(result.IsSuccess);
        Assert.Equal("system", result.Data!.Context["validatedBy"]);
    }

    // ===== Invalid Transitions — Returns Failure, Not Exception =====

    [Fact]
    public async Task TryTransition_InvalidPath_ReturnsFail_WithAllowedList()
    {
        var created = MakeStatus(1, "CREATED");
        var validated = MakeStatus(2, "VALIDATED");
        SetupStatusLookup(created);
        _mockRepo.Setup(r => r.GetAllowedTransitionsAsync("transaction", 1, It.IsAny<CancellationToken>()))
            .ReturnsAsync([MakeTransition(1, validated)]);

        var result = await _engine.TryTransitionAsync("transaction", 1, "COMPLETED");

        Assert.False(result.IsSuccess);
        Assert.Equal(OperationStatus.ValidationError, result.Status);
        Assert.Contains("VALIDATED", result.Message);
        Assert.NotNull(result.Metadata);
        var allowed = result.Metadata!["allowedTransitions"] as string[];
        Assert.Contains("VALIDATED", allowed!);
        Assert.Equal("transaction", result.Metadata["entityType"]);
    }

    [Fact]
    public async Task TryTransition_FinalStatus_NoTransitions_ReturnsFail()
    {
        var completed = MakeStatus(4, "COMPLETED");
        SetupStatusLookup(completed);
        _mockRepo.Setup(r => r.GetAllowedTransitionsAsync("transaction", 4, It.IsAny<CancellationToken>()))
            .ReturnsAsync([]);

        var result = await _engine.TryTransitionAsync("transaction", 4, "PROCESSING");

        Assert.False(result.IsSuccess);
        var allowed = result.Metadata!["allowedTransitions"] as string[];
        Assert.Empty(allowed!);
    }

    [Fact]
    public async Task TryTransition_UnknownStatusId_ReturnsNotFound()
    {
        _mockRepo.Setup(r => r.GetStatusByIdAsync(999, It.IsAny<CancellationToken>()))
            .ReturnsAsync((WorkflowStatus?)null);

        var result = await _engine.TryTransitionAsync("transaction", 999, "VALIDATED");

        Assert.False(result.IsSuccess);
        Assert.Equal(OperationStatus.NotFound, result.Status);
        Assert.Contains("999", result.Message);
    }

    // ===== RULE EVALUATION — maxRetries actually enforced =====

    [Fact]
    public async Task TryTransition_MaxRetries_UnderLimit_Allows()
    {
        var failed = MakeStatus(5, "FAILED");
        var validated = MakeStatus(2, "VALIDATED");
        SetupStatusLookup(failed);
        _mockRepo.Setup(r => r.GetAllowedTransitionsAsync("transaction", 5, It.IsAny<CancellationToken>()))
            .ReturnsAsync([MakeTransition(5, validated, rules: new() { ["maxRetries"] = 3 })]);

        // 2 prior attempts, max is 3 → allowed
        var result = await _engine.TryTransitionAsync(
            "transaction", 5, "VALIDATED", priorTransitionCount: 2);

        Assert.True(result.IsSuccess);
    }

    [Fact]
    public async Task TryTransition_MaxRetries_AtLimit_Rejects()
    {
        var failed = MakeStatus(5, "FAILED");
        var validated = MakeStatus(2, "VALIDATED");
        SetupStatusLookup(failed);
        _mockRepo.Setup(r => r.GetAllowedTransitionsAsync("transaction", 5, It.IsAny<CancellationToken>()))
            .ReturnsAsync([MakeTransition(5, validated, rules: new() { ["maxRetries"] = 3 })]);

        // 3 prior attempts = at limit → rejected
        var result = await _engine.TryTransitionAsync(
            "transaction", 5, "VALIDATED", priorTransitionCount: 3);

        Assert.False(result.IsSuccess);
        Assert.Equal(OperationStatus.ValidationError, result.Status);
        Assert.Contains("maximum retries", result.Message);
        Assert.Equal("maxRetries", result.Metadata!["rule"]);
        Assert.Equal(3, result.Metadata["maxRetries"]);
        Assert.Equal(3, result.Metadata["priorAttempts"]);
    }

    [Fact]
    public async Task TryTransition_MaxRetries_OverLimit_Rejects()
    {
        var failed = MakeStatus(5, "FAILED");
        var validated = MakeStatus(2, "VALIDATED");
        SetupStatusLookup(failed);
        _mockRepo.Setup(r => r.GetAllowedTransitionsAsync("transaction", 5, It.IsAny<CancellationToken>()))
            .ReturnsAsync([MakeTransition(5, validated, rules: new() { ["maxRetries"] = 3 })]);

        // 5 prior attempts, max is 3 → definitely rejected
        var result = await _engine.TryTransitionAsync(
            "transaction", 5, "VALIDATED", priorTransitionCount: 5);

        Assert.False(result.IsSuccess);
        Assert.Contains("exceeded", result.Message);
    }

    [Fact]
    public async Task TryTransition_NoRules_IgnoresCount()
    {
        var created = MakeStatus(1, "CREATED");
        var validated = MakeStatus(2, "VALIDATED");
        SetupStatusLookup(created);
        _mockRepo.Setup(r => r.GetAllowedTransitionsAsync("transaction", 1, It.IsAny<CancellationToken>()))
            .ReturnsAsync([MakeTransition(1, validated)]); // no rules

        // High count doesn't matter — no maxRetries rule defined
        var result = await _engine.TryTransitionAsync(
            "transaction", 1, "VALIDATED", priorTransitionCount: 100);

        Assert.True(result.IsSuccess);
    }

    // ===== Available Targets =====

    [Fact]
    public async Task GetAvailableTargets_ReturnsAllWithRules()
    {
        var completed = MakeStatus(4, "COMPLETED");
        var failed = MakeStatus(5, "FAILED");
        _mockRepo.Setup(r => r.GetAllowedTransitionsAsync("transaction", 3, It.IsAny<CancellationToken>()))
            .ReturnsAsync([
                MakeTransition(3, completed),
                MakeTransition(3, failed, rules: new() { ["autoRetry"] = true })
            ]);

        var result = await _engine.GetAvailableTargetsAsync("transaction", 3);

        Assert.True(result.IsSuccess);
        Assert.Equal(2, result.Data!.Count);
        Assert.Contains(result.Data, t => t.StatusName == "FAILED" && t.Rules.ContainsKey("autoRetry"));
    }

    // ===== Initial Status =====

    [Fact]
    public async Task GetInitialStatus_Configured_ReturnsOk()
    {
        _mockRepo.Setup(r => r.GetInitialStatusAsync("transaction", It.IsAny<CancellationToken>()))
            .ReturnsAsync(MakeStatus(1, "CREATED"));

        var result = await _engine.GetInitialStatusAsync("transaction");
        Assert.True(result.IsSuccess);
        Assert.Equal("CREATED", result.Data!.Name);
    }

    [Fact]
    public async Task GetInitialStatus_NotConfigured_ReturnsConfigError()
    {
        _mockRepo.Setup(r => r.GetInitialStatusAsync("unknown", It.IsAny<CancellationToken>()))
            .ReturnsAsync((WorkflowStatus?)null);

        var result = await _engine.GetInitialStatusAsync("unknown");
        Assert.False(result.IsSuccess);
        Assert.Equal(OperationStatus.ConfigurationError, result.Status);
    }

    // ===== ⭐ MULTI-ENTITY ISOLATION — B's Key Differentiator =====

    [Fact]
    public async Task TryTransition_DifferentEntityTypes_AreIsolated()
    {
        var txnCreated = MakeStatus(1, "CREATED", "transaction");
        var txnValidated = MakeStatus(2, "VALIDATED", "transaction");
        SetupStatusLookup(txnCreated);
        _mockRepo.Setup(r => r.GetAllowedTransitionsAsync("transaction", 1, It.IsAny<CancellationToken>()))
            .ReturnsAsync([MakeTransition(1, txnValidated, "transaction")]);

        var orderPending = MakeStatus(11, "PENDING", "order");
        var orderConfirmed = MakeStatus(12, "CONFIRMED", "order");
        _mockRepo.Setup(r => r.GetStatusByIdAsync(11, It.IsAny<CancellationToken>()))
            .ReturnsAsync(orderPending);
        _mockRepo.Setup(r => r.GetAllowedTransitionsAsync("order", 11, It.IsAny<CancellationToken>()))
            .ReturnsAsync([MakeTransition(11, orderConfirmed, "order")]);

        var txnResult = await _engine.TryTransitionAsync("transaction", 1, "VALIDATED");
        Assert.True(txnResult.IsSuccess);

        var orderResult = await _engine.TryTransitionAsync("order", 11, "CONFIRMED");
        Assert.True(orderResult.IsSuccess);
        Assert.Equal("CONFIRMED", orderResult.Data!.ToStatusName);
    }

    [Fact]
    public async Task TryTransition_CrossEntityTransition_Fails()
    {
        var txnCreated = MakeStatus(1, "CREATED", "transaction");
        var txnValidated = MakeStatus(2, "VALIDATED", "transaction");
        SetupStatusLookup(txnCreated);
        _mockRepo.Setup(r => r.GetAllowedTransitionsAsync("transaction", 1, It.IsAny<CancellationToken>()))
            .ReturnsAsync([MakeTransition(1, txnValidated, "transaction")]);

        var result = await _engine.TryTransitionAsync("transaction", 1, "CONFIRMED");
        Assert.False(result.IsSuccess);
    }
}
