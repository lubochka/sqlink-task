using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using TransactionWorkflow.Application.DTOs;
using TransactionWorkflow.Infrastructure.Data;

namespace TransactionWorkflow.Tests;

public class TransactionApiIntegrationTests : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly HttpClient _client;
    private static readonly JsonSerializerOptions Json = new() { PropertyNameCaseInsensitive = true };

    public TransactionApiIntegrationTests(WebApplicationFactory<Program> factory)
    {
        _client = factory.WithWebHostBuilder(builder =>
        {
            builder.ConfigureServices(services =>
            {
                var desc = services.SingleOrDefault(d =>
                    d.ServiceType == typeof(DbContextOptions<AppDbContext>));
                if (desc != null) services.Remove(desc);

                services.AddDbContext<AppDbContext>(opts =>
                    opts.UseInMemoryDatabase("TestDb_" + Guid.NewGuid()));

                var sp = services.BuildServiceProvider();
                using var scope = sp.CreateScope();
                var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
                db.Database.EnsureCreated();
            });
        }).CreateClient();
    }

    // ===== Create Transaction =====

    [Fact]
    public async Task Create_ReturnsCreatedWithInitialStatus()
    {
        var resp = await _client.PostAsJsonAsync("/transactions",
            new CreateTransactionRequest(250.50m, "USD", "Test",
                new Dictionary<string, object> { ["merchantId"] = "M-789" }));

        Assert.Equal(HttpStatusCode.Created, resp.StatusCode);
        var txn = await resp.Content.ReadFromJsonAsync<TransactionDto>(Json);
        Assert.Equal("CREATED", txn!.Status);
        Assert.Equal(250.50m, txn.Amount);
        Assert.StartsWith("TXN-", txn.ReferenceNumber);
    }

    // ===== Get Transaction =====

    [Fact]
    public async Task Get_NonExistent_Returns404()
    {
        var resp = await _client.GetAsync("/transactions/99999");
        Assert.Equal(HttpStatusCode.NotFound, resp.StatusCode);
    }

    // ===== Valid Transition =====

    [Fact]
    public async Task Transition_ValidPath_ReturnsUpdatedStatus()
    {
        var resp = await _client.PostAsJsonAsync("/transactions", new CreateTransactionRequest(100m));
        var txn = await resp.Content.ReadFromJsonAsync<TransactionDto>(Json);

        resp = await _client.PostAsJsonAsync($"/transactions/{txn!.Id}/transition",
            new TransitionRequest("VALIDATED", "Checks passed"));

        Assert.Equal(HttpStatusCode.OK, resp.StatusCode);
        txn = await resp.Content.ReadFromJsonAsync<TransactionDto>(Json);
        Assert.Equal("VALIDATED", txn!.Status);
    }

    // ===== Invalid Transition =====

    [Fact]
    public async Task Transition_InvalidPath_Returns400WithAllowedList()
    {
        var resp = await _client.PostAsJsonAsync("/transactions", new CreateTransactionRequest(100m));
        var txn = await resp.Content.ReadFromJsonAsync<TransactionDto>(Json);

        resp = await _client.PostAsJsonAsync($"/transactions/{txn!.Id}/transition",
            new TransitionRequest("COMPLETED"));

        Assert.Equal(HttpStatusCode.BadRequest, resp.StatusCode);
        var body = await resp.Content.ReadAsStringAsync();
        Assert.Contains("VALIDATED", body);
        Assert.Contains("allowedTransitions", body);
        Assert.Contains("transaction", body); // entityType in error response
    }

    // ===== Full Happy Path =====

    [Fact]
    public async Task FullWorkflow_HappyPath()
    {
        var resp = await _client.PostAsJsonAsync("/transactions", new CreateTransactionRequest(500m));
        var txn = await resp.Content.ReadFromJsonAsync<TransactionDto>(Json);

        foreach (var status in new[] { "VALIDATED", "PROCESSING", "COMPLETED" })
        {
            resp = await _client.PostAsJsonAsync($"/transactions/{txn!.Id}/transition",
                new TransitionRequest(status));
            txn = await resp.Content.ReadFromJsonAsync<TransactionDto>(Json);
        }

        Assert.Equal("COMPLETED", txn!.Status);
    }

    // ===== Failure + Retry Path =====

    [Fact]
    public async Task FullWorkflow_FailureRetry()
    {
        var resp = await _client.PostAsJsonAsync("/transactions", new CreateTransactionRequest(200m));
        var txn = await resp.Content.ReadFromJsonAsync<TransactionDto>(Json);

        foreach (var s in new[] { "VALIDATED", "PROCESSING", "FAILED" })
        {
            resp = await _client.PostAsJsonAsync($"/transactions/{txn!.Id}/transition",
                new TransitionRequest(s, s == "FAILED" ? "Gateway timeout" : null));
            txn = await resp.Content.ReadFromJsonAsync<TransactionDto>(Json);
        }
        Assert.Equal("FAILED", txn!.Status);

        // Backward: FAILED → VALIDATED
        resp = await _client.PostAsJsonAsync($"/transactions/{txn.Id}/transition",
            new TransitionRequest("VALIDATED", "Retrying"));
        txn = await resp.Content.ReadFromJsonAsync<TransactionDto>(Json);
        Assert.Equal("VALIDATED", txn!.Status);
    }

    // ===== Available Transitions =====

    [Fact]
    public async Task AvailableTransitions_ReturnsCorrectOptions()
    {
        var resp = await _client.PostAsJsonAsync("/transactions", new CreateTransactionRequest(100m));
        var txn = await resp.Content.ReadFromJsonAsync<TransactionDto>(Json);

        resp = await _client.GetAsync($"/transactions/{txn!.Id}/available-transitions");
        var available = await resp.Content.ReadFromJsonAsync<List<AvailableTransitionDto>>(Json);

        Assert.Single(available!);
        Assert.Equal("VALIDATED", available[0].StatusName);
    }

    // ===== History =====

    [Fact]
    public async Task History_RecordsAllTransitions()
    {
        var resp = await _client.PostAsJsonAsync("/transactions", new CreateTransactionRequest(100m));
        var txn = await resp.Content.ReadFromJsonAsync<TransactionDto>(Json);

        await _client.PostAsJsonAsync($"/transactions/{txn!.Id}/transition",
            new TransitionRequest("VALIDATED", "Auto"));
        await _client.PostAsJsonAsync($"/transactions/{txn.Id}/transition",
            new TransitionRequest("PROCESSING"));

        resp = await _client.GetAsync($"/transactions/{txn.Id}/history");
        var history = await resp.Content.ReadFromJsonAsync<List<TransactionHistoryDto>>(Json);

        Assert.Equal(2, history!.Count);
        Assert.Equal("CREATED", history[0].FromStatus);
        Assert.Equal("VALIDATED", history[0].ToStatus);
    }

    // ===== ⭐ MULTI-ENTITY TYPE — B's Key Differentiator =====

    [Fact]
    public async Task Admin_GetEntityTypes_ReturnsConfiguredTypes()
    {
        var resp = await _client.GetAsync("/admin/workflow/entity-types");
        Assert.Equal(HttpStatusCode.OK, resp.StatusCode);
        var types = await resp.Content.ReadFromJsonAsync<List<string>>(Json);
        Assert.Contains("transaction", types!);
    }

    [Fact]
    public async Task Admin_GetStatusesByEntityType_ReturnsScoped()
    {
        var resp = await _client.GetAsync("/admin/workflow/transaction/statuses");
        var statuses = await resp.Content.ReadFromJsonAsync<List<WorkflowStatusDto>>(Json);
        Assert.Equal(5, statuses!.Count);
        Assert.All(statuses, s => Assert.Equal("transaction", s.EntityType));
    }

    [Fact]
    public async Task Admin_AddNewEntityType_CreatesSeparateWorkflow()
    {
        // Create a brand-new "order" workflow at runtime — zero code changes!
        await _client.PostAsJsonAsync("/admin/workflow/statuses",
            new AddStatusRequest("order", "PENDING", "Awaiting confirmation", IsInitial: true));
        await _client.PostAsJsonAsync("/admin/workflow/statuses",
            new AddStatusRequest("order", "CONFIRMED", "Order confirmed"));
        await _client.PostAsJsonAsync("/admin/workflow/statuses",
            new AddStatusRequest("order", "SHIPPED", "Order shipped", IsFinal: true));

        await _client.PostAsJsonAsync("/admin/workflow/transitions",
            new AddTransitionRequest("order", "PENDING", "CONFIRMED", "Confirm order"));
        await _client.PostAsJsonAsync("/admin/workflow/transitions",
            new AddTransitionRequest("order", "CONFIRMED", "SHIPPED", "Ship order",
                new Dictionary<string, object> { ["requiresTracking"] = true }));

        // Verify: entity-types now includes "order"
        var typesResp = await _client.GetAsync("/admin/workflow/entity-types");
        var types = await typesResp.Content.ReadFromJsonAsync<List<string>>(Json);
        Assert.Contains("order", types!);

        // Verify: order statuses are isolated from transaction statuses
        var orderStatusesResp = await _client.GetAsync("/admin/workflow/order/statuses");
        var orderStatuses = await orderStatusesResp.Content.ReadFromJsonAsync<List<WorkflowStatusDto>>(Json);
        Assert.Equal(3, orderStatuses!.Count);
        Assert.Contains(orderStatuses, s => s.Name == "PENDING");
        Assert.DoesNotContain(orderStatuses, s => s.Name == "CREATED"); // transaction status, not order

        // Verify: transaction workflow is completely unaffected
        var txnStatusesResp = await _client.GetAsync("/admin/workflow/transaction/statuses");
        var txnStatuses = await txnStatusesResp.Content.ReadFromJsonAsync<List<WorkflowStatusDto>>(Json);
        Assert.Equal(5, txnStatuses!.Count);
    }
}
