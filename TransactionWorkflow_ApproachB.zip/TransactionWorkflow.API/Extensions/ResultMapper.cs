using Microsoft.AspNetCore.Mvc;
using TransactionWorkflow.Domain.Core;

namespace TransactionWorkflow.API.Extensions;

/// <summary>
/// MACHINE — Single mapping point from DataProcessResult to HTTP responses.
/// Uses RFC 7807 ProblemDetails for structured, standardized error responses.
/// </summary>
public static class ResultMapper
{
    public static IActionResult ToActionResult<T>(this DataProcessResult<T> result)
    {
        if (result.IsSuccess)
            return new OkObjectResult(result.Data);

        return BuildProblemResult(result);
    }

    public static IActionResult ToCreatedResult<T>(
        this DataProcessResult<T> result, string routeName, object routeValues)
    {
        if (result.IsSuccess)
            return new CreatedAtActionResult(routeName, null, routeValues, result.Data);
        return BuildProblemResult(result);
    }

    private static IActionResult BuildProblemResult<T>(DataProcessResult<T> result)
    {
        var statusCode = result.Status switch
        {
            OperationStatus.NotFound => 404,
            OperationStatus.ValidationError => 400,
            OperationStatus.Conflict => 409,
            OperationStatus.ConfigurationError => 500,
            _ => 500
        };

        var problem = new ProblemDetails
        {
            Type = $"https://httpstatuses.io/{statusCode}",
            Title = result.Status.ToString(),
            Status = statusCode,
            Detail = result.Message
        };

        // Attach metadata (e.g., allowed transitions) as ProblemDetails extensions
        if (result.Metadata is not null)
        {
            foreach (var (key, value) in result.Metadata)
                problem.Extensions[key] = value;
        }

        return new ObjectResult(problem) { StatusCode = statusCode };
    }
}
