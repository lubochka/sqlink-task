using Microsoft.AspNetCore.Mvc;
using TransactionWorkflow.API.Extensions;
using TransactionWorkflow.Application.DTOs;
using TransactionWorkflow.Application.Interfaces;

namespace TransactionWorkflow.API.Controllers;

/// <summary>
/// Workflow administration — scoped by entity type.
/// 
/// B's key differentiator: This API manages workflows for ANY entity type.
/// GET /admin/workflow/entity-types returns all configured types.
/// GET /admin/workflow/{entityType}/statuses returns statuses for that type.
///
/// To add a completely new workflow for "order" entities:
///   POST /admin/workflow/statuses  {"entityType":"order","name":"PENDING","isInitial":true}
///   POST /admin/workflow/statuses  {"entityType":"order","name":"CONFIRMED"}
///   POST /admin/workflow/transitions {"entityType":"order","fromStatus":"PENDING","toStatus":"CONFIRMED"}
/// No code changes. No deployment. No developer needed.
/// </summary>
[ApiController]
[Route("admin/workflow")]
[Produces("application/json")]
public class AdminController : ControllerBase
{
    private readonly IWorkflowAdminService _adminService;
    public AdminController(IWorkflowAdminService adminService) => _adminService = adminService;

    /// <summary>List all configured entity types (e.g., "transaction", "order")</summary>
    [HttpGet("entity-types")]
    [ProducesResponseType(typeof(List<string>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetEntityTypes(CancellationToken ct)
        => (await _adminService.GetEntityTypesAsync(ct)).ToActionResult();

    /// <summary>Get all workflow statuses for an entity type</summary>
    [HttpGet("{entityType}/statuses")]
    [ProducesResponseType(typeof(List<WorkflowStatusDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetStatuses(string entityType, CancellationToken ct)
        => (await _adminService.GetStatusesAsync(entityType, ct)).ToActionResult();

    /// <summary>Add a new workflow status (requires entityType in body)</summary>
    [HttpPost("statuses")]
    [ProducesResponseType(typeof(WorkflowStatusDto), StatusCodes.Status201Created)]
    public async Task<IActionResult> AddStatus(
        [FromBody] AddStatusRequest request, CancellationToken ct)
    {
        var result = await _adminService.AddStatusAsync(request, ct);
        return result.IsSuccess
            ? Created($"/admin/workflow/{request.EntityType}/statuses", result.Data)
            : result.ToActionResult();
    }

    /// <summary>Get all workflow transitions for an entity type</summary>
    [HttpGet("{entityType}/transitions")]
    [ProducesResponseType(typeof(List<WorkflowTransitionDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetTransitions(string entityType, CancellationToken ct)
        => (await _adminService.GetTransitionsAsync(entityType, ct)).ToActionResult();

    /// <summary>Add a new workflow transition with optional rules (requires entityType in body)</summary>
    [HttpPost("transitions")]
    [ProducesResponseType(typeof(WorkflowTransitionDto), StatusCodes.Status201Created)]
    public async Task<IActionResult> AddTransition(
        [FromBody] AddTransitionRequest request, CancellationToken ct)
    {
        var result = await _adminService.AddTransitionAsync(request, ct);
        return result.IsSuccess
            ? Created($"/admin/workflow/{request.EntityType}/transitions", result.Data)
            : result.ToActionResult();
    }

    /// <summary>Get workflow as Mermaid.js diagram for a given entity type</summary>
    [HttpGet("{entityType}/visualize")]
    [Produces("text/plain")]
    [ProducesResponseType(typeof(string), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Visualize(string entityType, CancellationToken ct)
    {
        var result = await _adminService.GetWorkflowVisualizationAsync(entityType, ct);
        return result.IsSuccess
            ? Content(result.Data!, "text/plain")
            : result.ToActionResult();
    }
}
