# CLAUDE.md — Transaction Workflow Engine (Approach B: Multi-Tenant DNA)

A platform-level workflow engine that manages statuses and transitions for ANY entity type
(transactions, orders, tickets) from a single deployment. New workflows are added via database
rows, not code. Full V17 "Freedom Machine" implementation.

## Read First
- `.ai-config/project-architecture.md` — Multi-tenant philosophy and Machine vs Freedom
- `.ai-config/coding-standards.md` — DataProcessResult pattern, ResultMapper, engine signature
- `.ai-config/v17-skill-map.md` — Maps V17 skills to actual files
- `TransactionWorkflow.Domain/Core/DataProcessResult.cs` — Universal return type
- `TransactionWorkflow.Domain/Services/WorkflowEngine.cs` — The generic engine

## Rules
1. ALL service methods return `DataProcessResult<T>` — never throw exceptions
2. ALL async methods take `CancellationToken ct = default`
3. WorkflowEngine is entity-agnostic — always accepts `entityType` parameter
4. ResultMapper maps DataProcessResult → RFC 7807 ProblemDetails
5. GlobalExceptionMiddleware catches only unexpected failures (safety net)
6. JSON Rules in WorkflowTransition are actually evaluated by the engine
7. New entity types require ZERO code changes (SQL inserts + thin adapter service)
8. EntityType scoping prevents cross-entity workflow collisions

## Tech Stack
.NET 8, EF Core 8, SQL Server (Docker), xUnit, Moq, FluentValidation

## Quick Reference
| What | Where |
|------|-------|
| DataProcessResult | `Domain/Core/DataProcessResult.cs` |
| EntityType constants | `Domain/Core/EntityTypes.cs` |
| Generic engine | `Domain/Services/WorkflowEngine.cs` |
| Engine interface | `Domain/Interfaces/IWorkflowEngine.cs` |
| Adapter service | `Application/Services/TransactionService.cs` |
| ResultMapper | `API/Extensions/ResultMapper.cs` |
| Exception safety net | `API/Middleware/GlobalExceptionMiddleware.cs` |
| Controllers | `API/Controllers/` |
| Caching decorator | `Infrastructure/Caching/CachedWorkflowRepository.cs` |
| Tests | `Tests/` |

## V17 Alignment
This is the most V17-aligned approach. It implements:
- Skill 01 (DataProcessResult), Skill 02 (JSON rule evaluation),
- Skill 05 (DB Fabric with JSON converters), Skill 08/09 (Flow Definition/Orchestrator),
- Skill 15 (API Gateway via ResultMapper), Skill 29 (Testing), Skill 45 (Design Patterns)
