# Transaction Workflow Engine — Approach B (Multi-Tenant DNA)

A **platform-level** workflow engine that manages statuses and transitions for **any entity type** — transactions, orders, support tickets — all from one deployment. New workflows are added via database rows, not code.

> **Philosophy:** "Freedom Machine" — the engine doesn't know what a "Transaction" is. It handles any entity type via `EntityType` scoping.

---

## 🗺️ Document Map & Project Structure

```text
TransactionWorkflow/
├── .ai-config/                              # 🧠 AI Agent Context
│   ├── project-architecture.md              # Multi-tenant philosophy
│   ├── coding-standards.md                  # DataProcessResult patterns
│   └── v17-skill-map.md                     # V17 skill → file mapping
├── .github/copilot-instructions.md          # GitHub Copilot rules
├── CLAUDE.md                                # Claude Code instructions
├── TransactionWorkflow.Domain/              # 🟡 THE MACHINE (Generic)
│   ├── Core/
│   │   ├── DataProcessResult.cs             # [Skill 01] Universal return type
│   │   └── EntityTypes.cs                   # [Skill 01] "transaction", "order"
│   ├── Models/                              # WorkflowStatus (has EntityType column)
│   ├── Interfaces/
│   │   └── IWorkflowEngine.cs              # [Skill 09] Generic: TryTransition(entityType,...)
│   └── Services/
│       └── WorkflowEngine.cs                # [Skill 09] Entity-agnostic orchestrator
│                                            # [Skill 02] EvaluateTransitionRules (JSON)
├── TransactionWorkflow.Application/         # 🟠 ADAPTER LAYER
│   └── Services/
│       └── TransactionService.cs            # Bridges "Transaction" → WorkflowEngine
├── TransactionWorkflow.Infrastructure/      # 🔵 PERSISTENCE [Skill 05]
│   ├── Data/AppDbContext.cs                 # EF Core + JSON value converters
│   ├── Repositories/                        # EntityType-scoped queries
│   └── Caching/CachedWorkflowRepository.cs  # [Skill 45] Decorator pattern
├── TransactionWorkflow.API/                 # 🟣 GATEWAY [Skill 15]
│   ├── Controllers/                         # Transactions + Admin
│   ├── Extensions/ResultMapper.cs           # DataProcessResult → ProblemDetails
│   └── Middleware/GlobalExceptionMiddleware.cs  # Safety net for unexpected errors
├── TransactionWorkflow.Tests/               # 🟢 TESTING [Skill 29]
├── docker-compose.yml
└── start.sh
```

---

## 🚀 Quick Start

```bash
./start.sh
# ✅ API at http://localhost:5000/swagger
```

### Run Tests
```bash
dotnet test
```

---

## 🌟 What Makes B Different?

The core differentiator is **EntityType scoping**. Every status and transition belongs to an entity type.

**To add "Orders" workflow — zero code changes:**

```bash
curl -X POST http://localhost:5000/admin/workflow/statuses \
  -H "Content-Type: application/json" \
  -d '{"entityType":"order","name":"PENDING","isInitial":true}'

curl -X POST http://localhost:5000/admin/workflow/statuses \
  -H "Content-Type: application/json" \
  -d '{"entityType":"order","name":"SHIPPED"}'

curl -X POST http://localhost:5000/admin/workflow/transitions \
  -H "Content-Type: application/json" \
  -d '{"entityType":"order","fromStatus":"PENDING","toStatus":"SHIPPED"}'
```

---

## 📡 API Endpoints

### Transactions

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/transactions` | Create a new transaction |
| `GET` | `/transactions/{id}` | Get transaction by ID |
| `POST` | `/transactions/{id}/transition` | Transition to a new status |
| `GET` | `/transactions/{id}/available-transitions` | List valid next statuses |
| `GET` | `/transactions/{id}/history` | Get status change history |

### Admin

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/admin/workflow/statuses` | List all statuses |
| `POST` | `/admin/workflow/statuses` | Add status (with entityType) |
| `GET` | `/admin/workflow/transitions` | List all transitions |
| `POST` | `/admin/workflow/transitions` | Add transition (with entityType + optional JSON rules) |
| `GET` | `/admin/workflow/visualize` | Mermaid.js workflow diagram |

### Seeded Workflow (entityType: "transaction")
```
CREATED → VALIDATED → PROCESSING → COMPLETED
                               ↘ FAILED → VALIDATED (retry, maxRetries: 3)
```

---

## 🛠️ V17 Skill Integration (Maximum)

| V17 Skill | Implementation | Key File |
|-----------|----------------|----------|
| **Skill 01** (Core Interfaces) | DataProcessResult + OperationStatus + Metadata | `Domain/Core/DataProcessResult.cs` |
| **Skill 02** (Object Processor) | JSON rule evaluation (maxRetries) | `Domain/Services/WorkflowEngine.cs` |
| **Skill 05** (Database Fabric) | EF Core + JSON converters | `Infrastructure/Data/AppDbContext.cs` |
| **Skill 08** (Flow Definition) | EntityType-scoped DB rows + Mermaid viz | `Domain/Models/` |
| **Skill 09** (Flow Orchestrator) | Generic entity-agnostic engine | `Domain/Services/WorkflowEngine.cs` |
| **Skill 15** (API Gateway) | ResultMapper → ProblemDetails (RFC 7807) | `API/Extensions/ResultMapper.cs` |
| **Skill 29** (Testing) | Multi-entity isolation tests | `Tests/` |
| **Skill 45** (Design Patterns) | Decorator, Adapter, Strategy | Multiple files |

---

## 🧠 AI Agent Configuration

| Agent | Config File |
|-------|-------------|
| GitHub Copilot | `.github/copilot-instructions.md` |
| Claude Code | `CLAUDE.md` |
| General | `.ai-config/project-architecture.md` |

**Key Rules:**
1. Never throw exceptions — use `DataProcessResult<T>`
2. Keep WorkflowEngine entity-agnostic
3. Prefer SQL data changes over C# code changes
