using Microsoft.Extensions.Caching.Memory;
using TransactionWorkflow.Domain.Interfaces;
using TransactionWorkflow.Domain.Models;

namespace TransactionWorkflow.Infrastructure.Caching;

// ═══════════════════════════════════════════════════════════════════════
// MACHINE — Decorator pattern (V17 DNA-8 Cache Pattern).
// Cache keys include entityType for per-workflow isolation.
// Admin writes invalidate only the affected entity type's cache.
// ═══════════════════════════════════════════════════════════════════════

public class CachedWorkflowRepository : IWorkflowRepository
{
    private readonly IWorkflowRepository _inner;
    private readonly IMemoryCache _cache;
    private static readonly TimeSpan CacheTtl = TimeSpan.FromMinutes(30);

    public CachedWorkflowRepository(IWorkflowRepository inner, IMemoryCache cache)
    {
        _inner = inner;
        _cache = cache;
    }

    public Task<WorkflowStatus?> GetStatusByIdAsync(int statusId, CancellationToken ct = default)
        => _inner.GetStatusByIdAsync(statusId, ct);

    public Task<WorkflowStatus?> GetStatusByNameAsync(
        string entityType, string name, CancellationToken ct = default)
        => _inner.GetStatusByNameAsync(entityType, name, ct);

    public async Task<WorkflowStatus?> GetInitialStatusAsync(
        string entityType, CancellationToken ct = default)
        => await _cache.GetOrCreateAsync($"wf:{entityType}:initial", async e =>
        {
            e.AbsoluteExpirationRelativeToNow = CacheTtl;
            return await _inner.GetInitialStatusAsync(entityType, ct);
        });

    public async Task<List<WorkflowTransition>> GetAllowedTransitionsAsync(
        string entityType, int fromStatusId, CancellationToken ct = default)
        => await _cache.GetOrCreateAsync($"wf:{entityType}:trans:{fromStatusId}", async e =>
        {
            e.AbsoluteExpirationRelativeToNow = CacheTtl;
            return await _inner.GetAllowedTransitionsAsync(entityType, fromStatusId, ct);
        }) ?? [];

    public async Task<List<WorkflowStatus>> GetAllStatusesAsync(
        string entityType, CancellationToken ct = default)
        => await _cache.GetOrCreateAsync($"wf:{entityType}:statuses", async e =>
        {
            e.AbsoluteExpirationRelativeToNow = CacheTtl;
            return await _inner.GetAllStatusesAsync(entityType, ct);
        }) ?? [];

    public async Task<List<WorkflowTransition>> GetAllTransitionsAsync(
        string entityType, CancellationToken ct = default)
        => await _cache.GetOrCreateAsync($"wf:{entityType}:transitions", async e =>
        {
            e.AbsoluteExpirationRelativeToNow = CacheTtl;
            return await _inner.GetAllTransitionsAsync(entityType, ct);
        }) ?? [];

    public async Task<WorkflowStatus> AddStatusAsync(WorkflowStatus status, CancellationToken ct = default)
    {
        var result = await _inner.AddStatusAsync(status, ct);
        InvalidateEntityType(status.EntityType);
        return result;
    }

    public async Task<WorkflowTransition> AddTransitionAsync(
        WorkflowTransition transition, CancellationToken ct = default)
    {
        var result = await _inner.AddTransitionAsync(transition, ct);
        InvalidateEntityType(transition.EntityType);
        return result;
    }

    public Task<List<string>> GetAllEntityTypesAsync(CancellationToken ct = default)
        => _inner.GetAllEntityTypesAsync(ct);

    /// <summary>
    /// Invalidate cache only for the specific entity type that changed.
    /// Other entity types' caches remain warm.
    /// </summary>
    private void InvalidateEntityType(string entityType)
    {
        _cache.Remove($"wf:{entityType}:initial");
        _cache.Remove($"wf:{entityType}:statuses");
        _cache.Remove($"wf:{entityType}:transitions");
        // Note: per-status transition caches will expire via TTL
    }
}
