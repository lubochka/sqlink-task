using Microsoft.EntityFrameworkCore;
using TransactionWorkflow.Domain.Interfaces;
using TransactionWorkflow.Domain.Models;
using TransactionWorkflow.Infrastructure.Data;

namespace TransactionWorkflow.Infrastructure.Repositories;

// ═══════════════════════════════════════════════════════════════════════
// MACHINE — Every query is scoped by entityType.
//
// This means the same SQL Server database can hold:
//   - "transaction" workflow: CREATED→VALIDATED→PROCESSING→COMPLETED
//   - "order" workflow: PENDING→CONFIRMED→SHIPPED→DELIVERED
//   - "ticket" workflow: OPEN→IN_PROGRESS→RESOLVED→CLOSED
//
// All isolated by the EntityType column. Zero code changes needed.
// ═══════════════════════════════════════════════════════════════════════

public class WorkflowRepository : IWorkflowRepository
{
    private readonly AppDbContext _db;
    public WorkflowRepository(AppDbContext db) => _db = db;

    public async Task<WorkflowStatus?> GetStatusByIdAsync(int statusId, CancellationToken ct = default)
        => await _db.WorkflowStatuses.AsNoTracking().FirstOrDefaultAsync(s => s.Id == statusId, ct);

    public async Task<WorkflowStatus?> GetStatusByNameAsync(
        string entityType, string name, CancellationToken ct = default)
        => await _db.WorkflowStatuses.AsNoTracking().FirstOrDefaultAsync(
            s => s.EntityType == entityType && s.Name == name.ToUpperInvariant(), ct);

    public async Task<WorkflowStatus?> GetInitialStatusAsync(
        string entityType, CancellationToken ct = default)
        => await _db.WorkflowStatuses.AsNoTracking().FirstOrDefaultAsync(
            s => s.EntityType == entityType && s.IsInitial, ct);

    public async Task<List<WorkflowTransition>> GetAllowedTransitionsAsync(
        string entityType, int fromStatusId, CancellationToken ct = default)
        => await _db.WorkflowTransitions
            .Include(t => t.ToStatus)
            .AsNoTracking()
            .Where(t => t.EntityType == entityType && t.FromStatusId == fromStatusId)
            .ToListAsync(ct);

    public async Task<List<WorkflowStatus>> GetAllStatusesAsync(
        string entityType, CancellationToken ct = default)
        => await _db.WorkflowStatuses
            .AsNoTracking()
            .Where(s => s.EntityType == entityType)
            .OrderBy(s => s.Id)
            .ToListAsync(ct);

    public async Task<List<WorkflowTransition>> GetAllTransitionsAsync(
        string entityType, CancellationToken ct = default)
        => await _db.WorkflowTransitions
            .Include(t => t.FromStatus)
            .Include(t => t.ToStatus)
            .AsNoTracking()
            .Where(t => t.EntityType == entityType)
            .OrderBy(t => t.Id)
            .ToListAsync(ct);

    public async Task<WorkflowStatus> AddStatusAsync(
        WorkflowStatus status, CancellationToken ct = default)
    {
        _db.WorkflowStatuses.Add(status);
        await _db.SaveChangesAsync(ct);
        return status;
    }

    public async Task<WorkflowTransition> AddTransitionAsync(
        WorkflowTransition transition, CancellationToken ct = default)
    {
        _db.WorkflowTransitions.Add(transition);
        await _db.SaveChangesAsync(ct);
        await _db.Entry(transition).Reference(t => t.FromStatus).LoadAsync(ct);
        await _db.Entry(transition).Reference(t => t.ToStatus).LoadAsync(ct);
        return transition;
    }

    public async Task<List<string>> GetAllEntityTypesAsync(CancellationToken ct = default)
        => await _db.WorkflowStatuses
            .AsNoTracking()
            .Select(s => s.EntityType)
            .Distinct()
            .OrderBy(e => e)
            .ToListAsync(ct);
}
