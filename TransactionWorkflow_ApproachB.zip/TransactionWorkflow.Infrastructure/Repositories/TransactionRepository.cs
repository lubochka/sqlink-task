using Microsoft.EntityFrameworkCore;
using TransactionWorkflow.Domain.Core;
using TransactionWorkflow.Domain.Interfaces;
using TransactionWorkflow.Domain.Models;
using TransactionWorkflow.Infrastructure.Data;

namespace TransactionWorkflow.Infrastructure.Repositories;

public class TransactionRepository : ITransactionRepository
{
    private readonly AppDbContext _db;
    public TransactionRepository(AppDbContext db) => _db = db;

    public async Task<Transaction?> GetByIdAsync(int id, CancellationToken ct = default)
        => await _db.Transactions.Include(t => t.Status).FirstOrDefaultAsync(t => t.Id == id, ct);

    public async Task<Transaction> CreateAsync(Transaction transaction, CancellationToken ct = default)
    {
        _db.Transactions.Add(transaction);
        await _db.SaveChangesAsync(ct);
        return transaction;
    }

    public async Task<DataProcessResult<Transaction>> UpdateAsync(
        Transaction transaction, CancellationToken ct = default)
    {
        try
        {
            _db.Transactions.Update(transaction);
            await _db.SaveChangesAsync(ct);
            return DataProcessResult<Transaction>.Ok(transaction);
        }
        catch (DbUpdateConcurrencyException)
        {
            return DataProcessResult<Transaction>.Conflict(
                $"Transaction {transaction.Id} was modified by another request. Please retry.");
        }
    }

    public async Task<List<TransactionHistory>> GetHistoryAsync(
        int transactionId, CancellationToken ct = default)
        => await _db.TransactionHistory
            .Where(h => h.TransactionId == transactionId)
            .OrderBy(h => h.Timestamp)
            .ToListAsync(ct);

    public async Task AddHistoryAsync(TransactionHistory history, CancellationToken ct = default)
    {
        _db.TransactionHistory.Add(history);
        await _db.SaveChangesAsync(ct);
    }
}
