namespace TransactionWorkflow.Domain.Core;

// ═══════════════════════════════════════════════════════════════════════
// FREEDOM LAYER — Entity types are data, not code structure.
//
// The entire workflow engine is entity-type agnostic. It receives an
// entityType string and looks up that type's statuses and transitions
// from the database. Adding "order" or "support-ticket" workflows
// requires ZERO code changes — just new DB rows.
//
// These constants exist only as conveniences for the current
// application. The engine itself works with any string value.
// ═══════════════════════════════════════════════════════════════════════

public static class EntityTypes
{
    /// <summary>Financial transactions — the primary use case for this assignment.</summary>
    public const string Transaction = "transaction";

    // Future entity types — add here + seed workflow rules in DB:
    // public const string Order = "order";
    // public const string SupportTicket = "support-ticket";
    // public const string Invoice = "invoice";
}
