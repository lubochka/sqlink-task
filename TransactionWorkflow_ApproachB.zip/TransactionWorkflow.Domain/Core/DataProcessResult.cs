namespace TransactionWorkflow.Domain.Core;

// ═══════════════════════════════════════════════════════════════════════
// MACHINE LAYER — Static, generic, never changes per entity type.
// Inspired by XIIGen V17 Skill 01: DataProcessResult<T> pattern.
//
// RULE: Services never throw exceptions for expected business outcomes.
//       They return DataProcessResult with a status code and metadata.
//       Controllers map OperationStatus → HTTP codes in one place.
// ═══════════════════════════════════════════════════════════════════════

public enum OperationStatus
{
    Success,
    NotFound,
    ValidationError,
    Conflict,
    ConfigurationError
}

public record DataProcessResult<T>
{
    public OperationStatus Status { get; init; } = OperationStatus.Success;
    public T? Data { get; init; }
    public string Message { get; init; } = string.Empty;
    public Dictionary<string, object>? Metadata { get; init; }

    public bool IsSuccess => Status == OperationStatus.Success;

    public static DataProcessResult<T> Ok(T data, string message = "")
        => new() { Status = OperationStatus.Success, Data = data, Message = message };

    public static DataProcessResult<T> Fail(string message, OperationStatus status = OperationStatus.ValidationError)
        => new() { Status = status, Message = message };

    public static DataProcessResult<T> NotFound(string message = "Not found")
        => new() { Status = OperationStatus.NotFound, Message = message };

    public static DataProcessResult<T> Conflict(string message)
        => new() { Status = OperationStatus.Conflict, Message = message };

    /// <summary>
    /// Chain metadata onto a result — used for structured error responses.
    /// E.g., invalid transition → attach allowed transitions list.
    /// </summary>
    public DataProcessResult<T> WithMeta(string key, object value)
    {
        var meta = Metadata != null
            ? new Dictionary<string, object>(Metadata)
            : new Dictionary<string, object>();
        meta[key] = value;
        return this with { Metadata = meta };
    }
}
