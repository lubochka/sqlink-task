using TransactionWorkflow.Domain.Core;
using TransactionWorkflow.Domain.Interfaces;
using TransactionWorkflow.Domain.Models;

namespace TransactionWorkflow.Domain.Services;

// ═══════════════════════════════════════════════════════════════════════
// MACHINE — The single source of truth for all workflow transition logic.
//
// KEY DESIGN DECISION (from review):
//   The engine accepts currentStatusId only — NOT currentStatusName.
//   It resolves the name internally from the repository. This prevents
//   the caller from accidentally passing ID=1 (CREATED) with
//   Name="COMPLETED", which would produce confusing error messages.
//
// RULE EVALUATION:
//   Transition Rules (stored as JSON in the DB) are not just metadata —
//   the engine actually evaluates them. Currently supported:
//     - maxRetries: int — rejects transition when priorTransitionCount >= value
//   New rule types can be added without changing the interface.
// ═══════════════════════════════════════════════════════════════════════

public class WorkflowEngine : IWorkflowEngine
{
    private readonly IWorkflowRepository _workflowRepo;

    public WorkflowEngine(IWorkflowRepository workflowRepo)
    {
        _workflowRepo = workflowRepo;
    }

    public async Task<DataProcessResult<TransitionOutcome>> TryTransitionAsync(
        string entityType,
        int currentStatusId,
        string targetStatusName,
        string? reason = null,
        Dictionary<string, object>? context = null,
        int priorTransitionCount = 0,
        CancellationToken ct = default)
    {
        // Resolve current status name from ID — single source of truth.
        // This eliminates the caller mismatch risk (ID=1 but Name="COMPLETED").
        var currentStatus = await _workflowRepo.GetStatusByIdAsync(currentStatusId, ct);
        if (currentStatus is null)
            return DataProcessResult<TransitionOutcome>.Fail(
                $"Current status ID {currentStatusId} not found.",
                OperationStatus.NotFound);

        var currentStatusName = currentStatus.Name;

        // Query transitions scoped to this entity type
        var allowedTransitions = await _workflowRepo.GetAllowedTransitionsAsync(
            entityType, currentStatusId, ct);

        // Find the target among allowed transitions (case-insensitive)
        var matchingTransition = allowedTransitions.FirstOrDefault(
            t => t.ToStatus.Name.Equals(targetStatusName, StringComparison.OrdinalIgnoreCase));

        if (matchingTransition is null)
        {
            var allowedNames = allowedTransitions.Select(t => t.ToStatus.Name).ToArray();
            return DataProcessResult<TransitionOutcome>
                .Fail(
                    $"[{entityType}] Transition from '{currentStatusName}' to '{targetStatusName}' " +
                    $"is not allowed. Allowed transitions: [{string.Join(", ", allowedNames)}]")
                .WithMeta("allowedTransitions", allowedNames)
                .WithMeta("currentStatus", currentStatusName)
                .WithMeta("attemptedStatus", targetStatusName)
                .WithMeta("entityType", entityType);
        }

        // ═══ RULE EVALUATION — JSON rules are actually enforced ═══
        var ruleResult = EvaluateTransitionRules(
            matchingTransition.Rules, priorTransitionCount,
            entityType, currentStatusName, matchingTransition.ToStatus.Name);

        if (!ruleResult.IsSuccess)
            return ruleResult;

        var outcome = new TransitionOutcome(
            TargetStatusId: matchingTransition.ToStatus.Id,
            FromStatusName: currentStatusName,
            ToStatusName: matchingTransition.ToStatus.Name,
            Reason: reason,
            Context: context ?? new Dictionary<string, object>(),
            TransitionRules: matchingTransition.Rules,
            TransitionedAt: DateTime.UtcNow);

        return DataProcessResult<TransitionOutcome>.Ok(outcome);
    }

    public async Task<DataProcessResult<List<AvailableTarget>>> GetAvailableTargetsAsync(
        string entityType, int statusId, CancellationToken ct = default)
    {
        var transitions = await _workflowRepo.GetAllowedTransitionsAsync(
            entityType, statusId, ct);

        var targets = transitions.Select(t => new AvailableTarget(
            StatusId: t.ToStatus.Id,
            StatusName: t.ToStatus.Name,
            Description: t.Description,
            Rules: t.Rules)).ToList();

        return DataProcessResult<List<AvailableTarget>>.Ok(targets);
    }

    public async Task<DataProcessResult<WorkflowStatus>> GetInitialStatusAsync(
        string entityType, CancellationToken ct = default)
    {
        var initial = await _workflowRepo.GetInitialStatusAsync(entityType, ct);

        return initial is not null
            ? DataProcessResult<WorkflowStatus>.Ok(initial)
            : DataProcessResult<WorkflowStatus>.Fail(
                $"No initial workflow status configured for entity type '{entityType}'. " +
                "Ensure seed data has been applied.",
                OperationStatus.ConfigurationError);
    }

    // ═══════════════════════════════════════════════════════════════════
    // RULE EVALUATION ENGINE
    //
    // Transition rules are stored as Dictionary<string,object> in the DB
    // (FREEDOM — changeable at runtime). The evaluation logic is MACHINE.
    //
    // Currently supported rules:
    //   maxRetries (int) — maximum times this specific transition can occur.
    //                      Prevents infinite retry loops.
    //
    // Adding new rule types (e.g., "requiresApproval", "slaMinutes"):
    //   1. Add the rule key+value to the transition in the DB
    //   2. Add evaluation logic here
    //   3. Zero interface changes
    // ═══════════════════════════════════════════════════════════════════

    private static DataProcessResult<TransitionOutcome> EvaluateTransitionRules(
        Dictionary<string, object> rules,
        int priorTransitionCount,
        string entityType,
        string fromStatus,
        string toStatus)
    {
        if (rules.TryGetValue("maxRetries", out var maxRetriesObj))
        {
            var maxRetries = Convert.ToInt32(maxRetriesObj);
            if (priorTransitionCount >= maxRetries)
            {
                return DataProcessResult<TransitionOutcome>
                    .Fail(
                        $"[{entityType}] Transition from '{fromStatus}' to '{toStatus}' " +
                        $"rejected: maximum retries ({maxRetries}) exceeded. " +
                        $"Prior attempts: {priorTransitionCount}.")
                    .WithMeta("rule", "maxRetries")
                    .WithMeta("maxRetries", maxRetries)
                    .WithMeta("priorAttempts", priorTransitionCount)
                    .WithMeta("entityType", entityType);
            }
        }

        // Future rules: requiresApproval, slaMinutes, minimumAmount, etc.

        return DataProcessResult<TransitionOutcome>.Ok(default!); // pass-through
    }
}
