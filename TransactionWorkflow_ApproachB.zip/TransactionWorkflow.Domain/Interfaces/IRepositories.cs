using TransactionWorkflow.Domain.Core;
using TransactionWorkflow.Domain.Models;

namespace TransactionWorkflow.Domain.Interfaces;

// ═══════════════════════════════════════════════════════════════════════
// MACHINE — Repository contracts. Generic, entity-agnostic.
// Inspired by V17 Skill 01: IDatabaseService interface pattern.
//
// IWorkflowRepository is scoped by entityType on every query method.
// This enables the same database to hold completely different workflow
// definitions for different entity types.
// ═══════════════════════════════════════════════════════════════════════

public interface ITransactionRepository
{
    Task<Transaction?> GetByIdAsync(int id, CancellationToken ct = default);
    Task<Transaction> CreateAsync(Transaction transaction, CancellationToken ct = default);
    Task<DataProcessResult<Transaction>> UpdateAsync(Transaction transaction, CancellationToken ct = default);
    Task<List<TransactionHistory>> GetHistoryAsync(int transactionId, CancellationToken ct = default);
    Task AddHistoryAsync(TransactionHistory history, CancellationToken ct = default);
}

/// <summary>
/// Workflow configuration repository — ALL query methods are scoped by entityType.
/// This is B's core architectural differentiator: a single database can serve
/// different workflow definitions for transactions, orders, tickets, etc.
/// </summary>
public interface IWorkflowRepository
{
    // === EntityType-scoped queries ===
    Task<WorkflowStatus?> GetStatusByIdAsync(int statusId, CancellationToken ct = default);
    Task<WorkflowStatus?> GetStatusByNameAsync(string entityType, string name, CancellationToken ct = default);
    Task<WorkflowStatus?> GetInitialStatusAsync(string entityType, CancellationToken ct = default);
    Task<List<WorkflowTransition>> GetAllowedTransitionsAsync(string entityType, int fromStatusId, CancellationToken ct = default);
    Task<List<WorkflowStatus>> GetAllStatusesAsync(string entityType, CancellationToken ct = default);
    Task<List<WorkflowTransition>> GetAllTransitionsAsync(string entityType, CancellationToken ct = default);

    // === Admin: Entity type is part of the entity being created ===
    Task<WorkflowStatus> AddStatusAsync(WorkflowStatus status, CancellationToken ct = default);
    Task<WorkflowTransition> AddTransitionAsync(WorkflowTransition transition, CancellationToken ct = default);

    // === Cross-entity queries (admin overview) ===
    Task<List<string>> GetAllEntityTypesAsync(CancellationToken ct = default);
}
