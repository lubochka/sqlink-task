using TransactionWorkflow.Domain.Core;
using TransactionWorkflow.Domain.Models;

namespace TransactionWorkflow.Domain.Interfaces;

// ═══════════════════════════════════════════════════════════════════════
// MACHINE — The generic workflow engine interface.
//
// This engine doesn't know what a "transaction" is. It validates
// transitions for ANY entity type by looking up that type's workflow
// rules in the database.
//
// The entityType parameter is what makes B different from D:
//   - D's engine: TryTransitionAsync(currentStatus, targetStatus)
//   - B's engine: TryTransitionAsync(entityType, currentStatus, targetStatus)
//
// This means a single deployment can serve completely different
// workflows for different entity types — transactions, orders,
// support tickets — all configured via database rows.
// ═══════════════════════════════════════════════════════════════════════

/// <summary>
/// Engine outcome for a successful transition.
/// </summary>
public record TransitionOutcome(
    int TargetStatusId,
    string FromStatusName,
    string ToStatusName,
    string? Reason,
    Dictionary<string, object> Context,
    Dictionary<string, object> TransitionRules,
    DateTime TransitionedAt);

/// <summary>
/// An available target status with its transition rules.
/// </summary>
public record AvailableTarget(
    int StatusId,
    string StatusName,
    string? Description,
    Dictionary<string, object> Rules);

public interface IWorkflowEngine
{
    /// <summary>
    /// Validates and executes a status transition for the given entity type.
    /// The engine resolves the current status name internally from its ID,
    /// preventing caller-supplied mismatches (e.g., ID=1 but Name="COMPLETED").
    /// 
    /// priorTransitionCount enables rule evaluation: e.g., if a transition has
    /// {"maxRetries":3}, the engine rejects the transition when count >= 3.
    /// </summary>
    Task<DataProcessResult<TransitionOutcome>> TryTransitionAsync(
        string entityType,
        int currentStatusId,
        string targetStatusName,
        string? reason = null,
        Dictionary<string, object>? context = null,
        int priorTransitionCount = 0,
        CancellationToken ct = default);

    /// <summary>
    /// Returns all statuses reachable from the current status for this entity type.
    /// </summary>
    Task<DataProcessResult<List<AvailableTarget>>> GetAvailableTargetsAsync(
        string entityType,
        int statusId,
        CancellationToken ct = default);

    /// <summary>
    /// Returns the initial status for new entities of this type.
    /// </summary>
    Task<DataProcessResult<WorkflowStatus>> GetInitialStatusAsync(
        string entityType,
        CancellationToken ct = default);
}
