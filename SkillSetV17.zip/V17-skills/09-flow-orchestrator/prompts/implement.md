# Skill 09 — Flow Orchestrator: Implementation Guide

## Prerequisites
- Skill 01 (Core Interfaces) — MicroserviceBase, IDatabaseService, IQueueService
- Skill 02 (ObjectProcessor) — dynamic document serialization
- Skill 08 (Flow Definition) — FlowDefinition, FlowNode, FlowEdge, FlowValidator

## Step 1: Define Step Executor Interface
1. `IStepExecutor` with `NodeTypeName` property and `ExecuteAsync(context, ct)` method
2. `StepExecutionContext` — traceId, stepId, nodeType, input, configuration, previousStepOutputs
3. `StepResult` — success, output, error, debugData

## Step 2: Implement FlowOrchestrator (extends MicroserviceBase)
1. `_executors` dictionary: NodeType string → IStepExecutor
2. `_activeFlows` ConcurrentDictionary: traceId → FlowExecution (in-memory cache)
3. `RegisterExecutor(IStepExecutor)` — register at startup

## Step 3: TriggerFlowAsync
1. Create FlowExecution with unique traceId
2. Initialize StepStatuses for all nodes (status = Draft)
3. Persist to ES via `StoreDocumentAsync("flow-executions", traceId, execution)`
4. Mark trigger nodes as Completed, set their output = input
5. Call `ExecuteNextNodesAsync(flow, execution, triggerNodeIds)`

## Step 4: DAG Traversal (ExecuteNextNodesAsync)
1. Call `GetNextNodes(completedNodeIds)` — finds nodes whose ALL incoming edges have completed sources
2. If no next nodes → flow is complete, set FinalResult
3. Execute all ready nodes in parallel: `Task.WhenAll(nodes.Select(n => ExecuteNodeAsync(...)))`
4. After all complete, find newly completed → recurse

## Step 5: ExecuteNodeAsync (per node)
1. Set step status = Running, persist
2. Build StepExecutionContext with gathered input
3. Find executor by NodeType
4. Execute with timeout: `CancellationTokenSource.CreateLinkedTokenSource + CancelAfter`
5. On success: set Completed, store output, save NodeDebugData (Skill 14)
6. On failure: set Failed, propagate error to flow
7. On timeout: set Failed with "Timeout" error
8. Always persist after completion

## Step 6: Implement Resume
1. Load execution from ES by traceId
2. Find all completed step IDs
3. Set status = Running
4. Call `ExecuteNextNodesAsync(flow, execution, completedIds)`
5. Orchestrator naturally skips completed nodes

## Step 7: Register in DI
```csharp
builder.Services.AddSingleton<FlowOrchestrator>();
// At startup: orchestrator.RegisterExecutor(figmaParser);
// orchestrator.RegisterExecutor(aiTransformExecutor);
// orchestrator.RegisterExecutor(aiReviewExecutor);
```

## Step 8: Verify
- Test: Linear flow (3 nodes) → all execute in sequence
- Test: Fan-out (1→3→1) → parallel execution, merge waits for all
- Test: Step failure → flow marked Failed
- Test: Resume → continues from last checkpoint
- Integration: Full round-trip with ES persistence


---

## Genie DNA Compliance — MANDATORY for All Implementations

> Before writing ANY code, classify each component:
> **MACHINE** (static): Infrastructure that enables freedom. Build once, generic, interface-based.
> **FREEDOM** (dynamic): Anything users define. No fixed models, config-driven.

### DNA Checklist — Every Implementation MUST:
☐ **DNA-1 (Dynamic Documents):** Store data as `Dictionary<string, object>` / `Record<string, any>` — NOT typed model classes. User fields preserved without schema changes.
☐ **DNA-2 (BuildSearchFilter):** All queries use BuildSearchFilter/equivalent. Empty fields auto-skipped. No entity-specific query code.
☐ **DNA-3 (MicroserviceBase):** Inherit base class with DB, queue, cache, logger built in.
☐ **DNA-5 (DataProcessResult):** All public methods return `DataProcessResult<T>`. Errors return failure, not throw exceptions.
☐ **DNA-6 (Generic Interfaces):** External dependencies behind interfaces. Swap via config.
☐ **DNA-SCOPE:** Non-admin queries auto-inject userId filter. Cannot be bypassed.

### The Three Tests:
1. Can a business user change this without a developer? (YES = correct)
2. Does it work for entity types that do not exist yet? (YES = correct)
3. Can I swap the database/service/UI without changing this? (YES = correct)
