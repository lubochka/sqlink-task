# XIIGen Flow Orchestrator — Skill 09 | Python
# DAG execution engine with parallel fan-out, state persistence, resume

from __future__ import annotations
import asyncio
import time
import uuid as uuid_mod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional, Protocol


# ─── Interfaces ──────────────────────────────────────
@dataclass
class StepExecutionContext:
    trace_id: str = ""
    step_id: str = ""
    node_type: str = ""
    input: Any = None
    configuration: dict[str, Any] = field(default_factory=dict)
    previous_step_outputs: dict[str, Any] = field(default_factory=dict)


@dataclass
class StepResult:
    success: bool = True
    output: Any = None
    error: Optional[str] = None
    debug_data: dict[str, Any] = field(default_factory=dict)


class IStepExecutor(Protocol):
    @property
    def node_type_name(self) -> str: ...
    async def execute(self, context: StepExecutionContext) -> StepResult: ...


# ─── Flow Orchestrator ──────────────────────────────
class FlowOrchestrator:
    def __init__(self, db, logger=None):
        self._db = db
        self._logger = logger
        self._executors: dict[str, IStepExecutor] = {}
        self._active_flows: dict[str, dict] = {}

    def register_executor(self, executor: IStepExecutor) -> None:
        self._executors[executor.node_type_name] = executor

    async def trigger_flow(self, flow, input_data: Any, trace_id: str | None = None) -> dict:
        execution = {
            "executionId": str(uuid_mod.uuid4()),
            "traceId": trace_id or str(uuid_mod.uuid4()),
            "flowId": flow.flow_id,
            "status": "running",
            "stepStatuses": {},
            "stepOutputs": {},
            "input": input_data,
            "startedAt": datetime.now(timezone.utc).isoformat(),
            "completedAt": None,
            "finalResult": None,
            "error": None,
        }

        # Initialize step statuses
        for node in flow.nodes:
            execution["stepStatuses"][node.node_id] = {
                "stepId": node.node_id, "nodeType": node.type.value,
                "status": "draft", "output": None, "error": None,
            }

        await self._save_execution(execution)
        self._active_flows[execution["traceId"]] = execution

        # Mark triggers complete
        triggers = [n for n in flow.nodes if n.type.value == "trigger"]
        for t in triggers:
            s = execution["stepStatuses"][t.node_id]
            s["status"] = "completed"
            s["output"] = input_data
            execution["stepOutputs"][t.node_id] = input_data

        await self._execute_next(flow, execution, [t.node_id for t in triggers])
        return execution

    async def _execute_next(self, flow, execution: dict, completed_ids: list[str]) -> None:
        next_nodes = self._get_next_nodes(flow, completed_ids, execution)

        if not next_nodes:
            execution["status"] = "completed"
            execution["completedAt"] = datetime.now(timezone.utc).isoformat()
            completed_steps = [s for s in execution["stepStatuses"].values() if s["status"] == "completed"]
            if completed_steps:
                execution["finalResult"] = completed_steps[-1].get("output")
            await self._save_execution(execution)
            return

        # Execute all ready nodes in parallel
        tasks = [self._execute_node(flow, execution, node) for node in next_nodes]
        await asyncio.gather(*tasks, return_exceptions=True)

        newly_completed = [
            n.node_id for n in next_nodes
            if execution["stepStatuses"].get(n.node_id, {}).get("status") == "completed"
        ]

        if newly_completed and execution["status"] == "running":
            await self._execute_next(flow, execution, newly_completed)

    async def _execute_node(self, flow, execution: dict, node) -> None:
        step = execution["stepStatuses"][node.node_id]
        step["status"] = "running"
        step["startedAt"] = datetime.now(timezone.utc).isoformat()
        await self._save_execution(execution)

        start = time.monotonic()

        try:
            context = StepExecutionContext(
                trace_id=execution["traceId"],
                step_id=node.node_id,
                node_type=node.type.value,
                input=self._gather_input(flow, execution, node),
                configuration=node.configuration,
                previous_step_outputs=execution["stepOutputs"],
            )

            executor = self._executors.get(node.type.value)
            if not executor:
                raise RuntimeError(f"No executor for node type '{node.type.value}'")

            result = await asyncio.wait_for(
                executor.execute(context),
                timeout=node.timeout_seconds,
            )

            duration = time.monotonic() - start

            if result.success:
                step["status"] = "completed"
                step["output"] = result.output
                execution["stepOutputs"][node.node_id] = result.output

                await self._db.store("debug-traces", "xiigen", str(uuid_mod.uuid4()), {
                    "traceId": execution["traceId"], "stepId": node.node_id,
                    "nodeType": node.type.value, "input": context.input,
                    "output": result.output, "duration": duration,
                    "intermediateData": result.debug_data,
                })
            else:
                step["status"] = "failed"
                step["error"] = result.error
                execution["status"] = "failed"
                execution["error"] = f"Step {node.name} failed: {result.error}"

        except asyncio.TimeoutError:
            step["status"] = "failed"
            step["error"] = "Timeout"
            execution["status"] = "failed"
            execution["error"] = f"Step {node.name} timed out"
        except Exception as ex:
            step["status"] = "failed"
            step["error"] = str(ex)
            execution["status"] = "failed"
            execution["error"] = f"Step {node.name}: {ex}"

        step["completedAt"] = datetime.now(timezone.utc).isoformat()
        await self._save_execution(execution)

    def _get_next_nodes(self, flow, completed_ids: list[str], execution: dict) -> list:
        result = []
        for cid in completed_ids:
            out_edges = [e for e in flow.edges if e.source_node_id == cid]
            for edge in out_edges:
                target = execution["stepStatuses"].get(edge.target_node_id, {})
                if target.get("status", "draft") != "draft":
                    continue
                incoming = [e for e in flow.edges if e.target_node_id == edge.target_node_id]
                all_ready = all(
                    execution["stepStatuses"].get(e.source_node_id, {}).get("status") == "completed"
                    for e in incoming
                )
                if all_ready:
                    node = next((n for n in flow.nodes if n.node_id == edge.target_node_id), None)
                    if node and not any(r.node_id == node.node_id for r in result):
                        result.append(node)
        return result

    def _gather_input(self, flow, execution: dict, node) -> Any:
        incoming = [e for e in flow.edges if e.target_node_id == node.node_id]
        inputs = {}
        for edge in incoming:
            out = execution["stepOutputs"].get(edge.source_node_id)
            if out is not None:
                inputs[edge.source_node_id] = out
        values = list(inputs.values())
        return values[0] if len(values) == 1 else inputs

    async def _save_execution(self, execution: dict) -> None:
        await self._db.store("flow-executions", "xiigen", execution["traceId"], execution)

    async def get_execution(self, trace_id: str) -> dict | None:
        if trace_id in self._active_flows:
            return self._active_flows[trace_id]
        result = await self._db.get("flow-executions", "xiigen", trace_id)
        return result.get("data") if result else None

    async def resume(self, trace_id: str, flow) -> dict | None:
        execution = await self.get_execution(trace_id)
        if not execution or execution["status"] == "completed":
            return execution
        execution["status"] = "running"
        self._active_flows[trace_id] = execution
        completed = [k for k, v in execution["stepStatuses"].items() if v["status"] == "completed"]
        await self._execute_next(flow, execution, completed)
        return execution
