// XIIGen Flow Orchestrator — Skill 09 | Java 21+
// DAG execution engine with virtual threads, parallel fan-out, state persistence

package com.xiigen.flowengine;

import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Collectors;

public class FlowOrchestrator {

    // ─── Interfaces ─────────────────────────────────
    public interface StepExecutor {
        String nodeTypeName();
        StepResult execute(StepExecutionContext context) throws Exception;
    }

    public record StepExecutionContext(
        String traceId, String stepId, String nodeType,
        Object input, Map<String, Object> configuration,
        Map<String, Object> previousStepOutputs
    ) {}

    public record StepResult(boolean success, Object output, String error, Map<String, Object> debugData) {
        public static StepResult ok(Object output) { return new StepResult(true, output, null, Map.of()); }
        public static StepResult fail(String error) { return new StepResult(false, null, error, Map.of()); }
    }

    // ─── State ──────────────────────────────────────
    private final Map<String, StepExecutor> executors = new ConcurrentHashMap<>();
    private final Map<String, Map<String, Object>> activeFlows = new ConcurrentHashMap<>();
    private final Object db;
    private final ExecutorService virtualThreadPool = Executors.newVirtualThreadPerTaskExecutor();

    public FlowOrchestrator(Object db) { this.db = db; }

    public void registerExecutor(StepExecutor executor) {
        executors.put(executor.nodeTypeName(), executor);
    }

    // ─── Trigger ────────────────────────────────────
    public Map<String, Object> triggerFlow(FlowDefinition flow, Object input, String traceId) throws Exception {
        var execution = new HashMap<String, Object>();
        execution.put("executionId", UUID.randomUUID().toString());
        execution.put("traceId", traceId != null ? traceId : UUID.randomUUID().toString());
        execution.put("flowId", flow.getFlowId());
        execution.put("status", "running");
        execution.put("input", input);
        execution.put("startedAt", Instant.now().toString());

        var stepStatuses = new ConcurrentHashMap<String, Map<String, Object>>();
        var stepOutputs = new ConcurrentHashMap<String, Object>();

        for (var node : flow.getNodes()) {
            stepStatuses.put(node.nodeId(), Map.of(
                "stepId", node.nodeId(), "nodeType", node.type().name(),
                "status", "draft"
            ));
        }
        execution.put("stepStatuses", stepStatuses);
        execution.put("stepOutputs", stepOutputs);

        activeFlows.put((String) execution.get("traceId"), execution);

        // Mark triggers complete
        var triggers = flow.getNodes().stream()
            .filter(n -> n.type() == FlowDefinition.NodeType.TRIGGER)
            .toList();

        for (var trigger : triggers) {
            stepStatuses.put(trigger.nodeId(), new HashMap<>(Map.of(
                "stepId", trigger.nodeId(), "nodeType", trigger.type().name(),
                "status", "completed", "output", input
            )));
            stepOutputs.put(trigger.nodeId(), input);
        }

        // Execute DAG
        executeNextNodes(flow, execution, triggers.stream().map(FlowDefinition.FlowNode::nodeId).toList());
        return execution;
    }

    // ─── DAG Traversal ──────────────────────────────
    @SuppressWarnings("unchecked")
    private void executeNextNodes(FlowDefinition flow, Map<String, Object> execution, List<String> completedIds) throws Exception {
        var nextNodes = getNextNodes(flow, completedIds, execution);
        if (nextNodes.isEmpty()) {
            execution.put("status", "completed");
            execution.put("completedAt", Instant.now().toString());
            return;
        }

        // Execute in parallel using virtual threads
        var futures = nextNodes.stream()
            .map(node -> CompletableFuture.runAsync(
                () -> { try { executeNode(flow, execution, node); } catch (Exception e) { throw new RuntimeException(e); } },
                virtualThreadPool
            ))
            .toList();

        CompletableFuture.allOf(futures.toArray(CompletableFuture[]::new)).join();

        var stepStatuses = (Map<String, Map<String, Object>>) execution.get("stepStatuses");
        var newlyCompleted = nextNodes.stream()
            .filter(n -> "completed".equals(stepStatuses.get(n.nodeId()).get("status")))
            .map(FlowDefinition.FlowNode::nodeId)
            .toList();

        if (!newlyCompleted.isEmpty() && "running".equals(execution.get("status"))) {
            executeNextNodes(flow, execution, newlyCompleted);
        }
    }

    @SuppressWarnings("unchecked")
    private void executeNode(FlowDefinition flow, Map<String, Object> execution, FlowDefinition.FlowNode node) {
        var stepStatuses = (Map<String, Map<String, Object>>) execution.get("stepStatuses");
        var stepOutputs = (Map<String, Object>) execution.get("stepOutputs");
        var step = new HashMap<>(stepStatuses.get(node.nodeId()));
        step.put("status", "running");
        step.put("startedAt", Instant.now().toString());
        stepStatuses.put(node.nodeId(), step);

        try {
            var context = new StepExecutionContext(
                (String) execution.get("traceId"), node.nodeId(), node.type().name(),
                gatherInput(flow, execution, node), node.configuration(), stepOutputs
            );

            var executor = executors.get(node.type().name());
            if (executor == null) throw new IllegalStateException("No executor for: " + node.type());

            // Execute with timeout
            var future = CompletableFuture.supplyAsync(() -> {
                try { return executor.execute(context); } catch (Exception e) { throw new RuntimeException(e); }
            }, virtualThreadPool);

            var result = future.get(node.timeoutSeconds(), TimeUnit.SECONDS);

            if (result.success()) {
                step.put("status", "completed");
                step.put("output", result.output());
                stepOutputs.put(node.nodeId(), result.output());
            } else {
                step.put("status", "failed");
                step.put("error", result.error());
                execution.put("status", "failed");
                execution.put("error", "Step " + node.name() + " failed: " + result.error());
            }
        } catch (TimeoutException e) {
            step.put("status", "failed");
            step.put("error", "Timeout");
            execution.put("status", "failed");
        } catch (Exception e) {
            step.put("status", "failed");
            step.put("error", e.getMessage());
            execution.put("status", "failed");
        }

        step.put("completedAt", Instant.now().toString());
        stepStatuses.put(node.nodeId(), step);
    }

    @SuppressWarnings("unchecked")
    private List<FlowDefinition.FlowNode> getNextNodes(FlowDefinition flow, List<String> completedIds, Map<String, Object> execution) {
        var stepStatuses = (Map<String, Map<String, Object>>) execution.get("stepStatuses");
        var result = new ArrayList<FlowDefinition.FlowNode>();

        for (var cid : completedIds) {
            for (var edge : flow.getEdges()) {
                if (!edge.sourceNodeId().equals(cid)) continue;
                var target = stepStatuses.get(edge.targetNodeId());
                if (target != null && !"draft".equals(target.get("status"))) continue;

                boolean allReady = flow.getEdges().stream()
                    .filter(e -> e.targetNodeId().equals(edge.targetNodeId()))
                    .allMatch(e -> "completed".equals(
                        stepStatuses.getOrDefault(e.sourceNodeId(), Map.of()).get("status")));

                if (allReady) {
                    var node = flow.getNodes().stream()
                        .filter(n -> n.nodeId().equals(edge.targetNodeId()))
                        .findFirst().orElse(null);
                    if (node != null && result.stream().noneMatch(n -> n.nodeId().equals(node.nodeId()))) {
                        result.add(node);
                    }
                }
            }
        }
        return result;
    }

    @SuppressWarnings("unchecked")
    private Object gatherInput(FlowDefinition flow, Map<String, Object> execution, FlowDefinition.FlowNode node) {
        var stepOutputs = (Map<String, Object>) execution.get("stepOutputs");
        var inputs = new HashMap<String, Object>();
        for (var edge : flow.getEdges()) {
            if (edge.targetNodeId().equals(node.nodeId()) && stepOutputs.containsKey(edge.sourceNodeId())) {
                inputs.put(edge.sourceNodeId(), stepOutputs.get(edge.sourceNodeId()));
            }
        }
        return inputs.size() == 1 ? inputs.values().iterator().next() : inputs;
    }

    public Map<String, Object> getExecution(String traceId) {
        return activeFlows.getOrDefault(traceId, null);
    }
}
