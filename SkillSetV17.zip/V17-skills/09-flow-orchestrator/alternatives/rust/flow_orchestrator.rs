// XIIGen Flow Orchestrator — Skill 09 | Rust (tokio async)
// DAG execution engine with parallel fan-out, state persistence, resume

use crate::flow_definition::{FlowDefinition, FlowNode, FlowStatus, NodeType};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::sync::Arc;
use tokio::sync::RwLock;
use tokio::time::{timeout, Duration};
use uuid::Uuid;
use async_trait::async_trait;

// ─── Interfaces ─────────────────────────────────────
pub struct StepExecutionContext {
    pub trace_id: String,
    pub step_id: String,
    pub node_type: String,
    pub input: serde_json::Value,
    pub configuration: HashMap<String, serde_json::Value>,
    pub previous_step_outputs: HashMap<String, serde_json::Value>,
}

pub struct StepResult {
    pub success: bool,
    pub output: Option<serde_json::Value>,
    pub error: Option<String>,
    pub debug_data: HashMap<String, serde_json::Value>,
}

impl StepResult {
    pub fn ok(output: serde_json::Value) -> Self {
        Self { success: true, output: Some(output), error: None, debug_data: HashMap::new() }
    }
    pub fn fail(error: &str) -> Self {
        Self { success: false, output: None, error: Some(error.to_string()), debug_data: HashMap::new() }
    }
}

#[async_trait]
pub trait StepExecutor: Send + Sync {
    fn node_type_name(&self) -> &str;
    async fn execute(&self, context: StepExecutionContext) -> Result<StepResult, Box<dyn std::error::Error + Send + Sync>>;
}

// ─── Execution State ────────────────────────────────
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct FlowExecution {
    pub execution_id: String,
    pub trace_id: String,
    pub flow_id: String,
    pub status: String,
    pub step_statuses: HashMap<String, StepState>,
    pub step_outputs: HashMap<String, serde_json::Value>,
    pub input: serde_json::Value,
    pub final_result: Option<serde_json::Value>,
    pub started_at: String,
    pub completed_at: Option<String>,
    pub error: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StepState {
    pub step_id: String,
    pub node_type: String,
    pub status: String,
    pub output: Option<serde_json::Value>,
    pub error: Option<String>,
}

// ─── Orchestrator ───────────────────────────────────
pub struct FlowOrchestrator {
    executors: RwLock<HashMap<String, Arc<dyn StepExecutor>>>,
    active_flows: RwLock<HashMap<String, FlowExecution>>,
    db: Arc<dyn DatabaseClient>,
}

#[async_trait]
pub trait DatabaseClient: Send + Sync {
    async fn store(&self, index: &str, prefix: &str, id: &str, doc: &serde_json::Value) -> Result<(), Box<dyn std::error::Error + Send + Sync>>;
    async fn get(&self, index: &str, prefix: &str, id: &str) -> Result<Option<serde_json::Value>, Box<dyn std::error::Error + Send + Sync>>;
}

impl FlowOrchestrator {
    pub fn new(db: Arc<dyn DatabaseClient>) -> Self {
        Self {
            executors: RwLock::new(HashMap::new()),
            active_flows: RwLock::new(HashMap::new()),
            db,
        }
    }

    pub async fn register_executor(&self, executor: Arc<dyn StepExecutor>) {
        self.executors.write().await.insert(executor.node_type_name().to_string(), executor);
    }

    pub async fn trigger_flow(&self, flow: &FlowDefinition, input: serde_json::Value, trace_id: Option<String>) -> Result<FlowExecution, Box<dyn std::error::Error + Send + Sync>> {
        let tid = trace_id.unwrap_or_else(|| Uuid::new_v4().to_string());

        let mut execution = FlowExecution {
            execution_id: Uuid::new_v4().to_string(),
            trace_id: tid.clone(),
            flow_id: flow.flow_id.clone(),
            status: "running".to_string(),
            step_statuses: HashMap::new(),
            step_outputs: HashMap::new(),
            input: input.clone(),
            final_result: None,
            started_at: chrono::Utc::now().to_rfc3339(),
            completed_at: None,
            error: None,
        };

        // Initialize step states
        for node in &flow.nodes {
            execution.step_statuses.insert(node.node_id.clone(), StepState {
                step_id: node.node_id.clone(),
                node_type: format!("{:?}", node.node_type),
                status: "draft".to_string(),
                output: None,
                error: None,
            });
        }

        // Mark triggers complete
        let trigger_ids: Vec<String> = flow.nodes.iter()
            .filter(|n| n.node_type == NodeType::Trigger)
            .map(|n| {
                if let Some(state) = execution.step_statuses.get_mut(&n.node_id) {
                    state.status = "completed".to_string();
                    state.output = Some(input.clone());
                }
                execution.step_outputs.insert(n.node_id.clone(), input.clone());
                n.node_id.clone()
            })
            .collect();

        self.save_execution(&execution).await?;
        self.active_flows.write().await.insert(tid.clone(), execution.clone());

        self.execute_next(flow, &mut execution, &trigger_ids).await?;
        Ok(execution)
    }

    async fn execute_next(&self, flow: &FlowDefinition, execution: &mut FlowExecution, completed_ids: &[String]) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        let next_nodes = self.get_next_nodes(flow, completed_ids, execution);

        if next_nodes.is_empty() {
            execution.status = "completed".to_string();
            execution.completed_at = Some(chrono::Utc::now().to_rfc3339());
            self.save_execution(execution).await?;
            return Ok(());
        }

        // Execute in parallel with tokio::join
        let mut handles = Vec::new();
        let executors = self.executors.read().await;

        for node in &next_nodes {
            let input = self.gather_input(flow, execution, node);
            let executor = executors.get(&format!("{:?}", node.node_type)).cloned();
            let timeout_secs = node.timeout_seconds;
            let ctx = StepExecutionContext {
                trace_id: execution.trace_id.clone(),
                step_id: node.node_id.clone(),
                node_type: format!("{:?}", node.node_type),
                input,
                configuration: node.configuration.clone(),
                previous_step_outputs: execution.step_outputs.clone(),
            };

            handles.push(tokio::spawn(async move {
                if let Some(exec) = executor {
                    match timeout(Duration::from_secs(timeout_secs as u64), exec.execute(ctx)).await {
                        Ok(Ok(result)) => result,
                        Ok(Err(e)) => StepResult::fail(&e.to_string()),
                        Err(_) => StepResult::fail("Timeout"),
                    }
                } else {
                    StepResult::fail("No executor registered")
                }
            }));
        }

        let results = futures::future::join_all(handles).await;

        let mut newly_completed = Vec::new();
        for (i, result) in results.into_iter().enumerate() {
            let node = &next_nodes[i];
            match result {
                Ok(step_result) if step_result.success => {
                    if let Some(state) = execution.step_statuses.get_mut(&node.node_id) {
                        state.status = "completed".to_string();
                        state.output = step_result.output.clone();
                    }
                    if let Some(output) = step_result.output {
                        execution.step_outputs.insert(node.node_id.clone(), output);
                    }
                    newly_completed.push(node.node_id.clone());
                }
                _ => {
                    if let Some(state) = execution.step_statuses.get_mut(&node.node_id) {
                        state.status = "failed".to_string();
                    }
                    execution.status = "failed".to_string();
                }
            }
        }

        self.save_execution(execution).await?;

        if !newly_completed.is_empty() && execution.status == "running" {
            Box::pin(self.execute_next(flow, execution, &newly_completed)).await?;
        }

        Ok(())
    }

    fn get_next_nodes(&self, flow: &FlowDefinition, completed_ids: &[String], execution: &FlowExecution) -> Vec<FlowNode> {
        let mut result = Vec::new();
        for cid in completed_ids {
            for edge in &flow.edges {
                if edge.source_node_id != *cid { continue; }
                if let Some(state) = execution.step_statuses.get(&edge.target_node_id) {
                    if state.status != "draft" { continue; }
                }
                let all_ready = flow.edges.iter()
                    .filter(|e| e.target_node_id == edge.target_node_id)
                    .all(|e| execution.step_statuses.get(&e.source_node_id).map(|s| s.status == "completed").unwrap_or(false));
                if all_ready {
                    if let Some(node) = flow.nodes.iter().find(|n| n.node_id == edge.target_node_id) {
                        if !result.iter().any(|n: &FlowNode| n.node_id == node.node_id) {
                            result.push(node.clone());
                        }
                    }
                }
            }
        }
        result
    }

    fn gather_input(&self, flow: &FlowDefinition, execution: &FlowExecution, node: &FlowNode) -> serde_json::Value {
        let incoming: Vec<_> = flow.edges.iter().filter(|e| e.target_node_id == node.node_id).collect();
        let mut inputs = serde_json::Map::new();
        for edge in &incoming {
            if let Some(output) = execution.step_outputs.get(&edge.source_node_id) {
                inputs.insert(edge.source_node_id.clone(), output.clone());
            }
        }
        if inputs.len() == 1 {
            inputs.into_values().next().unwrap_or(serde_json::Value::Null)
        } else {
            serde_json::Value::Object(inputs)
        }
    }

    async fn save_execution(&self, execution: &FlowExecution) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        let val = serde_json::to_value(execution)?;
        self.db.store("flow-executions", "xiigen", &execution.trace_id, &val).await
    }

    pub async fn get_execution(&self, trace_id: &str) -> Option<FlowExecution> {
        self.active_flows.read().await.get(trace_id).cloned()
    }
}
