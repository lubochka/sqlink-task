// XIIGen Flow Orchestrator — Skill 09 | Node.js/TypeScript
// DAG execution engine with parallel fan-out, state persistence, resume

import { FlowDefinition, FlowExecution, FlowNode, FlowStatus, StepStatus } from './flow-definition';
import { v4 as uuid } from 'uuid';

// ─── Interfaces ─────────────────────────────────────
export interface StepExecutionContext {
  traceId: string;
  stepId: string;
  nodeType: string;
  input: any;
  configuration: Record<string, any>;
  previousStepOutputs: Record<string, any>;
}

export interface StepResult {
  success: boolean;
  output?: any;
  error?: string;
  debugData?: Record<string, any>;
}

export interface IStepExecutor {
  nodeTypeName: string;
  execute(context: StepExecutionContext): Promise<StepResult>;
}

// ─── Flow Orchestrator ──────────────────────────────
export class FlowOrchestrator {
  private executors = new Map<string, IStepExecutor>();
  private activeFlows = new Map<string, FlowExecution>();

  constructor(private db: any, private logger?: any) {}

  registerExecutor(executor: IStepExecutor): void {
    this.executors.set(executor.nodeTypeName, executor);
  }

  // ─── Trigger a Flow ─────────────────────────────
  async triggerFlow(flow: FlowDefinition, input: any, traceId?: string): Promise<FlowExecution> {
    const execution: FlowExecution = {
      executionId: uuid(),
      traceId: traceId || uuid(),
      flowId: flow.flowId,
      status: 'running',
      stepStatuses: {},
      stepOutputs: {},
      input,
      startedAt: new Date().toISOString(),
    };

    // Initialize step statuses
    for (const node of flow.nodes) {
      execution.stepStatuses[node.nodeId] = {
        stepId: node.nodeId,
        nodeType: node.type,
        status: 'draft',
      };
    }

    await this.saveExecution(execution);
    this.activeFlows.set(execution.traceId, execution);

    // Mark trigger nodes complete
    const triggers = flow.nodes.filter(n => n.type === 'trigger');
    for (const trigger of triggers) {
      execution.stepStatuses[trigger.nodeId].status = 'completed';
      execution.stepStatuses[trigger.nodeId].startedAt = new Date().toISOString();
      execution.stepStatuses[trigger.nodeId].completedAt = new Date().toISOString();
      execution.stepStatuses[trigger.nodeId].output = input;
      execution.stepOutputs[trigger.nodeId] = input;
    }

    // Execute DAG
    await this.executeNextNodes(flow, execution, triggers.map(t => t.nodeId));
    return execution;
  }

  // ─── DAG Traversal ──────────────────────────────
  private async executeNextNodes(flow: FlowDefinition, execution: FlowExecution, completedIds: string[]): Promise<void> {
    const nextNodes = this.getNextNodes(flow, completedIds, execution);

    if (nextNodes.length === 0) {
      execution.status = 'completed';
      execution.completedAt = new Date().toISOString();
      // Last completed node output is final result
      const lastStep = Object.values(execution.stepStatuses)
        .filter(s => s.status === 'completed')
        .sort((a, b) => (b.completedAt || '').localeCompare(a.completedAt || ''))[0];
      execution.finalResult = lastStep?.output;
      await this.saveExecution(execution);
      return;
    }

    // Execute all ready nodes in parallel
    await Promise.all(nextNodes.map(node => this.executeNode(flow, execution, node)));

    // Find newly completed → continue recursion
    const newlyCompleted = nextNodes
      .filter(n => execution.stepStatuses[n.nodeId]?.status === 'completed')
      .map(n => n.nodeId);

    if (newlyCompleted.length > 0 && execution.status === 'running') {
      await this.executeNextNodes(flow, execution, newlyCompleted);
    }
  }

  private async executeNode(flow: FlowDefinition, execution: FlowExecution, node: FlowNode): Promise<void> {
    const step = execution.stepStatuses[node.nodeId];
    step.status = 'running';
    step.startedAt = new Date().toISOString();
    await this.saveExecution(execution);

    const start = Date.now();

    try {
      const context: StepExecutionContext = {
        traceId: execution.traceId,
        stepId: node.nodeId,
        nodeType: node.type,
        input: this.gatherInput(flow, execution, node),
        configuration: node.configuration,
        previousStepOutputs: execution.stepOutputs,
      };

      const executor = this.executors.get(node.type);
      if (!executor) throw new Error(`No executor for node type '${node.type}'`);

      // Execute with timeout
      const result = await Promise.race([
        executor.execute(context),
        new Promise<StepResult>((_, reject) =>
          setTimeout(() => reject(new Error('Timeout')), node.timeoutSeconds * 1000)
        ),
      ]);

      if (result.success) {
        step.status = 'completed';
        step.output = result.output;
        execution.stepOutputs[node.nodeId] = result.output;

        // Store debug data
        await this.db.store?.('debug-traces', 'xiigen', uuid(), {
          traceId: execution.traceId, stepId: node.nodeId, nodeType: node.type,
          input: context.input, output: result.output,
          duration: Date.now() - start, intermediateData: result.debugData,
          timestamp: new Date().toISOString(),
        });
      } else {
        step.status = 'failed';
        step.error = result.error;
        execution.status = 'failed';
        execution.error = `Step ${node.name} failed: ${result.error}`;
      }
    } catch (err: any) {
      step.status = 'failed';
      step.error = err.message;
      execution.status = 'failed';
      execution.error = `Step ${node.name}: ${err.message}`;
    }

    step.completedAt = new Date().toISOString();
    await this.saveExecution(execution);
  }

  // ─── DAG Helpers ────────────────────────────────
  private getNextNodes(flow: FlowDefinition, completedIds: string[], execution: FlowExecution): FlowNode[] {
    const next: FlowNode[] = [];
    for (const cid of completedIds) {
      const outEdges = flow.edges.filter(e => e.sourceNodeId === cid);
      for (const edge of outEdges) {
        const targetStatus = execution.stepStatuses[edge.targetNodeId];
        if (targetStatus && targetStatus.status !== 'draft') continue;

        const incoming = flow.edges.filter(e => e.targetNodeId === edge.targetNodeId);
        const allReady = incoming.every(e =>
          execution.stepStatuses[e.sourceNodeId]?.status === 'completed'
        );

        if (allReady) {
          const node = flow.nodes.find(n => n.nodeId === edge.targetNodeId);
          if (node && !next.some(n => n.nodeId === node.nodeId)) next.push(node);
        }
      }
    }
    return next;
  }

  private gatherInput(flow: FlowDefinition, execution: FlowExecution, node: FlowNode): any {
    const incoming = flow.edges.filter(e => e.targetNodeId === node.nodeId);
    const inputs: Record<string, any> = {};
    for (const edge of incoming) {
      if (execution.stepOutputs[edge.sourceNodeId] !== undefined) {
        inputs[edge.sourceNodeId] = execution.stepOutputs[edge.sourceNodeId];
      }
    }
    const values = Object.values(inputs);
    return values.length === 1 ? values[0] : inputs;
  }

  // ─── State ──────────────────────────────────────
  private async saveExecution(execution: FlowExecution): Promise<void> {
    await this.db.store?.('flow-executions', 'xiigen', execution.traceId, execution);
  }

  async getExecution(traceId: string): Promise<FlowExecution | null> {
    if (this.activeFlows.has(traceId)) return this.activeFlows.get(traceId)!;
    const result = await this.db.get?.('flow-executions', 'xiigen', traceId);
    return result?.data ?? null;
  }

  // ─── Resume ─────────────────────────────────────
  async resume(traceId: string, flow: FlowDefinition): Promise<FlowExecution | null> {
    const execution = await this.getExecution(traceId);
    if (!execution || execution.status === 'completed') return execution;

    execution.status = 'running';
    this.activeFlows.set(traceId, execution);
    const completed = Object.entries(execution.stepStatuses)
      .filter(([_, s]) => s.status === 'completed')
      .map(([id]) => id);

    await this.executeNextNodes(flow, execution, completed);
    return execution;
  }
}
