<?php
// XIIGen Flow Orchestrator — Skill 09 | PHP 8.3+
// DAG execution engine with sequential fan-out, state persistence, resume
// Note: For true parallel execution, use amphp/parallel or ReactPHP

declare(strict_types=1);
namespace XIIGen\FlowEngine;

use Ramsey\Uuid\Uuid;

// ─── Interfaces ─────────────────────────────────────
class StepExecutionContext {
    public function __construct(
        public string $traceId = '',
        public string $stepId = '',
        public string $nodeType = '',
        public mixed $input = null,
        public array $configuration = [],
        public array $previousStepOutputs = [],
    ) {}
}

class StepResult {
    public function __construct(
        public bool $success = true,
        public mixed $output = null,
        public ?string $error = null,
        public array $debugData = [],
    ) {}

    public static function ok(mixed $output): self { return new self(true, $output); }
    public static function fail(string $error): self { return new self(false, null, $error); }
}

interface IStepExecutor {
    public function nodeTypeName(): string;
    public function execute(StepExecutionContext $context): StepResult;
}

// ─── Flow Orchestrator ──────────────────────────────
class FlowOrchestrator {
    private array $executors = [];
    private array $activeFlows = [];

    public function __construct(private $db) {}

    public function registerExecutor(IStepExecutor $executor): void {
        $this->executors[$executor->nodeTypeName()] = $executor;
    }

    public function triggerFlow(FlowDefinition $flow, mixed $input, ?string $traceId = null): array {
        $execution = [
            'executionId' => Uuid::uuid4()->toString(),
            'traceId' => $traceId ?? Uuid::uuid4()->toString(),
            'flowId' => $flow->flowId,
            'status' => 'running',
            'stepStatuses' => [],
            'stepOutputs' => [],
            'input' => $input,
            'finalResult' => null,
            'startedAt' => date('c'),
            'completedAt' => null,
            'error' => null,
        ];

        foreach ($flow->nodes as $node) {
            $execution['stepStatuses'][$node->nodeId] = [
                'stepId' => $node->nodeId,
                'nodeType' => $node->type->value,
                'status' => 'draft',
                'output' => null,
                'error' => null,
            ];
        }

        $this->activeFlows[$execution['traceId']] = &$execution;

        // Mark triggers complete
        $triggerIds = [];
        foreach ($flow->nodes as $node) {
            if ($node->type === NodeType::Trigger) {
                $execution['stepStatuses'][$node->nodeId]['status'] = 'completed';
                $execution['stepStatuses'][$node->nodeId]['output'] = $input;
                $execution['stepOutputs'][$node->nodeId] = $input;
                $triggerIds[] = $node->nodeId;
            }
        }

        $this->saveExecution($execution);
        $this->executeNextNodes($flow, $execution, $triggerIds);
        return $execution;
    }

    private function executeNextNodes(FlowDefinition $flow, array &$execution, array $completedIds): void {
        $nextNodes = $this->getNextNodes($flow, $completedIds, $execution);

        if (empty($nextNodes)) {
            $execution['status'] = 'completed';
            $execution['completedAt'] = date('c');
            $completed = array_filter($execution['stepStatuses'], fn($s) => $s['status'] === 'completed');
            if (!empty($completed)) {
                $last = end($completed);
                $execution['finalResult'] = $last['output'] ?? null;
            }
            $this->saveExecution($execution);
            return;
        }

        // Execute sequentially (PHP doesn't have native parallelism)
        // For parallel: use amphp/parallel or Swoole coroutines
        foreach ($nextNodes as $node) {
            $this->executeNode($flow, $execution, $node);
        }

        $newlyCompleted = [];
        foreach ($nextNodes as $node) {
            if (($execution['stepStatuses'][$node->nodeId]['status'] ?? '') === 'completed') {
                $newlyCompleted[] = $node->nodeId;
            }
        }

        if (!empty($newlyCompleted) && $execution['status'] === 'running') {
            $this->executeNextNodes($flow, $execution, $newlyCompleted);
        }
    }

    private function executeNode(FlowDefinition $flow, array &$execution, FlowNode $node): void {
        $step = &$execution['stepStatuses'][$node->nodeId];
        $step['status'] = 'running';
        $step['startedAt'] = date('c');
        $this->saveExecution($execution);

        $start = microtime(true);

        try {
            $context = new StepExecutionContext(
                traceId: $execution['traceId'],
                stepId: $node->nodeId,
                nodeType: $node->type->value,
                input: $this->gatherInput($flow, $execution, $node),
                configuration: $node->configuration,
                previousStepOutputs: $execution['stepOutputs'],
            );

            $executor = $this->executors[$node->type->value] ?? null;
            if (!$executor) {
                throw new \RuntimeException("No executor for: {$node->type->value}");
            }

            $result = $executor->execute($context);
            $duration = microtime(true) - $start;

            if ($result->success) {
                $step['status'] = 'completed';
                $step['output'] = $result->output;
                $execution['stepOutputs'][$node->nodeId] = $result->output;

                // Store debug data
                $this->db->store('debug-traces', 'xiigen', Uuid::uuid4()->toString(), [
                    'traceId' => $execution['traceId'], 'stepId' => $node->nodeId,
                    'nodeType' => $node->type->value, 'input' => $context->input,
                    'output' => $result->output, 'duration' => $duration,
                ]);
            } else {
                $step['status'] = 'failed';
                $step['error'] = $result->error;
                $execution['status'] = 'failed';
                $execution['error'] = "Step {$node->name} failed: {$result->error}";
            }
        } catch (\Throwable $e) {
            $step['status'] = 'failed';
            $step['error'] = $e->getMessage();
            $execution['status'] = 'failed';
            $execution['error'] = "Step {$node->name}: {$e->getMessage()}";
        }

        $step['completedAt'] = date('c');
        $this->saveExecution($execution);
    }

    private function getNextNodes(FlowDefinition $flow, array $completedIds, array $execution): array {
        $result = [];
        foreach ($completedIds as $cid) {
            foreach ($flow->edges as $edge) {
                if ($edge->sourceNodeId !== $cid) continue;
                $target = $execution['stepStatuses'][$edge->targetNodeId] ?? null;
                if ($target && $target['status'] !== 'draft') continue;

                $allReady = true;
                foreach ($flow->edges as $e) {
                    if ($e->targetNodeId !== $edge->targetNodeId) continue;
                    $src = $execution['stepStatuses'][$e->sourceNodeId] ?? null;
                    if (!$src || $src['status'] !== 'completed') { $allReady = false; break; }
                }

                if ($allReady) {
                    foreach ($flow->nodes as $node) {
                        if ($node->nodeId === $edge->targetNodeId) {
                            $exists = false;
                            foreach ($result as $r) { if ($r->nodeId === $node->nodeId) { $exists = true; break; } }
                            if (!$exists) $result[] = $node;
                            break;
                        }
                    }
                }
            }
        }
        return $result;
    }

    private function gatherInput(FlowDefinition $flow, array $execution, FlowNode $node): mixed {
        $inputs = [];
        foreach ($flow->edges as $edge) {
            if ($edge->targetNodeId === $node->nodeId && isset($execution['stepOutputs'][$edge->sourceNodeId])) {
                $inputs[$edge->sourceNodeId] = $execution['stepOutputs'][$edge->sourceNodeId];
            }
        }
        return count($inputs) === 1 ? reset($inputs) : $inputs;
    }

    private function saveExecution(array $execution): void {
        $this->db->store('flow-executions', 'xiigen', $execution['traceId'], $execution);
    }

    public function getExecution(string $traceId): ?array {
        return $this->activeFlows[$traceId] ?? null;
    }

    public function resume(string $traceId, FlowDefinition $flow): ?array {
        $execution = $this->getExecution($traceId);
        if (!$execution || $execution['status'] === 'completed') return $execution;
        $execution['status'] = 'running';
        $completed = array_keys(array_filter(
            $execution['stepStatuses'], fn($s) => $s['status'] === 'completed'
        ));
        $this->executeNextNodes($flow, $execution, $completed);
        return $execution;
    }
}
