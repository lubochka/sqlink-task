---
name: flow-orchestrator
description: Core DAG execution engine with topological traversal, parallel fan-out/fan-in, state checkpointing, and resume capability
triggers: flow orchestrator, execute flow, run pipeline, DAG execution, parallel execution, resume flow
dependencies: [01-core-interfaces, 02-object-processor, 03-elasticsearch-datastore, 04-redis-queue-service, 05-database-fabric, 08-flow-definition]
layer: L3-FlowEngine
genie-dna: Flow execution state stored as dynamic documents. All step outputs are schema-free. Uses MicroserviceBase for DB/queue/cache access.
phase: 2
---

# Skill 09: Flow Orchestrator
## The Core Execution Engine — DAG Traversal, State Persistence, Resume

The **brain** of XIIGen. Takes a FlowDefinition (from Skill 08) and executes it step by step through the DAG. Manages parallel fan-out (Split nodes), fan-in (Merge/wait-for-all), state persistence after every step, and resume from last checkpoint.

---

## Architecture

```
Client → API Gateway (Skill 15)
           ↓ POST /api/flow/trigger {flowId, body, traceId}
       FlowOrchestrator
           ↓ TriggerFlowAsync(flow, input, traceId)
           ↓ Creates FlowExecution → saves to ES
           ↓ Marks trigger nodes complete
           ↓ Calls ExecuteNextNodesAsync() recursively
               ↓ GetNextNodes() — finds ready nodes (all inputs satisfied)
               ↓ ExecuteNodeAsync() — per node:
                   ↓ Builds StepExecutionContext (input, config, previous outputs)
                   ↓ Finds IStepExecutor by NodeType
                   ↓ Executes with timeout
                   ↓ Saves NodeDebugData (Skill 14)
                   ↓ Updates execution state → saves to ES
               ↓ Parallel nodes via Task.WhenAll / Promise.all
               ↓ Recurse until no more ready nodes
           ↓ Sets FinalResult from last completed node
       Client ← polls GET /api/flow/{traceId}/status
```

## Key Concepts

### DAG Traversal
- Topological order is implicit — a node becomes "ready" when ALL its incoming edges have completed sources
- No explicit topological sort needed — the recursive `GetNextNodes()` achieves the same

### Parallel Execution (Fan-Out / Fan-In)
- **Fan-Out:** When multiple edges leave a single node, all targets become ready simultaneously → executed in parallel via Task.WhenAll
- **Fan-In:** A node with multiple incoming edges only becomes ready when ALL source nodes are completed

### State Checkpointing
- After EVERY step execution (success or failure), the full FlowExecution is saved to Elasticsearch
- This enables resume from any interruption point
- Active flows are also held in memory (ConcurrentDictionary) for fast polling

### Resume
- `ResumeAsync(traceId, flow)` loads last saved state
- Finds all completed nodes → calls `ExecuteNextNodesAsync()` with those as "just completed"
- Skips already-completed nodes automatically

### Step Executors
- Each NodeType maps to an `IStepExecutor` implementation
- Executors are registered at startup: `orchestrator.RegisterExecutor(executor)`
- Executor receives `StepExecutionContext` with input, config, and all previous outputs
- Returns `StepResult` with output + optional debug data

## IStepExecutor Interface

```csharp
public interface IStepExecutor
{
    string NodeTypeName { get; }
    Task<StepResult> ExecuteAsync(StepExecutionContext context, CancellationToken ct);
}

public class StepExecutionContext
{
    public string TraceId { get; set; }
    public string StepId { get; set; }
    public string NodeType { get; set; }
    public object Input { get; set; }
    public Dictionary<string, object> Configuration { get; set; }
    public Dictionary<string, object> PreviousStepOutputs { get; set; }
}

public class StepResult
{
    public bool Success { get; set; }
    public object Output { get; set; }
    public string Error { get; set; }
    public Dictionary<string, object> DebugData { get; set; }
}
```

## Configuration

```json
{
  "FlowOrchestrator": {
    "DefaultTimeoutSeconds": 300,
    "MaxParallelNodes": 10,
    "CheckpointIndex": "flow-executions",
    "DebugIndex": "debug-traces",
    "RetryDelayMs": 1000
  }
}
```

## API

| Method | Description |
|---|---|
| `RegisterExecutor(IStepExecutor)` | Register step executor for a NodeType |
| `TriggerFlowAsync(flow, input, traceId)` | Start new flow execution |
| `GetExecutionAsync(traceId)` | Get current execution state (memory → ES fallback) |
| `ResumeAsync(traceId, flow)` | Resume from last checkpoint |
| `CancelAsync(traceId)` | Cancel running execution |

## Genie DNA Application

- FlowExecution stored as dynamic document — arbitrary metadata and step outputs
- StepOutputs dict is schema-free — each step can output any structure
- Uses ObjectProcessor for serialization/deserialization of dynamic state
- MicroserviceBase provides `StoreDocumentAsync` / `GetDocumentAsync` with built-in error handling

## Error Handling

- Per-step: timeout → CancellationToken, exception → catch + mark Failed
- Per-flow: any step failure → flow status = Failed (configurable: fail-fast vs continue)
- Retry: configurable per node (maxRetries) with exponential backoff
- Dead letter: failed messages moved to dead letter queue for manual review

## Test Scenarios

1. Linear flow (3 nodes) → executes in order, returns final output
2. Parallel fan-out (1→3→1) → all 3 execute concurrently, merge waits
3. Step failure → flow marked Failed, error propagated
4. Step timeout → caught, flow marked Failed
5. Resume after interruption → continues from checkpoint
6. Unknown executor → throws clear error
