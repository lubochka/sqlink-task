// XIIGen.FlowEngine/FlowOrchestrator.cs - Skill 09 | .NET 9
using System.Collections.Concurrent;
using System.Diagnostics;
using Microsoft.Extensions.Logging;
using XIIGen.Core.Base;
using XIIGen.Core.Enums;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;
using XIIGen.FlowEngine.Models;

namespace XIIGen.FlowEngine;

public class FlowOrchestrator : MicroserviceBase
{
    private readonly Dictionary<string, IStepExecutor> _executors = [];
    private readonly ConcurrentDictionary<string, FlowExecution> _activeFlows = new();

    public FlowOrchestrator(IDatabaseService db, IQueueService queue, ILogger<FlowOrchestrator> logger,
        ICacheService cache = null, IObjectProcessor processor = null)
        : base(db, queue, logger, cache, objectProcessor: processor)
    {
        ServiceName = "flow-orchestrator";
    }

    public void RegisterExecutor(IStepExecutor executor) => _executors[executor.NodeTypeName] = executor;

    // ─── Trigger a Flow ─────────────────────────────
    public async Task<FlowExecution> TriggerFlowAsync(FlowDefinition flow, object input, string traceId = null, CancellationToken ct = default)
    {
        var execution = new FlowExecution
        {
            TraceId = traceId ?? Guid.NewGuid().ToString(),
            FlowId = flow.FlowId,
            Input = input,
            Status = FlowStatus.Running
        };

        // Initialize all step statuses
        foreach (var node in flow.Nodes)
        {
            execution.StepStatuses[node.NodeId] = new StepStatus
            {
                StepId = node.NodeId, NodeType = node.Type.ToString(), Status = FlowStatus.Draft
            };
        }

        // Persist initial state
        await SaveExecutionAsync(execution, ct);
        _activeFlows[execution.TraceId] = execution;

        // Start execution from trigger nodes
        var triggerNodes = flow.Nodes.Where(n => n.Type == NodeType.Trigger).ToList();
        foreach (var trigger in triggerNodes)
        {
            execution.StepStatuses[trigger.NodeId].Status = FlowStatus.Completed;
            execution.StepStatuses[trigger.NodeId].StartedAt = DateTime.UtcNow;
            execution.StepStatuses[trigger.NodeId].CompletedAt = DateTime.UtcNow;
            execution.StepStatuses[trigger.NodeId].Output = input;
            execution.StepOutputs[trigger.NodeId] = input;
        }

        // Execute next nodes in the DAG
        await ExecuteNextNodesAsync(flow, execution, triggerNodes.Select(t => t.NodeId).ToList(), ct);

        return execution;
    }

    // ─── DAG Traversal & Execution ──────────────────
    private async Task ExecuteNextNodesAsync(FlowDefinition flow, FlowExecution execution, List<string> completedNodeIds, CancellationToken ct)
    {
        var nextNodes = GetNextNodes(flow, completedNodeIds, execution);

        if (nextNodes.Count == 0)
        {
            // No more nodes - flow is complete
            execution.Status = FlowStatus.Completed;
            execution.CompletedAt = DateTime.UtcNow;
            // Last completed node's output is the final result
            var lastCompleted = execution.StepStatuses.Values
                .Where(s => s.Status == FlowStatus.Completed)
                .OrderByDescending(s => s.CompletedAt)
                .FirstOrDefault();
            execution.FinalResult = lastCompleted?.Output;
            await SaveExecutionAsync(execution, ct);
            return;
        }

        // Execute all ready nodes (parallel if multiple)
        var tasks = nextNodes.Select(node => ExecuteNodeAsync(flow, execution, node, ct));
        await Task.WhenAll(tasks);

        // After all parallel nodes complete, find newly completed and continue
        var newlyCompleted = nextNodes.Where(n => execution.StepStatuses[n.NodeId].Status == FlowStatus.Completed)
            .Select(n => n.NodeId).ToList();

        if (newlyCompleted.Count > 0 && execution.Status == FlowStatus.Running)
            await ExecuteNextNodesAsync(flow, execution, newlyCompleted, ct);
    }

    private async Task ExecuteNodeAsync(FlowDefinition flow, FlowExecution execution, FlowNode node, CancellationToken ct)
    {
        var stepStatus = execution.StepStatuses[node.NodeId];
        stepStatus.Status = FlowStatus.Running;
        stepStatus.StartedAt = DateTime.UtcNow;
        execution.CurrentStepId = node.NodeId;
        await SaveExecutionAsync(execution, ct);

        var sw = Stopwatch.StartNew();

        try
        {
            // Build execution context
            var context = new StepExecutionContext
            {
                TraceId = execution.TraceId,
                StepId = node.NodeId,
                NodeType = node.Type.ToString(),
                Input = GatherInputForNode(flow, execution, node),
                Configuration = node.Configuration,
                PreviousStepOutputs = execution.StepOutputs
            };

            // Find and execute the step executor
            var executorKey = node.Type.ToString();
            if (!_executors.TryGetValue(executorKey, out var executor))
            {
                throw new InvalidOperationException($"No executor registered for node type '{executorKey}'");
            }

            // Execute with timeout
            using var cts = CancellationTokenSource.CreateLinkedTokenSource(ct);
            cts.CancelAfter(TimeSpan.FromSeconds(node.TimeoutSeconds));

            var result = await executor.ExecuteAsync(context, cts.Token);
            sw.Stop();

            if (result.Success)
            {
                stepStatus.Status = FlowStatus.Completed;
                stepStatus.Output = result.Output;
                execution.StepOutputs[node.NodeId] = result.Output;

                // Store debug data
                var debug = new NodeDebugData
                {
                    TraceId = execution.TraceId, StepId = node.NodeId, NodeType = node.Type.ToString(),
                    Input = context.Input, Output = result.Output, Duration = sw.Elapsed,
                    IntermediateData = result.DebugData
                };
                await StoreDocumentAsync("debug-traces", debug.DebugId, debug, ct: ct);
            }
            else
            {
                stepStatus.Status = FlowStatus.Failed;
                stepStatus.Error = result.Error;
                execution.Status = FlowStatus.Failed;
                execution.Error = $"Step {node.Name} failed: {result.Error}";
            }
        }
        catch (OperationCanceledException)
        {
            stepStatus.Status = FlowStatus.Failed;
            stepStatus.Error = "Timeout";
            execution.Status = FlowStatus.Failed;
            execution.Error = $"Step {node.Name} timed out after {node.TimeoutSeconds}s";
        }
        catch (Exception ex)
        {
            stepStatus.Status = FlowStatus.Failed;
            stepStatus.Error = ex.Message;
            execution.Status = FlowStatus.Failed;
            execution.Error = $"Step {node.Name} error: {ex.Message}";
            await LogErrorAsync($"Node execution failed: {node.Name}", ex);
        }

        stepStatus.CompletedAt = DateTime.UtcNow;
        await SaveExecutionAsync(execution, ct);
    }

    // ─── DAG Helpers ────────────────────────────────
    private List<FlowNode> GetNextNodes(FlowDefinition flow, List<string> completedNodeIds, FlowExecution execution)
    {
        var next = new List<FlowNode>();
        foreach (var completedId in completedNodeIds)
        {
            var outEdges = flow.Edges.Where(e => e.SourceNodeId == completedId);
            foreach (var edge in outEdges)
            {
                if (execution.StepStatuses.TryGetValue(edge.TargetNodeId, out var status) && status.Status != FlowStatus.Draft) continue;

                // Check all incoming edges are satisfied
                var incomingEdges = flow.Edges.Where(e => e.TargetNodeId == edge.TargetNodeId);
                var allInputsReady = incomingEdges.All(e =>
                    execution.StepStatuses.TryGetValue(e.SourceNodeId, out var s) && s.Status == FlowStatus.Completed);

                if (allInputsReady)
                {
                    var node = flow.Nodes.First(n => n.NodeId == edge.TargetNodeId);
                    if (!next.Any(n => n.NodeId == node.NodeId)) next.Add(node);
                }
            }
        }
        return next;
    }

    private object GatherInputForNode(FlowDefinition flow, FlowExecution execution, FlowNode node)
    {
        var incomingEdges = flow.Edges.Where(e => e.TargetNodeId == node.NodeId);
        var inputs = new Dictionary<string, object>();
        foreach (var edge in incomingEdges)
        {
            if (execution.StepOutputs.TryGetValue(edge.SourceNodeId, out var output))
                inputs[edge.SourceNodeId] = output;
        }
        return inputs.Count == 1 ? inputs.Values.First() : inputs;
    }

    // ─── State Persistence ──────────────────────────
    private Task SaveExecutionAsync(FlowExecution execution, CancellationToken ct)
        => StoreDocumentAsync("flow-executions", execution.TraceId, execution, ct: ct);

    public async Task<FlowExecution> GetExecutionAsync(string traceId, CancellationToken ct = default)
    {
        if (_activeFlows.TryGetValue(traceId, out var active)) return active;
        var result = await GetDocumentAsync("flow-executions", traceId, ct);
        return result.IsSuccess ? (FlowExecution)result.Data : null;
    }

    // ─── Resume from Checkpoint ─────────────────────
    public async Task<FlowExecution> ResumeAsync(string traceId, FlowDefinition flow, CancellationToken ct = default)
    {
        var execution = await GetExecutionAsync(traceId, ct);
        if (execution is null) return null;
        if (execution.Status == FlowStatus.Completed) return execution;

        execution.Status = FlowStatus.Running;
        var completed = execution.StepStatuses.Where(s => s.Value.Status == FlowStatus.Completed).Select(s => s.Key).ToList();
        await ExecuteNextNodesAsync(flow, execution, completed, ct);
        return execution;
    }
}
