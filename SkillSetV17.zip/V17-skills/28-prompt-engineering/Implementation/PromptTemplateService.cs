// XIIGen.Quality/PromptEngineering/PromptTemplateService.cs — Skill 28 | .NET 9
// MACHINE: Template engine (resolve, inject, chain, A/B test)
// FREEDOM: Template data is Dictionary<string, object> — schema-free
// DNA: ParseObjectAlternative, BuildSearchFilter, DataProcessResult, scope injection
// Reference: SKILL.md, GENIE_DNA_GUIDE.md, FREEDOM_MACHINE_GUIDE.md
using System.Collections.Concurrent;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Quality.PromptEngineering;

// ─── IPromptTemplateService: MACHINE interface ────────────────
// Template data is always Dictionary<string, object> — FREEDOM
// The service logic (resolve, chain, A/B) is MACHINE — built once
public interface IPromptTemplateService
{
    // CRUD — all template data is Dictionary<string, object>
    Task<DataProcessResult<string>> StoreTemplateAsync(
        Dictionary<string, object> templateDoc, CancellationToken ct = default);
    Task<DataProcessResult<Dictionary<string, object>>> GetTemplateAsync(
        string templateId, CancellationToken ct = default);
    Task<DataProcessResult<List<Dictionary<string, object>>>> SearchTemplatesAsync(
        Dictionary<string, object> filter, string userId, bool isAdmin = false,
        int size = 20, CancellationToken ct = default);
    Task<DataProcessResult<bool>> DeleteTemplateAsync(
        string templateId, string userId, CancellationToken ct = default);

    // Resolution — MACHINE logic
    Task<DataProcessResult<string>> ResolveAsync(
        string templateId, Dictionary<string, object> variables,
        string traceId, CancellationToken ct = default);
    Task<DataProcessResult<string>> ResolveWithFeedbackAsync(
        string templateId, Dictionary<string, object> variables,
        string traceId, int maxExamples = 3, CancellationToken ct = default);

    // Chaining — sequential template execution
    Task<DataProcessResult<List<Dictionary<string, object>>>> ExecuteChainAsync(
        List<string> templateIds, Dictionary<string, object> initialContext,
        string traceId, CancellationToken ct = default);

    // A/B Testing — parallel variant execution
    Task<DataProcessResult<Dictionary<string, object>>> RunABTestAsync(
        List<string> variantIds, Dictionary<string, object> testInput,
        string traceId, CancellationToken ct = default);

    // Best template by rating + usage
    Task<DataProcessResult<Dictionary<string, object>>> GetBestTemplateAsync(
        string category, string aiModel = null, CancellationToken ct = default);

    // Clone system template to user scope
    Task<DataProcessResult<string>> CloneToUserScopeAsync(
        string templateId, string userId, CancellationToken ct = default);

    // Seed built-in system templates
    Task<DataProcessResult<int>> SeedSystemTemplatesAsync(CancellationToken ct = default);
}

// ─── PromptTemplateService: MACHINE implementation ────────────
public sealed class PromptTemplateService : IPromptTemplateService
{
    private const string TemplateIndex = "xiigen-prompt-templates";
    private const string ResultIndex = "xiigen-prompt-results";
    private static readonly Regex VarPattern = new(@"\{\{(\w+)\}\}", RegexOptions.Compiled);

    private readonly IDataStore _db;
    private readonly IObjectProcessor _processor;
    private readonly IFeedbackService _feedback;
    private readonly ILogger<PromptTemplateService> _logger;

    public PromptTemplateService(
        IDataStore db,
        IObjectProcessor processor,
        IFeedbackService feedback,
        ILogger<PromptTemplateService> logger)
    {
        _db = db;
        _processor = processor;
        _feedback = feedback;
        _logger = logger;
    }

    // ════════════════════════════════════════════════════════
    // CRUD — Template data is Dictionary<string,object> (FREEDOM)
    // ════════════════════════════════════════════════════════

    public async Task<DataProcessResult<string>> StoreTemplateAsync(
        Dictionary<string, object> templateDoc, CancellationToken ct = default)
    {
        try
        {
            // Genie DNA: ParseObjectAlternative — handle any shape
            var processed = _processor.ParseObjectAlternative(templateDoc);

            // Ensure MACHINE-required fields
            processed.TryAdd("id", Guid.NewGuid().ToString());
            processed.TryAdd("createdAt", DateTime.UtcNow);
            processed["updatedAt"] = DateTime.UtcNow;
            processed.TryAdd("version", 1);
            processed.TryAdd("usageCount", 0L);
            processed.TryAdd("avgRating", 0.0);
            processed.TryAdd("scope", "private");

            var id = processed["id"].ToString()!;
            var result = await _db.StoreAsync(TemplateIndex, id, processed, ct: ct);
            if (!result.IsSuccess)
                return DataProcessResult<string>.Fail($"Store failed: {result.Error}");

            _logger.LogInformation("[Skill28] Template stored: {Id} scope={Scope}",
                id, processed.GetValueOrDefault("scope"));
            return DataProcessResult<string>.Ok(id);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[Skill28] StoreTemplateAsync failed");
            return DataProcessResult<string>.Fail(ex.Message);
        }
    }

    public async Task<DataProcessResult<Dictionary<string, object>>> GetTemplateAsync(
        string templateId, CancellationToken ct = default)
    {
        try
        {
            return await _db.GetByIdAsync(TemplateIndex, templateId, ct);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[Skill28] GetTemplateAsync failed: {Id}", templateId);
            return DataProcessResult<Dictionary<string, object>>.Fail(ex.Message);
        }
    }

    public async Task<DataProcessResult<List<Dictionary<string, object>>>> SearchTemplatesAsync(
        Dictionary<string, object> filter, string userId, bool isAdmin = false,
        int size = 20, CancellationToken ct = default)
    {
        try
        {
            // Genie DNA Pattern 5: Scope injection
            var scopedFilter = InjectScope(filter, userId, isAdmin);

            // Genie DNA Pattern 2: BuildSearchFilter — skip empty values
            var searchFilter = _processor.BuildSearchFilter(scopedFilter);

            var result = await _db.SearchAsync(TemplateIndex, searchFilter, size, ct: ct);
            if (!result.IsSuccess)
                return DataProcessResult<List<Dictionary<string, object>>>.Fail(result.Error);

            return DataProcessResult<List<Dictionary<string, object>>>.Ok(result.Data);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[Skill28] SearchTemplatesAsync failed");
            return DataProcessResult<List<Dictionary<string, object>>>.Fail(ex.Message);
        }
    }

    public async Task<DataProcessResult<bool>> DeleteTemplateAsync(
        string templateId, string userId, CancellationToken ct = default)
    {
        try
        {
            var existing = await _db.GetByIdAsync(TemplateIndex, templateId, ct);
            if (!existing.IsSuccess)
                return DataProcessResult<bool>.Fail("Template not found");

            var ownerId = existing.Data.GetValueOrDefault("ownerId")?.ToString();
            var scope = existing.Data.GetValueOrDefault("scope")?.ToString();

            // System templates cannot be deleted by non-admins
            if (scope == "system")
                return DataProcessResult<bool>.Fail("Cannot delete system template");

            if (!string.IsNullOrEmpty(ownerId) && ownerId != userId)
                return DataProcessResult<bool>.Fail("Access denied: not the owner");

            return await _db.DeleteAsync(TemplateIndex, templateId, ct);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[Skill28] DeleteTemplateAsync failed: {Id}", templateId);
            return DataProcessResult<bool>.Fail(ex.Message);
        }
    }

    // ════════════════════════════════════════════════════════
    // RESOLUTION — MACHINE logic (variable substitution)
    // ════════════════════════════════════════════════════════

    public async Task<DataProcessResult<string>> ResolveAsync(
        string templateId, Dictionary<string, object> variables,
        string traceId, CancellationToken ct = default)
    {
        try
        {
            var templateResult = await GetTemplateAsync(templateId, ct);
            if (!templateResult.IsSuccess)
                return DataProcessResult<string>.Fail($"Template not found: {templateResult.Error}");

            var template = templateResult.Data;
            var resolved = ResolveTemplate(template, variables);

            // Track usage
            _ = IncrementUsageAsync(templateId, ct);
            _ = StoreResolutionRecord(templateId, traceId, variables, ct);

            return DataProcessResult<string>.Ok(resolved);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[Skill28] ResolveAsync failed: {Id}", templateId);
            return DataProcessResult<string>.Fail(ex.Message);
        }
    }

    public async Task<DataProcessResult<string>> ResolveWithFeedbackAsync(
        string templateId, Dictionary<string, object> variables,
        string traceId, int maxExamples = 3, CancellationToken ct = default)
    {
        try
        {
            var baseResult = await ResolveAsync(templateId, variables, traceId, ct);
            if (!baseResult.IsSuccess) return baseResult;

            // MACHINE: Inject feedback from Skill 13
            var feedbackXml = await BuildFeedbackContextAsync(templateId, maxExamples, ct);
            var prompt = string.IsNullOrEmpty(feedbackXml)
                ? baseResult.Data
                : $"{baseResult.Data}\n\n{feedbackXml}";

            return DataProcessResult<string>.Ok(prompt);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[Skill28] ResolveWithFeedbackAsync failed: {Id}", templateId);
            return DataProcessResult<string>.Fail(ex.Message);
        }
    }

    // ════════════════════════════════════════════════════════
    // CHAINING — Sequential template execution
    // ════════════════════════════════════════════════════════

    public async Task<DataProcessResult<List<Dictionary<string, object>>>> ExecuteChainAsync(
        List<string> templateIds, Dictionary<string, object> initialContext,
        string traceId, CancellationToken ct = default)
    {
        var results = new List<Dictionary<string, object>>();
        var context = new Dictionary<string, object>(initialContext);

        for (int i = 0; i < templateIds.Count; i++)
        {
            ct.ThrowIfCancellationRequested();
            var tid = templateIds[i];

            var resolved = await ResolveWithFeedbackAsync(tid, context, traceId, ct: ct);
            var stepResult = new Dictionary<string, object>
            {
                ["stepIndex"] = i,
                ["templateId"] = tid,
                ["success"] = resolved.IsSuccess,
                ["resolvedPrompt"] = resolved.IsSuccess ? resolved.Data : "",
                ["error"] = resolved.IsSuccess ? "" : resolved.Error,
                ["timestamp"] = DateTime.UtcNow,
                ["traceId"] = traceId
            };
            results.Add(stepResult);

            if (!resolved.IsSuccess)
            {
                _logger.LogWarning("[Skill28] Chain broken at step {Step} template {Id}: {Err}",
                    i, tid, resolved.Error);
                break;
            }

            // Feed output to next step
            context["previousOutput"] = resolved.Data;
            context["previousTemplateId"] = tid;
            context[$"step{i}_output"] = resolved.Data;
        }

        return DataProcessResult<List<Dictionary<string, object>>>.Ok(results);
    }

    // ════════════════════════════════════════════════════════
    // A/B TESTING — Parallel variant execution
    // ════════════════════════════════════════════════════════

    public async Task<DataProcessResult<Dictionary<string, object>>> RunABTestAsync(
        List<string> variantIds, Dictionary<string, object> testInput,
        string traceId, CancellationToken ct = default)
    {
        try
        {
            var tasks = variantIds.Select(async (id, idx) =>
            {
                var resolved = await ResolveWithFeedbackAsync(id, testInput, traceId, ct: ct);
                return (TemplateId: id, Index: idx, Result: resolved);
            });

            var outcomes = await Task.WhenAll(tasks);

            var variants = outcomes.Select(o => new Dictionary<string, object>
            {
                ["templateId"] = o.TemplateId,
                ["variantIndex"] = o.Index,
                ["success"] = o.Result.IsSuccess,
                ["prompt"] = o.Result.IsSuccess ? o.Result.Data : "",
                ["error"] = o.Result.IsSuccess ? "" : o.Result.Error
            }).ToList();

            var abResult = new Dictionary<string, object>
            {
                ["id"] = $"ab-{traceId}",
                ["traceId"] = traceId,
                ["testInput"] = testInput,
                ["variants"] = variants,
                ["status"] = "awaiting_feedback",
                ["createdAt"] = DateTime.UtcNow
            };

            await _db.StoreAsync(ResultIndex, abResult["id"].ToString()!, abResult, ct: ct);
            return DataProcessResult<Dictionary<string, object>>.Ok(abResult);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[Skill28] RunABTestAsync failed");
            return DataProcessResult<Dictionary<string, object>>.Fail(ex.Message);
        }
    }

    // ════════════════════════════════════════════════════════
    // BEST TEMPLATE SELECTION
    // ════════════════════════════════════════════════════════

    public async Task<DataProcessResult<Dictionary<string, object>>> GetBestTemplateAsync(
        string category, string aiModel = null, CancellationToken ct = default)
    {
        try
        {
            var filter = new Dictionary<string, object> { ["category"] = category };
            if (!string.IsNullOrEmpty(aiModel)) filter["aiModel"] = aiModel;

            // BuildSearchFilter skips empty → only non-empty fields used
            var searchFilter = _processor.BuildSearchFilter(filter);
            var result = await _db.SearchAsync(TemplateIndex, searchFilter, 1,
                sortBy: "avgRating", sortOrder: "desc", ct: ct);

            if (!result.IsSuccess || result.Data.Count == 0)
                return DataProcessResult<Dictionary<string, object>>.Fail("No templates found");

            return DataProcessResult<Dictionary<string, object>>.Ok(result.Data[0]);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[Skill28] GetBestTemplateAsync failed");
            return DataProcessResult<Dictionary<string, object>>.Fail(ex.Message);
        }
    }

    // ════════════════════════════════════════════════════════
    // CLONE TO USER SCOPE
    // ════════════════════════════════════════════════════════

    public async Task<DataProcessResult<string>> CloneToUserScopeAsync(
        string templateId, string userId, CancellationToken ct = default)
    {
        try
        {
            var existing = await GetTemplateAsync(templateId, ct);
            if (!existing.IsSuccess) return DataProcessResult<string>.Fail(existing.Error);

            var clone = new Dictionary<string, object>(existing.Data)
            {
                ["id"] = Guid.NewGuid().ToString(),
                ["ownerId"] = userId,
                ["scope"] = "private",
                ["clonedFrom"] = templateId,
                ["createdAt"] = DateTime.UtcNow,
                ["updatedAt"] = DateTime.UtcNow,
                ["version"] = 1,
                ["usageCount"] = 0L,
                ["avgRating"] = 0.0
            };
            return await StoreTemplateAsync(clone, ct);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[Skill28] CloneToUserScopeAsync failed: {Id}", templateId);
            return DataProcessResult<string>.Fail(ex.Message);
        }
    }

    // ════════════════════════════════════════════════════════
    // SEED SYSTEM TEMPLATES
    // ════════════════════════════════════════════════════════

    public async Task<DataProcessResult<int>> SeedSystemTemplatesAsync(CancellationToken ct = default)
    {
        var templates = BuildSystemTemplates();
        int seeded = 0;
        foreach (var template in templates)
        {
            template["scope"] = "system";
            template["ownerId"] = "system";
            var result = await StoreTemplateAsync(template, ct);
            if (result.IsSuccess) seeded++;
        }
        _logger.LogInformation("[Skill28] Seeded {Count} system templates", seeded);
        return DataProcessResult<int>.Ok(seeded);
    }

    // ════════════════════════════════════════════════════════
    // PRIVATE HELPERS
    // ════════════════════════════════════════════════════════

    /// <summary>Resolves {{variables}} in system+user prompt from template doc</summary>
    private string ResolveTemplate(Dictionary<string, object> template, Dictionary<string, object> variables)
    {
        var systemPrompt = GetStringField(template, "systemPrompt");
        var userPattern = GetStringField(template, "userPromptPattern");

        var resolvedSystem = ResolveVariables(systemPrompt, variables);
        var resolvedUser = ResolveVariables(userPattern, variables);

        return $"[SYSTEM]\n{resolvedSystem}\n\n[USER]\n{resolvedUser}";
    }

    private static string ResolveVariables(string text, Dictionary<string, object> variables)
    {
        if (string.IsNullOrEmpty(text)) return text;
        return VarPattern.Replace(text, match =>
        {
            var key = match.Groups[1].Value;
            if (variables.TryGetValue(key, out var value))
            {
                return value switch
                {
                    string s => s,
                    JsonElement je => je.ToString(),
                    _ => value?.ToString() ?? match.Value
                };
            }
            return match.Value; // Keep unresolved
        });
    }

    /// <summary>Genie DNA Pattern 5: Scope injection for multi-tenancy</summary>
    private static Dictionary<string, object> InjectScope(
        Dictionary<string, object> filter, string userId, bool isAdmin)
    {
        var scoped = new Dictionary<string, object>(filter);
        if (!isAdmin && !string.IsNullOrEmpty(userId))
        {
            // User sees: own templates + system + public
            // BuildSearchFilter handles the OR logic via _scope_userId
            scoped["_scope_userId"] = userId;
        }
        return scoped;
    }

    /// <summary>Build feedback XML context from Skill 13</summary>
    private async Task<string> BuildFeedbackContextAsync(
        string templateId, int maxExamples, CancellationToken ct)
    {
        try
        {
            var positives = await _feedback.GetFeedbackAsync(
                templateId, minRating: 4, limit: maxExamples, ct: ct);
            var negatives = await _feedback.GetFeedbackAsync(
                templateId, maxRating: 2, limit: maxExamples, ct: ct);

            bool hasPositive = positives.IsSuccess && positives.Data?.Count > 0;
            bool hasNegative = negatives.IsSuccess && negatives.Data?.Count > 0;
            if (!hasPositive && !hasNegative) return "";

            var sb = new StringBuilder();
            sb.AppendLine("<xiigen-context>");

            if (hasPositive)
            {
                sb.AppendLine("  <positive-examples>");
                foreach (var ex in positives.Data!)
                {
                    var rating = GetStringField(ex, "rating", "5");
                    var output = GetStringField(ex, "output");
                    sb.AppendLine($"    <example rating=\"{rating}\">{Truncate(output, 500)}</example>");
                }
                sb.AppendLine("  </positive-examples>");
            }

            if (hasNegative)
            {
                sb.AppendLine("  <negative-examples>");
                foreach (var ex in negatives.Data!)
                {
                    var rating = GetStringField(ex, "rating", "1");
                    var feedback = GetStringField(ex, "feedback");
                    var output = GetStringField(ex, "output");
                    sb.AppendLine($"    <example rating=\"{rating}\" feedback=\"{feedback}\">{Truncate(output, 300)}</example>");
                }
                sb.AppendLine("  </negative-examples>");
            }

            sb.AppendLine("</xiigen-context>");
            return sb.ToString();
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "[Skill28] BuildFeedbackContext failed for {Id}", templateId);
            return "";
        }
    }

    private async Task IncrementUsageAsync(string templateId, CancellationToken ct)
    {
        try
        {
            var t = await GetTemplateAsync(templateId, ct);
            if (!t.IsSuccess) return;
            var count = Convert.ToInt64(t.Data.GetValueOrDefault("usageCount", 0L));
            t.Data["usageCount"] = count + 1;
            t.Data["lastUsedAt"] = DateTime.UtcNow;
            await _db.StoreAsync(TemplateIndex, templateId, t.Data, ct: ct);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "[Skill28] IncrementUsage failed: {Id}", templateId);
        }
    }

    private async Task StoreResolutionRecord(
        string templateId, string traceId,
        Dictionary<string, object> variables, CancellationToken ct)
    {
        try
        {
            var record = new Dictionary<string, object>
            {
                ["id"] = $"res-{traceId}-{templateId}",
                ["templateId"] = templateId,
                ["traceId"] = traceId,
                ["variables"] = variables,
                ["resolvedAt"] = DateTime.UtcNow,
                ["status"] = "resolved"
            };
            await _db.StoreAsync(ResultIndex, record["id"].ToString()!, record, ct: ct);
        }
        catch { /* fire-and-forget telemetry */ }
    }

    // ════════════════════════════════════════════════════════
    // BUILT-IN SYSTEM TEMPLATES (FREEDOM data, seeded once)
    // ════════════════════════════════════════════════════════

    private static List<Dictionary<string, object>> BuildSystemTemplates()
    {
        return
        [
            new() {
                ["id"] = "sys-figma-parse", ["templateName"] = "figma-parse",
                ["category"] = "parsing", ["aiModel"] = "claude-sonnet-4-5-20250929",
                ["systemPrompt"] = "You are a senior frontend engineer converting Figma designs to semantic HTML/CSS. Use semantic HTML5, flexbox/grid for auto-layout, CSS custom properties for tokens, ARIA for accessibility.",
                ["userPromptPattern"] = "Convert this Figma node tree to HTML+CSS:\n\n<figma_input>\n{{figma_nodes}}\n</figma_input>\n\nTarget tech: {{target_framework}}\nDesign tokens: {{design_tokens}}",
                ["variables"] = new List<Dictionary<string, object>> {
                    new() { ["name"] = "figma_nodes", ["type"] = "text", ["required"] = true },
                    new() { ["name"] = "target_framework", ["type"] = "text", ["default"] = "react" },
                    new() { ["name"] = "design_tokens", ["type"] = "text", ["default"] = "{}" }
                },
                ["outputFormat"] = "json"
            },
            new() {
                ["id"] = "sys-code-gen", ["templateName"] = "code-generation",
                ["category"] = "generation", ["aiModel"] = "claude-sonnet-4-5-20250929",
                ["systemPrompt"] = "You are a production-grade code generator. Follow SOLID principles, handle errors comprehensively, include logging, and respect the target architecture.",
                ["userPromptPattern"] = "Generate {{language}} code for:\n\n{{specification}}\n\nArchitecture: {{architecture}}\nPatterns: {{design_patterns}}",
                ["variables"] = new List<Dictionary<string, object>> {
                    new() { ["name"] = "language", ["type"] = "text", ["required"] = true },
                    new() { ["name"] = "specification", ["type"] = "text", ["required"] = true },
                    new() { ["name"] = "architecture", ["type"] = "text" },
                    new() { ["name"] = "design_patterns", ["type"] = "text" }
                },
                ["outputFormat"] = "code"
            },
            new() {
                ["id"] = "sys-code-review", ["templateName"] = "code-review-standard",
                ["category"] = "review", ["aiModel"] = "claude-sonnet-4-5-20250929",
                ["systemPrompt"] = "You are an expert code reviewer. Check for bugs, performance, security, and best practices. Score severity: info/warning/error/critical.",
                ["userPromptPattern"] = "Review this {{language}} code:\n\n```{{language}}\n{{codeBlock}}\n```\n\nFocus: {{focusAreas}}\nMin severity: {{minSeverity}}",
                ["variables"] = new List<Dictionary<string, object>> {
                    new() { ["name"] = "language", ["type"] = "text", ["required"] = true },
                    new() { ["name"] = "codeBlock", ["type"] = "text", ["required"] = true },
                    new() { ["name"] = "focusAreas", ["type"] = "text", ["default"] = "all" },
                    new() { ["name"] = "minSeverity", ["type"] = "select", ["default"] = "warning" }
                },
                ["outputFormat"] = "json"
            },
            new() {
                ["id"] = "sys-test-gen", ["templateName"] = "test-generation",
                ["category"] = "testing", ["aiModel"] = "claude-sonnet-4-5-20250929",
                ["systemPrompt"] = "You are a testing expert. Generate comprehensive tests covering happy path, error cases, edge cases, and boundary conditions.",
                ["userPromptPattern"] = "Generate {{testFramework}} tests for:\n\n```{{language}}\n{{sourceCode}}\n```\n\nCoverage target: {{coverageTarget}}%\nTest style: {{testStyle}}",
                ["variables"] = new List<Dictionary<string, object>> {
                    new() { ["name"] = "testFramework", ["type"] = "text", ["required"] = true },
                    new() { ["name"] = "language", ["type"] = "text", ["required"] = true },
                    new() { ["name"] = "sourceCode", ["type"] = "text", ["required"] = true },
                    new() { ["name"] = "coverageTarget", ["type"] = "number", ["default"] = 80 },
                    new() { ["name"] = "testStyle", ["type"] = "select", ["default"] = "arrange-act-assert" }
                },
                ["outputFormat"] = "code"
            },
            new() {
                ["id"] = "sys-architecture", ["templateName"] = "architecture-analysis",
                ["category"] = "architecture", ["aiModel"] = "claude-sonnet-4-5-20250929",
                ["systemPrompt"] = "You are a system architect. Analyze screens/flows and produce architecture recommendations following microservice and event-driven patterns.",
                ["userPromptPattern"] = "Analyze these screens and produce an architecture:\n\n{{screen_descriptions}}\n\nTech stack: {{tech_stack}}\nScale: {{expected_scale}}",
                ["variables"] = new List<Dictionary<string, object>> {
                    new() { ["name"] = "screen_descriptions", ["type"] = "text", ["required"] = true },
                    new() { ["name"] = "tech_stack", ["type"] = "text" },
                    new() { ["name"] = "expected_scale", ["type"] = "text" }
                },
                ["outputFormat"] = "json"
            },
            new() {
                ["id"] = "sys-doc-gen", ["templateName"] = "documentation-generation",
                ["category"] = "documentation", ["aiModel"] = "claude-sonnet-4-5-20250929",
                ["systemPrompt"] = "You are a technical writer. Generate clear, well-structured documentation with examples, diagrams descriptions, and API references.",
                ["userPromptPattern"] = "Document this {{component_type}}:\n\n{{source}}\n\nAudience: {{audience}}\nFormat: {{doc_format}}",
                ["variables"] = new List<Dictionary<string, object>> {
                    new() { ["name"] = "component_type", ["type"] = "text", ["required"] = true },
                    new() { ["name"] = "source", ["type"] = "text", ["required"] = true },
                    new() { ["name"] = "audience", ["type"] = "text", ["default"] = "developers" },
                    new() { ["name"] = "doc_format", ["type"] = "select", ["default"] = "markdown" }
                },
                ["outputFormat"] = "markdown"
            }
        ];
    }

    // ─── Utility helpers ────

    private static string GetStringField(Dictionary<string, object> doc, string key, string fallback = "")
    {
        if (doc.TryGetValue(key, out var val))
        {
            return val switch
            {
                string s => s,
                JsonElement je => je.ToString(),
                _ => val?.ToString() ?? fallback
            };
        }
        return fallback;
    }

    private static string Truncate(string text, int maxLen) =>
        string.IsNullOrEmpty(text) || text.Length <= maxLen ? text : text[..maxLen] + "...";
}

// ─── DI Extension ────
public static class PromptEngineeringExtensions
{
    public static IServiceCollection AddPromptEngineering(this IServiceCollection services)
    {
        services.AddSingleton<IPromptTemplateService, PromptTemplateService>();
        return services;
    }
}
