<?php
// XIIGen Skill 28 — Prompt Template Service | PHP / Laravel
// Structured prompt templates with variable injection, feedback, and RAG context.

namespace XIIGen\Skills\PromptEngineering;

use XIIGen\Core\Interfaces\DatabaseService;
use XIIGen\Core\Interfaces\DataProcessResult;
use XIIGen\Core\Processor\ObjectProcessor;

class PromptTemplate {
    public function __construct(
        public string $id,
        public string $phase,
        public string $name,
        public int $version,
        public string $systemPrompt,
        public string $userPromptPattern,
        public array $variables = [],
        public string $outputFormat = '',
        public ?string $abVariant = null,
        public array $tags = [],
        public string $createdAt = '',
        public string $updatedAt = '',
    ) {
        $this->createdAt = $this->createdAt ?: date('c');
        $this->updatedAt = $this->updatedAt ?: date('c');
    }
}

class ResolvedPrompt {
    public function __construct(
        public string $templateId,
        public string $systemPrompt,
        public string $userPrompt,
        public array $resolvedVariables,
        public int $estimatedTokens,
    ) {}
}

class PromptChain {
    public function __construct(
        public string $id,
        public string $name,
        public array $steps,
        public array $passThroughVariables = [],
    ) {}
}

class PromptTemplateService {
    private const INDEX = 'xiigen-prompt-templates';
    private array $templates = [];
    private array $chains = [];

    public function __construct(private DatabaseService $db) {
        $this->registerBuiltins();
    }

    // ─── Registry ─────────────────────────────────
    public function register(PromptTemplate $template): void {
        $this->templates[$template->id] = $template;
    }

    public function registerChain(PromptChain $chain): void {
        $this->chains[$chain->id] = $chain;
    }

    public function get(string $templateId): ?PromptTemplate {
        return $this->templates[$templateId] ?? null;
    }

    // ─── Resolution ───────────────────────────────
    public function resolve(string $templateId, string $traceId, array $variables = []): DataProcessResult {
        $template = $this->templates[$templateId] ?? null;
        if (!$template) {
            return DataProcessResult::failure("Template '{$templateId}' not found");
        }
        try {
            $allVars = array_merge(['trace_id' => $traceId], $variables);
            $systemPrompt = $this->replaceVariables($template->systemPrompt, $allVars);
            $userPrompt = $this->replaceVariables($template->userPromptPattern, $allVars);
            $resolved = new ResolvedPrompt(
                $templateId, $systemPrompt, $userPrompt, $allVars,
                (int)ceil(mb_strlen($systemPrompt . $userPrompt) / 4)
            );
            return DataProcessResult::success($resolved);
        } catch (\Throwable $e) {
            return DataProcessResult::failure("Resolution failed: " . $e->getMessage());
        }
    }

    public function resolveChain(string $chainId, string $traceId, array $variables = []): DataProcessResult {
        $chain = $this->chains[$chainId] ?? null;
        if (!$chain) {
            return DataProcessResult::failure("Chain '{$chainId}' not found");
        }
        $results = [];
        $currentVars = $variables;
        foreach ($chain->steps as $stepId) {
            $result = $this->resolve($stepId, $traceId, $currentVars);
            if (!$result->success) {
                return DataProcessResult::failure("Chain step '{$stepId}' failed: {$result->error}");
            }
            $results[] = $result->data;
            foreach ($chain->passThroughVariables as $key) {
                if (isset($result->data->resolvedVariables[$key])) {
                    $currentVars[$key] = $result->data->resolvedVariables[$key];
                }
            }
        }
        return DataProcessResult::success($results);
    }

    // ─── Persistence ──────────────────────────────
    public function saveTemplate(PromptTemplate $template): DataProcessResult {
        $doc = ObjectProcessor::parseObjectAlternative((array)$template);
        $result = $this->db->upsert(self::INDEX, $template->id, $doc);
        return $result->success ? DataProcessResult::success($template) : DataProcessResult::failure($result->error);
    }

    public function queryTemplates(array $filter): DataProcessResult {
        $searchFilter = ObjectProcessor::buildSearchFilter($filter);
        return $this->db->query(self::INDEX, $searchFilter);
    }

    // ─── Helpers ──────────────────────────────────
    private function replaceVariables(string $text, array $vars): string {
        return preg_replace_callback('/\{\{(\w+)\}\}/', function ($m) use ($vars) {
            return $vars[$m[1]] ?? $m[0];
        }, $text);
    }

    // ─── Built-in Templates ───────────────────────
    private function registerBuiltins(): void {
        $this->register(new PromptTemplate('figma-parse', 'parsing', 'Figma to HTML/CSS', 1,
            "You are a senior frontend engineer converting Figma to semantic HTML/CSS.\n{{rag_context}}\n{{feedback_history}}",
            "Convert this Figma node to {{technology}} code:\n{{previous_output}}",
            [['name'=>'technology','type'=>'string','required'=>true,'default'=>'html-css']],
            'json:{ html, css, components }', null, ['figma','parsing']));
        $this->register(new PromptTemplate('code-generate', 'generation', 'Code Generation', 1,
            "You are a senior {{language}} developer. Generate production code.\n{{genie_dna}}\n{{rag_context}}\n{{feedback_history}}",
            "Generate {{language}} code for: {{previous_output}}",
            [['name'=>'language','type'=>'string','required'=>true,'default'=>'csharp']],
            'json:{ files, dependencies }', null, ['generation','code']));
        $this->register(new PromptTemplate('code-review', 'review', 'Code Review', 1,
            "You are a senior code reviewer. Evaluate quality, security, performance.\n{{rag_context}}\n{{feedback_history}}",
            "Review this {{language}} code:\n{{previous_output}}",
            [['name'=>'language','type'=>'string','required'=>true,'default'=>'csharp']],
            'json:{ score, issues, suggestions }', null, ['review','quality']));
        $this->register(new PromptTemplate('test-generate', 'testing', 'Test Generation', 1,
            "You are a QA engineer. Generate comprehensive tests. Target 80%+ coverage.\n{{rag_context}}\n{{feedback_history}}",
            "Generate {{language}} tests for:\n{{previous_output}}",
            [['name'=>'language','type'=>'string','required'=>true,'default'=>'php']],
            'json:{ testFiles, coverage }', null, ['testing','quality']));
    }
}
