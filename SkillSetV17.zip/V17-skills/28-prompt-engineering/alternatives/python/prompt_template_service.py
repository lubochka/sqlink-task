"""XIIGen Skill 28 — Prompt Template Service | Python
Structured prompt templates with variable injection, feedback, and RAG context.
"""
import re
import json
import math
from dataclasses import dataclass, field
from typing import Any, Optional
from datetime import datetime, timezone
from core_interfaces import DatabaseService, DataProcessResult
from object_processor import ObjectProcessor

@dataclass
class VariableDefinition:
    name: str
    var_type: str  # string, number, boolean, json
    required: bool
    default_value: Any = None
    description: str = ""

@dataclass
class PromptTemplate:
    id: str
    phase: str
    name: str
    version: int
    system_prompt: str
    user_prompt_pattern: str
    variables: list[VariableDefinition] = field(default_factory=list)
    output_format: str = ""
    ab_variant: Optional[str] = None
    tags: list[str] = field(default_factory=list)
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

@dataclass
class ResolvedPrompt:
    template_id: str
    system_prompt: str
    user_prompt: str
    resolved_variables: dict[str, str]
    estimated_tokens: int

@dataclass
class PromptChain:
    id: str
    name: str
    steps: list[str]  # template IDs in order
    pass_through_variables: list[str] = field(default_factory=list)

class PromptTemplateService:
    INDEX = "xiigen-prompt-templates"
    BUILTIN_VARS = [
        "trace_id", "step_id", "technology", "language",
        "rag_context", "feedback_history", "previous_output",
        "design_tokens", "genie_dna"
    ]

    def __init__(self, db: DatabaseService):
        self._db = db
        self._templates: dict[str, PromptTemplate] = {}
        self._chains: dict[str, PromptChain] = {}
        self._register_builtins()

    # ─── Registry ────────────────────────────────────
    def register(self, template: PromptTemplate) -> None:
        self._templates[template.id] = template

    def register_chain(self, chain: PromptChain) -> None:
        self._chains[chain.id] = chain

    def get(self, template_id: str) -> Optional[PromptTemplate]:
        return self._templates.get(template_id)

    # ─── Resolution ──────────────────────────────────
    async def resolve(
        self, template_id: str, trace_id: str,
        variables: dict[str, str] | None = None
    ) -> DataProcessResult[ResolvedPrompt]:
        template = self._templates.get(template_id)
        if not template:
            return DataProcessResult(success=False, error=f"Template '{template_id}' not found")
        try:
            all_vars = {"trace_id": trace_id, **(variables or {})}
            system_prompt = self._replace_variables(template.system_prompt, all_vars)
            user_prompt = self._replace_variables(template.user_prompt_pattern, all_vars)
            resolved = ResolvedPrompt(
                template_id=template_id,
                system_prompt=system_prompt,
                user_prompt=user_prompt,
                resolved_variables=all_vars,
                estimated_tokens=self._estimate_tokens(system_prompt + user_prompt),
            )
            return DataProcessResult(success=True, data=resolved)
        except Exception as e:
            return DataProcessResult(success=False, error=f"Resolution failed: {e}")

    async def resolve_chain(
        self, chain_id: str, trace_id: str,
        variables: dict[str, str] | None = None
    ) -> DataProcessResult[list[ResolvedPrompt]]:
        chain = self._chains.get(chain_id)
        if not chain:
            return DataProcessResult(success=False, error=f"Chain '{chain_id}' not found")
        results = []
        current_vars = dict(variables or {})
        for step_id in chain.steps:
            result = await self.resolve(step_id, trace_id, current_vars)
            if not result.success:
                return DataProcessResult(success=False, error=f"Chain step '{step_id}' failed: {result.error}")
            results.append(result.data)
            for key in chain.pass_through_variables:
                if key in result.data.resolved_variables:
                    current_vars[key] = result.data.resolved_variables[key]
        return DataProcessResult(success=True, data=results)

    # ─── Persistence ─────────────────────────────────
    async def save_template(self, template: PromptTemplate) -> DataProcessResult[PromptTemplate]:
        doc = ObjectProcessor.parse_object_alternative(template.__dict__)
        result = await self._db.upsert(self.INDEX, template.id, doc)
        if not result.success:
            return DataProcessResult(success=False, error=result.error)
        return DataProcessResult(success=True, data=template)

    async def query_templates(self, filter_obj: dict) -> DataProcessResult[list[PromptTemplate]]:
        search_filter = ObjectProcessor.build_search_filter(filter_obj)
        return await self._db.query(self.INDEX, search_filter)

    # ─── Helpers ─────────────────────────────────────
    def _replace_variables(self, text: str, vars_dict: dict[str, str]) -> str:
        def replacer(match):
            key = match.group(1)
            return vars_dict.get(key, match.group(0))
        return re.sub(r"\{\{(\w+)\}\}", replacer, text)

    @staticmethod
    def _estimate_tokens(text: str) -> int:
        return math.ceil(len(text) / 4)

    # ─── Built-in Templates ──────────────────────────
    def _register_builtins(self) -> None:
        self.register(PromptTemplate(
            id="figma-parse", phase="parsing", name="Figma Node to HTML/CSS", version=1,
            system_prompt="You are a senior frontend engineer converting Figma to semantic HTML/CSS.\n{{rag_context}}\n{{feedback_history}}",
            user_prompt_pattern="Convert this Figma node to {{technology}} code:\n{{previous_output}}",
            variables=[VariableDefinition("technology", "string", True, "html-css", "Target framework")],
            output_format="json:{ html, css, components }", tags=["figma", "parsing"],
        ))
        self.register(PromptTemplate(
            id="code-generate", phase="generation", name="Code Generation", version=1,
            system_prompt="You are a senior {{language}} developer. Generate production code.\n{{genie_dna}}\n{{rag_context}}\n{{feedback_history}}",
            user_prompt_pattern="Generate {{language}} code for: {{previous_output}}",
            variables=[VariableDefinition("language", "string", True, "csharp", "Target language")],
            output_format="json:{ files, dependencies }", tags=["generation", "code"],
        ))
        self.register(PromptTemplate(
            id="code-review", phase="review", name="Code Review", version=1,
            system_prompt="You are a senior code reviewer. Evaluate quality, security, performance.\n{{rag_context}}\n{{feedback_history}}",
            user_prompt_pattern="Review this {{language}} code:\n{{previous_output}}",
            variables=[VariableDefinition("language", "string", True, "csharp", "Code language")],
            output_format="json:{ score, issues, suggestions }", tags=["review", "quality"],
        ))
        self.register(PromptTemplate(
            id="test-generate", phase="testing", name="Test Generation", version=1,
            system_prompt="You are a QA engineer. Generate comprehensive tests. Target 80%+ coverage.\n{{rag_context}}\n{{feedback_history}}",
            user_prompt_pattern="Generate {{language}} tests for:\n{{previous_output}}",
            variables=[VariableDefinition("language", "string", True, "python", "Test language")],
            output_format="json:{ test_files, coverage }", tags=["testing", "quality"],
        ))
