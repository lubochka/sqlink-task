// XIIGen Skill 28 — Prompt Template Service | Rust
// Structured prompt templates with variable injection, feedback, and RAG context.

use std::collections::HashMap;
use std::sync::RwLock;
use serde::{Deserialize, Serialize};
use chrono::{DateTime, Utc};
use regex::Regex;
use crate::core_interfaces::{DatabaseService, DataProcessResult};
use crate::object_processor::ObjectProcessor;

// ─── Models ───────────────────────────────────────────
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VariableDefinition {
    pub name: String,
    pub var_type: String,
    pub required: bool,
    pub default_value: Option<serde_json::Value>,
    pub description: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PromptTemplate {
    pub id: String,
    pub phase: String,
    pub name: String,
    pub version: u32,
    pub system_prompt: String,
    pub user_prompt_pattern: String,
    pub variables: Vec<VariableDefinition>,
    pub output_format: String,
    pub ab_variant: Option<String>,
    pub tags: Vec<String>,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResolvedPrompt {
    pub template_id: String,
    pub system_prompt: String,
    pub user_prompt: String,
    pub resolved_variables: HashMap<String, String>,
    pub estimated_tokens: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PromptChain {
    pub id: String,
    pub name: String,
    pub steps: Vec<String>,
    pub pass_through_variables: Vec<String>,
}

// ─── Service ─────────────────────────────────────────
pub struct PromptTemplateService {
    templates: RwLock<HashMap<String, PromptTemplate>>,
    chains: RwLock<HashMap<String, PromptChain>>,
    db: Box<dyn DatabaseService>,
    var_regex: Regex,
}

const INDEX: &str = "xiigen-prompt-templates";

impl PromptTemplateService {
    pub fn new(db: Box<dyn DatabaseService>) -> Self {
        let service = Self {
            templates: RwLock::new(HashMap::new()),
            chains: RwLock::new(HashMap::new()),
            db,
            var_regex: Regex::new(r"\{\{(\w+)\}\}").unwrap(),
        };
        service.register_builtins();
        service
    }

    pub fn register(&self, template: PromptTemplate) {
        self.templates.write().unwrap().insert(template.id.clone(), template);
    }

    pub fn register_chain(&self, chain: PromptChain) {
        self.chains.write().unwrap().insert(chain.id.clone(), chain);
    }

    pub fn get(&self, template_id: &str) -> Option<PromptTemplate> {
        self.templates.read().unwrap().get(template_id).cloned()
    }

    pub async fn resolve(
        &self, template_id: &str, trace_id: &str,
        variables: Option<HashMap<String, String>>,
    ) -> DataProcessResult<ResolvedPrompt> {
        let templates = self.templates.read().unwrap();
        let template = match templates.get(template_id) {
            Some(t) => t.clone(),
            None => return DataProcessResult::failure(&format!("Template '{}' not found", template_id)),
        };
        drop(templates);

        let mut all_vars = variables.unwrap_or_default();
        all_vars.insert("trace_id".to_string(), trace_id.to_string());

        let system_prompt = self.replace_variables(&template.system_prompt, &all_vars);
        let user_prompt = self.replace_variables(&template.user_prompt_pattern, &all_vars);
        let estimated_tokens = (system_prompt.len() + user_prompt.len()) / 4 + 1;

        DataProcessResult::success(ResolvedPrompt {
            template_id: template_id.to_string(),
            system_prompt, user_prompt, resolved_variables: all_vars, estimated_tokens,
        })
    }

    pub async fn resolve_chain(
        &self, chain_id: &str, trace_id: &str,
        variables: Option<HashMap<String, String>>,
    ) -> DataProcessResult<Vec<ResolvedPrompt>> {
        let chains = self.chains.read().unwrap();
        let chain = match chains.get(chain_id) {
            Some(c) => c.clone(),
            None => return DataProcessResult::failure(&format!("Chain '{}' not found", chain_id)),
        };
        drop(chains);

        let mut results = Vec::new();
        let mut current_vars = variables.unwrap_or_default();

        for step_id in &chain.steps {
            let result = self.resolve(step_id, trace_id, Some(current_vars.clone())).await;
            match result.data {
                Some(ref resolved) => {
                    for key in &chain.pass_through_variables {
                        if let Some(val) = resolved.resolved_variables.get(key) {
                            current_vars.insert(key.clone(), val.clone());
                        }
                    }
                    results.push(resolved.clone());
                }
                None => return DataProcessResult::failure(&format!("Chain step '{}' failed", step_id)),
            }
        }
        DataProcessResult::success(results)
    }

    pub async fn save_template(&self, template: &PromptTemplate) -> DataProcessResult<()> {
        let doc = ObjectProcessor::parse_object_alternative(template);
        self.db.upsert(INDEX, &template.id, &doc).await
    }

    fn replace_variables(&self, text: &str, vars: &HashMap<String, String>) -> String {
        self.var_regex.replace_all(text, |caps: &regex::Captures| {
            let key = &caps[1];
            vars.get(key).cloned().unwrap_or_else(|| caps[0].to_string())
        }).to_string()
    }

    fn register_builtins(&self) {
        let now = Utc::now();
        self.register(PromptTemplate {
            id: "figma-parse".into(), phase: "parsing".into(), name: "Figma Node to HTML/CSS".into(),
            version: 1, system_prompt: "You are a senior frontend engineer converting Figma to semantic HTML/CSS.\n{{rag_context}}\n{{feedback_history}}".into(),
            user_prompt_pattern: "Convert this Figma node to {{technology}} code:\n{{previous_output}}".into(),
            variables: vec![VariableDefinition { name: "technology".into(), var_type: "string".into(), required: true, default_value: Some("html-css".into()), description: "Target framework".into() }],
            output_format: "json:{ html, css, components }".into(), ab_variant: None,
            tags: vec!["figma".into(), "parsing".into()], created_at: now, updated_at: now,
        });
        self.register(PromptTemplate {
            id: "code-generate".into(), phase: "generation".into(), name: "Code Generation".into(),
            version: 1, system_prompt: "You are a senior {{language}} developer. Generate production code.\n{{genie_dna}}\n{{rag_context}}\n{{feedback_history}}".into(),
            user_prompt_pattern: "Generate {{language}} code for: {{previous_output}}".into(),
            variables: vec![VariableDefinition { name: "language".into(), var_type: "string".into(), required: true, default_value: Some("csharp".into()), description: "Target language".into() }],
            output_format: "json:{ files, dependencies }".into(), ab_variant: None,
            tags: vec!["generation".into(), "code".into()], created_at: now, updated_at: now,
        });
    }
}
