// XIIGen Skill 28 — Prompt Template Service | Java / Spring Boot
// Structured prompt templates with variable injection, feedback, and RAG context.

package com.xiigen.skills.promptengineering;

import com.xiigen.core.interfaces.DatabaseService;
import com.xiigen.core.interfaces.DataProcessResult;
import com.xiigen.core.processor.ObjectProcessor;
import org.springframework.stereotype.Service;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
public class PromptTemplateService {
    private static final String INDEX = "xiigen-prompt-templates";
    private static final Pattern VAR_PATTERN = Pattern.compile("\\{\\{(\\w+)\\}\\}");

    private final Map<String, PromptTemplate> templates = new ConcurrentHashMap<>();
    private final Map<String, PromptChain> chains = new ConcurrentHashMap<>();
    private final DatabaseService db;

    public PromptTemplateService(DatabaseService db) {
        this.db = db;
        registerBuiltInTemplates();
    }

    // ─── Models ─────────────────────────────────────
    public record VariableDefinition(String name, String type, boolean required,
                                      Object defaultValue, String description) {}

    public record PromptTemplate(String id, String phase, String name, int version,
                                  String systemPrompt, String userPromptPattern,
                                  List<VariableDefinition> variables, String outputFormat,
                                  String abVariant, List<String> tags,
                                  Instant createdAt, Instant updatedAt) {}

    public record ResolvedPrompt(String templateId, String systemPrompt, String userPrompt,
                                  Map<String, String> resolvedVariables, int estimatedTokens) {}

    public record PromptChain(String id, String name, List<String> steps,
                               List<String> passThroughVariables) {}

    // ─── Registry ──────────────────────────────────
    public void register(PromptTemplate template) {
        templates.put(template.id(), template);
    }

    public void registerChain(PromptChain chain) {
        chains.put(chain.id(), chain);
    }

    public Optional<PromptTemplate> get(String templateId) {
        return Optional.ofNullable(templates.get(templateId));
    }

    // ─── Resolution ────────────────────────────────
    public DataProcessResult<ResolvedPrompt> resolve(String templateId, String traceId,
                                                      Map<String, String> variables) {
        var template = templates.get(templateId);
        if (template == null)
            return DataProcessResult.failure("Template '" + templateId + "' not found");
        try {
            var allVars = new HashMap<>(variables != null ? variables : Map.of());
            allVars.put("trace_id", traceId);

            String systemPrompt = replaceVariables(template.systemPrompt(), allVars);
            String userPrompt = replaceVariables(template.userPromptPattern(), allVars);

            var resolved = new ResolvedPrompt(templateId, systemPrompt, userPrompt,
                    allVars, estimateTokens(systemPrompt + userPrompt));
            return DataProcessResult.success(resolved);
        } catch (Exception e) {
            return DataProcessResult.failure("Resolution failed: " + e.getMessage());
        }
    }

    public DataProcessResult<List<ResolvedPrompt>> resolveChain(String chainId, String traceId,
                                                                  Map<String, String> variables) {
        var chain = chains.get(chainId);
        if (chain == null)
            return DataProcessResult.failure("Chain '" + chainId + "' not found");

        var results = new ArrayList<ResolvedPrompt>();
        var currentVars = new HashMap<>(variables != null ? variables : Map.of());

        for (String stepId : chain.steps()) {
            var result = resolve(stepId, traceId, currentVars);
            if (!result.isSuccess())
                return DataProcessResult.failure("Chain step '" + stepId + "' failed: " + result.getError());
            results.add(result.getData());
            for (String key : chain.passThroughVariables()) {
                String val = result.getData().resolvedVariables().get(key);
                if (val != null) currentVars.put(key, val);
            }
        }
        return DataProcessResult.success(results);
    }

    // ─── Persistence ────────────────────────────────
    public DataProcessResult<PromptTemplate> saveTemplate(PromptTemplate template) {
        var doc = ObjectProcessor.parseObjectAlternative(template);
        var result = db.upsert(INDEX, template.id(), doc);
        return result.isSuccess() ? DataProcessResult.success(template) : DataProcessResult.failure(result.getError());
    }

    public DataProcessResult<List<PromptTemplate>> queryTemplates(Map<String, Object> filter) {
        var searchFilter = ObjectProcessor.buildSearchFilter(filter);
        return db.query(INDEX, searchFilter);
    }

    // ─── Helpers ────────────────────────────────────
    private String replaceVariables(String text, Map<String, String> vars) {
        Matcher matcher = VAR_PATTERN.matcher(text);
        StringBuilder sb = new StringBuilder();
        while (matcher.find()) {
            String key = matcher.group(1);
            matcher.appendReplacement(sb, Matcher.quoteReplacement(vars.getOrDefault(key, matcher.group(0))));
        }
        matcher.appendTail(sb);
        return sb.toString();
    }

    private int estimateTokens(String text) {
        return (int) Math.ceil(text.length() / 4.0);
    }

    // ─── Built-in Templates ─────────────────────────
    private void registerBuiltInTemplates() {
        var now = Instant.now();
        register(new PromptTemplate("figma-parse", "parsing", "Figma Node to HTML/CSS", 1,
            "You are a senior frontend engineer converting Figma to semantic HTML/CSS.\n{{rag_context}}\n{{feedback_history}}",
            "Convert this Figma node to {{technology}} code:\n{{previous_output}}",
            List.of(new VariableDefinition("technology", "string", true, "html-css", "Target framework")),
            "json:{ html, css, components }", null, List.of("figma", "parsing"), now, now));

        register(new PromptTemplate("code-generate", "generation", "Code Generation", 1,
            "You are a senior {{language}} developer. Generate production code.\n{{genie_dna}}\n{{rag_context}}\n{{feedback_history}}",
            "Generate {{language}} code for: {{previous_output}}",
            List.of(new VariableDefinition("language", "string", true, "csharp", "Target language")),
            "json:{ files, dependencies }", null, List.of("generation", "code"), now, now));

        register(new PromptTemplate("code-review", "review", "Code Review", 1,
            "You are a senior code reviewer. Evaluate quality, security, performance.\n{{rag_context}}\n{{feedback_history}}",
            "Review this {{language}} code:\n{{previous_output}}",
            List.of(new VariableDefinition("language", "string", true, "csharp", "Code language")),
            "json:{ score, issues, suggestions }", null, List.of("review", "quality"), now, now));

        register(new PromptTemplate("test-generate", "testing", "Test Generation", 1,
            "You are a QA engineer. Generate comprehensive tests. Target 80%+ coverage.\n{{rag_context}}\n{{feedback_history}}",
            "Generate {{language}} tests for:\n{{previous_output}}",
            List.of(new VariableDefinition("language", "string", true, "java", "Test language")),
            "json:{ testFiles, coverage }", null, List.of("testing", "quality"), now, now));
    }
}
