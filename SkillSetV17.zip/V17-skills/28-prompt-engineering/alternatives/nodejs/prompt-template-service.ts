// XIIGen Skill 28 — Prompt Template Service | Node.js/TypeScript
// Structured prompt templates with variable injection, feedback, and RAG context.

import { DatabaseService, QueueService, DataProcessResult } from '../../01-core-interfaces';
import { ObjectProcessor } from '../../02-object-processor';

// ─── Models ───────────────────────────────────────────
export interface PromptTemplate {
  id: string;
  phase: string;
  name: string;
  version: number;
  systemPrompt: string;
  userPromptPattern: string;
  variables: VariableDefinition[];
  outputFormat: string;
  abVariant?: string;
  tags: string[];
  createdAt: string;
  updatedAt: string;
}

export interface VariableDefinition {
  name: string;
  type: 'string' | 'number' | 'boolean' | 'json';
  required: boolean;
  defaultValue?: unknown;
  description: string;
}

export interface ResolvedPrompt {
  templateId: string;
  systemPrompt: string;
  userPrompt: string;
  resolvedVariables: Record<string, string>;
  estimatedTokens: number;
}

export interface PromptChain {
  id: string;
  name: string;
  steps: string[]; // template IDs in order
  passThroughVariables: string[];
}

// ─── Built-in Variables ──────────────────────────────
const BUILTIN_VARS = [
  'trace_id', 'step_id', 'technology', 'language',
  'rag_context', 'feedback_history', 'previous_output',
  'design_tokens', 'genie_dna'
];

// ─── Service ─────────────────────────────────────────
export class PromptTemplateService {
  private templates = new Map<string, PromptTemplate>();
  private chains = new Map<string, PromptChain>();
  private readonly db: DatabaseService;
  private readonly INDEX = 'xiigen-prompt-templates';

  constructor(db: DatabaseService) {
    this.db = db;
    this.registerBuiltInTemplates();
  }

  // ─── Registry ────────────────────────────────────
  register(template: PromptTemplate): void {
    this.templates.set(template.id, template);
  }

  registerChain(chain: PromptChain): void {
    this.chains.set(chain.id, chain);
  }

  get(templateId: string): PromptTemplate | undefined {
    return this.templates.get(templateId);
  }

  // ─── Resolution ──────────────────────────────────
  async resolve(
    templateId: string,
    traceId: string,
    variables: Record<string, string> = {}
  ): Promise<DataProcessResult<ResolvedPrompt>> {
    const template = this.templates.get(templateId);
    if (!template) {
      return { success: false, error: `Template '${templateId}' not found` };
    }

    try {
      // Merge built-in + custom variables
      const allVars: Record<string, string> = {
        trace_id: traceId,
        ...variables,
      };

      // Resolve system prompt
      const systemPrompt = this.replaceVariables(template.systemPrompt, allVars);
      const userPrompt = this.replaceVariables(template.userPromptPattern, allVars);

      const resolved: ResolvedPrompt = {
        templateId,
        systemPrompt,
        userPrompt,
        resolvedVariables: allVars,
        estimatedTokens: this.estimateTokens(systemPrompt + userPrompt),
      };

      return { success: true, data: resolved };
    } catch (err) {
      return { success: false, error: `Resolution failed: ${(err as Error).message}` };
    }
  }

  async resolveChain(
    chainId: string,
    traceId: string,
    variables: Record<string, string> = {}
  ): Promise<DataProcessResult<ResolvedPrompt[]>> {
    const chain = this.chains.get(chainId);
    if (!chain) {
      return { success: false, error: `Chain '${chainId}' not found` };
    }

    const results: ResolvedPrompt[] = [];
    let currentVars = { ...variables };

    for (const stepId of chain.steps) {
      const result = await this.resolve(stepId, traceId, currentVars);
      if (!result.success || !result.data) {
        return { success: false, error: `Chain step '${stepId}' failed: ${result.error}` };
      }
      results.push(result.data);
      // Pass-through variables propagate to next step
      for (const key of chain.passThroughVariables) {
        if (result.data.resolvedVariables[key]) {
          currentVars[key] = result.data.resolvedVariables[key];
        }
      }
    }

    return { success: true, data: results };
  }

  // ─── Persistence ─────────────────────────────────
  async saveTemplate(template: PromptTemplate): Promise<DataProcessResult<PromptTemplate>> {
    const doc = ObjectProcessor.parseObjectAlternative(template);
    const result = await this.db.upsert(this.INDEX, template.id, doc);
    if (!result.success) return { success: false, error: result.error };
    return { success: true, data: template };
  }

  async queryTemplates(filter: Record<string, unknown>): Promise<DataProcessResult<PromptTemplate[]>> {
    const searchFilter = ObjectProcessor.buildSearchFilter(filter);
    return this.db.query(this.INDEX, searchFilter);
  }

  // ─── Helpers ─────────────────────────────────────
  private replaceVariables(text: string, vars: Record<string, string>): string {
    return text.replace(/\{\{(\w+)\}\}/g, (match, key) => {
      return vars[key] ?? match; // Keep unreplaced vars as-is
    });
  }

  private estimateTokens(text: string): number {
    return Math.ceil(text.length / 4);
  }

  // ─── Built-in Templates ──────────────────────────
  private registerBuiltInTemplates(): void {
    this.register({
      id: 'figma-parse',
      phase: 'parsing',
      name: 'Figma Node to HTML/CSS',
      version: 1,
      systemPrompt: `You are a senior frontend engineer converting Figma designs to semantic HTML/CSS.
Rules: Use semantic HTML5, convert auto-layout to flexbox/grid, CSS custom properties for tokens,
maintain exact spacing/colors/typography, responsive layouts, ARIA attributes.
{{rag_context}}
{{feedback_history}}`,
      userPromptPattern: `Convert this Figma node to {{technology}} code:\n{{previous_output}}`,
      variables: [{ name: 'technology', type: 'string', required: true, defaultValue: 'html-css', description: 'Target framework' }],
      outputFormat: 'json:{ html: string, css: string, components: string[] }',
      tags: ['figma', 'parsing', 'frontend'],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });

    this.register({
      id: 'code-generate',
      phase: 'generation',
      name: 'Code Generation',
      version: 1,
      systemPrompt: `You are a senior {{language}} developer. Generate production-quality code.
Follow SOLID principles, include error handling, use dependency injection.
{{genie_dna}}
{{rag_context}}
{{feedback_history}}`,
      userPromptPattern: `Generate {{language}} code for: {{previous_output}}\nDesign tokens: {{design_tokens}}`,
      variables: [{ name: 'language', type: 'string', required: true, defaultValue: 'csharp', description: 'Target language' }],
      outputFormat: 'json:{ files: [{ path: string, content: string }], dependencies: string[] }',
      tags: ['generation', 'code'],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });

    this.register({
      id: 'code-review',
      phase: 'review',
      name: 'Code Review',
      version: 1,
      systemPrompt: `You are a senior code reviewer. Evaluate code quality, security, performance.
Score 1-10 per category. Suggest specific fixes.
{{rag_context}}
{{feedback_history}}`,
      userPromptPattern: `Review this {{language}} code:\n{{previous_output}}`,
      variables: [{ name: 'language', type: 'string', required: true, defaultValue: 'csharp', description: 'Code language' }],
      outputFormat: 'json:{ score: number, issues: Issue[], suggestions: string[] }',
      tags: ['review', 'quality'],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });

    this.register({
      id: 'test-generate',
      phase: 'testing',
      name: 'Test Generation',
      version: 1,
      systemPrompt: `You are a QA engineer. Generate comprehensive tests for the given code.
Include: unit tests, edge cases, error scenarios, mocking strategies.
Target coverage: 80%+.
{{rag_context}}
{{feedback_history}}`,
      userPromptPattern: `Generate {{language}} tests for:\n{{previous_output}}\nTest framework: {{test_framework}}`,
      variables: [
        { name: 'language', type: 'string', required: true, defaultValue: 'csharp', description: 'Test language' },
        { name: 'test_framework', type: 'string', required: false, defaultValue: 'xunit', description: 'Testing framework' },
      ],
      outputFormat: 'json:{ testFiles: [{ path: string, content: string }], coverage: number }',
      tags: ['testing', 'quality'],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });
  }
}
