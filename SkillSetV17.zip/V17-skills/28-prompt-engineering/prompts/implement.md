# Implement Skill 28: Prompt Engineering Service

## DNA Thinking Framework
Before writing any code:
1. **Classify:** MACHINE (template engine — resolve, chain, A/B) vs FREEDOM (template content — dynamic docs)
2. **Test:** Can a user change this without a developer? Template content = YES → Dictionary<string, object>
3. **Test:** Does this work for template types that don't exist yet? YES → ParseObjectAlternative handles any shape
4. **Store:** All FREEDOM data via ObjectProcessor (no fixed models, no @dataclass, no typed interfaces for DATA)
5. **Query:** All FREEDOM queries via BuildSearchFilter (empty-field skip + scope injection)

## Step 1: Create Project Structure
```
XIIGen.Quality/
├── PromptEngineering/
│   ├── PromptTemplateService.cs    # MACHINE: engine logic
│   └── Extensions.cs               # DI registration
```

## Step 2: Implement IPromptTemplateService Interface
- All template data is `Dictionary<string, object>` — NO PromptTemplate class
- StoreTemplateAsync: use ParseObjectAlternative, add id/createdAt/version defaults
- SearchTemplatesAsync: use BuildSearchFilter + scope injection (userId for non-admin)
- ResolveAsync: get template doc, substitute {{variables}} via regex
- ResolveWithFeedbackAsync: resolve + inject Skill 13 feedback as XML context

## Step 3: Variable Resolution (MACHINE)
- Regex `\{\{(\w+)\}\}` matches variable placeholders
- Look up in variables dictionary, handle string/JsonElement/other types
- Keep unresolved variables as-is (for later stages)

## Step 4: Feedback Integration (MACHINE)
- Query Skill 13 for rated results (4-5★ positive, 1-2★ negative)
- Format as `<xiigen-context>` XML block
- Inject after the resolved prompt

## Step 5: Template Chaining (MACHINE)
- ExecuteChainAsync runs templates in order
- Each step's output becomes `previousOutput` in next step's context
- Track per-step results with traceId

## Step 6: A/B Testing (MACHINE)
- RunABTestAsync dispatches variants via Task.WhenAll
- Store results in xiigen-prompt-results for later evaluation
- Status starts as "awaiting_feedback"

## Step 7: System Template Seeding
- BuildSystemTemplates returns List<Dictionary<string, object>> — NOT typed models
- 6 built-in templates: figma-parse, code-gen, code-review, test-gen, architecture, doc-gen
- All have scope: "system", ownerId: "system"

## Step 8: Scope Isolation
- Non-admin queries inject _scope_userId filter
- Delete checks ownership before removing
- System templates are read-only for non-admins
- CloneToUserScopeAsync copies system template with new scope: "private"

## Step 9: Register DI
```csharp
services.AddSingleton<IPromptTemplateService, PromptTemplateService>();
```

## Abstraction Extraction (for AI agents)
When you see templates + variable substitution in any domain:
- **MACHINE:** The resolve/chain/test engine (ONE service for all template types)
- **FREEDOM:** The template content (dynamic document — any shape)
- **BRIDGE:** Entity index name ("prompt-templates", "email-templates", "form-templates")
Same service, different index → handles all template use cases.
