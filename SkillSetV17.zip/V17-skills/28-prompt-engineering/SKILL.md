---
skill_id: "28"
name: prompt-engineering
title: "Prompt Engineering Service"
layer: "L7: Quality"
version: "17.1"
status: "active"
dependencies: ["01-core-interfaces", "02-object-processor", "03-elasticsearch-datastore", "06-ai-providers", "13-feedback-service"]
genie_dna:
  - "DNA-1: Prompt templates stored as dynamic documents (Dict<string,object>) in ES"
  - "DNA-2: BuildSearchFilter for template search — skip empty, inject scope"
  - "DNA-3: ParseObjectAlternative for template storage — no fixed schema"
  - "DNA-4: Entity Definition Registry defines template fields at runtime"
  - "DNA-5: DataProcessResult wraps all operations"
  - "DNA-FREEDOM: Template content is FREEDOM — users define without code"
  - "DNA-MACHINE: TemplateEngine is MACHINE — built once, generic"
  - "DNA-SCOPE: ownerId injected on all template queries"
  - "DNA-FEEDBACK: Successful prompts improve via feedback loop (Skill 13)"
triggers: prompt template, prompt engineering, system prompt, few-shot, chain of thought, prompt versioning, A/B testing prompts, template management
es_indices:
  - "xiigen-prompt-templates"
  - "xiigen-prompt-results"
---

# Skill 28: Prompt Engineering Service
## Template Management with Feedback-Driven Improvement

**Status:** Enhanced — DNA-Compliant  
**Priority:** P0 — Every AI call depends on prompt quality  
**Dependencies:** Skill 01 (Core), Skill 02 (ObjectProcessor), Skill 06 (AI Providers), Skill 13 (Feedback)  
**Layer:** L7: Quality  
**Estimated LOC:** ~500  

---

## Overview

The Prompt Engineering Service is XIIGen's "recipe book" — it manages structured prompt templates that tell AI models exactly how to generate, review, and test code. Unlike hardcoded prompt strings, templates are dynamic documents that users and AI agents create, refine, and A/B test at runtime. The service handles variable resolution, feedback injection (positive/negative examples from past runs), and version management.

## Key Concepts

- **Template** — A dynamic document (Dictionary<string, object>) stored in ES. Contains system prompt, user prompt pattern, variables, output format, and any user-added metadata. No fixed schema.
- **VariableResolver** — MACHINE component that substitutes `{{variableName}}` placeholders with runtime values.
- **FeedbackInjector** — MACHINE component that queries Skill 13 for successful/failed examples and injects them as few-shot examples.
- **TemplateChain** — Ordered list of templates applied in sequence. Output of one becomes input for the next.
- **A/B Variant** — Two+ template versions tested in parallel; results compared to select winner.

---

## Component Classification (MACHINE vs FREEDOM)

### 🔧 MACHINE (static infrastructure — build once)
| Component | What It Does |
|-----------|-------------|
| PromptTemplateService | Resolves variables, injects feedback, chains templates |
| VariableResolver | Substitution engine — replaces {{var}} with values |
| FeedbackInjector | Formats positive/negative examples into prompt sections |
| TemplateChainExecutor | Runs ordered template sequences |
| ABTestRunner | Dispatches parallel variants, collects results |
| ScopeInjector | Adds ownerId to all template queries |

### 🔓 FREEDOM (user-definable — dynamic documents)
| Component | What Users Control |
|-----------|-------------------|
| Template content | systemPrompt, userPromptPattern, outputFormat — any text |
| Variable definitions | Names, types, defaults — users add new variables at runtime |
| Template metadata | Tags, categories, team, estimated_cost — any field |
| A/B variant config | Which templates compete, sample size, success criteria |
| Output format specs | JSON, XML, markdown, code — user decides |

### The Test
> Can a business user change this without a developer?
> - Change template content → YES (update document) → FREEDOM ✅
> - Change variable resolution logic → NO (engine code) → MACHINE ✅
> - Add a new metadata field → YES (just add to document) → FREEDOM ✅

---

## Scope Isolation

- Template queries inject `ownerId` filter (non-admin users see only their templates)
- System templates: `scope: "system"` — readable by all, modifiable by admins only
- Users clone system templates to `scope: "private"` for customization
- Team templates: `scope: "team"` with `teamId` filter
- AI agent scope: agent uses requesting user's `userId` for all operations
- Admin users see all templates across all scopes

---

## AI Agent Communication

How AI agents (communicating with users through the platform) use this skill:

1. **Discovery:** Agent queries available templates via SearchTemplatesAsync with category/tags filter
2. **Creation:** "I need a template for reviewing legal contracts" → Agent POSTs dynamic doc
3. **Refinement:** Agent reads feedback data, identifies low-performing templates, suggests improvements
4. **Explanation:** Agent reads template results and explains to users in natural language
5. **Composition:** Agent chains templates (parsing → generation → review) for full pipeline
6. **A/B Testing:** Agent proposes variant prompts and analyzes which performs better

Key insight: AI agents use the SAME dynamic document API. Creating via agent = creating via UI = POST Dictionary<string, object>.

---

## Primary Implementation (.NET 9)

### Interface

```csharp
namespace XIIGen.Quality.Interfaces;

public interface IPromptTemplateService
{
    // CRUD — all data is Dictionary<string, object>
    Task<DataProcessResult<string>> StoreTemplateAsync(
        Dictionary<string, object> templateDoc, CancellationToken ct = default);
    Task<DataProcessResult<Dictionary<string, object>>> GetTemplateAsync(
        string templateId, CancellationToken ct = default);
    Task<DataProcessResult<List<Dictionary<string, object>>>> SearchTemplatesAsync(
        Dictionary<string, object> filter, string userId, bool isAdmin = false,
        int size = 20, CancellationToken ct = default);
    Task<DataProcessResult<bool>> DeleteTemplateAsync(
        string templateId, string userId, CancellationToken ct = default);

    // Resolution — MACHINE logic
    Task<DataProcessResult<string>> ResolveAsync(
        string templateId, Dictionary<string, object> variables,
        string traceId, CancellationToken ct = default);
    Task<DataProcessResult<string>> ResolveWithFeedbackAsync(
        string templateId, Dictionary<string, object> variables,
        string traceId, int maxExamples = 3, CancellationToken ct = default);
    
    // Chaining
    Task<DataProcessResult<List<Dictionary<string, object>>>> ExecuteChainAsync(
        List<string> templateIds, Dictionary<string, object> initialContext,
        string traceId, CancellationToken ct = default);
    
    // A/B Testing
    Task<DataProcessResult<Dictionary<string, object>>> RunABTestAsync(
        List<string> variantIds, Dictionary<string, object> testInput,
        string traceId, CancellationToken ct = default);
    
    // Best template by rating/usage
    Task<DataProcessResult<Dictionary<string, object>>> GetBestTemplateAsync(
        string category, string aiModel, CancellationToken ct = default);
    
    // Clone system template to user scope
    Task<DataProcessResult<string>> CloneToUserScopeAsync(
        string templateId, string userId, CancellationToken ct = default);
}
```

### ES Index (Dynamic Mapping)

```json
{
  "mappings": {
    "dynamic": true,
    "properties": {
      "id": { "type": "keyword" },
      "templateName": { "type": "keyword" },
      "category": { "type": "keyword" },
      "systemPrompt": { "type": "text" },
      "userPromptPattern": { "type": "text" },
      "variables": { "type": "nested" },
      "outputFormat": { "type": "text" },
      "ownerId": { "type": "keyword" },
      "scope": { "type": "keyword" },
      "avgRating": { "type": "float" },
      "usageCount": { "type": "long" },
      "version": { "type": "integer" },
      "createdAt": { "type": "date" },
      "updatedAt": { "type": "date" }
    }
  }
}
```
`dynamic: true` means users can add ANY fields — ParseObjectAlternative handles them.

### DI Registration
```csharp
services.AddSingleton<IPromptTemplateService, PromptTemplateService>();
```

---

## Feedback Integration Pattern

```
1. User runs template → AI generates output
2. User rates output (1-5 stars) + optional text feedback
3. Feedback stored in xiigen-prompt-results (Skill 13)
4. Next time same template is used:
   a. FeedbackInjector queries rated results (4-5★ → positive, 1-2★ → negative)
   b. Examples injected into prompt:
      <xiigen-context>
        <positive-examples>
          <example rating="5">clean, focused output...</example>
        </positive-examples>
        <negative-examples>
          <example rating="1" feedback="Too verbose">wordy output...</example>
        </negative-examples>
      </xiigen-context>
```

---

## Abstraction Extraction

When you see multiple systems with templates + variable substitution:
1. The **TEMPLATE ENGINE** is MACHINE (resolve, inject, chain) — built once
2. The **TEMPLATE CONTENT** is FREEDOM (user-defined, schema-free) — dynamic doc
3. The **VARIABLE SYSTEM** bridges them (built-in vars from context + custom vars from user)

Apply to: email templates, report templates, notification templates, workflow step templates, form templates — ALL use the same PromptTemplateService. The entity index name ("prompt-templates", "email-templates") is the ONLY difference.

---

## Dependencies

| Skill | What It Provides |
|-------|-----------------|
| 01 | DataProcessResult, IDataStore, IObjectProcessor interfaces |
| 02 | ParseObjectAlternative for dynamic doc processing |
| 03 | Elasticsearch storage backend |
| 06 | AI provider abstraction for template testing |
| 13 | Feedback data for positive/negative example injection |

## Related Skills
- **29-31** — Use prompt templates to generate test code
- **17** — Code generator consumes resolved prompts
- **11** — AI Transform uses templates for transformation steps
- **12** — AI Review uses templates for review criteria
