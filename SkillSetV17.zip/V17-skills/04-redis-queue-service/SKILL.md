# Skill 04: Redis Queue Service
## IQueueService implementation using Redis Streams with consumer groups

**Status:** Ready to Generate  
**Priority:** P0 — Default job queue  
**Dependencies:** Skill 01 (Core Interfaces)  
**Layer:** L2: Infrastructure  
**Phase:** 2  
**Estimated LOC:** ~210  

---

## Overview

Redis Streams powers XIIGen's job queue. This skill implements `IQueueService` with consumer groups (ensuring each job is processed exactly once even with multiple workers), dead letter queue support, and message acknowledgment. Also includes `RedisCacheService` implementing `ICacheService`.

## Key Concepts

- **Consumer Groups:** Multiple workers in a group share the load; each message delivered to ONE consumer
- **Acknowledgment:** Worker must ACK after processing; unACKed messages are re-delivered
- **Dead Letter Queue:** Failed messages moved to `{queue}-dlq` after max retries
- **Pending check:** On startup, claim any pending (unACKed) messages first before reading new ones
- **Message format:** body (JSON), priority, enqueuedAt, headers as stream entries

---

## Primary Implementation (.NET 9)

```csharp
// NuGet: StackExchange.Redis
namespace XIIGen.Infrastructure.Redis;

public class RedisQueueService : IQueueService
{
    private readonly IConnectionMultiplexer _redis;
    private readonly IDatabase _db;
    public QueueType QueueType => QueueType.RedisStreams;

    public RedisQueueService(string connectionString)
    {
        _redis = ConnectionMultiplexer.Connect(connectionString);
        _db = _redis.GetDatabase();
    }

    public async Task<DataProcessResult<string>> EnqueueAsync<T>(
        string queueName, T message, Dictionary<string, string> headers = null,
        int priority = 5, CancellationToken ct = default)
    {
        var entries = new NameValueEntry[] {
            new("body", JsonSerializer.Serialize(message)),
            new("priority", priority.ToString()),
            new("enqueuedAt", DateTime.UtcNow.ToString("O")),
            new("headers", JsonSerializer.Serialize(headers ?? []))
        };
        var id = await _db.StreamAddAsync(queueName, entries);
        return DataProcessResult<string>.Ok(id.ToString());
    }

    public async IAsyncEnumerable<QueueMessage<T>> ConsumeAsync<T>(
        string queueName, string consumerGroup, string consumerId,
        [EnumeratorCancellation] CancellationToken ct = default)
    {
        await EnsureConsumerGroupAsync(queueName, consumerGroup);
        // First: claim any pending messages
        var pending = await _db.StreamReadGroupAsync(queueName, consumerGroup, consumerId, "0-0", 10);
        foreach (var entry in pending) yield return ParseEntry<T>(entry, queueName);
        // Then: read new messages
        while (!ct.IsCancellationRequested) {
            var entries = await _db.StreamReadGroupAsync(queueName, consumerGroup, consumerId, ">", 5);
            if (entries.Length == 0) { await Task.Delay(1000, ct); continue; }
            foreach (var entry in entries) yield return ParseEntry<T>(entry, queueName);
        }
    }

    public async Task<DataProcessResult<bool>> AcknowledgeAsync(
        string queueName, string consumerGroup, string messageId, CancellationToken ct = default)
    {
        var acked = await _db.StreamAcknowledgeAsync(queueName, consumerGroup, messageId);
        return DataProcessResult<bool>.Ok(acked > 0);
    }

    // ... RejectAsync, MoveToDeadLetterAsync, GetQueueLengthAsync
    // Full implementation in Implementation/RedisServices.cs
}

public class RedisCacheService : ICacheService { /* Redis GET/SET/DEL with optional expiry */ }
```

### DI Registration

```csharp
builder.Services.AddSingleton<IQueueService>(new RedisQueueService(builder.Configuration["Redis:Connection"] ?? "localhost:6379"));
builder.Services.AddSingleton<ICacheService>(sp => new RedisCacheService(sp.GetRequiredService<IConnectionMultiplexer>()));
```

---

## Queue Alternatives (in alternatives/ folder)

| Queue | File | When to Use |
|-------|------|-------------|
| Kafka | `alternatives/kafka/` | High-throughput event streaming |
| RabbitMQ | `alternatives/rabbitmq/` | Complex routing, exchanges |
| SQS | `alternatives/sqs/` | AWS-native serverless |
| Azure Service Bus | `alternatives/azure-sb/` | Azure-native enterprise |

## Anti-Patterns
- **Don't** forget to ACK messages — they'll be re-delivered to other consumers
- **Don't** process without consumer groups — you'll get duplicate processing
- **Don't** use RPUSH/LPOP for job queues — Streams give you persistence + consumer groups
