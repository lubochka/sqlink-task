# Skill 04: Redis Queue Service — Implementation Prompt

## Prerequisites
- Skill 01 (Core Interfaces) implemented — `IQueueService`, `QueueMessage<T>`, `DataProcessResult<T>`, enums
- Redis 7.x running (Docker: `docker run -d -p 6379:6379 redis:7-alpine`)

## .NET Implementation Steps

### 1. Add NuGet Package
```bash
dotnet add package StackExchange.Redis
```

### 2. Create Service File
**Path:** `XIIGen.Infrastructure/Redis/RedisQueueService.cs`

Copy implementation from `Implementation/RedisServices.cs` (207 lines). Includes both `RedisQueueService` and `RedisCacheService`.

Key patterns:
- **Consumer Groups:** `StreamReadGroupAsync` with `">"` for new messages — each message delivered to ONE consumer
- **ACK after processing:** Always call `AcknowledgeAsync` after successful processing
- **Dead Letter Queue:** `{queueName}-dlq` for failed messages with `originalQueue` and `failedAt` metadata
- **Pending recovery:** On startup, check for pending messages (`StreamPendingAsync`) and reclaim
- **Message format:** `body` (JSON), `priority`, `enqueuedAt`, `headers` fields in stream entry
- **IAsyncEnumerable:** `ConsumeAsync` yields messages via `IAsyncEnumerable<QueueMessage<T>>`
- **CancellationToken:** All methods accept and respect cancellation

### 3. Register in DI
```csharp
// In XIIGen.Infrastructure/DependencyInjection.cs
services.AddSingleton<IConnectionMultiplexer>(ConnectionMultiplexer.Connect(config["Redis:ConnectionString"] ?? "localhost:6379"));
services.AddSingleton<IQueueService, RedisQueueService>();
services.AddSingleton<ICacheService, RedisCacheService>();
```

### 4. Configuration
```json
{ "Redis": { "ConnectionString": "localhost:6379" } }
```

### 5. Verify
```csharp
var queue = serviceProvider.GetRequiredService<IQueueService>();

// Enqueue a job
var enqResult = await queue.EnqueueAsync("test-queue", new { TaskId = "t1", Action = "process" });
Assert.Equal(DataProcessStatus.Ok, enqResult.Status);
Assert.NotNull(enqResult.Data); // stream ID like "1234567890-0"

// Consume and ACK
await foreach (var msg in queue.ConsumeAsync<dynamic>("test-queue", "worker-group", "worker-1", cts.Token))
{
    Assert.Equal("t1", msg.Body.TaskId);
    await queue.AcknowledgeAsync("test-queue", "worker-group", msg.Id);
    break; // Just verify first message
}

// Verify queue length
var len = await queue.GetQueueLengthAsync("test-queue");
Assert.True(len.Data >= 0);
```

## Queue Alternatives

| Queue | Package | Best For |
|-------|---------|----------|
| **Redis Streams** (default) | StackExchange.Redis | Low-latency, simple setup, good for most workloads |
| Kafka | Confluent.Kafka | High-throughput event streaming, log retention |
| RabbitMQ | RabbitMQ.Client | Complex routing, priority queues, mature ecosystem |
| AWS SQS | AWSSDK.SQS | Serverless, managed, no infrastructure |
| Azure Service Bus | Azure.Messaging.ServiceBus | Azure enterprise, topics/subscriptions |

All alternatives implement the same `IQueueService` interface — swap via DI config.

## Alternative Stack Instructions

| Stack | Package | File |
|-------|---------|------|
| Node.js | `ioredis@5` | `alternatives/nodejs/redis-queue-service.ts` |
| Python | `redis[hiredis]>=5` | `alternatives/python/redis_queue_service.py` |
| Java | `redis.clients:jedis:5+` | `alternatives/java/RedisQueueService.java` |
| Rust | `redis = { features = ["streams"] }` | `alternatives/rust/redis_queue_service.rs` |
| PHP | `ext-redis` (phpredis) | `alternatives/php/RedisQueueService.php` |

## Anti-Patterns
- ❌ Don't forget ACK — unACKed messages pile up in pending entries list (PEL)
- ❌ Don't use `RPUSH/LPOP` instead of Streams — no consumer groups, no ACK, no replay
- ❌ Don't process without consumer groups — messages get lost if worker crashes
- ❌ Don't block indefinitely — always use `BLOCK` with timeout (100ms) + `CancellationToken`
- ❌ Don't skip dead letter queue — failed messages need a recovery path


---

## Genie DNA Compliance — MANDATORY for All Implementations

> Before writing ANY code, classify each component:
> **MACHINE** (static): Infrastructure that enables freedom. Build once, generic, interface-based.
> **FREEDOM** (dynamic): Anything users define. No fixed models, config-driven.

### DNA Checklist — Every Implementation MUST:
☐ **DNA-1 (Dynamic Documents):** Store data as `Dictionary<string, object>` / `Record<string, any>` — NOT typed model classes. User fields preserved without schema changes.
☐ **DNA-2 (BuildSearchFilter):** All queries use BuildSearchFilter/equivalent. Empty fields auto-skipped. No entity-specific query code.
☐ **DNA-3 (MicroserviceBase):** Inherit base class with DB, queue, cache, logger built in.
☐ **DNA-5 (DataProcessResult):** All public methods return `DataProcessResult<T>`. Errors return failure, not throw exceptions.
☐ **DNA-6 (Generic Interfaces):** External dependencies behind interfaces. Swap via config.
☐ **DNA-SCOPE:** Non-admin queries auto-inject userId filter. Cannot be bypassed.

### The Three Tests:
1. Can a business user change this without a developer? (YES = correct)
2. Does it work for entity types that do not exist yet? (YES = correct)
3. Can I swap the database/service/UI without changing this? (YES = correct)
