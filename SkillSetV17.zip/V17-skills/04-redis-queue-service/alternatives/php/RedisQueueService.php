<?php
// Skill 04: Redis Queue Service — PHP 8.3 / phpredis extension (Streams)
declare(strict_types=1);

namespace XIIGen\Infrastructure\Redis;

use XIIGen\Core\{IQueueService, QueueType, DataProcessResult, QueueMessage};

final class RedisQueueService implements IQueueService
{
    private readonly \Redis $client;

    public function __construct(string $host = '127.0.0.1', int $port = 6379)
    {
        $this->client = new \Redis();
        $this->client->connect($host, $port);
    }

    public function queueType(): QueueType { return QueueType::REDIS_STREAMS; }

    public function enqueue(string $queueName, mixed $message, array $headers = [], int $priority = 5): DataProcessResult
    {
        try {
            $id = $this->client->xAdd($queueName, '*', [
                'body'       => json_encode($message, JSON_THROW_ON_ERROR),
                'priority'   => (string) $priority,
                'enqueuedAt' => (new \DateTimeImmutable('now', new \DateTimeZone('UTC')))->format('c'),
                'headers'    => json_encode($headers, JSON_THROW_ON_ERROR),
            ]);
            return DataProcessResult::ok($id);
        } catch (\Throwable $e) { return DataProcessResult::fail($e->getMessage()); }
    }

    /**
     * @return \Generator<QueueMessage>
     */
    public function consume(string $queueName, string $consumerGroup, string $consumerId): \Generator
    {
        $this->ensureConsumerGroup($queueName, $consumerGroup);

        while (true) {
            try {
                $entries = $this->client->xReadGroup($consumerGroup, $consumerId, [$queueName => '>'], 1, 100);
                if (!$entries || empty($entries[$queueName])) continue;

                foreach ($entries[$queueName] as $id => $fields) {
                    yield new QueueMessage(
                        id: $id,
                        queueName: $queueName,
                        body: json_decode($fields['body'] ?? '{}', true, 512, JSON_THROW_ON_ERROR),
                        consumerGroup: $consumerGroup,
                        enqueuedAt: $fields['enqueuedAt'] ?? '',
                        headers: json_decode($fields['headers'] ?? '{}', true),
                        priority: (int) ($fields['priority'] ?? 5),
                    );
                }
            } catch (\Throwable) { usleep(100_000); }
        }
    }

    public function acknowledge(string $queueName, string $consumerGroup, string $messageId): DataProcessResult
    {
        try {
            $count = $this->client->xAck($queueName, $consumerGroup, [$messageId]);
            return DataProcessResult::ok($count > 0);
        } catch (\Throwable $e) { return DataProcessResult::fail($e->getMessage()); }
    }

    public function reject(string $queueName, string $consumerGroup, string $messageId, bool $requeue = false): DataProcessResult
    {
        try {
            $this->client->xAck($queueName, $consumerGroup, [$messageId]);
            if ($requeue) {
                $entries = $this->client->xRange($queueName, $messageId, $messageId, 1);
                if (!empty($entries)) {
                    $this->client->xAdd($queueName, '*', reset($entries));
                }
            }
            return DataProcessResult::ok(true);
        } catch (\Throwable $e) { return DataProcessResult::fail($e->getMessage()); }
    }

    public function moveToDeadLetter(string $queueName, string $consumerGroup, string $messageId): DataProcessResult
    {
        try {
            $dlq = "{$queueName}-dlq";
            $entries = $this->client->xRange($queueName, $messageId, $messageId, 1);
            if (!empty($entries)) {
                $fields = reset($entries);
                $fields['originalQueue'] = $queueName;
                $fields['failedAt'] = (new \DateTimeImmutable('now', new \DateTimeZone('UTC')))->format('c');
                $this->client->xAdd($dlq, '*', $fields);
            }
            $this->client->xAck($queueName, $consumerGroup, [$messageId]);
            return DataProcessResult::ok(true);
        } catch (\Throwable $e) { return DataProcessResult::fail($e->getMessage()); }
    }

    public function getQueueLength(string $queueName): DataProcessResult
    {
        try {
            $len = $this->client->xLen($queueName);
            return DataProcessResult::ok($len);
        } catch (\Throwable $e) { return DataProcessResult::fail($e->getMessage()); }
    }

    private function ensureConsumerGroup(string $queueName, string $group): void
    {
        try { $this->client->xGroup('CREATE', $queueName, $group, '0', true); }
        catch (\Throwable) { /* group already exists */ }
    }
}

// --- Redis Cache Service ---
final class RedisCacheService
{
    private readonly \Redis $client;

    public function __construct(string $host = '127.0.0.1', int $port = 6379)
    {
        $this->client = new \Redis();
        $this->client->connect($host, $port);
    }

    public function get(string $key): mixed
    {
        $val = $this->client->get($key);
        return $val !== false ? json_decode($val, true) : null;
    }

    public function set(string $key, mixed $value, ?int $ttlSeconds = null): void
    {
        $json = json_encode($value, JSON_THROW_ON_ERROR);
        $ttlSeconds ? $this->client->setex($key, $ttlSeconds, $json) : $this->client->set($key, $json);
    }

    public function delete(string $key): bool { return $this->client->del($key) > 0; }
    public function exists(string $key): bool { return (bool) $this->client->exists($key); }
}
