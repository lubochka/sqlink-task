# Skill 04: Redis Queue Service — Python / redis-py 5.x (async)
import json
import asyncio
from datetime import datetime, timezone
from dataclasses import dataclass, field
from typing import AsyncGenerator, TypeVar, Generic, Optional
from redis.asyncio import Redis
from core_interfaces import IQueueService, QueueType, DataProcessResult, QueueMessage

T = TypeVar('T')

class RedisQueueService(IQueueService):
    def __init__(self, connection_url: str = "redis://localhost:6379"):
        self.client = Redis.from_url(connection_url, decode_responses=True)

    @property
    def queue_type(self) -> QueueType: return QueueType.REDIS_STREAMS

    async def enqueue(self, queue_name: str, message, headers: dict = None, priority: int = 5) -> DataProcessResult:
        try:
            msg_id = await self.client.xadd(queue_name, {
                "body": json.dumps(message, default=str),
                "priority": str(priority),
                "enqueuedAt": datetime.now(timezone.utc).isoformat(),
                "headers": json.dumps(headers or {})
            })
            return DataProcessResult.ok(msg_id)
        except Exception as e: return DataProcessResult.fail(str(e))

    async def consume(self, queue_name: str, consumer_group: str, consumer_id: str) -> AsyncGenerator[QueueMessage, None]:
        await self._ensure_consumer_group(queue_name, consumer_group)
        while True:
            try:
                entries = await self.client.xreadgroup(consumer_group, consumer_id, {queue_name: ">"}, count=1, block=100)
                if not entries: continue
                for stream_name, messages in entries:
                    for msg_id, fields in messages:
                        yield QueueMessage(
                            id=msg_id,
                            queue_name=queue_name,
                            body=json.loads(fields.get("body", "{}")),
                            consumer_group=consumer_group,
                            enqueued_at=fields.get("enqueuedAt", ""),
                            headers=json.loads(fields.get("headers", "{}")),
                            priority=int(fields.get("priority", "5"))
                        )
            except asyncio.CancelledError: break
            except Exception: await asyncio.sleep(0.1)

    async def acknowledge(self, queue_name: str, consumer_group: str, message_id: str) -> DataProcessResult:
        try:
            count = await self.client.xack(queue_name, consumer_group, message_id)
            return DataProcessResult.ok(count > 0)
        except Exception as e: return DataProcessResult.fail(str(e))

    async def reject(self, queue_name: str, consumer_group: str, message_id: str, requeue: bool = False) -> DataProcessResult:
        try:
            await self.client.xack(queue_name, consumer_group, message_id)
            if requeue:
                entries = await self.client.xrange(queue_name, min=message_id, max=message_id, count=1)
                if entries:
                    _, fields = entries[0]
                    await self.client.xadd(queue_name, fields)
            return DataProcessResult.ok(True)
        except Exception as e: return DataProcessResult.fail(str(e))

    async def move_to_dead_letter(self, queue_name: str, consumer_group: str, message_id: str) -> DataProcessResult:
        try:
            dlq = f"{queue_name}-dlq"
            entries = await self.client.xrange(queue_name, min=message_id, max=message_id, count=1)
            if entries:
                _, fields = entries[0]
                fields["originalQueue"] = queue_name
                fields["failedAt"] = datetime.now(timezone.utc).isoformat()
                await self.client.xadd(dlq, fields)
            await self.client.xack(queue_name, consumer_group, message_id)
            return DataProcessResult.ok(True)
        except Exception as e: return DataProcessResult.fail(str(e))

    async def get_queue_length(self, queue_name: str) -> DataProcessResult:
        try:
            length = await self.client.xlen(queue_name)
            return DataProcessResult.ok(length)
        except Exception as e: return DataProcessResult.fail(str(e))

    async def _ensure_consumer_group(self, queue_name: str, group: str):
        try: await self.client.xgroup_create(queue_name, group, id="0", mkstream=True)
        except Exception: pass  # group already exists


class RedisCacheService:
    def __init__(self, connection_url: str = "redis://localhost:6379"):
        self.client = Redis.from_url(connection_url, decode_responses=True)

    async def get(self, key: str): 
        val = await self.client.get(key)
        return json.loads(val) if val else None

    async def set(self, key: str, value, ttl_seconds: int = None):
        data = json.dumps(value, default=str)
        if ttl_seconds: await self.client.setex(key, ttl_seconds, data)
        else: await self.client.set(key, data)

    async def delete(self, key: str) -> bool: return (await self.client.delete(key)) > 0
    async def exists(self, key: str) -> bool: return (await self.client.exists(key)) > 0
