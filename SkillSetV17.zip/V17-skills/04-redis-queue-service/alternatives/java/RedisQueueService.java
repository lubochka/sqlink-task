// Skill 04: Redis Queue Service — Java / Jedis 5.x (Redis Streams)
package com.xiigen.infrastructure.redis;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.xiigen.core.*;
import redis.clients.jedis.*;
import redis.clients.jedis.resps.StreamEntry;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;

public class RedisQueueService implements IQueueService {
    private final JedisPool pool;
    private final ObjectMapper mapper = new ObjectMapper();

    @Override public QueueType getQueueType() { return QueueType.REDIS_STREAMS; }

    public RedisQueueService(String host, int port) { this.pool = new JedisPool(host, port); }
    public RedisQueueService(JedisPool pool) { this.pool = pool; }

    @Override
    public <T> CompletableFuture<DataProcessResult<String>> enqueue(String queueName, T message, Map<String, String> headers, int priority) {
        return CompletableFuture.supplyAsync(() -> {
            try (var jedis = pool.getResource()) {
                var fields = new HashMap<String, String>();
                fields.put("body", mapper.writeValueAsString(message));
                fields.put("priority", String.valueOf(priority));
                fields.put("enqueuedAt", Instant.now().toString());
                fields.put("headers", mapper.writeValueAsString(headers != null ? headers : Map.of()));
                var id = jedis.xadd(queueName, StreamEntryID.NEW_ENTRY, fields);
                return DataProcessResult.ok(id.toString());
            } catch (Exception e) { return DataProcessResult.<String>fail(e.getMessage()); }
        });
    }

    @Override
    public <T> BlockingQueue<QueueMessage<T>> consume(String queueName, String consumerGroup, String consumerId, Class<T> type) {
        var queue = new LinkedBlockingQueue<QueueMessage<T>>();
        ensureConsumerGroup(queueName, consumerGroup);

        Thread.ofVirtual().start(() -> {
            while (!Thread.currentThread().isInterrupted()) {
                try (var jedis = pool.getResource()) {
                    var entries = jedis.xreadGroup(consumerGroup, consumerId,
                        new XReadGroupParams().count(1).block(100),
                        Map.entry(queueName, StreamEntryID.UNRECEIVED_ENTRY));
                    if (entries == null || entries.isEmpty()) continue;
                    for (var streamEntry : entries) {
                        for (var entry : streamEntry.getValue()) {
                            var msg = new QueueMessage<T>();
                            msg.setId(entry.getID().toString());
                            msg.setQueueName(queueName);
                            msg.setBody(mapper.readValue(entry.getFields().get("body"), type));
                            msg.setConsumerGroup(consumerGroup);
                            msg.setEnqueuedAt(Instant.parse(entry.getFields().getOrDefault("enqueuedAt", Instant.now().toString())));
                            queue.put(msg);
                        }
                    }
                } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
                catch (Exception e) { try { Thread.sleep(100); } catch (InterruptedException ignored) {} }
            }
        });
        return queue;
    }

    @Override
    public CompletableFuture<DataProcessResult<Boolean>> acknowledge(String queueName, String consumerGroup, String messageId) {
        return CompletableFuture.supplyAsync(() -> {
            try (var jedis = pool.getResource()) {
                long count = jedis.xack(queueName, consumerGroup, new StreamEntryID(messageId));
                return DataProcessResult.ok(count > 0);
            } catch (Exception e) { return DataProcessResult.<Boolean>fail(e.getMessage()); }
        });
    }

    @Override
    public CompletableFuture<DataProcessResult<Boolean>> reject(String queueName, String consumerGroup, String messageId, boolean requeue) {
        return CompletableFuture.supplyAsync(() -> {
            try (var jedis = pool.getResource()) {
                jedis.xack(queueName, consumerGroup, new StreamEntryID(messageId));
                if (requeue) {
                    var entries = jedis.xrange(queueName, new StreamEntryID(messageId), new StreamEntryID(messageId), 1);
                    if (!entries.isEmpty()) jedis.xadd(queueName, StreamEntryID.NEW_ENTRY, entries.get(0).getFields());
                }
                return DataProcessResult.ok(true);
            } catch (Exception e) { return DataProcessResult.<Boolean>fail(e.getMessage()); }
        });
    }

    @Override
    public CompletableFuture<DataProcessResult<Boolean>> moveToDeadLetter(String queueName, String consumerGroup, String messageId) {
        return CompletableFuture.supplyAsync(() -> {
            try (var jedis = pool.getResource()) {
                String dlq = queueName + "-dlq";
                var entries = jedis.xrange(queueName, new StreamEntryID(messageId), new StreamEntryID(messageId), 1);
                if (!entries.isEmpty()) {
                    var fields = new HashMap<>(entries.get(0).getFields());
                    fields.put("originalQueue", queueName);
                    fields.put("failedAt", Instant.now().toString());
                    jedis.xadd(dlq, StreamEntryID.NEW_ENTRY, fields);
                }
                jedis.xack(queueName, consumerGroup, new StreamEntryID(messageId));
                return DataProcessResult.ok(true);
            } catch (Exception e) { return DataProcessResult.<Boolean>fail(e.getMessage()); }
        });
    }

    @Override
    public CompletableFuture<DataProcessResult<Long>> getQueueLength(String queueName) {
        return CompletableFuture.supplyAsync(() -> {
            try (var jedis = pool.getResource()) {
                return DataProcessResult.ok(jedis.xlen(queueName));
            } catch (Exception e) { return DataProcessResult.<Long>fail(e.getMessage()); }
        });
    }

    private void ensureConsumerGroup(String queueName, String group) {
        try (var jedis = pool.getResource()) { jedis.xgroupCreate(queueName, group, new StreamEntryID(), true); }
        catch (Exception ignored) { /* group exists */ }
    }
}
