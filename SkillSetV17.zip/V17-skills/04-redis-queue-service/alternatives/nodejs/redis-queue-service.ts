// Skill 04: Redis Queue Service — Node.js / ioredis
import Redis from 'ioredis';
import { IQueueService, QueueType, DataProcessResult, QueueMessage } from './core-interfaces';

export class RedisQueueService implements IQueueService {
  private client: Redis;
  readonly queueType = QueueType.RedisStreams;

  constructor(connectionUrl = 'redis://localhost:6379') {
    this.client = new Redis(connectionUrl);
  }

  async enqueue<T>(queueName: string, message: T, headers: Record<string, string> = {}, priority = 5): Promise<DataProcessResult<string>> {
    try {
      const id = await this.client.xadd(queueName, '*',
        'body', JSON.stringify(message),
        'priority', String(priority),
        'enqueuedAt', new Date().toISOString(),
        'headers', JSON.stringify(headers)
      );
      return DataProcessResult.ok(id!);
    } catch (e: any) { return DataProcessResult.fail(e.message); }
  }

  async *consume<T>(queueName: string, consumerGroup: string, consumerId: string, signal?: AbortSignal): AsyncGenerator<QueueMessage<T>> {
    await this.ensureConsumerGroup(queueName, consumerGroup);

    while (!signal?.aborted) {
      try {
        const entries = await this.client.xreadgroup('GROUP', consumerGroup, consumerId, 'COUNT', '1', 'BLOCK', '100', 'STREAMS', queueName, '>');
        if (!entries || entries.length === 0) continue;

        for (const [, messages] of entries) {
          for (const [id, fields] of messages) {
            const fieldMap: Record<string, string> = {};
            for (let i = 0; i < fields.length; i += 2) fieldMap[fields[i]] = fields[i + 1];

            yield {
              id,
              queueName,
              body: JSON.parse(fieldMap.body) as T,
              consumerGroup,
              enqueuedAt: new Date(fieldMap.enqueuedAt || Date.now()),
              headers: JSON.parse(fieldMap.headers || '{}'),
              priority: parseInt(fieldMap.priority || '5'),
            };
          }
        }
      } catch { await new Promise(r => setTimeout(r, 100)); }
    }
  }

  async acknowledge(queueName: string, consumerGroup: string, messageId: string): Promise<DataProcessResult<boolean>> {
    try {
      const count = await this.client.xack(queueName, consumerGroup, messageId);
      return DataProcessResult.ok(count > 0);
    } catch (e: any) { return DataProcessResult.fail(e.message); }
  }

  async reject(queueName: string, consumerGroup: string, messageId: string, requeue = false): Promise<DataProcessResult<boolean>> {
    try {
      await this.client.xack(queueName, consumerGroup, messageId);
      if (requeue) {
        const entries = await this.client.xrange(queueName, messageId, messageId, 'COUNT', '1');
        if (entries.length > 0) {
          const [, fields] = entries[0];
          await this.client.xadd(queueName, '*', ...fields);
        }
      }
      return DataProcessResult.ok(true);
    } catch (e: any) { return DataProcessResult.fail(e.message); }
  }

  async moveToDeadLetter(queueName: string, consumerGroup: string, messageId: string): Promise<DataProcessResult<boolean>> {
    try {
      const dlq = `${queueName}-dlq`;
      const entries = await this.client.xrange(queueName, messageId, messageId, 'COUNT', '1');
      if (entries.length > 0) {
        const [, fields] = entries[0];
        await this.client.xadd(dlq, '*', ...fields, 'originalQueue', queueName, 'failedAt', new Date().toISOString());
      }
      await this.client.xack(queueName, consumerGroup, messageId);
      return DataProcessResult.ok(true);
    } catch (e: any) { return DataProcessResult.fail(e.message); }
  }

  async getQueueLength(queueName: string): Promise<DataProcessResult<number>> {
    try {
      const len = await this.client.xlen(queueName);
      return DataProcessResult.ok(len);
    } catch (e: any) { return DataProcessResult.fail(e.message); }
  }

  private async ensureConsumerGroup(queueName: string, group: string): Promise<void> {
    try { await this.client.xgroup('CREATE', queueName, group, '0', 'MKSTREAM'); }
    catch { /* group already exists */ }
  }

  async dispose(): Promise<void> { await this.client.quit(); }
}

// --- Redis Cache Service ---
export class RedisCacheService {
  private client: Redis;

  constructor(connectionUrl = 'redis://localhost:6379') { this.client = new Redis(connectionUrl); }

  async get<T>(key: string): Promise<T | null> {
    const val = await this.client.get(key);
    return val ? JSON.parse(val) : null;
  }

  async set<T>(key: string, value: T, ttlSeconds?: number): Promise<void> {
    const json = JSON.stringify(value);
    ttlSeconds ? await this.client.setex(key, ttlSeconds, json) : await this.client.set(key, json);
  }

  async delete(key: string): Promise<boolean> { return (await this.client.del(key)) > 0; }
  async exists(key: string): Promise<boolean> { return (await this.client.exists(key)) > 0; }
}
