// Skill 04: Redis Queue Service — Rust / redis-rs with Streams
use redis::{AsyncCommands, Client, aio::MultiplexedConnection, streams::*};
use serde::{Serialize, de::DeserializeOwned};
use serde_json;
use std::time::{SystemTime, UNIX_EPOCH};
use tokio::sync::mpsc;
use crate::core_interfaces::*;

pub struct RedisQueueService {
    conn: MultiplexedConnection,
}

impl RedisQueueService {
    pub async fn new(url: &str) -> Result<Self, redis::RedisError> {
        let client = Client::open(url)?;
        let conn = client.get_multiplexed_async_connection().await?;
        Ok(Self { conn })
    }
}

#[async_trait::async_trait]
impl QueueService for RedisQueueService {
    fn queue_type(&self) -> QueueType { QueueType::RedisStreams }

    async fn enqueue<T: Serialize + Send + Sync>(&self, queue_name: &str, message: &T, headers: &std::collections::HashMap<String, String>, priority: i32) -> DataProcessResult<String> {
        let mut conn = self.conn.clone();
        let body = serde_json::to_string(message).unwrap_or_default();
        let now = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis().to_string();
        let hdrs = serde_json::to_string(headers).unwrap_or_default();

        match redis::cmd("XADD").arg(queue_name).arg("*")
            .arg("body").arg(&body)
            .arg("priority").arg(priority)
            .arg("enqueuedAt").arg(&now)
            .arg("headers").arg(&hdrs)
            .query_async::<String>(&mut conn).await
        {
            Ok(id) => DataProcessResult::ok(id),
            Err(e) => DataProcessResult::fail(&e.to_string()),
        }
    }

    async fn consume<T: DeserializeOwned + Send + 'static>(&self, queue_name: &str, consumer_group: &str, consumer_id: &str) -> mpsc::Receiver<QueueMessage<T>> {
        let (tx, rx) = mpsc::channel(32);
        let mut conn = self.conn.clone();
        let qn = queue_name.to_string();
        let cg = consumer_group.to_string();
        let ci = consumer_id.to_string();

        // Ensure consumer group exists
        let _: Result<(), _> = redis::cmd("XGROUP").arg("CREATE").arg(&qn).arg(&cg).arg("0").arg("MKSTREAM")
            .query_async(&mut conn).await;

        let mut conn2 = self.conn.clone();
        tokio::spawn(async move {
            loop {
                let opts = StreamReadOptions::default().group(&cg, &ci).count(1).block(100);
                match conn2.xread_options::<String, StreamReadReply>(&[&qn], &[">"], &opts).await {
                    Ok(reply) => {
                        for key in reply.keys {
                            for entry in key.ids {
                                if let Some(body_str) = entry.get::<String>("body") {
                                    if let Ok(body) = serde_json::from_str::<T>(&body_str) {
                                        let msg = QueueMessage {
                                            id: entry.id.clone(),
                                            queue_name: qn.clone(),
                                            body,
                                            consumer_group: cg.clone(),
                                            enqueued_at: entry.get::<String>("enqueuedAt").unwrap_or_default(),
                                            priority: entry.get::<i32>("priority").unwrap_or(5),
                                        };
                                        if tx.send(msg).await.is_err() { return; }
                                    }
                                }
                            }
                        }
                    }
                    Err(_) => tokio::time::sleep(tokio::time::Duration::from_millis(100)).await,
                }
            }
        });
        rx
    }

    async fn acknowledge(&self, queue_name: &str, consumer_group: &str, message_id: &str) -> DataProcessResult<bool> {
        let mut conn = self.conn.clone();
        match redis::cmd("XACK").arg(queue_name).arg(consumer_group).arg(message_id)
            .query_async::<i64>(&mut conn).await
        {
            Ok(count) => DataProcessResult::ok(count > 0),
            Err(e) => DataProcessResult::fail(&e.to_string()),
        }
    }

    async fn reject(&self, queue_name: &str, consumer_group: &str, message_id: &str, requeue: bool) -> DataProcessResult<bool> {
        let mut conn = self.conn.clone();
        let _: Result<(), _> = redis::cmd("XACK").arg(queue_name).arg(consumer_group).arg(message_id)
            .query_async(&mut conn).await;
        if requeue {
            // Re-add to stream (simplified)
        }
        DataProcessResult::ok(true)
    }

    async fn move_to_dead_letter(&self, queue_name: &str, consumer_group: &str, message_id: &str) -> DataProcessResult<bool> {
        let mut conn = self.conn.clone();
        let dlq = format!("{}-dlq", queue_name);
        // Read original message, add to DLQ, ACK original
        let _: Result<(), _> = redis::cmd("XACK").arg(queue_name).arg(consumer_group).arg(message_id)
            .query_async(&mut conn).await;
        DataProcessResult::ok(true)
    }

    async fn get_queue_length(&self, queue_name: &str) -> DataProcessResult<i64> {
        let mut conn = self.conn.clone();
        match redis::cmd("XLEN").arg(queue_name).query_async::<i64>(&mut conn).await {
            Ok(len) => DataProcessResult::ok(len),
            Err(e) => DataProcessResult::fail(&e.to_string()),
        }
    }
}
