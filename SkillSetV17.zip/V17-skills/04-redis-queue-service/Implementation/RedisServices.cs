// XIIGen.Infrastructure.Redis/RedisServices.cs - Skill 04 | .NET 9
using System.Runtime.CompilerServices;
using System.Text.Json;
using StackExchange.Redis;
using XIIGen.Core.Enums;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Infrastructure.Redis;

public class RedisQueueService : IQueueService
{
    private readonly IConnectionMultiplexer _redis;
    private readonly IDatabase _db;
    public QueueType QueueType => QueueType.RedisStreams;

    public RedisQueueService(string connectionString)
    {
        _redis = ConnectionMultiplexer.Connect(connectionString);
        _db = _redis.GetDatabase();
    }

    public RedisQueueService(IConnectionMultiplexer redis) { _redis = redis; _db = redis.GetDatabase(); }

    public async Task<DataProcessResult<string>> EnqueueAsync<T>(
        string queueName, T message, Dictionary<string, string> headers = null, int priority = 5, CancellationToken ct = default)
    {
        var json = JsonSerializer.Serialize(message);
        var entries = new NameValueEntry[]
        {
            new("body", json),
            new("priority", priority.ToString()),
            new("enqueuedAt", DateTime.UtcNow.ToString("O")),
            new("headers", JsonSerializer.Serialize(headers ?? []))
        };
        var id = await _db.StreamAddAsync(queueName, entries);
        return DataProcessResult<string>.Success(id.ToString());
    }

    public async IAsyncEnumerable<QueueMessage<T>> ConsumeAsync<T>(
        string queueName, string consumerGroup, string consumerId, [EnumeratorCancellation] CancellationToken ct = default)
    {
        await EnsureConsumerGroupAsync(queueName, consumerGroup);

        while (!ct.IsCancellationRequested)
        {
            var entries = await _db.StreamReadGroupAsync(queueName, consumerGroup, consumerId, ">", count: 1);
            if (entries.Length == 0) { await Task.Delay(100, ct); continue; }

            foreach (var entry in entries)
            {
                var body = entry.Values.FirstOrDefault(v => v.Name == "body").Value.ToString();
                var msg = new QueueMessage<T>
                {
                    Id = entry.Id.ToString(),
                    QueueName = queueName,
                    Body = JsonSerializer.Deserialize<T>(body),
                    ConsumerGroup = consumerGroup,
                    EnqueuedAt = DateTime.TryParse(entry.Values.FirstOrDefault(v => v.Name == "enqueuedAt").Value.ToString(), out var d) ? d : DateTime.UtcNow
                };
                yield return msg;
            }
        }
    }

    public async Task<DataProcessResult<bool>> AcknowledgeAsync(
        string queueName, string consumerGroup, string messageId, CancellationToken ct = default)
    {
        var result = await _db.StreamAcknowledgeAsync(queueName, consumerGroup, messageId);
        return DataProcessResult<bool>.Success(result > 0);
    }

    public async Task<DataProcessResult<bool>> RejectAsync(
        string queueName, string consumerGroup, string messageId, bool requeue = false, CancellationToken ct = default)
    {
        await _db.StreamAcknowledgeAsync(queueName, consumerGroup, messageId);
        if (requeue)
        {
            var entry = await _db.StreamRangeAsync(queueName, messageId, messageId, count: 1);
            if (entry.Length > 0) await _db.StreamAddAsync(queueName, entry[0].Values);
        }
        return DataProcessResult<bool>.Success(true);
    }

    public async Task<DataProcessResult<bool>> MoveToDeadLetterAsync(
        string queueName, string messageId, string reason, CancellationToken ct = default)
    {
        var dlq = $"{queueName}.dlq";
        var entries = await _db.StreamRangeAsync(queueName, messageId, messageId, count: 1);
        if (entries.Length > 0)
        {
            var values = entries[0].Values.Append(new NameValueEntry("dlqReason", reason)).ToArray();
            await _db.StreamAddAsync(dlq, values);
        }
        return DataProcessResult<bool>.Success(true);
    }

    public async Task<DataProcessResult<long>> GetQueueLengthAsync(string queueName, CancellationToken ct = default)
    {
        var length = await _db.StreamLengthAsync(queueName);
        return DataProcessResult<long>.Success(length);
    }

    public async Task<DataProcessResult<ConsumerGroupInfo>> GetConsumerGroupInfoAsync(
        string queueName, string consumerGroup, CancellationToken ct = default)
    {
        var groups = await _db.StreamGroupInfoAsync(queueName);
        var group = groups.FirstOrDefault(g => g.Name == consumerGroup);
        if (group.Name.IsNullOrEmpty) return DataProcessResult<ConsumerGroupInfo>.NotFound();
        return DataProcessResult<ConsumerGroupInfo>.Success(new ConsumerGroupInfo
        {
            GroupName = group.Name!, ConsumerCount = group.ConsumerCount, PendingMessages = group.PendingMessageCount
        });
    }

    public async Task<DataProcessResult<bool>> CreateConsumerGroupAsync(string queueName, string consumerGroup, CancellationToken ct = default)
    {
        await EnsureConsumerGroupAsync(queueName, consumerGroup);
        return DataProcessResult<bool>.Success(true);
    }

    public async Task<DataProcessResult<bool>> PurgeQueueAsync(string queueName, CancellationToken ct = default)
    {
        await _db.StreamTrimAsync(queueName, 0);
        return DataProcessResult<bool>.Success(true);
    }

    public async Task<DataProcessResult<QueueMessage<T>>> PeekAsync<T>(string queueName, CancellationToken ct = default)
    {
        var entries = await _db.StreamRangeAsync(queueName, count: 1);
        if (entries.Length == 0) return DataProcessResult<QueueMessage<T>>.NotFound();
        var body = entries[0].Values.FirstOrDefault(v => v.Name == "body").Value.ToString();
        return DataProcessResult<QueueMessage<T>>.Success(new QueueMessage<T>
        {
            Id = entries[0].Id.ToString(), Body = JsonSerializer.Deserialize<T>(body), QueueName = queueName
        });
    }

    public async Task<bool> QueueExistsAsync(string queueName, CancellationToken ct = default)
    {
        var length = await _db.StreamLengthAsync(queueName);
        return length >= 0;
    }

    public async Task<DataProcessResult<bool>> CreateQueueAsync(string queueName, CancellationToken ct = default)
    {
        await _db.StreamAddAsync(queueName, [new NameValueEntry("init", "true")]);
        await _db.StreamTrimAsync(queueName, 0);
        return DataProcessResult<bool>.Success(true);
    }

    private async Task EnsureConsumerGroupAsync(string queueName, string consumerGroup)
    {
        try { await _db.StreamCreateConsumerGroupAsync(queueName, consumerGroup, "0-0", createStream: true); }
        catch (RedisServerException ex) when (ex.Message.Contains("BUSYGROUP")) { /* Already exists */ }
    }
}

// ─── Redis Cache Service ────────────────────────────

public class RedisCacheService : ICacheService
{
    private readonly IDatabase _db;

    public RedisCacheService(IConnectionMultiplexer redis) { _db = redis.GetDatabase(); }
    public RedisCacheService(string connectionString) { _db = ConnectionMultiplexer.Connect(connectionString).GetDatabase(); }

    public async Task<DataProcessResult<T>> GetAsync<T>(string key, CancellationToken ct = default)
    {
        var value = await _db.StringGetAsync(key);
        if (value.IsNullOrEmpty) return DataProcessResult<T>.NotFound();
        return DataProcessResult<T>.Success(JsonSerializer.Deserialize<T>(value!));
    }

    public async Task<DataProcessResult<bool>> SetAsync<T>(string key, T value, TimeSpan? expiration = null, CancellationToken ct = default)
    {
        var json = JsonSerializer.Serialize(value);
        await _db.StringSetAsync(key, json, expiration);
        return DataProcessResult<bool>.Success(true);
    }

    public async Task<DataProcessResult<bool>> DeleteAsync(string key, CancellationToken ct = default)
    {
        await _db.KeyDeleteAsync(key);
        return DataProcessResult<bool>.Success(true);
    }

    public async Task<DataProcessResult<bool>> ExistsAsync(string key, CancellationToken ct = default)
        => DataProcessResult<bool>.Success(await _db.KeyExistsAsync(key));

    public async Task<DataProcessResult<T>> GetOrSetAsync<T>(string key, Func<Task<T>> factory, TimeSpan? expiration = null, CancellationToken ct = default)
    {
        var existing = await GetAsync<T>(key, ct);
        if (existing.IsSuccess) return existing;
        var value = await factory();
        await SetAsync(key, value, expiration, ct);
        return DataProcessResult<T>.Success(value);
    }

    public async Task<DataProcessResult<bool>> InvalidateByPrefixAsync(string prefix, CancellationToken ct = default)
    {
        var server = _db.Multiplexer.GetServer(_db.Multiplexer.GetEndPoints().First());
        var keys = server.Keys(pattern: $"{prefix}*").ToArray();
        if (keys.Length > 0) await _db.KeyDeleteAsync(keys);
        return DataProcessResult<bool>.Success(true);
    }
}
