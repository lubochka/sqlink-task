# Skill 35: MCP Server — Implementation Prompt

## Phase 1: MCP Protocol Handler
Implement MCP SSE transport. Tool listing endpoint. Tool execution endpoint.

## Phase 2: Dynamic Tool Generation
Generate MCP tools from entity definitions. store/search/get per entity type.

## Phase 3: Scope Isolation
Tool execution respects UserScope. AI agents scoped to user's data.

## Phase 4: Flow Integration
Tool calls emit events to flow orchestrator. Results stored as dynamic documents.

---

## Genie DNA Compliance — MANDATORY
☐ DNA-1: Dynamic Documents — Dictionary<string, object>, NOT typed models
☐ DNA-2: BuildSearchFilter — skip empty fields, no entity-specific query code
☐ DNA-3: MicroserviceBase — inherit DB, queue, cache, logger
☐ DNA-5: DataProcessResult<T> — all methods return result wrapper
☐ DNA-6: Generic Interfaces — swap via config
☐ DNA-SCOPE: Non-admin queries auto-inject userId filter
