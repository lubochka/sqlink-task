/**
 * XIIGen Skill 35: MCP Server — Java Alternative
 * Model Context Protocol server giving AI assistants direct API access
 * DNA: DataProcessResult, dynamic documents, scope isolation, generic interfaces
 */
package com.xiigen.mcp;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

public class McpServerService {

    private static final String REGISTRY_INDEX = "mcp-tool-registry";
    private static final String HISTORY_INDEX = "mcp-tool-history";

    private final IDatabaseService db;
    private final IQueueService queue;
    private final ILogger logger;
    private final String apiBaseUrl;
    private final ObjectMapper mapper = new ObjectMapper();
    private final Map<String, McpToolDefinition> tools = new ConcurrentHashMap<>();
    private final Map<String, ServiceEndpoint> endpoints = new ConcurrentHashMap<>();

    public McpServerService(IDatabaseService db, IQueueService queue, ILogger logger, String apiBaseUrl) {
        this.db = db; this.queue = queue; this.logger = logger;
        this.apiBaseUrl = apiBaseUrl != null ? apiBaseUrl : "http://localhost:8080/api";
    }

    /** Initialize MCP server with service endpoints. DNA: dynamic document registry. */
    public DataProcessResult<Map<String, Object>> initialize(List<ServiceEndpoint> serviceEndpoints) {
        try {
            for (ServiceEndpoint ep : serviceEndpoints) {
                this.endpoints.put(ep.serviceName(), ep);
                registerServiceTools(ep);
            }

            db.upsert(REGISTRY_INDEX, Map.of(
                "id", "mcp-registry",
                "toolCount", tools.size(),
                "serviceCount", serviceEndpoints.size(),
                "tools", new ArrayList<>(tools.keySet()),
                "updatedAt", Instant.now().toString()
            ));

            logger.info("MCP initialized: " + tools.size() + " tools from " + serviceEndpoints.size() + " services");
            return DataProcessResult.success(Map.of(
                "tools", Map.of("listChanged", true),
                "resources", Map.of("subscribe", true, "listChanged", true),
                "prompts", Map.of("listChanged", true)
            ), "Registered " + tools.size() + " tools");
        } catch (Exception e) {
            return DataProcessResult.error(e.getMessage());
        }
    }

    /** List all available tools (MCP protocol: tools/list). */
    public DataProcessResult<List<Map<String, Object>>> listTools() {
        List<Map<String, Object>> result = tools.values().stream()
            .map(t -> Map.<String, Object>of("name", t.name(), "description", t.description(), "inputSchema", t.inputSchema()))
            .collect(Collectors.toList());
        return DataProcessResult.success(result, result.size() + " tools available");
    }

    /** Execute tool call from AI assistant. DNA: DataProcessResult wrapping. */
    public DataProcessResult<Map<String, Object>> executeTool(String toolName, Map<String, Object> arguments) {
        try {
            if (!tools.containsKey(toolName)) {
                return DataProcessResult.error("Unknown tool: " + toolName);
            }

            String[] parts = toolName.split("_", 2);
            String serviceName = parts[0];
            String operation = parts.length > 1 ? parts[1] : "";
            ServiceEndpoint endpoint = endpoints.get(serviceName);
            if (endpoint == null) {
                return DataProcessResult.error("Service not found: " + serviceName);
            }

            Map<String, Object> result = routeToolCall(endpoint, operation, arguments);

            // DNA: Store execution history
            db.upsert(HISTORY_INDEX, Map.of(
                "id", "exec-" + System.currentTimeMillis(),
                "toolName", toolName,
                "arguments", arguments,
                "success", !Boolean.TRUE.equals(result.get("isError")),
                "executedAt", Instant.now().toString()
            ));

            return DataProcessResult.success(result, "Tool executed");
        } catch (Exception e) {
            logger.error("MCP execution failed: " + toolName, e);
            return DataProcessResult.error(e.getMessage());
        }
    }

    /** Query tool history. DNA: BuildSearchFilter — skip empty values. */
    public DataProcessResult<List<Map<String, Object>>> queryToolHistory(Map<String, Object> filters) {
        try {
            Map<String, Object> clean = filters.entrySet().stream()
                .filter(e -> e.getValue() != null && !"".equals(e.getValue()))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
            List<Map<String, Object>> results = db.query(HISTORY_INDEX, clean);
            return DataProcessResult.success(results, "Found " + results.size() + " executions");
        } catch (Exception e) {
            return DataProcessResult.error(e.getMessage());
        }
    }

    /** Register a reusable prompt template. */
    public DataProcessResult<Void> registerPrompt(String name, String description, String template, List<String> args) {
        try {
            db.upsert("mcp-prompts", Map.of(
                "id", "prompt-" + name, "name", name, "description", description,
                "template", template, "arguments", args,
                "createdAt", Instant.now().toString()
            ));
            return DataProcessResult.success(null, "Prompt '" + name + "' registered");
        } catch (Exception e) {
            return DataProcessResult.error(e.getMessage());
        }
    }

    // --- Private ---

    private void registerServiceTools(ServiceEndpoint ep) {
        String sn = ep.serviceName();
        String desc = ep.description();

        if (ep.methods().contains("list")) {
            tools.put(sn + "_list", new McpToolDefinition(sn + "_list", "List all " + desc,
                Map.of("type", "object", "properties", Map.of(
                    "scopeId", Map.of("type", "string"), "limit", Map.of("type", "number")),
                    "required", List.of("scopeId"))));
        }
        if (ep.methods().contains("get")) {
            tools.put(sn + "_get", new McpToolDefinition(sn + "_get", "Get " + desc + " by ID",
                Map.of("type", "object", "properties", Map.of(
                    "id", Map.of("type", "string"), "scopeId", Map.of("type", "string")),
                    "required", List.of("id", "scopeId"))));
        }
        if (ep.methods().contains("create")) {
            tools.put(sn + "_create", new McpToolDefinition(sn + "_create", "Create " + desc,
                Map.of("type", "object", "properties", Map.of(
                    "scopeId", Map.of("type", "string"), "data", Map.of("type", "object")),
                    "required", List.of("scopeId", "data"))));
        }
        if (ep.methods().contains("search")) {
            tools.put(sn + "_search", new McpToolDefinition(sn + "_search", "Search " + desc,
                Map.of("type", "object", "properties", Map.of(
                    "scopeId", Map.of("type", "string"), "query", Map.of("type", "object")),
                    "required", List.of("scopeId"))));
        }
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> routeToolCall(ServiceEndpoint ep, String op, Map<String, Object> args) throws Exception {
        String idx = ep.indexName();
        String scopeId = (String) args.getOrDefault("scopeId", "");

        return switch (op) {
            case "list" -> {
                List<Map<String, Object>> results = db.query(idx, Map.of("scopeId", scopeId));
                int limit = ((Number) args.getOrDefault("limit", 20)).intValue();
                yield Map.of("content", List.of(Map.of("type", "text",
                    "text", mapper.writeValueAsString(results.subList(0, Math.min(limit, results.size()))))));
            }
            case "get" -> {
                List<Map<String, Object>> results = db.query(idx, Map.of("id", args.get("id"), "scopeId", scopeId));
                yield Map.of("content", List.of(Map.of("type", "text",
                    "text", mapper.writeValueAsString(results.isEmpty() ? null : results.get(0)))));
            }
            case "create" -> {
                Map<String, Object> data = (Map<String, Object>) args.getOrDefault("data", Map.of());
                Map<String, Object> doc = new HashMap<>(data);
                doc.put("scopeId", scopeId);
                doc.put("createdAt", Instant.now().toString());
                db.upsert(idx, doc);
                yield Map.of("content", List.of(Map.of("type", "text", "text", "Created document in " + idx)));
            }
            case "search" -> {
                Map<String, Object> query = (Map<String, Object>) args.getOrDefault("query", Map.of());
                Map<String, Object> clean = query.entrySet().stream()
                    .filter(e -> e.getValue() != null && !"".equals(e.getValue()))
                    .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
                clean.put("scopeId", scopeId);
                List<Map<String, Object>> results = db.query(idx, clean);
                yield Map.of("content", List.of(Map.of("type", "text", "text", mapper.writeValueAsString(results))));
            }
            default -> Map.of("content", List.of(Map.of("type", "text", "text", "Unknown: " + op)), "isError", true);
        };
    }
}

// --- Records ---
record McpToolDefinition(String name, String description, Map<String, Object> inputSchema) {}
record ServiceEndpoint(String serviceName, String basePath, List<String> methods, String indexName, String description) {}
