<?php
/**
 * XIIGen Skill 35: MCP Server — PHP Alternative
 * Model Context Protocol server giving AI assistants direct API access
 * DNA: DataProcessResult, dynamic documents, scope isolation, generic interfaces
 */
namespace XIIGen\Mcp;

class DataProcessResult {
    public function __construct(
        public readonly bool $success, public readonly mixed $data, public readonly string $message
    ) {}
    public static function ok(mixed $data, string $msg): self { return new self(true, $data, $msg); }
    public static function error(string $msg): self { return new self(false, null, $msg); }
}

class McpToolDefinition {
    public function __construct(
        public readonly string $name, public readonly string $description, public readonly array $inputSchema
    ) {}
}

class ServiceEndpoint {
    public function __construct(
        public readonly string $serviceName, public readonly string $basePath,
        public readonly array $methods, public readonly string $indexName, public readonly string $description
    ) {}
}

class McpServerService {
    private const REGISTRY_INDEX = 'mcp-tool-registry';
    private const HISTORY_INDEX = 'mcp-tool-history';

    /** @var array<string, McpToolDefinition> */
    private array $tools = [];
    /** @var array<string, ServiceEndpoint> */
    private array $endpoints = [];

    public function __construct(
        private readonly object $db, private readonly object $queue, private readonly object $logger,
        private readonly string $apiBaseUrl = 'http://localhost:8080/api'
    ) {}

    /** Initialize MCP server with service endpoints. DNA: dynamic document registry. */
    public function initialize(array $serviceEndpoints): DataProcessResult {
        try {
            foreach ($serviceEndpoints as $ep) {
                $this->endpoints[$ep->serviceName] = $ep;
                $this->registerServiceTools($ep);
            }

            $this->db->upsert(self::REGISTRY_INDEX, [
                'id' => 'mcp-registry', 'toolCount' => count($this->tools),
                'serviceCount' => count($serviceEndpoints),
                'tools' => array_keys($this->tools),
                'updatedAt' => (new \DateTimeImmutable())->format(\DateTimeInterface::ATOM),
            ]);

            $tc = count($this->tools);
            $this->logger->info("MCP initialized: {$tc} tools from " . count($serviceEndpoints) . " services");
            return DataProcessResult::ok([
                'tools' => ['listChanged' => true], 'resources' => ['subscribe' => true], 'prompts' => ['listChanged' => true]
            ], "Registered {$tc} tools");
        } catch (\Throwable $e) {
            return DataProcessResult::error($e->getMessage());
        }
    }

    /** List all available tools (MCP protocol: tools/list). */
    public function listTools(): DataProcessResult {
        $list = array_map(fn(McpToolDefinition $t) => [
            'name' => $t->name, 'description' => $t->description, 'inputSchema' => $t->inputSchema
        ], array_values($this->tools));
        return DataProcessResult::ok($list, count($list) . ' tools available');
    }

    /** Execute tool call from AI. DNA: DataProcessResult wrapping. */
    public function executeTool(string $toolName, array $arguments): DataProcessResult {
        try {
            if (!isset($this->tools[$toolName])) {
                return DataProcessResult::error("Unknown tool: {$toolName}");
            }

            $parts = explode('_', $toolName, 2);
            $serviceName = $parts[0];
            $operation = $parts[1] ?? '';
            $endpoint = $this->endpoints[$serviceName] ?? null;
            if (!$endpoint) return DataProcessResult::error("Service not found: {$serviceName}");

            $result = $this->routeToolCall($endpoint, $operation, $arguments);

            // DNA: Store execution history as dynamic document
            $this->db->upsert(self::HISTORY_INDEX, [
                'id' => 'exec-' . microtime(true), 'toolName' => $toolName,
                'arguments' => $arguments, 'success' => !($result['isError'] ?? false),
                'executedAt' => (new \DateTimeImmutable())->format(\DateTimeInterface::ATOM),
            ]);

            return DataProcessResult::ok($result, 'Tool executed');
        } catch (\Throwable $e) {
            $this->logger->error("MCP execution failed: {$e->getMessage()}");
            return DataProcessResult::error($e->getMessage());
        }
    }

    /** Query tool history. DNA: BuildSearchFilter — skip empty. */
    public function queryToolHistory(array $filters): DataProcessResult {
        try {
            $clean = array_filter($filters, fn($v) => $v !== null && $v !== '');
            $results = $this->db->query(self::HISTORY_INDEX, $clean);
            return DataProcessResult::ok($results, 'Found ' . count($results) . ' executions');
        } catch (\Throwable $e) {
            return DataProcessResult::error($e->getMessage());
        }
    }

    /** Register a reusable prompt template. */
    public function registerPrompt(string $name, string $description, string $template, array $args): DataProcessResult {
        try {
            $this->db->upsert('mcp-prompts', [
                'id' => "prompt-{$name}", 'name' => $name, 'description' => $description,
                'template' => $template, 'arguments' => $args,
                'createdAt' => (new \DateTimeImmutable())->format(\DateTimeInterface::ATOM),
            ]);
            return DataProcessResult::ok(null, "Prompt '{$name}' registered");
        } catch (\Throwable $e) {
            return DataProcessResult::error($e->getMessage());
        }
    }

    // --- Private ---

    private function registerServiceTools(ServiceEndpoint $ep): void {
        $sn = $ep->serviceName; $desc = $ep->description;
        foreach ($ep->methods as $method) {
            match ($method) {
                'list' => $this->tools["{$sn}_list"] = new McpToolDefinition("{$sn}_list", "List all {$desc}",
                    ['type'=>'object','properties'=>['scopeId'=>['type'=>'string'],'limit'=>['type'=>'number']],'required'=>['scopeId']]),
                'get' => $this->tools["{$sn}_get"] = new McpToolDefinition("{$sn}_get", "Get {$desc} by ID",
                    ['type'=>'object','properties'=>['id'=>['type'=>'string'],'scopeId'=>['type'=>'string']],'required'=>['id','scopeId']]),
                'create' => $this->tools["{$sn}_create"] = new McpToolDefinition("{$sn}_create", "Create {$desc}",
                    ['type'=>'object','properties'=>['scopeId'=>['type'=>'string'],'data'=>['type'=>'object']],'required'=>['scopeId','data']]),
                'search' => $this->tools["{$sn}_search"] = new McpToolDefinition("{$sn}_search", "Search {$desc}",
                    ['type'=>'object','properties'=>['scopeId'=>['type'=>'string'],'query'=>['type'=>'object']],'required'=>['scopeId']]),
                default => null,
            };
        }
    }

    private function routeToolCall(ServiceEndpoint $ep, string $op, array $args): array {
        $idx = $ep->indexName;
        $scopeId = $args['scopeId'] ?? '';
        return match ($op) {
            'list' => ['content' => [['type' => 'text', 'text' => json_encode(
                array_slice($this->db->query($idx, ['scopeId' => $scopeId]), 0, $args['limit'] ?? 20), JSON_PRETTY_PRINT)]]],
            'get' => ['content' => [['type' => 'text', 'text' => json_encode(
                ($this->db->query($idx, ['id' => $args['id'] ?? '', 'scopeId' => $scopeId]))[0] ?? null, JSON_PRETTY_PRINT)]]],
            'create' => (function() use ($idx, $args, $scopeId) {
                $doc = array_merge($args['data'] ?? [], ['scopeId' => $scopeId, 'createdAt' => date('c')]);
                $this->db->upsert($idx, $doc);
                return ['content' => [['type' => 'text', 'text' => "Created document in {$idx}"]]];
            })(),
            'search' => (function() use ($idx, $args, $scopeId) {
                $query = array_filter($args['query'] ?? [], fn($v) => $v !== null && $v !== '');
                $query['scopeId'] = $scopeId;
                return ['content' => [['type' => 'text', 'text' => json_encode(
                    $this->db->query($idx, $query), JSON_PRETTY_PRINT)]]];
            })(),
            default => ['content' => [['type' => 'text', 'text' => "Unknown: {$op}"]], 'isError' => true],
        };
    }
}
