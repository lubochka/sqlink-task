"""
XIIGen Skill 35: MCP Server — Python Alternative
Model Context Protocol server giving AI assistants direct API access
DNA: DataProcessResult, dynamic documents, scope isolation, generic interfaces
"""
from dataclasses import dataclass, field
from typing import Any, Optional
from datetime import datetime
import json


@dataclass
class DataProcessResult:
    success: bool
    data: Any
    message: str


@dataclass
class McpToolDefinition:
    name: str
    description: str
    input_schema: dict


@dataclass
class McpToolCall:
    name: str
    arguments: dict


@dataclass
class McpToolResult:
    content: list[dict]
    is_error: bool = False


@dataclass
class ServiceEndpoint:
    service_name: str
    base_path: str
    methods: list[str]
    index_name: str
    description: str


class McpServerService:
    """
    MCP server providing AI assistants with direct access to all XIIGen services.
    DNA: DataProcessResult, dynamic documents, BuildSearchFilter, scope isolation.
    """
    REGISTRY_INDEX = "mcp-tool-registry"
    HISTORY_INDEX = "mcp-tool-history"

    def __init__(self, db, queue, logger, api_base_url: str = "http://localhost:8000/api"):
        self._db = db
        self._queue = queue
        self._logger = logger
        self._api_base_url = api_base_url
        self._tools: dict[str, McpToolDefinition] = {}
        self._endpoints: dict[str, ServiceEndpoint] = {}

    async def initialize(self, endpoints: list[ServiceEndpoint]) -> DataProcessResult:
        """Initialize MCP server with service endpoints. DNA: dynamic document registry."""
        try:
            for ep in endpoints:
                self._endpoints[ep.service_name] = ep
                self._register_service_tools(ep)

            await self._db.upsert(self.REGISTRY_INDEX, {
                "id": "mcp-registry",
                "toolCount": len(self._tools),
                "serviceCount": len(endpoints),
                "tools": list(self._tools.keys()),
                "updatedAt": datetime.utcnow().isoformat()
            })

            self._logger.info(f"MCP initialized: {len(self._tools)} tools from {len(endpoints)} services")
            return DataProcessResult(True, {
                "tools": {"listChanged": True},
                "resources": {"subscribe": True, "listChanged": True},
                "prompts": {"listChanged": True}
            }, f"Registered {len(self._tools)} tools")
        except Exception as e:
            return DataProcessResult(False, {}, str(e))

    async def list_tools(self) -> DataProcessResult:
        """List all available tools (MCP protocol: tools/list)."""
        tools = [{"name": t.name, "description": t.description, "inputSchema": t.input_schema}
                 for t in self._tools.values()]
        return DataProcessResult(True, tools, f"{len(tools)} tools available")

    async def execute_tool(self, tool_call: McpToolCall) -> DataProcessResult:
        """Execute a tool call from AI assistant. DNA: DataProcessResult wrapping."""
        try:
            if tool_call.name not in self._tools:
                return DataProcessResult(False,
                    McpToolResult([{"type": "text", "text": f"Unknown tool: {tool_call.name}"}], True),
                    "Tool not found")

            parts = tool_call.name.split("_", 1)
            service_name, operation = parts[0], parts[1] if len(parts) > 1 else ""
            endpoint = self._endpoints.get(service_name)
            if not endpoint:
                return DataProcessResult(False,
                    McpToolResult([{"type": "text", "text": f"Service not found: {service_name}"}], True),
                    "Service not found")

            result = await self._route_tool_call(endpoint, operation, tool_call.arguments)

            # DNA: Store execution history as dynamic document
            await self._db.upsert(self.HISTORY_INDEX, {
                "id": f"exec-{datetime.utcnow().timestamp()}",
                "toolName": tool_call.name,
                "arguments": tool_call.arguments,
                "success": not result.is_error,
                "executedAt": datetime.utcnow().isoformat()
            })

            return DataProcessResult(True, result, "Tool executed")
        except Exception as e:
            self._logger.error(f"MCP tool execution failed: {e}")
            return DataProcessResult(False,
                McpToolResult([{"type": "text", "text": f"Error: {e}"}], True), str(e))

    async def query_tool_history(self, **filters) -> DataProcessResult:
        """DNA: BuildSearchFilter — skip empty values."""
        try:
            clean = {k: v for k, v in filters.items() if v is not None and v != ""}
            results = await self._db.query(self.HISTORY_INDEX, clean)
            return DataProcessResult(True, results, f"Found {len(results)} executions")
        except Exception as e:
            return DataProcessResult(False, [], str(e))

    async def register_prompt(self, name: str, description: str,
                               template: str, args: list[str]) -> DataProcessResult:
        """Register a reusable prompt template for AI assistants."""
        try:
            await self._db.upsert("mcp-prompts", {
                "id": f"prompt-{name}", "name": name, "description": description,
                "template": template, "arguments": args,
                "createdAt": datetime.utcnow().isoformat()
            })
            return DataProcessResult(True, None, f"Prompt '{name}' registered")
        except Exception as e:
            return DataProcessResult(False, None, str(e))

    # --- Private ---

    def _register_service_tools(self, endpoint: ServiceEndpoint):
        sn = endpoint.service_name
        desc = endpoint.description

        if "list" in endpoint.methods:
            self._tools[f"{sn}_list"] = McpToolDefinition(
                f"{sn}_list", f"List all {desc}",
                {"type": "object", "properties": {
                    "scopeId": {"type": "string", "description": "Scope/tenant ID"},
                    "limit": {"type": "number"}, "offset": {"type": "number"}
                }, "required": ["scopeId"]})

        if "get" in endpoint.methods:
            self._tools[f"{sn}_get"] = McpToolDefinition(
                f"{sn}_get", f"Get specific {desc} by ID",
                {"type": "object", "properties": {
                    "id": {"type": "string"}, "scopeId": {"type": "string"}
                }, "required": ["id", "scopeId"]})

        if "create" in endpoint.methods:
            self._tools[f"{sn}_create"] = McpToolDefinition(
                f"{sn}_create", f"Create new {desc}",
                {"type": "object", "properties": {
                    "scopeId": {"type": "string"},
                    "data": {"type": "object", "description": "Dynamic document data"}
                }, "required": ["scopeId", "data"]})

        if "search" in endpoint.methods:
            self._tools[f"{sn}_search"] = McpToolDefinition(
                f"{sn}_search", f"Search {desc} with filters",
                {"type": "object", "properties": {
                    "scopeId": {"type": "string"},
                    "query": {"type": "object", "description": "Search filter"}
                }, "required": ["scopeId"]})

    async def _route_tool_call(self, endpoint: ServiceEndpoint,
                                operation: str, args: dict) -> McpToolResult:
        idx = endpoint.index_name
        match operation:
            case "list":
                results = await self._db.query(idx, {"scopeId": args["scopeId"]})
                limit = args.get("limit", 20)
                return McpToolResult([{"type": "text", "text": json.dumps(results[:limit], default=str, indent=2)}])
            case "get":
                results = await self._db.query(idx, {"id": args["id"], "scopeId": args["scopeId"]})
                return McpToolResult([{"type": "text", "text": json.dumps(results[0] if results else None, default=str, indent=2)}])
            case "create":
                doc = {**args.get("data", {}), "scopeId": args["scopeId"], "createdAt": datetime.utcnow().isoformat()}
                await self._db.upsert(idx, doc)
                return McpToolResult([{"type": "text", "text": f"Created document in {idx}"}])
            case "search":
                query = {k: v for k, v in (args.get("query") or {}).items() if v is not None and v != ""}
                query["scopeId"] = args["scopeId"]
                results = await self._db.query(idx, query)
                return McpToolResult([{"type": "text", "text": json.dumps(results, default=str, indent=2)}])
            case _:
                return McpToolResult([{"type": "text", "text": f"Unknown operation: {operation}"}], True)


# --- FastAPI Integration ---
def create_mcp_router(service: McpServerService):
    from fastapi import APIRouter, Request
    router = APIRouter(prefix="/mcp", tags=["MCP"])

    @router.post("/tools/list")
    async def list_tools():
        return (await service.list_tools()).data

    @router.post("/tools/call")
    async def call_tool(request: Request):
        body = await request.json()
        result = await service.execute_tool(McpToolCall(body["name"], body.get("arguments", {})))
        return result.data

    return router
