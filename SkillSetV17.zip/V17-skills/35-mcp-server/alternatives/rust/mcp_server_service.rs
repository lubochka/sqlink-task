// XIIGen Skill 35: MCP Server — Rust Alternative
// Model Context Protocol server giving AI assistants direct API access
// DNA: DataProcessResult, dynamic documents, scope isolation, generic interfaces

use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::sync::Arc;
use tokio::sync::RwLock;
use chrono::Utc;

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct DataProcessResult<T: Default> {
    pub success: bool, pub data: T, pub message: String,
}
impl<T: Default> DataProcessResult<T> {
    pub fn ok(data: T, msg: &str) -> Self { Self { success: true, data, message: msg.into() } }
    pub fn err(msg: &str) -> Self { Self { success: false, data: T::default(), message: msg.into() } }
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct McpToolDefinition {
    pub name: String, pub description: String,
    pub input_schema: serde_json::Value,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct McpToolCall { pub name: String, pub arguments: serde_json::Value }

#[derive(Debug, Serialize, Deserialize, Clone, Default)]
pub struct McpToolResult {
    pub content: Vec<McpContent>, pub is_error: bool,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct McpContent { pub r#type: String, pub text: String }

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct ServiceEndpoint {
    pub service_name: String, pub base_path: String,
    pub methods: Vec<String>, pub index_name: String, pub description: String,
}

#[async_trait::async_trait]
pub trait IDatabaseService: Send + Sync {
    async fn upsert(&self, index: &str, doc: serde_json::Value) -> Result<(), Box<dyn std::error::Error>>;
    async fn query(&self, index: &str, filter: serde_json::Value) -> Result<Vec<serde_json::Value>, Box<dyn std::error::Error>>;
}

pub trait ILogger: Send + Sync {
    fn info(&self, msg: &str);
    fn error(&self, msg: &str);
}

pub struct McpServerService {
    db: Arc<dyn IDatabaseService>,
    logger: Arc<dyn ILogger>,
    tools: RwLock<HashMap<String, McpToolDefinition>>,
    endpoints: RwLock<HashMap<String, ServiceEndpoint>>,
}

impl McpServerService {
    const REGISTRY: &'static str = "mcp-tool-registry";
    const HISTORY: &'static str = "mcp-tool-history";

    pub fn new(db: Arc<dyn IDatabaseService>, logger: Arc<dyn ILogger>) -> Self {
        Self { db, logger, tools: RwLock::new(HashMap::new()), endpoints: RwLock::new(HashMap::new()) }
    }

    /// Initialize MCP server with service endpoints. DNA: dynamic document registry.
    pub async fn initialize(&self, service_endpoints: Vec<ServiceEndpoint>) -> DataProcessResult<serde_json::Value> {
        let mut tools_w = self.tools.write().await;
        let mut ep_w = self.endpoints.write().await;

        for ep in &service_endpoints {
            ep_w.insert(ep.service_name.clone(), ep.clone());
            Self::register_service_tools(&mut tools_w, ep);
        }

        let tool_count = tools_w.len();
        let svc_count = service_endpoints.len();

        if let Err(e) = self.db.upsert(Self::REGISTRY, serde_json::json!({
            "id": "mcp-registry", "toolCount": tool_count, "serviceCount": svc_count,
            "tools": tools_w.keys().collect::<Vec<_>>(), "updatedAt": Utc::now().to_rfc3339()
        })).await {
            self.logger.error(&format!("Registry save failed: {}", e));
        }

        self.logger.info(&format!("MCP initialized: {} tools from {} services", tool_count, svc_count));
        DataProcessResult::ok(serde_json::json!({
            "tools": {"listChanged": true}, "resources": {"subscribe": true}, "prompts": {"listChanged": true}
        }), &format!("Registered {} tools", tool_count))
    }

    /// List all available tools (MCP protocol: tools/list)
    pub async fn list_tools(&self) -> DataProcessResult<Vec<McpToolDefinition>> {
        let tools = self.tools.read().await;
        let list: Vec<McpToolDefinition> = tools.values().cloned().collect();
        DataProcessResult::ok(list.clone(), &format!("{} tools available", list.len()))
    }

    /// Execute tool call. DNA: DataProcessResult wrapping.
    pub async fn execute_tool(&self, call: McpToolCall) -> DataProcessResult<McpToolResult> {
        let tools = self.tools.read().await;
        if !tools.contains_key(&call.name) {
            return DataProcessResult::err(&format!("Unknown tool: {}", call.name));
        }
        drop(tools);

        let parts: Vec<&str> = call.name.splitn(2, '_').collect();
        let (svc_name, operation) = (parts[0], parts.get(1).unwrap_or(&""));

        let endpoints = self.endpoints.read().await;
        let endpoint = match endpoints.get(svc_name) {
            Some(ep) => ep.clone(),
            None => return DataProcessResult::err(&format!("Service not found: {}", svc_name)),
        };
        drop(endpoints);

        match self.route_tool_call(&endpoint, operation, &call.arguments).await {
            Ok(result) => {
                let _ = self.db.upsert(Self::HISTORY, serde_json::json!({
                    "id": format!("exec-{}", Utc::now().timestamp_millis()),
                    "toolName": call.name, "success": !result.is_error,
                    "executedAt": Utc::now().to_rfc3339()
                })).await;
                DataProcessResult::ok(result, "Tool executed")
            }
            Err(e) => {
                self.logger.error(&format!("MCP execution failed: {}", e));
                DataProcessResult::ok(
                    McpToolResult { content: vec![McpContent { r#type: "text".into(), text: format!("Error: {}", e) }], is_error: true },
                    &e.to_string()
                )
            }
        }
    }

    /// Query tool history. DNA: BuildSearchFilter.
    pub async fn query_history(&self, filters: HashMap<String, String>) -> DataProcessResult<Vec<serde_json::Value>> {
        let clean: HashMap<&str, &str> = filters.iter()
            .filter(|(_, v)| !v.is_empty())
            .map(|(k, v)| (k.as_str(), v.as_str()))
            .collect();
        match self.db.query(Self::HISTORY, serde_json::to_value(&clean).unwrap_or_default()).await {
            Ok(r) => { let c = r.len(); DataProcessResult::ok(r, &format!("Found {} executions", c)) }
            Err(e) => DataProcessResult::err(&e.to_string()),
        }
    }

    // --- Private ---
    fn register_service_tools(tools: &mut HashMap<String, McpToolDefinition>, ep: &ServiceEndpoint) {
        let sn = &ep.service_name;
        let desc = &ep.description;
        for method in &ep.methods {
            let (name, tool_desc, schema) = match method.as_str() {
                "list" => (format!("{}_list", sn), format!("List all {}", desc),
                    serde_json::json!({"type":"object","properties":{"scopeId":{"type":"string"},"limit":{"type":"number"}},"required":["scopeId"]})),
                "get" => (format!("{}_get", sn), format!("Get {} by ID", desc),
                    serde_json::json!({"type":"object","properties":{"id":{"type":"string"},"scopeId":{"type":"string"}},"required":["id","scopeId"]})),
                "create" => (format!("{}_create", sn), format!("Create {}", desc),
                    serde_json::json!({"type":"object","properties":{"scopeId":{"type":"string"},"data":{"type":"object"}},"required":["scopeId","data"]})),
                "search" => (format!("{}_search", sn), format!("Search {}", desc),
                    serde_json::json!({"type":"object","properties":{"scopeId":{"type":"string"},"query":{"type":"object"}},"required":["scopeId"]})),
                _ => continue,
            };
            tools.insert(name.clone(), McpToolDefinition { name, description: tool_desc, input_schema: schema });
        }
    }

    async fn route_tool_call(&self, ep: &ServiceEndpoint, op: &str, args: &serde_json::Value) -> Result<McpToolResult, Box<dyn std::error::Error>> {
        let idx = &ep.index_name;
        let scope_id = args.get("scopeId").and_then(|v| v.as_str()).unwrap_or("");
        let text = match op {
            "list" => {
                let r = self.db.query(idx, serde_json::json!({"scopeId": scope_id})).await?;
                let limit = args.get("limit").and_then(|v| v.as_u64()).unwrap_or(20) as usize;
                serde_json::to_string_pretty(&r[..r.len().min(limit)])?
            }
            "get" => {
                let id = args.get("id").and_then(|v| v.as_str()).unwrap_or("");
                let r = self.db.query(idx, serde_json::json!({"id": id, "scopeId": scope_id})).await?;
                serde_json::to_string_pretty(r.first().unwrap_or(&serde_json::Value::Null))?
            }
            "create" => {
                let data = args.get("data").cloned().unwrap_or(serde_json::json!({}));
                let mut doc = data.as_object().cloned().unwrap_or_default();
                doc.insert("scopeId".into(), scope_id.into());
                doc.insert("createdAt".into(), Utc::now().to_rfc3339().into());
                self.db.upsert(idx, serde_json::Value::Object(doc)).await?;
                format!("Created document in {}", idx)
            }
            "search" => {
                let query = args.get("query").and_then(|v| v.as_object()).cloned().unwrap_or_default();
                let mut clean: serde_json::Map<String, serde_json::Value> = query.into_iter()
                    .filter(|(_, v)| !v.is_null() && v.as_str().map_or(true, |s| !s.is_empty()))
                    .collect();
                clean.insert("scopeId".into(), scope_id.into());
                let r = self.db.query(idx, serde_json::Value::Object(clean)).await?;
                serde_json::to_string_pretty(&r)?
            }
            _ => return Ok(McpToolResult { content: vec![McpContent { r#type: "text".into(), text: format!("Unknown: {}", op) }], is_error: true }),
        };
        Ok(McpToolResult { content: vec![McpContent { r#type: "text".into(), text }], is_error: false })
    }
}
