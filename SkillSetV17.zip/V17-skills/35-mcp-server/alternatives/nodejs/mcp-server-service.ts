/**
 * XIIGen Skill 35: MCP Server — Node.js Alternative
 * Model Context Protocol server giving AI assistants direct API access
 * DNA: DataProcessResult, dynamic documents, scope isolation, generic interfaces
 */
import { DataProcessResult, IDatabaseService, IQueueService } from '../../01-core-interfaces/alternatives/nodejs/core-interfaces';

// --- MCP Protocol Types ---
interface McpToolDefinition {
  name: string;
  description: string;
  inputSchema: { type: string; properties: Record<string, any>; required?: string[] };
}

interface McpToolCall {
  name: string;
  arguments: Record<string, any>;
}

interface McpToolResult {
  content: Array<{ type: 'text'; text: string } | { type: 'resource'; resource: any }>;
  isError?: boolean;
}

interface McpCapabilities {
  tools: { listChanged: boolean };
  resources: { subscribe: boolean; listChanged: boolean };
  prompts: { listChanged: boolean };
}

interface ServiceEndpoint {
  serviceName: string;
  basePath: string;
  methods: string[]; // CRUD operations available
  indexName: string;
  description: string;
}

// --- MCP Server Service ---
export class McpServerService {
  private readonly INDEX = 'mcp-tool-registry';
  private registeredTools: Map<string, McpToolDefinition> = new Map();
  private serviceEndpoints: Map<string, ServiceEndpoint> = new Map();

  constructor(
    private db: IDatabaseService,
    private queue: IQueueService,
    private logger: any,
    private apiBaseUrl: string = 'http://localhost:3000/api'
  ) {}

  /**
   * Initialize MCP server with auto-discovered service endpoints
   * DNA: Dynamic document storage for tool registry
   */
  async initialize(endpoints: ServiceEndpoint[]): Promise<DataProcessResult<McpCapabilities>> {
    try {
      for (const ep of endpoints) {
        this.serviceEndpoints.set(ep.serviceName, ep);
        this.registerServiceTools(ep);
      }

      // DNA: Store registry as dynamic document
      await this.db.upsert(this.INDEX, {
        id: 'mcp-registry',
        toolCount: this.registeredTools.size,
        serviceCount: endpoints.length,
        tools: Array.from(this.registeredTools.keys()),
        updatedAt: new Date().toISOString()
      });

      const capabilities: McpCapabilities = {
        tools: { listChanged: true },
        resources: { subscribe: true, listChanged: true },
        prompts: { listChanged: true }
      };

      this.logger.info(`MCP server initialized: ${this.registeredTools.size} tools from ${endpoints.length} services`);
      return { success: true, data: capabilities, message: `Registered ${this.registeredTools.size} tools` };
    } catch (error: any) {
      return { success: false, data: {} as McpCapabilities, message: error.message };
    }
  }

  /**
   * List all available tools (MCP protocol: tools/list)
   */
  async listTools(): Promise<DataProcessResult<McpToolDefinition[]>> {
    const tools = Array.from(this.registeredTools.values());
    return { success: true, data: tools, message: `${tools.length} tools available` };
  }

  /**
   * Execute a tool call from AI assistant (MCP protocol: tools/call)
   * DNA: DataProcessResult wrapping for every tool execution
   */
  async executeTool(toolCall: McpToolCall): Promise<DataProcessResult<McpToolResult>> {
    try {
      const tool = this.registeredTools.get(toolCall.name);
      if (!tool) {
        return { success: false, data: { content: [{ type: 'text', text: `Unknown tool: ${toolCall.name}` }], isError: true }, message: 'Tool not found' };
      }

      // Parse tool name: {service}_{operation}
      const [serviceName, operation] = toolCall.name.split('_', 2);
      const endpoint = this.serviceEndpoints.get(serviceName);
      if (!endpoint) {
        return { success: false, data: { content: [{ type: 'text', text: `Service not found: ${serviceName}` }], isError: true }, message: 'Service not found' };
      }

      // Route to appropriate handler
      const result = await this.routeToolCall(endpoint, operation, toolCall.arguments);
      return { success: true, data: result, message: 'Tool executed successfully' };
    } catch (error: any) {
      this.logger.error('MCP tool execution failed', { tool: toolCall.name, error: error.message });
      return {
        success: false,
        data: { content: [{ type: 'text', text: `Error: ${error.message}` }], isError: true },
        message: error.message
      };
    }
  }

  /**
   * Query tool execution history with filtering
   * DNA: BuildSearchFilter — skip empty values
   */
  async queryToolHistory(filter: Record<string, any>): Promise<DataProcessResult<any[]>> {
    try {
      const cleanFilter = Object.entries(filter)
        .filter(([_, v]) => v !== null && v !== undefined && v !== '')
        .reduce((acc, [k, v]) => ({ ...acc, [k]: v }), {} as Record<string, any>);
      const results = await this.db.query('mcp-tool-history', cleanFilter);
      return { success: true, data: results, message: `Found ${results.length} executions` };
    } catch (error: any) {
      return { success: false, data: [], message: error.message };
    }
  }

  /**
   * Register a custom prompt template for AI assistants
   */
  async registerPrompt(name: string, description: string, template: string, args: string[]): Promise<DataProcessResult<void>> {
    try {
      await this.db.upsert('mcp-prompts', {
        id: `prompt-${name}`, name, description, template,
        arguments: args, createdAt: new Date().toISOString()
      });
      return { success: true, data: undefined, message: `Prompt '${name}' registered` };
    } catch (error: any) {
      return { success: false, data: undefined, message: error.message };
    }
  }

  // --- Private Helpers ---

  private registerServiceTools(endpoint: ServiceEndpoint): void {
    const { serviceName, description } = endpoint;

    if (endpoint.methods.includes('list')) {
      this.registeredTools.set(`${serviceName}_list`, {
        name: `${serviceName}_list`,
        description: `List all ${description}`,
        inputSchema: {
          type: 'object',
          properties: {
            scopeId: { type: 'string', description: 'Scope/tenant ID' },
            limit: { type: 'number', description: 'Max results (default 20)' },
            offset: { type: 'number', description: 'Pagination offset' }
          },
          required: ['scopeId']
        }
      });
    }

    if (endpoint.methods.includes('get')) {
      this.registeredTools.set(`${serviceName}_get`, {
        name: `${serviceName}_get`,
        description: `Get a specific ${description} by ID`,
        inputSchema: {
          type: 'object',
          properties: {
            id: { type: 'string', description: 'Document ID' },
            scopeId: { type: 'string', description: 'Scope/tenant ID' }
          },
          required: ['id', 'scopeId']
        }
      });
    }

    if (endpoint.methods.includes('create')) {
      this.registeredTools.set(`${serviceName}_create`, {
        name: `${serviceName}_create`,
        description: `Create a new ${description}`,
        inputSchema: {
          type: 'object',
          properties: {
            scopeId: { type: 'string', description: 'Scope/tenant ID' },
            data: { type: 'object', description: 'Document data (dynamic)' }
          },
          required: ['scopeId', 'data']
        }
      });
    }

    if (endpoint.methods.includes('search')) {
      this.registeredTools.set(`${serviceName}_search`, {
        name: `${serviceName}_search`,
        description: `Search ${description} with filters`,
        inputSchema: {
          type: 'object',
          properties: {
            scopeId: { type: 'string', description: 'Scope/tenant ID' },
            query: { type: 'object', description: 'Search filter (DNA: BuildSearchFilter)' }
          },
          required: ['scopeId']
        }
      });
    }
  }

  private async routeToolCall(
    endpoint: ServiceEndpoint, operation: string, args: Record<string, any>
  ): Promise<McpToolResult> {
    // DNA: All operations go through generic database interface
    switch (operation) {
      case 'list': {
        const results = await this.db.query(endpoint.indexName, { scopeId: args.scopeId });
        return { content: [{ type: 'text', text: JSON.stringify(results.slice(0, args.limit || 20), null, 2) }] };
      }
      case 'get': {
        const results = await this.db.query(endpoint.indexName, { id: args.id, scopeId: args.scopeId });
        return { content: [{ type: 'text', text: JSON.stringify(results[0] || null, null, 2) }] };
      }
      case 'create': {
        await this.db.upsert(endpoint.indexName, { ...args.data, scopeId: args.scopeId, createdAt: new Date().toISOString() });
        return { content: [{ type: 'text', text: `Created document in ${endpoint.indexName}` }] };
      }
      case 'search': {
        const cleanQuery = Object.entries(args.query || {})
          .filter(([_, v]) => v !== null && v !== '')
          .reduce((acc, [k, v]) => ({ ...acc, [k]: v }), { scopeId: args.scopeId } as Record<string, any>);
        const results = await this.db.query(endpoint.indexName, cleanQuery);
        return { content: [{ type: 'text', text: JSON.stringify(results, null, 2) }] };
      }
      default:
        return { content: [{ type: 'text', text: `Unknown operation: ${operation}` }], isError: true };
    }
  }
}

// --- Express MCP Endpoint ---
export function createMcpRouter(mcpService: McpServerService) {
  return {
    async handleRequest(req: any, res: any) {
      const { method, params } = req.body;
      switch (method) {
        case 'tools/list': { const r = await mcpService.listTools(); res.json(r.data); break; }
        case 'tools/call': { const r = await mcpService.executeTool(params); res.json(r.data); break; }
        default: res.status(400).json({ error: `Unknown method: ${method}` });
      }
    }
  };
}
