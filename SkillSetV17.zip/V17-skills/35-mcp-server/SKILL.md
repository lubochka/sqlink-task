---
skill_id: "35"
name: mcp-server
title: "MCP Server — AI API Access"
layer: "L8: Quality Assurance"
version: "17.1"
status: "active"
priority: "P0"
dependencies: ["01-core-interfaces", "15-api-gateway", "34-swagger-openapi"]
alternatives_server: [nodejs-mcp-sdk, python-mcp, java-mcp, rust-mcp, php-mcp]
genie_dna:
  - "DNA-MCP: AI tools get direct access to all XIIGen APIs for integration and debugging"
  - "DNA-6: MCP server exposes generic interfaces — AI doesn't need service-specific knowledge"
  - "DNA-RESULT: Every MCP tool call returns DataProcessResult for AI error handling"
triggers: mcp, model context protocol, ai access, ai tools, ai integration, tool use, function calling
estimated_loc: 700
---

# Skill 35: MCP Server — AI API Access
## Give AI Assistants Direct Access to All XIIGen APIs

**Classification:** MACHINE — MCP protocol definitions are static  
**Priority:** P0 — Critical for AI-driven development and debugging  
**Dependencies:** Skill 01 (Core), Skill 15 (API Gateway), Skill 34 (Swagger)  
**Layer:** L8: Quality Assurance  
**Estimated LOC:** ~700  

---

## Overview

The MCP (Model Context Protocol) Server exposes all XIIGen microservice APIs as tools that AI assistants (Claude, Cursor, Copilot, Cline) can call directly. It transforms OpenAPI specs (Skill 34) into MCP tool definitions, handles authentication, rate limiting, and result formatting. This enables AI to: query flow execution status, inspect debug data, trigger deployments, search documentation, manage feedback, and generate code — all through natural language tool calls.

## Key Concepts

- **Auto-Discovery** — MCP tools are auto-generated from OpenAPI specs. Adding a new endpoint automatically exposes it to AI.
- **Tool Categories** — Tools grouped by domain: flow management, debugging, code generation, documentation, deployment, feedback.
- **Context Injection** — MCP server enriches AI tool calls with relevant context from RAG (Skill 00a) and recent execution history.
- **Safety Layer** — Read-only tools available by default. Write/deploy tools require explicit user approval via confirmation prompts.
- **Streaming Results** — Long-running operations (code gen, deployment) stream progress updates back to AI.

---

## DNA Integration

### Required Patterns
- **DataProcessResult** — Every MCP tool returns `DataProcessResult` so AI can handle errors gracefully.
- **Dynamic Document** — MCP request/response logs stored as dynamic documents for audit and improvement.
- **Scope Isolation** — Each MCP session is scoped to a project/user. Tools cannot access other users' data.
- **BuildSearchFilter** — AI search tools use BuildSearchFilter internally, enabling natural queries like "find failed pipelines last week."

### Anti-Patterns to AVOID
- ❌ Manually defining MCP tools — auto-generate from OpenAPI specs
- ❌ Allowing write operations without user confirmation
- ❌ Exposing internal implementation details in tool descriptions — keep descriptions API-level
- ❌ Returning raw error stacks to AI — wrap in DataProcessResult with actionable messages

---

## Primary Implementation (.NET 9)

### Models

```csharp
namespace XIIGen.Mcp.Models;

public record McpToolDefinition(
    string Name,
    string Description,
    string Category,       // flow | debug | code | docs | deploy | feedback
    List<McpParameter> Parameters,
    string ReturnType,
    bool RequiresConfirmation,
    string[] Tags
);

public record McpParameter(
    string Name, string Type, string Description,
    bool Required, object DefaultValue = null
);

public record McpToolCall(
    string ToolName, Dictionary<string, object> Arguments,
    string SessionId, string UserId, DateTime CalledAt
);

public record McpToolResult(
    bool Success, object Data, string Message,
    TimeSpan Duration, string[] Suggestions
);
```

### Service Interface

```csharp
namespace XIIGen.Mcp.Interfaces;

public interface IMcpServer
{
    Task<DataProcessResult<List<McpToolDefinition>>> ListToolsAsync(string category = null, CancellationToken ct = default);
    Task<DataProcessResult<McpToolResult>> ExecuteToolAsync(McpToolCall call, CancellationToken ct = default);
    Task<DataProcessResult<bool>> RefreshToolsFromSpecAsync(CancellationToken ct = default);
    Task<DataProcessResult<List<Dictionary<string, object>>>> GetToolCallHistoryAsync(Dictionary<string, object> filters, CancellationToken ct = default);
}
```

### Core Implementation

```csharp
public class McpServer : IMcpServer
{
    private readonly IDatabaseService _db;
    private readonly ISwaggerService _swagger;
    private readonly HttpClient _httpClient;
    private readonly ILogger<McpServer> _logger;
    private List<McpToolDefinition> _tools = new();

    public async Task<DataProcessResult<McpToolResult>> ExecuteToolAsync(
        McpToolCall call, CancellationToken ct = default)
    {
        try
        {
            var tool = _tools.FirstOrDefault(t => t.Name == call.ToolName);
            if (tool == null) return DataProcessResult<McpToolResult>.Fail($"Tool not found: {call.ToolName}");

            if (tool.RequiresConfirmation)
                return DataProcessResult<McpToolResult>.Fail("CONFIRMATION_REQUIRED: This tool modifies data. Please confirm.");

            var result = await RouteToServiceAsync(tool, call.Arguments, ct);
            
            // DNA: Log as dynamic document
            await _db.UpsertAsync("mcp-calls", new Dictionary<string, object>
            {
                ["id"] = Guid.NewGuid().ToString(),
                ["toolName"] = call.ToolName,
                ["arguments"] = call.Arguments,
                ["result"] = result,
                ["sessionId"] = call.SessionId,
                ["userId"] = call.UserId,
                ["calledAt"] = call.CalledAt
            }, ct);

            return DataProcessResult<McpToolResult>.Ok(result);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "MCP tool execution failed: {Tool}", call.ToolName);
            return DataProcessResult<McpToolResult>.Fail(ex.Message);
        }
    }
}
```

### DI Registration

```csharp
services.AddSingleton<IMcpServer, McpServer>();
services.AddHostedService<McpToolRefreshService>(); // Periodically refreshes tools from specs
```

---

## Test Scenarios

1. List all tools → verify categories match service domains
2. Execute read-only tool (query flows) → verify DataProcessResult returned
3. Execute write tool (trigger deploy) → verify CONFIRMATION_REQUIRED response
4. Refresh tools after adding new endpoint → verify new tool appears
5. Query tool call history by session → verify BuildSearchFilter used
6. AI calls non-existent tool → verify graceful error with suggestions
7. Rate limit exceeded → verify appropriate throttling response

## Component Classification
- **Category:** AI Integration
- **Inputs:** Tool calls from AI assistants, OpenAPI specs
- **Outputs:** Tool execution results, tool definitions, call history
- **Side Effects:** Routes calls to microservices, logs call history
- **ES Indexes:** `mcp-calls`, `mcp-tools`
