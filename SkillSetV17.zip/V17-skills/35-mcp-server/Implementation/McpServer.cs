// XIIGen.Skills.McpServer/McpServer.cs | .NET 9 | Skill 35
// Model Context Protocol (MCP) server that exposes all XIIGen APIs as tools
// for AI agents to query, debug, modify, and integrate system components.
// Protocol: JSON-RPC 2.0 over stdio/SSE

using System.Text.Json;
using System.Text.Json.Serialization;
using Microsoft.Extensions.Logging;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Skills.McpServer;

public class McpServer
{
    private readonly IDatabaseService _db;
    private readonly IQueueService _queue;
    private readonly IAiProvider _ai;
    private readonly ILogger<McpServer> _logger;
    private readonly Dictionary<string, Func<JsonElement, Task<object>>> _tools = [];

    public McpServer(IDatabaseService db, IQueueService queue, IAiProvider ai, ILogger<McpServer> logger)
    {
        _db = db; _queue = queue; _ai = ai; _logger = logger;
        RegisterTools();
    }

    // ═══════════════════════════════════════════════════════
    // MCP PROTOCOL HANDLER
    // ═══════════════════════════════════════════════════════

    public async Task HandleRequestAsync(Stream input, Stream output, CancellationToken ct)
    {
        using var reader = new StreamReader(input);
        using var writer = new StreamWriter(output) { AutoFlush = true };

        while (!ct.IsCancellationRequested)
        {
            var line = await reader.ReadLineAsync(ct);
            if (line == null) break;

            try
            {
                var request = JsonSerializer.Deserialize<JsonRpcRequest>(line);
                var response = await ProcessRequestAsync(request, ct);
                await writer.WriteLineAsync(JsonSerializer.Serialize(response));
            }
            catch (Exception ex)
            {
                var error = new JsonRpcResponse
                {
                    Id = null, Error = new JsonRpcError { Code = -32603, Message = ex.Message }
                };
                await writer.WriteLineAsync(JsonSerializer.Serialize(error));
            }
        }
    }

    private async Task<JsonRpcResponse> ProcessRequestAsync(JsonRpcRequest request, CancellationToken ct)
    {
        return request.Method switch
        {
            "initialize" => new JsonRpcResponse
            {
                Id = request.Id,
                Result = new
                {
                    protocolVersion = "2024-11-05",
                    capabilities = new
                    {
                        tools = new { listChanged = true },
                        resources = new { subscribe = false, listChanged = false }
                    },
                    serverInfo = new { name = "xiigen-mcp", version = "1.0.0" }
                }
            },
            "tools/list" => new JsonRpcResponse
            {
                Id = request.Id,
                Result = new { tools = GetToolDefinitions() }
            },
            "tools/call" => await HandleToolCallAsync(request, ct),
            _ => new JsonRpcResponse
            {
                Id = request.Id,
                Error = new JsonRpcError { Code = -32601, Message = $"Unknown method: {request.Method}" }
            }
        };
    }

    // ═══════════════════════════════════════════════════════
    // TOOL DEFINITIONS - All XIIGen capabilities exposed
    // ═══════════════════════════════════════════════════════

    private void RegisterTools()
    {
        // ─── Flow Management ─────────────────────────────
        _tools["trigger_flow"] = async (args) =>
        {
            var flowId = args.GetProperty("flow_id").GetString();
            var body = args.GetProperty("body");
            var traceId = Guid.NewGuid().ToString();
            await _queue.EnqueueAsync("xiigen.flows.trigger", new { flowId, traceId, body });
            return new { traceId, status = "triggered" };
        };

        _tools["get_flow_status"] = async (args) =>
        {
            var traceId = args.GetProperty("trace_id").GetString();
            var result = await _db.GetDocumentAsync<object>("flow-executions", "xiigen", traceId);
            return result.IsSuccess ? result.Data : new { error = "Not found" };
        };

        _tools["list_flows"] = async (args) =>
        {
            var results = await _db.SearchDocumentsAsync<object>("flow-definitions", "xiigen",
                new SearchOptions { Size = args.TryGetProperty("limit", out var l) ? l.GetInt32() : 20 });
            return results.Data ?? new List<object>();
        };

        _tools["get_flow_definition"] = async (args) =>
        {
            var flowId = args.GetProperty("flow_id").GetString();
            return (await _db.GetDocumentAsync<object>("flow-definitions", "xiigen", flowId)).Data;
        };

        // ─── Step Results & Debugging ────────────────────
        _tools["get_step_results"] = async (args) =>
        {
            var traceId = args.GetProperty("trace_id").GetString();
            var results = await _db.SearchDocumentsAsync<object>("step-results", "xiigen",
                new SearchOptions { Conditions = [new SearchCondition { Property = "traceId", Value = traceId }] });
            return results.Data ?? [];
        };

        _tools["get_step_prompts"] = async (args) =>
        {
            var traceId = args.GetProperty("trace_id").GetString();
            var results = await _db.SearchDocumentsAsync<object>("step-prompts", "xiigen",
                new SearchOptions { Conditions = [new SearchCondition { Property = "traceId", Value = traceId }] });
            return results.Data ?? [];
        };

        _tools["get_step_logs"] = async (args) =>
        {
            var traceId = args.GetProperty("trace_id").GetString();
            var level = args.TryGetProperty("level", out var lv) ? lv.GetString() : null;
            var conditions = new List<SearchCondition>
            {
                new() { Property = "traceId", Value = traceId }
            };
            if (level != null) conditions.Add(new() { Property = "level", Value = level });
            var results = await _db.SearchDocumentsAsync<object>("service-logs", "xiigen",
                new SearchOptions { Conditions = conditions, Size = 100 });
            return results.Data ?? [];
        };

        // ─── Feedback ────────────────────────────────────
        _tools["submit_feedback"] = async (args) =>
        {
            var traceId = args.GetProperty("trace_id").GetString();
            var stepId = args.GetProperty("step_id").GetString();
            var rating = args.GetProperty("rating").GetString();
            var text = args.TryGetProperty("text", out var t) ? t.GetString() : null;
            var id = $"{traceId}-{stepId}-fb";
            await _db.StoreDocumentAsync("user-feedback", "xiigen", id, new
            {
                traceId, stepId, rating, comment = text, createdAt = DateTime.UtcNow
            });
            return new { id, status = "stored" };
        };

        _tools["get_feedback"] = async (args) =>
        {
            var traceId = args.GetProperty("trace_id").GetString();
            var results = await _db.SearchDocumentsAsync<object>("user-feedback", "xiigen",
                new SearchOptions { Conditions = [new SearchCondition { Property = "traceId", Value = traceId }] });
            return results.Data ?? [];
        };

        // ─── Database Operations ─────────────────────────
        _tools["query_index"] = async (args) =>
        {
            var index = args.GetProperty("index").GetString();
            var filter = args.TryGetProperty("filter", out var f) ? f : default;
            var size = args.TryGetProperty("limit", out var s) ? s.GetInt32() : 10;
            var results = await _db.SearchDocumentsAsync<object>(index, "xiigen",
                new SearchOptions { Size = size });
            return results.Data ?? [];
        };

        _tools["get_document"] = async (args) =>
        {
            var index = args.GetProperty("index").GetString();
            var id = args.GetProperty("id").GetString();
            return (await _db.GetDocumentAsync<object>(index, "xiigen", id)).Data;
        };

        _tools["store_document"] = async (args) =>
        {
            var index = args.GetProperty("index").GetString();
            var id = args.GetProperty("id").GetString();
            var doc = args.GetProperty("document");
            await _db.StoreDocumentAsync(index, "xiigen", id, doc);
            return new { id, index, status = "stored" };
        };

        // ─── AI Operations ──────────────────────────────
        _tools["execute_ai_prompt"] = async (args) =>
        {
            var prompt = args.GetProperty("prompt").GetString();
            var system = args.TryGetProperty("system_prompt", out var sp) ? sp.GetString() : null;
            var maxTokens = args.TryGetProperty("max_tokens", out var mt) ? mt.GetInt32() : 2000;
            var response = await _ai.ExecuteAsync(new AiRequest
            {
                Prompt = prompt, SystemPrompt = system, MaxTokens = maxTokens
            });
            return new { response.Content, response.Model, response.TokensIn, response.TokensOut };
        };

        // ─── Code Generation ─────────────────────────────
        _tools["generate_code"] = async (args) =>
        {
            var description = args.GetProperty("description").GetString();
            var language = args.TryGetProperty("language", out var lang) ? lang.GetString() : "csharp";
            var response = await _ai.ExecuteAsync(new AiRequest
            {
                SystemPrompt = $"Generate production-quality {language} code. Follow XIIGen patterns.",
                Prompt = description, MaxTokens = 8000
            });
            return new { code = response.Content, language };
        };

        // ─── System Health ──────────────────────────────
        _tools["health_check"] = async (args) =>
        {
            var dbHealth = await _db.IndexExistsAsync("flow-definitions", "xiigen");
            return new
            {
                database = dbHealth ? "healthy" : "unhealthy",
                timestamp = DateTime.UtcNow
            };
        };

        _tools["get_system_metrics"] = async (args) =>
        {
            var results = await _db.SearchDocumentsAsync<object>("system-metrics", "xiigen",
                new SearchOptions { Size = 1, SortField = "timestamp", SortDescending = true });
            return results.Data?.FirstOrDefault() ?? new { status = "no metrics" };
        };
    }

    private List<McpToolDefinition> GetToolDefinitions() =>
    [
        new("trigger_flow", "Trigger execution of a flow pipeline",
            new { type = "object", properties = new { flow_id = new { type = "string" }, body = new { type = "object" } }, required = new[] { "flow_id" } }),
        new("get_flow_status", "Get current status of a flow execution",
            new { type = "object", properties = new { trace_id = new { type = "string" } }, required = new[] { "trace_id" } }),
        new("list_flows", "List all available flow definitions",
            new { type = "object", properties = new { limit = new { type = "integer", @default = 20 } } }),
        new("get_flow_definition", "Get a specific flow definition",
            new { type = "object", properties = new { flow_id = new { type = "string" } }, required = new[] { "flow_id" } }),
        new("get_step_results", "Get all step results for a trace",
            new { type = "object", properties = new { trace_id = new { type = "string" } }, required = new[] { "trace_id" } }),
        new("get_step_prompts", "Get AI prompts and responses for a trace",
            new { type = "object", properties = new { trace_id = new { type = "string" } }, required = new[] { "trace_id" } }),
        new("get_step_logs", "Get service logs for a trace",
            new { type = "object", properties = new { trace_id = new { type = "string" }, level = new { type = "string" } }, required = new[] { "trace_id" } }),
        new("submit_feedback", "Submit feedback on a step result",
            new { type = "object", properties = new { trace_id = new { type = "string" }, step_id = new { type = "string" }, rating = new { type = "string", @enum = new[] { "Positive", "Neutral", "Negative" } }, text = new { type = "string" } }, required = new[] { "trace_id", "step_id", "rating" } }),
        new("get_feedback", "Get all feedback for a trace",
            new { type = "object", properties = new { trace_id = new { type = "string" } }, required = new[] { "trace_id" } }),
        new("query_index", "Query any Elasticsearch index",
            new { type = "object", properties = new { index = new { type = "string" }, limit = new { type = "integer" } }, required = new[] { "index" } }),
        new("get_document", "Get a specific document by ID",
            new { type = "object", properties = new { index = new { type = "string" }, id = new { type = "string" } }, required = new[] { "index", "id" } }),
        new("store_document", "Store/update a document",
            new { type = "object", properties = new { index = new { type = "string" }, id = new { type = "string" }, document = new { type = "object" } }, required = new[] { "index", "id", "document" } }),
        new("execute_ai_prompt", "Execute an AI prompt directly",
            new { type = "object", properties = new { prompt = new { type = "string" }, system_prompt = new { type = "string" }, max_tokens = new { type = "integer" } }, required = new[] { "prompt" } }),
        new("generate_code", "Generate code from description",
            new { type = "object", properties = new { description = new { type = "string" }, language = new { type = "string" } }, required = new[] { "description" } }),
        new("health_check", "Check system health",
            new { type = "object", properties = new { } }),
        new("get_system_metrics", "Get latest system metrics",
            new { type = "object", properties = new { } }),
    ];

    private async Task<JsonRpcResponse> HandleToolCallAsync(JsonRpcRequest request, CancellationToken ct)
    {
        var toolName = request.Params?.GetProperty("name").GetString();
        var args = request.Params?.GetProperty("arguments") ?? default;

        if (toolName == null || !_tools.TryGetValue(toolName, out var handler))
            return new JsonRpcResponse { Id = request.Id, Error = new JsonRpcError { Code = -32602, Message = $"Unknown tool: {toolName}" } };

        try
        {
            var result = await handler(args);
            return new JsonRpcResponse
            {
                Id = request.Id,
                Result = new { content = new[] { new { type = "text", text = JsonSerializer.Serialize(result) } } }
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "MCP tool {Tool} failed", toolName);
            return new JsonRpcResponse
            {
                Id = request.Id,
                Result = new { content = new[] { new { type = "text", text = $"Error: {ex.Message}" } }, isError = true }
            };
        }
    }
}

// ─── JSON-RPC Models ─────────────────────────────────────
public class JsonRpcRequest
{
    [JsonPropertyName("jsonrpc")] public string JsonRpc { get; set; } = "2.0";
    [JsonPropertyName("id")] public object Id { get; set; }
    [JsonPropertyName("method")] public string Method { get; set; }
    [JsonPropertyName("params")] public JsonElement? Params { get; set; }
}
public class JsonRpcResponse
{
    [JsonPropertyName("jsonrpc")] public string JsonRpc { get; set; } = "2.0";
    [JsonPropertyName("id")] public object Id { get; set; }
    [JsonPropertyName("result")] public object Result { get; set; }
    [JsonPropertyName("error")] public JsonRpcError Error { get; set; }
}
public class JsonRpcError
{
    [JsonPropertyName("code")] public int Code { get; set; }
    [JsonPropertyName("message")] public string Message { get; set; }
}
public record McpToolDefinition(string name, string description, object inputSchema);
