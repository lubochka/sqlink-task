---
name: figma-parser
description: Parses Figma API JSON and FigmaCodeGenerator Element trees into structured HTML/CSS component fragments for AI processing
triggers: figma parser, parse figma, figma to html, figma components, figma node tree, design extraction
dependencies: [01-core-interfaces, 02-object-processor]
layer: L4-StepExecutors
genie-dna: All parsed components stored as dynamic documents via ObjectProcessor. Component queries use BuildSearchFilter with empty-field skipping.
phase: 3
---

# Skill 10: Figma Parser
## Converts Figma Node Trees → Structured HTML/CSS Component Fragments

The **ingredient prep station** of the pipeline. Takes raw Figma JSON (either from Figma REST API or from the FigmaCodeGenerator plugin's Element tree) and produces clean, structured component fragments that AI models can understand and transform into production code.

---

## Architecture

```
Input Sources:
  A) Figma REST API JSON (via /v1/files/:key/nodes)
  B) FigmaCodeGenerator Element[] (via Skill 39 webhook)
  C) Direct JSON paste (user uploads raw nodes)
       ↓
  FigmaParser.ExecuteAsync(context)
       ↓ Detects input format (API vs Element vs raw)
       ↓ Routes to appropriate parser
       ↓
  ParseFigmaApiNodes()          ParsePluginElements()
       ↓                              ↓
  ExtractComponents()           MapElementToComponent()
       ↓ layoutMode→flexbox         ↓ code→html, codeCss→css
       ↓ fills→background            ↓ style→css properties
       ↓ effects→box-shadow          ↓ subElements→children
       ↓ constraints→responsive      ↓ parentSettings→context
       ↓                              ↓
       └──────────┬───────────────────┘
                  ↓
  List<Dictionary<string,object>> components (dynamic documents)
       ↓
  BuildComponentTree()   → parent-child hierarchy
  DetectPatterns()       → lists, cards, navs, forms, modals
  ExtractDesignTokens()  → colors, fonts, spacing used
  GenerateComponentMap() → screen-level summary
       ↓
  StepExecutionResult.Ok(output)
       ↓ output = { components[], tree, patterns[], tokens, screenMap }
```

## Input Formats

### A: Figma REST API Format
```json
{
  "document": {
    "children": [{
      "id": "1:2", "name": "Frame", "type": "FRAME",
      "layoutMode": "VERTICAL", "itemSpacing": 8,
      "fills": [{ "type": "SOLID", "color": { "r": 1, "g": 1, "b": 1, "a": 1 } }],
      "children": [...]
    }]
  }
}
```

### B: FigmaCodeGenerator Element Format
```json
[{
  "name": "Header", "sourceType": "FRAME", "type": "div",
  "containingString": null,
  "style": { "width": "390", "height": "64" },
  "code": "<div class=\"header\">",
  "codeCss": ".header { display: flex; }",
  "subElements": [...]
}]
```

## Key Features

### 1. Multi-Format Detection
Automatically detects whether input is Figma API JSON, FigmaCodeGenerator Elements, or raw node arrays. Inspects JSON structure — no configuration needed.

### 2. CSS Extraction (Figma API → CSS)
Maps Figma layout properties to CSS:
- `layoutMode` → `display: flex; flex-direction`
- `primaryAxisAlignItems` → `justify-content`
- `fills[].color` → `background-color: rgba(...)`
- `effects[].type: DROP_SHADOW` → `box-shadow`
- `strokes` → `border`, `cornerRadius` → `border-radius`
- Auto-layout → full flexbox model with gap, padding, alignment

### 3. Pattern Detection
Identifies common UI patterns from the component tree:
- **Lists/Repeaters**: 3+ siblings with same structure
- **Cards**: Container with image + text + optional action
- **Navigation**: Horizontal layout with icon+text items
- **Forms**: Containers with labeled input-like elements
- **Modals**: Overlapping layers with backdrop
- **Headers/Footers**: Top/bottom positioned full-width elements

### 4. Design Token Extraction
Collects unique design values: color palette (with frequency), typography scale, spacing values, border radius, shadow definitions.

### 5. Screen-Level Summary
Generates high-level map: screen name → component list with hierarchy depth, enabling AI to understand overall structure before details.

## Genie DNA Integration

### DNA-1: Dynamic Documents
All parsed components are `Dictionary<string, object>` — no fixed model class. Extra Figma properties pass through, AI metadata coexists, schema-free ES storage.

### DNA-2: Empty-Field Skipping
Component queries use `BuildSearchFilter` — search by any combination of type, name, pattern, screen.

### DNA-5: DataProcessResult
All parsing returns success/failure with error details per component, not just pass/fail for the whole batch.

## Configuration
```json
{
  "figmaParser": {
    "maxDepth": 20,
    "detectPatterns": true,
    "extractTokens": true,
    "includeInvisible": false,
    "imageHandling": "placeholder",
    "cssUnit": "px",
    "classNameStrategy": "kebab-case"
  }
}
```

## Dependencies
| Skill | Usage |
|---|---|
| 01-core-interfaces | IStepExecutor, StepExecutionContext, MicroserviceBase |
| 02-object-processor | ParseObjectAlternative for dynamic docs, MergeObjects |

## Alternatives
| Language | File | Notes |
|---|---|---|
| .NET 9 (primary) | `Implementation/FigmaParser.cs` | Full feature set |
| Node.js/TypeScript | `alternatives/nodejs/figma-parser.ts` | Closest to Figma API native |
| Python | `alternatives/python/figma_parser.py` | Good for ML pipeline integration |
| Java | `alternatives/java/FigmaParser.java` | Enterprise deployments |
| Rust | `alternatives/rust/figma_parser.rs` | High-performance batch parsing |
| PHP | `alternatives/php/FigmaParser.php` | WordPress/CMS integration |
