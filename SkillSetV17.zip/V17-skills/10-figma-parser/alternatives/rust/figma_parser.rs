// XIIGen Skill 10: Figma Parser | Rust
// Parses Figma API JSON + FigmaCodeGenerator Elements -> structured components
// Uses serde_json::Value as dynamic document (Genie DNA-1)

use serde_json::{json, Value, Map};
use std::collections::HashMap;
use regex::Regex;
use uuid::Uuid;

pub struct FigmaParserConfig {
    pub max_depth: usize, pub detect_patterns: bool, pub extract_tokens: bool,
    pub include_invisible: bool, pub css_unit: String,
}
impl Default for FigmaParserConfig {
    fn default() -> Self { Self { max_depth: 20, detect_patterns: true, extract_tokens: true, include_invisible: false, css_unit: "px".into() } }
}

pub struct FigmaParser { config: FigmaParserConfig }

#[derive(Debug, PartialEq)] pub enum InputFormat { FigmaApi, PluginElement, RawNodeArray }

impl FigmaParser {
    pub fn new(config: FigmaParserConfig) -> Self { Self { config } }
    pub fn node_type_name(&self) -> &str { "FigmaParser" }

    pub async fn execute_async(&self, context: &Value) -> Value {
        let input = context.get("input").unwrap_or(&Value::Null);
        let format = self.detect_format(input);
        let components = match format {
            InputFormat::FigmaApi => self.parse_figma_api_nodes(input),
            InputFormat::PluginElement => self.parse_plugin_elements(input),
            InputFormat::RawNodeArray => self.parse_raw_nodes(input),
        };
        let tree = self.build_component_tree(&components);
        let patterns = if self.config.detect_patterns { self.detect_patterns_list(&components) } else { vec![] };
        let tokens = if self.config.extract_tokens { self.extract_design_tokens(&components) } else { json!({}) };
        json!({"success": true, "output": {"components": components, "tree": tree, "patterns": patterns, "tokens": tokens,
            "metadata": {"format": format!("{:?}", format), "componentCount": components.len()}}})
    }

    pub fn detect_format(&self, input: &Value) -> InputFormat {
        if input.is_object() && input.get("document").is_some() { return InputFormat::FigmaApi; }
        if let Some(arr) = input.as_array() {
            if let Some(first) = arr.first() {
                if first.get("sourceType").is_some() && first.get("code").is_some() { return InputFormat::PluginElement; }
            }
        }
        InputFormat::RawNodeArray
    }

    pub fn parse_figma_api_nodes(&self, root: &Value) -> Vec<Value> {
        let mut comps = Vec::new();
        let start = root.get("document").unwrap_or(root);
        self.extract_api(start, &mut comps, None, 0);
        comps
    }

    fn extract_api(&self, node: &Value, comps: &mut Vec<Value>, parent_id: Option<&str>, depth: usize) {
        if depth > self.config.max_depth { return; }
        if let Some(arr) = node.as_array() { for n in arr { self.extract_api(n, comps, parent_id, depth); } return; }
        let obj = match node.as_object() { Some(o) => o, None => return };
        if !self.config.include_invisible { if let Some(v) = obj.get("visible") { if !v.as_bool().unwrap_or(true) { return; } } }

        let id = obj.get("id").and_then(|v| v.as_str()).unwrap_or(&Uuid::new_v4().to_string()).to_string();
        let name = obj.get("name").and_then(|v| v.as_str()).unwrap_or("unknown").to_string();
        let ntype = obj.get("type").and_then(|v| v.as_str()).unwrap_or("FRAME").to_string();
        let css = self.extract_css_api(obj);
        let tag = match ntype.as_str() { "TEXT" => "span", "VECTOR" => "svg", _ => "div" };
        let class_name = Self::sanitize(&name);

        let mut comp = json!({"id": id, "name": name, "type": ntype, "parentId": parent_id, "css": css,
            "html": format!("<{} class=\"{}\">", tag, class_name), "depth": depth, "className": class_name});
        if ntype == "TEXT" { if let Some(ch) = obj.get("characters") { comp["textContent"] = ch.clone(); } }
        comps.push(comp);
        if let Some(children) = obj.get("children").and_then(|c| c.as_array()) {
            for child in children { self.extract_api(child, comps, Some(&id), depth + 1); }
        }
    }

    pub fn parse_plugin_elements(&self, elements: &Value) -> Vec<Value> {
        let mut comps = Vec::new();
        let arr = if elements.is_array() { elements.as_array().unwrap().to_vec() } else { vec![elements.clone()] };
        for el in &arr { self.map_element(el, &mut comps, None, 0); }
        comps
    }

    fn map_element(&self, el: &Value, comps: &mut Vec<Value>, parent_id: Option<&str>, depth: usize) {
        if depth > self.config.max_depth { return; }
        let obj = match el.as_object() { Some(o) => o, None => return };
        let id = Uuid::new_v4().to_string();
        let name = obj.get("name").and_then(|v| v.as_str()).unwrap_or("element").to_string();
        let ntype = obj.get("sourceType").and_then(|v| v.as_str()).unwrap_or("FRAME").to_string();
        let code = obj.get("code").and_then(|v| v.as_str()).unwrap_or("").to_string();
        let tag = match ntype.as_str() { "TEXT" => "span", "VECTOR" => "svg", _ => "div" };
        let class_name = Self::sanitize(&name);
        let html = if code.is_empty() { format!("<{} class=\"{}\">", tag, class_name) } else { code };

        let mut css = serde_json::Map::new();
        if let Some(style) = obj.get("style").and_then(|v| v.as_object()) {
            for (k, v) in style { css.insert(Self::camel_to_kebab(k), json!(v.as_str().unwrap_or(&v.to_string()))); }
        }
        let mut comp = json!({"id": id, "name": name, "type": ntype, "parentId": parent_id, "css": css, "html": html,
            "depth": depth, "className": class_name, "pluginGenerated": true});
        if let Some(cs) = obj.get("containingString").and_then(|v| v.as_str()) { comp["textContent"] = json!(cs); }
        comps.push(comp);
        if let Some(subs) = obj.get("subElements").and_then(|v| v.as_array()) {
            for sub in subs { self.map_element(sub, comps, Some(&id), depth + 1); }
        }
    }

    pub fn parse_raw_nodes(&self, input: &Value) -> Vec<Value> {
        let mut comps = Vec::new();
        if input.is_array() { for n in input.as_array().unwrap() { self.extract_api(n, &mut comps, None, 0); } }
        else { self.extract_api(input, &mut comps, None, 0); }
        comps
    }

    fn extract_css_api(&self, node: &Map<String, Value>) -> Value {
        let mut css = serde_json::Map::new();
        let u = &self.config.css_unit;
        if let Some(lm) = node.get("layoutMode").and_then(|v| v.as_str()) {
            css.insert("display".into(), json!("flex"));
            css.insert("flex-direction".into(), json!(if lm == "VERTICAL" { "column" } else { "row" }));
        }
        if let Some(s) = node.get("itemSpacing").and_then(|v| v.as_f64()) { css.insert("gap".into(), json!(format!("{}{}", s, u))); }
        if let Some(bb) = node.get("absoluteBoundingBox").and_then(|v| v.as_object()) {
            if let Some(w) = bb.get("width").and_then(|v| v.as_f64()) { css.insert("width".into(), json!(format!("{}{}", w, u))); }
            if let Some(h) = bb.get("height").and_then(|v| v.as_f64()) { css.insert("height".into(), json!(format!("{}{}", h, u))); }
        }
        if let Some(r) = node.get("cornerRadius").and_then(|v| v.as_f64()) { css.insert("border-radius".into(), json!(format!("{}{}", r, u))); }
        Value::Object(css)
    }

    pub fn build_component_tree(&self, components: &[Value]) -> Vec<Value> {
        let mut lookup: HashMap<String, Value> = HashMap::new();
        for c in components { if let Some(id) = c.get("id").and_then(|v| v.as_str()) { lookup.insert(id.to_string(), c.clone()); } }
        components.iter().filter(|c| { let pid = c.get("parentId").and_then(|v| v.as_str()); pid.is_none() || !lookup.contains_key(pid.unwrap_or("")) }).cloned().collect()
    }

    pub fn detect_patterns_list(&self, _components: &[Value]) -> Vec<Value> { vec![] }
    pub fn extract_design_tokens(&self, _components: &[Value]) -> Value { json!({"colors": {}, "fontSizes": {}, "spacings": {}}) }

    fn sanitize(name: &str) -> String { name.replace(' ', "-").to_lowercase().chars().filter(|c| c.is_alphanumeric() || *c == '-').collect() }
    fn camel_to_kebab(s: &str) -> String { Regex::new(r"([a-z])([A-Z])").unwrap().replace_all(s, "$1-$2").to_lowercase() }
}
