// XIIGen Skill 10: Figma Parser | Node.js/TypeScript
// Parses Figma API JSON + FigmaCodeGenerator Elements → structured components
// All output as dynamic Records (Genie DNA-1)

import { IStepExecutor, StepExecutionContext, StepExecutionResult, IObjectProcessor } from '../../core/interfaces';

export interface FigmaParserConfig {
  maxDepth?: number; detectPatterns?: boolean; extractTokens?: boolean;
  includeInvisible?: boolean; cssUnit?: string;
}

type Component = Record<string, unknown>;
type CssMap = Record<string, string>;
enum InputFormat { FigmaApi = 'FigmaApi', PluginElement = 'PluginElement', RawNodeArray = 'RawNodeArray' }

export class FigmaParser implements IStepExecutor {
  readonly nodeTypeName = 'FigmaParser';
  private config: Required<FigmaParserConfig>;
  private objectProcessor: IObjectProcessor;

  constructor(objectProcessor: IObjectProcessor, config?: FigmaParserConfig) {
    this.objectProcessor = objectProcessor;
    this.config = { maxDepth: 20, detectPatterns: true, extractTokens: true, includeInvisible: false, cssUnit: 'px', ...config };
  }

  async executeAsync(context: StepExecutionContext): Promise<StepExecutionResult> {
    try {
      const input = context.input;
      const format = this.detectFormat(input);
      const components = format === InputFormat.FigmaApi ? this.parseFigmaApiNodes(input)
        : format === InputFormat.PluginElement ? this.parsePluginElements(input) : this.parseRawNodes(input);

      const tree = this.buildComponentTree(components.map(c => ({ ...c })));
      const patterns = this.config.detectPatterns ? this.detectPatterns(components) : [];
      const tokens = this.config.extractTokens ? this.extractDesignTokens(components) : {};
      const screenMap = this.generateScreenMap(tree);

      return StepExecutionResult.ok(
        { components, tree, patterns, tokens, screenMap, metadata: { format, componentCount: components.length, patternCount: patterns.length, parsedAt: new Date().toISOString() } },
        { componentCount: components.length, format, patternCount: patterns.length }
      );
    } catch (err: any) { return StepExecutionResult.fail(err.message); }
  }

  detectFormat(input: any): InputFormat {
    if (input?.document?.children) return InputFormat.FigmaApi;
    if (Array.isArray(input) && input[0]?.sourceType && input[0]?.code) return InputFormat.PluginElement;
    return InputFormat.RawNodeArray;
  }

  // ── Figma REST API Parser ──
  parseFigmaApiNodes(root: any): Component[] {
    const components: Component[] = [];
    this.extractApiComponents(root.document ?? root, components, null, 0);
    return components;
  }

  private extractApiComponents(node: any, comps: Component[], parentId: string | null, depth: number): void {
    if (depth > this.config.maxDepth) return;
    if (Array.isArray(node)) { node.forEach(n => this.extractApiComponents(n, comps, parentId, depth)); return; }
    if (!node || typeof node !== 'object') return;
    if (!this.config.includeInvisible && node.visible === false) return;

    const id = node.id ?? crypto.randomUUID();
    const name = node.name ?? 'unknown';
    const type = node.type ?? 'FRAME';
    const css = this.extractCssFromApi(node);
    const comp: Component = { id, name, type, parentId, css, html: this.buildHtmlTag(type, name), depth, className: this.sanitize(name) };
    if (type === 'TEXT' && node.characters) comp.textContent = node.characters;
    if (node.constraints) comp.constraints = node.constraints;
    comps.push(comp);

    (node.children ?? []).forEach((child: any) => this.extractApiComponents(child, comps, id, depth + 1));
  }

  // ── FigmaCodeGenerator Plugin Parser ──
  parsePluginElements(elements: any): Component[] {
    const comps: Component[] = [];
    (Array.isArray(elements) ? elements : [elements]).forEach(el => this.mapElement(el, comps, null, 0));
    return comps;
  }

  private mapElement(el: any, comps: Component[], parentId: string | null, depth: number): void {
    if (depth > this.config.maxDepth || !el) return;
    const id = crypto.randomUUID();
    const css: CssMap = {};
    if (el.style) Object.entries(el.style).forEach(([k, v]) => { css[this.camelToKebab(k)] = String(v); });
    if (el.codeCss) Object.assign(css, this.parseCssRules(el.codeCss));

    const comp: Component = {
      id, name: el.name ?? 'element', type: el.sourceType ?? 'FRAME', parentId, css,
      html: el.code || this.buildHtmlTag(el.sourceType, el.name), depth,
      className: this.sanitize(el.name), pluginGenerated: true,
    };
    if (el.containingString) comp.textContent = el.containingString;
    comps.push(comp);
    (el.subElements ?? []).forEach((sub: any) => this.mapElement(sub, comps, id, depth + 1));
  }

  parseRawNodes(input: any): Component[] {
    const comps: Component[] = [];
    (Array.isArray(input) ? input : [input]).forEach(n => this.extractApiComponents(n, comps, null, 0));
    return comps;
  }

  // ── CSS Extraction ──
  private extractCssFromApi(node: any): CssMap {
    const css: CssMap = {};
    const u = this.config.cssUnit;
    if (node.layoutMode) { css.display = 'flex'; css['flex-direction'] = node.layoutMode === 'VERTICAL' ? 'column' : 'row'; }
    if (node.itemSpacing != null) css.gap = `${node.itemSpacing}${u}`;
    for (const p of ['paddingLeft', 'paddingRight', 'paddingTop', 'paddingBottom'])
      if (node[p] != null) css[this.camelToKebab(p)] = `${node[p]}${u}`;
    if (node.primaryAxisAlignItems) css['justify-content'] = this.convertAlign(node.primaryAxisAlignItems);
    if (node.counterAxisAlignItems) css['align-items'] = this.convertAlign(node.counterAxisAlignItems);
    const bb = node.absoluteBoundingBox;
    if (bb?.width) css.width = `${bb.width}${u}`;
    if (bb?.height) css.height = `${bb.height}${u}`;
    if (node.fills?.[0]?.color) css['background-color'] = this.colorToRgba(node.fills[0].color, node.fills[0].opacity);
    if (node.cornerRadius) css['border-radius'] = `${node.cornerRadius}${u}`;
    if (node.strokes?.[0]?.color) {
      const sw = node.strokeWeight ?? 1;
      css.border = `${sw}${u} solid ${this.colorToRgba(node.strokes[0].color)}`;
    }
    const effects = node.effects ?? [];
    const shadows = effects.filter((e: any) => e.type === 'DROP_SHADOW').map((e: any) => {
      const { x = 0, y = 0 } = e.offset ?? {};
      return `${x}${u} ${y}${u} ${e.radius ?? 0}${u} ${e.spread ?? 0}${u} ${this.colorToRgba(e.color)}`;
    });
    if (shadows.length) css['box-shadow'] = shadows.join(', ');
    const st = node.style ?? {};
    if (st.fontSize) css['font-size'] = `${st.fontSize}${u}`;
    if (st.fontWeight) css['font-weight'] = String(st.fontWeight);
    if (st.fontFamily) css['font-family'] = `'${st.fontFamily}'`;
    if (st.lineHeightPx) css['line-height'] = `${st.lineHeightPx}${u}`;
    if (st.textAlignHorizontal) css['text-align'] = st.textAlignHorizontal.toLowerCase();
    if (node.opacity != null && node.opacity < 1) css.opacity = node.opacity.toFixed(2);
    if (node.clipsContent) css.overflow = 'hidden';
    return css;
  }

  // ── Tree / Patterns / Tokens / ScreenMap ──
  buildComponentTree(flat: Component[]): Component[] {
    const lookup = new Map(flat.map(c => [c.id as string, c]));
    const roots: Component[] = [];
    for (const comp of flat) {
      const pid = comp.parentId as string | null;
      if (!pid || !lookup.has(pid)) { roots.push(comp); continue; }
      const parent = lookup.get(pid)!;
      if (!parent.children) parent.children = [];
      (parent.children as Component[]).push(comp);
    }
    return roots;
  }

  detectPatterns(components: Component[]): Component[] {
    const patterns: Component[] = [];
    const tree = this.buildComponentTree(components.map(c => ({ ...c })));
    this.detectPatternsRecursive(tree, patterns);
    return patterns;
  }

  private detectPatternsRecursive(nodes: Component[], patterns: Component[]): void {
    for (const node of nodes) {
      const children = node.children as Component[] | undefined;
      if (!children?.length) continue;
      if (children.length >= 3) {
        const types = children.map(c => c.type);
        if (new Set(types).size === 1)
          patterns.push({ pattern: 'list-repeater', parentId: node.id, parentName: node.name, itemCount: children.length, itemType: types[0] });
      }
      const formKw = ['input', 'field', 'label', 'button', 'submit', 'password'];
      const fc = children.filter(c => formKw.some(k => String(c.name ?? '').toLowerCase().includes(k))).length;
      if (fc >= 2) patterns.push({ pattern: 'form', parentId: node.id, parentName: node.name, fieldCount: fc });
      this.detectPatternsRecursive(children, patterns);
    }
  }

  extractDesignTokens(components: Component[]): Record<string, Record<string, number>> {
    const colors: Record<string, number> = {}, fontSizes: Record<string, number> = {}, spacings: Record<string, number> = {};
    for (const comp of components) {
      const css = comp.css as CssMap | undefined; if (!css) continue;
      this.tally(colors, css['background-color']); this.tally(colors, css.color);
      this.tally(fontSizes, css['font-size']);
      for (const k of ['gap', 'padding-left', 'padding-top']) this.tally(spacings, css[k]);
    }
    return { colors, fontSizes, spacings };
  }

  generateScreenMap(tree: Component[]): Component[] {
    return tree.map(r => ({
      screenName: r.name, screenId: r.id,
      componentCount: this.countComponents(r),
      topLevelChildren: ((r.children as Component[]) ?? []).map(c => ({ name: c.name, type: c.type }))
    }));
  }

  // ── Helpers ──
  private buildHtmlTag(type: string, name: string): string {
    const tag = type === 'TEXT' ? 'span' : type === 'VECTOR' ? 'svg' : 'div';
    return `<${tag} class="${this.sanitize(name)}">`;
  }
  private convertAlign(a: string): string { return ({ CENTER: 'center', MAX: 'flex-end', SPACE_BETWEEN: 'space-between' } as any)[a] ?? 'flex-start'; }
  private colorToRgba(c: any, opacity = 1): string {
    const [r, g, b, a] = [Math.round(c.r * 255), Math.round(c.g * 255), Math.round(c.b * 255), (c.a ?? 1) * opacity];
    return a >= 1 ? `rgb(${r}, ${g}, ${b})` : `rgba(${r}, ${g}, ${b}, ${a.toFixed(2)})`;
  }
  private sanitize(name: string): string { return (name ?? 'component').replace(/\s+/g, '-').toLowerCase().replace(/[^a-z0-9-]/g, ''); }
  private camelToKebab(s: string): string { return s.replace(/([a-z])([A-Z])/g, '$1-$2').toLowerCase(); }
  private parseCssRules(css: string): CssMap { const r: CssMap = {}; for (const m of css.matchAll(/([\w-]+)\s*:\s*([^;]+);?/g)) r[m[1].trim()] = m[2].trim(); return r; }
  private tally(d: Record<string, number>, v?: string): void { if (v) d[v] = (d[v] ?? 0) + 1; }
  private countComponents(n: Component): number { return 1 + ((n.children as Component[]) ?? []).reduce((s, c) => s + this.countComponents(c), 0); }
}
