// XIIGen Skill 10: Figma Parser | Java 21
// Parses Figma API JSON + FigmaCodeGenerator Elements -> structured components
// Output: dynamic Maps (Genie DNA-1), no fixed model classes
package com.xiigen.figma;

import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.node.*;
import java.util.*;
import java.util.stream.*;
import java.util.regex.*;

public class FigmaParser implements IStepExecutor {
    @Override public String getNodeTypeName() { return "FigmaParser"; }

    private final ObjectMapper mapper = new ObjectMapper();
    private int maxDepth = 20;
    private boolean detectPatternsEnabled = true;
    private boolean extractTokensEnabled = true;
    private boolean includeInvisible = false;
    private String cssUnit = "px";

    public FigmaParser() {}
    public FigmaParser(int maxDepth, boolean detectPatterns, boolean extractTokens) {
        this.maxDepth = maxDepth; this.detectPatternsEnabled = detectPatterns; this.extractTokensEnabled = extractTokens;
    }

    public enum InputFormat { FigmaApi, PluginElement, RawNodeArray }

    @Override
    public StepExecutionResult executeAsync(StepExecutionContext context) {
        try {
            JsonNode input = mapper.valueToTree(context.getInput());
            InputFormat format = detectFormat(input);
            List<Map<String, Object>> components = switch (format) {
                case FigmaApi -> parseFigmaApiNodes(input);
                case PluginElement -> parsePluginElements(input);
                case RawNodeArray -> parseRawNodes(input);
            };
            List<Map<String, Object>> tree = buildComponentTree(deepCopy(components));
            List<Map<String, Object>> patterns = detectPatternsEnabled ? detectPatterns(components) : List.of();
            Map<String, Object> tokens = extractTokensEnabled ? extractDesignTokens(components) : Map.of();
            List<Map<String, Object>> screenMap = generateScreenMap(tree);

            Map<String, Object> output = new LinkedHashMap<>();
            output.put("components", components); output.put("tree", tree);
            output.put("patterns", patterns); output.put("tokens", tokens); output.put("screenMap", screenMap);
            output.put("metadata", Map.of("format", format.name(), "componentCount", components.size()));
            return StepExecutionResult.ok(output, Map.of("componentCount", components.size(), "format", format.name()));
        } catch (Exception e) { return StepExecutionResult.fail(e.getMessage()); }
    }

    public InputFormat detectFormat(JsonNode input) {
        if (input.isObject() && input.has("document")) return InputFormat.FigmaApi;
        if (input.isArray() && input.size() > 0 && input.get(0).has("sourceType") && input.get(0).has("code")) return InputFormat.PluginElement;
        return InputFormat.RawNodeArray;
    }

    public List<Map<String, Object>> parseFigmaApiNodes(JsonNode root) {
        List<Map<String, Object>> comps = new ArrayList<>();
        extractApiComponents(root.has("document") ? root.get("document") : root, comps, null, 0);
        return comps;
    }

    private void extractApiComponents(JsonNode node, List<Map<String, Object>> comps, String parentId, int depth) {
        if (depth > maxDepth) return;
        if (node.isArray()) { node.forEach(n -> extractApiComponents(n, comps, parentId, depth)); return; }
        if (!node.isObject()) return;
        if (!includeInvisible && node.has("visible") && !node.get("visible").asBoolean()) return;

        String id = node.has("id") ? node.get("id").asText() : UUID.randomUUID().toString();
        String name = node.has("name") ? node.get("name").asText() : "unknown";
        String type = node.has("type") ? node.get("type").asText() : "FRAME";
        Map<String, String> css = extractCssFromApi(node);

        Map<String, Object> comp = new LinkedHashMap<>();
        comp.put("id", id); comp.put("name", name); comp.put("type", type);
        comp.put("parentId", parentId); comp.put("css", css);
        comp.put("html", buildHtmlTag(type, name)); comp.put("depth", depth);
        comp.put("className", sanitize(name));
        if ("TEXT".equals(type) && node.has("characters")) comp.put("textContent", node.get("characters").asText());
        comps.add(comp);

        if (node.has("children")) node.get("children").forEach(child -> extractApiComponents(child, comps, id, depth + 1));
    }

    public List<Map<String, Object>> parsePluginElements(JsonNode elements) {
        List<Map<String, Object>> comps = new ArrayList<>();
        if (elements.isArray()) elements.forEach(el -> mapElement(el, comps, null, 0));
        else mapElement(elements, comps, null, 0);
        return comps;
    }

    private void mapElement(JsonNode el, List<Map<String, Object>> comps, String parentId, int depth) {
        if (depth > maxDepth || !el.isObject()) return;
        String id = UUID.randomUUID().toString();
        Map<String, String> css = new LinkedHashMap<>();
        if (el.has("style") && el.get("style").isObject())
            el.get("style").fields().forEachRemaining(f -> css.put(camelToKebab(f.getKey()), f.getValue().asText()));
        if (el.has("codeCss")) css.putAll(parseCssRules(el.get("codeCss").asText()));

        Map<String, Object> comp = new LinkedHashMap<>();
        comp.put("id", id); comp.put("name", el.has("name") ? el.get("name").asText() : "element");
        comp.put("type", el.has("sourceType") ? el.get("sourceType").asText() : "FRAME");
        comp.put("parentId", parentId); comp.put("css", css);
        comp.put("html", el.has("code") ? el.get("code").asText() : buildHtmlTag((String)comp.get("type"), (String)comp.get("name")));
        comp.put("depth", depth); comp.put("className", sanitize((String)comp.get("name"))); comp.put("pluginGenerated", true);
        if (el.has("containingString") && !el.get("containingString").isNull()) comp.put("textContent", el.get("containingString").asText());
        comps.add(comp);
        if (el.has("subElements") && el.get("subElements").isArray()) el.get("subElements").forEach(sub -> mapElement(sub, comps, id, depth + 1));
    }

    public List<Map<String, Object>> parseRawNodes(JsonNode input) {
        List<Map<String, Object>> comps = new ArrayList<>();
        if (input.isArray()) input.forEach(n -> extractApiComponents(n, comps, null, 0));
        else extractApiComponents(input, comps, null, 0);
        return comps;
    }

    private Map<String, String> extractCssFromApi(JsonNode node) {
        Map<String, String> css = new LinkedHashMap<>();
        if (node.has("layoutMode")) { css.put("display", "flex"); css.put("flex-direction", "VERTICAL".equals(node.get("layoutMode").asText()) ? "column" : "row"); }
        if (node.has("itemSpacing")) css.put("gap", node.get("itemSpacing").asDouble() + cssUnit);
        for (String p : List.of("paddingLeft", "paddingRight", "paddingTop", "paddingBottom"))
            if (node.has(p)) css.put(camelToKebab(p), node.get(p).asDouble() + cssUnit);
        if (node.has("absoluteBoundingBox")) {
            JsonNode bb = node.get("absoluteBoundingBox");
            if (bb.has("width")) css.put("width", bb.get("width").asDouble() + cssUnit);
            if (bb.has("height")) css.put("height", bb.get("height").asDouble() + cssUnit);
        }
        if (node.has("fills") && node.get("fills").size() > 0 && node.get("fills").get(0).has("color"))
            css.put("background-color", colorToRgba(node.get("fills").get(0).get("color"), 1));
        if (node.has("cornerRadius")) css.put("border-radius", node.get("cornerRadius").asDouble() + cssUnit);
        if (node.has("style")) {
            JsonNode st = node.get("style");
            if (st.has("fontSize")) css.put("font-size", st.get("fontSize").asDouble() + cssUnit);
            if (st.has("fontWeight")) css.put("font-weight", String.valueOf(st.get("fontWeight").asInt()));
            if (st.has("fontFamily")) css.put("font-family", "'" + st.get("fontFamily").asText() + "'");
        }
        return css;
    }

    @SuppressWarnings("unchecked")
    public List<Map<String, Object>> buildComponentTree(List<Map<String, Object>> flat) {
        Map<String, Map<String, Object>> lookup = flat.stream().collect(Collectors.toMap(c -> (String)c.get("id"), c -> c, (a,b)->a));
        List<Map<String, Object>> roots = new ArrayList<>();
        for (var comp : flat) {
            String pid = (String) comp.get("parentId");
            if (pid == null || !lookup.containsKey(pid)) { roots.add(comp); continue; }
            lookup.get(pid).computeIfAbsent("children", k -> new ArrayList<>());
            ((List<Map<String, Object>>) lookup.get(pid).get("children")).add(comp);
        }
        return roots;
    }

    @SuppressWarnings("unchecked")
    public List<Map<String, Object>> detectPatterns(List<Map<String, Object>> components) {
        List<Map<String, Object>> patterns = new ArrayList<>();
        var tree = buildComponentTree(deepCopy(components));
        detectPatternsRec(tree, patterns);
        return patterns;
    }

    @SuppressWarnings("unchecked")
    private void detectPatternsRec(List<Map<String, Object>> nodes, List<Map<String, Object>> patterns) {
        for (var n : nodes) {
            var ch = (List<Map<String, Object>>) n.getOrDefault("children", List.of());
            if (ch.isEmpty()) continue;
            if (ch.size() >= 3) {
                var types = ch.stream().map(c -> (String) c.getOrDefault("type", "")).collect(Collectors.toSet());
                if (types.size() == 1) patterns.add(Map.of("pattern", "list-repeater", "parentId", n.get("id"), "parentName", n.getOrDefault("name", ""), "itemCount", ch.size()));
            }
            detectPatternsRec(ch, patterns);
        }
    }

    public Map<String, Object> extractDesignTokens(List<Map<String, Object>> components) {
        Map<String, Integer> colors = new LinkedHashMap<>(), fonts = new LinkedHashMap<>(), spacings = new LinkedHashMap<>();
        for (var c : components) {
            @SuppressWarnings("unchecked") var css = (Map<String, String>) c.getOrDefault("css", Map.of());
            tally(colors, css.get("background-color")); tally(fonts, css.get("font-size")); tally(spacings, css.get("gap"));
        }
        return Map.of("colors", colors, "fontSizes", fonts, "spacings", spacings);
    }

    public List<Map<String, Object>> generateScreenMap(List<Map<String, Object>> tree) {
        return tree.stream().map(r -> Map.<String, Object>of("screenName", r.getOrDefault("name", ""), "screenId", r.getOrDefault("id", ""), "componentCount", countComponents(r))).toList();
    }

    private String buildHtmlTag(String type, String name) { String tag = "TEXT".equals(type) ? "span" : "VECTOR".equals(type) ? "svg" : "div"; return "<" + tag + " class=\"" + sanitize(name) + "\">"; }
    private String colorToRgba(JsonNode c, double op) { int r=(int)(c.get("r").asDouble()*255), g=(int)(c.get("g").asDouble()*255), b=(int)(c.get("b").asDouble()*255); double a=(c.has("a")?c.get("a").asDouble():1)*op; return a>=1?"rgb(%d,%d,%d)".formatted(r,g,b):"rgba(%d,%d,%d,%.2f)".formatted(r,g,b,a); }
    private String sanitize(String n) { return (n!=null?n:"component").replace(" ","-").toLowerCase().replaceAll("[^a-z0-9-]",""); }
    private String camelToKebab(String s) { return s.replaceAll("([a-z])([A-Z])","$1-$2").toLowerCase(); }
    private Map<String, String> parseCssRules(String css) { Map<String,String> r=new LinkedHashMap<>(); var m=Pattern.compile("([\\w-]+)\\s*:\\s*([^;]+);?").matcher(css); while(m.find()) r.put(m.group(1).trim(),m.group(2).trim()); return r; }
    private void tally(Map<String,Integer> d, String v) { if(v!=null&&!v.isEmpty()) d.merge(v,1,Integer::sum); }
    @SuppressWarnings("unchecked") private int countComponents(Map<String,Object> n) { return 1+((List<Map<String,Object>>)n.getOrDefault("children",List.of())).stream().mapToInt(this::countComponents).sum(); }
    private List<Map<String,Object>> deepCopy(List<Map<String,Object>> l) { return l.stream().map(LinkedHashMap::new).collect(Collectors.toList()); }
}
