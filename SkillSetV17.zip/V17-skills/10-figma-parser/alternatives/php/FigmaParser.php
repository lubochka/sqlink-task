<?php
// XIIGen Skill 10: Figma Parser | PHP 8.3
// Parses Figma API JSON + FigmaCodeGenerator Elements -> structured components
// Dynamic arrays (Genie DNA-1) -- no fixed model classes
declare(strict_types=1);
namespace XIIGen\Figma;

class FigmaParserConfig {
    public function __construct(
        public readonly int $maxDepth = 20, public readonly bool $detectPatterns = true,
        public readonly bool $extractTokens = true, public readonly bool $includeInvisible = false,
        public readonly string $cssUnit = 'px',
    ) {}
}

class FigmaParser {
    public string $nodeTypeName = 'FigmaParser';
    private FigmaParserConfig $config;

    public function __construct(?FigmaParserConfig $config = null) { $this->config = $config ?? new FigmaParserConfig(); }

    public function executeAsync(array $context): array {
        try {
            $input = $context['input'] ?? [];
            $format = $this->detectFormat($input);
            $components = match ($format) {
                'FigmaApi' => $this->parseFigmaApiNodes($input),
                'PluginElement' => $this->parsePluginElements($input),
                default => $this->parseRawNodes($input),
            };
            $tree = $this->buildComponentTree(array_map(fn($c) => [...$c], $components));
            $patterns = $this->config->detectPatterns ? $this->detectPatterns($components) : [];
            $tokens = $this->config->extractTokens ? $this->extractDesignTokens($components) : [];
            $screenMap = $this->generateScreenMap($tree);
            return ['success' => true, 'output' => ['components' => $components, 'tree' => $tree, 'patterns' => $patterns,
                'tokens' => $tokens, 'screenMap' => $screenMap, 'metadata' => ['format' => $format, 'componentCount' => count($components)]]];
        } catch (\Throwable $e) { return ['success' => false, 'error' => $e->getMessage()]; }
    }

    public function detectFormat(mixed $input): string {
        if (is_array($input) && isset($input['document'])) return 'FigmaApi';
        if (is_array($input) && isset($input[0]['sourceType'], $input[0]['code'])) return 'PluginElement';
        return 'RawNodeArray';
    }

    public function parseFigmaApiNodes(array $root): array {
        $comps = []; $this->extractApi($root['document'] ?? $root, $comps, null, 0); return $comps;
    }

    private function extractApi(mixed $node, array &$comps, ?string $parentId, int $depth): void {
        if ($depth > $this->config->maxDepth) return;
        if (is_array($node) && array_is_list($node)) { foreach ($node as $n) $this->extractApi($n, $comps, $parentId, $depth); return; }
        if (!is_array($node)) return;
        if (!$this->config->includeInvisible && isset($node['visible']) && !$node['visible']) return;
        $id = $node['id'] ?? bin2hex(random_bytes(8));
        $name = $node['name'] ?? 'unknown'; $type = $node['type'] ?? 'FRAME';
        $css = $this->extractCssApi($node);
        $comp = ['id' => $id, 'name' => $name, 'type' => $type, 'parentId' => $parentId, 'css' => $css,
                 'html' => $this->buildTag($type, $name), 'depth' => $depth, 'className' => $this->sanitize($name)];
        if ($type === 'TEXT' && isset($node['characters'])) $comp['textContent'] = $node['characters'];
        $comps[] = $comp;
        foreach ($node['children'] ?? [] as $child) $this->extractApi($child, $comps, $id, $depth + 1);
    }

    public function parsePluginElements(array $elements): array {
        $comps = [];
        foreach (isset($elements[0]) ? $elements : [$elements] as $el) $this->mapElement($el, $comps, null, 0);
        return $comps;
    }

    private function mapElement(array $el, array &$comps, ?string $parentId, int $depth): void {
        if ($depth > $this->config->maxDepth) return;
        $id = bin2hex(random_bytes(8)); $css = [];
        if (isset($el['style']) && is_array($el['style']))
            foreach ($el['style'] as $k => $v) $css[$this->camelToKebab($k)] = (string)$v;
        if (!empty($el['codeCss'])) $css = array_merge($css, $this->parseCssRules($el['codeCss']));
        $name = $el['name'] ?? 'element'; $type = $el['sourceType'] ?? 'FRAME';
        $comp = ['id' => $id, 'name' => $name, 'type' => $type, 'parentId' => $parentId, 'css' => $css,
                 'html' => !empty($el['code']) ? $el['code'] : $this->buildTag($type, $name),
                 'depth' => $depth, 'className' => $this->sanitize($name), 'pluginGenerated' => true];
        if (!empty($el['containingString'])) $comp['textContent'] = $el['containingString'];
        $comps[] = $comp;
        foreach ($el['subElements'] ?? [] as $sub) $this->mapElement($sub, $comps, $id, $depth + 1);
    }

    public function parseRawNodes(mixed $input): array {
        $comps = [];
        foreach (is_array($input) && isset($input[0]) ? $input : [$input] as $n) $this->extractApi($n, $comps, null, 0);
        return $comps;
    }

    private function extractCssApi(array $node): array {
        $css = []; $u = $this->config->cssUnit;
        if (isset($node['layoutMode'])) { $css['display'] = 'flex'; $css['flex-direction'] = $node['layoutMode'] === 'VERTICAL' ? 'column' : 'row'; }
        if (isset($node['itemSpacing'])) $css['gap'] = $node['itemSpacing'] . $u;
        foreach (['paddingLeft','paddingRight','paddingTop','paddingBottom'] as $p) if (isset($node[$p])) $css[$this->camelToKebab($p)] = $node[$p] . $u;
        $bb = $node['absoluteBoundingBox'] ?? [];
        if (isset($bb['width'])) $css['width'] = $bb['width'] . $u;
        if (isset($bb['height'])) $css['height'] = $bb['height'] . $u;
        if (!empty($node['fills'][0]['color'])) $css['background-color'] = $this->colorToRgba($node['fills'][0]['color'], $node['fills'][0]['opacity'] ?? 1);
        if (isset($node['cornerRadius'])) $css['border-radius'] = $node['cornerRadius'] . $u;
        if (!empty($node['strokes'][0]['color'])) { $sw = $node['strokeWeight'] ?? 1; $css['border'] = $sw . $u . ' solid ' . $this->colorToRgba($node['strokes'][0]['color']); }
        $st = $node['style'] ?? [];
        if (isset($st['fontSize'])) $css['font-size'] = $st['fontSize'] . $u;
        if (isset($st['fontWeight'])) $css['font-weight'] = (string)$st['fontWeight'];
        if (isset($st['fontFamily'])) $css['font-family'] = "'{$st['fontFamily']}'";
        if (isset($st['lineHeightPx'])) $css['line-height'] = $st['lineHeightPx'] . $u;
        if (isset($st['textAlignHorizontal'])) $css['text-align'] = strtolower($st['textAlignHorizontal']);
        if (isset($node['opacity']) && $node['opacity'] < 1) $css['opacity'] = number_format($node['opacity'], 2);
        if (!empty($node['clipsContent'])) $css['overflow'] = 'hidden';
        return $css;
    }

    public function buildComponentTree(array $flat): array {
        $lookup = []; foreach ($flat as &$c) $lookup[$c['id']] = &$c; unset($c);
        $roots = [];
        foreach ($flat as &$comp) {
            $pid = $comp['parentId'] ?? null;
            if (!$pid || !isset($lookup[$pid])) { $roots[] = &$comp; continue; }
            $lookup[$pid]['children'][] = &$comp;
        }
        return $roots;
    }

    public function detectPatterns(array $comps): array {
        $patterns = []; $tree = $this->buildComponentTree(array_map(fn($c) => [...$c], $comps));
        $this->detectRec($tree, $patterns); return $patterns;
    }

    private function detectRec(array $nodes, array &$patterns): void {
        foreach ($nodes as $n) {
            $ch = $n['children'] ?? []; if (empty($ch)) continue;
            if (count($ch) >= 3) { $types = array_map(fn($c) => $c['type'] ?? '', $ch);
                if (count(array_unique($types)) === 1) $patterns[] = ['pattern' => 'list-repeater', 'parentId' => $n['id'], 'parentName' => $n['name'] ?? '', 'itemCount' => count($ch)]; }
            $formKw = ['input','field','label','button','submit','password'];
            $fc = count(array_filter($ch, fn($c) => count(array_filter($formKw, fn($k) => str_contains(strtolower($c['name'] ?? ''), $k))) > 0));
            if ($fc >= 2) $patterns[] = ['pattern' => 'form', 'parentId' => $n['id'], 'fieldCount' => $fc];
            $this->detectRec($ch, $patterns);
        }
    }

    public function extractDesignTokens(array $comps): array {
        $colors = []; $fonts = []; $spacings = [];
        foreach ($comps as $c) { $css = $c['css'] ?? [];
            foreach (['background-color','color'] as $k) if (!empty($css[$k])) $colors[$css[$k]] = ($colors[$css[$k]] ?? 0) + 1;
            if (!empty($css['font-size'])) $fonts[$css['font-size']] = ($fonts[$css['font-size']] ?? 0) + 1;
            foreach (['gap','padding-left','padding-top'] as $k) if (!empty($css[$k])) $spacings[$css[$k]] = ($spacings[$css[$k]] ?? 0) + 1;
        }
        return ['colors' => $colors, 'fontSizes' => $fonts, 'spacings' => $spacings];
    }

    public function generateScreenMap(array $tree): array {
        return array_map(fn($r) => ['screenName' => $r['name'] ?? '', 'screenId' => $r['id'] ?? '', 'componentCount' => $this->countComps($r),
            'topLevelChildren' => array_map(fn($c) => ['name' => $c['name'] ?? '', 'type' => $c['type'] ?? ''], $r['children'] ?? [])], $tree);
    }

    private function buildTag(string $type, string $name): string { $tag = match($type) { 'TEXT' => 'span', 'VECTOR' => 'svg', default => 'div' }; return "<{$tag} class=\"{$this->sanitize($name)}\">"; }
    private function colorToRgba(array $c, float $op = 1): string { $r=(int)($c['r']*255); $g=(int)($c['g']*255); $b=(int)($c['b']*255); $a=($c['a']??1)*$op; return $a>=1?"rgb($r,$g,$b)":sprintf("rgba(%d,%d,%d,%.2f)",$r,$g,$b,$a); }
    private function sanitize(string $name): string { return preg_replace('/[^a-z0-9-]/', '', strtolower(str_replace(' ', '-', $name))); }
    private function camelToKebab(string $s): string { return strtolower(preg_replace('/([a-z])([A-Z])/', '$1-$2', $s)); }
    private function parseCssRules(string $css): array { preg_match_all('/([\w-]+)\s*:\s*([^;]+);?/', $css, $m, PREG_SET_ORDER); $r=[]; foreach ($m as $match) $r[trim($match[1])]=trim($match[2]); return $r; }
    private function countComps(array $n): int { return 1 + array_sum(array_map(fn($c) => $this->countComps($c), $n['children'] ?? [])); }
}
