"""XIIGen Skill 10: Figma Parser | Python
Parses Figma API JSON + FigmaCodeGenerator Elements -> structured components.
All output as dynamic dicts (Genie DNA-1). No fixed model classes.
"""
from __future__ import annotations
import re, uuid
from dataclasses import dataclass

@dataclass
class FigmaParserConfig:
    max_depth: int = 20
    detect_patterns: bool = True
    extract_tokens: bool = True
    include_invisible: bool = False
    css_unit: str = "px"

class FigmaParser:
    """IStepExecutor: Parses Figma nodes into structured component fragments."""
    node_type_name = "FigmaParser"

    def __init__(self, object_processor=None, config: FigmaParserConfig | None = None):
        self.op = object_processor
        self.config = config or FigmaParserConfig()

    async def execute_async(self, context: dict) -> dict:
        try:
            inp = context.get("input", {})
            fmt = self.detect_format(inp)
            parse_fn = {"FigmaApi": self.parse_figma_api_nodes, "PluginElement": self.parse_plugin_elements, "RawNodeArray": self.parse_raw_nodes}
            components = parse_fn[fmt](inp)
            tree = self.build_component_tree([dict(c) for c in components])
            patterns = self.detect_patterns(components) if self.config.detect_patterns else []
            tokens = self.extract_design_tokens(components) if self.config.extract_tokens else {}
            screen_map = self.generate_screen_map(tree)
            return {"success": True, "output": {"components": components, "tree": tree, "patterns": patterns, "tokens": tokens, "screenMap": screen_map,
                "metadata": {"format": fmt, "componentCount": len(components), "patternCount": len(patterns)}},
                "debug": {"componentCount": len(components), "format": fmt}}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def detect_format(self, inp) -> str:
        if isinstance(inp, dict) and "document" in inp: return "FigmaApi"
        if isinstance(inp, list) and inp and isinstance(inp[0], dict) and "sourceType" in inp[0]: return "PluginElement"
        return "RawNodeArray"

    def parse_figma_api_nodes(self, root: dict) -> list[dict]:
        comps = []
        self._extract_api(root.get("document", root), comps, None, 0)
        return comps

    def _extract_api(self, node, comps, parent_id, depth):
        if depth > self.config.max_depth: return
        if isinstance(node, list):
            for n in node: self._extract_api(n, comps, parent_id, depth)
            return
        if not isinstance(node, dict): return
        if not self.config.include_invisible and node.get("visible") is False: return
        nid = node.get("id", uuid.uuid4().hex)
        name, ntype = node.get("name", "unknown"), node.get("type", "FRAME")
        css = self._extract_css_api(node)
        comp = {"id": nid, "name": name, "type": ntype, "parentId": parent_id, "css": css,
                "html": self._build_tag(ntype, name), "depth": depth, "className": self._sanitize(name)}
        if ntype == "TEXT" and "characters" in node: comp["textContent"] = node["characters"]
        if "constraints" in node: comp["constraints"] = node["constraints"]
        comps.append(comp)
        for child in node.get("children", []):
            self._extract_api(child, comps, nid, depth + 1)

    def parse_plugin_elements(self, elements) -> list[dict]:
        comps = []
        for el in (elements if isinstance(elements, list) else [elements]):
            self._map_element(el, comps, None, 0)
        return comps

    def _map_element(self, el, comps, parent_id, depth):
        if depth > self.config.max_depth or not isinstance(el, dict): return
        nid = uuid.uuid4().hex
        css = {}
        if isinstance(el.get("style"), dict):
            css = {self._camel_to_kebab(k): str(v) for k, v in el["style"].items()}
        if el.get("codeCss"): css.update(self._parse_css_rules(el["codeCss"]))
        name, ntype = el.get("name", "element"), el.get("sourceType", "FRAME")
        comp = {"id": nid, "name": name, "type": ntype, "parentId": parent_id, "css": css,
                "html": el.get("code") or self._build_tag(ntype, name), "depth": depth,
                "className": self._sanitize(name), "pluginGenerated": True}
        if el.get("containingString"): comp["textContent"] = el["containingString"]
        comps.append(comp)
        for sub in el.get("subElements", []):
            self._map_element(sub, comps, nid, depth + 1)

    def parse_raw_nodes(self, inp) -> list[dict]:
        comps = []
        for n in (inp if isinstance(inp, list) else [inp]):
            self._extract_api(n, comps, None, 0)
        return comps

    def _extract_css_api(self, node: dict) -> dict:
        css, u = {}, self.config.css_unit
        if "layoutMode" in node: css["display"] = "flex"; css["flex-direction"] = "column" if node["layoutMode"] == "VERTICAL" else "row"
        if "itemSpacing" in node: css["gap"] = f"{node['itemSpacing']}{u}"
        for p in ["paddingLeft", "paddingRight", "paddingTop", "paddingBottom"]:
            if p in node: css[self._camel_to_kebab(p)] = f"{node[p]}{u}"
        am = {"CENTER": "center", "MAX": "flex-end", "SPACE_BETWEEN": "space-between"}
        if "primaryAxisAlignItems" in node: css["justify-content"] = am.get(node["primaryAxisAlignItems"], "flex-start")
        if "counterAxisAlignItems" in node: css["align-items"] = am.get(node["counterAxisAlignItems"], "flex-start")
        bb = node.get("absoluteBoundingBox", {})
        if "width" in bb: css["width"] = f"{bb['width']}{u}"
        if "height" in bb: css["height"] = f"{bb['height']}{u}"
        fills = node.get("fills", [])
        if fills and "color" in fills[0]: css["background-color"] = self._color_rgba(fills[0]["color"], fills[0].get("opacity", 1))
        if "cornerRadius" in node: css["border-radius"] = f"{node['cornerRadius']}{u}"
        strokes = node.get("strokes", [])
        if strokes and "color" in strokes[0]:
            sw = node.get("strokeWeight", 1)
            css["border"] = f"{sw}{u} solid {self._color_rgba(strokes[0]['color'])}"
        shadows = []
        for eff in node.get("effects", []):
            if eff.get("type") == "DROP_SHADOW" and "color" in eff:
                off = eff.get("offset", {})
                shadows.append(f"{off.get('x',0)}{u} {off.get('y',0)}{u} {eff.get('radius',0)}{u} {eff.get('spread',0)}{u} {self._color_rgba(eff['color'])}")
        if shadows: css["box-shadow"] = ", ".join(shadows)
        st = node.get("style", {})
        if "fontSize" in st: css["font-size"] = f"{st['fontSize']}{u}"
        if "fontWeight" in st: css["font-weight"] = str(st["fontWeight"])
        if "fontFamily" in st: css["font-family"] = f"\'{st['fontFamily']}\'"
        if "lineHeightPx" in st: css["line-height"] = f"{st['lineHeightPx']}{u}"
        if "textAlignHorizontal" in st: css["text-align"] = st["textAlignHorizontal"].lower()
        if node.get("opacity", 1) < 1: css["opacity"] = f"{node['opacity']:.2f}"
        if node.get("clipsContent"): css["overflow"] = "hidden"
        return css

    def build_component_tree(self, flat: list[dict]) -> list[dict]:
        lookup = {c["id"]: c for c in flat}
        roots = []
        for c in flat:
            pid = c.get("parentId")
            if not pid or pid not in lookup: roots.append(c); continue
            lookup[pid].setdefault("children", []).append(c)
        return roots

    def detect_patterns(self, components: list[dict]) -> list[dict]:
        patterns = []
        tree = self.build_component_tree([dict(c) for c in components])
        self._detect_rec(tree, patterns)
        return patterns

    def _detect_rec(self, nodes, patterns):
        for n in nodes:
            ch = n.get("children", [])
            if not ch: continue
            if len(ch) >= 3:
                types = [c.get("type", "") for c in ch]
                if len(set(types)) == 1:
                    patterns.append({"pattern": "list-repeater", "parentId": n["id"], "parentName": n.get("name"), "itemCount": len(ch), "itemType": types[0]})
            form_kw = {"input", "field", "label", "button", "submit", "password"}
            fc = sum(1 for c in ch if any(k in str(c.get("name", "")).lower() for k in form_kw))
            if fc >= 2: patterns.append({"pattern": "form", "parentId": n["id"], "parentName": n.get("name"), "fieldCount": fc})
            self._detect_rec(ch, patterns)

    def extract_design_tokens(self, components: list[dict]) -> dict:
        colors, fonts, spacings = {}, {}, {}
        for c in components:
            css = c.get("css", {})
            for k in ["background-color", "color"]: self._tally(colors, css.get(k))
            self._tally(fonts, css.get("font-size"))
            for k in ["gap", "padding-left", "padding-top"]: self._tally(spacings, css.get(k))
        return {"colors": colors, "fontSizes": fonts, "spacings": spacings}

    def generate_screen_map(self, tree: list[dict]) -> list[dict]:
        return [{"screenName": r.get("name"), "screenId": r.get("id"), "componentCount": self._count(r),
                 "topLevelChildren": [{"name": c.get("name"), "type": c.get("type")} for c in r.get("children", [])]} for r in tree]

    def _build_tag(self, ntype, name):
        tag = {"TEXT": "span", "VECTOR": "svg"}.get(ntype, "div")
        return f'<{tag} class="{self._sanitize(name)}">'
    def _color_rgba(self, c, opacity=1):
        r, g, b, a = int(c["r"]*255), int(c["g"]*255), int(c["b"]*255), c.get("a", 1) * opacity
        return f"rgb({r}, {g}, {b})" if a >= 1 else f"rgba({r}, {g}, {b}, {a:.2f})"
    def _sanitize(self, name): return re.sub(r"[^a-z0-9-]", "", (name or "component").replace(" ", "-").lower())
    def _camel_to_kebab(self, s): return re.sub(r"([a-z])([A-Z])", r"\1-\2", s).lower()
    def _parse_css_rules(self, css_text): return {m.group(1).strip(): m.group(2).strip() for m in re.finditer(r"([\w-]+)\s*:\s*([^;]+);?", css_text)}
    def _tally(self, d, v):
        if v: d[v] = d.get(v, 0) + 1
    def _count(self, n): return 1 + sum(self._count(c) for c in n.get("children", []))
