// XIIGen.Figma/FigmaParser.cs - Skill 10 | .NET 9
// Enhanced: Multi-format detection, pattern recognition, design tokens, Genie DNA
using System.Collections.Concurrent;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Figma;

/// <summary>
/// Parses Figma API JSON or FigmaCodeGenerator Element trees into structured
/// component fragments. Implements IStepExecutor for flow engine integration.
/// All output is dynamic documents (Dictionary) — no fixed model classes.
/// </summary>
public class FigmaParser : IStepExecutor
{
    public string NodeTypeName => "FigmaParser";

    private readonly ILogger<FigmaParser> _logger;
    private readonly IObjectProcessor _objectProcessor;
    private readonly FigmaParserConfig _config;

    public FigmaParser(ILogger<FigmaParser> logger, IObjectProcessor objectProcessor, FigmaParserConfig config = null)
    {
        _logger = logger;
        _objectProcessor = objectProcessor;
        _config = config ?? new FigmaParserConfig();
    }

    // ── IStepExecutor ──────────────────────────────────────────────────
    public async Task<StepExecutionResult> ExecuteAsync(StepExecutionContext context, CancellationToken ct = default)
    {
        try
        {
            var input = context.Input;
            var json = input is JsonElement je ? je : JsonSerializer.SerializeToElement(input);

            // Detect input format and parse accordingly
            var format = DetectFormat(json);
            _logger.LogInformation("Detected Figma input format: {Format}", format);

            var components = format switch
            {
                InputFormat.FigmaApi => ParseFigmaApiNodes(json),
                InputFormat.PluginElement => ParsePluginElements(json),
                InputFormat.RawNodeArray => ParseRawNodes(json),
                _ => throw new ArgumentException($"Unknown Figma input format")
            };

            // Build enriched output
            var tree = BuildComponentTree(components);
            var patterns = _config.DetectPatterns ? DetectPatterns(components) : new List<Dictionary<string, object>>();
            var tokens = _config.ExtractTokens ? ExtractDesignTokens(components) : new Dictionary<string, object>();
            var screenMap = GenerateScreenMap(tree);

            // Store as dynamic document
            var output = _objectProcessor.ParseObjectAlternative(new
            {
                components,
                tree,
                patterns,
                tokens,
                screenMap,
                metadata = new
                {
                    format = format.ToString(),
                    componentCount = components.Count,
                    patternCount = patterns.Count,
                    screenCount = screenMap.Count,
                    parsedAt = DateTime.UtcNow.ToString("O")
                }
            });

            var debug = new Dictionary<string, object>
            {
                ["componentCount"] = components.Count,
                ["format"] = format.ToString(),
                ["patternCount"] = patterns.Count,
                ["tokenCategories"] = tokens.Keys.ToList()
            };

            return StepExecutionResult.Ok(output, debug);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "FigmaParser failed");
            return StepExecutionResult.Fail(ex.Message);
        }
    }

    // ── Format Detection ───────────────────────────────────────────────
    public enum InputFormat { FigmaApi, PluginElement, RawNodeArray }

    public InputFormat DetectFormat(JsonElement json)
    {
        // Figma API: has "document" with "children"
        if (json.ValueKind == JsonValueKind.Object && json.TryGetProperty("document", out _))
            return InputFormat.FigmaApi;

        // Plugin Element: array where items have "sourceType" + "code" + "subElements"
        if (json.ValueKind == JsonValueKind.Array && json.GetArrayLength() > 0)
        {
            var first = json[0];
            if (first.TryGetProperty("sourceType", out _) && first.TryGetProperty("code", out _))
                return InputFormat.PluginElement;
        }

        // Raw nodes: array or object with "type" like FRAME/TEXT/GROUP
        return InputFormat.RawNodeArray;
    }

    // ── Figma REST API Parser ──────────────────────────────────────────
    public List<Dictionary<string, object>> ParseFigmaApiNodes(JsonElement root)
    {
        var components = new List<Dictionary<string, object>>();
        var startNode = root.TryGetProperty("document", out var doc) ? doc : root;
        ExtractApiComponents(startNode, components, null, 0);
        return components;
    }

    private void ExtractApiComponents(JsonElement node, List<Dictionary<string, object>> components, string parentId, int depth)
    {
        if (depth > _config.MaxDepth) return;
        if (node.ValueKind == JsonValueKind.Array)
        {
            foreach (var item in node.EnumerateArray())
                ExtractApiComponents(item, components, parentId, depth);
            return;
        }
        if (node.ValueKind != JsonValueKind.Object) return;

        // Skip invisible nodes unless configured to include them
        if (!_config.IncludeInvisible && node.TryGetProperty("visible", out var vis) && !vis.GetBoolean())
            return;

        var id = node.TryGetProperty("id", out var idProp) ? idProp.GetString() : Guid.NewGuid().ToString("N");
        var name = node.TryGetProperty("name", out var nameProp) ? nameProp.GetString() : "unknown";
        var type = node.TryGetProperty("type", out var typeProp) ? typeProp.GetString() : "FRAME";

        var css = ExtractCssFromApi(node);
        var html = BuildHtmlTag(type, name);
        var textContent = (string)null;
        if (type == "TEXT" && node.TryGetProperty("characters", out var chars))
            textContent = chars.GetString();

        // Build as dynamic document — Genie DNA-1
        var component = new Dictionary<string, object>
        {
            ["id"] = id,
            ["name"] = name,
            ["type"] = type,
            ["parentId"] = parentId,
            ["css"] = css,
            ["html"] = html,
            ["depth"] = depth,
            ["className"] = SanitizeClassName(name)
        };
        if (textContent != null) component["textContent"] = textContent;

        // Extract constraints for responsive hints
        if (node.TryGetProperty("constraints", out var constraints))
            component["constraints"] = _objectProcessor.ParseObjectAlternative(constraints);

        // Extract component set info
        if (node.TryGetProperty("componentProperties", out var compProps))
            component["componentProperties"] = _objectProcessor.ParseObjectAlternative(compProps);

        components.Add(component);

        // Recurse into children
        if (node.TryGetProperty("children", out var children))
            foreach (var child in children.EnumerateArray())
                ExtractApiComponents(child, components, id, depth + 1);
    }

    // ── FigmaCodeGenerator Plugin Parser ───────────────────────────────
    public List<Dictionary<string, object>> ParsePluginElements(JsonElement elements)
    {
        var components = new List<Dictionary<string, object>>();
        if (elements.ValueKind == JsonValueKind.Array)
            foreach (var el in elements.EnumerateArray())
                MapElementToComponent(el, components, null, 0);
        else
            MapElementToComponent(elements, components, null, 0);
        return components;
    }

    private void MapElementToComponent(JsonElement el, List<Dictionary<string, object>> components, string parentId, int depth)
    {
        if (depth > _config.MaxDepth) return;
        if (el.ValueKind != JsonValueKind.Object) return;

        var id = Guid.NewGuid().ToString("N");
        var name = el.TryGetProperty("name", out var n) ? n.GetString() : "element";
        var sourceType = el.TryGetProperty("sourceType", out var st) ? st.GetString() : "FRAME";

        // Plugin already provides code + codeCss
        var code = el.TryGetProperty("code", out var c) ? c.GetString() : "";
        var codeCss = el.TryGetProperty("codeCss", out var cc) ? cc.GetString() : "";
        var containingString = el.TryGetProperty("containingString", out var cs) ? cs.GetString() : null;

        // Parse style object into CSS map
        var css = new Dictionary<string, string>();
        if (el.TryGetProperty("style", out var style) && style.ValueKind == JsonValueKind.Object)
            foreach (var prop in style.EnumerateObject())
                css[CamelToKebab(prop.Name)] = prop.Value.ToString();

        // Merge codeCss properties (plugin-generated CSS rules)
        if (!string.IsNullOrEmpty(codeCss))
            foreach (var rule in ParseCssRules(codeCss))
                css.TryAdd(rule.Key, rule.Value);

        var component = new Dictionary<string, object>
        {
            ["id"] = id,
            ["name"] = name,
            ["type"] = sourceType,
            ["parentId"] = parentId,
            ["css"] = css,
            ["html"] = string.IsNullOrEmpty(code) ? BuildHtmlTag(sourceType, name) : code,
            ["depth"] = depth,
            ["className"] = SanitizeClassName(name),
            ["pluginGenerated"] = true
        };
        if (containingString != null) component["textContent"] = containingString;
        components.Add(component);

        // Recurse into subElements
        if (el.TryGetProperty("subElements", out var subs) && subs.ValueKind == JsonValueKind.Array)
            foreach (var sub in subs.EnumerateArray())
                MapElementToComponent(sub, components, id, depth + 1);
    }

    // ── Raw Node Parser ────────────────────────────────────────────────
    public List<Dictionary<string, object>> ParseRawNodes(JsonElement json)
    {
        var components = new List<Dictionary<string, object>>();
        if (json.ValueKind == JsonValueKind.Array)
            foreach (var item in json.EnumerateArray())
                ExtractApiComponents(item, components, null, 0);
        else
            ExtractApiComponents(json, components, null, 0);
        return components;
    }

    // ── CSS Extraction (Figma API properties → CSS) ────────────────────
    private Dictionary<string, string> ExtractCssFromApi(JsonElement node)
    {
        var css = new Dictionary<string, string>();

        // Layout (auto-layout → flexbox)
        if (node.TryGetProperty("layoutMode", out var layout))
        {
            css["display"] = "flex";
            css["flex-direction"] = layout.GetString() == "VERTICAL" ? "column" : "row";
        }
        if (node.TryGetProperty("itemSpacing", out var spacing)) css["gap"] = FormatPx(spacing);
        if (node.TryGetProperty("paddingLeft", out var pl)) css["padding-left"] = FormatPx(pl);
        if (node.TryGetProperty("paddingRight", out var pr)) css["padding-right"] = FormatPx(pr);
        if (node.TryGetProperty("paddingTop", out var pt)) css["padding-top"] = FormatPx(pt);
        if (node.TryGetProperty("paddingBottom", out var pb)) css["padding-bottom"] = FormatPx(pb);
        if (node.TryGetProperty("primaryAxisAlignItems", out var mainAlign))
            css["justify-content"] = ConvertAlign(mainAlign.GetString());
        if (node.TryGetProperty("counterAxisAlignItems", out var crossAlign))
            css["align-items"] = ConvertAlign(crossAlign.GetString());
        if (node.TryGetProperty("layoutWrap", out var wrap) && wrap.GetString() == "WRAP")
            css["flex-wrap"] = "wrap";

        // Sizing
        if (node.TryGetProperty("absoluteBoundingBox", out var bounds))
        {
            if (bounds.TryGetProperty("width", out var w)) css["width"] = FormatPx(w);
            if (bounds.TryGetProperty("height", out var h)) css["height"] = FormatPx(h);
        }
        // Size constraints (min/max)
        if (node.TryGetProperty("minWidth", out var minW)) css["min-width"] = FormatPx(minW);
        if (node.TryGetProperty("maxWidth", out var maxW)) css["max-width"] = FormatPx(maxW);
        if (node.TryGetProperty("minHeight", out var minH)) css["min-height"] = FormatPx(minH);
        if (node.TryGetProperty("maxHeight", out var maxH)) css["max-height"] = FormatPx(maxH);

        // Background fills
        if (node.TryGetProperty("fills", out var fills) && fills.GetArrayLength() > 0)
        {
            var fill = fills[0];
            if (fill.TryGetProperty("type", out var fillType))
            {
                if (fillType.GetString() == "SOLID" && fill.TryGetProperty("color", out var color))
                    css["background-color"] = ColorToRgba(color, fill);
                else if (fillType.GetString() == "GRADIENT_LINEAR" && fill.TryGetProperty("gradientStops", out var stops))
                    css["background"] = BuildLinearGradient(stops);
            }
        }

        // Border (strokes)
        if (node.TryGetProperty("strokes", out var strokes) && strokes.GetArrayLength() > 0)
        {
            var stroke = strokes[0];
            if (stroke.TryGetProperty("color", out var sc))
            {
                var width = node.TryGetProperty("strokeWeight", out var sw) ? sw.GetDouble() : 1;
                css["border"] = $"{width}{_config.CssUnit} solid {ColorToRgba(sc, stroke)}";
            }
        }

        // Border radius
        if (node.TryGetProperty("cornerRadius", out var radius))
            css["border-radius"] = FormatPx(radius);
        else if (node.TryGetProperty("rectangleCornerRadii", out var radii) && radii.GetArrayLength() == 4)
            css["border-radius"] = $"{radii[0].GetDouble()}{_config.CssUnit} {radii[1].GetDouble()}{_config.CssUnit} {radii[2].GetDouble()}{_config.CssUnit} {radii[3].GetDouble()}{_config.CssUnit}";

        // Effects (shadows, blur)
        if (node.TryGetProperty("effects", out var effects))
        {
            var shadows = new List<string>();
            foreach (var effect in effects.EnumerateArray())
            {
                if (!effect.TryGetProperty("type", out var et)) continue;
                if (et.GetString() == "DROP_SHADOW" && effect.TryGetProperty("color", out var shColor))
                {
                    var ox = effect.TryGetProperty("offset", out var off) && off.TryGetProperty("x", out var ox2) ? ox2.GetDouble() : 0;
                    var oy = off.TryGetProperty("y", out var oy2) ? oy2.GetDouble() : 0;
                    var blur = effect.TryGetProperty("radius", out var br) ? br.GetDouble() : 0;
                    var spread = effect.TryGetProperty("spread", out var sp) ? sp.GetDouble() : 0;
                    shadows.Add($"{ox}{_config.CssUnit} {oy}{_config.CssUnit} {blur}{_config.CssUnit} {spread}{_config.CssUnit} {ColorToRgba(shColor, effect)}");
                }
                else if (et.GetString() == "LAYER_BLUR" && effect.TryGetProperty("radius", out var blurR))
                    css["filter"] = $"blur({blurR.GetDouble()}{_config.CssUnit})";
            }
            if (shadows.Count > 0) css["box-shadow"] = string.Join(", ", shadows);
        }

        // Text styles
        if (node.TryGetProperty("style", out var textStyle))
        {
            if (textStyle.TryGetProperty("fontSize", out var fs)) css["font-size"] = FormatPx(fs);
            if (textStyle.TryGetProperty("fontWeight", out var fw)) css["font-weight"] = fw.GetInt32().ToString();
            if (textStyle.TryGetProperty("fontFamily", out var ff)) css["font-family"] = $"'{ff.GetString()}'";
            if (textStyle.TryGetProperty("lineHeightPx", out var lh)) css["line-height"] = FormatPx(lh);
            if (textStyle.TryGetProperty("letterSpacing", out var ls)) css["letter-spacing"] = FormatPx(ls);
            if (textStyle.TryGetProperty("textAlignHorizontal", out var ta)) css["text-align"] = ta.GetString()?.ToLower();
            if (textStyle.TryGetProperty("textDecoration", out var td)) css["text-decoration"] = td.GetString()?.ToLower();
        }

        // Opacity
        if (node.TryGetProperty("opacity", out var op) && op.GetDouble() < 1.0)
            css["opacity"] = op.GetDouble().ToString("F2");

        // Overflow
        if (node.TryGetProperty("clipsContent", out var clip) && clip.GetBoolean())
            css["overflow"] = "hidden";

        return css;
    }

    // ── Component Tree Builder ──────────────────────────────────────────
    public List<Dictionary<string, object>> BuildComponentTree(List<Dictionary<string, object>> flatComponents)
    {
        var lookup = flatComponents.ToDictionary(c => c["id"].ToString(), c => c);
        var roots = new List<Dictionary<string, object>>();

        foreach (var comp in flatComponents)
        {
            var parentId = comp.TryGetValue("parentId", out var pid) ? pid?.ToString() : null;
            if (string.IsNullOrEmpty(parentId) || !lookup.ContainsKey(parentId))
            {
                roots.Add(comp);
            }
            else
            {
                var parent = lookup[parentId];
                if (!parent.ContainsKey("children"))
                    parent["children"] = new List<Dictionary<string, object>>();
                ((List<Dictionary<string, object>>)parent["children"]).Add(comp);
            }
        }
        return roots;
    }

    // ── Pattern Detection ──────────────────────────────────────────────
    public List<Dictionary<string, object>> DetectPatterns(List<Dictionary<string, object>> components)
    {
        var patterns = new List<Dictionary<string, object>>();
        var tree = BuildComponentTree(new List<Dictionary<string, object>>(components.Select(c => new Dictionary<string, object>(c))));

        DetectPatternsRecursive(tree, patterns);
        return patterns;
    }

    private void DetectPatternsRecursive(List<Dictionary<string, object>> nodes, List<Dictionary<string, object>> patterns)
    {
        foreach (var node in nodes)
        {
            var children = node.TryGetValue("children", out var ch) ? ch as List<Dictionary<string, object>> : null;
            if (children == null || children.Count == 0) continue;

            // List/Repeater: 3+ children with same type structure
            if (children.Count >= 3)
            {
                var types = children.Select(c => c.TryGetValue("type", out var t) ? t.ToString() : "").ToList();
                if (types.Distinct().Count() == 1)
                    patterns.Add(new Dictionary<string, object>
                    {
                        ["pattern"] = "list-repeater",
                        ["parentId"] = node["id"],
                        ["parentName"] = node.GetValueOrDefault("name", ""),
                        ["itemCount"] = children.Count,
                        ["itemType"] = types[0]
                    });
            }

            // Form: children with names containing input/field/label/button
            var formKeywords = new[] { "input", "field", "label", "button", "submit", "text", "email", "password" };
            var formChildren = children.Count(c =>
            {
                var name = c.TryGetValue("name", out var n) ? n.ToString().ToLower() : "";
                return formKeywords.Any(k => name.Contains(k));
            });
            if (formChildren >= 2)
                patterns.Add(new Dictionary<string, object>
                {
                    ["pattern"] = "form",
                    ["parentId"] = node["id"],
                    ["parentName"] = node.GetValueOrDefault("name", ""),
                    ["fieldCount"] = formChildren
                });

            // Navigation: horizontal layout with multiple similar items
            var css = node.TryGetValue("css", out var cssObj) ? cssObj as Dictionary<string, string> : null;
            if (css != null && css.TryGetValue("flex-direction", out var dir) && dir == "row" && children.Count >= 3)
                patterns.Add(new Dictionary<string, object>
                {
                    ["pattern"] = "navigation",
                    ["parentId"] = node["id"],
                    ["parentName"] = node.GetValueOrDefault("name", ""),
                    ["itemCount"] = children.Count
                });

            DetectPatternsRecursive(children, patterns);
        }
    }

    // ── Design Token Extraction ────────────────────────────────────────
    public Dictionary<string, object> ExtractDesignTokens(List<Dictionary<string, object>> components)
    {
        var colors = new Dictionary<string, int>();
        var fontSizes = new Dictionary<string, int>();
        var fontFamilies = new Dictionary<string, int>();
        var spacings = new Dictionary<string, int>();
        var radii = new Dictionary<string, int>();

        foreach (var comp in components)
        {
            if (comp.TryGetValue("css", out var cssObj) && cssObj is Dictionary<string, string> css)
            {
                Tally(colors, css, "background-color");
                Tally(colors, css, "color");
                Tally(fontSizes, css, "font-size");
                Tally(fontFamilies, css, "font-family");
                Tally(radii, css, "border-radius");
                foreach (var key in new[] { "gap", "padding-left", "padding-top", "padding-right", "padding-bottom" })
                    Tally(spacings, css, key);
            }
        }

        return new Dictionary<string, object>
        {
            ["colors"] = colors.OrderByDescending(kv => kv.Value).ToDictionary(kv => kv.Key, kv => (object)kv.Value),
            ["fontSizes"] = fontSizes.OrderByDescending(kv => kv.Value).ToDictionary(kv => kv.Key, kv => (object)kv.Value),
            ["fontFamilies"] = fontFamilies.OrderByDescending(kv => kv.Value).ToDictionary(kv => kv.Key, kv => (object)kv.Value),
            ["spacings"] = spacings.OrderByDescending(kv => kv.Value).ToDictionary(kv => kv.Key, kv => (object)kv.Value),
            ["radii"] = radii.OrderByDescending(kv => kv.Value).ToDictionary(kv => kv.Key, kv => (object)kv.Value)
        };
    }

    // ── Screen Map Generator ───────────────────────────────────────────
    public List<Dictionary<string, object>> GenerateScreenMap(List<Dictionary<string, object>> tree)
    {
        return tree.Select(root => new Dictionary<string, object>
        {
            ["screenName"] = root.GetValueOrDefault("name", "Unknown"),
            ["screenId"] = root.GetValueOrDefault("id", ""),
            ["componentCount"] = CountComponents(root),
            ["maxDepth"] = CalcMaxDepth(root, 0),
            ["topLevelChildren"] = (root.TryGetValue("children", out var ch) && ch is List<Dictionary<string, object>> children)
                ? children.Select(c => new Dictionary<string, object>
                {
                    ["name"] = c.GetValueOrDefault("name", ""),
                    ["type"] = c.GetValueOrDefault("type", "")
                }).ToList()
                : new List<Dictionary<string, object>>()
        }).ToList();
    }

    // ── Helpers ─────────────────────────────────────────────────────────
    private static string BuildHtmlTag(string type, string name)
    {
        var tag = type switch { "TEXT" => "span", "RECTANGLE" or "ELLIPSE" => "div", "VECTOR" => "svg", _ => "div" };
        return $"<{tag} class=\"{SanitizeClassName(name)}\">";
    }

    private static string ConvertAlign(string figmaAlign) => figmaAlign switch
    {
        "CENTER" => "center", "MAX" => "flex-end", "SPACE_BETWEEN" => "space-between", _ => "flex-start"
    };

    private static string ColorToRgba(JsonElement color, JsonElement parent = default)
    {
        var r = (int)(color.GetProperty("r").GetDouble() * 255);
        var g = (int)(color.GetProperty("g").GetDouble() * 255);
        var b = (int)(color.GetProperty("b").GetDouble() * 255);
        var a = color.TryGetProperty("a", out var alpha) ? alpha.GetDouble() : 1.0;
        // Check parent opacity
        if (parent.ValueKind == JsonValueKind.Object && parent.TryGetProperty("opacity", out var op))
            a *= op.GetDouble();
        return a >= 1.0 ? $"rgb({r}, {g}, {b})" : $"rgba({r}, {g}, {b}, {a:F2})";
    }

    private string BuildLinearGradient(JsonElement stops)
    {
        var parts = new List<string>();
        foreach (var stop in stops.EnumerateArray())
            if (stop.TryGetProperty("color", out var c) && stop.TryGetProperty("position", out var p))
                parts.Add($"{ColorToRgba(c)} {p.GetDouble() * 100:F0}%");
        return $"linear-gradient(180deg, {string.Join(", ", parts)})";
    }

    private string FormatPx(JsonElement val) => $"{val.GetDouble()}{_config.CssUnit}";

    private static string SanitizeClassName(string name)
    {
        if (string.IsNullOrEmpty(name)) return "component";
        return Regex.Replace(name.Replace(" ", "-").ToLower(), @"[^a-z0-9\-]", "");
    }

    private static string CamelToKebab(string camel) =>
        Regex.Replace(camel, @"([a-z])([A-Z])", "$1-$2").ToLower();

    private static Dictionary<string, string> ParseCssRules(string cssText)
    {
        var rules = new Dictionary<string, string>();
        var matches = Regex.Matches(cssText, @"([\w-]+)\s*:\s*([^;]+);?");
        foreach (Match m in matches) rules[m.Groups[1].Value.Trim()] = m.Groups[2].Value.Trim();
        return rules;
    }

    private static void Tally(Dictionary<string, int> dict, Dictionary<string, string> css, string key)
    {
        if (css.TryGetValue(key, out var val) && !string.IsNullOrEmpty(val))
            dict[val] = dict.TryGetValue(val, out var count) ? count + 1 : 1;
    }

    private static int CountComponents(Dictionary<string, object> node)
    {
        var count = 1;
        if (node.TryGetValue("children", out var ch) && ch is List<Dictionary<string, object>> children)
            count += children.Sum(c => CountComponents(c));
        return count;
    }

    private static int CalcMaxDepth(Dictionary<string, object> node, int current)
    {
        if (!node.TryGetValue("children", out var ch) || ch is not List<Dictionary<string, object>> children || children.Count == 0)
            return current;
        return children.Max(c => CalcMaxDepth(c, current + 1));
    }
}

/// <summary>Configuration for FigmaParser. All fields optional with sensible defaults.</summary>
public class FigmaParserConfig
{
    public int MaxDepth { get; set; } = 20;
    public bool DetectPatterns { get; set; } = true;
    public bool ExtractTokens { get; set; } = true;
    public bool IncludeInvisible { get; set; } = false;
    public string ImageHandling { get; set; } = "placeholder"; // placeholder | base64 | url
    public string CssUnit { get; set; } = "px";
    public string ClassNameStrategy { get; set; } = "kebab-case";
}

/// <summary>DI registration extensions.</summary>
public static class FigmaParserExtensions
{
    public static IServiceCollection AddXIIGenFigmaParser(this IServiceCollection services, Action<FigmaParserConfig> configure = null)
    {
        var config = new FigmaParserConfig();
        configure?.Invoke(config);
        services.AddSingleton(config);
        services.AddTransient<FigmaParser>();
        services.AddTransient<IStepExecutor>(sp => sp.GetRequiredService<FigmaParser>());
        return services;
    }
}
