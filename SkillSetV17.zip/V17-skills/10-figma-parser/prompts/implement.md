# Skill 10 — Figma Parser: Implementation Guide

## Prerequisites
- Skill 01 (Core Interfaces) — IStepExecutor, StepExecutionContext, MicroserviceBase
- Skill 02 (ObjectProcessor) — ParseObjectAlternative, BuildSearchFilter

## Step 1: Implement Format Detection
1. Check for `document.children` → Figma REST API format
2. Check for array with `sourceType` + `code` → FigmaCodeGenerator plugin format
3. Default → raw node array
4. Log detected format for debugging

## Step 2: Implement Figma API Parser
1. Recursive traversal of Figma node tree
2. Extract CSS from: layoutMode, fills, effects, strokes, constraints, style
3. Map auto-layout → flexbox (direction, gap, alignment, wrap)
4. Map fills → background-color (solid + gradient)
5. Map effects → box-shadow, filter: blur
6. Map strokes → border
7. Skip invisible nodes unless configured otherwise
8. Build dynamic document per component (Genie DNA-1 — no model class)

## Step 3: Implement Plugin Element Parser
1. Map FigmaCodeGenerator Element fields: name, sourceType, code, codeCss, subElements, style
2. Parse `codeCss` string into CSS property map
3. Parse `style` object with camelCase→kebab-case conversion
4. Recursively process `subElements` as children

## Step 4: Build Component Tree
1. Create lookup by component ID
2. Wire parent-child relationships using parentId
3. Components without parent → roots

## Step 5: Pattern Detection
1. **List/Repeater**: 3+ siblings with identical type structure
2. **Form**: Children with names containing input/field/label/button keywords
3. **Navigation**: Horizontal flex container with 3+ similar children
4. Return pattern type, parent info, and item count

## Step 6: Design Token Extraction
1. Collect all unique color values (background-color, color) with frequency
2. Collect font sizes, font families
3. Collect spacing values (gap, padding)
4. Collect border-radius values

## Step 7: Screen Map Generation
1. For each root component, generate summary: name, id, componentCount, maxDepth
2. Include top-level children names and types

## Step 8: DI Registration
1. `AddXIIGenFigmaParser(config?)` extension method
2. Register FigmaParserConfig, FigmaParser, and IStepExecutor

## Testing
- Parse sample Figma API response → verify component count, CSS extraction
- Parse FigmaCodeGenerator Element array → verify mapping
- Verify pattern detection with known UI patterns
- Verify design token extraction with varied designs


---

## Genie DNA Compliance — MANDATORY for All Implementations

> Before writing ANY code, classify each component:
> **MACHINE** (static): Infrastructure that enables freedom. Build once, generic, interface-based.
> **FREEDOM** (dynamic): Anything users define. No fixed models, config-driven.

### DNA Checklist — Every Implementation MUST:
☐ **DNA-1 (Dynamic Documents):** Store data as `Dictionary<string, object>` / `Record<string, any>` — NOT typed model classes. User fields preserved without schema changes.
☐ **DNA-2 (BuildSearchFilter):** All queries use BuildSearchFilter/equivalent. Empty fields auto-skipped. No entity-specific query code.
☐ **DNA-3 (MicroserviceBase):** Inherit base class with DB, queue, cache, logger built in.
☐ **DNA-5 (DataProcessResult):** All public methods return `DataProcessResult<T>`. Errors return failure, not throw exceptions.
☐ **DNA-6 (Generic Interfaces):** External dependencies behind interfaces. Swap via config.
☐ **DNA-SCOPE:** Non-admin queries auto-inject userId filter. Cannot be bypassed.

### The Three Tests:
1. Can a business user change this without a developer? (YES = correct)
2. Does it work for entity types that do not exist yet? (YES = correct)
3. Can I swap the database/service/UI without changing this? (YES = correct)
