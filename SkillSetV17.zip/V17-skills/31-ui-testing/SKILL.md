---
skill_id: "31"
name: ui-testing
title: "UI Test Generator Service"
layer: "L7: Quality"
version: "17.1"
status: "active"
dependencies: ["01-core-interfaces", "02-object-processor", "06-ai-providers", "10-figma-parser", "28-prompt-engineering"]
genie_dna:
  - "DNA-1: UI test specs stored as dynamic documents in ES"
  - "DNA-2: BuildSearchFilter for spec search — skip empty, inject scope"
  - "DNA-3: ParseObjectAlternative for spec storage"
  - "DNA-5: DataProcessResult wraps all operations"
  - "DNA-FREEDOM: Component specs, visual baselines, accessibility rules are user-definable"
  - "DNA-MACHINE: UI test engine generates and compares"
  - "DNA-SCOPE: ownerId injected on all spec queries"
triggers: ui test, visual regression, component test, storybook, screenshot test, accessibility test, a11y
es_indices:
  - "xiigen-ui-test-specs"
  - "xiigen-ui-test-results"
  - "xiigen-visual-baselines"
---

# Skill 31: UI Test Generator Service
## Visual Regression + Component Testing with Figma Integration

**Status:** Enhanced — DNA-Compliant  
**Priority:** P1 — Ensures UI matches design  
**Dependencies:** Skill 01, Skill 02, Skill 10 (Figma Parser), Skill 28  
**Layer:** L7: Quality  
**Estimated LOC:** ~400  

---

## Overview

The UI Test Generator creates component tests and visual regression tests by comparing generated UI against Figma designs. Test specs are dynamic documents — users define what components to test, acceptable visual thresholds, and accessibility rules. The engine uses AI to generate test code and compare screenshots against baselines.

## Key Concepts

- **UITestSpec** — Dynamic document: component selectors, expected states, visual thresholds. Schema-free.
- **VisualBaseline** — Reference screenshots/snapshots for comparison. Stored as dynamic docs with binary refs.
- **ComponentAnalyzer** — MACHINE: extracts testable components from Figma parse output (Skill 10).
- **A11yChecker** — MACHINE: validates accessibility rules (WCAG levels configurable via FREEDOM docs).

---

## Component Classification (MACHINE vs FREEDOM)

### 🔧 MACHINE
| Component | What It Does |
|-----------|-------------|
| UITestGeneratorService | Orchestrates spec → AI → test code pipeline |
| ComponentAnalyzer | Extracts components from Figma output for testing |
| VisualComparer | Screenshot diff engine with configurable thresholds |
| A11yChecker | Accessibility validation engine |

### 🔓 FREEDOM
| Component | What Users Control |
|-----------|-------------------|
| UI test specs | Component selectors, expected states, interactions |
| Visual baselines | Reference images per viewport/theme |
| A11y rules | WCAG level, custom rules, severity thresholds |
| Viewport configs | Device sizes, orientations — dynamic docs |
| Theme variants | Light/dark/high-contrast — test each |

---

## Scope Isolation
- Spec queries inject `ownerId` filter (non-admin)
- Visual baselines scoped to project + team
- System specs (scope: "system") provide default component tests
- AI agents use requesting user's scope

## AI Agent Communication
1. "Make sure my login screen looks right on mobile" → agent creates viewport spec + generates tests
2. "Check accessibility on all screens" → agent creates A11y spec docs per screen
3. Agent reads Figma parse (Skill 10) output → auto-generates component specs
4. Agent compares visual baselines → explains visual diffs in natural language

---

## Primary Interface (.NET 9)

```csharp
public interface IUITestGeneratorService
{
    Task<DataProcessResult<Dictionary<string, object>>> GenerateUITestsAsync(
        Dictionary<string, object> request, string userId, string traceId, CancellationToken ct = default);
    Task<DataProcessResult<Dictionary<string, object>>> GenerateFromFigmaAsync(
        string figmaNodeId, string userId, string traceId, CancellationToken ct = default);
    Task<DataProcessResult<string>> StoreSpecAsync(
        Dictionary<string, object> spec, CancellationToken ct = default);
    Task<DataProcessResult<List<Dictionary<string, object>>>> SearchSpecsAsync(
        Dictionary<string, object> filter, string userId, bool isAdmin = false, CancellationToken ct = default);
    Task<DataProcessResult<Dictionary<string, object>>> CompareVisualAsync(
        string specId, Dictionary<string, object> screenshot, CancellationToken ct = default);
    Task<DataProcessResult<Dictionary<string, object>>> CheckAccessibilityAsync(
        Dictionary<string, object> component, Dictionary<string, object> rules, CancellationToken ct = default);
}
```

### DI: `services.AddSingleton<IUITestGeneratorService, UITestGeneratorService>();`

---

## Abstraction Extraction
UI testing adds visual comparison and accessibility layers on top of the shared testing pattern:
- MACHINE: visual comparison engine, accessibility checker (build once)
- FREEDOM: specs, baselines, rules, viewport configs (dynamic docs)
- Figma integration (Skill 10) enables auto-generation of component specs from design files.

## Dependencies
| Skill | Provides |
|-------|---------|
| 10 | Figma parse output for component extraction |
| 28 | Prompt templates for test generation |
| 29 | Shared test result infrastructure |
