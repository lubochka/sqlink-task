# Skill 31: UI Testing — Implementation Prompt

## Phase 1: Component Test Setup
React Testing Library + Jest. Storybook for component isolation.

## Phase 2: Dynamic Form Tests
Given entity definition with N fields -> verify form renders N inputs.
Add field to definition -> verify form updates without code change.

## Phase 3: Filter Assembly Tests
Fill 2 of 5 fields -> verify only 2 in submitted filter. Clear field -> verify key REMOVED.

## Phase 4: Visual Regression
Storybook snapshots. Playwright visual comparison.

---

## Genie DNA Compliance — MANDATORY
☐ DNA-1: Dynamic Documents — Dictionary<string, object>, NOT typed models
☐ DNA-2: BuildSearchFilter — skip empty fields, no entity-specific query code
☐ DNA-3: MicroserviceBase — inherit DB, queue, cache, logger
☐ DNA-5: DataProcessResult<T> — all methods return result wrapper
☐ DNA-6: Generic Interfaces — swap via config
☐ DNA-SCOPE: Non-admin queries auto-inject userId filter
