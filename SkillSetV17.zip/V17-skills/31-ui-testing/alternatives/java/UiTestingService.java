/**
 * XIIGen Skill 31: UI Testing — Java Alternative
 * Uses Selenium WebDriver for visual regression and snapshot testing
 * DNA: DataProcessResult, dynamic documents, BuildSearchFilter
 */
package com.xiigen.uitesting;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class UiTestingService {
    private final IDatabaseService db;
    private final ILogger logger;
    private WebDriver driver;

    public UiTestingService(IDatabaseService db, ILogger logger) {
        this.db = db;
        this.logger = logger;
    }

    public DataProcessResult<UiTestResult> runSnapshotTest(UiTestConfig config) {
        try {
            initDriver(config.getViewport());
            driver.get(config.getBaselineUrl() != null ? config.getBaselineUrl()
                : "http://localhost:3000/components/" + config.getComponentId());

            List<String> screenshots = new ArrayList<>();
            for (String selector : config.getSelectors()) {
                WebElement element = driver.findElement(By.cssSelector(selector));
                byte[] screenshot = ((TakesScreenshot) element).getScreenshotAs(OutputType.BYTES);
                screenshots.add(Base64.getEncoder().encodeToString(screenshot));
            }

            UiTestResult result = new UiTestResult(
                "uitest-" + System.currentTimeMillis(),
                config.getComponentId(), config.getTestType(),
                screenshots.size() == config.getSelectors().size(),
                screenshots, null, List.of(), 0, Instant.now().toString()
            );

            // DNA: Store as dynamic document
            Map<String, Object> doc = new HashMap<>();
            doc.put("id", result.getId());
            doc.put("componentId", result.getComponentId());
            doc.put("testType", result.getTestType());
            doc.put("passed", result.isPassed());
            doc.put("screenshotCount", screenshots.size());
            doc.put("timestamp", result.getTimestamp());
            db.upsert("ui-test-results", doc);

            return DataProcessResult.ok(result, "Snapshot test completed");
        } catch (Exception e) {
            logger.error("UI test failed", e);
            return DataProcessResult.fail(e.getMessage());
        }
    }

    // DNA: BuildSearchFilter pattern
    public DataProcessResult<List<UiTestResult>> queryTestHistory(Map<String, Object> filters) {
        Map<String, Object> searchFilter = filters.entrySet().stream()
            .filter(e -> e.getValue() != null && !e.getValue().toString().isEmpty())
            .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
        return db.query("ui-test-results", searchFilter);
    }

    private void initDriver(Map<String, Integer> viewport) {
        if (driver == null) {
            ChromeOptions options = new ChromeOptions();
            options.addArguments("--headless", "--no-sandbox");
            driver = new ChromeDriver(options);
        }
        driver.manage().window().setSize(
            new Dimension(viewport.get("width"), viewport.get("height")));
    }

    public void close() { if (driver != null) driver.quit(); }
}
