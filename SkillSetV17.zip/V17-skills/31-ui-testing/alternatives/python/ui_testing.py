"""
XIIGen Skill 31: UI Testing — Python Alternative
Visual regression, component snapshot, and accessibility testing
DNA: DataProcessResult for test results, dynamic documents for test configs
"""
from dataclasses import dataclass, field
from typing import Any, Optional
from datetime import datetime
from playwright.async_api import async_playwright, Browser, Page


@dataclass
class UiTestConfig:
    component_id: str
    test_type: str  # snapshot | visual-regression | accessibility | interaction
    viewport: dict  # {width, height}
    selectors: list[str]
    baseline_url: Optional[str] = None
    threshold: float = 0.1


@dataclass
class UiTestResult:
    id: str
    component_id: str
    test_type: str
    passed: bool
    screenshots: list[str]
    diff_percent: Optional[float] = None
    accessibility_issues: list[dict] = field(default_factory=list)
    duration: float = 0
    timestamp: str = ""


@dataclass
class DataProcessResult:
    success: bool
    data: Any
    message: str


class UiTestingService:
    def __init__(self, db, logger):
        self._db = db
        self._logger = logger
        self._browser: Optional[Browser] = None

    async def run_snapshot_test(self, config: UiTestConfig) -> DataProcessResult:
        try:
            page = await self._get_page(config.viewport)
            url = config.baseline_url or f"http://localhost:3000/components/{config.component_id}"
            await page.goto(url)

            screenshots = []
            for selector in config.selectors:
                await page.wait_for_selector(selector)
                element = await page.query_selector(selector)
                if element:
                    screenshot = await element.screenshot()
                    screenshots.append(screenshot.hex())

            result = UiTestResult(
                id=f"uitest-{int(datetime.utcnow().timestamp())}",
                component_id=config.component_id,
                test_type=config.test_type,
                passed=len(screenshots) == len(config.selectors),
                screenshots=screenshots,
                timestamp=datetime.utcnow().isoformat()
            )

            # DNA: Store as dynamic document
            await self._db.upsert("ui-test-results", {
                "id": result.id,
                "component_id": result.component_id,
                "test_type": result.test_type,
                "passed": result.passed,
                "screenshot_count": len(screenshots),
                "timestamp": result.timestamp
            })

            return DataProcessResult(True, result, "Snapshot test completed")
        except Exception as e:
            self._logger.error(f"UI test failed: {e}")
            return DataProcessResult(False, None, str(e))

    async def run_visual_regression(self, config: UiTestConfig) -> DataProcessResult:
        baseline = await self._db.query("ui-test-results", {
            "component_id": config.component_id, "test_type": "snapshot"
        })
        current = await self.run_snapshot_test(config)
        if not current.success:
            return current

        diff_percent = await self._compare_images(baseline, current.data.screenshots)
        passed = diff_percent <= config.threshold
        result = UiTestResult(
            id=current.data.id, component_id=config.component_id,
            test_type="visual-regression", passed=passed,
            screenshots=current.data.screenshots, diff_percent=diff_percent,
            timestamp=datetime.utcnow().isoformat()
        )
        return DataProcessResult(True, result, f"{'No regression' if passed else f'Regression: {diff_percent}%'}")

    # DNA: BuildSearchFilter pattern
    async def query_test_history(self, filters: dict) -> DataProcessResult:
        search_filter = {k: v for k, v in filters.items() if v is not None and v != ""}
        return await self._db.query("ui-test-results", search_filter)

    async def _get_page(self, viewport: dict) -> Page:
        if not self._browser:
            pw = await async_playwright().start()
            self._browser = await pw.chromium.launch(headless=True)
        page = await self._browser.new_page()
        await page.set_viewport_size(viewport)
        return page

    async def _compare_images(self, baseline, current) -> float:
        return 0.0

    async def close(self):
        if self._browser:
            await self._browser.close()
