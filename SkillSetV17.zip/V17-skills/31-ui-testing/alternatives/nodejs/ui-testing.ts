/**
 * XIIGen Skill 31: UI Testing — Node.js Alternative
 * Visual regression, component snapshot, and accessibility testing
 * DNA: DataProcessResult for test results, dynamic documents for test configs
 */
import { DataProcessResult, IDatabaseService } from '../../core-interfaces';
import puppeteer, { Browser, Page } from 'puppeteer';

interface UiTestConfig {
  componentId: string;
  testType: 'snapshot' | 'visual-regression' | 'accessibility' | 'interaction';
  viewport: { width: number; height: number };
  selectors: string[];
  baselineUrl?: string;
  threshold?: number;
}

interface UiTestResult {
  id: string;
  componentId: string;
  testType: string;
  passed: boolean;
  screenshots: string[];
  diffPercent?: number;
  accessibilityIssues?: AccessibilityIssue[];
  duration: number;
  timestamp: string;
}

interface AccessibilityIssue {
  rule: string; severity: string; element: string; message: string;
}

class UiTestingService {
  private browser: Browser | null = null;
  constructor(private db: IDatabaseService, private logger: any) {}

  async runSnapshotTest(config: UiTestConfig): Promise<DataProcessResult<UiTestResult>> {
    try {
      const page = await this.getPage(config.viewport);
      await page.goto(config.baselineUrl || `http://localhost:3000/components/${config.componentId}`);
      
      const screenshots: string[] = [];
      for (const selector of config.selectors) {
        await page.waitForSelector(selector);
        const element = await page.$(selector);
        const screenshot = await element?.screenshot({ encoding: 'base64' });
        if (screenshot) screenshots.push(screenshot);
      }

      const result: UiTestResult = {
        id: `uitest-${Date.now()}`,
        componentId: config.componentId,
        testType: config.testType,
        passed: screenshots.length === config.selectors.length,
        screenshots,
        duration: 0,
        timestamp: new Date().toISOString()
      };

      // DNA: Store as dynamic document
      await this.db.upsert('ui-test-results', {
        id: result.id, ...result, screenshots: screenshots.length // Don't store base64 in ES
      });

      return { success: true, data: result, message: 'Snapshot test completed' };
    } catch (error: any) {
      this.logger.error('UI test failed', { error, config });
      return { success: false, data: null as any, message: error.message };
    }
  }

  async runVisualRegressionTest(config: UiTestConfig): Promise<DataProcessResult<UiTestResult>> {
    try {
      // Get baseline from previous test
      const baseline = await this.db.query('ui-test-results', {
        componentId: config.componentId,
        testType: 'snapshot'
      });

      const current = await this.runSnapshotTest(config);
      if (!current.success || !baseline) {
        return { success: false, data: null as any, message: 'Could not compare screenshots' };
      }

      const diffPercent = await this.compareImages(
        baseline.data?.screenshots?.[0],
        current.data?.screenshots?.[0]
      );
      
      const passed = diffPercent <= (config.threshold || 0.1);
      const result: UiTestResult = {
        ...current.data!,
        testType: 'visual-regression',
        passed,
        diffPercent
      };

      return { success: true, data: result, message: passed ? 'No visual regression' : `Regression: ${diffPercent}% diff` };
    } catch (error: any) {
      return { success: false, data: null as any, message: error.message };
    }
  }

  // DNA: BuildSearchFilter pattern
  async queryTestHistory(filters: Record<string, any>): Promise<DataProcessResult<UiTestResult[]>> {
    const searchFilter = Object.entries(filters)
      .filter(([_, v]) => v !== null && v !== undefined && v !== '')
      .reduce((acc, [k, v]) => ({ ...acc, [k]: v }), {});
    return this.db.query('ui-test-results', searchFilter);
  }

  private async getPage(viewport: { width: number; height: number }): Promise<Page> {
    if (!this.browser) this.browser = await puppeteer.launch({ headless: true });
    const page = await this.browser.newPage();
    await page.setViewport(viewport);
    return page;
  }

  private async compareImages(baseline: string, current: string): Promise<number> {
    // Placeholder: Use pixelmatch or sharp for actual comparison
    return 0;
  }

  async close(): Promise<void> {
    await this.browser?.close();
  }
}

export { UiTestingService, UiTestConfig, UiTestResult };
