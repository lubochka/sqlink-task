<?php
/**
 * XIIGen Skill 31: UI Testing — PHP Alternative
 * Uses Panther (headless Chrome) for visual testing
 * DNA: DataProcessResult, dynamic documents, BuildSearchFilter
 */
namespace XIIGen\UiTesting;

class UiTestingService
{
    private $db;
    private $logger;
    private $client = null;

    public function __construct($db, $logger)
    {
        $this->db = $db;
        $this->logger = $logger;
    }

    public function runSnapshotTest(array $config): array
    {
        try {
            $client = $this->getClient($config['viewport'] ?? []);
            $url = $config['baselineUrl'] ?? "http://localhost:3000/components/{$config['componentId']}";
            $client->request('GET', $url);

            $screenshots = [];
            foreach ($config['selectors'] as $selector) {
                $crawler = $client->getCrawler();
                $element = $crawler->filter($selector);
                if ($element->count() > 0) {
                    $screenshot = $client->takeScreenshot();
                    $screenshots[] = base64_encode($screenshot);
                }
            }

            $result = [
                'id' => 'uitest-' . time(),
                'componentId' => $config['componentId'],
                'testType' => $config['testType'],
                'passed' => count($screenshots) === count($config['selectors']),
                'screenshotCount' => count($screenshots),
                'timestamp' => date('c'),
            ];

            // DNA: Store as dynamic document
            $this->db->upsert('ui-test-results', $result);

            return ['success' => true, 'data' => $result, 'message' => 'Snapshot test completed'];
        } catch (\Exception $e) {
            $this->logger->error('UI test failed: ' . $e->getMessage());
            return ['success' => false, 'data' => null, 'message' => $e->getMessage()];
        }
    }

    // DNA: BuildSearchFilter pattern
    public function queryTestHistory(array $filters): array
    {
        $searchFilter = array_filter($filters, fn($v) => $v !== null && $v !== '');
        return $this->db->query('ui-test-results', $searchFilter);
    }

    private function getClient(array $viewport)
    {
        if (!$this->client) {
            $this->client = \Symfony\Component\Panther\Client::createChromeClient(null, null, [
                '--headless', '--no-sandbox',
                '--window-size=' . ($viewport['width'] ?? 1280) . ',' . ($viewport['height'] ?? 720)
            ]);
        }
        return $this->client;
    }

    public function close(): void
    {
        $this->client?->quit();
    }
}
