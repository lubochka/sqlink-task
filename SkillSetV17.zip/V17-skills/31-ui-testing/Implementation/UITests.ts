// XIIGen.Testing.UI | Skill 31
// Playwright for E2E browser tests + React Testing Library for component tests.
// Tests cover: Flow Editor, Flow Runner, Feedback UI, Debug Panel

// ═══════════════════════════════════════════════════════
// FILE: playwright.config.ts
// ═══════════════════════════════════════════════════════

// playwright.config.ts
import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: './tests/ui',
  fullyParallel: true,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: [['html'], ['junit', { outputFile: 'test-results/junit.xml' }]],
  use: {
    baseURL: process.env.BASE_URL || 'http://localhost:3000',
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
  },
  projects: [
    { name: 'chromium', use: { ...devices['Desktop Chrome'] } },
    { name: 'firefox', use: { ...devices['Desktop Firefox'] } },
    { name: 'webkit', use: { ...devices['Desktop Safari'] } },
    { name: 'mobile-chrome', use: { ...devices['Pixel 7'] } },
    { name: 'mobile-safari', use: { ...devices['iPhone 14'] } },
  ],
  webServer: {
    command: 'npm run dev',
    url: 'http://localhost:3000',
    reuseExistingServer: !process.env.CI,
  },
});

// ═══════════════════════════════════════════════════════
// FILE: tests/ui/flow-editor.spec.ts - Flow Editor E2E
// ═══════════════════════════════════════════════════════

import { test, expect, Page } from '@playwright/test';

test.describe('Flow Editor', () => {

  test.beforeEach(async ({ page }) => {
    await page.goto('/editor');
    await page.waitForSelector('[data-testid="flow-canvas"]');
  });

  test('loads empty canvas', async ({ page }) => {
    const canvas = page.locator('[data-testid="flow-canvas"]');
    await expect(canvas).toBeVisible();
    const nodes = page.locator('[data-testid^="flow-node-"]');
    await expect(nodes).toHaveCount(0);
  });

  test('adds node via drag from toolbar', async ({ page }) => {
    const toolbar = page.locator('[data-testid="node-toolbar"]');
    const aiTransformNode = toolbar.locator('[data-node-type="ai-transform"]');
    const canvas = page.locator('[data-testid="flow-canvas"]');

    await aiTransformNode.dragTo(canvas, { targetPosition: { x: 300, y: 200 } });
    await expect(page.locator('[data-testid^="flow-node-"]')).toHaveCount(1);
  });

  test('connects two nodes with edge', async ({ page }) => {
    // Add two nodes
    await addNode(page, 'ai-transform', 200, 150);
    await addNode(page, 'ai-review', 500, 150);

    // Connect them
    const sourceHandle = page.locator('[data-testid="flow-node-0"] [data-handletype="source"]');
    const targetHandle = page.locator('[data-testid="flow-node-1"] [data-handletype="target"]');
    await sourceHandle.dragTo(targetHandle);

    await expect(page.locator('[data-testid^="flow-edge-"]')).toHaveCount(1);
  });

  test('opens node config panel on click', async ({ page }) => {
    await addNode(page, 'ai-transform', 300, 200);
    await page.locator('[data-testid="flow-node-0"]').click();

    const configPanel = page.locator('[data-testid="node-config-panel"]');
    await expect(configPanel).toBeVisible();
    await expect(configPanel.locator('h3')).toContainText('AI Transform');
  });

  test('saves flow definition', async ({ page }) => {
    await addNode(page, 'figma-parser', 200, 150);
    await addNode(page, 'ai-transform', 500, 150);

    const saveBtn = page.locator('[data-testid="save-flow-btn"]');
    await saveBtn.click();

    await expect(page.locator('[data-testid="save-success-toast"]')).toBeVisible();
  });

  test('loads existing flow definition', async ({ page }) => {
    await page.goto('/editor/figma-to-react-v1');
    await page.waitForSelector('[data-testid="flow-canvas"]');

    const nodes = page.locator('[data-testid^="flow-node-"]');
    await expect(nodes).toHaveCount.greaterThan(0);
  });

  test('keyboard shortcut Ctrl+Z undoes last action', async ({ page }) => {
    await addNode(page, 'ai-transform', 300, 200);
    await expect(page.locator('[data-testid^="flow-node-"]')).toHaveCount(1);

    await page.keyboard.press('Control+z');
    await expect(page.locator('[data-testid^="flow-node-"]')).toHaveCount(0);
  });

  test('delete key removes selected node', async ({ page }) => {
    await addNode(page, 'ai-transform', 300, 200);
    await page.locator('[data-testid="flow-node-0"]').click();
    await page.keyboard.press('Delete');

    await expect(page.locator('[data-testid^="flow-node-"]')).toHaveCount(0);
  });
});

test.describe('Flow Runner', () => {

  test('triggers flow and shows progress', async ({ page }) => {
    await page.goto('/runner');
    await page.fill('[data-testid="flow-id-input"]', 'figma-to-react-v1');
    await page.click('[data-testid="trigger-flow-btn"]');

    await expect(page.locator('[data-testid="flow-progress"]')).toBeVisible();
    await expect(page.locator('[data-testid="flow-status"]')).toContainText(/Running|Queued/);
  });

  test('shows step results as they complete', async ({ page }) => {
    await page.goto('/runner');
    await triggerTestFlow(page);

    // Wait for at least one step to complete
    await page.waitForSelector('[data-testid="step-status-completed"]', { timeout: 15000 });
    const completedSteps = page.locator('[data-testid="step-status-completed"]');
    await expect(completedSteps).toHaveCount.greaterThan(0);
  });

  test('feedback buttons appear on completed steps', async ({ page }) => {
    await page.goto('/runner');
    await triggerTestFlow(page);
    await page.waitForSelector('[data-testid="step-status-completed"]', { timeout: 15000 });

    const feedbackBtns = page.locator('[data-testid="feedback-positive"]');
    await expect(feedbackBtns.first()).toBeVisible();
  });

  test('submitting feedback shows confirmation', async ({ page }) => {
    await page.goto('/runner');
    await triggerTestFlow(page);
    await page.waitForSelector('[data-testid="feedback-positive"]', { timeout: 15000 });

    await page.locator('[data-testid="feedback-positive"]').first().click();
    await expect(page.locator('[data-testid="feedback-submitted"]').first()).toBeVisible();
  });
});

test.describe('Debug Panel', () => {

  test('shows step input/output/prompts', async ({ page }) => {
    await page.goto('/debug/trace-123');
    await page.waitForSelector('[data-testid="debug-timeline"]');

    const steps = page.locator('[data-testid^="debug-step-"]');
    await expect(steps).toHaveCount.greaterThan(0);

    // Expand first step
    await steps.first().click();
    await expect(page.locator('[data-testid="step-input"]')).toBeVisible();
    await expect(page.locator('[data-testid="step-output"]')).toBeVisible();
    await expect(page.locator('[data-testid="step-prompt"]')).toBeVisible();
  });
});

test.describe('Responsive Design', () => {

  test('editor adapts to mobile viewport', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/editor');
    await expect(page.locator('[data-testid="mobile-menu-toggle"]')).toBeVisible();
  });

  test('runner works on tablet', async ({ page }) => {
    await page.setViewportSize({ width: 768, height: 1024 });
    await page.goto('/runner');
    await expect(page.locator('[data-testid="flow-id-input"]')).toBeVisible();
  });
});

test.describe('Accessibility', () => {

  test('flow editor is keyboard navigable', async ({ page }) => {
    await page.goto('/editor');
    await page.keyboard.press('Tab');
    const focused = page.locator(':focus');
    await expect(focused).toBeVisible();
  });

  test('all interactive elements have ARIA labels', async ({ page }) => {
    await page.goto('/editor');
    const buttons = page.locator('button:not([aria-label]):not([aria-labelledby])');
    const count = await buttons.count();
    // Allow some buttons with visible text content
    for (let i = 0; i < count; i++) {
      const text = await buttons.nth(i).textContent();
      expect(text?.trim().length).toBeGreaterThan(0);
    }
  });
});

// ─── Helper Functions ────────────────────────────────────

async function addNode(page: Page, nodeType: string, x: number, y: number) {
  const toolbar = page.locator('[data-testid="node-toolbar"]');
  const node = toolbar.locator(`[data-node-type="${nodeType}"]`);
  const canvas = page.locator('[data-testid="flow-canvas"]');
  await node.dragTo(canvas, { targetPosition: { x, y } });
}

async function triggerTestFlow(page: Page) {
  await page.fill('[data-testid="flow-id-input"]', 'figma-to-react-v1');
  await page.click('[data-testid="trigger-flow-btn"]');
  await page.waitForSelector('[data-testid="flow-progress"]');
}

// ═══════════════════════════════════════════════════════
// FILE: tests/components/FlowNode.test.tsx - Component Tests
// ═══════════════════════════════════════════════════════

import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { FlowNode } from '../../src/components/FlowNode';

describe('FlowNode Component', () => {
  const defaultProps = {
    id: 'node-1',
    type: 'ai-transform',
    label: 'AI Transform',
    status: 'idle',
    onSelect: jest.fn(),
    onDelete: jest.fn(),
  };

  it('renders with correct label', () => {
    render(<FlowNode {...defaultProps} />);
    expect(screen.getByText('AI Transform')).toBeInTheDocument();
  });

  it('shows running indicator when status is running', () => {
    render(<FlowNode {...defaultProps} status="running" />);
    expect(screen.getByTestId('running-indicator')).toBeInTheDocument();
  });

  it('shows error state on failed status', () => {
    render(<FlowNode {...defaultProps} status="failed" />);
    expect(screen.getByTestId('error-indicator')).toBeInTheDocument();
  });

  it('calls onSelect when clicked', () => {
    render(<FlowNode {...defaultProps} />);
    fireEvent.click(screen.getByTestId('flow-node-node-1'));
    expect(defaultProps.onSelect).toHaveBeenCalledWith('node-1');
  });

  it('shows delete button on hover', () => {
    render(<FlowNode {...defaultProps} />);
    fireEvent.mouseEnter(screen.getByTestId('flow-node-node-1'));
    expect(screen.getByTestId('delete-node-btn')).toBeVisible();
  });

  it('calls onDelete when delete button clicked', () => {
    render(<FlowNode {...defaultProps} />);
    fireEvent.mouseEnter(screen.getByTestId('flow-node-node-1'));
    fireEvent.click(screen.getByTestId('delete-node-btn'));
    expect(defaultProps.onDelete).toHaveBeenCalledWith('node-1');
  });

  it('renders handles for connections', () => {
    render(<FlowNode {...defaultProps} />);
    expect(screen.getByTestId('source-handle')).toBeInTheDocument();
    expect(screen.getByTestId('target-handle')).toBeInTheDocument();
  });

  it('matches snapshot', () => {
    const { container } = render(<FlowNode {...defaultProps} />);
    expect(container).toMatchSnapshot();
  });
});

describe('FeedbackPanel Component', () => {
  const defaultProps = {
    traceId: 'trace-1',
    stepId: 'step-1',
    onSubmit: jest.fn(),
  };

  it('renders three rating buttons', () => {
    render(<FeedbackPanel {...defaultProps} />);
    expect(screen.getByTestId('feedback-positive')).toBeInTheDocument();
    expect(screen.getByTestId('feedback-neutral')).toBeInTheDocument();
    expect(screen.getByTestId('feedback-negative')).toBeInTheDocument();
  });

  it('shows text input when rating selected', () => {
    render(<FeedbackPanel {...defaultProps} />);
    fireEvent.click(screen.getByTestId('feedback-positive'));
    expect(screen.getByPlaceholderText(/comment/i)).toBeInTheDocument();
  });

  it('submits feedback with rating and text', () => {
    render(<FeedbackPanel {...defaultProps} />);
    fireEvent.click(screen.getByTestId('feedback-negative'));
    fireEvent.change(screen.getByPlaceholderText(/comment/i), { target: { value: 'Bad layout' } });
    fireEvent.click(screen.getByTestId('submit-feedback-btn'));
    expect(defaultProps.onSubmit).toHaveBeenCalledWith('step-1', 'Negative', 'Bad layout');
  });
});
