// XIIGen.Skills.UITesting/UITestGenerator.cs | .NET 9 | Skill 31
// Generates UI component tests, interaction tests, and visual regression tests.

using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using XIIGen.Core.Base;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Skills.UITesting;

// ═══ Models ═══════════════════════════════════════════
public record UITestConfig(
    string Framework = "react-native-testing-library",
    bool GenerateSnapshots = true,
    bool GenerateAccessibilityTests = true,
    bool GenerateInteractionTests = true,
    bool GenerateStorybook = false,
    string[] ExcludePatterns = null
);

public record UITestSuite(
    string ComponentName,
    string Framework,
    List<UITestFile> TestFiles,
    int TotalTests,
    DateTime GeneratedAt
);

public record UITestFile(
    string Path,
    string Content,
    string TestType, // "component", "interaction", "snapshot", "accessibility"
    int TestCount
);

public record ComponentAnalysis(
    string Name,
    List<PropDefinition> Props,
    List<string> StateHooks,
    List<string> EventHandlers,
    List<string> ChildComponents,
    bool HasNavigation,
    bool HasAsyncEffects
);

public record PropDefinition(
    string Name,
    string Type,
    bool Required,
    string DefaultValue
);

public record StorySet(
    string ComponentName,
    List<StoryDefinition> Stories,
    string StoryFileContent
);

public record StoryDefinition(
    string Name,
    string Description,
    Dictionary<string, object> Args
);

// ═══ Service ═════════════════════════════════════════
public class UITestGenerator : MicroserviceBase
{
    private readonly IDatabaseService _db;

    public UITestGenerator(IDatabaseService db, IQueueService queue,
        ILogger<UITestGenerator> logger, ICacheService cache = null)
        : base(db, queue, logger, cache)
    {
        _db = db;
        ServiceName = "ui-test-generator";
    }

    // ─── Component Test Generation ────────────────────
    public async Task<DataProcessResult<UITestSuite>> GenerateComponentTestsAsync(
        string componentCode, string framework, UITestConfig config = null)
    {
        config ??= new UITestConfig();
        try
        {
            var analysis = AnalyzeComponent(componentCode);
            var testFiles = new List<UITestFile>();

            // Render tests
            testFiles.Add(GenerateRenderTests(analysis, framework));

            // Props tests
            if (analysis.Props.Any())
                testFiles.Add(GeneratePropsTests(analysis, framework));

            // Event tests
            if (config.GenerateInteractionTests && analysis.EventHandlers.Any())
                testFiles.Add(GenerateEventTests(analysis, framework));

            // Snapshot tests
            if (config.GenerateSnapshots)
                testFiles.Add(GenerateSnapshotTests(analysis, framework));

            // Accessibility tests
            if (config.GenerateAccessibilityTests)
                testFiles.Add(GenerateAccessibilityTests(analysis, framework));

            var suite = new UITestSuite(
                analysis.Name, framework, testFiles,
                testFiles.Sum(f => f.TestCount), DateTime.UtcNow);

            return DataProcessResult<UITestSuite>.Success(suite);
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "UI test generation failed");
            return DataProcessResult<UITestSuite>.Failure($"Generation failed: {ex.Message}");
        }
    }

    // ─── Storybook Generation ─────────────────────────
    public async Task<DataProcessResult<StorySet>> GenerateStorybookStoriesAsync(
        string componentCode, string framework)
    {
        try
        {
            var analysis = AnalyzeComponent(componentCode);
            var stories = new List<StoryDefinition>();

            // Default story
            stories.Add(new StoryDefinition("Default", "Component with default props",
                GetDefaultArgs(analysis)));

            // Variant stories per prop combination
            foreach (var prop in analysis.Props.Where(p => p.Type == "boolean"))
            {
                stories.Add(new StoryDefinition(
                    $"With{prop.Name}True", $"Component with {prop.Name} enabled",
                    new Dictionary<string, object> { [prop.Name] = true }));
            }

            // Loading state
            if (analysis.HasAsyncEffects)
                stories.Add(new StoryDefinition("Loading", "Component in loading state",
                    new Dictionary<string, object> { ["isLoading"] = true }));

            // Empty state
            stories.Add(new StoryDefinition("Empty", "Component with no data",
                new Dictionary<string, object>()));

            var content = GenerateStoryFileContent(analysis, stories, framework);
            return DataProcessResult<StorySet>.Success(
                new StorySet(analysis.Name, stories, content));
        }
        catch (Exception ex)
        {
            return DataProcessResult<StorySet>.Failure($"Storybook generation failed: {ex.Message}");
        }
    }

    // ─── Analysis ─────────────────────────────────────
    private ComponentAnalysis AnalyzeComponent(string code)
    {
        var name = ExtractComponentName(code);
        return new ComponentAnalysis(
            Name: name,
            Props: ExtractProps(code),
            StateHooks: ExtractStateHooks(code),
            EventHandlers: ExtractEventHandlers(code),
            ChildComponents: ExtractChildComponents(code),
            HasNavigation: code.Contains("useNavigation") || code.Contains("router"),
            HasAsyncEffects: code.Contains("useEffect") || code.Contains("async")
        );
    }

    private string ExtractComponentName(string code)
    {
        // Simplified: extract from "export default function ComponentName" or "const ComponentName"
        var match = System.Text.RegularExpressions.Regex.Match(
            code, @"(?:export\s+default\s+function|const)\s+(\w+)");
        return match.Success ? match.Groups[1].Value : "Component";
    }

    private List<PropDefinition> ExtractProps(string code)
    {
        var props = new List<PropDefinition>();
        var match = System.Text.RegularExpressions.Regex.Match(
            code, @"(?:interface|type)\s+\w*Props\s*\{([^}]+)\}");
        if (match.Success)
        {
            var body = match.Groups[1].Value;
            foreach (System.Text.RegularExpressions.Match prop in
                System.Text.RegularExpressions.Regex.Matches(body, @"(\w+)(\?)?:\s*(\w+)"))
            {
                props.Add(new PropDefinition(
                    prop.Groups[1].Value,
                    prop.Groups[3].Value,
                    !prop.Groups[2].Success,
                    null));
            }
        }
        return props;
    }

    private List<string> ExtractStateHooks(string code) =>
        System.Text.RegularExpressions.Regex.Matches(code, @"useState\w*<?\w*>?\(")
            .Select(m => m.Value).ToList();

    private List<string> ExtractEventHandlers(string code) =>
        System.Text.RegularExpressions.Regex.Matches(code, @"(?:onPress|onChange|onSubmit|onClick|onFocus)\s*=")
            .Select(m => m.Value.TrimEnd('=',' ')).Distinct().ToList();

    private List<string> ExtractChildComponents(string code) =>
        System.Text.RegularExpressions.Regex.Matches(code, @"<([A-Z]\w+)")
            .Select(m => m.Groups[1].Value).Distinct().ToList();

    // ─── Test Generators ──────────────────────────────
    private UITestFile GenerateRenderTests(ComponentAnalysis analysis, string framework)
    {
        var sb = new StringBuilder();
        sb.AppendLine($"// Auto-generated render tests for {analysis.Name}");
        sb.AppendLine($"import {{ render, screen }} from '@testing-library/{(framework.Contains("native") ? "react-native" : "react")}';");
        sb.AppendLine($"import {{ {analysis.Name} }} from '../{analysis.Name}';");
        sb.AppendLine();
        sb.AppendLine($"describe('{analysis.Name} - Render', () => {{");
        sb.AppendLine($"  it('renders without crashing', () => {{");
        sb.AppendLine($"    const {{ container }} = render(<{analysis.Name} />);");
        sb.AppendLine($"    expect(container).toBeTruthy();");
        sb.AppendLine($"  }});");

        foreach (var prop in analysis.Props.Where(p => p.Required))
        {
            sb.AppendLine($"  it('renders with required prop {prop.Name}', () => {{");
            sb.AppendLine($"    render(<{analysis.Name} {prop.Name}={{{GetTestValue(prop)}}} />);");
            sb.AppendLine($"  }});");
        }

        sb.AppendLine($"}});");
        return new UITestFile($"{analysis.Name}.render.test.tsx", sb.ToString(), "component",
            1 + analysis.Props.Count(p => p.Required));
    }

    private UITestFile GeneratePropsTests(ComponentAnalysis analysis, string framework)
    {
        var sb = new StringBuilder();
        sb.AppendLine($"describe('{analysis.Name} - Props', () => {{");
        foreach (var prop in analysis.Props)
        {
            sb.AppendLine($"  it('handles {prop.Name} prop correctly', () => {{");
            sb.AppendLine($"    const {{ getByTestId }} = render(<{analysis.Name} {prop.Name}={{{GetTestValue(prop)}}} />);");
            sb.AppendLine($"    // Verify prop is applied");
            sb.AppendLine($"  }});");
        }
        sb.AppendLine($"}});");
        return new UITestFile($"{analysis.Name}.props.test.tsx", sb.ToString(), "component", analysis.Props.Count);
    }

    private UITestFile GenerateEventTests(ComponentAnalysis analysis, string framework)
    {
        var sb = new StringBuilder();
        sb.AppendLine($"import {{ fireEvent }} from '@testing-library/{(framework.Contains("native") ? "react-native" : "react")}';");
        sb.AppendLine($"describe('{analysis.Name} - Events', () => {{");
        foreach (var handler in analysis.EventHandlers)
        {
            sb.AppendLine($"  it('handles {handler} event', () => {{");
            sb.AppendLine($"    const mockHandler = jest.fn();");
            sb.AppendLine($"    const {{ getByTestId }} = render(<{analysis.Name} {handler}={{mockHandler}} />);");
            sb.AppendLine($"    fireEvent.press(getByTestId('{analysis.Name.ToLower()}-trigger'));");
            sb.AppendLine($"    expect(mockHandler).toHaveBeenCalled();");
            sb.AppendLine($"  }});");
        }
        sb.AppendLine($"}});");
        return new UITestFile($"{analysis.Name}.events.test.tsx", sb.ToString(), "interaction", analysis.EventHandlers.Count);
    }

    private UITestFile GenerateSnapshotTests(ComponentAnalysis analysis, string framework)
    {
        var sb = new StringBuilder();
        sb.AppendLine($"describe('{analysis.Name} - Snapshots', () => {{");
        sb.AppendLine($"  it('matches default snapshot', () => {{");
        sb.AppendLine($"    const tree = render(<{analysis.Name} />).toJSON();");
        sb.AppendLine($"    expect(tree).toMatchSnapshot();");
        sb.AppendLine($"  }});");
        sb.AppendLine($"}});");
        return new UITestFile($"{analysis.Name}.snapshot.test.tsx", sb.ToString(), "snapshot", 1);
    }

    private UITestFile GenerateAccessibilityTests(ComponentAnalysis analysis, string framework)
    {
        var sb = new StringBuilder();
        sb.AppendLine($"describe('{analysis.Name} - Accessibility', () => {{");
        sb.AppendLine($"  it('has accessible labels', () => {{");
        sb.AppendLine($"    const {{ getByA11yLabel }} = render(<{analysis.Name} />);");
        sb.AppendLine($"    // Verify ARIA labels exist");
        sb.AppendLine($"  }});");
        sb.AppendLine($"  it('supports screen reader', () => {{");
        sb.AppendLine($"    const {{ getByRole }} = render(<{analysis.Name} />);");
        sb.AppendLine($"    // Verify semantic roles");
        sb.AppendLine($"  }});");
        sb.AppendLine($"}});");
        return new UITestFile($"{analysis.Name}.a11y.test.tsx", sb.ToString(), "accessibility", 2);
    }

    private string GenerateStoryFileContent(ComponentAnalysis analysis, List<StoryDefinition> stories, string framework)
    {
        var sb = new StringBuilder();
        sb.AppendLine($"import type {{ Meta, StoryObj }} from '@storybook/react';");
        sb.AppendLine($"import {{ {analysis.Name} }} from './{analysis.Name}';");
        sb.AppendLine();
        sb.AppendLine($"const meta: Meta<typeof {analysis.Name}> = {{");
        sb.AppendLine($"  title: 'Components/{analysis.Name}',");
        sb.AppendLine($"  component: {analysis.Name},");
        sb.AppendLine($"}};");
        sb.AppendLine($"export default meta;");
        foreach (var story in stories)
        {
            sb.AppendLine($"export const {story.Name}: StoryObj<typeof {analysis.Name}> = {{");
            sb.AppendLine($"  args: {JsonSerializer.Serialize(story.Args)},");
            sb.AppendLine($"}};");
        }
        return sb.ToString();
    }

    private Dictionary<string, object> GetDefaultArgs(ComponentAnalysis analysis) =>
        analysis.Props.Where(p => p.Required).ToDictionary(
            p => p.Name, p => (object)GetTestValue(p));

    private string GetTestValue(PropDefinition prop) => prop.Type switch
    {
        "string" => "'test value'",
        "number" => "42",
        "boolean" => "true",
        _ => "'test'"
    };
}
