# Skill 50: Groups Service
## Community and group management with dynamic membership, role-based permissions, and policy enforcement

```yaml
skill_id: "50"
skill_name: "Groups Service"
layer: "L10: Social Graph"
phase: "D1"
priority: "P1"
status: "Ready to Generate"
estimated_loc: 800
dependencies:
  - "01-core-interfaces"
  - "02-object-processor"
  - "03-elasticsearch-datastore"
  - "04-redis-queue-service"
  - "20-auth-service"
  - "21-permissions-service"
  - "49-connections-service"
uml_coverage:
  - "User Registration (group auto-join)"
  - "Event Create (group-scoped events)"
  - "Post Create (group content distribution)"
  - "Friend Request (shared groups as weight factor)"
  - "Marketplace (cooperator groups)"
dna_classification:
  machine:
    - "Role permission enforcement (admin/moderator/member hierarchy)"
    - "Membership state machine (invited→pending→active→suspended→banned)"
    - "Capacity enforcement (hard limit on member count)"
    - "Content policy rule engine (what types allowed per group)"
  freedom:
    - "Group types (professional, social, interest, private — admin-defined)"
    - "Custom roles beyond default three (admin-configurable)"
    - "Join policies (open, approval, invite-only — per group)"
    - "Content policies (allowed post types, attachment rules — per group)"
    - "Auto-join rules (match users to groups on registration)"
    - "Group categories and tags"
    - "Membership duration limits, trial periods"
```

---

## Overview

The Groups Service manages community spaces where users gather around shared interests, professions, or goals. It handles the full lifecycle: group creation, membership management with role-based permissions, policy enforcement for content and join rules, and group discovery. Groups are a critical social graph node — they influence connection strength (Skill 49), scope event visibility (Skill 53), filter feed content (Skill 46), and provide matching signals (Skill 47).

Every group, membership, role, and policy is stored as a dynamic document (`Dictionary<string, object>`) enabling business users to define new group types, custom roles, and content policies without code changes — the Genie DNA "Freedom Machine" philosophy.

## Key Concepts

- **Group** — A dynamic document with name, type, description, policies, and metadata. Any fields can be added by the business user.
- **Membership** — Links a user to a group with a role, status, and timestamps. Status follows a state machine: `invited → pending → active → suspended → banned`.
- **Role** — Named permission set (admin, moderator, member, or custom). Permissions are a dynamic list of capability strings.
- **Policy** — Configurable rules per group: join policy (open/approval/invite), content policy (allowed types), capacity limits, visibility.
- **Auto-Join Rule** — Dynamic rule matching user attributes to groups for automatic membership on registration.

---

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    API Gateway (15)                       │
│  POST /groups  GET /groups/:id  POST /groups/:id/join   │
└────────────────────┬────────────────────────────────────┘
                     │
┌────────────────────▼────────────────────────────────────┐
│              Groups Service (50)                         │
│                                                          │
│  ┌──────────┐  ┌──────────────┐  ┌───────────────────┐  │
│  │ Group    │  │ Membership   │  │ Policy Engine     │  │
│  │ CRUD     │  │ Manager      │  │ (join + content)  │  │
│  └────┬─────┘  └──────┬───────┘  └────────┬──────────┘  │
│       │               │                    │             │
│  ┌────▼───────────────▼────────────────────▼──────────┐  │
│  │         IDatabaseService (Skill 01)                │  │
│  │  ES Indices: groups, group-members, group-config   │  │
│  └────────────────────────────────────────────────────┘  │
│       │                                                  │
│  ┌────▼────────────────────────────────────────────────┐ │
│  │         IQueueService (Skill 04)                    │ │
│  │  Publishes: GroupCreated, MemberJoined, MemberLeft  │ │
│  │  Subscribes: UserRegistered, ConnectionAccepted     │ │
│  └─────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────┘
         │                    │                  │
    ┌────▼───┐          ┌────▼──────┐     ┌─────▼─────┐
    │Feed(46)│          │Connect(49)│     │Events(53) │
    │group   │          │shared grp │     │group-scope│
    │content │          │weight     │     │events     │
    └────────┘          └───────────┘     └───────────┘
```

---

## Elasticsearch Indices

### `groups`
```json
{
  "groupId": "grp_abc123",
  "name": "Tech Entrepreneurs Berlin",
  "type": "professional",
  "description": "A community for tech founders in Berlin",
  "visibility": "public",
  "scopeId": "tenant_001",
  "createdBy": "user_001",
  "memberCount": 47,
  "capacity": 500,
  "tags": ["tech", "startup", "berlin"],
  "policies": {
    "joinPolicy": "approval",
    "contentTypes": ["discussion", "event", "resource"],
    "allowAttachments": true,
    "moderationLevel": "standard"
  },
  "metadata": {
    "coverImage": "https://...",
    "location": "Berlin, Germany",
    "customField1": "any value"
  },
  "status": "active",
  "createdAt": "2025-01-15T10:00:00Z",
  "updatedAt": "2025-06-20T14:30:00Z"
}
```

### `group-members`
```json
{
  "membershipId": "mbr_def456",
  "groupId": "grp_abc123",
  "userId": "user_042",
  "role": "member",
  "permissions": ["read", "post", "comment"],
  "status": "active",
  "joinedAt": "2025-03-01T09:00:00Z",
  "invitedBy": "user_001",
  "metadata": {
    "joinSource": "auto-match",
    "matchScore": 0.82
  }
}
```

### `group-config`
```json
{
  "configId": "cfg_grp_001",
  "scopeId": "tenant_001",
  "defaultRoles": {
    "admin": ["read", "post", "comment", "delete", "ban", "invite", "editGroup", "manageRoles"],
    "moderator": ["read", "post", "comment", "delete", "invite"],
    "member": ["read", "post", "comment"]
  },
  "groupTypes": ["professional", "social", "interest", "private", "course"],
  "maxGroupsPerUser": 50,
  "autoJoinRules": [
    {
      "ruleId": "rule_001",
      "matchField": "interests",
      "matchValue": "technology",
      "targetGroupId": "grp_abc123",
      "role": "member"
    }
  ]
}
```

---

## Genie DNA Patterns

### DNA-1: Dynamic Documents
All groups, memberships, and configs stored as `Dictionary<string, object>`. No `Group` class, no `Membership` class. Group policies, custom roles, and metadata fields are extensible without code changes.

### DNA-2: BuildSearchFilter
```csharp
var filter = new Dictionary<string, object>();
if (!string.IsNullOrEmpty(type)) filter["type"] = type;
if (!string.IsNullOrEmpty(status)) filter["status"] = status;
if (!string.IsNullOrEmpty(scopeId)) filter["scopeId"] = scopeId;
if (tags?.Any() == true) filter["_any_tags"] = tags;
// Empty fields automatically skipped — no null checks in query builder
```

### DNA-5: DataProcessResult
Every public method returns `DataProcessResult<T>` with `isSuccess`, `data`, `error`. No exceptions leak to callers.

### DNA-SCOPE: Isolation
- Public groups: visible to all users in same scopeId (tenant)
- Private groups: visible only to members
- All queries filter by scopeId automatically
- Admin role: can see all groups in scope

### DNA-FREEDOM: Dynamic Configuration
| What | How |
|------|-----|
| Group types | Stored in `group-config`, admin adds/removes types |
| Roles & permissions | Named roles with capability string lists, fully dynamic |
| Join policies | Per-group `joinPolicy` field: open/approval/invite |
| Content policies | Per-group `contentTypes` array, admin-configurable |
| Auto-join rules | Pattern matching user fields → group assignment |
| Capacity limits | Per-group `capacity` field, enforced at join time |

### DNA-7: Event-Driven
**Publishes:**
1. `GroupCreated` — new group created
2. `GroupUpdated` — group settings/policies changed
3. `GroupDeleted` — group removed
4. `MemberJoined` — user joined group (any method)
5. `MemberLeft` — user left or was removed
6. `MemberRoleChanged` — role promotion/demotion
7. `MemberSuspended` — member suspended by moderator
8. `MemberBanned` — member permanently banned

**Subscribes to:**
1. `UserRegistered` → evaluate auto-join rules
2. `ConnectionAccepted` → suggest groups of connected user

---

## Core Operations

### 1. Group Lifecycle
| Method | Description |
|--------|-------------|
| `CreateGroupAsync(creatorId, groupData)` | Create group, auto-assign creator as admin |
| `GetGroupByIdAsync(groupId, requesterId)` | Get group (visibility check) |
| `SearchGroupsAsync(filter, page, pageSize)` | Search with BuildSearchFilter |
| `UpdateGroupAsync(groupId, updates, updaterId)` | Update fields (admin only) |
| `DeleteGroupAsync(groupId, deleterId)` | Soft-delete (admin/creator only) |

### 2. Membership Management
| Method | Description |
|--------|-------------|
| `JoinGroupAsync(groupId, userId)` | Join based on policy (auto/pending/denied) |
| `LeaveGroupAsync(groupId, userId)` | User voluntarily leaves |
| `InviteMemberAsync(groupId, inviterId, inviteeId)` | Invite user (requires invite permission) |
| `AcceptInviteAsync(membershipId, userId)` | Accept invitation |
| `ApproveMemberAsync(membershipId, approverId)` | Approve pending request (moderator+) |
| `RejectMemberAsync(membershipId, rejecterId)` | Reject pending request |
| `RemoveMemberAsync(groupId, userId, removerId)` | Kick member (moderator+) |
| `GetMembersAsync(groupId, page, pageSize, role?)` | List members with pagination |
| `GetUserGroupsAsync(userId, page, pageSize)` | List groups user belongs to |

### 3. Role & Permission Management
| Method | Description |
|--------|-------------|
| `ChangeRoleAsync(groupId, userId, newRole, changerId)` | Promote/demote (admin only) |
| `HasPermissionAsync(groupId, userId, permission)` | Check if user has capability |
| `GetRolePermissionsAsync(groupId, role)` | Get permissions for role |

### 4. Policy Enforcement
| Method | Description |
|--------|-------------|
| `CanPostAsync(groupId, userId, contentType)` | Check content policy + permission |
| `GetGroupPoliciesAsync(groupId)` | Get current policies |
| `UpdatePoliciesAsync(groupId, policies, updaterId)` | Update policies (admin only) |

### 5. Discovery & Auto-Join
| Method | Description |
|--------|-------------|
| `DiscoverGroupsAsync(userId, limit)` | Suggest groups based on connections + interests |
| `EvaluateAutoJoinAsync(userId, userProfile)` | Match user to auto-join rules |
| `GetSharedGroupsAsync(userA, userB)` | Groups both users belong to (for connection strength) |

---

## Membership State Machine

```
  ┌──────────┐    accept     ┌────────┐
  │ INVITED  │──────────────►│ ACTIVE │◄─────────┐
  └──────────┘               └────┬───┘          │
                                  │            unsuspend
  ┌──────────┐    approve    ┌────┴───┐          │
  │ PENDING  │──────────────►│        │    ┌─────┴─────┐
  └──────────┘               │        │    │ SUSPENDED │
       │                     │ ACTIVE │───►│           │
       │ reject              │        │    └─────┬─────┘
       ▼                     └────┬───┘          │
  ┌──────────┐                    │              │ ban
  │ REJECTED │               leave│remove        ▼
  └──────────┘                    │         ┌────────┐
                                  ▼         │ BANNED │
                             ┌────────┐     └────────┘
                             │  LEFT  │
                             └────────┘
```

Valid transitions:
- `INVITED → ACTIVE` (user accepts)
- `INVITED → REJECTED` (user declines)
- `PENDING → ACTIVE` (moderator approves)
- `PENDING → REJECTED` (moderator rejects)
- `ACTIVE → LEFT` (user leaves or is removed)
- `ACTIVE → SUSPENDED` (moderator suspends)
- `SUSPENDED → ACTIVE` (moderator unsuspends)
- `SUSPENDED → BANNED` (moderator bans)
- Open join: user goes directly to `ACTIVE` (no PENDING state)

---

## Anti-Patterns (Do NOT)

```csharp
// ❌ WRONG: Typed Group model
public class Group {
    public string Name { get; set; }
    public GroupType Type { get; set; }  // Enum locks types
    public int MaxMembers { get; set; }
}

// ✅ CORRECT: Dynamic document
var group = new Dictionary<string, object> {
    ["name"] = "Tech Entrepreneurs",
    ["type"] = "professional",  // String, admin-defined
    ["capacity"] = 500,
    ["policies"] = new Dictionary<string, object> {
        ["joinPolicy"] = "approval"
    }
};
```

```csharp
// ❌ WRONG: Hardcoded roles
if (role == "admin" || role == "moderator") { ... }

// ✅ CORRECT: Permission-based check
var perms = GetRolePermissions(groupId, userRole);
if (perms.Contains("delete")) { ... }
```

---

## Test Scenarios

**Happy Path:**
1. Create group → creator becomes admin → verify group doc + membership doc
2. User requests to join (approval policy) → moderator approves → status becomes ACTIVE
3. Admin invites user → user accepts → membership created with default role

**Edge Cases:**
- Join group at capacity → DataProcessResult.failure("Group is at capacity")
- Non-member tries to post → HasPermission returns false
- Last admin tries to leave → Reject with "Transfer admin role first"
- Banned user tries to rejoin → Reject
- Auto-join on registration → User matched to 3 groups automatically

**Performance:**
- Group with 10K+ members → paginated member listing <1s
- Search across 100K groups → BuildSearchFilter with pagination <2s
- GetSharedGroups for connection strength → <500ms

---

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/groups` | Create group |
| GET | `/api/groups/:id` | Get group details |
| GET | `/api/groups` | Search groups (query params) |
| PUT | `/api/groups/:id` | Update group (admin) |
| DELETE | `/api/groups/:id` | Delete group (admin) |
| POST | `/api/groups/:id/join` | Request to join |
| POST | `/api/groups/:id/leave` | Leave group |
| POST | `/api/groups/:id/invite` | Invite member |
| POST | `/api/groups/:id/members/:mid/approve` | Approve pending |
| POST | `/api/groups/:id/members/:mid/reject` | Reject pending |
| DELETE | `/api/groups/:id/members/:uid` | Remove member |
| PUT | `/api/groups/:id/members/:uid/role` | Change role |
| GET | `/api/groups/:id/members` | List members |
| GET | `/api/users/:uid/groups` | User's groups |
| PUT | `/api/groups/:id/policies` | Update policies |
| GET | `/api/groups/discover` | Discover groups |
| GET | `/api/groups/shared/:userA/:userB` | Shared groups |
| POST | `/api/groups/:id/members/:uid/suspend` | Suspend member |
| POST | `/api/groups/:id/members/:uid/ban` | Ban member |
