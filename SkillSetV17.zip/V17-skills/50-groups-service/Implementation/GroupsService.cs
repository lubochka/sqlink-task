// Skill 50: Groups Service — .NET 9 Implementation
// DNA-compliant community management with dynamic documents
// Dependencies: Skill 01 (Core Interfaces), Skill 03 (Elasticsearch), Skill 04 (Redis Queue)

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Groups;

// ─── Configuration ───────────────────────────────────────────────

public class GroupsConfig
{
    public string GroupsIndex { get; set; } = "groups";
    public string MembersIndex { get; set; } = "group-members";
    public string ConfigIndex { get; set; } = "group-config";
    public int DefaultPageSize { get; set; } = 20;
    public int MaxGroupsPerUser { get; set; } = 50;
    public int DefaultCapacity { get; set; } = 500;
    public string DefaultJoinPolicy { get; set; } = "approval";
}

// ─── Membership Status Constants ─────────────────────────────────

public static class MemberStatus
{
    public const string Invited = "invited";
    public const string Pending = "pending";
    public const string Active = "active";
    public const string Suspended = "suspended";
    public const string Banned = "banned";
    public const string Left = "left";
    public const string Rejected = "rejected";

    private static readonly Dictionary<string, HashSet<string>> ValidTransitions = new()
    {
        [Invited]   = new() { Active, Rejected },
        [Pending]   = new() { Active, Rejected },
        [Active]    = new() { Left, Suspended },
        [Suspended] = new() { Active, Banned },
    };

    public static bool CanTransition(string from, string to)
        => ValidTransitions.TryGetValue(from, out var targets) && targets.Contains(to);
}

// ─── Default Role Permissions ────────────────────────────────────

public static class DefaultRoles
{
    public static readonly Dictionary<string, List<string>> Permissions = new()
    {
        ["admin"] = new() { "read", "post", "comment", "delete", "ban", "suspend",
                            "invite", "approve", "editGroup", "manageRoles", "managePolicies" },
        ["moderator"] = new() { "read", "post", "comment", "delete", "invite", "approve", "suspend" },
        ["member"] = new() { "read", "post", "comment" },
    };
}

// ─── Pagination Result ───────────────────────────────────────────

public record PagedResult(
    List<Dictionary<string, object>> Items,
    int Total,
    int Page,
    int PageSize,
    int TotalPages
);

// ─── Groups Service ──────────────────────────────────────────────

public class GroupsService
{
    private readonly IDatabaseService _db;
    private readonly IQueueService _queue;
    private readonly ILogger<GroupsService> _logger;
    private readonly GroupsConfig _config;

    public GroupsService(
        IDatabaseService db,
        IQueueService queue,
        ILogger<GroupsService> logger,
        GroupsConfig? config = null)
    {
        _db = db;
        _queue = queue;
        _logger = logger;
        _config = config ?? new GroupsConfig();
    }

    // ══════════════════════════════════════════════════════════════
    // 1. GROUP LIFECYCLE
    // ══════════════════════════════════════════════════════════════

    public async Task<DataProcessResult<Dictionary<string, object>>> CreateGroupAsync(
        string creatorId,
        Dictionary<string, object> groupData,
        CancellationToken ct = default)
    {
        try
        {
            // Check user group limit
            var userGroupsFilter = new Dictionary<string, object>
            {
                ["userId"] = creatorId,
                ["status"] = MemberStatus.Active
            };
            var existingMemberships = await _db.SearchDocumentsAsync(
                _config.MembersIndex, userGroupsFilter, ct);
            if (existingMemberships.Count >= _config.MaxGroupsPerUser)
                return DataProcessResult<Dictionary<string, object>>.Failure(
                    $"User has reached maximum of {_config.MaxGroupsPerUser} groups");

            var groupId = $"grp_{Guid.NewGuid():N}";
            var now = DateTime.UtcNow.ToString("o");

            var group = new Dictionary<string, object>(groupData)
            {
                ["groupId"] = groupId,
                ["createdBy"] = creatorId,
                ["memberCount"] = 1,
                ["status"] = "active",
                ["createdAt"] = now,
                ["updatedAt"] = now
            };

            // Apply defaults if not provided
            group.TryAdd("type", "general");
            group.TryAdd("visibility", "public");
            group.TryAdd("capacity", _config.DefaultCapacity);

            if (!group.ContainsKey("policies"))
            {
                group["policies"] = new Dictionary<string, object>
                {
                    ["joinPolicy"] = _config.DefaultJoinPolicy,
                    ["contentTypes"] = new List<string> { "discussion", "event", "resource" },
                    ["allowAttachments"] = true,
                    ["moderationLevel"] = "standard"
                };
            }

            await _db.SaveDocumentAsync(_config.GroupsIndex, group, ct);

            // Auto-create admin membership for creator
            var adminMembership = new Dictionary<string, object>
            {
                ["membershipId"] = $"mbr_{Guid.NewGuid():N}",
                ["groupId"] = groupId,
                ["userId"] = creatorId,
                ["role"] = "admin",
                ["permissions"] = DefaultRoles.Permissions["admin"],
                ["status"] = MemberStatus.Active,
                ["joinedAt"] = now,
                ["metadata"] = new Dictionary<string, object> { ["joinSource"] = "creator" }
            };
            await _db.SaveDocumentAsync(_config.MembersIndex, adminMembership, ct);

            await PublishEventAsync("GroupCreated", group, ct);

            _logger.LogInformation("Group {GroupId} created by {UserId}", groupId, creatorId);
            return DataProcessResult<Dictionary<string, object>>.Success(group);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "CreateGroup failed for user {UserId}", creatorId);
            return DataProcessResult<Dictionary<string, object>>.Failure(
                $"CreateGroup failed: {ex.Message}");
        }
    }

    public async Task<DataProcessResult<Dictionary<string, object>>> GetGroupByIdAsync(
        string groupId,
        string requesterId,
        CancellationToken ct = default)
    {
        try
        {
            var group = await _db.GetDocumentAsync(_config.GroupsIndex, groupId, ct);
            if (group == null)
                return DataProcessResult<Dictionary<string, object>>.Failure("Group not found");

            var visibility = group.GetValueOrDefault("visibility")?.ToString() ?? "public";
            if (visibility == "private")
            {
                var isMember = await IsMemberAsync(groupId, requesterId, ct);
                if (!isMember.Data)
                    return DataProcessResult<Dictionary<string, object>>.Failure(
                        "Private group — membership required");
            }

            return DataProcessResult<Dictionary<string, object>>.Success(group);
        }
        catch (Exception ex)
        {
            return DataProcessResult<Dictionary<string, object>>.Failure(
                $"GetGroupById failed: {ex.Message}");
        }
    }

    public async Task<DataProcessResult<PagedResult>> SearchGroupsAsync(
        Dictionary<string, object> filter,
        int page = 0,
        int pageSize = 0,
        CancellationToken ct = default)
    {
        try
        {
            var size = pageSize > 0 ? pageSize : _config.DefaultPageSize;

            // DNA-2: BuildSearchFilter — only non-empty values included
            var searchFilter = BuildSearchFilter(filter);
            searchFilter["status"] = "active"; // only active groups

            var all = await _db.SearchDocumentsAsync(_config.GroupsIndex, searchFilter, ct);
            var total = all.Count;
            var items = all.Skip(page * size).Take(size).ToList();

            return DataProcessResult<PagedResult>.Success(new PagedResult(
                items, total, page, size, (int)Math.Ceiling((double)total / size)));
        }
        catch (Exception ex)
        {
            return DataProcessResult<PagedResult>.Failure($"SearchGroups failed: {ex.Message}");
        }
    }

    public async Task<DataProcessResult<Dictionary<string, object>>> UpdateGroupAsync(
        string groupId,
        Dictionary<string, object> updates,
        string updaterId,
        CancellationToken ct = default)
    {
        try
        {
            var permCheck = await HasPermissionAsync(groupId, updaterId, "editGroup", ct);
            if (!permCheck.Data)
                return DataProcessResult<Dictionary<string, object>>.Failure(
                    "Insufficient permissions to edit group");

            var group = await _db.GetDocumentAsync(_config.GroupsIndex, groupId, ct);
            if (group == null)
                return DataProcessResult<Dictionary<string, object>>.Failure("Group not found");

            // Merge updates into existing group
            foreach (var kvp in updates)
            {
                if (kvp.Key is not ("groupId" or "createdBy" or "createdAt"))
                    group[kvp.Key] = kvp.Value;
            }
            group["updatedAt"] = DateTime.UtcNow.ToString("o");

            await _db.SaveDocumentAsync(_config.GroupsIndex, group, ct);
            await PublishEventAsync("GroupUpdated", group, ct);

            return DataProcessResult<Dictionary<string, object>>.Success(group);
        }
        catch (Exception ex)
        {
            return DataProcessResult<Dictionary<string, object>>.Failure(
                $"UpdateGroup failed: {ex.Message}");
        }
    }

    public async Task<DataProcessResult<Dictionary<string, object>>> DeleteGroupAsync(
        string groupId,
        string deleterId,
        CancellationToken ct = default)
    {
        try
        {
            var group = await _db.GetDocumentAsync(_config.GroupsIndex, groupId, ct);
            if (group == null)
                return DataProcessResult<Dictionary<string, object>>.Failure("Group not found");

            var createdBy = group.GetValueOrDefault("createdBy")?.ToString();
            var isAdmin = await HasPermissionAsync(groupId, deleterId, "editGroup", ct);
            if (!isAdmin.Data && createdBy != deleterId)
                return DataProcessResult<Dictionary<string, object>>.Failure(
                    "Only admin or creator can delete group");

            group["status"] = "deleted";
            group["deletedAt"] = DateTime.UtcNow.ToString("o");
            group["deletedBy"] = deleterId;
            await _db.SaveDocumentAsync(_config.GroupsIndex, group, ct);

            await PublishEventAsync("GroupDeleted", group, ct);

            return DataProcessResult<Dictionary<string, object>>.Success(
                new() { ["deleted"] = groupId });
        }
        catch (Exception ex)
        {
            return DataProcessResult<Dictionary<string, object>>.Failure(
                $"DeleteGroup failed: {ex.Message}");
        }
    }

    // ══════════════════════════════════════════════════════════════
    // 2. MEMBERSHIP MANAGEMENT
    // ══════════════════════════════════════════════════════════════

    public async Task<DataProcessResult<Dictionary<string, object>>> JoinGroupAsync(
        string groupId,
        string userId,
        Dictionary<string, object>? metadata = null,
        CancellationToken ct = default)
    {
        try
        {
            var group = await _db.GetDocumentAsync(_config.GroupsIndex, groupId, ct);
            if (group == null)
                return DataProcessResult<Dictionary<string, object>>.Failure("Group not found");

            if (group.GetValueOrDefault("status")?.ToString() != "active")
                return DataProcessResult<Dictionary<string, object>>.Failure("Group is not active");

            // Check if already a member
            var existingResult = await GetMembershipAsync(groupId, userId, ct);
            if (existingResult.IsSuccess)
            {
                var existingStatus = existingResult.Data?.GetValueOrDefault("status")?.ToString();
                if (existingStatus == MemberStatus.Active)
                    return DataProcessResult<Dictionary<string, object>>.Failure("Already a member");
                if (existingStatus == MemberStatus.Banned)
                    return DataProcessResult<Dictionary<string, object>>.Failure("User is banned from this group");
                if (existingStatus == MemberStatus.Pending)
                    return DataProcessResult<Dictionary<string, object>>.Failure("Join request already pending");
            }

            // Check capacity
            var memberCount = Convert.ToInt32(group.GetValueOrDefault("memberCount") ?? 0);
            var capacity = Convert.ToInt32(group.GetValueOrDefault("capacity") ?? _config.DefaultCapacity);
            if (memberCount >= capacity)
                return DataProcessResult<Dictionary<string, object>>.Failure("Group is at capacity");

            // Determine status based on join policy
            var policies = group.GetValueOrDefault("policies") as Dictionary<string, object>;
            var joinPolicy = policies?.GetValueOrDefault("joinPolicy")?.ToString() ?? "approval";

            var status = joinPolicy switch
            {
                "open" => MemberStatus.Active,
                "invite" => throw new InvalidOperationException("Invite-only group — use InviteMember"),
                _ => MemberStatus.Pending // "approval" or default
            };

            var membershipId = $"mbr_{Guid.NewGuid():N}";
            var now = DateTime.UtcNow.ToString("o");

            var membership = new Dictionary<string, object>
            {
                ["membershipId"] = membershipId,
                ["groupId"] = groupId,
                ["userId"] = userId,
                ["role"] = "member",
                ["permissions"] = DefaultRoles.Permissions["member"],
                ["status"] = status,
                ["metadata"] = metadata ?? new Dictionary<string, object>()
            };

            if (status == MemberStatus.Active)
            {
                membership["joinedAt"] = now;
                group["memberCount"] = memberCount + 1;
                group["updatedAt"] = now;
                await _db.SaveDocumentAsync(_config.GroupsIndex, group, ct);
                await PublishEventAsync("MemberJoined", membership, ct);
            }
            else
            {
                membership["requestedAt"] = now;
            }

            await _db.SaveDocumentAsync(_config.MembersIndex, membership, ct);

            return DataProcessResult<Dictionary<string, object>>.Success(membership);
        }
        catch (InvalidOperationException ex)
        {
            return DataProcessResult<Dictionary<string, object>>.Failure(ex.Message);
        }
        catch (Exception ex)
        {
            return DataProcessResult<Dictionary<string, object>>.Failure(
                $"JoinGroup failed: {ex.Message}");
        }
    }

    public async Task<DataProcessResult<Dictionary<string, object>>> LeaveGroupAsync(
        string groupId,
        string userId,
        CancellationToken ct = default)
    {
        try
        {
            var membership = await GetMembershipAsync(groupId, userId, ct);
            if (!membership.IsSuccess)
                return DataProcessResult<Dictionary<string, object>>.Failure("Not a member");

            var doc = membership.Data!;
            var role = doc.GetValueOrDefault("role")?.ToString();

            // Prevent last admin from leaving
            if (role == "admin")
            {
                var adminFilter = new Dictionary<string, object>
                {
                    ["groupId"] = groupId,
                    ["role"] = "admin",
                    ["status"] = MemberStatus.Active
                };
                var admins = await _db.SearchDocumentsAsync(_config.MembersIndex, adminFilter, ct);
                if (admins.Count <= 1)
                    return DataProcessResult<Dictionary<string, object>>.Failure(
                        "Transfer admin role before leaving — you are the last admin");
            }

            if (!MemberStatus.CanTransition(doc.GetValueOrDefault("status")?.ToString() ?? "", MemberStatus.Left))
                return DataProcessResult<Dictionary<string, object>>.Failure("Cannot leave from current status");

            doc["status"] = MemberStatus.Left;
            doc["leftAt"] = DateTime.UtcNow.ToString("o");
            await _db.SaveDocumentAsync(_config.MembersIndex, doc, ct);

            // Decrement member count
            var group = await _db.GetDocumentAsync(_config.GroupsIndex, groupId, ct);
            if (group != null)
            {
                var count = Convert.ToInt32(group.GetValueOrDefault("memberCount") ?? 1);
                group["memberCount"] = Math.Max(0, count - 1);
                group["updatedAt"] = DateTime.UtcNow.ToString("o");
                await _db.SaveDocumentAsync(_config.GroupsIndex, group, ct);
            }

            await PublishEventAsync("MemberLeft", doc, ct);

            return DataProcessResult<Dictionary<string, object>>.Success(doc);
        }
        catch (Exception ex)
        {
            return DataProcessResult<Dictionary<string, object>>.Failure(
                $"LeaveGroup failed: {ex.Message}");
        }
    }

    public async Task<DataProcessResult<Dictionary<string, object>>> InviteMemberAsync(
        string groupId,
        string inviterId,
        string inviteeId,
        CancellationToken ct = default)
    {
        try
        {
            var permCheck = await HasPermissionAsync(groupId, inviterId, "invite", ct);
            if (!permCheck.Data)
                return DataProcessResult<Dictionary<string, object>>.Failure(
                    "Insufficient permissions to invite");

            // Check if already member
            var existing = await GetMembershipAsync(groupId, inviteeId, ct);
            if (existing.IsSuccess)
            {
                var existingStatus = existing.Data?.GetValueOrDefault("status")?.ToString();
                if (existingStatus == MemberStatus.Active)
                    return DataProcessResult<Dictionary<string, object>>.Failure("User is already a member");
                if (existingStatus == MemberStatus.Banned)
                    return DataProcessResult<Dictionary<string, object>>.Failure("User is banned from this group");
            }

            // Check capacity
            var group = await _db.GetDocumentAsync(_config.GroupsIndex, groupId, ct);
            var memberCount = Convert.ToInt32(group?.GetValueOrDefault("memberCount") ?? 0);
            var capacity = Convert.ToInt32(group?.GetValueOrDefault("capacity") ?? _config.DefaultCapacity);
            if (memberCount >= capacity)
                return DataProcessResult<Dictionary<string, object>>.Failure("Group is at capacity");

            var membership = new Dictionary<string, object>
            {
                ["membershipId"] = $"mbr_{Guid.NewGuid():N}",
                ["groupId"] = groupId,
                ["userId"] = inviteeId,
                ["role"] = "member",
                ["permissions"] = DefaultRoles.Permissions["member"],
                ["status"] = MemberStatus.Invited,
                ["invitedBy"] = inviterId,
                ["invitedAt"] = DateTime.UtcNow.ToString("o"),
                ["metadata"] = new Dictionary<string, object> { ["joinSource"] = "invite" }
            };

            await _db.SaveDocumentAsync(_config.MembersIndex, membership, ct);

            return DataProcessResult<Dictionary<string, object>>.Success(membership);
        }
        catch (Exception ex)
        {
            return DataProcessResult<Dictionary<string, object>>.Failure(
                $"InviteMember failed: {ex.Message}");
        }
    }

    public async Task<DataProcessResult<Dictionary<string, object>>> AcceptInviteAsync(
        string membershipId,
        string userId,
        CancellationToken ct = default)
    {
        try
        {
            var doc = await _db.GetDocumentAsync(_config.MembersIndex, membershipId, ct);
            if (doc == null)
                return DataProcessResult<Dictionary<string, object>>.Failure("Membership not found");
            if (doc.GetValueOrDefault("userId")?.ToString() != userId)
                return DataProcessResult<Dictionary<string, object>>.Failure("Not your invitation");

            var currentStatus = doc.GetValueOrDefault("status")?.ToString() ?? "";
            if (!MemberStatus.CanTransition(currentStatus, MemberStatus.Active))
                return DataProcessResult<Dictionary<string, object>>.Failure(
                    $"Cannot accept from '{currentStatus}' status");

            doc["status"] = MemberStatus.Active;
            doc["joinedAt"] = DateTime.UtcNow.ToString("o");
            await _db.SaveDocumentAsync(_config.MembersIndex, doc, ct);

            // Increment member count
            var groupId = doc.GetValueOrDefault("groupId")?.ToString() ?? "";
            await IncrementMemberCountAsync(groupId, 1, ct);

            await PublishEventAsync("MemberJoined", doc, ct);

            return DataProcessResult<Dictionary<string, object>>.Success(doc);
        }
        catch (Exception ex)
        {
            return DataProcessResult<Dictionary<string, object>>.Failure(
                $"AcceptInvite failed: {ex.Message}");
        }
    }

    public async Task<DataProcessResult<Dictionary<string, object>>> ApproveMemberAsync(
        string membershipId,
        string approverId,
        CancellationToken ct = default)
    {
        try
        {
            var doc = await _db.GetDocumentAsync(_config.MembersIndex, membershipId, ct);
            if (doc == null)
                return DataProcessResult<Dictionary<string, object>>.Failure("Membership not found");

            var groupId = doc.GetValueOrDefault("groupId")?.ToString() ?? "";
            var permCheck = await HasPermissionAsync(groupId, approverId, "approve", ct);
            if (!permCheck.Data)
                return DataProcessResult<Dictionary<string, object>>.Failure(
                    "Insufficient permissions to approve");

            var currentStatus = doc.GetValueOrDefault("status")?.ToString() ?? "";
            if (currentStatus != MemberStatus.Pending)
                return DataProcessResult<Dictionary<string, object>>.Failure(
                    $"Can only approve pending requests, current: '{currentStatus}'");

            doc["status"] = MemberStatus.Active;
            doc["approvedBy"] = approverId;
            doc["joinedAt"] = DateTime.UtcNow.ToString("o");
            await _db.SaveDocumentAsync(_config.MembersIndex, doc, ct);

            await IncrementMemberCountAsync(groupId, 1, ct);
            await PublishEventAsync("MemberJoined", doc, ct);

            return DataProcessResult<Dictionary<string, object>>.Success(doc);
        }
        catch (Exception ex)
        {
            return DataProcessResult<Dictionary<string, object>>.Failure(
                $"ApproveMember failed: {ex.Message}");
        }
    }

    public async Task<DataProcessResult<Dictionary<string, object>>> RejectMemberAsync(
        string membershipId,
        string rejecterId,
        CancellationToken ct = default)
    {
        try
        {
            var doc = await _db.GetDocumentAsync(_config.MembersIndex, membershipId, ct);
            if (doc == null)
                return DataProcessResult<Dictionary<string, object>>.Failure("Membership not found");

            var groupId = doc.GetValueOrDefault("groupId")?.ToString() ?? "";
            var permCheck = await HasPermissionAsync(groupId, rejecterId, "approve", ct);
            if (!permCheck.Data)
                return DataProcessResult<Dictionary<string, object>>.Failure(
                    "Insufficient permissions to reject");

            var currentStatus = doc.GetValueOrDefault("status")?.ToString() ?? "";
            if (!MemberStatus.CanTransition(currentStatus, MemberStatus.Rejected))
                return DataProcessResult<Dictionary<string, object>>.Failure(
                    $"Cannot reject from '{currentStatus}' status");

            doc["status"] = MemberStatus.Rejected;
            doc["rejectedBy"] = rejecterId;
            doc["rejectedAt"] = DateTime.UtcNow.ToString("o");
            await _db.SaveDocumentAsync(_config.MembersIndex, doc, ct);

            return DataProcessResult<Dictionary<string, object>>.Success(doc);
        }
        catch (Exception ex)
        {
            return DataProcessResult<Dictionary<string, object>>.Failure(
                $"RejectMember failed: {ex.Message}");
        }
    }

    public async Task<DataProcessResult<Dictionary<string, object>>> RemoveMemberAsync(
        string groupId,
        string userId,
        string removerId,
        CancellationToken ct = default)
    {
        try
        {
            var permCheck = await HasPermissionAsync(groupId, removerId, "delete", ct);
            if (!permCheck.Data)
                return DataProcessResult<Dictionary<string, object>>.Failure(
                    "Insufficient permissions to remove member");

            var membership = await GetMembershipAsync(groupId, userId, ct);
            if (!membership.IsSuccess)
                return DataProcessResult<Dictionary<string, object>>.Failure("User is not a member");

            var doc = membership.Data!;
            doc["status"] = MemberStatus.Left;
            doc["removedBy"] = removerId;
            doc["leftAt"] = DateTime.UtcNow.ToString("o");
            await _db.SaveDocumentAsync(_config.MembersIndex, doc, ct);

            await IncrementMemberCountAsync(groupId, -1, ct);
            await PublishEventAsync("MemberLeft", doc, ct);

            return DataProcessResult<Dictionary<string, object>>.Success(doc);
        }
        catch (Exception ex)
        {
            return DataProcessResult<Dictionary<string, object>>.Failure(
                $"RemoveMember failed: {ex.Message}");
        }
    }

    public async Task<DataProcessResult<Dictionary<string, object>>> SuspendMemberAsync(
        string groupId,
        string userId,
        string suspenderId,
        string? reason = null,
        CancellationToken ct = default)
    {
        try
        {
            var permCheck = await HasPermissionAsync(groupId, suspenderId, "suspend", ct);
            if (!permCheck.Data)
                return DataProcessResult<Dictionary<string, object>>.Failure(
                    "Insufficient permissions to suspend");

            var membership = await GetMembershipAsync(groupId, userId, ct);
            if (!membership.IsSuccess)
                return DataProcessResult<Dictionary<string, object>>.Failure("User is not a member");

            var doc = membership.Data!;
            if (!MemberStatus.CanTransition(
                doc.GetValueOrDefault("status")?.ToString() ?? "", MemberStatus.Suspended))
                return DataProcessResult<Dictionary<string, object>>.Failure("Cannot suspend from current status");

            doc["status"] = MemberStatus.Suspended;
            doc["suspendedBy"] = suspenderId;
            doc["suspendedAt"] = DateTime.UtcNow.ToString("o");
            if (reason != null) doc["suspendReason"] = reason;

            await _db.SaveDocumentAsync(_config.MembersIndex, doc, ct);
            await PublishEventAsync("MemberSuspended", doc, ct);

            return DataProcessResult<Dictionary<string, object>>.Success(doc);
        }
        catch (Exception ex)
        {
            return DataProcessResult<Dictionary<string, object>>.Failure(
                $"SuspendMember failed: {ex.Message}");
        }
    }

    public async Task<DataProcessResult<Dictionary<string, object>>> BanMemberAsync(
        string groupId,
        string userId,
        string bannerId,
        string? reason = null,
        CancellationToken ct = default)
    {
        try
        {
            var permCheck = await HasPermissionAsync(groupId, bannerId, "ban", ct);
            if (!permCheck.Data)
                return DataProcessResult<Dictionary<string, object>>.Failure(
                    "Insufficient permissions to ban");

            var membership = await GetMembershipAsync(groupId, userId, ct);
            if (!membership.IsSuccess)
                return DataProcessResult<Dictionary<string, object>>.Failure("User is not a member");

            var doc = membership.Data!;
            if (!MemberStatus.CanTransition(
                doc.GetValueOrDefault("status")?.ToString() ?? "", MemberStatus.Banned))
                return DataProcessResult<Dictionary<string, object>>.Failure(
                    "Cannot ban from current status — suspend first if active");

            doc["status"] = MemberStatus.Banned;
            doc["bannedBy"] = bannerId;
            doc["bannedAt"] = DateTime.UtcNow.ToString("o");
            if (reason != null) doc["banReason"] = reason;

            await _db.SaveDocumentAsync(_config.MembersIndex, doc, ct);
            await IncrementMemberCountAsync(groupId, -1, ct);
            await PublishEventAsync("MemberBanned", doc, ct);

            return DataProcessResult<Dictionary<string, object>>.Success(doc);
        }
        catch (Exception ex)
        {
            return DataProcessResult<Dictionary<string, object>>.Failure(
                $"BanMember failed: {ex.Message}");
        }
    }

    public async Task<DataProcessResult<PagedResult>> GetMembersAsync(
        string groupId,
        int page = 0,
        int pageSize = 0,
        string? role = null,
        CancellationToken ct = default)
    {
        try
        {
            var size = pageSize > 0 ? pageSize : _config.DefaultPageSize;
            var filter = new Dictionary<string, object>
            {
                ["groupId"] = groupId,
                ["status"] = MemberStatus.Active
            };
            if (!string.IsNullOrEmpty(role)) filter["role"] = role;

            var all = await _db.SearchDocumentsAsync(_config.MembersIndex, filter, ct);
            var total = all.Count;
            var items = all.Skip(page * size).Take(size).ToList();

            return DataProcessResult<PagedResult>.Success(
                new PagedResult(items, total, page, size, (int)Math.Ceiling((double)total / size)));
        }
        catch (Exception ex)
        {
            return DataProcessResult<PagedResult>.Failure($"GetMembers failed: {ex.Message}");
        }
    }

    public async Task<DataProcessResult<PagedResult>> GetUserGroupsAsync(
        string userId,
        int page = 0,
        int pageSize = 0,
        CancellationToken ct = default)
    {
        try
        {
            var size = pageSize > 0 ? pageSize : _config.DefaultPageSize;
            var filter = new Dictionary<string, object>
            {
                ["userId"] = userId,
                ["status"] = MemberStatus.Active
            };

            var memberships = await _db.SearchDocumentsAsync(_config.MembersIndex, filter, ct);

            // Enrich with group details
            var enriched = new List<Dictionary<string, object>>();
            foreach (var m in memberships)
            {
                var gId = m.GetValueOrDefault("groupId")?.ToString();
                if (gId != null)
                {
                    var group = await _db.GetDocumentAsync(_config.GroupsIndex, gId, ct);
                    if (group != null)
                    {
                        var item = new Dictionary<string, object>(m)
                        {
                            ["groupName"] = group.GetValueOrDefault("name") ?? "",
                            ["groupType"] = group.GetValueOrDefault("type") ?? ""
                        };
                        enriched.Add(item);
                    }
                }
            }

            var total = enriched.Count;
            var items = enriched.Skip(page * size).Take(size).ToList();

            return DataProcessResult<PagedResult>.Success(
                new PagedResult(items, total, page, size, (int)Math.Ceiling((double)total / size)));
        }
        catch (Exception ex)
        {
            return DataProcessResult<PagedResult>.Failure($"GetUserGroups failed: {ex.Message}");
        }
    }

    // ══════════════════════════════════════════════════════════════
    // 3. ROLE & PERMISSION MANAGEMENT
    // ══════════════════════════════════════════════════════════════

    public async Task<DataProcessResult<Dictionary<string, object>>> ChangeRoleAsync(
        string groupId,
        string userId,
        string newRole,
        string changerId,
        CancellationToken ct = default)
    {
        try
        {
            var permCheck = await HasPermissionAsync(groupId, changerId, "manageRoles", ct);
            if (!permCheck.Data)
                return DataProcessResult<Dictionary<string, object>>.Failure(
                    "Insufficient permissions to change roles");

            var membership = await GetMembershipAsync(groupId, userId, ct);
            if (!membership.IsSuccess)
                return DataProcessResult<Dictionary<string, object>>.Failure("User is not a member");

            var doc = membership.Data!;
            var oldRole = doc.GetValueOrDefault("role")?.ToString();
            var permissions = await GetRolePermissionsInternalAsync(groupId, newRole, ct);

            doc["role"] = newRole;
            doc["permissions"] = permissions;
            doc["roleChangedBy"] = changerId;
            doc["roleChangedAt"] = DateTime.UtcNow.ToString("o");

            await _db.SaveDocumentAsync(_config.MembersIndex, doc, ct);

            await PublishEventAsync("MemberRoleChanged", new Dictionary<string, object>
            {
                ["groupId"] = groupId,
                ["userId"] = userId,
                ["oldRole"] = oldRole ?? "",
                ["newRole"] = newRole,
                ["changedBy"] = changerId
            }, ct);

            return DataProcessResult<Dictionary<string, object>>.Success(doc);
        }
        catch (Exception ex)
        {
            return DataProcessResult<Dictionary<string, object>>.Failure(
                $"ChangeRole failed: {ex.Message}");
        }
    }

    public async Task<DataProcessResult<bool>> HasPermissionAsync(
        string groupId,
        string userId,
        string permission,
        CancellationToken ct = default)
    {
        try
        {
            var membership = await GetMembershipAsync(groupId, userId, ct);
            if (!membership.IsSuccess)
                return DataProcessResult<bool>.Success(false);

            var doc = membership.Data!;
            if (doc.GetValueOrDefault("status")?.ToString() != MemberStatus.Active)
                return DataProcessResult<bool>.Success(false);

            var permissions = doc.GetValueOrDefault("permissions") as IEnumerable<object>;
            var permList = permissions?.Select(p => p.ToString()).ToList() ?? new List<string?>();
            return DataProcessResult<bool>.Success(permList.Contains(permission));
        }
        catch (Exception ex)
        {
            return DataProcessResult<bool>.Failure($"HasPermission failed: {ex.Message}");
        }
    }

    // ══════════════════════════════════════════════════════════════
    // 4. POLICY ENFORCEMENT
    // ══════════════════════════════════════════════════════════════

    public async Task<DataProcessResult<bool>> CanPostAsync(
        string groupId,
        string userId,
        string contentType,
        CancellationToken ct = default)
    {
        try
        {
            // Check membership + post permission
            var permCheck = await HasPermissionAsync(groupId, userId, "post", ct);
            if (!permCheck.Data)
                return DataProcessResult<bool>.Success(false);

            // Check content type against group policy
            var group = await _db.GetDocumentAsync(_config.GroupsIndex, groupId, ct);
            if (group == null)
                return DataProcessResult<bool>.Success(false);

            var policies = group.GetValueOrDefault("policies") as Dictionary<string, object>;
            var allowedTypes = policies?.GetValueOrDefault("contentTypes") as IEnumerable<object>;
            if (allowedTypes == null)
                return DataProcessResult<bool>.Success(true); // No policy = allow all

            var typeList = allowedTypes.Select(t => t.ToString()).ToList();
            return DataProcessResult<bool>.Success(typeList.Contains(contentType));
        }
        catch (Exception ex)
        {
            return DataProcessResult<bool>.Failure($"CanPost failed: {ex.Message}");
        }
    }

    public async Task<DataProcessResult<Dictionary<string, object>>> UpdatePoliciesAsync(
        string groupId,
        Dictionary<string, object> policies,
        string updaterId,
        CancellationToken ct = default)
    {
        try
        {
            var permCheck = await HasPermissionAsync(groupId, updaterId, "managePolicies", ct);
            if (!permCheck.Data)
                return DataProcessResult<Dictionary<string, object>>.Failure(
                    "Insufficient permissions to manage policies");

            var group = await _db.GetDocumentAsync(_config.GroupsIndex, groupId, ct);
            if (group == null)
                return DataProcessResult<Dictionary<string, object>>.Failure("Group not found");

            group["policies"] = policies;
            group["updatedAt"] = DateTime.UtcNow.ToString("o");
            await _db.SaveDocumentAsync(_config.GroupsIndex, group, ct);

            await PublishEventAsync("GroupUpdated", group, ct);

            return DataProcessResult<Dictionary<string, object>>.Success(group);
        }
        catch (Exception ex)
        {
            return DataProcessResult<Dictionary<string, object>>.Failure(
                $"UpdatePolicies failed: {ex.Message}");
        }
    }

    // ══════════════════════════════════════════════════════════════
    // 5. DISCOVERY & AUTO-JOIN
    // ══════════════════════════════════════════════════════════════

    public async Task<DataProcessResult<List<Dictionary<string, object>>>> DiscoverGroupsAsync(
        string userId,
        int limit = 10,
        CancellationToken ct = default)
    {
        try
        {
            // Get user's current groups
            var userFilter = new Dictionary<string, object>
            {
                ["userId"] = userId,
                ["status"] = MemberStatus.Active
            };
            var userMemberships = await _db.SearchDocumentsAsync(_config.MembersIndex, userFilter, ct);
            var userGroupIds = userMemberships
                .Select(m => m.GetValueOrDefault("groupId")?.ToString())
                .Where(id => id != null)
                .ToHashSet();

            // Get all active public groups
            var groupFilter = new Dictionary<string, object>
            {
                ["status"] = "active",
                ["visibility"] = "public"
            };
            var allGroups = await _db.SearchDocumentsAsync(_config.GroupsIndex, groupFilter, ct);

            // Filter out groups user is already in, sort by member count (popularity)
            var suggestions = allGroups
                .Where(g => !userGroupIds.Contains(g.GetValueOrDefault("groupId")?.ToString()))
                .OrderByDescending(g => Convert.ToInt32(g.GetValueOrDefault("memberCount") ?? 0))
                .Take(limit)
                .ToList();

            return DataProcessResult<List<Dictionary<string, object>>>.Success(suggestions);
        }
        catch (Exception ex)
        {
            return DataProcessResult<List<Dictionary<string, object>>>.Failure(
                $"DiscoverGroups failed: {ex.Message}");
        }
    }

    public async Task<DataProcessResult<List<Dictionary<string, object>>>> EvaluateAutoJoinAsync(
        string userId,
        Dictionary<string, object> userProfile,
        CancellationToken ct = default)
    {
        try
        {
            // Load auto-join rules from config
            var configFilter = new Dictionary<string, object>();
            var configs = await _db.SearchDocumentsAsync(_config.ConfigIndex, configFilter, ct);
            var config = configs.FirstOrDefault();
            if (config == null)
                return DataProcessResult<List<Dictionary<string, object>>>.Success(new());

            var rules = config.GetValueOrDefault("autoJoinRules") as IEnumerable<object>;
            if (rules == null)
                return DataProcessResult<List<Dictionary<string, object>>>.Success(new());

            var joined = new List<Dictionary<string, object>>();

            foreach (var ruleObj in rules)
            {
                if (ruleObj is not Dictionary<string, object> rule) continue;

                var matchField = rule.GetValueOrDefault("matchField")?.ToString();
                var matchValue = rule.GetValueOrDefault("matchValue")?.ToString();
                var targetGroupId = rule.GetValueOrDefault("targetGroupId")?.ToString();

                if (matchField == null || matchValue == null || targetGroupId == null) continue;

                // Check if user profile matches rule
                var profileValue = userProfile.GetValueOrDefault(matchField);
                bool matches = profileValue switch
                {
                    string s => s.Contains(matchValue, StringComparison.OrdinalIgnoreCase),
                    IEnumerable<object> list => list.Any(i =>
                        i.ToString()?.Contains(matchValue, StringComparison.OrdinalIgnoreCase) == true),
                    _ => false
                };

                if (matches)
                {
                    var metadata = new Dictionary<string, object>
                    {
                        ["joinSource"] = "auto-join",
                        ["ruleId"] = rule.GetValueOrDefault("ruleId") ?? ""
                    };
                    var result = await JoinGroupAsync(targetGroupId, userId, metadata, ct);
                    if (result.IsSuccess)
                        joined.Add(result.Data!);
                }
            }

            _logger.LogInformation("Auto-join evaluated for user {UserId}: {Count} groups joined",
                userId, joined.Count);

            return DataProcessResult<List<Dictionary<string, object>>>.Success(joined);
        }
        catch (Exception ex)
        {
            return DataProcessResult<List<Dictionary<string, object>>>.Failure(
                $"EvaluateAutoJoin failed: {ex.Message}");
        }
    }

    public async Task<DataProcessResult<List<string>>> GetSharedGroupsAsync(
        string userA,
        string userB,
        CancellationToken ct = default)
    {
        try
        {
            var filterA = new Dictionary<string, object>
            {
                ["userId"] = userA,
                ["status"] = MemberStatus.Active
            };
            var filterB = new Dictionary<string, object>
            {
                ["userId"] = userB,
                ["status"] = MemberStatus.Active
            };

            var groupsA = await _db.SearchDocumentsAsync(_config.MembersIndex, filterA, ct);
            var groupsB = await _db.SearchDocumentsAsync(_config.MembersIndex, filterB, ct);

            var idsA = groupsA
                .Select(m => m.GetValueOrDefault("groupId")?.ToString())
                .Where(id => id != null)
                .ToHashSet();

            var idsB = groupsB
                .Select(m => m.GetValueOrDefault("groupId")?.ToString())
                .Where(id => id != null)
                .ToList();

            var shared = idsB.Where(id => idsA.Contains(id)).ToList()!;

            return DataProcessResult<List<string>>.Success(shared!);
        }
        catch (Exception ex)
        {
            return DataProcessResult<List<string>>.Failure(
                $"GetSharedGroups failed: {ex.Message}");
        }
    }

    // ══════════════════════════════════════════════════════════════
    // PRIVATE HELPERS
    // ══════════════════════════════════════════════════════════════

    private async Task<DataProcessResult<Dictionary<string, object>>> GetMembershipAsync(
        string groupId,
        string userId,
        CancellationToken ct)
    {
        var filter = new Dictionary<string, object>
        {
            ["groupId"] = groupId,
            ["userId"] = userId
        };
        var docs = await _db.SearchDocumentsAsync(_config.MembersIndex, filter, ct);
        var active = docs
            .Where(d => d.GetValueOrDefault("status")?.ToString() is
                MemberStatus.Active or MemberStatus.Suspended or MemberStatus.Invited or MemberStatus.Pending)
            .OrderByDescending(d => d.GetValueOrDefault("joinedAt")?.ToString())
            .FirstOrDefault();

        if (active != null)
            return DataProcessResult<Dictionary<string, object>>.Success(active);

        // Check for banned status
        var banned = docs.FirstOrDefault(d =>
            d.GetValueOrDefault("status")?.ToString() == MemberStatus.Banned);
        if (banned != null)
            return DataProcessResult<Dictionary<string, object>>.Success(banned);

        return DataProcessResult<Dictionary<string, object>>.Failure("Not a member");
    }

    private async Task<DataProcessResult<bool>> IsMemberAsync(
        string groupId,
        string userId,
        CancellationToken ct)
    {
        var result = await GetMembershipAsync(groupId, userId, ct);
        return DataProcessResult<bool>.Success(
            result.IsSuccess && result.Data?.GetValueOrDefault("status")?.ToString() == MemberStatus.Active);
    }

    private async Task<List<string>> GetRolePermissionsInternalAsync(
        string groupId,
        string role,
        CancellationToken ct)
    {
        // Try group-specific config first, fall back to defaults
        if (DefaultRoles.Permissions.TryGetValue(role, out var defaults))
            return defaults;
        return new List<string> { "read" }; // Fallback: read-only
    }

    private async Task IncrementMemberCountAsync(string groupId, int delta, CancellationToken ct)
    {
        var group = await _db.GetDocumentAsync(_config.GroupsIndex, groupId, ct);
        if (group != null)
        {
            var count = Convert.ToInt32(group.GetValueOrDefault("memberCount") ?? 0);
            group["memberCount"] = Math.Max(0, count + delta);
            group["updatedAt"] = DateTime.UtcNow.ToString("o");
            await _db.SaveDocumentAsync(_config.GroupsIndex, group, ct);
        }
    }

    private static Dictionary<string, object> BuildSearchFilter(Dictionary<string, object> input)
    {
        var filter = new Dictionary<string, object>();
        foreach (var kvp in input)
        {
            if (kvp.Value == null) continue;
            if (kvp.Value is string s && string.IsNullOrEmpty(s)) continue;
            filter[kvp.Key] = kvp.Value;
        }
        return filter;
    }

    private async Task PublishEventAsync(
        string eventType,
        Dictionary<string, object> payload,
        CancellationToken ct)
    {
        try
        {
            await _queue.PublishAsync("group.events", new Dictionary<string, object>
            {
                ["type"] = eventType,
                ["payload"] = payload,
                ["timestamp"] = DateTime.UtcNow.ToString("o")
            }, ct);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to publish event {EventType}", eventType);
        }
    }
}

// ─── DI Registration ─────────────────────────────────────────────

public static class GroupsServiceExtensions
{
    public static IServiceCollection AddXIIGenGroupsService(
        this IServiceCollection services,
        Action<GroupsConfig>? configure = null)
    {
        var config = new GroupsConfig();
        configure?.Invoke(config);
        services.AddSingleton(config);
        services.AddScoped<GroupsService>();
        return services;
    }
}
