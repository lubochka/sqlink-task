/**
 * Skill 50: Groups Service — Java Implementation
 * DNA-compliant community management with dynamic documents
 *
 * Dependencies: Skill 01 (IDatabaseService, IQueueService, DataProcessResult)
 * Requires: Java 21+
 */

package com.xiigen.groups;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

// ─── Interfaces (from Skill 01) ─────────────────────────────────

interface IDatabaseService {
    void saveDocument(String index, Map<String, Object> doc);
    Map<String, Object> getDocument(String index, String id);
    List<Map<String, Object>> searchDocuments(String index, Map<String, Object> filter);
    void deleteDocument(String index, String id);
}

interface IQueueService {
    void publish(String channel, Map<String, Object> message);
}

// ─── DataProcessResult ──────────────────────────────────────────

class DataProcessResult<T> {
    private final boolean isSuccess;
    private final T data;
    private final String error;

    private DataProcessResult(boolean isSuccess, T data, String error) {
        this.isSuccess = isSuccess;
        this.data = data;
        this.error = error;
    }

    public static <T> DataProcessResult<T> success(T data) {
        return new DataProcessResult<>(true, data, null);
    }

    public static <T> DataProcessResult<T> failure(String error) {
        return new DataProcessResult<>(false, null, error);
    }

    public boolean isSuccess() { return isSuccess; }
    public T getData() { return data; }
    public String getError() { return error; }
}

// ─── Configuration ───────────────────────────────────────────────

class GroupsConfig {
    String groupsIndex = "groups";
    String membersIndex = "group-members";
    String configIndex = "group-config";
    int defaultPageSize = 20;
    int maxGroupsPerUser = 50;
    int defaultCapacity = 500;
    String defaultJoinPolicy = "approval";
}

// ─── Constants ───────────────────────────────────────────────────

class MemberStatus {
    static final String INVITED = "invited";
    static final String PENDING = "pending";
    static final String ACTIVE = "active";
    static final String SUSPENDED = "suspended";
    static final String BANNED = "banned";
    static final String LEFT = "left";
    static final String REJECTED = "rejected";

    private static final Map<String, Set<String>> VALID_TRANSITIONS = Map.of(
        INVITED, Set.of(ACTIVE, REJECTED),
        PENDING, Set.of(ACTIVE, REJECTED),
        ACTIVE, Set.of(LEFT, SUSPENDED),
        SUSPENDED, Set.of(ACTIVE, BANNED)
    );

    static boolean canTransition(String from, String to) {
        Set<String> targets = VALID_TRANSITIONS.get(from);
        return targets != null && targets.contains(to);
    }
}

class DefaultRoles {
    static final Map<String, List<String>> PERMISSIONS = Map.of(
        "admin", List.of("read", "post", "comment", "delete", "ban", "suspend",
                         "invite", "approve", "editGroup", "manageRoles", "managePolicies"),
        "moderator", List.of("read", "post", "comment", "delete", "invite", "approve", "suspend"),
        "member", List.of("read", "post", "comment")
    );
}

// ─── Paged Result ────────────────────────────────────────────────

record PagedResult(
    List<Map<String, Object>> items,
    int total,
    int page,
    int pageSize,
    int totalPages
) {}

// ─── Groups Service ──────────────────────────────────────────────

public class GroupsService {
    private final IDatabaseService db;
    private final IQueueService queue;
    private final GroupsConfig config;

    public GroupsService(IDatabaseService db, IQueueService queue) {
        this(db, queue, new GroupsConfig());
    }

    public GroupsService(IDatabaseService db, IQueueService queue, GroupsConfig config) {
        this.db = db;
        this.queue = queue;
        this.config = config;
    }

    // ── 1. Group Lifecycle ───────────────────────────────────────

    public DataProcessResult<Map<String, Object>> createGroup(
            String creatorId, Map<String, Object> groupData) {
        try {
            var userGroups = db.searchDocuments(config.membersIndex,
                Map.of("userId", creatorId, "status", MemberStatus.ACTIVE));
            if (userGroups.size() >= config.maxGroupsPerUser) {
                return DataProcessResult.failure(
                    "User has reached maximum of " + config.maxGroupsPerUser + " groups");
            }

            String groupId = "grp_" + UUID.randomUUID().toString().replace("-", "");
            String now = Instant.now().toString();

            var group = new HashMap<>(groupData);
            group.put("groupId", groupId);
            group.put("createdBy", creatorId);
            group.put("memberCount", 1);
            group.put("status", "active");
            group.put("createdAt", now);
            group.put("updatedAt", now);
            group.putIfAbsent("type", "general");
            group.putIfAbsent("visibility", "public");
            group.putIfAbsent("capacity", config.defaultCapacity);
            group.putIfAbsent("policies", Map.of(
                "joinPolicy", config.defaultJoinPolicy,
                "contentTypes", List.of("discussion", "event", "resource"),
                "allowAttachments", true,
                "moderationLevel", "standard"
            ));

            db.saveDocument(config.groupsIndex, group);

            var adminMembership = new HashMap<String, Object>();
            adminMembership.put("membershipId", "mbr_" + UUID.randomUUID().toString().replace("-", ""));
            adminMembership.put("groupId", groupId);
            adminMembership.put("userId", creatorId);
            adminMembership.put("role", "admin");
            adminMembership.put("permissions", DefaultRoles.PERMISSIONS.get("admin"));
            adminMembership.put("status", MemberStatus.ACTIVE);
            adminMembership.put("joinedAt", now);
            adminMembership.put("metadata", Map.of("joinSource", "creator"));
            db.saveDocument(config.membersIndex, adminMembership);

            publishEvent("GroupCreated", group);
            return DataProcessResult.success(group);
        } catch (Exception e) {
            return DataProcessResult.failure("CreateGroup failed: " + e.getMessage());
        }
    }

    public DataProcessResult<Map<String, Object>> getGroupById(String groupId, String requesterId) {
        try {
            var group = db.getDocument(config.groupsIndex, groupId);
            if (group == null) return DataProcessResult.failure("Group not found");

            if ("private".equals(getStr(group, "visibility"))) {
                if (!isMember(groupId, requesterId)) {
                    return DataProcessResult.failure("Private group — membership required");
                }
            }
            return DataProcessResult.success(group);
        } catch (Exception e) {
            return DataProcessResult.failure("GetGroupById failed: " + e.getMessage());
        }
    }

    public DataProcessResult<PagedResult> searchGroups(
            Map<String, Object> filter, int page, int pageSize) {
        try {
            int size = pageSize > 0 ? pageSize : config.defaultPageSize;
            var searchFilter = buildSearchFilter(filter);
            searchFilter.put("status", "active");

            var all = db.searchDocuments(config.groupsIndex, searchFilter);
            int total = all.size();
            var items = all.stream().skip((long) page * size).limit(size).collect(Collectors.toList());

            return DataProcessResult.success(new PagedResult(
                items, total, page, size, (int) Math.ceil((double) total / size)));
        } catch (Exception e) {
            return DataProcessResult.failure("SearchGroups failed: " + e.getMessage());
        }
    }

    public DataProcessResult<Map<String, Object>> updateGroup(
            String groupId, Map<String, Object> updates, String updaterId) {
        try {
            var perm = hasPermission(groupId, updaterId, "editGroup");
            if (!perm.getData()) return DataProcessResult.failure("Insufficient permissions");

            var group = db.getDocument(config.groupsIndex, groupId);
            if (group == null) return DataProcessResult.failure("Group not found");

            for (var entry : updates.entrySet()) {
                if (!Set.of("groupId", "createdBy", "createdAt").contains(entry.getKey())) {
                    group.put(entry.getKey(), entry.getValue());
                }
            }
            group.put("updatedAt", Instant.now().toString());

            db.saveDocument(config.groupsIndex, group);
            publishEvent("GroupUpdated", group);
            return DataProcessResult.success(group);
        } catch (Exception e) {
            return DataProcessResult.failure("UpdateGroup failed: " + e.getMessage());
        }
    }

    public DataProcessResult<Map<String, Object>> deleteGroup(String groupId, String deleterId) {
        try {
            var group = db.getDocument(config.groupsIndex, groupId);
            if (group == null) return DataProcessResult.failure("Group not found");

            var isAdmin = hasPermission(groupId, deleterId, "editGroup");
            if (!isAdmin.getData() && !deleterId.equals(getStr(group, "createdBy"))) {
                return DataProcessResult.failure("Only admin or creator can delete group");
            }

            group.put("status", "deleted");
            group.put("deletedAt", Instant.now().toString());
            group.put("deletedBy", deleterId);
            db.saveDocument(config.groupsIndex, group);
            publishEvent("GroupDeleted", group);
            return DataProcessResult.success(Map.of("deleted", groupId));
        } catch (Exception e) {
            return DataProcessResult.failure("DeleteGroup failed: " + e.getMessage());
        }
    }

    // ── 2. Membership Management ─────────────────────────────────

    public DataProcessResult<Map<String, Object>> joinGroup(
            String groupId, String userId, Map<String, Object> metadata) {
        try {
            var group = db.getDocument(config.groupsIndex, groupId);
            if (group == null) return DataProcessResult.failure("Group not found");
            if (!"active".equals(getStr(group, "status")))
                return DataProcessResult.failure("Group is not active");

            var existing = getMembership(groupId, userId);
            if (existing != null) {
                String st = getStr(existing, "status");
                if (MemberStatus.ACTIVE.equals(st)) return DataProcessResult.failure("Already a member");
                if (MemberStatus.BANNED.equals(st)) return DataProcessResult.failure("User is banned");
                if (MemberStatus.PENDING.equals(st)) return DataProcessResult.failure("Request pending");
            }

            int memberCount = getInt(group, "memberCount");
            int capacity = getInt(group, "capacity", config.defaultCapacity);
            if (memberCount >= capacity)
                return DataProcessResult.failure("Group is at capacity");

            @SuppressWarnings("unchecked")
            var policies = (Map<String, Object>) group.getOrDefault("policies", Map.of());
            String joinPolicy = String.valueOf(policies.getOrDefault("joinPolicy", "approval"));

            if ("invite".equals(joinPolicy))
                return DataProcessResult.failure("Invite-only group");

            String status = "open".equals(joinPolicy) ? MemberStatus.ACTIVE : MemberStatus.PENDING;
            String now = Instant.now().toString();

            var membership = new HashMap<String, Object>();
            membership.put("membershipId", "mbr_" + UUID.randomUUID().toString().replace("-", ""));
            membership.put("groupId", groupId);
            membership.put("userId", userId);
            membership.put("role", "member");
            membership.put("permissions", DefaultRoles.PERMISSIONS.get("member"));
            membership.put("status", status);
            membership.put("metadata", metadata != null ? metadata : Map.of());

            if (MemberStatus.ACTIVE.equals(status)) {
                membership.put("joinedAt", now);
                group.put("memberCount", memberCount + 1);
                group.put("updatedAt", now);
                db.saveDocument(config.groupsIndex, group);
                publishEvent("MemberJoined", membership);
            } else {
                membership.put("requestedAt", now);
            }

            db.saveDocument(config.membersIndex, membership);
            return DataProcessResult.success(membership);
        } catch (Exception e) {
            return DataProcessResult.failure("JoinGroup failed: " + e.getMessage());
        }
    }

    public DataProcessResult<Map<String, Object>> leaveGroup(String groupId, String userId) {
        try {
            var membership = getMembership(groupId, userId);
            if (membership == null) return DataProcessResult.failure("Not a member");

            if ("admin".equals(getStr(membership, "role"))) {
                var admins = db.searchDocuments(config.membersIndex,
                    Map.of("groupId", groupId, "role", "admin", "status", MemberStatus.ACTIVE));
                if (admins.size() <= 1) {
                    return DataProcessResult.failure("Transfer admin role first — last admin");
                }
            }

            if (!MemberStatus.canTransition(getStr(membership, "status"), MemberStatus.LEFT)) {
                return DataProcessResult.failure("Cannot leave from current status");
            }

            membership.put("status", MemberStatus.LEFT);
            membership.put("leftAt", Instant.now().toString());
            db.saveDocument(config.membersIndex, membership);
            incrementMemberCount(groupId, -1);
            publishEvent("MemberLeft", membership);
            return DataProcessResult.success(membership);
        } catch (Exception e) {
            return DataProcessResult.failure("LeaveGroup failed: " + e.getMessage());
        }
    }

    public DataProcessResult<Map<String, Object>> inviteMember(
            String groupId, String inviterId, String inviteeId) {
        try {
            var perm = hasPermission(groupId, inviterId, "invite");
            if (!perm.getData()) return DataProcessResult.failure("Insufficient permissions");

            var existing = getMembership(groupId, inviteeId);
            if (existing != null) {
                if (MemberStatus.ACTIVE.equals(getStr(existing, "status")))
                    return DataProcessResult.failure("Already a member");
                if (MemberStatus.BANNED.equals(getStr(existing, "status")))
                    return DataProcessResult.failure("User is banned");
            }

            var group = db.getDocument(config.groupsIndex, groupId);
            if (getInt(group, "memberCount") >= getInt(group, "capacity", config.defaultCapacity)) {
                return DataProcessResult.failure("Group is at capacity");
            }

            var membership = new HashMap<String, Object>();
            membership.put("membershipId", "mbr_" + UUID.randomUUID().toString().replace("-", ""));
            membership.put("groupId", groupId);
            membership.put("userId", inviteeId);
            membership.put("role", "member");
            membership.put("permissions", DefaultRoles.PERMISSIONS.get("member"));
            membership.put("status", MemberStatus.INVITED);
            membership.put("invitedBy", inviterId);
            membership.put("invitedAt", Instant.now().toString());
            membership.put("metadata", Map.of("joinSource", "invite"));
            db.saveDocument(config.membersIndex, membership);

            return DataProcessResult.success(membership);
        } catch (Exception e) {
            return DataProcessResult.failure("InviteMember failed: " + e.getMessage());
        }
    }

    public DataProcessResult<Map<String, Object>> acceptInvite(String membershipId, String userId) {
        try {
            var doc = db.getDocument(config.membersIndex, membershipId);
            if (doc == null) return DataProcessResult.failure("Membership not found");
            if (!userId.equals(getStr(doc, "userId"))) return DataProcessResult.failure("Not your invitation");
            if (!MemberStatus.canTransition(getStr(doc, "status"), MemberStatus.ACTIVE)) {
                return DataProcessResult.failure("Cannot accept from '" + getStr(doc, "status") + "'");
            }

            doc.put("status", MemberStatus.ACTIVE);
            doc.put("joinedAt", Instant.now().toString());
            db.saveDocument(config.membersIndex, doc);
            incrementMemberCount(getStr(doc, "groupId"), 1);
            publishEvent("MemberJoined", doc);
            return DataProcessResult.success(doc);
        } catch (Exception e) {
            return DataProcessResult.failure("AcceptInvite failed: " + e.getMessage());
        }
    }

    public DataProcessResult<Map<String, Object>> approveMember(String membershipId, String approverId) {
        try {
            var doc = db.getDocument(config.membersIndex, membershipId);
            if (doc == null) return DataProcessResult.failure("Membership not found");

            var perm = hasPermission(getStr(doc, "groupId"), approverId, "approve");
            if (!perm.getData()) return DataProcessResult.failure("Insufficient permissions");
            if (!MemberStatus.PENDING.equals(getStr(doc, "status"))) {
                return DataProcessResult.failure("Can only approve pending requests");
            }

            doc.put("status", MemberStatus.ACTIVE);
            doc.put("approvedBy", approverId);
            doc.put("joinedAt", Instant.now().toString());
            db.saveDocument(config.membersIndex, doc);
            incrementMemberCount(getStr(doc, "groupId"), 1);
            publishEvent("MemberJoined", doc);
            return DataProcessResult.success(doc);
        } catch (Exception e) {
            return DataProcessResult.failure("ApproveMember failed: " + e.getMessage());
        }
    }

    public DataProcessResult<Map<String, Object>> removeMember(
            String groupId, String userId, String removerId) {
        try {
            var perm = hasPermission(groupId, removerId, "delete");
            if (!perm.getData()) return DataProcessResult.failure("Insufficient permissions");

            var membership = getMembership(groupId, userId);
            if (membership == null) return DataProcessResult.failure("Not a member");

            membership.put("status", MemberStatus.LEFT);
            membership.put("removedBy", removerId);
            membership.put("leftAt", Instant.now().toString());
            db.saveDocument(config.membersIndex, membership);
            incrementMemberCount(groupId, -1);
            publishEvent("MemberLeft", membership);
            return DataProcessResult.success(membership);
        } catch (Exception e) {
            return DataProcessResult.failure("RemoveMember failed: " + e.getMessage());
        }
    }

    public DataProcessResult<Map<String, Object>> suspendMember(
            String groupId, String userId, String suspenderId, String reason) {
        try {
            var perm = hasPermission(groupId, suspenderId, "suspend");
            if (!perm.getData()) return DataProcessResult.failure("Insufficient permissions");

            var membership = getMembership(groupId, userId);
            if (membership == null) return DataProcessResult.failure("Not a member");
            if (!MemberStatus.canTransition(getStr(membership, "status"), MemberStatus.SUSPENDED)) {
                return DataProcessResult.failure("Cannot suspend from current status");
            }

            membership.put("status", MemberStatus.SUSPENDED);
            membership.put("suspendedBy", suspenderId);
            membership.put("suspendedAt", Instant.now().toString());
            if (reason != null) membership.put("suspendReason", reason);

            db.saveDocument(config.membersIndex, membership);
            publishEvent("MemberSuspended", membership);
            return DataProcessResult.success(membership);
        } catch (Exception e) {
            return DataProcessResult.failure("SuspendMember failed: " + e.getMessage());
        }
    }

    public DataProcessResult<Map<String, Object>> banMember(
            String groupId, String userId, String bannerId, String reason) {
        try {
            var perm = hasPermission(groupId, bannerId, "ban");
            if (!perm.getData()) return DataProcessResult.failure("Insufficient permissions");

            var membership = getMembership(groupId, userId);
            if (membership == null) return DataProcessResult.failure("Not a member");
            if (!MemberStatus.canTransition(getStr(membership, "status"), MemberStatus.BANNED)) {
                return DataProcessResult.failure("Cannot ban — suspend first if active");
            }

            membership.put("status", MemberStatus.BANNED);
            membership.put("bannedBy", bannerId);
            membership.put("bannedAt", Instant.now().toString());
            if (reason != null) membership.put("banReason", reason);

            db.saveDocument(config.membersIndex, membership);
            incrementMemberCount(groupId, -1);
            publishEvent("MemberBanned", membership);
            return DataProcessResult.success(membership);
        } catch (Exception e) {
            return DataProcessResult.failure("BanMember failed: " + e.getMessage());
        }
    }

    public DataProcessResult<PagedResult> getMembers(
            String groupId, int page, int pageSize, String role) {
        try {
            int size = pageSize > 0 ? pageSize : config.defaultPageSize;
            var filter = new HashMap<String, Object>();
            filter.put("groupId", groupId);
            filter.put("status", MemberStatus.ACTIVE);
            if (role != null && !role.isEmpty()) filter.put("role", role);

            var all = db.searchDocuments(config.membersIndex, filter);
            int total = all.size();
            var items = all.stream().skip((long) page * size).limit(size).collect(Collectors.toList());

            return DataProcessResult.success(new PagedResult(
                items, total, page, size, (int) Math.ceil((double) total / size)));
        } catch (Exception e) {
            return DataProcessResult.failure("GetMembers failed: " + e.getMessage());
        }
    }

    // ── 3. Role & Permission ─────────────────────────────────────

    public DataProcessResult<Map<String, Object>> changeRole(
            String groupId, String userId, String newRole, String changerId) {
        try {
            var perm = hasPermission(groupId, changerId, "manageRoles");
            if (!perm.getData()) return DataProcessResult.failure("Insufficient permissions");

            var membership = getMembership(groupId, userId);
            if (membership == null) return DataProcessResult.failure("Not a member");

            String oldRole = getStr(membership, "role");
            membership.put("role", newRole);
            membership.put("permissions", DefaultRoles.PERMISSIONS.getOrDefault(newRole, List.of("read")));
            membership.put("roleChangedBy", changerId);
            membership.put("roleChangedAt", Instant.now().toString());

            db.saveDocument(config.membersIndex, membership);
            publishEvent("MemberRoleChanged", Map.of(
                "groupId", groupId, "userId", userId,
                "oldRole", oldRole, "newRole", newRole, "changedBy", changerId));
            return DataProcessResult.success(membership);
        } catch (Exception e) {
            return DataProcessResult.failure("ChangeRole failed: " + e.getMessage());
        }
    }

    public DataProcessResult<Boolean> hasPermission(String groupId, String userId, String permission) {
        try {
            var membership = getMembership(groupId, userId);
            if (membership == null || !MemberStatus.ACTIVE.equals(getStr(membership, "status"))) {
                return DataProcessResult.success(false);
            }
            @SuppressWarnings("unchecked")
            var perms = (List<String>) membership.getOrDefault("permissions", List.of());
            return DataProcessResult.success(perms.contains(permission));
        } catch (Exception e) {
            return DataProcessResult.failure("HasPermission failed: " + e.getMessage());
        }
    }

    // ── 4. Policy ────────────────────────────────────────────────

    public DataProcessResult<Boolean> canPost(String groupId, String userId, String contentType) {
        try {
            var perm = hasPermission(groupId, userId, "post");
            if (!perm.getData()) return DataProcessResult.success(false);

            var group = db.getDocument(config.groupsIndex, groupId);
            if (group == null) return DataProcessResult.success(false);

            @SuppressWarnings("unchecked")
            var policies = (Map<String, Object>) group.getOrDefault("policies", Map.of());
            @SuppressWarnings("unchecked")
            var types = (List<String>) policies.getOrDefault("contentTypes", List.of());
            if (types.isEmpty()) return DataProcessResult.success(true);
            return DataProcessResult.success(types.contains(contentType));
        } catch (Exception e) {
            return DataProcessResult.failure("CanPost failed: " + e.getMessage());
        }
    }

    // ── 5. Discovery ─────────────────────────────────────────────

    public DataProcessResult<List<String>> getSharedGroups(String userA, String userB) {
        try {
            var memA = db.searchDocuments(config.membersIndex,
                Map.of("userId", userA, "status", MemberStatus.ACTIVE));
            var memB = db.searchDocuments(config.membersIndex,
                Map.of("userId", userB, "status", MemberStatus.ACTIVE));

            var idsA = memA.stream().map(m -> getStr(m, "groupId")).collect(Collectors.toSet());
            var shared = memB.stream()
                .map(m -> getStr(m, "groupId"))
                .filter(idsA::contains)
                .collect(Collectors.toList());

            return DataProcessResult.success(shared);
        } catch (Exception e) {
            return DataProcessResult.failure("GetSharedGroups failed: " + e.getMessage());
        }
    }

    // ── Private Helpers ──────────────────────────────────────────

    private Map<String, Object> getMembership(String groupId, String userId) {
        var docs = db.searchDocuments(config.membersIndex,
            Map.of("groupId", groupId, "userId", userId));

        var activeStatuses = Set.of(MemberStatus.ACTIVE, MemberStatus.SUSPENDED,
                                     MemberStatus.INVITED, MemberStatus.PENDING);
        var active = docs.stream()
            .filter(d -> activeStatuses.contains(getStr(d, "status")))
            .findFirst().orElse(null);
        if (active != null) return new HashMap<>(active);

        return docs.stream()
            .filter(d -> MemberStatus.BANNED.equals(getStr(d, "status")))
            .findFirst().map(HashMap::new).orElse(null);
    }

    private boolean isMember(String groupId, String userId) {
        var m = getMembership(groupId, userId);
        return m != null && MemberStatus.ACTIVE.equals(getStr(m, "status"));
    }

    private void incrementMemberCount(String groupId, int delta) {
        var group = db.getDocument(config.groupsIndex, groupId);
        if (group != null) {
            group.put("memberCount", Math.max(0, getInt(group, "memberCount") + delta));
            group.put("updatedAt", Instant.now().toString());
            db.saveDocument(config.groupsIndex, group);
        }
    }

    private Map<String, Object> buildSearchFilter(Map<String, Object> input) {
        var filter = new HashMap<String, Object>();
        for (var entry : input.entrySet()) {
            if (entry.getValue() != null && !"".equals(entry.getValue())) {
                filter.put(entry.getKey(), entry.getValue());
            }
        }
        return filter;
    }

    private void publishEvent(String eventType, Map<String, Object> payload) {
        try {
            queue.publish("group.events", Map.of(
                "type", eventType,
                "payload", payload,
                "timestamp", Instant.now().toString()
            ));
        } catch (Exception ignored) { }
    }

    private static String getStr(Map<String, Object> map, String key) {
        Object val = map != null ? map.get(key) : null;
        return val != null ? val.toString() : "";
    }

    private static int getInt(Map<String, Object> map, String key) {
        return getInt(map, key, 0);
    }

    private static int getInt(Map<String, Object> map, String key, int defaultVal) {
        Object val = map != null ? map.get(key) : null;
        if (val instanceof Number n) return n.intValue();
        return defaultVal;
    }
}
