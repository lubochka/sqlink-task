/**
 * Skill 50: Groups Service — Node.js/TypeScript Implementation
 * DNA-compliant community management with dynamic documents
 * 
 * Dependencies: Skill 01 (IDatabaseService, IQueueService, DataProcessResult)
 */

import { randomUUID } from 'crypto';

// ─── Interfaces (from Skill 01) ─────────────────────────────────

type Doc = Record<string, any>;

interface IDatabaseService {
  saveDocument(index: string, doc: Doc): Promise<void>;
  getDocument(index: string, id: string): Promise<Doc | null>;
  searchDocuments(index: string, filter: Doc): Promise<Doc[]>;
  deleteDocument(index: string, id: string): Promise<void>;
}

interface IQueueService {
  publish(channel: string, message: Doc): Promise<void>;
}

interface DataProcessResult<T> {
  isSuccess: boolean;
  data?: T;
  error?: string;
}

function success<T>(data: T): DataProcessResult<T> {
  return { isSuccess: true, data };
}

function failure<T>(error: string): DataProcessResult<T> {
  return { isSuccess: false, error };
}

// ─── Configuration ───────────────────────────────────────────────

interface GroupsConfig {
  groupsIndex: string;
  membersIndex: string;
  configIndex: string;
  defaultPageSize: number;
  maxGroupsPerUser: number;
  defaultCapacity: number;
  defaultJoinPolicy: string;
}

const defaultConfig: GroupsConfig = {
  groupsIndex: 'groups',
  membersIndex: 'group-members',
  configIndex: 'group-config',
  defaultPageSize: 20,
  maxGroupsPerUser: 50,
  defaultCapacity: 500,
  defaultJoinPolicy: 'approval',
};

// ─── Constants ───────────────────────────────────────────────────

const MemberStatus = {
  INVITED: 'invited',
  PENDING: 'pending',
  ACTIVE: 'active',
  SUSPENDED: 'suspended',
  BANNED: 'banned',
  LEFT: 'left',
  REJECTED: 'rejected',
} as const;

const VALID_TRANSITIONS: Record<string, Set<string>> = {
  [MemberStatus.INVITED]: new Set([MemberStatus.ACTIVE, MemberStatus.REJECTED]),
  [MemberStatus.PENDING]: new Set([MemberStatus.ACTIVE, MemberStatus.REJECTED]),
  [MemberStatus.ACTIVE]: new Set([MemberStatus.LEFT, MemberStatus.SUSPENDED]),
  [MemberStatus.SUSPENDED]: new Set([MemberStatus.ACTIVE, MemberStatus.BANNED]),
};

function canTransition(from: string, to: string): boolean {
  return VALID_TRANSITIONS[from]?.has(to) ?? false;
}

const DEFAULT_ROLE_PERMISSIONS: Record<string, string[]> = {
  admin: ['read', 'post', 'comment', 'delete', 'ban', 'suspend', 'invite', 'approve', 'editGroup', 'manageRoles', 'managePolicies'],
  moderator: ['read', 'post', 'comment', 'delete', 'invite', 'approve', 'suspend'],
  member: ['read', 'post', 'comment'],
};

// ─── Paged Result ────────────────────────────────────────────────

interface PagedResult {
  items: Doc[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
}

// ─── Groups Service ──────────────────────────────────────────────

export class GroupsService {
  private db: IDatabaseService;
  private queue: IQueueService;
  private config: GroupsConfig;

  constructor(db: IDatabaseService, queue: IQueueService, config?: Partial<GroupsConfig>) {
    this.db = db;
    this.queue = queue;
    this.config = { ...defaultConfig, ...config };
  }

  // ── 1. Group Lifecycle ─────────────────────────────────────────

  async createGroup(creatorId: string, groupData: Doc): Promise<DataProcessResult<Doc>> {
    try {
      const userGroups = await this.db.searchDocuments(this.config.membersIndex, {
        userId: creatorId, status: MemberStatus.ACTIVE,
      });
      if (userGroups.length >= this.config.maxGroupsPerUser) {
        return failure(`User has reached maximum of ${this.config.maxGroupsPerUser} groups`);
      }

      const groupId = `grp_${randomUUID().replace(/-/g, '')}`;
      const now = new Date().toISOString();

      const group: Doc = {
        ...groupData,
        groupId,
        createdBy: creatorId,
        memberCount: 1,
        status: 'active',
        createdAt: now,
        updatedAt: now,
      };
      group.type ??= 'general';
      group.visibility ??= 'public';
      group.capacity ??= this.config.defaultCapacity;
      group.policies ??= {
        joinPolicy: this.config.defaultJoinPolicy,
        contentTypes: ['discussion', 'event', 'resource'],
        allowAttachments: true,
        moderationLevel: 'standard',
      };

      await this.db.saveDocument(this.config.groupsIndex, group);

      const adminMembership: Doc = {
        membershipId: `mbr_${randomUUID().replace(/-/g, '')}`,
        groupId,
        userId: creatorId,
        role: 'admin',
        permissions: DEFAULT_ROLE_PERMISSIONS['admin'],
        status: MemberStatus.ACTIVE,
        joinedAt: now,
        metadata: { joinSource: 'creator' },
      };
      await this.db.saveDocument(this.config.membersIndex, adminMembership);

      await this.publishEvent('GroupCreated', group);
      return success(group);
    } catch (err: any) {
      return failure(`CreateGroup failed: ${err.message}`);
    }
  }

  async getGroupById(groupId: string, requesterId: string): Promise<DataProcessResult<Doc>> {
    try {
      const group = await this.db.getDocument(this.config.groupsIndex, groupId);
      if (!group) return failure('Group not found');

      if (group.visibility === 'private') {
        const isMember = await this.isMember(groupId, requesterId);
        if (!isMember) return failure('Private group — membership required');
      }
      return success(group);
    } catch (err: any) {
      return failure(`GetGroupById failed: ${err.message}`);
    }
  }

  async searchGroups(filter: Doc, page = 0, pageSize = 0): Promise<DataProcessResult<PagedResult>> {
    try {
      const size = pageSize > 0 ? pageSize : this.config.defaultPageSize;
      const searchFilter = this.buildSearchFilter({ ...filter, status: 'active' });
      const all = await this.db.searchDocuments(this.config.groupsIndex, searchFilter);
      const total = all.length;
      const items = all.slice(page * size, (page + 1) * size);
      return success({ items, total, page, pageSize: size, totalPages: Math.ceil(total / size) });
    } catch (err: any) {
      return failure(`SearchGroups failed: ${err.message}`);
    }
  }

  async updateGroup(groupId: string, updates: Doc, updaterId: string): Promise<DataProcessResult<Doc>> {
    try {
      const perm = await this.hasPermission(groupId, updaterId, 'editGroup');
      if (!perm.data) return failure('Insufficient permissions to edit group');

      const group = await this.db.getDocument(this.config.groupsIndex, groupId);
      if (!group) return failure('Group not found');

      for (const [key, value] of Object.entries(updates)) {
        if (!['groupId', 'createdBy', 'createdAt'].includes(key)) {
          group[key] = value;
        }
      }
      group.updatedAt = new Date().toISOString();

      await this.db.saveDocument(this.config.groupsIndex, group);
      await this.publishEvent('GroupUpdated', group);
      return success(group);
    } catch (err: any) {
      return failure(`UpdateGroup failed: ${err.message}`);
    }
  }

  async deleteGroup(groupId: string, deleterId: string): Promise<DataProcessResult<Doc>> {
    try {
      const group = await this.db.getDocument(this.config.groupsIndex, groupId);
      if (!group) return failure('Group not found');

      const isAdmin = await this.hasPermission(groupId, deleterId, 'editGroup');
      if (!isAdmin.data && group.createdBy !== deleterId) {
        return failure('Only admin or creator can delete group');
      }

      group.status = 'deleted';
      group.deletedAt = new Date().toISOString();
      group.deletedBy = deleterId;
      await this.db.saveDocument(this.config.groupsIndex, group);
      await this.publishEvent('GroupDeleted', group);
      return success({ deleted: groupId });
    } catch (err: any) {
      return failure(`DeleteGroup failed: ${err.message}`);
    }
  }

  // ── 2. Membership Management ───────────────────────────────────

  async joinGroup(groupId: string, userId: string, metadata: Doc = {}): Promise<DataProcessResult<Doc>> {
    try {
      const group = await this.db.getDocument(this.config.groupsIndex, groupId);
      if (!group) return failure('Group not found');
      if (group.status !== 'active') return failure('Group is not active');

      const existing = await this.getMembership(groupId, userId);
      if (existing) {
        if (existing.status === MemberStatus.ACTIVE) return failure('Already a member');
        if (existing.status === MemberStatus.BANNED) return failure('User is banned from this group');
        if (existing.status === MemberStatus.PENDING) return failure('Join request already pending');
      }

      const memberCount = group.memberCount ?? 0;
      const capacity = group.capacity ?? this.config.defaultCapacity;
      if (memberCount >= capacity) return failure('Group is at capacity');

      const joinPolicy = group.policies?.joinPolicy ?? 'approval';
      if (joinPolicy === 'invite') return failure('Invite-only group — use invite');

      const status = joinPolicy === 'open' ? MemberStatus.ACTIVE : MemberStatus.PENDING;
      const now = new Date().toISOString();

      const membership: Doc = {
        membershipId: `mbr_${randomUUID().replace(/-/g, '')}`,
        groupId,
        userId,
        role: 'member',
        permissions: DEFAULT_ROLE_PERMISSIONS['member'],
        status,
        metadata,
      };

      if (status === MemberStatus.ACTIVE) {
        membership.joinedAt = now;
        group.memberCount = memberCount + 1;
        group.updatedAt = now;
        await this.db.saveDocument(this.config.groupsIndex, group);
        await this.publishEvent('MemberJoined', membership);
      } else {
        membership.requestedAt = now;
      }

      await this.db.saveDocument(this.config.membersIndex, membership);
      return success(membership);
    } catch (err: any) {
      return failure(`JoinGroup failed: ${err.message}`);
    }
  }

  async leaveGroup(groupId: string, userId: string): Promise<DataProcessResult<Doc>> {
    try {
      const membership = await this.getMembership(groupId, userId);
      if (!membership) return failure('Not a member');

      if (membership.role === 'admin') {
        const admins = await this.db.searchDocuments(this.config.membersIndex, {
          groupId, role: 'admin', status: MemberStatus.ACTIVE,
        });
        if (admins.length <= 1) {
          return failure('Transfer admin role before leaving — you are the last admin');
        }
      }

      if (!canTransition(membership.status, MemberStatus.LEFT)) {
        return failure('Cannot leave from current status');
      }

      membership.status = MemberStatus.LEFT;
      membership.leftAt = new Date().toISOString();
      await this.db.saveDocument(this.config.membersIndex, membership);
      await this.incrementMemberCount(groupId, -1);
      await this.publishEvent('MemberLeft', membership);
      return success(membership);
    } catch (err: any) {
      return failure(`LeaveGroup failed: ${err.message}`);
    }
  }

  async inviteMember(groupId: string, inviterId: string, inviteeId: string): Promise<DataProcessResult<Doc>> {
    try {
      const perm = await this.hasPermission(groupId, inviterId, 'invite');
      if (!perm.data) return failure('Insufficient permissions to invite');

      const existing = await this.getMembership(groupId, inviteeId);
      if (existing?.status === MemberStatus.ACTIVE) return failure('User is already a member');
      if (existing?.status === MemberStatus.BANNED) return failure('User is banned from this group');

      const group = await this.db.getDocument(this.config.groupsIndex, groupId);
      const memberCount = group?.memberCount ?? 0;
      const capacity = group?.capacity ?? this.config.defaultCapacity;
      if (memberCount >= capacity) return failure('Group is at capacity');

      const membership: Doc = {
        membershipId: `mbr_${randomUUID().replace(/-/g, '')}`,
        groupId,
        userId: inviteeId,
        role: 'member',
        permissions: DEFAULT_ROLE_PERMISSIONS['member'],
        status: MemberStatus.INVITED,
        invitedBy: inviterId,
        invitedAt: new Date().toISOString(),
        metadata: { joinSource: 'invite' },
      };

      await this.db.saveDocument(this.config.membersIndex, membership);
      return success(membership);
    } catch (err: any) {
      return failure(`InviteMember failed: ${err.message}`);
    }
  }

  async acceptInvite(membershipId: string, userId: string): Promise<DataProcessResult<Doc>> {
    try {
      const doc = await this.db.getDocument(this.config.membersIndex, membershipId);
      if (!doc) return failure('Membership not found');
      if (doc.userId !== userId) return failure('Not your invitation');
      if (!canTransition(doc.status, MemberStatus.ACTIVE)) {
        return failure(`Cannot accept from '${doc.status}' status`);
      }

      doc.status = MemberStatus.ACTIVE;
      doc.joinedAt = new Date().toISOString();
      await this.db.saveDocument(this.config.membersIndex, doc);
      await this.incrementMemberCount(doc.groupId, 1);
      await this.publishEvent('MemberJoined', doc);
      return success(doc);
    } catch (err: any) {
      return failure(`AcceptInvite failed: ${err.message}`);
    }
  }

  async approveMember(membershipId: string, approverId: string): Promise<DataProcessResult<Doc>> {
    try {
      const doc = await this.db.getDocument(this.config.membersIndex, membershipId);
      if (!doc) return failure('Membership not found');

      const perm = await this.hasPermission(doc.groupId, approverId, 'approve');
      if (!perm.data) return failure('Insufficient permissions to approve');
      if (doc.status !== MemberStatus.PENDING) {
        return failure(`Can only approve pending requests, current: '${doc.status}'`);
      }

      doc.status = MemberStatus.ACTIVE;
      doc.approvedBy = approverId;
      doc.joinedAt = new Date().toISOString();
      await this.db.saveDocument(this.config.membersIndex, doc);
      await this.incrementMemberCount(doc.groupId, 1);
      await this.publishEvent('MemberJoined', doc);
      return success(doc);
    } catch (err: any) {
      return failure(`ApproveMember failed: ${err.message}`);
    }
  }

  async removeMember(groupId: string, userId: string, removerId: string): Promise<DataProcessResult<Doc>> {
    try {
      const perm = await this.hasPermission(groupId, removerId, 'delete');
      if (!perm.data) return failure('Insufficient permissions to remove member');

      const membership = await this.getMembership(groupId, userId);
      if (!membership) return failure('User is not a member');

      membership.status = MemberStatus.LEFT;
      membership.removedBy = removerId;
      membership.leftAt = new Date().toISOString();
      await this.db.saveDocument(this.config.membersIndex, membership);
      await this.incrementMemberCount(groupId, -1);
      await this.publishEvent('MemberLeft', membership);
      return success(membership);
    } catch (err: any) {
      return failure(`RemoveMember failed: ${err.message}`);
    }
  }

  async suspendMember(groupId: string, userId: string, suspenderId: string, reason?: string): Promise<DataProcessResult<Doc>> {
    try {
      const perm = await this.hasPermission(groupId, suspenderId, 'suspend');
      if (!perm.data) return failure('Insufficient permissions to suspend');

      const membership = await this.getMembership(groupId, userId);
      if (!membership) return failure('User is not a member');
      if (!canTransition(membership.status, MemberStatus.SUSPENDED)) {
        return failure('Cannot suspend from current status');
      }

      membership.status = MemberStatus.SUSPENDED;
      membership.suspendedBy = suspenderId;
      membership.suspendedAt = new Date().toISOString();
      if (reason) membership.suspendReason = reason;

      await this.db.saveDocument(this.config.membersIndex, membership);
      await this.publishEvent('MemberSuspended', membership);
      return success(membership);
    } catch (err: any) {
      return failure(`SuspendMember failed: ${err.message}`);
    }
  }

  async banMember(groupId: string, userId: string, bannerId: string, reason?: string): Promise<DataProcessResult<Doc>> {
    try {
      const perm = await this.hasPermission(groupId, bannerId, 'ban');
      if (!perm.data) return failure('Insufficient permissions to ban');

      const membership = await this.getMembership(groupId, userId);
      if (!membership) return failure('User is not a member');
      if (!canTransition(membership.status, MemberStatus.BANNED)) {
        return failure('Cannot ban from current status — suspend first if active');
      }

      membership.status = MemberStatus.BANNED;
      membership.bannedBy = bannerId;
      membership.bannedAt = new Date().toISOString();
      if (reason) membership.banReason = reason;

      await this.db.saveDocument(this.config.membersIndex, membership);
      await this.incrementMemberCount(membership.groupId, -1);
      await this.publishEvent('MemberBanned', membership);
      return success(membership);
    } catch (err: any) {
      return failure(`BanMember failed: ${err.message}`);
    }
  }

  async getMembers(groupId: string, page = 0, pageSize = 0, role?: string): Promise<DataProcessResult<PagedResult>> {
    try {
      const size = pageSize > 0 ? pageSize : this.config.defaultPageSize;
      const filter: Doc = { groupId, status: MemberStatus.ACTIVE };
      if (role) filter.role = role;

      const all = await this.db.searchDocuments(this.config.membersIndex, filter);
      const total = all.length;
      const items = all.slice(page * size, (page + 1) * size);
      return success({ items, total, page, pageSize: size, totalPages: Math.ceil(total / size) });
    } catch (err: any) {
      return failure(`GetMembers failed: ${err.message}`);
    }
  }

  async getUserGroups(userId: string, page = 0, pageSize = 0): Promise<DataProcessResult<PagedResult>> {
    try {
      const size = pageSize > 0 ? pageSize : this.config.defaultPageSize;
      const memberships = await this.db.searchDocuments(this.config.membersIndex, {
        userId, status: MemberStatus.ACTIVE,
      });

      const enriched: Doc[] = [];
      for (const m of memberships) {
        const group = await this.db.getDocument(this.config.groupsIndex, m.groupId);
        if (group) {
          enriched.push({ ...m, groupName: group.name ?? '', groupType: group.type ?? '' });
        }
      }

      const total = enriched.length;
      const items = enriched.slice(page * size, (page + 1) * size);
      return success({ items, total, page, pageSize: size, totalPages: Math.ceil(total / size) });
    } catch (err: any) {
      return failure(`GetUserGroups failed: ${err.message}`);
    }
  }

  // ── 3. Role & Permission ───────────────────────────────────────

  async changeRole(groupId: string, userId: string, newRole: string, changerId: string): Promise<DataProcessResult<Doc>> {
    try {
      const perm = await this.hasPermission(groupId, changerId, 'manageRoles');
      if (!perm.data) return failure('Insufficient permissions to change roles');

      const membership = await this.getMembership(groupId, userId);
      if (!membership) return failure('User is not a member');

      const oldRole = membership.role;
      membership.role = newRole;
      membership.permissions = DEFAULT_ROLE_PERMISSIONS[newRole] ?? ['read'];
      membership.roleChangedBy = changerId;
      membership.roleChangedAt = new Date().toISOString();

      await this.db.saveDocument(this.config.membersIndex, membership);
      await this.publishEvent('MemberRoleChanged', { groupId, userId, oldRole, newRole, changedBy: changerId });
      return success(membership);
    } catch (err: any) {
      return failure(`ChangeRole failed: ${err.message}`);
    }
  }

  async hasPermission(groupId: string, userId: string, permission: string): Promise<DataProcessResult<boolean>> {
    try {
      const membership = await this.getMembership(groupId, userId);
      if (!membership || membership.status !== MemberStatus.ACTIVE) return success(false);
      const perms: string[] = membership.permissions ?? [];
      return success(perms.includes(permission));
    } catch (err: any) {
      return failure(`HasPermission failed: ${err.message}`);
    }
  }

  // ── 4. Policy ──────────────────────────────────────────────────

  async canPost(groupId: string, userId: string, contentType: string): Promise<DataProcessResult<boolean>> {
    try {
      const perm = await this.hasPermission(groupId, userId, 'post');
      if (!perm.data) return success(false);

      const group = await this.db.getDocument(this.config.groupsIndex, groupId);
      if (!group) return success(false);

      const allowedTypes: string[] = group.policies?.contentTypes ?? [];
      if (allowedTypes.length === 0) return success(true);
      return success(allowedTypes.includes(contentType));
    } catch (err: any) {
      return failure(`CanPost failed: ${err.message}`);
    }
  }

  // ── 5. Discovery & Auto-Join ───────────────────────────────────

  async getSharedGroups(userA: string, userB: string): Promise<DataProcessResult<string[]>> {
    try {
      const memA = await this.db.searchDocuments(this.config.membersIndex, { userId: userA, status: MemberStatus.ACTIVE });
      const memB = await this.db.searchDocuments(this.config.membersIndex, { userId: userB, status: MemberStatus.ACTIVE });

      const idsA = new Set(memA.map(m => m.groupId));
      const shared = memB.filter(m => idsA.has(m.groupId)).map(m => m.groupId);
      return success(shared);
    } catch (err: any) {
      return failure(`GetSharedGroups failed: ${err.message}`);
    }
  }

  // ── Private Helpers ────────────────────────────────────────────

  private async getMembership(groupId: string, userId: string): Promise<Doc | null> {
    const docs = await this.db.searchDocuments(this.config.membersIndex, { groupId, userId });
    const active = docs.find(d =>
      [MemberStatus.ACTIVE, MemberStatus.SUSPENDED, MemberStatus.INVITED, MemberStatus.PENDING].includes(d.status));
    return active ?? docs.find(d => d.status === MemberStatus.BANNED) ?? null;
  }

  private async isMember(groupId: string, userId: string): Promise<boolean> {
    const m = await this.getMembership(groupId, userId);
    return m?.status === MemberStatus.ACTIVE;
  }

  private async incrementMemberCount(groupId: string, delta: number): Promise<void> {
    const group = await this.db.getDocument(this.config.groupsIndex, groupId);
    if (group) {
      group.memberCount = Math.max(0, (group.memberCount ?? 0) + delta);
      group.updatedAt = new Date().toISOString();
      await this.db.saveDocument(this.config.groupsIndex, group);
    }
  }

  private buildSearchFilter(input: Doc): Doc {
    const filter: Doc = {};
    for (const [key, value] of Object.entries(input)) {
      if (value == null) continue;
      if (typeof value === 'string' && value === '') continue;
      filter[key] = value;
    }
    return filter;
  }

  private async publishEvent(eventType: string, payload: Doc): Promise<void> {
    try {
      await this.queue.publish('group.events', {
        type: eventType, payload, timestamp: new Date().toISOString(),
      });
    } catch { /* non-fatal */ }
  }
}
