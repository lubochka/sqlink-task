// XIIGen Groups Service — Skill 50 | Rust Alternative
// Community management: groups, membership, roles, policies, auto-join
// Genie DNA: DNA-1 (HashMap<String,Value>), DNA-2 (build_search_filter), DNA-5 (DataProcessResult)

use std::collections::{HashMap, HashSet};
use chrono::Utc;
use serde_json::Value;
use uuid::Uuid;

type Doc = HashMap<String, Value>;

// ─── Configuration ──────────────────────────────────────────────
#[derive(Clone)]
pub struct GroupsConfig {
    pub groups_index: String,
    pub members_index: String,
    pub config_index: String,
    pub default_page_size: usize,
    pub max_groups_per_user: usize,
    pub max_members_per_group: usize,
}

impl Default for GroupsConfig {
    fn default() -> Self {
        Self {
            groups_index: "groups".into(),
            members_index: "group-members".into(),
            config_index: "group-config".into(),
            default_page_size: 20,
            max_groups_per_user: 100,
            max_members_per_group: 10000,
        }
    }
}

// ─── Paged Result ───────────────────────────────────────────────
pub struct PagedResult {
    pub items: Vec<Doc>,
    pub total_count: usize,
    pub page: usize,
    pub page_size: usize,
}

// ─── DataProcessResult (DNA-5) ──────────────────────────────────
pub struct DataProcessResult<T> {
    pub is_success: bool,
    pub data: Option<T>,
    pub error: Option<String>,
}

impl<T> DataProcessResult<T> {
    pub fn success(data: T) -> Self { Self { is_success: true, data: Some(data), error: None } }
    pub fn failure(err: &str) -> Self { Self { is_success: false, data: None, error: Some(err.to_string()) } }
}

// ─── Membership Status FSM (MACHINE) ────────────────────────────
pub mod member_status {
    pub const INVITED: &str = "invited";
    pub const PENDING: &str = "pending";
    pub const ACTIVE: &str = "active";
    pub const LEFT: &str = "left";
    pub const SUSPENDED: &str = "suspended";
    pub const BANNED: &str = "banned";
    pub const REJECTED: &str = "rejected";

    pub fn can_transition(from: &str, to: &str) -> bool {
        matches!((from, to),
            ("invited", "active") | ("invited", "rejected") |
            ("pending", "active") | ("pending", "rejected") |
            ("active", "left") | ("active", "suspended") |
            ("suspended", "active") | ("suspended", "banned"))
    }
}

// ─── Default Roles (MACHINE structure, FREEDOM content) ─────────
pub mod default_roles {
    pub fn admin_permissions() -> Vec<String> {
        vec![
            "read", "post", "comment", "delete", "ban", "suspend",
            "invite", "approve", "editGroup", "manageRoles", "managePolicies",
        ].into_iter().map(String::from).collect()
    }

    pub fn moderator_permissions() -> Vec<String> {
        vec!["read", "post", "comment", "delete", "invite", "approve", "suspend"]
            .into_iter().map(String::from).collect()
    }

    pub fn member_permissions() -> Vec<String> {
        vec!["read", "post", "comment"]
            .into_iter().map(String::from).collect()
    }

    pub fn get_permissions(role: &str) -> Vec<String> {
        match role {
            "admin" => admin_permissions(),
            "moderator" => moderator_permissions(),
            "member" => member_permissions(),
            _ => vec!["read".to_string()],
        }
    }
}

// ─── Database + Queue Traits (Skill 01 interfaces) ─────────────
#[async_trait::async_trait]
pub trait IDatabaseService: Send + Sync {
    async fn save_document(&self, index: &str, doc: &Doc) -> Result<(), String>;
    async fn get_document(&self, index: &str, id: &str) -> Result<Option<Doc>, String>;
    async fn search_documents(&self, index: &str, filter: &Doc) -> Result<Vec<Doc>, String>;
    async fn delete_document(&self, index: &str, id: &str) -> Result<(), String>;
}

#[async_trait::async_trait]
pub trait IQueueService: Send + Sync {
    async fn publish(&self, channel: &str, message: &Doc) -> Result<(), String>;
}

// ─── Helpers ────────────────────────────────────────────────────
fn get_str(doc: &Doc, key: &str) -> String {
    doc.get(key).and_then(|v| v.as_str()).unwrap_or("").to_string()
}

fn get_i64(doc: &Doc, key: &str) -> i64 {
    doc.get(key).and_then(|v| v.as_i64()).unwrap_or(0)
}

fn get_arr_str(doc: &Doc, key: &str) -> Vec<String> {
    doc.get(key)
        .and_then(|v| v.as_array())
        .map(|a| a.iter().filter_map(|v| v.as_str().map(String::from)).collect())
        .unwrap_or_default()
}

fn now_iso() -> String { Utc::now().to_rfc3339() }
fn new_id() -> String { Uuid::new_v4().to_string().replace("-", "") }

// ─── build_search_filter (DNA-2) — skip empty fields ────────────
fn build_search_filter(input: &Doc) -> Doc {
    let mut filter = Doc::new();
    for (k, v) in input {
        match v {
            Value::String(s) if !s.is_empty() => { filter.insert(k.clone(), v.clone()); }
            Value::Number(_) | Value::Bool(_) => { filter.insert(k.clone(), v.clone()); }
            Value::Array(a) if !a.is_empty() => { filter.insert(k.clone(), v.clone()); }
            Value::Object(o) if !o.is_empty() => { filter.insert(k.clone(), v.clone()); }
            _ => {}
        }
    }
    filter
}

// ═════════════════════════════════════════════════════════════════
// ███  GroupsService  ████████████████████████████████████████████
// ═════════════════════════════════════════════════════════════════
pub struct GroupsService {
    db: Box<dyn IDatabaseService>,
    queue: Box<dyn IQueueService>,
    config: GroupsConfig,
}

impl GroupsService {
    pub fn new(db: Box<dyn IDatabaseService>, queue: Box<dyn IQueueService>) -> Self {
        Self { db, queue, config: GroupsConfig::default() }
    }

    pub fn with_config(db: Box<dyn IDatabaseService>, queue: Box<dyn IQueueService>, config: GroupsConfig) -> Self {
        Self { db, queue, config }
    }

    // ─── Group CRUD ─────────────────────────────────────────────

    pub async fn create_group(
        &self, creator_id: &str, name: &str, group_type: &str, extra: Doc,
    ) -> DataProcessResult<Doc> {
        if name.is_empty() { return DataProcessResult::failure("Group name is required"); }

        let group_id = new_id();
        let now = now_iso();

        let mut group: Doc = HashMap::from([
            ("groupId".into(), Value::String(group_id.clone())),
            ("name".into(), Value::String(name.to_string())),
            ("type".into(), Value::String(group_type.to_string())),
            ("createdBy".into(), Value::String(creator_id.to_string())),
            ("visibility".into(), Value::String("public".into())),
            ("joinPolicy".into(), Value::String("open".into())),
            ("memberCount".into(), Value::Number(1.into())),
            ("capacity".into(), Value::Number(self.config.max_members_per_group.into())),
            ("status".into(), Value::String("active".into())),
            ("createdAt".into(), Value::String(now.clone())),
            ("updatedAt".into(), Value::String(now.clone())),
        ]);

        // FREEDOM: merge any extra fields from the business user
        for (k, v) in extra { group.insert(k, v); }

        // Default policies (FREEDOM — can be overridden via extra)
        if !group.contains_key("policies") {
            let policies: Doc = HashMap::from([
                ("joinPolicy".into(), Value::String("open".into())),
                ("contentTypes".into(), Value::Array(vec![
                    Value::String("text".into()), Value::String("image".into()),
                    Value::String("link".into()),
                ])),
            ]);
            group.insert("policies".into(), serde_json::to_value(policies).unwrap());
        }

        if let Err(e) = self.db.save_document(&self.config.groups_index, &group).await {
            return DataProcessResult::failure(&format!("Failed to save group: {e}"));
        }

        // Auto-add creator as admin
        let membership = self.create_membership_doc(&group_id, creator_id, "admin", member_status::ACTIVE);
        let _ = self.db.save_document(&self.config.members_index, &membership).await;

        self.publish_event("GroupCreated", &HashMap::from([
            ("groupId".into(), Value::String(group_id)),
            ("createdBy".into(), Value::String(creator_id.to_string())),
        ])).await;

        DataProcessResult::success(group)
    }

    pub async fn get_group_by_id(&self, group_id: &str, requester_id: &str) -> DataProcessResult<Doc> {
        match self.db.get_document(&self.config.groups_index, group_id).await {
            Ok(Some(group)) => {
                let vis = get_str(&group, "visibility");
                if vis == "private" {
                    if !self.is_member(group_id, requester_id).await {
                        return DataProcessResult::failure("Group is private, membership required");
                    }
                }
                DataProcessResult::success(group)
            }
            Ok(None) => DataProcessResult::failure("Group not found"),
            Err(e) => DataProcessResult::failure(&format!("DB error: {e}")),
        }
    }

    pub async fn search_groups(
        &self, criteria: Doc, page: usize, page_size: Option<usize>,
    ) -> DataProcessResult<PagedResult> {
        let ps = page_size.unwrap_or(self.config.default_page_size);
        let filter = build_search_filter(&criteria);
        match self.db.search_documents(&self.config.groups_index, &filter).await {
            Ok(all) => {
                let total = all.len();
                let start = page * ps;
                let items: Vec<Doc> = all.into_iter().skip(start).take(ps).collect();
                DataProcessResult::success(PagedResult { items, total_count: total, page, page_size: ps })
            }
            Err(e) => DataProcessResult::failure(&format!("Search failed: {e}")),
        }
    }

    pub async fn update_group(
        &self, group_id: &str, updater_id: &str, updates: Doc,
    ) -> DataProcessResult<Doc> {
        if !self.has_permission_check(group_id, updater_id, "editGroup").await {
            return DataProcessResult::failure("Permission denied: editGroup required");
        }
        match self.db.get_document(&self.config.groups_index, group_id).await {
            Ok(Some(mut group)) => {
                // FREEDOM: apply any dynamic updates
                for (k, v) in updates {
                    if k != "groupId" && k != "createdBy" && k != "createdAt" {
                        group.insert(k, v);
                    }
                }
                group.insert("updatedAt".into(), Value::String(now_iso()));
                let _ = self.db.save_document(&self.config.groups_index, &group).await;
                self.publish_event("GroupUpdated", &HashMap::from([
                    ("groupId".into(), Value::String(group_id.to_string())),
                    ("updatedBy".into(), Value::String(updater_id.to_string())),
                ])).await;
                DataProcessResult::success(group)
            }
            Ok(None) => DataProcessResult::failure("Group not found"),
            Err(e) => DataProcessResult::failure(&format!("DB error: {e}")),
        }
    }

    pub async fn delete_group(&self, group_id: &str, deleter_id: &str) -> DataProcessResult<Doc> {
        if !self.has_permission_check(group_id, deleter_id, "editGroup").await {
            return DataProcessResult::failure("Permission denied: editGroup required");
        }
        match self.db.get_document(&self.config.groups_index, group_id).await {
            Ok(Some(group)) => {
                let _ = self.db.delete_document(&self.config.groups_index, group_id).await;
                self.publish_event("GroupDeleted", &HashMap::from([
                    ("groupId".into(), Value::String(group_id.to_string())),
                    ("deletedBy".into(), Value::String(deleter_id.to_string())),
                ])).await;
                DataProcessResult::success(group)
            }
            Ok(None) => DataProcessResult::failure("Group not found"),
            Err(e) => DataProcessResult::failure(&format!("DB error: {e}")),
        }
    }

    // ─── Membership Management ──────────────────────────────────

    pub async fn join_group(
        &self, group_id: &str, user_id: &str, extra: Doc,
    ) -> DataProcessResult<Doc> {
        // Check group exists
        let group = match self.db.get_document(&self.config.groups_index, group_id).await {
            Ok(Some(g)) => g,
            Ok(None) => return DataProcessResult::failure("Group not found"),
            Err(e) => return DataProcessResult::failure(&format!("DB error: {e}")),
        };

        // Check capacity
        let count = get_i64(&group, "memberCount") as usize;
        let capacity = get_i64(&group, "capacity") as usize;
        if count >= capacity {
            return DataProcessResult::failure("Group is at capacity");
        }

        // Check not already a member
        if let Some(existing) = self.get_membership(group_id, user_id).await {
            let status = get_str(&existing, "status");
            if status == member_status::ACTIVE || status == member_status::PENDING
                || status == member_status::INVITED {
                return DataProcessResult::failure("Already a member or has pending request");
            }
            if status == member_status::BANNED {
                return DataProcessResult::failure("User is banned from this group");
            }
        }

        // Determine status based on join policy (FREEDOM)
        let join_policy = get_str(&group, "joinPolicy");
        let status = match join_policy.as_str() {
            "open" => member_status::ACTIVE,
            "approval" => member_status::PENDING,
            "invite" => return DataProcessResult::failure("Group is invite-only"),
            _ => member_status::PENDING,
        };

        let mut membership = self.create_membership_doc(group_id, user_id, "member", status);
        for (k, v) in extra { membership.insert(k, v); }

        if let Err(e) = self.db.save_document(&self.config.members_index, &membership).await {
            return DataProcessResult::failure(&format!("Failed to save membership: {e}"));
        }

        if status == member_status::ACTIVE {
            self.increment_member_count(group_id, 1).await;
            self.publish_event("MemberJoined", &HashMap::from([
                ("groupId".into(), Value::String(group_id.to_string())),
                ("userId".into(), Value::String(user_id.to_string())),
            ])).await;
        }

        DataProcessResult::success(membership)
    }

    pub async fn leave_group(&self, group_id: &str, user_id: &str) -> DataProcessResult<Doc> {
        let membership = match self.get_membership(group_id, user_id).await {
            Some(m) => m,
            None => return DataProcessResult::failure("Not a member of this group"),
        };

        let status = get_str(&membership, "status");
        if status != member_status::ACTIVE {
            return DataProcessResult::failure(&format!("Cannot leave with status: {status}"));
        }

        let role = get_str(&membership, "role");
        if role == "admin" {
            // Check if last admin
            let filter: Doc = HashMap::from([
                ("groupId".into(), Value::String(group_id.to_string())),
                ("role".into(), Value::String("admin".into())),
                ("status".into(), Value::String(member_status::ACTIVE.into())),
            ]);
            if let Ok(admins) = self.db.search_documents(&self.config.members_index, &filter).await {
                if admins.len() <= 1 {
                    return DataProcessResult::failure("Cannot leave: you are the last admin. Transfer role first.");
                }
            }
        }

        if !member_status::can_transition(&status, member_status::LEFT) {
            return DataProcessResult::failure("Invalid status transition");
        }

        let mid = get_str(&membership, "membershipId");
        let mut updated = membership;
        updated.insert("status".into(), Value::String(member_status::LEFT.into()));
        updated.insert("leftAt".into(), Value::String(now_iso()));
        let _ = self.db.save_document(&self.config.members_index, &updated).await;

        self.increment_member_count(group_id, -1).await;
        self.publish_event("MemberLeft", &HashMap::from([
            ("groupId".into(), Value::String(group_id.to_string())),
            ("userId".into(), Value::String(user_id.to_string())),
        ])).await;

        DataProcessResult::success(updated)
    }

    pub async fn invite_member(
        &self, group_id: &str, inviter_id: &str, invitee_id: &str,
    ) -> DataProcessResult<Doc> {
        if !self.has_permission_check(group_id, inviter_id, "invite").await {
            return DataProcessResult::failure("Permission denied: invite required");
        }

        // Check not already a member
        if let Some(existing) = self.get_membership(group_id, invitee_id).await {
            let status = get_str(&existing, "status");
            if status == member_status::ACTIVE || status == member_status::INVITED {
                return DataProcessResult::failure("User is already a member or invited");
            }
            if status == member_status::BANNED {
                return DataProcessResult::failure("User is banned from this group");
            }
        }

        let mut membership = self.create_membership_doc(group_id, invitee_id, "member", member_status::INVITED);
        membership.insert("invitedBy".into(), Value::String(inviter_id.to_string()));

        if let Err(e) = self.db.save_document(&self.config.members_index, &membership).await {
            return DataProcessResult::failure(&format!("Failed to save invite: {e}"));
        }

        DataProcessResult::success(membership)
    }

    pub async fn accept_invite(&self, membership_id: &str, user_id: &str) -> DataProcessResult<Doc> {
        match self.db.get_document(&self.config.members_index, membership_id).await {
            Ok(Some(mut m)) => {
                if get_str(&m, "userId") != user_id {
                    return DataProcessResult::failure("Invite belongs to a different user");
                }
                if get_str(&m, "status") != member_status::INVITED {
                    return DataProcessResult::failure("Not in invited status");
                }
                m.insert("status".into(), Value::String(member_status::ACTIVE.into()));
                m.insert("joinedAt".into(), Value::String(now_iso()));
                let _ = self.db.save_document(&self.config.members_index, &m).await;
                let gid = get_str(&m, "groupId");
                self.increment_member_count(&gid, 1).await;
                self.publish_event("MemberJoined", &HashMap::from([
                    ("groupId".into(), Value::String(gid)),
                    ("userId".into(), Value::String(user_id.to_string())),
                ])).await;
                DataProcessResult::success(m)
            }
            Ok(None) => DataProcessResult::failure("Membership not found"),
            Err(e) => DataProcessResult::failure(&format!("DB error: {e}")),
        }
    }

    pub async fn approve_member(&self, membership_id: &str, approver_id: &str) -> DataProcessResult<Doc> {
        match self.db.get_document(&self.config.members_index, membership_id).await {
            Ok(Some(mut m)) => {
                let gid = get_str(&m, "groupId");
                if !self.has_permission_check(&gid, approver_id, "approve").await {
                    return DataProcessResult::failure("Permission denied: approve required");
                }
                if get_str(&m, "status") != member_status::PENDING {
                    return DataProcessResult::failure("Not in pending status");
                }
                m.insert("status".into(), Value::String(member_status::ACTIVE.into()));
                m.insert("approvedBy".into(), Value::String(approver_id.to_string()));
                m.insert("joinedAt".into(), Value::String(now_iso()));
                let _ = self.db.save_document(&self.config.members_index, &m).await;
                self.increment_member_count(&gid, 1).await;
                self.publish_event("MemberJoined", &HashMap::from([
                    ("groupId".into(), Value::String(gid)),
                    ("userId".into(), Value::String(get_str(&m, "userId"))),
                ])).await;
                DataProcessResult::success(m)
            }
            Ok(None) => DataProcessResult::failure("Membership not found"),
            Err(e) => DataProcessResult::failure(&format!("DB error: {e}")),
        }
    }

    pub async fn reject_member(&self, membership_id: &str, rejector_id: &str) -> DataProcessResult<Doc> {
        match self.db.get_document(&self.config.members_index, membership_id).await {
            Ok(Some(mut m)) => {
                let gid = get_str(&m, "groupId");
                if !self.has_permission_check(&gid, rejector_id, "approve").await {
                    return DataProcessResult::failure("Permission denied");
                }
                let status = get_str(&m, "status");
                if status != member_status::PENDING && status != member_status::INVITED {
                    return DataProcessResult::failure("Not in pending/invited status");
                }
                m.insert("status".into(), Value::String(member_status::REJECTED.into()));
                m.insert("rejectedBy".into(), Value::String(rejector_id.to_string()));
                let _ = self.db.save_document(&self.config.members_index, &m).await;
                DataProcessResult::success(m)
            }
            Ok(None) => DataProcessResult::failure("Membership not found"),
            Err(e) => DataProcessResult::failure(&format!("DB error: {e}")),
        }
    }

    pub async fn remove_member(
        &self, group_id: &str, remover_id: &str, target_id: &str,
    ) -> DataProcessResult<Doc> {
        if !self.has_permission_check(group_id, remover_id, "ban").await {
            return DataProcessResult::failure("Permission denied: ban required for removal");
        }
        let membership = match self.get_membership(group_id, target_id).await {
            Some(m) => m,
            None => return DataProcessResult::failure("Target is not a member"),
        };
        if get_str(&membership, "status") != member_status::ACTIVE {
            return DataProcessResult::failure("Target is not active");
        }
        let mid = get_str(&membership, "membershipId");
        let mut updated = membership;
        updated.insert("status".into(), Value::String(member_status::LEFT.into()));
        updated.insert("removedBy".into(), Value::String(remover_id.to_string()));
        updated.insert("leftAt".into(), Value::String(now_iso()));
        let _ = self.db.save_document(&self.config.members_index, &updated).await;
        self.increment_member_count(group_id, -1).await;
        self.publish_event("MemberLeft", &HashMap::from([
            ("groupId".into(), Value::String(group_id.to_string())),
            ("userId".into(), Value::String(target_id.to_string())),
            ("removedBy".into(), Value::String(remover_id.to_string())),
        ])).await;
        DataProcessResult::success(updated)
    }

    pub async fn suspend_member(
        &self, group_id: &str, suspender_id: &str, target_id: &str, reason: &str,
    ) -> DataProcessResult<Doc> {
        if !self.has_permission_check(group_id, suspender_id, "suspend").await {
            return DataProcessResult::failure("Permission denied: suspend required");
        }
        let membership = match self.get_membership(group_id, target_id).await {
            Some(m) => m,
            None => return DataProcessResult::failure("Target is not a member"),
        };
        if !member_status::can_transition(&get_str(&membership, "status"), member_status::SUSPENDED) {
            return DataProcessResult::failure("Cannot suspend from current status");
        }
        let mut updated = membership;
        updated.insert("status".into(), Value::String(member_status::SUSPENDED.into()));
        updated.insert("suspendedBy".into(), Value::String(suspender_id.to_string()));
        updated.insert("suspendReason".into(), Value::String(reason.to_string()));
        updated.insert("suspendedAt".into(), Value::String(now_iso()));
        let _ = self.db.save_document(&self.config.members_index, &updated).await;
        self.publish_event("MemberSuspended", &HashMap::from([
            ("groupId".into(), Value::String(group_id.to_string())),
            ("userId".into(), Value::String(target_id.to_string())),
        ])).await;
        DataProcessResult::success(updated)
    }

    pub async fn ban_member(
        &self, group_id: &str, banner_id: &str, target_id: &str, reason: &str,
    ) -> DataProcessResult<Doc> {
        if !self.has_permission_check(group_id, banner_id, "ban").await {
            return DataProcessResult::failure("Permission denied: ban required");
        }
        let membership = match self.get_membership(group_id, target_id).await {
            Some(m) => m,
            None => return DataProcessResult::failure("Target is not a member"),
        };
        let status = get_str(&membership, "status");
        if status != member_status::ACTIVE && status != member_status::SUSPENDED {
            return DataProcessResult::failure("Can only ban active or suspended members");
        }
        let mut updated = membership;
        updated.insert("status".into(), Value::String(member_status::BANNED.into()));
        updated.insert("bannedBy".into(), Value::String(banner_id.to_string()));
        updated.insert("banReason".into(), Value::String(reason.to_string()));
        updated.insert("bannedAt".into(), Value::String(now_iso()));
        let _ = self.db.save_document(&self.config.members_index, &updated).await;
        self.increment_member_count(group_id, -1).await;
        self.publish_event("MemberBanned", &HashMap::from([
            ("groupId".into(), Value::String(group_id.to_string())),
            ("userId".into(), Value::String(target_id.to_string())),
        ])).await;
        DataProcessResult::success(updated)
    }

    // ─── Query Members ──────────────────────────────────────────

    pub async fn get_members(
        &self, group_id: &str, requester_id: &str, page: usize, page_size: Option<usize>,
    ) -> DataProcessResult<PagedResult> {
        if !self.is_member(group_id, requester_id).await {
            return DataProcessResult::failure("Must be a member to view members list");
        }
        let ps = page_size.unwrap_or(self.config.default_page_size);
        let filter: Doc = HashMap::from([
            ("groupId".into(), Value::String(group_id.to_string())),
            ("status".into(), Value::String(member_status::ACTIVE.into())),
        ]);
        match self.db.search_documents(&self.config.members_index, &filter).await {
            Ok(all) => {
                let total = all.len();
                let items: Vec<Doc> = all.into_iter().skip(page * ps).take(ps).collect();
                DataProcessResult::success(PagedResult { items, total_count: total, page, page_size: ps })
            }
            Err(e) => DataProcessResult::failure(&format!("Search failed: {e}")),
        }
    }

    pub async fn get_user_groups(
        &self, user_id: &str, page: usize, page_size: Option<usize>,
    ) -> DataProcessResult<PagedResult> {
        let ps = page_size.unwrap_or(self.config.default_page_size);
        let filter: Doc = HashMap::from([
            ("userId".into(), Value::String(user_id.to_string())),
            ("status".into(), Value::String(member_status::ACTIVE.into())),
        ]);
        match self.db.search_documents(&self.config.members_index, &filter).await {
            Ok(memberships) => {
                let total = memberships.len();
                let items: Vec<Doc> = memberships.into_iter().skip(page * ps).take(ps).collect();
                DataProcessResult::success(PagedResult { items, total_count: total, page, page_size: ps })
            }
            Err(e) => DataProcessResult::failure(&format!("Search failed: {e}")),
        }
    }

    // ─── Role & Permission Management ───────────────────────────

    pub async fn change_role(
        &self, group_id: &str, changer_id: &str, target_id: &str, new_role: &str,
    ) -> DataProcessResult<Doc> {
        if !self.has_permission_check(group_id, changer_id, "manageRoles").await {
            return DataProcessResult::failure("Permission denied: manageRoles required");
        }
        let membership = match self.get_membership(group_id, target_id).await {
            Some(m) => m,
            None => return DataProcessResult::failure("Target is not a member"),
        };
        if get_str(&membership, "status") != member_status::ACTIVE {
            return DataProcessResult::failure("Target is not active");
        }

        // Last admin protection
        let old_role = get_str(&membership, "role");
        if old_role == "admin" && new_role != "admin" {
            let filter: Doc = HashMap::from([
                ("groupId".into(), Value::String(group_id.to_string())),
                ("role".into(), Value::String("admin".into())),
                ("status".into(), Value::String(member_status::ACTIVE.into())),
            ]);
            if let Ok(admins) = self.db.search_documents(&self.config.members_index, &filter).await {
                if admins.len() <= 1 {
                    return DataProcessResult::failure("Cannot demote last admin");
                }
            }
        }

        let permissions = default_roles::get_permissions(new_role);
        let mut updated = membership;
        updated.insert("role".into(), Value::String(new_role.to_string()));
        updated.insert("permissions".into(), serde_json::to_value(&permissions).unwrap());
        updated.insert("roleChangedAt".into(), Value::String(now_iso()));
        let _ = self.db.save_document(&self.config.members_index, &updated).await;

        self.publish_event("MemberRoleChanged", &HashMap::from([
            ("groupId".into(), Value::String(group_id.to_string())),
            ("userId".into(), Value::String(target_id.to_string())),
            ("newRole".into(), Value::String(new_role.to_string())),
        ])).await;

        DataProcessResult::success(updated)
    }

    pub async fn has_permission(
        &self, group_id: &str, user_id: &str, permission: &str,
    ) -> DataProcessResult<bool> {
        DataProcessResult::success(self.has_permission_check(group_id, user_id, permission).await)
    }

    pub async fn can_post(
        &self, group_id: &str, user_id: &str, content_type: &str,
    ) -> DataProcessResult<bool> {
        if !self.has_permission_check(group_id, user_id, "post").await {
            return DataProcessResult::success(false);
        }

        // Check content policy (FREEDOM — per-group content types)
        match self.db.get_document(&self.config.groups_index, group_id).await {
            Ok(Some(group)) => {
                if let Some(policies) = group.get("policies") {
                    if let Some(types) = policies.get("contentTypes") {
                        let allowed = get_arr_str(
                            &HashMap::from([("ct".into(), types.clone())]),
                            "ct",
                        );
                        if !allowed.is_empty() && !allowed.contains(&content_type.to_string()) {
                            return DataProcessResult::success(false);
                        }
                    }
                }
                DataProcessResult::success(true)
            }
            _ => DataProcessResult::success(false),
        }
    }

    // ─── Cross-Service Queries ──────────────────────────────────

    pub async fn get_shared_groups(
        &self, user_a: &str, user_b: &str,
    ) -> DataProcessResult<Vec<String>> {
        let filter_a: Doc = HashMap::from([
            ("userId".into(), Value::String(user_a.to_string())),
            ("status".into(), Value::String(member_status::ACTIVE.into())),
        ]);
        let filter_b: Doc = HashMap::from([
            ("userId".into(), Value::String(user_b.to_string())),
            ("status".into(), Value::String(member_status::ACTIVE.into())),
        ]);

        let groups_a = match self.db.search_documents(&self.config.members_index, &filter_a).await {
            Ok(docs) => docs,
            Err(e) => return DataProcessResult::failure(&format!("Search failed: {e}")),
        };
        let groups_b = match self.db.search_documents(&self.config.members_index, &filter_b).await {
            Ok(docs) => docs,
            Err(e) => return DataProcessResult::failure(&format!("Search failed: {e}")),
        };

        let set_a: HashSet<String> = groups_a.iter().map(|d| get_str(d, "groupId")).collect();
        let shared: Vec<String> = groups_b.iter()
            .map(|d| get_str(d, "groupId"))
            .filter(|gid| set_a.contains(gid))
            .collect();

        DataProcessResult::success(shared)
    }

    // ─── Private Helpers ────────────────────────────────────────

    fn create_membership_doc(
        &self, group_id: &str, user_id: &str, role: &str, status: &str,
    ) -> Doc {
        let now = now_iso();
        let permissions = default_roles::get_permissions(role);
        HashMap::from([
            ("membershipId".into(), Value::String(new_id())),
            ("groupId".into(), Value::String(group_id.to_string())),
            ("userId".into(), Value::String(user_id.to_string())),
            ("role".into(), Value::String(role.to_string())),
            ("permissions".into(), serde_json::to_value(&permissions).unwrap()),
            ("status".into(), Value::String(status.to_string())),
            ("joinedAt".into(), Value::String(if status == member_status::ACTIVE { now.clone() } else { "".into() })),
            ("createdAt".into(), Value::String(now.clone())),
            ("updatedAt".into(), Value::String(now)),
        ])
    }

    async fn get_membership(&self, group_id: &str, user_id: &str) -> Option<Doc> {
        let filter: Doc = HashMap::from([
            ("groupId".into(), Value::String(group_id.to_string())),
            ("userId".into(), Value::String(user_id.to_string())),
        ]);
        if let Ok(docs) = self.db.search_documents(&self.config.members_index, &filter).await {
            // Priority: active > suspended > invited > pending > others
            let priority = |s: &str| -> usize {
                match s {
                    "active" => 0, "suspended" => 1, "invited" => 2,
                    "pending" => 3, _ => 4,
                }
            };
            let mut sorted = docs;
            sorted.sort_by(|a, b| {
                priority(&get_str(a, "status")).cmp(&priority(&get_str(b, "status")))
            });
            sorted.into_iter().next()
        } else {
            None
        }
    }

    async fn is_member(&self, group_id: &str, user_id: &str) -> bool {
        if let Some(m) = self.get_membership(group_id, user_id).await {
            let status = get_str(&m, "status");
            status == member_status::ACTIVE || status == member_status::SUSPENDED
        } else {
            false
        }
    }

    async fn has_permission_check(&self, group_id: &str, user_id: &str, permission: &str) -> bool {
        if let Some(m) = self.get_membership(group_id, user_id).await {
            if get_str(&m, "status") != member_status::ACTIVE { return false; }
            let perms = get_arr_str(&m, "permissions");
            perms.contains(&permission.to_string())
        } else {
            false
        }
    }

    async fn increment_member_count(&self, group_id: &str, delta: i64) {
        if let Ok(Some(mut group)) = self.db.get_document(&self.config.groups_index, group_id).await {
            let current = get_i64(&group, "memberCount");
            let new_count = (current + delta).max(0);
            group.insert("memberCount".into(), Value::Number(new_count.into()));
            let _ = self.db.save_document(&self.config.groups_index, &group).await;
        }
    }

    async fn publish_event(&self, event_type: &str, payload: &Doc) {
        let mut event: Doc = HashMap::from([
            ("eventType".into(), Value::String(event_type.to_string())),
            ("timestamp".into(), Value::String(now_iso())),
        ]);
        for (k, v) in payload { event.insert(k.clone(), v.clone()); }
        let _ = self.queue.publish("groups-events", &event).await;
    }
}
