"""
Skill 50: Groups Service — Python Implementation
DNA-compliant community management with dynamic documents

Dependencies: Skill 01 (IDatabaseService, IQueueService, DataProcessResult)
Requires: Python 3.12+
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

Doc = dict[str, Any]


# ─── Interfaces (from Skill 01) ──────────────────────────────────

class IDatabaseService:
    async def save_document(self, index: str, doc: Doc) -> None: ...
    async def get_document(self, index: str, doc_id: str) -> Doc | None: ...
    async def search_documents(self, index: str, filt: Doc) -> list[Doc]: ...
    async def delete_document(self, index: str, doc_id: str) -> None: ...


class IQueueService:
    async def publish(self, channel: str, message: Doc) -> None: ...


@dataclass
class DataProcessResult[T]:
    is_success: bool
    data: T | None = None
    error: str | None = None

    @classmethod
    def success(cls, data: T) -> DataProcessResult[T]:
        return cls(is_success=True, data=data)

    @classmethod
    def failure(cls, error: str) -> DataProcessResult[T]:
        return cls(is_success=False, error=error)


# ─── Configuration ────────────────────────────────────────────────

@dataclass
class GroupsConfig:
    groups_index: str = "groups"
    members_index: str = "group-members"
    config_index: str = "group-config"
    default_page_size: int = 20
    max_groups_per_user: int = 50
    default_capacity: int = 500
    default_join_policy: str = "approval"


# ─── Constants ────────────────────────────────────────────────────

class MemberStatus:
    INVITED = "invited"
    PENDING = "pending"
    ACTIVE = "active"
    SUSPENDED = "suspended"
    BANNED = "banned"
    LEFT = "left"
    REJECTED = "rejected"

    _VALID_TRANSITIONS: dict[str, set[str]] = {
        "invited": {"active", "rejected"},
        "pending": {"active", "rejected"},
        "active": {"left", "suspended"},
        "suspended": {"active", "banned"},
    }

    @classmethod
    def can_transition(cls, from_status: str, to_status: str) -> bool:
        return to_status in cls._VALID_TRANSITIONS.get(from_status, set())


DEFAULT_ROLE_PERMISSIONS: dict[str, list[str]] = {
    "admin": ["read", "post", "comment", "delete", "ban", "suspend",
              "invite", "approve", "editGroup", "manageRoles", "managePolicies"],
    "moderator": ["read", "post", "comment", "delete", "invite", "approve", "suspend"],
    "member": ["read", "post", "comment"],
}


# ─── Groups Service ──────────────────────────────────────────────

class GroupsService:
    def __init__(
        self,
        db: IDatabaseService,
        queue: IQueueService,
        config: GroupsConfig | None = None,
    ):
        self._db = db
        self._queue = queue
        self._config = config or GroupsConfig()

    # ── 1. Group Lifecycle ────────────────────────────────────────

    async def create_group(self, creator_id: str, group_data: Doc) -> DataProcessResult[Doc]:
        try:
            user_groups = await self._db.search_documents(
                self._config.members_index,
                {"userId": creator_id, "status": MemberStatus.ACTIVE},
            )
            if len(user_groups) >= self._config.max_groups_per_user:
                return DataProcessResult.failure(
                    f"User has reached maximum of {self._config.max_groups_per_user} groups"
                )

            group_id = f"grp_{uuid.uuid4().hex}"
            now = datetime.now(timezone.utc).isoformat()

            group: Doc = {
                **group_data,
                "groupId": group_id,
                "createdBy": creator_id,
                "memberCount": 1,
                "status": "active",
                "createdAt": now,
                "updatedAt": now,
            }
            group.setdefault("type", "general")
            group.setdefault("visibility", "public")
            group.setdefault("capacity", self._config.default_capacity)
            group.setdefault("policies", {
                "joinPolicy": self._config.default_join_policy,
                "contentTypes": ["discussion", "event", "resource"],
                "allowAttachments": True,
                "moderationLevel": "standard",
            })

            await self._db.save_document(self._config.groups_index, group)

            admin_membership: Doc = {
                "membershipId": f"mbr_{uuid.uuid4().hex}",
                "groupId": group_id,
                "userId": creator_id,
                "role": "admin",
                "permissions": DEFAULT_ROLE_PERMISSIONS["admin"],
                "status": MemberStatus.ACTIVE,
                "joinedAt": now,
                "metadata": {"joinSource": "creator"},
            }
            await self._db.save_document(self._config.members_index, admin_membership)

            await self._publish_event("GroupCreated", group)
            return DataProcessResult.success(group)
        except Exception as e:
            return DataProcessResult.failure(f"CreateGroup failed: {e}")

    async def get_group_by_id(self, group_id: str, requester_id: str) -> DataProcessResult[Doc]:
        try:
            group = await self._db.get_document(self._config.groups_index, group_id)
            if not group:
                return DataProcessResult.failure("Group not found")

            if group.get("visibility") == "private":
                is_member = await self._is_member(group_id, requester_id)
                if not is_member:
                    return DataProcessResult.failure("Private group — membership required")

            return DataProcessResult.success(group)
        except Exception as e:
            return DataProcessResult.failure(f"GetGroupById failed: {e}")

    async def search_groups(
        self, filt: Doc, page: int = 0, page_size: int = 0
    ) -> DataProcessResult[Doc]:
        try:
            size = page_size if page_size > 0 else self._config.default_page_size
            search_filter = self._build_search_filter({**filt, "status": "active"})
            all_docs = await self._db.search_documents(self._config.groups_index, search_filter)
            total = len(all_docs)
            items = all_docs[page * size : (page + 1) * size]
            return DataProcessResult.success({
                "items": items, "total": total, "page": page,
                "pageSize": size, "totalPages": -(-total // size),
            })
        except Exception as e:
            return DataProcessResult.failure(f"SearchGroups failed: {e}")

    async def update_group(
        self, group_id: str, updates: Doc, updater_id: str
    ) -> DataProcessResult[Doc]:
        try:
            perm = await self.has_permission(group_id, updater_id, "editGroup")
            if not perm.data:
                return DataProcessResult.failure("Insufficient permissions to edit group")

            group = await self._db.get_document(self._config.groups_index, group_id)
            if not group:
                return DataProcessResult.failure("Group not found")

            for key, value in updates.items():
                if key not in ("groupId", "createdBy", "createdAt"):
                    group[key] = value
            group["updatedAt"] = datetime.now(timezone.utc).isoformat()

            await self._db.save_document(self._config.groups_index, group)
            await self._publish_event("GroupUpdated", group)
            return DataProcessResult.success(group)
        except Exception as e:
            return DataProcessResult.failure(f"UpdateGroup failed: {e}")

    async def delete_group(self, group_id: str, deleter_id: str) -> DataProcessResult[Doc]:
        try:
            group = await self._db.get_document(self._config.groups_index, group_id)
            if not group:
                return DataProcessResult.failure("Group not found")

            is_admin = await self.has_permission(group_id, deleter_id, "editGroup")
            if not is_admin.data and group.get("createdBy") != deleter_id:
                return DataProcessResult.failure("Only admin or creator can delete group")

            group["status"] = "deleted"
            group["deletedAt"] = datetime.now(timezone.utc).isoformat()
            group["deletedBy"] = deleter_id
            await self._db.save_document(self._config.groups_index, group)
            await self._publish_event("GroupDeleted", group)
            return DataProcessResult.success({"deleted": group_id})
        except Exception as e:
            return DataProcessResult.failure(f"DeleteGroup failed: {e}")

    # ── 2. Membership Management ──────────────────────────────────

    async def join_group(
        self, group_id: str, user_id: str, metadata: Doc | None = None
    ) -> DataProcessResult[Doc]:
        try:
            group = await self._db.get_document(self._config.groups_index, group_id)
            if not group:
                return DataProcessResult.failure("Group not found")
            if group.get("status") != "active":
                return DataProcessResult.failure("Group is not active")

            existing = await self._get_membership(group_id, user_id)
            if existing:
                st = existing.get("status")
                if st == MemberStatus.ACTIVE:
                    return DataProcessResult.failure("Already a member")
                if st == MemberStatus.BANNED:
                    return DataProcessResult.failure("User is banned from this group")
                if st == MemberStatus.PENDING:
                    return DataProcessResult.failure("Join request already pending")

            member_count = group.get("memberCount", 0)
            capacity = group.get("capacity", self._config.default_capacity)
            if member_count >= capacity:
                return DataProcessResult.failure("Group is at capacity")

            join_policy = (group.get("policies") or {}).get("joinPolicy", "approval")
            if join_policy == "invite":
                return DataProcessResult.failure("Invite-only group — use invite")

            status = MemberStatus.ACTIVE if join_policy == "open" else MemberStatus.PENDING
            now = datetime.now(timezone.utc).isoformat()

            membership: Doc = {
                "membershipId": f"mbr_{uuid.uuid4().hex}",
                "groupId": group_id,
                "userId": user_id,
                "role": "member",
                "permissions": DEFAULT_ROLE_PERMISSIONS["member"],
                "status": status,
                "metadata": metadata or {},
            }

            if status == MemberStatus.ACTIVE:
                membership["joinedAt"] = now
                group["memberCount"] = member_count + 1
                group["updatedAt"] = now
                await self._db.save_document(self._config.groups_index, group)
                await self._publish_event("MemberJoined", membership)
            else:
                membership["requestedAt"] = now

            await self._db.save_document(self._config.members_index, membership)
            return DataProcessResult.success(membership)
        except Exception as e:
            return DataProcessResult.failure(f"JoinGroup failed: {e}")

    async def leave_group(self, group_id: str, user_id: str) -> DataProcessResult[Doc]:
        try:
            membership = await self._get_membership(group_id, user_id)
            if not membership:
                return DataProcessResult.failure("Not a member")

            if membership.get("role") == "admin":
                admins = await self._db.search_documents(
                    self._config.members_index,
                    {"groupId": group_id, "role": "admin", "status": MemberStatus.ACTIVE},
                )
                if len(admins) <= 1:
                    return DataProcessResult.failure(
                        "Transfer admin role before leaving — you are the last admin"
                    )

            if not MemberStatus.can_transition(membership.get("status", ""), MemberStatus.LEFT):
                return DataProcessResult.failure("Cannot leave from current status")

            membership["status"] = MemberStatus.LEFT
            membership["leftAt"] = datetime.now(timezone.utc).isoformat()
            await self._db.save_document(self._config.members_index, membership)
            await self._increment_member_count(group_id, -1)
            await self._publish_event("MemberLeft", membership)
            return DataProcessResult.success(membership)
        except Exception as e:
            return DataProcessResult.failure(f"LeaveGroup failed: {e}")

    async def invite_member(
        self, group_id: str, inviter_id: str, invitee_id: str
    ) -> DataProcessResult[Doc]:
        try:
            perm = await self.has_permission(group_id, inviter_id, "invite")
            if not perm.data:
                return DataProcessResult.failure("Insufficient permissions to invite")

            existing = await self._get_membership(group_id, invitee_id)
            if existing:
                if existing.get("status") == MemberStatus.ACTIVE:
                    return DataProcessResult.failure("User is already a member")
                if existing.get("status") == MemberStatus.BANNED:
                    return DataProcessResult.failure("User is banned from this group")

            group = await self._db.get_document(self._config.groups_index, group_id)
            member_count = (group or {}).get("memberCount", 0)
            capacity = (group or {}).get("capacity", self._config.default_capacity)
            if member_count >= capacity:
                return DataProcessResult.failure("Group is at capacity")

            membership: Doc = {
                "membershipId": f"mbr_{uuid.uuid4().hex}",
                "groupId": group_id,
                "userId": invitee_id,
                "role": "member",
                "permissions": DEFAULT_ROLE_PERMISSIONS["member"],
                "status": MemberStatus.INVITED,
                "invitedBy": inviter_id,
                "invitedAt": datetime.now(timezone.utc).isoformat(),
                "metadata": {"joinSource": "invite"},
            }
            await self._db.save_document(self._config.members_index, membership)
            return DataProcessResult.success(membership)
        except Exception as e:
            return DataProcessResult.failure(f"InviteMember failed: {e}")

    async def accept_invite(self, membership_id: str, user_id: str) -> DataProcessResult[Doc]:
        try:
            doc = await self._db.get_document(self._config.members_index, membership_id)
            if not doc:
                return DataProcessResult.failure("Membership not found")
            if doc.get("userId") != user_id:
                return DataProcessResult.failure("Not your invitation")
            if not MemberStatus.can_transition(doc.get("status", ""), MemberStatus.ACTIVE):
                return DataProcessResult.failure(f"Cannot accept from '{doc.get('status')}' status")

            doc["status"] = MemberStatus.ACTIVE
            doc["joinedAt"] = datetime.now(timezone.utc).isoformat()
            await self._db.save_document(self._config.members_index, doc)
            await self._increment_member_count(doc["groupId"], 1)
            await self._publish_event("MemberJoined", doc)
            return DataProcessResult.success(doc)
        except Exception as e:
            return DataProcessResult.failure(f"AcceptInvite failed: {e}")

    async def approve_member(self, membership_id: str, approver_id: str) -> DataProcessResult[Doc]:
        try:
            doc = await self._db.get_document(self._config.members_index, membership_id)
            if not doc:
                return DataProcessResult.failure("Membership not found")

            perm = await self.has_permission(doc["groupId"], approver_id, "approve")
            if not perm.data:
                return DataProcessResult.failure("Insufficient permissions to approve")
            if doc.get("status") != MemberStatus.PENDING:
                return DataProcessResult.failure(
                    f"Can only approve pending requests, current: '{doc.get('status')}'"
                )

            doc["status"] = MemberStatus.ACTIVE
            doc["approvedBy"] = approver_id
            doc["joinedAt"] = datetime.now(timezone.utc).isoformat()
            await self._db.save_document(self._config.members_index, doc)
            await self._increment_member_count(doc["groupId"], 1)
            await self._publish_event("MemberJoined", doc)
            return DataProcessResult.success(doc)
        except Exception as e:
            return DataProcessResult.failure(f"ApproveMember failed: {e}")

    async def remove_member(
        self, group_id: str, user_id: str, remover_id: str
    ) -> DataProcessResult[Doc]:
        try:
            perm = await self.has_permission(group_id, remover_id, "delete")
            if not perm.data:
                return DataProcessResult.failure("Insufficient permissions to remove member")

            membership = await self._get_membership(group_id, user_id)
            if not membership:
                return DataProcessResult.failure("User is not a member")

            membership["status"] = MemberStatus.LEFT
            membership["removedBy"] = remover_id
            membership["leftAt"] = datetime.now(timezone.utc).isoformat()
            await self._db.save_document(self._config.members_index, membership)
            await self._increment_member_count(group_id, -1)
            await self._publish_event("MemberLeft", membership)
            return DataProcessResult.success(membership)
        except Exception as e:
            return DataProcessResult.failure(f"RemoveMember failed: {e}")

    async def suspend_member(
        self, group_id: str, user_id: str, suspender_id: str, reason: str | None = None
    ) -> DataProcessResult[Doc]:
        try:
            perm = await self.has_permission(group_id, suspender_id, "suspend")
            if not perm.data:
                return DataProcessResult.failure("Insufficient permissions to suspend")

            membership = await self._get_membership(group_id, user_id)
            if not membership:
                return DataProcessResult.failure("User is not a member")
            if not MemberStatus.can_transition(membership.get("status", ""), MemberStatus.SUSPENDED):
                return DataProcessResult.failure("Cannot suspend from current status")

            membership["status"] = MemberStatus.SUSPENDED
            membership["suspendedBy"] = suspender_id
            membership["suspendedAt"] = datetime.now(timezone.utc).isoformat()
            if reason:
                membership["suspendReason"] = reason

            await self._db.save_document(self._config.members_index, membership)
            await self._publish_event("MemberSuspended", membership)
            return DataProcessResult.success(membership)
        except Exception as e:
            return DataProcessResult.failure(f"SuspendMember failed: {e}")

    async def ban_member(
        self, group_id: str, user_id: str, banner_id: str, reason: str | None = None
    ) -> DataProcessResult[Doc]:
        try:
            perm = await self.has_permission(group_id, banner_id, "ban")
            if not perm.data:
                return DataProcessResult.failure("Insufficient permissions to ban")

            membership = await self._get_membership(group_id, user_id)
            if not membership:
                return DataProcessResult.failure("User is not a member")
            if not MemberStatus.can_transition(membership.get("status", ""), MemberStatus.BANNED):
                return DataProcessResult.failure(
                    "Cannot ban from current status — suspend first if active"
                )

            membership["status"] = MemberStatus.BANNED
            membership["bannedBy"] = banner_id
            membership["bannedAt"] = datetime.now(timezone.utc).isoformat()
            if reason:
                membership["banReason"] = reason

            await self._db.save_document(self._config.members_index, membership)
            await self._increment_member_count(group_id, -1)
            await self._publish_event("MemberBanned", membership)
            return DataProcessResult.success(membership)
        except Exception as e:
            return DataProcessResult.failure(f"BanMember failed: {e}")

    async def get_members(
        self, group_id: str, page: int = 0, page_size: int = 0, role: str | None = None
    ) -> DataProcessResult[Doc]:
        try:
            size = page_size if page_size > 0 else self._config.default_page_size
            filt: Doc = {"groupId": group_id, "status": MemberStatus.ACTIVE}
            if role:
                filt["role"] = role

            all_docs = await self._db.search_documents(self._config.members_index, filt)
            total = len(all_docs)
            items = all_docs[page * size : (page + 1) * size]
            return DataProcessResult.success({
                "items": items, "total": total, "page": page,
                "pageSize": size, "totalPages": -(-total // size),
            })
        except Exception as e:
            return DataProcessResult.failure(f"GetMembers failed: {e}")

    async def get_user_groups(
        self, user_id: str, page: int = 0, page_size: int = 0
    ) -> DataProcessResult[Doc]:
        try:
            size = page_size if page_size > 0 else self._config.default_page_size
            memberships = await self._db.search_documents(
                self._config.members_index,
                {"userId": user_id, "status": MemberStatus.ACTIVE},
            )

            enriched: list[Doc] = []
            for m in memberships:
                group = await self._db.get_document(self._config.groups_index, m.get("groupId", ""))
                if group:
                    enriched.append({
                        **m,
                        "groupName": group.get("name", ""),
                        "groupType": group.get("type", ""),
                    })

            total = len(enriched)
            items = enriched[page * size : (page + 1) * size]
            return DataProcessResult.success({
                "items": items, "total": total, "page": page,
                "pageSize": size, "totalPages": -(-total // size),
            })
        except Exception as e:
            return DataProcessResult.failure(f"GetUserGroups failed: {e}")

    # ── 3. Role & Permission ──────────────────────────────────────

    async def change_role(
        self, group_id: str, user_id: str, new_role: str, changer_id: str
    ) -> DataProcessResult[Doc]:
        try:
            perm = await self.has_permission(group_id, changer_id, "manageRoles")
            if not perm.data:
                return DataProcessResult.failure("Insufficient permissions to change roles")

            membership = await self._get_membership(group_id, user_id)
            if not membership:
                return DataProcessResult.failure("User is not a member")

            old_role = membership.get("role")
            membership["role"] = new_role
            membership["permissions"] = DEFAULT_ROLE_PERMISSIONS.get(new_role, ["read"])
            membership["roleChangedBy"] = changer_id
            membership["roleChangedAt"] = datetime.now(timezone.utc).isoformat()

            await self._db.save_document(self._config.members_index, membership)
            await self._publish_event("MemberRoleChanged", {
                "groupId": group_id, "userId": user_id,
                "oldRole": old_role, "newRole": new_role, "changedBy": changer_id,
            })
            return DataProcessResult.success(membership)
        except Exception as e:
            return DataProcessResult.failure(f"ChangeRole failed: {e}")

    async def has_permission(
        self, group_id: str, user_id: str, permission: str
    ) -> DataProcessResult[bool]:
        try:
            membership = await self._get_membership(group_id, user_id)
            if not membership or membership.get("status") != MemberStatus.ACTIVE:
                return DataProcessResult.success(False)
            perms: list[str] = membership.get("permissions", [])
            return DataProcessResult.success(permission in perms)
        except Exception as e:
            return DataProcessResult.failure(f"HasPermission failed: {e}")

    # ── 4. Policy ─────────────────────────────────────────────────

    async def can_post(
        self, group_id: str, user_id: str, content_type: str
    ) -> DataProcessResult[bool]:
        try:
            perm = await self.has_permission(group_id, user_id, "post")
            if not perm.data:
                return DataProcessResult.success(False)

            group = await self._db.get_document(self._config.groups_index, group_id)
            if not group:
                return DataProcessResult.success(False)

            allowed = (group.get("policies") or {}).get("contentTypes", [])
            if not allowed:
                return DataProcessResult.success(True)
            return DataProcessResult.success(content_type in allowed)
        except Exception as e:
            return DataProcessResult.failure(f"CanPost failed: {e}")

    # ── 5. Discovery ──────────────────────────────────────────────

    async def get_shared_groups(self, user_a: str, user_b: str) -> DataProcessResult[list[str]]:
        try:
            mem_a = await self._db.search_documents(
                self._config.members_index, {"userId": user_a, "status": MemberStatus.ACTIVE}
            )
            mem_b = await self._db.search_documents(
                self._config.members_index, {"userId": user_b, "status": MemberStatus.ACTIVE}
            )
            ids_a = {m.get("groupId") for m in mem_a}
            shared = [m["groupId"] for m in mem_b if m.get("groupId") in ids_a]
            return DataProcessResult.success(shared)
        except Exception as e:
            return DataProcessResult.failure(f"GetSharedGroups failed: {e}")

    # ── Private Helpers ───────────────────────────────────────────

    async def _get_membership(self, group_id: str, user_id: str) -> Doc | None:
        docs = await self._db.search_documents(
            self._config.members_index, {"groupId": group_id, "userId": user_id}
        )
        active_statuses = {MemberStatus.ACTIVE, MemberStatus.SUSPENDED,
                          MemberStatus.INVITED, MemberStatus.PENDING}
        active = next((d for d in docs if d.get("status") in active_statuses), None)
        if active:
            return active
        return next((d for d in docs if d.get("status") == MemberStatus.BANNED), None)

    async def _is_member(self, group_id: str, user_id: str) -> bool:
        m = await self._get_membership(group_id, user_id)
        return m is not None and m.get("status") == MemberStatus.ACTIVE

    async def _increment_member_count(self, group_id: str, delta: int) -> None:
        group = await self._db.get_document(self._config.groups_index, group_id)
        if group:
            group["memberCount"] = max(0, group.get("memberCount", 0) + delta)
            group["updatedAt"] = datetime.now(timezone.utc).isoformat()
            await self._db.save_document(self._config.groups_index, group)

    def _build_search_filter(self, inp: Doc) -> Doc:
        return {k: v for k, v in inp.items() if v is not None and v != ""}

    async def _publish_event(self, event_type: str, payload: Doc) -> None:
        try:
            await self._queue.publish("group.events", {
                "type": event_type,
                "payload": payload,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            })
        except Exception:
            pass  # Non-fatal
