<?php
/**
 * Skill 50: Groups Service — PHP Implementation
 * DNA-compliant community/group management with dynamic documents,
 * membership state machine, role-based permissions, and policy enforcement
 *
 * Requires: PHP 8.3+, ext-json
 * Interfaces: IDatabaseService, IQueueService from Skill 01
 */

declare(strict_types=1);

namespace XIIGen\Groups;

use XIIGen\Core\IDatabaseService;
use XIIGen\Core\IQueueService;
use XIIGen\Core\DataProcessResult;

/** @phpstan-type Doc = array<string, mixed> */

// ─── Configuration ───────────────────────────────────────────────

class GroupsConfig
{
    public function __construct(
        public string $groupsIndex      = 'groups',
        public string $membersIndex     = 'group-members',
        public string $configIndex      = 'group-config',
        public int    $defaultPageSize  = 20,
        public int    $maxGroupsPerUser = 50,
        public int    $defaultCapacity  = 500,
    ) {}
}

// ─── Membership Status Constants ─────────────────────────────────

class MemberStatus
{
    public const INVITED   = 'invited';
    public const PENDING   = 'pending';
    public const ACTIVE    = 'active';
    public const LEFT      = 'left';
    public const SUSPENDED = 'suspended';
    public const BANNED    = 'banned';
    public const REJECTED  = 'rejected';

    /** Valid state transitions: from → [to, ...] */
    public const TRANSITIONS = [
        self::INVITED   => [self::ACTIVE, self::REJECTED],
        self::PENDING   => [self::ACTIVE, self::REJECTED],
        self::ACTIVE    => [self::LEFT, self::SUSPENDED],
        self::SUSPENDED => [self::ACTIVE, self::BANNED],
    ];

    public static function canTransition(string $from, string $to): bool
    {
        return in_array($to, self::TRANSITIONS[$from] ?? [], true);
    }
}

// ─── Default Role Permissions ────────────────────────────────────

class DefaultRoles
{
    public const ADMIN = [
        'read', 'post', 'comment', 'delete', 'ban', 'suspend',
        'invite', 'approve', 'editGroup', 'manageRoles', 'managePolicies',
    ];

    public const MODERATOR = [
        'read', 'post', 'comment', 'delete', 'invite', 'approve', 'suspend',
    ];

    public const MEMBER = ['read', 'post', 'comment'];

    /** @return array<string, list<string>> */
    public static function all(): array
    {
        return [
            'admin'     => self::ADMIN,
            'moderator' => self::MODERATOR,
            'member'    => self::MEMBER,
        ];
    }
}

// ─── Pagination Result ───────────────────────────────────────────

class PagedResult
{
    /** @param list<Doc> $items */
    public function __construct(
        public array $items   = [],
        public int   $total   = 0,
        public int   $page    = 1,
        public int   $pageSize = 20,
    ) {}
}

// ─── Groups Service ──────────────────────────────────────────────

class GroupsService
{
    public function __construct(
        private readonly IDatabaseService $db,
        private readonly IQueueService    $queue,
        private readonly GroupsConfig     $config = new GroupsConfig(),
    ) {}

    // ═══════════════════════════════════════════════════════════════
    // 1. Group Lifecycle
    // ═══════════════════════════════════════════════════════════════

    /**
     * Create a new group. Creator automatically becomes admin.
     *
     * @param Doc $context  Scope context (scopeId, requesterId)
     * @param Doc $groupData  Group fields (name, type, description, policies, etc.)
     * @return DataProcessResult<Doc>
     */
    public function createGroup(array $context, array $groupData): DataProcessResult
    {
        try {
            $creatorId = (string) ($context['requesterId'] ?? '');
            $scopeId   = (string) ($context['scopeId'] ?? '');
            if ($creatorId === '' || $scopeId === '') {
                return DataProcessResult::failure('Missing requesterId or scopeId in context');
            }

            $name = (string) ($groupData['name'] ?? '');
            if ($name === '') {
                return DataProcessResult::failure('Group name is required');
            }

            // Check max groups per user
            $userGroupCount = $this->countUserGroups($context, $creatorId);
            if ($userGroupCount >= $this->config->maxGroupsPerUser) {
                return DataProcessResult::failure(
                    "User has reached maximum groups limit ({$this->config->maxGroupsPerUser})"
                );
            }

            $now     = gmdate('Y-m-d\TH:i:s\Z');
            $groupId = 'grp_' . bin2hex(random_bytes(12));

            // Build group document — dynamic, no typed model
            $group = array_merge($groupData, [
                'groupId'     => $groupId,
                'scopeId'     => $scopeId,
                'createdBy'   => $creatorId,
                'memberCount' => 1,
                'capacity'    => (int) ($groupData['capacity'] ?? $this->config->defaultCapacity),
                'status'      => 'active',
                'createdAt'   => $now,
                'updatedAt'   => $now,
            ]);

            // Ensure policies have defaults
            $policies = (array) ($group['policies'] ?? []);
            $policies['joinPolicy']       = $policies['joinPolicy'] ?? 'approval';
            $policies['contentTypes']     = $policies['contentTypes'] ?? ['discussion', 'event', 'resource'];
            $policies['allowAttachments'] = $policies['allowAttachments'] ?? true;
            $policies['moderationLevel']  = $policies['moderationLevel'] ?? 'standard';
            $group['policies'] = $policies;

            // Ensure visibility default
            $group['visibility'] = $group['visibility'] ?? 'public';
            $group['tags']       = $group['tags'] ?? [];

            $this->db->index($context, $this->config->groupsIndex, $groupId, $group);

            // Create admin membership for creator
            $membershipId = 'mbr_' . bin2hex(random_bytes(12));
            $membership = [
                'membershipId' => $membershipId,
                'groupId'      => $groupId,
                'userId'       => $creatorId,
                'role'         => 'admin',
                'permissions'  => DefaultRoles::ADMIN,
                'status'       => MemberStatus::ACTIVE,
                'joinedAt'     => $now,
                'metadata'     => ['joinSource' => 'creator'],
            ];

            $this->db->index($context, $this->config->membersIndex, $membershipId, $membership);

            $this->publishEvent($context, 'GroupCreated', [
                'groupId'   => $groupId,
                'creatorId' => $creatorId,
                'name'      => $name,
                'type'      => $group['type'] ?? 'general',
            ]);

            return DataProcessResult::success($group);
        } catch (\Throwable $e) {
            return DataProcessResult::failure("CreateGroup failed: {$e->getMessage()}");
        }
    }

    /**
     * Get group by ID with visibility check.
     *
     * @param Doc $context
     * @return DataProcessResult<Doc>
     */
    public function getGroupById(array $context, string $groupId): DataProcessResult
    {
        try {
            $group = $this->db->getById($context, $this->config->groupsIndex, $groupId);
            if ($group === null) {
                return DataProcessResult::failure('Group not found');
            }

            // Private group visibility check
            $visibility = (string) ($group['visibility'] ?? 'public');
            if ($visibility === 'private') {
                $requesterId = (string) ($context['requesterId'] ?? '');
                if ($requesterId !== '') {
                    $isMember = $this->isMember($context, $groupId, $requesterId);
                    if (!$isMember) {
                        return DataProcessResult::failure('Group is private. Membership required.');
                    }
                }
            }

            return DataProcessResult::success($group);
        } catch (\Throwable $e) {
            return DataProcessResult::failure("GetGroupById failed: {$e->getMessage()}");
        }
    }

    /**
     * Search groups with BuildSearchFilter (DNA-2: empty fields skipped).
     *
     * @param Doc $context
     * @param Doc $filter  Optional fields: type, status, visibility, tags, scopeId
     * @return DataProcessResult<PagedResult>
     */
    public function searchGroups(array $context, array $filter, int $page = 1, int $pageSize = 0): DataProcessResult
    {
        try {
            $pageSize = $pageSize > 0 ? $pageSize : $this->config->defaultPageSize;
            $esFilter = self::buildSearchFilter($filter);

            $results = $this->db->search($context, $this->config->groupsIndex, $esFilter, $page, $pageSize);
            $items   = $results['items'] ?? [];
            $total   = (int) ($results['total'] ?? count($items));

            return DataProcessResult::success(new PagedResult($items, $total, $page, $pageSize));
        } catch (\Throwable $e) {
            return DataProcessResult::failure("SearchGroups failed: {$e->getMessage()}");
        }
    }

    /**
     * Update group fields (admin only).
     *
     * @param Doc $context
     * @param Doc $updates  Fields to update
     * @return DataProcessResult<Doc>
     */
    public function updateGroup(array $context, string $groupId, array $updates): DataProcessResult
    {
        try {
            $updaterId = (string) ($context['requesterId'] ?? '');

            // Permission check: admin or editGroup
            $hasPerm = $this->hasPermissionInternal($context, $groupId, $updaterId, 'editGroup');
            if (!$hasPerm) {
                return DataProcessResult::failure('Requires editGroup permission');
            }

            $group = $this->db->getById($context, $this->config->groupsIndex, $groupId);
            if ($group === null) {
                return DataProcessResult::failure('Group not found');
            }

            // Prevent overwriting system fields
            unset($updates['groupId'], $updates['scopeId'], $updates['createdBy'], $updates['createdAt']);
            $updates['updatedAt'] = gmdate('Y-m-d\TH:i:s\Z');

            $updated = array_merge($group, $updates);
            $this->db->index($context, $this->config->groupsIndex, $groupId, $updated);

            $this->publishEvent($context, 'GroupUpdated', [
                'groupId'   => $groupId,
                'updaterId' => $updaterId,
                'fields'    => array_keys($updates),
            ]);

            return DataProcessResult::success($updated);
        } catch (\Throwable $e) {
            return DataProcessResult::failure("UpdateGroup failed: {$e->getMessage()}");
        }
    }

    /**
     * Soft-delete group (admin/creator only).
     *
     * @param Doc $context
     * @return DataProcessResult<Doc>
     */
    public function deleteGroup(array $context, string $groupId): DataProcessResult
    {
        try {
            $deleterId = (string) ($context['requesterId'] ?? '');

            $group = $this->db->getById($context, $this->config->groupsIndex, $groupId);
            if ($group === null) {
                return DataProcessResult::failure('Group not found');
            }

            // Only creator or admin can delete
            $createdBy = (string) ($group['createdBy'] ?? '');
            $isAdmin   = $this->hasPermissionInternal($context, $groupId, $deleterId, 'editGroup');
            if ($deleterId !== $createdBy && !$isAdmin) {
                return DataProcessResult::failure('Only group creator or admin can delete');
            }

            $group['status']    = 'deleted';
            $group['deletedAt'] = gmdate('Y-m-d\TH:i:s\Z');
            $group['deletedBy'] = $deleterId;
            $group['updatedAt'] = $group['deletedAt'];

            $this->db->index($context, $this->config->groupsIndex, $groupId, $group);

            $this->publishEvent($context, 'GroupDeleted', [
                'groupId'   => $groupId,
                'deleterId' => $deleterId,
            ]);

            return DataProcessResult::success($group);
        } catch (\Throwable $e) {
            return DataProcessResult::failure("DeleteGroup failed: {$e->getMessage()}");
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // 2. Membership Management
    // ═══════════════════════════════════════════════════════════════

    /**
     * User requests to join a group. Outcome depends on join policy:
     * - open: status = ACTIVE immediately
     * - approval: status = PENDING (awaits moderator)
     * - invite: rejected (must be invited)
     *
     * @param Doc $context
     * @return DataProcessResult<Doc>
     */
    public function joinGroup(array $context, string $groupId): DataProcessResult
    {
        try {
            $userId = (string) ($context['requesterId'] ?? '');
            if ($userId === '') {
                return DataProcessResult::failure('Missing requesterId');
            }

            $group = $this->db->getById($context, $this->config->groupsIndex, $groupId);
            if ($group === null) {
                return DataProcessResult::failure('Group not found');
            }

            if (($group['status'] ?? '') !== 'active') {
                return DataProcessResult::failure('Group is not active');
            }

            // Capacity check
            $memberCount = (int) ($group['memberCount'] ?? 0);
            $capacity    = (int) ($group['capacity'] ?? $this->config->defaultCapacity);
            if ($memberCount >= $capacity) {
                return DataProcessResult::failure('Group is at capacity');
            }

            // Check if already a member (active/suspended/pending/invited)
            $existing = $this->getMembership($context, $groupId, $userId);
            if ($existing !== null) {
                $existingStatus = (string) ($existing['status'] ?? '');
                if ($existingStatus === MemberStatus::BANNED) {
                    return DataProcessResult::failure('User is banned from this group');
                }
                if (in_array($existingStatus, [MemberStatus::ACTIVE, MemberStatus::PENDING, MemberStatus::INVITED], true)) {
                    return DataProcessResult::failure("User already has membership status: {$existingStatus}");
                }
            }

            // Join policy determines initial status
            $policies   = (array) ($group['policies'] ?? []);
            $joinPolicy = (string) ($policies['joinPolicy'] ?? 'approval');

            if ($joinPolicy === 'invite') {
                return DataProcessResult::failure('This group is invite-only');
            }

            $now          = gmdate('Y-m-d\TH:i:s\Z');
            $membershipId = 'mbr_' . bin2hex(random_bytes(12));
            $status       = ($joinPolicy === 'open') ? MemberStatus::ACTIVE : MemberStatus::PENDING;

            $membership = [
                'membershipId' => $membershipId,
                'groupId'      => $groupId,
                'userId'       => $userId,
                'role'         => 'member',
                'permissions'  => DefaultRoles::MEMBER,
                'status'       => $status,
                'joinedAt'     => ($status === MemberStatus::ACTIVE) ? $now : null,
                'requestedAt'  => $now,
                'metadata'     => ['joinSource' => 'self', 'joinPolicy' => $joinPolicy],
            ];

            $this->db->index($context, $this->config->membersIndex, $membershipId, $membership);

            // If open join, increment count and publish
            if ($status === MemberStatus::ACTIVE) {
                $this->incrementMemberCount($context, $groupId, 1);
                $this->publishEvent($context, 'MemberJoined', [
                    'groupId'      => $groupId,
                    'userId'       => $userId,
                    'membershipId' => $membershipId,
                    'method'       => 'open-join',
                ]);
            }

            return DataProcessResult::success($membership);
        } catch (\Throwable $e) {
            return DataProcessResult::failure("JoinGroup failed: {$e->getMessage()}");
        }
    }

    /**
     * User voluntarily leaves a group.
     *
     * @param Doc $context
     * @return DataProcessResult<Doc>
     */
    public function leaveGroup(array $context, string $groupId): DataProcessResult
    {
        try {
            $userId = (string) ($context['requesterId'] ?? '');

            $membership = $this->getMembership($context, $groupId, $userId);
            if ($membership === null) {
                return DataProcessResult::failure('User is not a member of this group');
            }

            $status = (string) ($membership['status'] ?? '');
            if (!MemberStatus::canTransition($status, MemberStatus::LEFT)) {
                return DataProcessResult::failure("Cannot leave from status: {$status}");
            }

            // Last admin protection
            $role = (string) ($membership['role'] ?? '');
            if ($role === 'admin') {
                $adminCount = $this->countMembersByRole($context, $groupId, 'admin');
                if ($adminCount <= 1) {
                    return DataProcessResult::failure('Cannot leave: you are the last admin. Transfer admin role first.');
                }
            }

            $membership['status']  = MemberStatus::LEFT;
            $membership['leftAt']  = gmdate('Y-m-d\TH:i:s\Z');
            $membershipId = (string) $membership['membershipId'];

            $this->db->index($context, $this->config->membersIndex, $membershipId, $membership);
            $this->incrementMemberCount($context, $groupId, -1);

            $this->publishEvent($context, 'MemberLeft', [
                'groupId' => $groupId,
                'userId'  => $userId,
                'reason'  => 'voluntary',
            ]);

            return DataProcessResult::success($membership);
        } catch (\Throwable $e) {
            return DataProcessResult::failure("LeaveGroup failed: {$e->getMessage()}");
        }
    }

    /**
     * Invite a user to join the group (requires invite permission).
     *
     * @param Doc $context
     * @return DataProcessResult<Doc>
     */
    public function inviteMember(array $context, string $groupId, string $inviteeId): DataProcessResult
    {
        try {
            $inviterId = (string) ($context['requesterId'] ?? '');

            // Permission check
            if (!$this->hasPermissionInternal($context, $groupId, $inviterId, 'invite')) {
                return DataProcessResult::failure('Requires invite permission');
            }

            // Check if already a member
            $existing = $this->getMembership($context, $groupId, $inviteeId);
            if ($existing !== null) {
                $existingStatus = (string) ($existing['status'] ?? '');
                if ($existingStatus === MemberStatus::BANNED) {
                    return DataProcessResult::failure('User is banned from this group');
                }
                if (in_array($existingStatus, [MemberStatus::ACTIVE, MemberStatus::PENDING, MemberStatus::INVITED], true)) {
                    return DataProcessResult::failure("User already has membership status: {$existingStatus}");
                }
            }

            // Capacity check
            $group = $this->db->getById($context, $this->config->groupsIndex, $groupId);
            if ($group === null) {
                return DataProcessResult::failure('Group not found');
            }
            $memberCount = (int) ($group['memberCount'] ?? 0);
            $capacity    = (int) ($group['capacity'] ?? $this->config->defaultCapacity);
            if ($memberCount >= $capacity) {
                return DataProcessResult::failure('Group is at capacity');
            }

            $now          = gmdate('Y-m-d\TH:i:s\Z');
            $membershipId = 'mbr_' . bin2hex(random_bytes(12));

            $membership = [
                'membershipId' => $membershipId,
                'groupId'      => $groupId,
                'userId'       => $inviteeId,
                'role'         => 'member',
                'permissions'  => DefaultRoles::MEMBER,
                'status'       => MemberStatus::INVITED,
                'invitedBy'    => $inviterId,
                'invitedAt'    => $now,
                'metadata'     => ['joinSource' => 'invite'],
            ];

            $this->db->index($context, $this->config->membersIndex, $membershipId, $membership);

            return DataProcessResult::success($membership);
        } catch (\Throwable $e) {
            return DataProcessResult::failure("InviteMember failed: {$e->getMessage()}");
        }
    }

    /**
     * Accept an invitation (invited user only).
     *
     * @param Doc $context
     * @return DataProcessResult<Doc>
     */
    public function acceptInvite(array $context, string $membershipId): DataProcessResult
    {
        try {
            $userId = (string) ($context['requesterId'] ?? '');

            $membership = $this->db->getById($context, $this->config->membersIndex, $membershipId);
            if ($membership === null) {
                return DataProcessResult::failure('Membership not found');
            }

            if ((string) ($membership['userId'] ?? '') !== $userId) {
                return DataProcessResult::failure('Only the invited user can accept');
            }

            $status = (string) ($membership['status'] ?? '');
            if (!MemberStatus::canTransition($status, MemberStatus::ACTIVE) || $status !== MemberStatus::INVITED) {
                return DataProcessResult::failure("Cannot accept from status: {$status}");
            }

            $membership['status']   = MemberStatus::ACTIVE;
            $membership['joinedAt'] = gmdate('Y-m-d\TH:i:s\Z');

            $this->db->index($context, $this->config->membersIndex, $membershipId, $membership);

            $groupId = (string) $membership['groupId'];
            $this->incrementMemberCount($context, $groupId, 1);

            $this->publishEvent($context, 'MemberJoined', [
                'groupId'      => $groupId,
                'userId'       => $userId,
                'membershipId' => $membershipId,
                'method'       => 'invite-accept',
            ]);

            return DataProcessResult::success($membership);
        } catch (\Throwable $e) {
            return DataProcessResult::failure("AcceptInvite failed: {$e->getMessage()}");
        }
    }

    /**
     * Approve a pending membership request (moderator+ only).
     *
     * @param Doc $context
     * @return DataProcessResult<Doc>
     */
    public function approveMember(array $context, string $membershipId): DataProcessResult
    {
        try {
            $approverId = (string) ($context['requesterId'] ?? '');

            $membership = $this->db->getById($context, $this->config->membersIndex, $membershipId);
            if ($membership === null) {
                return DataProcessResult::failure('Membership not found');
            }

            $groupId = (string) $membership['groupId'];
            if (!$this->hasPermissionInternal($context, $groupId, $approverId, 'approve')) {
                return DataProcessResult::failure('Requires approve permission');
            }

            $status = (string) ($membership['status'] ?? '');
            if ($status !== MemberStatus::PENDING) {
                return DataProcessResult::failure("Cannot approve from status: {$status}");
            }

            $membership['status']     = MemberStatus::ACTIVE;
            $membership['joinedAt']   = gmdate('Y-m-d\TH:i:s\Z');
            $membership['approvedBy'] = $approverId;

            $this->db->index($context, $this->config->membersIndex, $membershipId, $membership);
            $this->incrementMemberCount($context, $groupId, 1);

            $this->publishEvent($context, 'MemberJoined', [
                'groupId'      => $groupId,
                'userId'       => (string) $membership['userId'],
                'membershipId' => $membershipId,
                'method'       => 'approved',
            ]);

            return DataProcessResult::success($membership);
        } catch (\Throwable $e) {
            return DataProcessResult::failure("ApproveMember failed: {$e->getMessage()}");
        }
    }

    /**
     * Reject a pending membership request (moderator+ only).
     *
     * @param Doc $context
     * @return DataProcessResult<Doc>
     */
    public function rejectMember(array $context, string $membershipId): DataProcessResult
    {
        try {
            $rejecterId = (string) ($context['requesterId'] ?? '');

            $membership = $this->db->getById($context, $this->config->membersIndex, $membershipId);
            if ($membership === null) {
                return DataProcessResult::failure('Membership not found');
            }

            $groupId = (string) $membership['groupId'];
            if (!$this->hasPermissionInternal($context, $groupId, $rejecterId, 'approve')) {
                return DataProcessResult::failure('Requires approve permission');
            }

            $status = (string) ($membership['status'] ?? '');
            if ($status !== MemberStatus::PENDING) {
                return DataProcessResult::failure("Cannot reject from status: {$status}");
            }

            $membership['status']     = MemberStatus::REJECTED;
            $membership['rejectedBy'] = $rejecterId;
            $membership['rejectedAt'] = gmdate('Y-m-d\TH:i:s\Z');

            $this->db->index($context, $this->config->membersIndex, $membershipId, $membership);

            return DataProcessResult::success($membership);
        } catch (\Throwable $e) {
            return DataProcessResult::failure("RejectMember failed: {$e->getMessage()}");
        }
    }

    /**
     * Remove a member (moderator+ only). Target cannot be removed if they have higher role.
     *
     * @param Doc $context
     * @return DataProcessResult<Doc>
     */
    public function removeMember(array $context, string $groupId, string $targetUserId): DataProcessResult
    {
        try {
            $removerId = (string) ($context['requesterId'] ?? '');

            if (!$this->hasPermissionInternal($context, $groupId, $removerId, 'delete')) {
                return DataProcessResult::failure('Requires delete permission to remove members');
            }

            $membership = $this->getMembership($context, $groupId, $targetUserId);
            if ($membership === null) {
                return DataProcessResult::failure('Target user is not a member');
            }

            $status = (string) ($membership['status'] ?? '');
            if (!MemberStatus::canTransition($status, MemberStatus::LEFT)) {
                return DataProcessResult::failure("Cannot remove from status: {$status}");
            }

            $membership['status']    = MemberStatus::LEFT;
            $membership['removedBy'] = $removerId;
            $membership['removedAt'] = gmdate('Y-m-d\TH:i:s\Z');
            $membershipId = (string) $membership['membershipId'];

            $this->db->index($context, $this->config->membersIndex, $membershipId, $membership);
            $this->incrementMemberCount($context, $groupId, -1);

            $this->publishEvent($context, 'MemberLeft', [
                'groupId'   => $groupId,
                'userId'    => $targetUserId,
                'removedBy' => $removerId,
                'reason'    => 'removed',
            ]);

            return DataProcessResult::success($membership);
        } catch (\Throwable $e) {
            return DataProcessResult::failure("RemoveMember failed: {$e->getMessage()}");
        }
    }

    /**
     * Suspend a member (requires suspend permission).
     *
     * @param Doc $context
     * @return DataProcessResult<Doc>
     */
    public function suspendMember(array $context, string $groupId, string $targetUserId): DataProcessResult
    {
        try {
            $suspenderId = (string) ($context['requesterId'] ?? '');

            if (!$this->hasPermissionInternal($context, $groupId, $suspenderId, 'suspend')) {
                return DataProcessResult::failure('Requires suspend permission');
            }

            $membership = $this->getMembership($context, $groupId, $targetUserId);
            if ($membership === null) {
                return DataProcessResult::failure('Target user is not a member');
            }

            $status = (string) ($membership['status'] ?? '');
            if (!MemberStatus::canTransition($status, MemberStatus::SUSPENDED)) {
                return DataProcessResult::failure("Cannot suspend from status: {$status}");
            }

            $membership['status']      = MemberStatus::SUSPENDED;
            $membership['suspendedBy'] = $suspenderId;
            $membership['suspendedAt'] = gmdate('Y-m-d\TH:i:s\Z');
            $membershipId = (string) $membership['membershipId'];

            $this->db->index($context, $this->config->membersIndex, $membershipId, $membership);

            $this->publishEvent($context, 'MemberSuspended', [
                'groupId'     => $groupId,
                'userId'      => $targetUserId,
                'suspendedBy' => $suspenderId,
            ]);

            return DataProcessResult::success($membership);
        } catch (\Throwable $e) {
            return DataProcessResult::failure("SuspendMember failed: {$e->getMessage()}");
        }
    }

    /**
     * Ban a member permanently (requires ban permission). Only from suspended state.
     *
     * @param Doc $context
     * @return DataProcessResult<Doc>
     */
    public function banMember(array $context, string $groupId, string $targetUserId): DataProcessResult
    {
        try {
            $bannerId = (string) ($context['requesterId'] ?? '');

            if (!$this->hasPermissionInternal($context, $groupId, $bannerId, 'ban')) {
                return DataProcessResult::failure('Requires ban permission');
            }

            $membership = $this->getMembership($context, $groupId, $targetUserId);
            if ($membership === null) {
                return DataProcessResult::failure('Target user is not a member');
            }

            $status = (string) ($membership['status'] ?? '');
            if (!MemberStatus::canTransition($status, MemberStatus::BANNED)) {
                return DataProcessResult::failure("Cannot ban from status: {$status}. Must suspend first.");
            }

            $membership['status']   = MemberStatus::BANNED;
            $membership['bannedBy'] = $bannerId;
            $membership['bannedAt'] = gmdate('Y-m-d\TH:i:s\Z');
            $membershipId = (string) $membership['membershipId'];

            $this->db->index($context, $this->config->membersIndex, $membershipId, $membership);
            $this->incrementMemberCount($context, $groupId, -1);

            $this->publishEvent($context, 'MemberBanned', [
                'groupId'  => $groupId,
                'userId'   => $targetUserId,
                'bannedBy' => $bannerId,
            ]);

            return DataProcessResult::success($membership);
        } catch (\Throwable $e) {
            return DataProcessResult::failure("BanMember failed: {$e->getMessage()}");
        }
    }

    /**
     * List members of a group with pagination and optional role filter.
     *
     * @param Doc $context
     * @return DataProcessResult<PagedResult>
     */
    public function getMembers(array $context, string $groupId, int $page = 1, int $pageSize = 0, ?string $role = null): DataProcessResult
    {
        try {
            $pageSize = $pageSize > 0 ? $pageSize : $this->config->defaultPageSize;

            $filter = ['groupId' => $groupId, 'status' => MemberStatus::ACTIVE];
            if ($role !== null && $role !== '') {
                $filter['role'] = $role;
            }

            $results = $this->db->search($context, $this->config->membersIndex, $filter, $page, $pageSize);
            $items   = $results['items'] ?? [];
            $total   = (int) ($results['total'] ?? count($items));

            return DataProcessResult::success(new PagedResult($items, $total, $page, $pageSize));
        } catch (\Throwable $e) {
            return DataProcessResult::failure("GetMembers failed: {$e->getMessage()}");
        }
    }

    /**
     * Get all groups a user belongs to.
     *
     * @param Doc $context
     * @return DataProcessResult<PagedResult>
     */
    public function getUserGroups(array $context, string $userId, int $page = 1, int $pageSize = 0): DataProcessResult
    {
        try {
            $pageSize = $pageSize > 0 ? $pageSize : $this->config->defaultPageSize;

            $filter = ['userId' => $userId, 'status' => MemberStatus::ACTIVE];
            $results = $this->db->search($context, $this->config->membersIndex, $filter, $page, $pageSize);

            $memberships = $results['items'] ?? [];
            $total       = (int) ($results['total'] ?? count($memberships));

            // Hydrate with group data
            $groupIds = array_map(fn(array $m) => (string) ($m['groupId'] ?? ''), $memberships);
            $groupIds = array_filter($groupIds);

            $groups = [];
            foreach ($groupIds as $gid) {
                $g = $this->db->getById($context, $this->config->groupsIndex, $gid);
                if ($g !== null) {
                    $groups[] = $g;
                }
            }

            return DataProcessResult::success(new PagedResult($groups, $total, $page, $pageSize));
        } catch (\Throwable $e) {
            return DataProcessResult::failure("GetUserGroups failed: {$e->getMessage()}");
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // 3. Role & Permission Management
    // ═══════════════════════════════════════════════════════════════

    /**
     * Change a member's role (admin only).
     *
     * @param Doc $context
     * @return DataProcessResult<Doc>
     */
    public function changeRole(array $context, string $groupId, string $targetUserId, string $newRole): DataProcessResult
    {
        try {
            $changerId = (string) ($context['requesterId'] ?? '');

            if (!$this->hasPermissionInternal($context, $groupId, $changerId, 'manageRoles')) {
                return DataProcessResult::failure('Requires manageRoles permission');
            }

            $membership = $this->getMembership($context, $groupId, $targetUserId);
            if ($membership === null) {
                return DataProcessResult::failure('Target user is not a member');
            }

            if ((string) ($membership['status'] ?? '') !== MemberStatus::ACTIVE) {
                return DataProcessResult::failure('Can only change role of active members');
            }

            $oldRole = (string) ($membership['role'] ?? 'member');

            // If demoting from admin, check last-admin protection
            if ($oldRole === 'admin' && $newRole !== 'admin') {
                $adminCount = $this->countMembersByRole($context, $groupId, 'admin');
                if ($adminCount <= 1) {
                    return DataProcessResult::failure('Cannot demote the last admin');
                }
            }

            // Resolve permissions for new role
            $permissions = $this->getRolePermissionsInternal($context, $groupId, $newRole);

            $membership['role']            = $newRole;
            $membership['permissions']     = $permissions;
            $membership['roleChangedAt']   = gmdate('Y-m-d\TH:i:s\Z');
            $membership['roleChangedBy']   = $changerId;
            $membership['previousRole']    = $oldRole;
            $membershipId = (string) $membership['membershipId'];

            $this->db->index($context, $this->config->membersIndex, $membershipId, $membership);

            $this->publishEvent($context, 'MemberRoleChanged', [
                'groupId'  => $groupId,
                'userId'   => $targetUserId,
                'oldRole'  => $oldRole,
                'newRole'  => $newRole,
                'changedBy' => $changerId,
            ]);

            return DataProcessResult::success($membership);
        } catch (\Throwable $e) {
            return DataProcessResult::failure("ChangeRole failed: {$e->getMessage()}");
        }
    }

    /**
     * Check if a user has a specific permission in a group.
     *
     * @param Doc $context
     * @return DataProcessResult<bool>
     */
    public function hasPermission(array $context, string $groupId, string $userId, string $permission): DataProcessResult
    {
        try {
            $result = $this->hasPermissionInternal($context, $groupId, $userId, $permission);
            return DataProcessResult::success($result);
        } catch (\Throwable $e) {
            return DataProcessResult::failure("HasPermission failed: {$e->getMessage()}");
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // 4. Policy Enforcement
    // ═══════════════════════════════════════════════════════════════

    /**
     * Check if user can post specific content type in group.
     *
     * @param Doc $context
     * @return DataProcessResult<bool>
     */
    public function canPost(array $context, string $groupId, string $userId, string $contentType): DataProcessResult
    {
        try {
            // Check user has post permission
            if (!$this->hasPermissionInternal($context, $groupId, $userId, 'post')) {
                return DataProcessResult::success(false);
            }

            // Check content type is allowed by group policy
            $group = $this->db->getById($context, $this->config->groupsIndex, $groupId);
            if ($group === null) {
                return DataProcessResult::success(false);
            }

            $policies     = (array) ($group['policies'] ?? []);
            $contentTypes = (array) ($policies['contentTypes'] ?? []);

            // If no content types defined, allow all
            if (empty($contentTypes)) {
                return DataProcessResult::success(true);
            }

            $allowed = in_array($contentType, $contentTypes, true);
            return DataProcessResult::success($allowed);
        } catch (\Throwable $e) {
            return DataProcessResult::failure("CanPost failed: {$e->getMessage()}");
        }
    }

    /**
     * Get group policies.
     *
     * @param Doc $context
     * @return DataProcessResult<Doc>
     */
    public function getGroupPolicies(array $context, string $groupId): DataProcessResult
    {
        try {
            $group = $this->db->getById($context, $this->config->groupsIndex, $groupId);
            if ($group === null) {
                return DataProcessResult::failure('Group not found');
            }

            $policies = (array) ($group['policies'] ?? []);
            return DataProcessResult::success($policies);
        } catch (\Throwable $e) {
            return DataProcessResult::failure("GetGroupPolicies failed: {$e->getMessage()}");
        }
    }

    /**
     * Update group policies (requires managePolicies permission).
     *
     * @param Doc $context
     * @param Doc $policies  New policy values
     * @return DataProcessResult<Doc>
     */
    public function updatePolicies(array $context, string $groupId, array $policies): DataProcessResult
    {
        try {
            $updaterId = (string) ($context['requesterId'] ?? '');

            if (!$this->hasPermissionInternal($context, $groupId, $updaterId, 'managePolicies')) {
                return DataProcessResult::failure('Requires managePolicies permission');
            }

            $group = $this->db->getById($context, $this->config->groupsIndex, $groupId);
            if ($group === null) {
                return DataProcessResult::failure('Group not found');
            }

            $existing = (array) ($group['policies'] ?? []);
            $merged   = array_merge($existing, $policies);

            $group['policies']  = $merged;
            $group['updatedAt'] = gmdate('Y-m-d\TH:i:s\Z');

            $this->db->index($context, $this->config->groupsIndex, $groupId, $group);

            $this->publishEvent($context, 'GroupUpdated', [
                'groupId'   => $groupId,
                'updaterId' => $updaterId,
                'fields'    => ['policies'],
            ]);

            return DataProcessResult::success($group);
        } catch (\Throwable $e) {
            return DataProcessResult::failure("UpdatePolicies failed: {$e->getMessage()}");
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // 5. Discovery & Auto-Join
    // ═══════════════════════════════════════════════════════════════

    /**
     * Discover groups for a user based on their connections' groups.
     *
     * @param Doc $context
     * @return DataProcessResult<list<Doc>>
     */
    public function discoverGroups(array $context, string $userId, int $limit = 10): DataProcessResult
    {
        try {
            // Get user's current groups
            $userMemberships = $this->db->search($context, $this->config->membersIndex, [
                'userId' => $userId,
                'status' => MemberStatus::ACTIVE,
            ], 1, 200);
            $userGroupIds = array_map(
                fn(array $m) => (string) ($m['groupId'] ?? ''),
                $userMemberships['items'] ?? []
            );
            $userGroupIds = array_filter($userGroupIds);
            $userGroupSet = array_flip($userGroupIds);

            // Search public active groups not already joined
            $publicGroups = $this->db->search($context, $this->config->groupsIndex, [
                'visibility' => 'public',
                'status'     => 'active',
            ], 1, $limit * 3);

            $suggestions = [];
            foreach (($publicGroups['items'] ?? []) as $group) {
                $gid = (string) ($group['groupId'] ?? '');
                if ($gid !== '' && !isset($userGroupSet[$gid])) {
                    $suggestions[] = $group;
                    if (count($suggestions) >= $limit) {
                        break;
                    }
                }
            }

            return DataProcessResult::success($suggestions);
        } catch (\Throwable $e) {
            return DataProcessResult::failure("DiscoverGroups failed: {$e->getMessage()}");
        }
    }

    /**
     * Evaluate auto-join rules for a newly registered user.
     * Called when UserRegistered event is received.
     *
     * @param Doc $context
     * @param Doc $userProfile  User profile with attributes to match
     * @return DataProcessResult<list<Doc>>  List of auto-created memberships
     */
    public function evaluateAutoJoin(array $context, string $userId, array $userProfile): DataProcessResult
    {
        try {
            $scopeId = (string) ($context['scopeId'] ?? '');

            // Load config to get auto-join rules
            $config = $this->db->search($context, $this->config->configIndex, [
                'scopeId' => $scopeId,
            ], 1, 1);

            $configDoc = ($config['items'] ?? [])[0] ?? null;
            if ($configDoc === null) {
                return DataProcessResult::success([]);
            }

            $rules          = (array) ($configDoc['autoJoinRules'] ?? []);
            $joinedGroups   = [];

            foreach ($rules as $rule) {
                $rule       = (array) $rule;
                $matchField = (string) ($rule['matchField'] ?? '');
                $matchValue = (string) ($rule['matchValue'] ?? '');
                $targetGrp  = (string) ($rule['targetGroupId'] ?? '');
                $role       = (string) ($rule['role'] ?? 'member');

                if ($matchField === '' || $matchValue === '' || $targetGrp === '') {
                    continue;
                }

                // Check if user profile field matches
                $userValue = $userProfile[$matchField] ?? null;
                $matched   = false;

                if (is_array($userValue)) {
                    $matched = in_array($matchValue, $userValue, true);
                } elseif (is_string($userValue)) {
                    $matched = (strtolower($userValue) === strtolower($matchValue));
                }

                if (!$matched) {
                    continue;
                }

                // Verify group exists and has capacity
                $group = $this->db->getById($context, $this->config->groupsIndex, $targetGrp);
                if ($group === null || ($group['status'] ?? '') !== 'active') {
                    continue;
                }

                $memberCount = (int) ($group['memberCount'] ?? 0);
                $capacity    = (int) ($group['capacity'] ?? $this->config->defaultCapacity);
                if ($memberCount >= $capacity) {
                    continue;
                }

                // Check not already a member
                $existing = $this->getMembership($context, $targetGrp, $userId);
                if ($existing !== null) {
                    continue;
                }

                // Create auto-join membership
                $now          = gmdate('Y-m-d\TH:i:s\Z');
                $membershipId = 'mbr_' . bin2hex(random_bytes(12));
                $permissions  = $this->getRolePermissionsInternal($context, $targetGrp, $role);

                $membership = [
                    'membershipId' => $membershipId,
                    'groupId'      => $targetGrp,
                    'userId'       => $userId,
                    'role'         => $role,
                    'permissions'  => $permissions,
                    'status'       => MemberStatus::ACTIVE,
                    'joinedAt'     => $now,
                    'metadata'     => [
                        'joinSource' => 'auto-join',
                        'ruleId'     => $rule['ruleId'] ?? '',
                        'matchField' => $matchField,
                        'matchValue' => $matchValue,
                    ],
                ];

                $this->db->index($context, $this->config->membersIndex, $membershipId, $membership);
                $this->incrementMemberCount($context, $targetGrp, 1);

                $this->publishEvent($context, 'MemberJoined', [
                    'groupId'      => $targetGrp,
                    'userId'       => $userId,
                    'membershipId' => $membershipId,
                    'method'       => 'auto-join',
                ]);

                $joinedGroups[] = $membership;
            }

            return DataProcessResult::success($joinedGroups);
        } catch (\Throwable $e) {
            return DataProcessResult::failure("EvaluateAutoJoin failed: {$e->getMessage()}");
        }
    }

    /**
     * Get groups shared between two users (for connection strength calculation).
     *
     * @param Doc $context
     * @return DataProcessResult<list<string>>  List of shared group IDs
     */
    public function getSharedGroups(array $context, string $userA, string $userB): DataProcessResult
    {
        try {
            $membershipsA = $this->db->search($context, $this->config->membersIndex, [
                'userId' => $userA,
                'status' => MemberStatus::ACTIVE,
            ], 1, 500);

            $membershipsB = $this->db->search($context, $this->config->membersIndex, [
                'userId' => $userB,
                'status' => MemberStatus::ACTIVE,
            ], 1, 500);

            $groupsA = array_map(
                fn(array $m) => (string) ($m['groupId'] ?? ''),
                $membershipsA['items'] ?? []
            );
            $groupsB = array_map(
                fn(array $m) => (string) ($m['groupId'] ?? ''),
                $membershipsB['items'] ?? []
            );

            $shared = array_values(array_intersect(array_filter($groupsA), array_filter($groupsB)));

            return DataProcessResult::success($shared);
        } catch (\Throwable $e) {
            return DataProcessResult::failure("GetSharedGroups failed: {$e->getMessage()}");
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // Private Helpers
    // ═══════════════════════════════════════════════════════════════

    /**
     * Get active/suspended/invited/pending membership for user in group.
     * Returns null if no qualifying membership found.
     *
     * @param Doc $context
     * @return Doc|null
     */
    private function getMembership(array $context, string $groupId, string $userId): ?array
    {
        $results = $this->db->search($context, $this->config->membersIndex, [
            'groupId' => $groupId,
            'userId'  => $userId,
        ], 1, 10);

        $items = $results['items'] ?? [];
        if (empty($items)) {
            return null;
        }

        // Prioritize active statuses
        $priority = [
            MemberStatus::ACTIVE    => 1,
            MemberStatus::SUSPENDED => 2,
            MemberStatus::INVITED   => 3,
            MemberStatus::PENDING   => 4,
            MemberStatus::BANNED    => 5,
        ];

        usort($items, function (array $a, array $b) use ($priority): int {
            $pa = $priority[(string) ($a['status'] ?? '')] ?? 99;
            $pb = $priority[(string) ($b['status'] ?? '')] ?? 99;
            return $pa <=> $pb;
        });

        return $items[0];
    }

    /**
     * Check if user is an active member of group.
     */
    private function isMember(array $context, string $groupId, string $userId): bool
    {
        $membership = $this->getMembership($context, $groupId, $userId);
        return $membership !== null && ($membership['status'] ?? '') === MemberStatus::ACTIVE;
    }

    /**
     * Check permission without wrapping in DataProcessResult.
     */
    private function hasPermissionInternal(array $context, string $groupId, string $userId, string $permission): bool
    {
        $membership = $this->getMembership($context, $groupId, $userId);
        if ($membership === null || ($membership['status'] ?? '') !== MemberStatus::ACTIVE) {
            return false;
        }

        $permissions = (array) ($membership['permissions'] ?? []);
        return in_array($permission, $permissions, true);
    }

    /**
     * Get permissions for a role in a group. Falls back to defaults.
     *
     * @return list<string>
     */
    private function getRolePermissionsInternal(array $context, string $groupId, string $role): array
    {
        // Could load from group-config for custom roles; fall back to defaults
        $defaults = DefaultRoles::all();
        return $defaults[$role] ?? DefaultRoles::MEMBER;
    }

    /**
     * Count active members with a specific role.
     */
    private function countMembersByRole(array $context, string $groupId, string $role): int
    {
        $results = $this->db->search($context, $this->config->membersIndex, [
            'groupId' => $groupId,
            'role'    => $role,
            'status'  => MemberStatus::ACTIVE,
        ], 1, 1);

        return (int) ($results['total'] ?? 0);
    }

    /**
     * Count groups a user belongs to (active memberships).
     */
    private function countUserGroups(array $context, string $userId): int
    {
        $results = $this->db->search($context, $this->config->membersIndex, [
            'userId' => $userId,
            'status' => MemberStatus::ACTIVE,
        ], 1, 1);

        return (int) ($results['total'] ?? 0);
    }

    /**
     * Increment or decrement group member count atomically.
     */
    private function incrementMemberCount(array $context, string $groupId, int $delta): void
    {
        $group = $this->db->getById($context, $this->config->groupsIndex, $groupId);
        if ($group === null) {
            return;
        }

        $current = (int) ($group['memberCount'] ?? 0);
        $group['memberCount'] = max(0, $current + $delta);
        $group['updatedAt']   = gmdate('Y-m-d\TH:i:s\Z');

        $this->db->index($context, $this->config->groupsIndex, $groupId, $group);
    }

    /**
     * DNA-2: BuildSearchFilter — skip empty fields automatically.
     *
     * @param Doc $input
     * @return Doc
     */
    private static function buildSearchFilter(array $input): array
    {
        $filter = [];
        foreach ($input as $key => $value) {
            if ($value === null || $value === '') {
                continue;
            }
            if (is_array($value) && empty($value)) {
                continue;
            }
            $filter[$key] = $value;
        }
        return $filter;
    }

    /**
     * Publish event to queue service.
     *
     * @param Doc $context
     * @param Doc $payload
     */
    private function publishEvent(array $context, string $eventType, array $payload): void
    {
        try {
            $this->queue->publish($context, 'groups-events', [
                'eventType' => $eventType,
                'payload'   => $payload,
                'timestamp' => gmdate('Y-m-d\TH:i:s\Z'),
                'scopeId'   => $context['scopeId'] ?? '',
            ]);
        } catch (\Throwable) {
            // Log but don't fail the operation
        }
    }
}
