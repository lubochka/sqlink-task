# Skill 50: Groups Service — Implementation Prompt

## Purpose
Guide AI agents to implement a DNA-compliant Groups Service that manages communities with dynamic membership, role-based permissions, join policies, and content policy enforcement.

## Context
You are implementing Skill 50 (Groups Service) for the XIIGen platform — Layer L10: Social Graph. This service manages community spaces where users form groups around shared interests, professions, or goals. It must follow Genie DNA patterns throughout.

## Dependencies
- Skill 01 (Core Interfaces): `IDatabaseService`, `IQueueService`, `DataProcessResult<T>`
- Skill 02 (Object Processor): Dynamic document manipulation
- Skill 20 (Auth): Token validation, user identity
- Skill 21 (Permissions): Scope-level access control
- Skill 49 (Connections): Shared groups as connection strength factor

## Elasticsearch Indices
1. **`groups`** — groupId, name, type, description, visibility, policies{}, memberCount, capacity, tags[], metadata{}, scopeId, status, createdBy, createdAt, updatedAt
2. **`group-members`** — membershipId, groupId, userId, role, permissions[], status, joinedAt, invitedBy, metadata{}
3. **`group-config`** — configId, scopeId, defaultRoles{}, groupTypes[], maxGroupsPerUser, autoJoinRules[]

## DNA Compliance Checklist
- [ ] **DNA-1**: All data as `Dictionary<string, object>` / dynamic docs — no `Group` class, no `Membership` class
- [ ] **DNA-2**: `BuildSearchFilter` with empty-field skipping for all queries
- [ ] **DNA-5**: Every public method returns `DataProcessResult<T>` — no raw exceptions
- [ ] **DNA-SCOPE**: All queries filter by scopeId; private groups visible only to members
- [ ] **DNA-FREEDOM**: Group types, roles, join policies, content policies, auto-join rules — all dynamic config
- [ ] **DNA-7**: Publish events (GroupCreated, MemberJoined, MemberLeft, MemberRoleChanged, MemberSuspended, MemberBanned); subscribe to UserRegistered, ConnectionAccepted

## Membership State Machine
```
INVITED → ACTIVE (user accepts) | REJECTED (user declines)
PENDING → ACTIVE (moderator approves) | REJECTED (moderator rejects)
ACTIVE → LEFT (user leaves/removed) | SUSPENDED (moderator suspends)
SUSPENDED → ACTIVE (unsuspend) | BANNED (moderator bans)
Open join: user → ACTIVE directly (no PENDING)
```
Validate every transition. Reject invalid ones with descriptive error.

## Core Operations to Implement

### Group Lifecycle (5 methods)
- CreateGroup: Validate name, check max-groups-per-user, create group doc + admin membership for creator
- GetGroupById: Visibility check — private groups require membership
- SearchGroups: BuildSearchFilter with type, status, visibility, tags, scopeId
- UpdateGroup: Admin/editGroup permission required; protect system fields (groupId, scopeId, createdBy)
- DeleteGroup: Soft-delete (status=deleted); creator or admin only

### Membership Management (9 methods)
- JoinGroup: Check capacity, check join policy (open→ACTIVE, approval→PENDING, invite→reject), check banned
- LeaveGroup: Validate state transition; last-admin protection (cannot leave if sole admin)
- InviteMember: Requires invite permission; check capacity; check banned/duplicate
- AcceptInvite: Only invitee; INVITED→ACTIVE; increment count; publish MemberJoined
- ApproveMember: Moderator+; PENDING→ACTIVE; increment count; publish MemberJoined
- RejectMember: Moderator+; PENDING→REJECTED
- RemoveMember: Moderator+; ACTIVE→LEFT; decrement count; publish MemberLeft
- SuspendMember: Requires suspend permission; ACTIVE→SUSPENDED; publish MemberSuspended
- BanMember: Requires ban permission; SUSPENDED→BANNED; decrement count; publish MemberBanned

### Role & Permissions (3 methods)
- ChangeRole: Admin/manageRoles only; last-admin protection on demotion; update permissions array
- HasPermission: Lookup membership, check permissions[] array (NOT role string)
- GetRolePermissions: Load from config or fall back to defaults (admin/moderator/member)

### Policy Enforcement (3 methods)
- CanPost: Check post permission AND content type in group policies
- GetGroupPolicies: Return policies{} sub-document
- UpdatePolicies: Requires managePolicies permission; merge with existing

### Discovery & Auto-Join (3 methods)
- DiscoverGroups: Find public groups user hasn't joined; optional: prioritize by connections
- EvaluateAutoJoin: On UserRegistered event, match user profile fields against autoJoinRules[]; create memberships
- GetSharedGroups: Intersect active memberships of two users; used by Skill 49 for connection strength

## Key Anti-Patterns to Avoid
```
❌ class Group { public string Name; public GroupType Type; }  // Typed model
❌ if (role == "admin") { ... }  // Hardcoded role check
❌ throw new Exception("Not authorized")  // Raw exception
❌ group.Policies.JoinPolicy  // Typed nested object
```

## Abstraction Extraction
When implementing this skill, identify these reusable patterns:
1. **State Machine Pattern**: ValidTransitions map + canTransition() — reusable for any entity with lifecycle states
2. **Permission-Based Auth**: Check permissions[] array instead of role strings — enables custom roles without code changes
3. **Capacity Enforcement**: Count-based limits with atomic increment/decrement — reusable for quotas
4. **Auto-Match Rules**: Field-value matching against dynamic rules — reusable for any rule-engine scenario
5. **Last-Admin Protection**: Prevent removal of sole role holder — reusable for any critical-role scenario

## Validation Criteria
- [ ] 23+ public methods implemented
- [ ] All state transitions validated
- [ ] Last-admin protection on leave and role change
- [ ] Capacity enforced on join and invite
- [ ] Permission-based checks (not role-based)
- [ ] 8 events published, 2 events subscribed
- [ ] BuildSearchFilter used for all queries
- [ ] No typed models anywhere
