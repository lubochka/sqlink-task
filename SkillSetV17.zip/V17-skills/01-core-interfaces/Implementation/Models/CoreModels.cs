// XIIGen.Core/Models/CoreModels.cs
// Skill 01 - Core Interfaces | .NET 9

using XIIGen.Core.Enums;

namespace XIIGen.Core.Models;

// ─── DataProcessResult<T> ─────────────────────────────
// Universal return type for all operations
public class DataProcessResult<T>
{
    public DataProcessStatus Status { get; set; }
    public T Data { get; set; }
    public string Message { get; set; }
    public string ErrorCode { get; set; }
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
    public Dictionary<string, object> Metadata { get; set; } = [];

    public bool IsSuccess => Status is DataProcessStatus.Success
        or DataProcessStatus.Created or DataProcessStatus.Updated
        or DataProcessStatus.Deleted;

    public static DataProcessResult<T> Success(T data, string message = null) => new()
    {
        Status = DataProcessStatus.Success, Data = data, Message = message ?? "OK"
    };

    public static DataProcessResult<T> Created(T data) => new()
    {
        Status = DataProcessStatus.Created, Data = data, Message = "Created"
    };

    public static DataProcessResult<T> Updated(T data) => new()
    {
        Status = DataProcessStatus.Updated, Data = data, Message = "Updated"
    };

    public static DataProcessResult<T> NotFound(string message = "Not found") => new()
    {
        Status = DataProcessStatus.NotFound, Message = message
    };

    public static DataProcessResult<T> Error(string message, string code = null) => new()
    {
        Status = DataProcessStatus.Error, Message = message, ErrorCode = code
    };

    public static DataProcessResult<T> Unauthorized(string message = "Unauthorized") => new()
    {
        Status = DataProcessStatus.Unauthorized, Message = message
    };
}

// ─── SearchCondition ──────────────────────────────────
public class SearchCondition
{
    public string Property { get; set; }
    public QueryType QueryType { get; set; }
    public object Value { get; set; }
    public object[] ValueRange { get; set; }
    public AggregationType? Aggregation { get; set; }
}

// ─── SearchOptions ────────────────────────────────────
public class SearchOptions
{
    public List<SearchCondition> Conditions { get; set; } = [];
    public int PageSize { get; set; } = 10;
    public int PageNum { get; set; } = 0;
    public string LastSearchId { get; set; }
    public string SortBy { get; set; }
    public string SortOrder { get; set; } = "desc";
}

// ─── SearchResult<T> ─────────────────────────────────
public class SearchResult<T>
{
    public List<T> Documents { get; set; } = [];
    public long Total { get; set; }
    public int PageSize { get; set; }
    public int PageNum { get; set; }
    public string SearchId { get; set; }
    public bool HasNext => (PageNum + 1) * PageSize < Total;
}

// ─── BulkResult ───────────────────────────────────────
public class BulkResult
{
    public int Succeeded { get; set; }
    public int Failed { get; set; }
    public List<BulkItemError> Errors { get; set; } = [];
}

public class BulkItemError
{
    public string Id { get; set; }
    public string Error { get; set; }
}

// ─── DatabaseConfig ───────────────────────────────────
public class DatabaseConfig
{
    public DatabaseType Type { get; set; }
    public string Name { get; set; }
    public string ConnectionString { get; set; }
    public Dictionary<string, object> Options { get; set; } = [];
}

// ─── QueueMessage<T> ─────────────────────────────────
public class QueueMessage<T>
{
    public string Id { get; set; }
    public string QueueName { get; set; }
    public T Body { get; set; }
    public Dictionary<string, string> Headers { get; set; } = [];
    public int Priority { get; set; } = 5;
    public DateTime EnqueuedAt { get; set; }
    public int DeliveryCount { get; set; }
    public string ConsumerGroup { get; set; }
}

// ─── AI Models ────────────────────────────────────────
public class AiRequest
{
    public string RequestId { get; set; } = Guid.NewGuid().ToString();
    public string Model { get; set; }
    public string SystemPrompt { get; set; }
    public string UserPrompt { get; set; }
    public List<AiMessage> Messages { get; set; } = [];
    public double Temperature { get; set; } = 0.7;
    public int MaxTokens { get; set; } = 4096;
    public string ResponseFormat { get; set; } // "json", "text", "code"
    public Dictionary<string, object> Metadata { get; set; } = [];
    public string TraceId { get; set; }
    public string StepId { get; set; }
}

public class AiMessage
{
    public string Role { get; set; } // "user", "assistant", "system"
    public string Content { get; set; }
}

public class AiResponse
{
    public string RequestId { get; set; }
    public string Model { get; set; }
    public string Content { get; set; }
    public AiUsage Usage { get; set; }
    public TimeSpan Duration { get; set; }
    public bool Success { get; set; }
    public string Error { get; set; }
    public Dictionary<string, object> Metadata { get; set; } = [];
}

public class AiUsage
{
    public int InputTokens { get; set; }
    public int OutputTokens { get; set; }
    public decimal EstimatedCost { get; set; }
}

public class AiStreamChunk
{
    public string Content { get; set; }
    public bool IsComplete { get; set; }
    public AiUsage Usage { get; set; }
}

public class AiModelInfo
{
    public string ModelId { get; set; }
    public string Provider { get; set; }
    public int MaxTokens { get; set; }
    public decimal CostPerInputToken { get; set; }
    public decimal CostPerOutputToken { get; set; }
    public bool SupportsStreaming { get; set; }
    public bool SupportsVision { get; set; }
}

// ─── Flow Models ──────────────────────────────────────
public class FlowTriggerRequest
{
    public string TraceId { get; set; } = Guid.NewGuid().ToString();
    public string FlowId { get; set; }
    public object Body { get; set; }
    public Dictionary<string, string> Headers { get; set; } = [];
    public string UserId { get; set; }
}

public class FlowStatusResponse
{
    public string TraceId { get; set; }
    public string FlowId { get; set; }
    public FlowStatus Status { get; set; }
    public string CurrentStep { get; set; }
    public double Progress { get; set; } // 0.0 - 1.0
    public object Result { get; set; }
    public List<StepStatus> Steps { get; set; } = [];
    public DateTime StartedAt { get; set; }
    public DateTime? CompletedAt { get; set; }
}

public class StepStatus
{
    public string StepId { get; set; }
    public string NodeType { get; set; }
    public FlowStatus Status { get; set; }
    public DateTime? StartedAt { get; set; }
    public DateTime? CompletedAt { get; set; }
    public object Input { get; set; }
    public object Output { get; set; }
    public string Error { get; set; }
}

// ─── Auth Models ──────────────────────────────────────
public class TokenValidationResult
{
    public bool IsValid { get; set; }
    public string UserId { get; set; }
    public string[] Roles { get; set; }
    public DateTime ExpiresAt { get; set; }
}

// ─── Health Check ─────────────────────────────────────
public class HealthCheckResult
{
    public bool Healthy { get; set; }
    public string ServiceName { get; set; }
    public string InstanceId { get; set; }
    public List<ComponentHealth> Checks { get; set; } = [];
    public DateTime CheckedAt { get; set; } = DateTime.UtcNow;
}

public class ComponentHealth
{
    public string Name { get; set; }
    public bool Healthy { get; set; }
    public string Error { get; set; }
    public TimeSpan? Latency { get; set; }
}

// ─── ConsumerGroupInfo ────────────────────────────────
public class ConsumerGroupInfo
{
    public string GroupName { get; set; }
    public int ConsumerCount { get; set; }
    public long PendingMessages { get; set; }
    public long ProcessedMessages { get; set; }
    public DateTime LastActivityAt { get; set; }
}

// ─── Feedback Models ──────────────────────────────────
public class FeedbackEntry
{
    public string FeedbackId { get; set; } = Guid.NewGuid().ToString();
    public string TraceId { get; set; }
    public string StepId { get; set; }
    public FeedbackRating Rating { get; set; }
    public string Text { get; set; }
    public string UserId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public Dictionary<string, object> Context { get; set; } = [];
}

// ─── Debug / Trace Models ─────────────────────────────
public class NodeDebugData
{
    public string DebugId { get; set; } = Guid.NewGuid().ToString();
    public string TraceId { get; set; }
    public string StepId { get; set; }
    public string NodeType { get; set; }
    public object Input { get; set; }
    public object IntermediateData { get; set; }
    public object Output { get; set; }
    public string PromptSent { get; set; }
    public string ResponseReceived { get; set; }
    public TimeSpan Duration { get; set; }
    public string Error { get; set; }
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
}
