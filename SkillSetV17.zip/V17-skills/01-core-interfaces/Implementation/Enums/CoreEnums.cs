// XIIGen.Core/Enums/CoreEnums.cs
// Skill 01 - Core Interfaces | .NET 9

namespace XIIGen.Core.Enums;

public enum DatabaseType
{
    Elasticsearch, MongoDB, PostgreSQL, Redis, MySQL, SqlServer, CosmosDb
}

public enum QueueType
{
    RedisStreams, RabbitMQ, AzureServiceBus, AwsSqs, Kafka
}

public enum QueryType
{
    Equal, Contains, GreaterThan, LessThan, GreaterEqual, LessEqual,
    Range, In, NotIn, Exists, NotExists, Prefix, Wildcard, Regex, Fuzzy
}

public enum AggregationType
{
    Sum, Average, Min, Max, Count, Terms, DateHistogram, Percentiles
}

public enum DataProcessStatus
{
    Success, Created, Updated, Deleted, NotFound, Error, Unauthorized,
    ValidationFailed, Timeout, Conflict, RateLimited
}

public enum AiModelType
{
    Claude, OpenAI, Gemini, Deepseek, Custom
}

public enum FlowStatus
{
    Draft, Active, Running, Paused, Completed, Failed, Cancelled, Archived
}

public enum NodeType
{
    Trigger, FigmaParser, AiTransform, AiReview, CodeGenerator,
    Feedback, Debug, Condition, Merge, Split, Delay, Custom,
    DocumentationGen, DesignSystem, SystemAnalyzer, Notification
}

public enum FeedbackRating
{
    Positive, Neutral, Negative
}
