// XIIGen.Core/Interfaces/IDatabaseService.cs
// Skill 01 - Core Interfaces | .NET 9

using XIIGen.Core.Enums;
using XIIGen.Core.Models;

namespace XIIGen.Core.Interfaces;

/// <summary>
/// Generic database interface - works with ANY database implementation.
/// Key: dynamic documents (no schemas), filter by non-empty fields only.
/// </summary>
public interface IDatabaseService
{
    DatabaseType DatabaseType { get; }

    Task<DataProcessResult<object>> StoreDocumentAsync(
        string indexName, string prefix, string id, object document,
        bool needToParse = true, CancellationToken ct = default);

    Task<DataProcessResult<List<object>>> SearchDocumentsAsync(
        string indexName, string prefix, object filter,
        int size = 10, CancellationToken ct = default);

    Task<DataProcessResult<object>> GetDocumentAsync(
        string indexName, string prefix, string id, CancellationToken ct = default);

    Task<DataProcessResult<Dictionary<string, long>>> GetFiltersAsync(
        string indexName, string prefix, string fieldName, CancellationToken ct = default);

    Task<DataProcessResult<Dictionary<string, long>>> GetFiltersFilteredAsync(
        string indexName, string prefix, string fieldName, object filter, CancellationToken ct = default);

    Task<DataProcessResult<bool>> DeleteDocumentAsync(
        string indexName, string prefix, string id, CancellationToken ct = default);

    Task<DataProcessResult<BulkResult>> BulkUpsertAsync(
        string indexName, string prefix, List<KeyValuePair<string, object>> documents, CancellationToken ct = default);

    Task<DataProcessResult<BulkResult>> BulkDeleteAsync(
        string indexName, string prefix, List<string> ids, CancellationToken ct = default);

    Task<DataProcessResult<T>> GetDocumentByFieldAsync<T>(
        string indexName, string prefix, string fieldName, string value, CancellationToken ct = default) where T : class, new();

    Task<DataProcessResult<Dictionary<string, object>>> AggregateAsync(
        string indexName, string prefix, object filter,
        Dictionary<string, string> aggregations, CancellationToken ct = default);

    Task<bool> IndexExistsAsync(string indexName, string prefix, CancellationToken ct = default);
    Task<DataProcessResult<bool>> CreateIndexAsync(string indexName, string prefix, CancellationToken ct = default);
}

// ─── IQueueService ────────────────────────────────────

/// <summary>
/// Generic queue interface with consumer group support.
/// Supports Redis Streams, RabbitMQ, Kafka, etc.
/// </summary>
public interface IQueueService
{
    QueueType QueueType { get; }

    Task<DataProcessResult<string>> EnqueueAsync<T>(
        string queueName, T message, Dictionary<string, string> headers = null,
        int priority = 5, CancellationToken ct = default);

    IAsyncEnumerable<QueueMessage<T>> ConsumeAsync<T>(
        string queueName, string consumerGroup, string consumerId, CancellationToken ct = default);

    Task<DataProcessResult<bool>> AcknowledgeAsync(
        string queueName, string consumerGroup, string messageId, CancellationToken ct = default);

    Task<DataProcessResult<bool>> RejectAsync(
        string queueName, string consumerGroup, string messageId,
        bool requeue = false, CancellationToken ct = default);

    Task<DataProcessResult<bool>> MoveToDeadLetterAsync(
        string queueName, string messageId, string reason, CancellationToken ct = default);

    Task<DataProcessResult<long>> GetQueueLengthAsync(string queueName, CancellationToken ct = default);

    Task<DataProcessResult<ConsumerGroupInfo>> GetConsumerGroupInfoAsync(
        string queueName, string consumerGroup, CancellationToken ct = default);

    Task<DataProcessResult<bool>> CreateConsumerGroupAsync(
        string queueName, string consumerGroup, CancellationToken ct = default);

    Task<DataProcessResult<bool>> PurgeQueueAsync(string queueName, CancellationToken ct = default);

    Task<DataProcessResult<QueueMessage<T>>> PeekAsync<T>(string queueName, CancellationToken ct = default);

    Task<bool> QueueExistsAsync(string queueName, CancellationToken ct = default);
    Task<DataProcessResult<bool>> CreateQueueAsync(string queueName, CancellationToken ct = default);
}

// ─── IAiProvider ──────────────────────────────────────

/// <summary>
/// Generic AI provider interface. Same contract for Claude, OpenAI, Gemini, Deepseek.
/// </summary>
public interface IAiProvider
{
    string ProviderName { get; }
    AiModelType ModelType { get; }

    Task<AiResponse> ExecuteAsync(AiRequest request, CancellationToken ct = default);
    IAsyncEnumerable<AiStreamChunk> StreamAsync(AiRequest request, CancellationToken ct = default);
    Task<AiModelInfo> GetModelInfoAsync(CancellationToken ct = default);
    Task<int> EstimateTokensAsync(string text, CancellationToken ct = default);
}

// ─── IObjectProcessor ─────────────────────────────────

/// <summary>
/// Dynamic document processor. Recursively parses JSON/objects,
/// infers types, builds query filters from non-empty fields.
/// </summary>
public interface IObjectProcessor
{
    Dictionary<string, object> ParseDocument(object document);
    List<SearchCondition> BuildQueryFilters(object filterObject);
    string InferFieldType(object value);
    Dictionary<string, object> FlattenDocument(object document, string prefix = "");
    object MergeDocuments(object original, object update);
    bool IsEmpty(object value);
}

// ─── ICacheService ────────────────────────────────────

public interface ICacheService
{
    Task<DataProcessResult<T>> GetAsync<T>(string key, CancellationToken ct = default);
    Task<DataProcessResult<bool>> SetAsync<T>(string key, T value, TimeSpan? expiration = null, CancellationToken ct = default);
    Task<DataProcessResult<bool>> DeleteAsync(string key, CancellationToken ct = default);
    Task<DataProcessResult<bool>> ExistsAsync(string key, CancellationToken ct = default);
    Task<DataProcessResult<T>> GetOrSetAsync<T>(string key, Func<Task<T>> factory, TimeSpan? expiration = null, CancellationToken ct = default);
    Task<DataProcessResult<bool>> InvalidateByPrefixAsync(string prefix, CancellationToken ct = default);
}

// ─── IPermissionsService ──────────────────────────────

public interface IPermissionsService
{
    Task<bool> HasPermissionAsync(string userId, string permission, CancellationToken ct = default);
    Task<bool> HasRoleAsync(string userId, string role, CancellationToken ct = default);
    Task<List<string>> GetPermissionsAsync(string userId, CancellationToken ct = default);
    Task<DataProcessResult<bool>> GrantPermissionAsync(string userId, string permission, CancellationToken ct = default);
    Task<DataProcessResult<bool>> RevokePermissionAsync(string userId, string permission, CancellationToken ct = default);
}

// ─── IAuthService ─────────────────────────────────────

public interface IAuthService
{
    Task<DataProcessResult<TokenValidationResult>> ValidateTokenAsync(string token, CancellationToken ct = default);
    Task<DataProcessResult<string>> GenerateTokenAsync(string userId, string[] roles, CancellationToken ct = default);
    Task<DataProcessResult<bool>> RevokeTokenAsync(string token, CancellationToken ct = default);
    Task<DataProcessResult<string>> RefreshTokenAsync(string refreshToken, CancellationToken ct = default);
}

// ─── IExternalService ─────────────────────────────────

public interface IExternalService
{
    string ServiceName { get; }
    Task<DataProcessResult<object>> CallAsync(string endpoint, object payload, Dictionary<string, string> headers = null, CancellationToken ct = default);
    Task<DataProcessResult<bool>> CheckHealthAsync(CancellationToken ct = default);
}

// ─── IStepExecutor ────────────────────────────────────
// Used by Flow Orchestrator to execute individual nodes

public interface IStepExecutor
{
    string NodeTypeName { get; }
    Task<StepExecutionResult> ExecuteAsync(StepExecutionContext context, CancellationToken ct = default);
}

public class StepExecutionContext
{
    public string TraceId { get; set; }
    public string StepId { get; set; }
    public string NodeType { get; set; }
    public object Input { get; set; }
    public Dictionary<string, object> Configuration { get; set; } = [];
    public Dictionary<string, object> PreviousStepOutputs { get; set; } = [];
    public List<FeedbackEntry> RelevantFeedback { get; set; } = [];
}

public class StepExecutionResult
{
    public bool Success { get; set; }
    public object Output { get; set; }
    public string Error { get; set; }
    public TimeSpan Duration { get; set; }
    public Dictionary<string, object> DebugData { get; set; } = [];

    public static StepExecutionResult Ok(object output, Dictionary<string, object> debug = null) => new()
    {
        Success = true, Output = output, DebugData = debug ?? []
    };

    public static StepExecutionResult Fail(string error) => new()
    {
        Success = false, Error = error
    };
}
