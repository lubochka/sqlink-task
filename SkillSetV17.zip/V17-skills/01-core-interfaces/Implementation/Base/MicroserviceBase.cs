// XIIGen.Core/Base/MicroserviceBase.cs
// Skill 01 - Core Interfaces | .NET 9
// Base class providing all 19 architectural components from Architecture.docx

using System.Collections.Concurrent;
using System.Diagnostics;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using XIIGen.Core.Enums;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Core.Base;

/// <summary>
/// Base class for ALL XIIGen microservices.
/// Provides 19 architectural components automatically.
/// </summary>
public abstract class MicroserviceBase : BackgroundService
{
    // ─── Core Injected Services ───────────────────────
    protected readonly IDatabaseService Database;
    protected readonly IQueueService Queue;
    protected readonly ILogger Logger;
    protected readonly ICacheService Cache;
    protected readonly IPermissionsService Permissions;
    protected readonly IAuthService Auth;
    protected readonly IObjectProcessor ObjectProcessor;

    // ─── Service Identity ─────────────────────────────
    protected string ServiceName { get; set; }
    protected string ServiceVersion { get; set; } = "1.0.0";
    protected string ServiceInstanceId { get; set; } = Guid.NewGuid().ToString();

    // ─── Component 6: Named Queues ────────────────────
    protected string MainQueue => $"{ServiceName}.main";
    protected string ConsumedQueue => $"{ServiceName}.consumed";
    protected string CreatedQueue => $"{ServiceName}.created";
    protected string ArchiveQueue => $"{ServiceName}.archive";

    // ─── Event System ─────────────────────────────────
    private readonly ConcurrentDictionary<string, List<Func<object, Task>>> _eventHandlers = new();

    // ─── Constructor ──────────────────────────────────
    protected MicroserviceBase(
        IDatabaseService database, IQueueService queue, ILogger logger,
        ICacheService cache = null, IPermissionsService permissions = null,
        IAuthService auth = null, IObjectProcessor objectProcessor = null)
    {
        Database = database ?? throw new ArgumentNullException(nameof(database));
        Queue = queue ?? throw new ArgumentNullException(nameof(queue));
        Logger = logger ?? throw new ArgumentNullException(nameof(logger));
        Cache = cache;
        Permissions = permissions;
        Auth = auth;
        ObjectProcessor = objectProcessor;
    }

    // ═══════════════════════════════════════════════════
    // COMPONENT 1: Database Operations
    // ═══════════════════════════════════════════════════

    protected async Task<DataProcessResult<object>> StoreDocumentAsync(
        string indexName, string id, object document, bool needToParse = true, CancellationToken ct = default)
    {
        try
        {
            return await Database.StoreDocumentAsync(indexName, ServiceName, id, document, needToParse, ct);
        }
        catch (Exception ex) { await LogErrorAsync($"Store failed: {indexName}/{id}", ex); return DataProcessResult<object>.Error(ex.Message); }
    }

    protected async Task<DataProcessResult<List<object>>> SearchDocumentsAsync(
        string indexName, object filter, int size = 10, CancellationToken ct = default)
    {
        try
        {
            return await Database.SearchDocumentsAsync(indexName, ServiceName, filter, size, ct);
        }
        catch (Exception ex) { await LogErrorAsync($"Search failed: {indexName}", ex); return DataProcessResult<List<object>>.Error(ex.Message); }
    }

    protected async Task<DataProcessResult<object>> GetDocumentAsync(
        string indexName, string id, CancellationToken ct = default)
    {
        try
        {
            return await Database.GetDocumentAsync(indexName, ServiceName, id, ct);
        }
        catch (Exception ex) { await LogErrorAsync($"Get failed: {indexName}/{id}", ex); return DataProcessResult<object>.Error(ex.Message); }
    }

    protected async Task<DataProcessResult<bool>> DeleteDocumentAsync(
        string indexName, string id, CancellationToken ct = default)
    {
        try
        {
            return await Database.DeleteDocumentAsync(indexName, ServiceName, id, ct);
        }
        catch (Exception ex) { await LogErrorAsync($"Delete failed: {indexName}/{id}", ex); return DataProcessResult<bool>.Error(ex.Message); }
    }

    // ═══════════════════════════════════════════════════
    // COMPONENT 2: Queue Operations
    // ═══════════════════════════════════════════════════

    protected async Task<DataProcessResult<string>> EnqueueAsync<T>(
        string queueName, T message, Dictionary<string, string> headers = null, int priority = 5, CancellationToken ct = default)
    {
        try
        {
            return await Queue.EnqueueAsync(queueName, message, headers, priority, ct);
        }
        catch (Exception ex) { await LogErrorAsync($"Enqueue failed: {queueName}", ex); return DataProcessResult<string>.Error(ex.Message); }
    }

    protected IAsyncEnumerable<QueueMessage<T>> ConsumeAsync<T>(
        string queueName, string consumerGroup, CancellationToken ct = default)
        => Queue.ConsumeAsync<T>(queueName, consumerGroup, ServiceInstanceId, ct);

    // ═══════════════════════════════════════════════════
    // COMPONENT 3: Permissions Check
    // ═══════════════════════════════════════════════════

    protected async Task<bool> CheckPermissionAsync(string permission, string userId = null)
    {
        if (Permissions is null) return true; // No permissions service = allow all
        try { return await Permissions.HasPermissionAsync(userId ?? ServiceInstanceId, permission); }
        catch (Exception ex) { await LogErrorAsync($"Permission check failed: {permission}", ex); return false; }
    }

    // ═══════════════════════════════════════════════════
    // COMPONENT 4: Query Request to Special Queue
    // ═══════════════════════════════════════════════════

    protected async Task<DataProcessResult<object>> QueryDataAsync(
        string query, Dictionary<string, string> parameters = null, CancellationToken ct = default)
    {
        var request = new { QueryId = Guid.NewGuid().ToString(), ServiceName, Query = query,
            Parameters = parameters ?? [], RequestedAt = DateTime.UtcNow };
        await EnqueueAsync("xiigen.queries.requests", request, ct: ct);
        await StoreDocumentAsync("query-requests", request.QueryId, request, ct: ct);
        return DataProcessResult<object>.Success(request);
    }

    // ═══════════════════════════════════════════════════
    // COMPONENT 5: Authentication Validation
    // ═══════════════════════════════════════════════════

    protected async Task<bool> ValidateTokenAsync(string token, CancellationToken ct = default)
    {
        if (Auth is null) return true;
        try
        {
            var result = await Auth.ValidateTokenAsync(token, ct);
            return result.IsSuccess && result.Data.IsValid;
        }
        catch (Exception ex) { await LogErrorAsync("Token validation failed", ex); return false; }
    }

    // ═══════════════════════════════════════════════════
    // COMPONENT 6: Queue Management (Main/Consumed/Created/Archive)
    // ═══════════════════════════════════════════════════

    protected Task<DataProcessResult<string>> PublishToMainQueueAsync<T>(T message, CancellationToken ct = default)
        => EnqueueAsync(MainQueue, message, ct: ct);

    protected Task<DataProcessResult<string>> ArchiveMessageAsync(object message, CancellationToken ct = default)
        => EnqueueAsync(ArchiveQueue, message, ct: ct);

    protected Task<DataProcessResult<string>> MarkConsumedAsync(object message, CancellationToken ct = default)
        => EnqueueAsync(ConsumedQueue, message, ct: ct);

    protected Task<DataProcessResult<string>> MarkCreatedAsync(object message, CancellationToken ct = default)
        => EnqueueAsync(CreatedQueue, message, ct: ct);

    // ═══════════════════════════════════════════════════
    // COMPONENT 7: GET Endpoints (Source of Truth)
    // ═══════════════════════════════════════════════════

    protected virtual async Task<DataProcessResult<object>> GetResourceAsync(
        string resourceType, string id, CancellationToken ct = default)
    {
        await LogInfoAsync($"GET {resourceType}/{id}");
        return await GetDocumentAsync(resourceType, id, ct);
    }

    // ═══════════════════════════════════════════════════
    // COMPONENT 8: Cache
    // ═══════════════════════════════════════════════════

    protected async Task<DataProcessResult<T>> GetCachedAsync<T>(string key, CancellationToken ct = default)
    {
        if (Cache is null) return DataProcessResult<T>.Error("Cache not configured");
        try { return await Cache.GetAsync<T>(key, ct); }
        catch (Exception ex) { await LogErrorAsync($"Cache get failed: {key}", ex); return DataProcessResult<T>.Error(ex.Message); }
    }

    protected async Task<DataProcessResult<bool>> SetCachedAsync<T>(string key, T value, TimeSpan? expiration = null, CancellationToken ct = default)
    {
        if (Cache is null) return DataProcessResult<bool>.Error("Cache not configured");
        try { return await Cache.SetAsync(key, value, expiration, ct); }
        catch (Exception ex) { await LogErrorAsync($"Cache set failed: {key}", ex); return DataProcessResult<bool>.Error(ex.Message); }
    }

    protected async Task<DataProcessResult<T>> GetOrCacheAsync<T>(string key, Func<Task<T>> factory, TimeSpan? exp = null, CancellationToken ct = default)
    {
        if (Cache is null) return DataProcessResult<T>.Success(await factory());
        return await Cache.GetOrSetAsync(key, factory, exp, ct);
    }

    // ═══════════════════════════════════════════════════
    // COMPONENT 9: Update Endpoints (Event-Driven)
    // ═══════════════════════════════════════════════════

    protected Task PublishUpdateEventAsync(string eventType, object data, CancellationToken ct = default)
        => PublishEventAsync($"update.{eventType}", data, ct);

    // ═══════════════════════════════════════════════════
    // COMPONENT 10: Kubernetes Health Checks
    // ═══════════════════════════════════════════════════

    public virtual async Task<HealthCheckResult> CheckHealthAsync()
    {
        var checks = new List<ComponentHealth>();
        var sw = Stopwatch.StartNew();

        try { await Database.IndexExistsAsync("health", ServiceName); checks.Add(new() { Name = "Database", Healthy = true, Latency = sw.Elapsed }); }
        catch (Exception ex) { checks.Add(new() { Name = "Database", Healthy = false, Error = ex.Message }); }

        sw.Restart();
        try { await Queue.QueueExistsAsync(MainQueue); checks.Add(new() { Name = "Queue", Healthy = true, Latency = sw.Elapsed }); }
        catch (Exception ex) { checks.Add(new() { Name = "Queue", Healthy = false, Error = ex.Message }); }

        if (Cache is not null)
        {
            sw.Restart();
            try { await Cache.SetAsync("health", DateTime.UtcNow, TimeSpan.FromSeconds(10)); checks.Add(new() { Name = "Cache", Healthy = true, Latency = sw.Elapsed }); }
            catch (Exception ex) { checks.Add(new() { Name = "Cache", Healthy = false, Error = ex.Message }); }
        }

        return new HealthCheckResult { Healthy = checks.TrueForAll(c => c.Healthy), ServiceName = ServiceName, InstanceId = ServiceInstanceId, Checks = checks };
    }

    // ═══════════════════════════════════════════════════
    // COMPONENT 11: Logger
    // ═══════════════════════════════════════════════════

    protected Task LogInfoAsync(string message, object data = null)
    { Logger.LogInformation("[{Svc}:{Inst}] {Msg}", ServiceName, ServiceInstanceId[..8], message); return Task.CompletedTask; }

    protected Task LogErrorAsync(string message, Exception ex = null)
    { if (ex is not null) Logger.LogError(ex, "[{Svc}:{Inst}] {Msg}", ServiceName, ServiceInstanceId[..8], message);
      else Logger.LogError("[{Svc}:{Inst}] {Msg}", ServiceName, ServiceInstanceId[..8], message); return Task.CompletedTask; }

    protected Task LogWarnAsync(string message)
    { Logger.LogWarning("[{Svc}:{Inst}] {Msg}", ServiceName, ServiceInstanceId[..8], message); return Task.CompletedTask; }

    // ═══════════════════════════════════════════════════
    // COMPONENT 12: Data Validation
    // ═══════════════════════════════════════════════════

    protected virtual Task<bool> ValidateDataAsync(object data, object schema = null) => Task.FromResult(data is not null);

    // ═══════════════════════════════════════════════════
    // COMPONENT 13: Event Orchestration
    // ═══════════════════════════════════════════════════

    protected async Task PublishEventAsync(string eventType, object data, CancellationToken ct = default)
    {
        var evt = new { EventId = Guid.NewGuid().ToString(), EventType = eventType, ServiceName,
            InstanceId = ServiceInstanceId, Data = data, PublishedAt = DateTime.UtcNow };
        await EnqueueAsync($"xiigen.events.{eventType}", evt, ct: ct);
        await StoreDocumentAsync("events-archive", evt.EventId, evt, ct: ct);
    }

    protected void SubscribeToEvent(string eventType, Func<object, Task> handler)
    {
        _eventHandlers.AddOrUpdate(eventType,
            _ => [handler],
            (_, list) => { list.Add(handler); return list; });
    }

    protected async Task DispatchEventAsync(string eventType, object data)
    {
        if (_eventHandlers.TryGetValue(eventType, out var handlers))
            foreach (var h in handlers)
                try { await h(data); } catch (Exception ex) { await LogErrorAsync($"Event handler error: {eventType}", ex); }
    }

    // ═══════════════════════════════════════════════════
    // COMPONENT 14: 3rd Party Communications
    // ═══════════════════════════════════════════════════

    protected async Task<DataProcessResult<object>> CallExternalServiceAsync(
        string serviceName, string endpoint, object payload, CancellationToken ct = default)
    {
        await LogInfoAsync($"External call: {serviceName}/{endpoint}");
        var log = new { CallId = Guid.NewGuid().ToString(), ServiceName = serviceName, Endpoint = endpoint,
            Payload = payload, CalledAt = DateTime.UtcNow, CallingService = ServiceName };
        await StoreDocumentAsync("external-calls", log.CallId, log, ct: ct);
        return DataProcessResult<object>.Success(log);
    }

    // ═══════════════════════════════════════════════════
    // COMPONENT 15: Sanity Check
    // ═══════════════════════════════════════════════════

    protected virtual async Task<bool> PerformSanityCheckAsync()
    {
        var health = await CheckHealthAsync();
        if (!health.Healthy) { await LogErrorAsync("Sanity check failed"); return false; }
        return true;
    }

    // ═══════════════════════════════════════════════════
    // COMPONENT 16: Test Data Generator
    // ═══════════════════════════════════════════════════

    protected virtual Task<object> GenerateTestDataAsync(string entityType)
        => Task.FromResult<object>(new { Id = Guid.NewGuid().ToString(), Type = entityType, CreatedAt = DateTime.UtcNow, TestData = true });

    // ═══════════════════════════════════════════════════
    // COMPONENT 17: Test Scenarios
    // ═══════════════════════════════════════════════════

    protected virtual async Task<bool> RunTestScenarioAsync(string scenarioName)
    {
        await LogInfoAsync($"Running test: {scenarioName}");
        return true;
    }

    // ═══════════════════════════════════════════════════
    // COMPONENT 18: Safe Shutdown
    // ═══════════════════════════════════════════════════

    public virtual async Task ShutdownAsync(CancellationToken ct)
    {
        await LogInfoAsync("Graceful shutdown starting");
        // Derived services override to drain queues, complete in-flight work, persist state
        await LogInfoAsync("Shutdown complete");
    }

    public override async Task StopAsync(CancellationToken ct)
    {
        await ShutdownAsync(ct);
        await base.StopAsync(ct);
    }

    // ═══════════════════════════════════════════════════
    // COMPONENT 19: Orchestration Events Management
    // ═══════════════════════════════════════════════════

    protected async Task RegisterEventHandlerAsync(string eventType)
    {
        var reg = new { ServiceName, InstanceId = ServiceInstanceId, EventType = eventType, RegisteredAt = DateTime.UtcNow };
        await StoreDocumentAsync("event-subscriptions", $"{ServiceName}:{eventType}", reg);
    }

    protected Task UnregisterEventHandlerAsync(string eventType)
        => DeleteDocumentAsync("event-subscriptions", $"{ServiceName}:{eventType}");

    protected async Task RegisterActionAsync(string actionName, Func<object, Task<object>> handler)
    {
        var reg = new { ServiceName, ActionName = actionName, RegisteredAt = DateTime.UtcNow };
        await StoreDocumentAsync("action-registrations", $"{ServiceName}:{actionName}", reg);
    }

    // ═══════════════════════════════════════════════════
    // BackgroundService Implementation
    // ═══════════════════════════════════════════════════

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        await LogInfoAsync($"Starting {ServiceName} v{ServiceVersion}");
        if (!await PerformSanityCheckAsync()) { await LogErrorAsync("Startup sanity check failed"); return; }

        await OnStartedAsync(stoppingToken);

        while (!stoppingToken.IsCancellationRequested)
        {
            try { await ProcessAsync(stoppingToken); }
            catch (OperationCanceledException) { break; }
            catch (Exception ex) { await LogErrorAsync("Processing error", ex); await Task.Delay(1000, stoppingToken); }
        }

        await LogInfoAsync($"Stopping {ServiceName}");
    }

    protected virtual Task OnStartedAsync(CancellationToken ct) => Task.CompletedTask;
    protected virtual Task ProcessAsync(CancellationToken ct) => Task.Delay(1000, ct);
}
