# Skill 01: Core Interfaces & MicroserviceBase
## The Foundation of XIIGen — Every service implements these contracts

**Status:** Ready to Generate  
**Priority:** P0 — Must be first, everything depends on this  
**Dependencies:** None  
**Layer:** L1: Foundation  
**Phase:** 1  
**Estimated LOC:** ~950  

---

## Overview

XIIGen's **universal plug system**. Every microservice, database driver, AI provider, and queue implementation connects through these interfaces. Key innovation: **dynamic documents** — no fixed schemas, no migrations. Send any JSON, store it, query back with automatic empty-field filtering.

MicroserviceBase provides 19 architectural capabilities to any inheriting service.

## Key Concepts

- **DataProcessResult\<T\>** — `{Status, Data, Message}` return pattern. Never throw for business logic.
- **Dynamic Documents** — `object` in/out. ObjectProcessor (Skill 02) handles parsing.
- **Filter by Non-Empty** — Pass filter object; only non-null fields become query conditions.
- **MicroserviceBase** — Inherits BackgroundService with 19 components.
- **CancellationToken Everywhere** — Graceful shutdown support on all async methods.

---

## Primary Implementation (.NET 9)

### Enums

```csharp
// File: XIIGen.Core/Enums/CoreEnums.cs
namespace XIIGen.Core.Enums;

public enum DataProcessStatus { Success, NotFound, Error, ValidationError, Unauthorized, Conflict, Timeout }
public enum DatabaseType { Elasticsearch, MongoDb, PostgreSql, Redis, CosmosDb, Neo4j, InMemory }
public enum QueueType { RedisStreams, RabbitMQ, Kafka, AzureServiceBus, SQS, InMemory }
public enum QueryType { Equals, Contains, GreaterThan, LessThan, Between, In, NotEquals, Exists, Prefix, Regex, Fuzzy }
public enum AiProviderType { Claude, OpenAi, Gemini, DeepSeek, Local }
public enum CacheStrategy { WriteThrough, WriteBack, ReadThrough, CacheAside }
```

### Models

```csharp
// File: XIIGen.Core/Models/CoreModels.cs
namespace XIIGen.Core.Models;

public record DataProcessResult<T>(
    DataProcessStatus Status = DataProcessStatus.Success, T? Data = default,
    string Message = "", Dictionary<string, object>? Metadata = null
) {
    public bool IsSuccess => Status == DataProcessStatus.Success;
    public static DataProcessResult<T> Ok(T data, string msg = "") => new(Data: data, Message: msg);
    public static DataProcessResult<T> Fail(string msg, DataProcessStatus s = DataProcessStatus.Error) => new(Status: s, Message: msg);
    public static DataProcessResult<T> NotFound(string msg = "Not found") => new(Status: DataProcessStatus.NotFound, Message: msg);
}

public record SearchCondition { public string Property { get; init; } = ""; public QueryType QueryType { get; init; } = QueryType.Equals; public object? Value { get; init; }; public object? ValueTo { get; init; } }
public record QueueMessage<T>(string Id, string QueueName, T Payload, Dictionary<string, string> Headers, int Priority = 5, int RetryCount = 0, DateTime EnqueuedAt = default);
public record BulkResult(int Succeeded, int Failed, List<string> Errors);
public record AiRequest(string Prompt, string? SystemPrompt = null, string? Model = null, float Temperature = 0.7f, int MaxTokens = 4096, List<AiMessage>? History = null, Dictionary<string, object>? Metadata = null);
public record AiResponse(string Content, string Model, int InputTokens, int OutputTokens, float DurationMs, Dictionary<string, object>? Metadata = null);
public record AiMessage(string Role, string Content);
public record PaginatedResult<T>(List<T> Items, int Total, int Page, int PageSize);
```

### Interfaces

```csharp
// File: XIIGen.Core/Interfaces/IDatabaseService.cs
namespace XIIGen.Core.Interfaces;

public interface IDatabaseService
{
    DatabaseType DatabaseType { get; }
    Task<DataProcessResult<object>> StoreDocumentAsync(string indexName, string prefix, string id, object document, bool needToParse = true, CancellationToken ct = default);
    Task<DataProcessResult<List<object>>> SearchDocumentsAsync(string indexName, string prefix, object filter, int size = 10, CancellationToken ct = default);
    Task<DataProcessResult<object>> GetDocumentAsync(string indexName, string prefix, string id, CancellationToken ct = default);
    Task<DataProcessResult<bool>> DeleteDocumentAsync(string indexName, string prefix, string id, CancellationToken ct = default);
    Task<DataProcessResult<BulkResult>> BulkUpsertAsync(string indexName, string prefix, List<KeyValuePair<string, object>> documents, CancellationToken ct = default);
    Task<DataProcessResult<BulkResult>> BulkDeleteAsync(string indexName, string prefix, List<string> ids, CancellationToken ct = default);
    Task<DataProcessResult<Dictionary<string, long>>> GetFiltersAsync(string indexName, string prefix, string fieldName, CancellationToken ct = default);
    Task<DataProcessResult<Dictionary<string, long>>> GetFiltersFilteredAsync(string indexName, string prefix, string fieldName, object filter, CancellationToken ct = default);
    Task<DataProcessResult<T>> GetDocumentByFieldAsync<T>(string indexName, string prefix, string fieldName, string value, CancellationToken ct = default) where T : class, new();
    Task<DataProcessResult<Dictionary<string, object>>> AggregateAsync(string indexName, string prefix, object filter, Dictionary<string, string> aggregations, CancellationToken ct = default);
    Task<bool> IndexExistsAsync(string indexName, string prefix, CancellationToken ct = default);
    Task<DataProcessResult<bool>> CreateIndexAsync(string indexName, string prefix, CancellationToken ct = default);
}

public interface IQueueService
{
    QueueType QueueType { get; }
    Task<DataProcessResult<string>> EnqueueAsync<T>(string queueName, T message, Dictionary<string, string>? headers = null, int priority = 5, CancellationToken ct = default);
    IAsyncEnumerable<QueueMessage<T>> ConsumeAsync<T>(string queueName, string consumerGroup, string consumerId, CancellationToken ct = default);
    Task<DataProcessResult<bool>> AcknowledgeAsync(string queueName, string consumerGroup, string messageId, CancellationToken ct = default);
    Task<DataProcessResult<bool>> RejectAsync(string queueName, string consumerGroup, string messageId, bool requeue = false, CancellationToken ct = default);
    Task<DataProcessResult<bool>> MoveToDeadLetterAsync(string queueName, string messageId, string reason, CancellationToken ct = default);
    Task<DataProcessResult<long>> GetQueueLengthAsync(string queueName, CancellationToken ct = default);
}

public interface IAiProvider
{
    AiProviderType ProviderType { get; }
    Task<DataProcessResult<AiResponse>> CompleteAsync(AiRequest request, CancellationToken ct = default);
    Task<DataProcessResult<AiResponse>> CompleteWithContextAsync(AiRequest request, List<string> ragContext, CancellationToken ct = default);
    IAsyncEnumerable<string> StreamAsync(AiRequest request, CancellationToken ct = default);
}

public interface IObjectProcessor
{
    Dictionary<string, object> ParseDocument(object document);
    List<SearchCondition> BuildQueryFilters(object filterObject);
    string InferFieldType(object value);
    T MapTo<T>(Dictionary<string, object> document) where T : new();
}

public interface ICacheService
{
    Task<T?> GetAsync<T>(string key, CancellationToken ct = default);
    Task SetAsync<T>(string key, T value, TimeSpan? expiry = null, CancellationToken ct = default);
    Task RemoveAsync(string key, CancellationToken ct = default);
    Task<bool> ExistsAsync(string key, CancellationToken ct = default);
}

public interface IPermissionsService
{
    Task<DataProcessResult<bool>> CheckPermissionAsync(string entityId, string resource, string action, CancellationToken ct = default);
    Task<DataProcessResult<List<string>>> GetPermissionsAsync(string entityId, CancellationToken ct = default);
}
```

### MicroserviceBase

```csharp
// File: XIIGen.Core/Base/MicroserviceBase.cs
namespace XIIGen.Core.Base;

public abstract class MicroserviceBase : BackgroundService
{
    protected string ServiceName { get; set; } = "unnamed";
    protected readonly IDatabaseService Db;
    protected readonly IQueueService Queue;
    protected readonly ILogger Logger;
    protected ICacheService? Cache { get; init; }
    protected IPermissionsService? Permissions { get; init; }
    protected IObjectProcessor? ObjectProcessor { get; init; }

    protected string MainQueue => $"{ServiceName}-main";
    protected string ConsumedQueue => $"{ServiceName}-consumed";
    protected string ArchiveQueue => $"{ServiceName}-archive";

    protected MicroserviceBase(IDatabaseService db, IQueueService queue, ILogger logger)
    { Db = db; Queue = queue; Logger = logger; }

    protected Task<DataProcessResult<object>> StoreDocumentAsync(string index, string id, object doc, CancellationToken ct = default)
        => Db.StoreDocumentAsync(index, ServiceName, id, doc, ct: ct);

    protected Task<DataProcessResult<List<object>>> SearchDocumentsAsync(string index, object filter, int size = 10, CancellationToken ct = default)
        => Db.SearchDocumentsAsync(index, ServiceName, filter, size, ct);

    protected Task<DataProcessResult<string>> PublishAsync<T>(T message, CancellationToken ct = default)
        => Queue.EnqueueAsync(MainQueue, message, ct: ct);

    public override async Task StopAsync(CancellationToken ct)
    {
        Logger.LogInformation("{Service} shutting down gracefully...", ServiceName);
        await base.StopAsync(ct);
    }
}
```

### DI Registration

```csharp
public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddXIIGenCore(this IServiceCollection services)
    {
        services.AddSingleton<IObjectProcessor, ObjectProcessor>();
        return services;
    }
}
```

---

## Unit Tests

```csharp
[Fact] public void DataProcessResult_Ok_SetsSuccess()
{
    var r = DataProcessResult<string>.Ok("hello");
    Assert.True(r.IsSuccess);
    Assert.Equal("hello", r.Data);
}
[Fact] public void DataProcessResult_Fail_SetsError()
{
    var r = DataProcessResult<int>.Fail("broken");
    Assert.False(r.IsSuccess);
    Assert.Equal(DataProcessStatus.Error, r.Status);
}
```

## Anti-Patterns
- **Don't** create fixed model classes for stored documents — use dynamic `object` + ParseDocument
- **Don't** throw exceptions for business logic — return `DataProcessResult.Fail(...)`
- **Don't** bypass CancellationToken — always pass it for graceful shutdown
- **Don't** access Db/Queue directly from controllers — go through service layer
