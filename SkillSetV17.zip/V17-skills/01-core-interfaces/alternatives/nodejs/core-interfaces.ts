// Skill 01: Core Interfaces — Node.js/TypeScript
// Equivalent of XIIGen.Core — all interfaces + base class

export enum DataProcessStatus { Success = "success", NotFound = "not_found", Error = "error", ValidationError = "validation_error", Unauthorized = "unauthorized", Conflict = "conflict", Timeout = "timeout" }
export enum DatabaseType { Elasticsearch = "elasticsearch", MongoDb = "mongodb", PostgreSql = "postgresql", Redis = "redis", CosmosDb = "cosmosdb", Neo4j = "neo4j", InMemory = "in_memory" }
export enum QueueType { RedisStreams = "redis_streams", RabbitMQ = "rabbitmq", Kafka = "kafka", SQS = "sqs", InMemory = "in_memory" }
export enum QueryType { Equals = "eq", Contains = "contains", GreaterThan = "gt", LessThan = "lt", Between = "between", In = "in", NotEquals = "ne", Exists = "exists", Prefix = "prefix", Regex = "regex", Fuzzy = "fuzzy" }
export enum AiProviderType { Claude = "claude", OpenAi = "openai", Gemini = "gemini", DeepSeek = "deepseek", Local = "local" }

// ─── Models ───
export interface DataProcessResult<T> { status: DataProcessStatus; data?: T; message: string; metadata?: Record<string, unknown>; }
export const ok = <T>(data: T, msg = ""): DataProcessResult<T> => ({ status: DataProcessStatus.Success, data, message: msg });
export const fail = <T>(msg: string, status = DataProcessStatus.Error): DataProcessResult<T> => ({ status, message: msg });
export const notFound = <T>(msg = "Not found"): DataProcessResult<T> => ({ status: DataProcessStatus.NotFound, message: msg });

export interface SearchCondition { property: string; queryType: QueryType; value: unknown; valueTo?: unknown; }
export interface QueueMessage<T> { id: string; queueName: string; payload: T; headers: Record<string, string>; priority: number; retryCount: number; enqueuedAt: Date; }
export interface BulkResult { succeeded: number; failed: number; errors: string[]; }
export interface AiRequest { prompt: string; systemPrompt?: string; model?: string; temperature?: number; maxTokens?: number; history?: { role: string; content: string }[]; metadata?: Record<string, unknown>; }
export interface AiResponse { content: string; model: string; inputTokens: number; outputTokens: number; durationMs: number; metadata?: Record<string, unknown>; }

// ─── Interfaces ───
export interface IDatabaseService {
  readonly databaseType: DatabaseType;
  storeDocument(indexName: string, prefix: string, id: string, document: unknown, needToParse?: boolean): Promise<DataProcessResult<unknown>>;
  searchDocuments(indexName: string, prefix: string, filter: unknown, size?: number): Promise<DataProcessResult<unknown[]>>;
  getDocument(indexName: string, prefix: string, id: string): Promise<DataProcessResult<unknown>>;
  deleteDocument(indexName: string, prefix: string, id: string): Promise<DataProcessResult<boolean>>;
  bulkUpsert(indexName: string, prefix: string, documents: Array<{ key: string; value: unknown }>): Promise<DataProcessResult<BulkResult>>;
  bulkDelete(indexName: string, prefix: string, ids: string[]): Promise<DataProcessResult<BulkResult>>;
  getFilters(indexName: string, prefix: string, fieldName: string): Promise<DataProcessResult<Record<string, number>>>;
  aggregate(indexName: string, prefix: string, filter: unknown, aggregations: Record<string, string>): Promise<DataProcessResult<Record<string, unknown>>>;
  indexExists(indexName: string, prefix: string): Promise<boolean>;
  createIndex(indexName: string, prefix: string): Promise<DataProcessResult<boolean>>;
}

export interface IQueueService {
  readonly queueType: QueueType;
  enqueue<T>(queueName: string, message: T, headers?: Record<string, string>, priority?: number): Promise<DataProcessResult<string>>;
  consume<T>(queueName: string, consumerGroup: string, consumerId: string, signal: AbortSignal): AsyncGenerator<QueueMessage<T>>;
  acknowledge(queueName: string, consumerGroup: string, messageId: string): Promise<DataProcessResult<boolean>>;
  reject(queueName: string, consumerGroup: string, messageId: string, requeue?: boolean): Promise<DataProcessResult<boolean>>;
  moveToDeadLetter(queueName: string, messageId: string, reason: string): Promise<DataProcessResult<boolean>>;
  getQueueLength(queueName: string): Promise<DataProcessResult<number>>;
}

export interface IAiProvider {
  readonly providerType: AiProviderType;
  complete(request: AiRequest): Promise<DataProcessResult<AiResponse>>;
  completeWithContext(request: AiRequest, ragContext: string[]): Promise<DataProcessResult<AiResponse>>;
  stream(request: AiRequest, signal: AbortSignal): AsyncGenerator<string>;
}

export interface IObjectProcessor {
  parseDocument(document: unknown): Record<string, unknown>;
  buildQueryFilters(filterObject: unknown): SearchCondition[];
  inferFieldType(value: unknown): string;
}

export interface ICacheService {
  get<T>(key: string): Promise<T | null>;
  set<T>(key: string, value: T, expiryMs?: number): Promise<void>;
  remove(key: string): Promise<void>;
  exists(key: string): Promise<boolean>;
}

// ─── MicroserviceBase ───
export abstract class MicroserviceBase {
  protected serviceName = "unnamed";
  protected db: IDatabaseService;
  protected queue: IQueueService;
  protected logger: Console;
  protected cache?: ICacheService;
  protected objectProcessor?: IObjectProcessor;
  private abortController = new AbortController();

  constructor(db: IDatabaseService, queue: IQueueService, logger = console) {
    this.db = db; this.queue = queue; this.logger = logger;
  }

  get mainQueue() { return `${this.serviceName}-main`; }
  get consumedQueue() { return `${this.serviceName}-consumed`; }
  get archiveQueue() { return `${this.serviceName}-archive`; }

  protected storeDocument(index: string, id: string, doc: unknown) {
    return this.db.storeDocument(index, this.serviceName, id, doc);
  }
  protected searchDocuments(index: string, filter: unknown, size = 10) {
    return this.db.searchDocuments(index, this.serviceName, filter, size);
  }
  protected publish<T>(message: T) {
    return this.queue.enqueue(this.mainQueue, message);
  }

  async start() { this.logger.info(`${this.serviceName} starting...`); }
  async shutdown() {
    this.logger.info(`${this.serviceName} shutting down...`);
    this.abortController.abort();
  }
}
