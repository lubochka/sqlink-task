# Skill 01: Core Interfaces — Python / FastAPI
# Equivalent of XIIGen.Core — all interfaces + base class

from enum import Enum
from dataclasses import dataclass, field
from typing import Any, AsyncGenerator, Optional
from abc import ABC, abstractmethod
from datetime import datetime
import logging

# ─── Enums ───
class DataProcessStatus(str, Enum):
    SUCCESS = "success"; NOT_FOUND = "not_found"; ERROR = "error"
    VALIDATION_ERROR = "validation_error"; UNAUTHORIZED = "unauthorized"
    CONFLICT = "conflict"; TIMEOUT = "timeout"

class DatabaseType(str, Enum):
    ELASTICSEARCH = "elasticsearch"; MONGODB = "mongodb"; POSTGRESQL = "postgresql"
    REDIS = "redis"; COSMOSDB = "cosmosdb"; NEO4J = "neo4j"; IN_MEMORY = "in_memory"

class QueueType(str, Enum):
    REDIS_STREAMS = "redis_streams"; RABBITMQ = "rabbitmq"; KAFKA = "kafka"
    SQS = "sqs"; IN_MEMORY = "in_memory"

class QueryType(str, Enum):
    EQUALS = "eq"; CONTAINS = "contains"; GT = "gt"; LT = "lt"
    BETWEEN = "between"; IN = "in"; NOT_EQUALS = "ne"; EXISTS = "exists"
    PREFIX = "prefix"; REGEX = "regex"; FUZZY = "fuzzy"

class AiProviderType(str, Enum):
    CLAUDE = "claude"; OPENAI = "openai"; GEMINI = "gemini"
    DEEPSEEK = "deepseek"; LOCAL = "local"

# ─── Models ───
@dataclass
class DataProcessResult:
    status: DataProcessStatus = DataProcessStatus.SUCCESS
    data: Any = None
    message: str = ""
    metadata: dict[str, Any] | None = None

    @property
    def is_success(self) -> bool: return self.status == DataProcessStatus.SUCCESS

    @staticmethod
    def ok(data: Any, msg: str = "") -> "DataProcessResult":
        return DataProcessResult(data=data, message=msg)

    @staticmethod
    def fail(msg: str, status: DataProcessStatus = DataProcessStatus.ERROR) -> "DataProcessResult":
        return DataProcessResult(status=status, message=msg)

    @staticmethod
    def not_found(msg: str = "Not found") -> "DataProcessResult":
        return DataProcessResult(status=DataProcessStatus.NOT_FOUND, message=msg)

@dataclass
class SearchCondition:
    property: str = ""
    query_type: QueryType = QueryType.EQUALS
    value: Any = None
    value_to: Any = None

@dataclass
class QueueMessage:
    id: str = ""
    queue_name: str = ""
    payload: Any = None
    headers: dict[str, str] = field(default_factory=dict)
    priority: int = 5
    retry_count: int = 0
    enqueued_at: datetime = field(default_factory=datetime.utcnow)

@dataclass
class BulkResult:
    succeeded: int = 0; failed: int = 0; errors: list[str] = field(default_factory=list)

@dataclass
class AiRequest:
    prompt: str = ""
    system_prompt: str | None = None
    model: str | None = None
    temperature: float = 0.7
    max_tokens: int = 4096
    history: list[dict[str, str]] | None = None
    metadata: dict[str, Any] | None = None

@dataclass
class AiResponse:
    content: str = ""
    model: str = ""
    input_tokens: int = 0
    output_tokens: int = 0
    duration_ms: float = 0.0
    metadata: dict[str, Any] | None = None

# ─── Interfaces (ABCs) ───
class IDatabaseService(ABC):
    @property
    @abstractmethod
    def database_type(self) -> DatabaseType: ...

    @abstractmethod
    async def store_document(self, index_name: str, prefix: str, id: str, document: Any, need_to_parse: bool = True) -> DataProcessResult: ...
    @abstractmethod
    async def search_documents(self, index_name: str, prefix: str, filter_obj: Any, size: int = 10) -> DataProcessResult: ...
    @abstractmethod
    async def get_document(self, index_name: str, prefix: str, id: str) -> DataProcessResult: ...
    @abstractmethod
    async def delete_document(self, index_name: str, prefix: str, id: str) -> DataProcessResult: ...
    @abstractmethod
    async def bulk_upsert(self, index_name: str, prefix: str, documents: list[tuple[str, Any]]) -> DataProcessResult: ...
    @abstractmethod
    async def bulk_delete(self, index_name: str, prefix: str, ids: list[str]) -> DataProcessResult: ...
    @abstractmethod
    async def get_filters(self, index_name: str, prefix: str, field_name: str) -> DataProcessResult: ...
    @abstractmethod
    async def aggregate(self, index_name: str, prefix: str, filter_obj: Any, aggregations: dict[str, str]) -> DataProcessResult: ...
    @abstractmethod
    async def index_exists(self, index_name: str, prefix: str) -> bool: ...
    @abstractmethod
    async def create_index(self, index_name: str, prefix: str) -> DataProcessResult: ...

class IQueueService(ABC):
    @property
    @abstractmethod
    def queue_type(self) -> QueueType: ...

    @abstractmethod
    async def enqueue(self, queue_name: str, message: Any, headers: dict[str, str] | None = None, priority: int = 5) -> DataProcessResult: ...
    @abstractmethod
    async def consume(self, queue_name: str, consumer_group: str, consumer_id: str) -> AsyncGenerator[QueueMessage, None]: ...
    @abstractmethod
    async def acknowledge(self, queue_name: str, consumer_group: str, message_id: str) -> DataProcessResult: ...
    @abstractmethod
    async def reject(self, queue_name: str, consumer_group: str, message_id: str, requeue: bool = False) -> DataProcessResult: ...

class IAiProvider(ABC):
    @property
    @abstractmethod
    def provider_type(self) -> AiProviderType: ...

    @abstractmethod
    async def complete(self, request: AiRequest) -> DataProcessResult: ...
    @abstractmethod
    async def complete_with_context(self, request: AiRequest, rag_context: list[str]) -> DataProcessResult: ...
    @abstractmethod
    async def stream(self, request: AiRequest) -> AsyncGenerator[str, None]: ...

class IObjectProcessor(ABC):
    @abstractmethod
    def parse_document(self, document: Any) -> dict[str, Any]: ...
    @abstractmethod
    def build_query_filters(self, filter_object: Any) -> list[SearchCondition]: ...
    @abstractmethod
    def infer_field_type(self, value: Any) -> str: ...

class ICacheService(ABC):
    @abstractmethod
    async def get(self, key: str) -> Any | None: ...
    @abstractmethod
    async def set(self, key: str, value: Any, expiry_seconds: int | None = None) -> None: ...
    @abstractmethod
    async def remove(self, key: str) -> None: ...
    @abstractmethod
    async def exists(self, key: str) -> bool: ...

# ─── MicroserviceBase ───
class MicroserviceBase(ABC):
    def __init__(self, db: IDatabaseService, queue: IQueueService, logger: logging.Logger | None = None):
        self.service_name = "unnamed"
        self.db = db
        self.queue = queue
        self.logger = logger or logging.getLogger(self.__class__.__name__)
        self.cache: ICacheService | None = None
        self.object_processor: IObjectProcessor | None = None
        self._running = False

    @property
    def main_queue(self) -> str: return f"{self.service_name}-main"
    @property
    def consumed_queue(self) -> str: return f"{self.service_name}-consumed"
    @property
    def archive_queue(self) -> str: return f"{self.service_name}-archive"

    async def store(self, index: str, id: str, doc: Any) -> DataProcessResult:
        return await self.db.store_document(index, self.service_name, id, doc)

    async def search(self, index: str, filter_obj: Any, size: int = 10) -> DataProcessResult:
        return await self.db.search_documents(index, self.service_name, filter_obj, size)

    async def publish(self, message: Any) -> DataProcessResult:
        return await self.queue.enqueue(self.main_queue, message)

    async def start(self):
        self._running = True
        self.logger.info(f"{self.service_name} starting...")

    async def shutdown(self):
        self._running = False
        self.logger.info(f"{self.service_name} shutting down...")
