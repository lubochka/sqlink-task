// Skill 01: Core Interfaces — Rust / Axum
// Equivalent of XIIGen.Core — all traits + base struct

use async_trait::async_trait;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use tokio::sync::broadcast;

// ─── Enums ───
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum DataProcessStatus { Success, NotFound, Error, ValidationError, Unauthorized, Conflict, Timeout }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum DatabaseType { Elasticsearch, MongoDb, PostgreSql, Redis, CosmosDb, Neo4j, InMemory }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum QueueType { RedisStreams, RabbitMQ, Kafka, Sqs, InMemory }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum QueryType { Equals, Contains, GreaterThan, LessThan, Between, In, NotEquals, Exists, Prefix, Regex, Fuzzy }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum AiProviderType { Claude, OpenAi, Gemini, DeepSeek, Local }

// ─── Models ───
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DataProcessResult<T: Clone> {
    pub status: DataProcessStatus,
    pub data: Option<T>,
    pub message: String,
    pub metadata: Option<HashMap<String, serde_json::Value>>,
}

impl<T: Clone> DataProcessResult<T> {
    pub fn ok(data: T) -> Self { Self { status: DataProcessStatus::Success, data: Some(data), message: String::new(), metadata: None } }
    pub fn fail(msg: &str) -> Self { Self { status: DataProcessStatus::Error, data: None, message: msg.to_string(), metadata: None } }
    pub fn not_found(msg: &str) -> Self { Self { status: DataProcessStatus::NotFound, data: None, message: msg.to_string(), metadata: None } }
    pub fn is_success(&self) -> bool { self.status == DataProcessStatus::Success }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SearchCondition { pub property: String, pub query_type: QueryType, pub value: serde_json::Value, pub value_to: Option<serde_json::Value> }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct QueueMessage<T: Clone> { pub id: String, pub queue_name: String, pub payload: T, pub headers: HashMap<String, String>, pub priority: i32, pub retry_count: i32 }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BulkResult { pub succeeded: i32, pub failed: i32, pub errors: Vec<String> }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AiRequest { pub prompt: String, pub system_prompt: Option<String>, pub model: Option<String>, pub temperature: f32, pub max_tokens: i32, pub history: Option<Vec<AiMessage>>, pub metadata: Option<HashMap<String, serde_json::Value>> }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AiResponse { pub content: String, pub model: String, pub input_tokens: i32, pub output_tokens: i32, pub duration_ms: f32 }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AiMessage { pub role: String, pub content: String }

// ─── Traits (Interfaces) ───
#[async_trait]
pub trait DatabaseService: Send + Sync {
    fn database_type(&self) -> DatabaseType;
    async fn store_document(&self, index: &str, prefix: &str, id: &str, document: serde_json::Value, need_to_parse: bool) -> DataProcessResult<serde_json::Value>;
    async fn search_documents(&self, index: &str, prefix: &str, filter: serde_json::Value, size: usize) -> DataProcessResult<Vec<serde_json::Value>>;
    async fn get_document(&self, index: &str, prefix: &str, id: &str) -> DataProcessResult<serde_json::Value>;
    async fn delete_document(&self, index: &str, prefix: &str, id: &str) -> DataProcessResult<bool>;
    async fn bulk_upsert(&self, index: &str, prefix: &str, documents: Vec<(String, serde_json::Value)>) -> DataProcessResult<BulkResult>;
    async fn bulk_delete(&self, index: &str, prefix: &str, ids: Vec<String>) -> DataProcessResult<BulkResult>;
    async fn get_filters(&self, index: &str, prefix: &str, field_name: &str) -> DataProcessResult<HashMap<String, i64>>;
    async fn aggregate(&self, index: &str, prefix: &str, filter: serde_json::Value, aggregations: HashMap<String, String>) -> DataProcessResult<HashMap<String, serde_json::Value>>;
    async fn index_exists(&self, index: &str, prefix: &str) -> bool;
    async fn create_index(&self, index: &str, prefix: &str) -> DataProcessResult<bool>;
}

#[async_trait]
pub trait QueueService: Send + Sync {
    fn queue_type(&self) -> QueueType;
    async fn enqueue(&self, queue_name: &str, message: serde_json::Value, headers: Option<HashMap<String, String>>, priority: i32) -> DataProcessResult<String>;
    async fn acknowledge(&self, queue_name: &str, consumer_group: &str, message_id: &str) -> DataProcessResult<bool>;
    async fn reject(&self, queue_name: &str, consumer_group: &str, message_id: &str, requeue: bool) -> DataProcessResult<bool>;
    async fn get_queue_length(&self, queue_name: &str) -> DataProcessResult<i64>;
}

#[async_trait]
pub trait AiProvider: Send + Sync {
    fn provider_type(&self) -> AiProviderType;
    async fn complete(&self, request: &AiRequest) -> DataProcessResult<AiResponse>;
    async fn complete_with_context(&self, request: &AiRequest, rag_context: &[String]) -> DataProcessResult<AiResponse>;
}

pub trait ObjectProcessor: Send + Sync {
    fn parse_document(&self, document: serde_json::Value) -> HashMap<String, serde_json::Value>;
    fn build_query_filters(&self, filter_object: serde_json::Value) -> Vec<SearchCondition>;
    fn infer_field_type(&self, value: &serde_json::Value) -> String;
}

#[async_trait]
pub trait CacheService: Send + Sync {
    async fn get(&self, key: &str) -> Option<serde_json::Value>;
    async fn set(&self, key: &str, value: serde_json::Value, expiry_secs: Option<u64>) -> ();
    async fn remove(&self, key: &str) -> ();
    async fn exists(&self, key: &str) -> bool;
}

// ─── MicroserviceBase ───
pub struct MicroserviceBase {
    pub service_name: String,
    pub db: Box<dyn DatabaseService>,
    pub queue: Box<dyn QueueService>,
    pub cache: Option<Box<dyn CacheService>>,
    shutdown_tx: broadcast::Sender<()>,
}

impl MicroserviceBase {
    pub fn new(service_name: &str, db: Box<dyn DatabaseService>, queue: Box<dyn QueueService>) -> Self {
        let (shutdown_tx, _) = broadcast::channel(1);
        Self { service_name: service_name.to_string(), db, queue, cache: None, shutdown_tx }
    }

    pub fn main_queue(&self) -> String { format!("{}-main", self.service_name) }
    pub fn consumed_queue(&self) -> String { format!("{}-consumed", self.service_name) }

    pub async fn store(&self, index: &str, id: &str, doc: serde_json::Value) -> DataProcessResult<serde_json::Value> {
        self.db.store_document(index, &self.service_name, id, doc, true).await
    }

    pub async fn search(&self, index: &str, filter: serde_json::Value, size: usize) -> DataProcessResult<Vec<serde_json::Value>> {
        self.db.search_documents(index, &self.service_name, filter, size).await
    }

    pub async fn publish(&self, message: serde_json::Value) -> DataProcessResult<String> {
        self.queue.enqueue(&self.main_queue(), message, None, 5).await
    }

    pub fn shutdown(&self) { let _ = self.shutdown_tx.send(()); tracing::info!("{} shutting down", self.service_name); }
    pub fn subscribe_shutdown(&self) -> broadcast::Receiver<()> { self.shutdown_tx.subscribe() }
}
