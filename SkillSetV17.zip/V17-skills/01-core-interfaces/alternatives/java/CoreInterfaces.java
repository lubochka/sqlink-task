// Skill 01: Core Interfaces — Java / Spring Boot
// Equivalent of XIIGen.Core — all interfaces + base class

package com.xiigen.core;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.Flow;
import java.util.concurrent.CompletableFuture;

// ─── Enums ───
public enum DataProcessStatus { SUCCESS, NOT_FOUND, ERROR, VALIDATION_ERROR, UNAUTHORIZED, CONFLICT, TIMEOUT }
public enum DatabaseType { ELASTICSEARCH, MONGODB, POSTGRESQL, REDIS, COSMOSDB, NEO4J, IN_MEMORY }
public enum QueueType { REDIS_STREAMS, RABBITMQ, KAFKA, SQS, IN_MEMORY }
public enum QueryType { EQUALS, CONTAINS, GREATER_THAN, LESS_THAN, BETWEEN, IN, NOT_EQUALS, EXISTS, PREFIX, REGEX, FUZZY }
public enum AiProviderType { CLAUDE, OPENAI, GEMINI, DEEPSEEK, LOCAL }

// ─── Models ───
public record DataProcessResult<T>(DataProcessStatus status, T data, String message, Map<String, Object> metadata) {
    public boolean isSuccess() { return status == DataProcessStatus.SUCCESS; }
    public static <T> DataProcessResult<T> ok(T data) { return new DataProcessResult<>(DataProcessStatus.SUCCESS, data, "", null); }
    public static <T> DataProcessResult<T> ok(T data, String msg) { return new DataProcessResult<>(DataProcessStatus.SUCCESS, data, msg, null); }
    public static <T> DataProcessResult<T> fail(String msg) { return new DataProcessResult<>(DataProcessStatus.ERROR, null, msg, null); }
    public static <T> DataProcessResult<T> fail(String msg, DataProcessStatus s) { return new DataProcessResult<>(s, null, msg, null); }
    public static <T> DataProcessResult<T> notFound(String msg) { return new DataProcessResult<>(DataProcessStatus.NOT_FOUND, null, msg, null); }
}

public record SearchCondition(String property, QueryType queryType, Object value, Object valueTo) {
    public SearchCondition(String property, QueryType queryType, Object value) { this(property, queryType, value, null); }
}

public record QueueMessage<T>(String id, String queueName, T payload, Map<String, String> headers, int priority, int retryCount, Instant enqueuedAt) {}
public record BulkResult(int succeeded, int failed, List<String> errors) {}
public record AiRequest(String prompt, String systemPrompt, String model, float temperature, int maxTokens, List<AiMessage> history, Map<String, Object> metadata) {}
public record AiResponse(String content, String model, int inputTokens, int outputTokens, float durationMs, Map<String, Object> metadata) {}
public record AiMessage(String role, String content) {}

// ─── Interfaces ───
public interface IDatabaseService {
    DatabaseType getDatabaseType();
    CompletableFuture<DataProcessResult<Object>> storeDocument(String indexName, String prefix, String id, Object document, boolean needToParse);
    CompletableFuture<DataProcessResult<List<Object>>> searchDocuments(String indexName, String prefix, Object filter, int size);
    CompletableFuture<DataProcessResult<Object>> getDocument(String indexName, String prefix, String id);
    CompletableFuture<DataProcessResult<Boolean>> deleteDocument(String indexName, String prefix, String id);
    CompletableFuture<DataProcessResult<BulkResult>> bulkUpsert(String indexName, String prefix, List<Map.Entry<String, Object>> documents);
    CompletableFuture<DataProcessResult<BulkResult>> bulkDelete(String indexName, String prefix, List<String> ids);
    CompletableFuture<DataProcessResult<Map<String, Long>>> getFilters(String indexName, String prefix, String fieldName);
    CompletableFuture<DataProcessResult<Map<String, Object>>> aggregate(String indexName, String prefix, Object filter, Map<String, String> aggregations);
    CompletableFuture<Boolean> indexExists(String indexName, String prefix);
    CompletableFuture<DataProcessResult<Boolean>> createIndex(String indexName, String prefix);
}

public interface IQueueService {
    QueueType getQueueType();
    CompletableFuture<DataProcessResult<String>> enqueue(String queueName, Object message, Map<String, String> headers, int priority);
    Flow.Publisher<QueueMessage<Object>> consume(String queueName, String consumerGroup, String consumerId);
    CompletableFuture<DataProcessResult<Boolean>> acknowledge(String queueName, String consumerGroup, String messageId);
    CompletableFuture<DataProcessResult<Boolean>> reject(String queueName, String consumerGroup, String messageId, boolean requeue);
    CompletableFuture<DataProcessResult<Long>> getQueueLength(String queueName);
}

public interface IAiProvider {
    AiProviderType getProviderType();
    CompletableFuture<DataProcessResult<AiResponse>> complete(AiRequest request);
    CompletableFuture<DataProcessResult<AiResponse>> completeWithContext(AiRequest request, List<String> ragContext);
    Flow.Publisher<String> stream(AiRequest request);
}

public interface IObjectProcessor {
    Map<String, Object> parseDocument(Object document);
    List<SearchCondition> buildQueryFilters(Object filterObject);
    String inferFieldType(Object value);
}

public interface ICacheService {
    <T> CompletableFuture<Optional<T>> get(String key, Class<T> type);
    <T> CompletableFuture<Void> set(String key, T value, long expiryMs);
    CompletableFuture<Void> remove(String key);
    CompletableFuture<Boolean> exists(String key);
}

// ─── MicroserviceBase ───
public abstract class MicroserviceBase {
    protected String serviceName = "unnamed";
    protected final IDatabaseService db;
    protected final IQueueService queue;
    protected final org.slf4j.Logger logger;
    protected ICacheService cache;
    protected IObjectProcessor objectProcessor;
    private volatile boolean running = false;

    protected MicroserviceBase(IDatabaseService db, IQueueService queue, org.slf4j.Logger logger) {
        this.db = db; this.queue = queue; this.logger = logger;
    }

    protected String mainQueue() { return serviceName + "-main"; }
    protected String consumedQueue() { return serviceName + "-consumed"; }
    protected String archiveQueue() { return serviceName + "-archive"; }

    protected CompletableFuture<DataProcessResult<Object>> storeDocument(String index, String id, Object doc) {
        return db.storeDocument(index, serviceName, id, doc, true);
    }
    protected CompletableFuture<DataProcessResult<List<Object>>> searchDocuments(String index, Object filter) {
        return db.searchDocuments(index, serviceName, filter, 10);
    }
    protected CompletableFuture<DataProcessResult<String>> publish(Object message) {
        return queue.enqueue(mainQueue(), message, null, 5);
    }

    public void start() { running = true; logger.info("{} starting...", serviceName); }
    public void shutdown() { running = false; logger.info("{} shutting down...", serviceName); }
    public boolean isRunning() { return running; }
}
