<?php
// Skill 01: Core Interfaces — PHP 8.3 / Laravel
// Equivalent of XIIGen.Core — all interfaces + base class

namespace XIIGen\Core;

// ─── Enums ───
enum DataProcessStatus: string {
    case Success = 'success'; case NotFound = 'not_found'; case Error = 'error';
    case ValidationError = 'validation_error'; case Unauthorized = 'unauthorized';
    case Conflict = 'conflict'; case Timeout = 'timeout';
}

enum DatabaseType: string {
    case Elasticsearch = 'elasticsearch'; case MongoDb = 'mongodb'; case PostgreSql = 'postgresql';
    case Redis = 'redis'; case CosmosDb = 'cosmosdb'; case Neo4j = 'neo4j'; case InMemory = 'in_memory';
}

enum QueueType: string {
    case RedisStreams = 'redis_streams'; case RabbitMQ = 'rabbitmq'; case Kafka = 'kafka';
    case SQS = 'sqs'; case InMemory = 'in_memory';
}

enum QueryType: string {
    case Equals = 'eq'; case Contains = 'contains'; case GreaterThan = 'gt';
    case LessThan = 'lt'; case Between = 'between'; case In = 'in';
    case NotEquals = 'ne'; case Exists = 'exists'; case Prefix = 'prefix';
    case Regex = 'regex'; case Fuzzy = 'fuzzy';
}

enum AiProviderType: string {
    case Claude = 'claude'; case OpenAi = 'openai'; case Gemini = 'gemini';
    case DeepSeek = 'deepseek'; case Local = 'local';
}

// ─── Models ───
readonly class DataProcessResult {
    public function __construct(
        public DataProcessStatus $status = DataProcessStatus::Success,
        public mixed $data = null,
        public string $message = '',
        public ?array $metadata = null,
    ) {}

    public function isSuccess(): bool { return $this->status === DataProcessStatus::Success; }

    public static function ok(mixed $data, string $msg = ''): self {
        return new self(data: $data, message: $msg);
    }
    public static function fail(string $msg, DataProcessStatus $status = DataProcessStatus::Error): self {
        return new self(status: $status, message: $msg);
    }
    public static function notFound(string $msg = 'Not found'): self {
        return new self(status: DataProcessStatus::NotFound, message: $msg);
    }
}

readonly class SearchCondition {
    public function __construct(
        public string $property = '',
        public QueryType $queryType = QueryType::Equals,
        public mixed $value = null,
        public mixed $valueTo = null,
    ) {}
}

readonly class QueueMessage {
    public function __construct(
        public string $id = '', public string $queueName = '',
        public mixed $payload = null, public array $headers = [],
        public int $priority = 5, public int $retryCount = 0,
    ) {}
}

readonly class BulkResult {
    public function __construct(public int $succeeded = 0, public int $failed = 0, public array $errors = []) {}
}

readonly class AiRequest {
    public function __construct(
        public string $prompt = '', public ?string $systemPrompt = null,
        public ?string $model = null, public float $temperature = 0.7,
        public int $maxTokens = 4096, public ?array $history = null,
        public ?array $metadata = null,
    ) {}
}

readonly class AiResponse {
    public function __construct(
        public string $content = '', public string $model = '',
        public int $inputTokens = 0, public int $outputTokens = 0,
        public float $durationMs = 0.0, public ?array $metadata = null,
    ) {}
}

// ─── Interfaces ───
interface IDatabaseService {
    public function getDatabaseType(): DatabaseType;
    public function storeDocument(string $indexName, string $prefix, string $id, mixed $document, bool $needToParse = true): DataProcessResult;
    public function searchDocuments(string $indexName, string $prefix, mixed $filter, int $size = 10): DataProcessResult;
    public function getDocument(string $indexName, string $prefix, string $id): DataProcessResult;
    public function deleteDocument(string $indexName, string $prefix, string $id): DataProcessResult;
    public function bulkUpsert(string $indexName, string $prefix, array $documents): DataProcessResult;
    public function bulkDelete(string $indexName, string $prefix, array $ids): DataProcessResult;
    public function getFilters(string $indexName, string $prefix, string $fieldName): DataProcessResult;
    public function aggregate(string $indexName, string $prefix, mixed $filter, array $aggregations): DataProcessResult;
    public function indexExists(string $indexName, string $prefix): bool;
    public function createIndex(string $indexName, string $prefix): DataProcessResult;
}

interface IQueueService {
    public function getQueueType(): QueueType;
    public function enqueue(string $queueName, mixed $message, ?array $headers = null, int $priority = 5): DataProcessResult;
    public function consume(string $queueName, string $consumerGroup, string $consumerId): \Generator;
    public function acknowledge(string $queueName, string $consumerGroup, string $messageId): DataProcessResult;
    public function reject(string $queueName, string $consumerGroup, string $messageId, bool $requeue = false): DataProcessResult;
    public function getQueueLength(string $queueName): DataProcessResult;
}

interface IAiProvider {
    public function getProviderType(): AiProviderType;
    public function complete(AiRequest $request): DataProcessResult;
    public function completeWithContext(AiRequest $request, array $ragContext): DataProcessResult;
    public function stream(AiRequest $request): \Generator;
}

interface IObjectProcessor {
    public function parseDocument(mixed $document): array;
    public function buildQueryFilters(mixed $filterObject): array;
    public function inferFieldType(mixed $value): string;
}

interface ICacheService {
    public function get(string $key): mixed;
    public function set(string $key, mixed $value, ?int $expirySeconds = null): void;
    public function remove(string $key): void;
    public function exists(string $key): bool;
}

// ─── MicroserviceBase ───
abstract class MicroserviceBase {
    protected string $serviceName = 'unnamed';
    protected ?ICacheService $cache = null;
    protected ?IObjectProcessor $objectProcessor = null;
    private bool $running = false;

    public function __construct(
        protected IDatabaseService $db,
        protected IQueueService $queue,
        protected \Psr\Log\LoggerInterface $logger,
    ) {}

    protected function mainQueue(): string { return "{$this->serviceName}-main"; }
    protected function consumedQueue(): string { return "{$this->serviceName}-consumed"; }
    protected function archiveQueue(): string { return "{$this->serviceName}-archive"; }

    protected function storeDocument(string $index, string $id, mixed $doc): DataProcessResult {
        return $this->db->storeDocument($index, $this->serviceName, $id, $doc);
    }
    protected function searchDocuments(string $index, mixed $filter, int $size = 10): DataProcessResult {
        return $this->db->searchDocuments($index, $this->serviceName, $filter, $size);
    }
    protected function publish(mixed $message): DataProcessResult {
        return $this->queue->enqueue($this->mainQueue(), $message);
    }

    public function start(): void { $this->running = true; $this->logger->info("{$this->serviceName} starting..."); }
    public function shutdown(): void { $this->running = false; $this->logger->info("{$this->serviceName} shutting down..."); }
    public function isRunning(): bool { return $this->running; }
}
