# Implement Skill 01: Core Interfaces & MicroserviceBase

## Prerequisites
- .NET 9 SDK installed
- Project structure: `XIIGen.Core` class library

## Step 1: Create Project
```bash
dotnet new classlib -n XIIGen.Core -f net9.0
cd XIIGen.Core
```

## Step 2: Create Folder Structure
```
XIIGen.Core/
├── Enums/CoreEnums.cs
├── Models/CoreModels.cs
├── Interfaces/
│   ├── IDatabaseService.cs
│   ├── IQueueService.cs
│   ├── IAiProvider.cs
│   ├── IObjectProcessor.cs
│   ├── ICacheService.cs
│   └── IPermissionsService.cs
├── Base/MicroserviceBase.cs
└── Extensions/ServiceCollectionExtensions.cs
```

## Step 3: Copy Code from SKILL.md
Copy each code block from the SKILL.md into the corresponding file.

## Step 4: Register in DI
```csharp
builder.Services.AddXIIGenCore();
```

## Step 5: Verify
```bash
dotnet build
```

## Step 6: Test
Create `XIIGen.Core.Tests` with:
- DataProcessResult creation tests
- SearchCondition building tests
- MicroserviceBase inheritance tests

## Alternative Stacks
- **Node.js:** Copy `alternatives/nodejs/core-interfaces.ts` → `src/core/`
- **Python:** Copy `alternatives/python/core_interfaces.py` → `src/core/`
- **Java:** Copy `alternatives/java/CoreInterfaces.java` → `src/main/java/com/xiigen/core/`
- **Rust:** Copy `alternatives/rust/core_interfaces.rs` → `src/core/`
- **PHP:** Copy `alternatives/php/CoreInterfaces.php` → `app/Core/`


---

## Genie DNA Compliance — MANDATORY for All Implementations

> Before writing ANY code, classify each component:
> **MACHINE** (static): Infrastructure that enables freedom. Build once, generic, interface-based.
> **FREEDOM** (dynamic): Anything users define. No fixed models, config-driven.

### DNA Checklist — Every Implementation MUST:
☐ **DNA-1 (Dynamic Documents):** Store data as `Dictionary<string, object>` / `Record<string, any>` — NOT typed model classes. User fields preserved without schema changes.
☐ **DNA-2 (BuildSearchFilter):** All queries use BuildSearchFilter/equivalent. Empty fields auto-skipped. No entity-specific query code.
☐ **DNA-3 (MicroserviceBase):** Inherit base class with DB, queue, cache, logger built in.
☐ **DNA-5 (DataProcessResult):** All public methods return `DataProcessResult<T>`. Errors return failure, not throw exceptions.
☐ **DNA-6 (Generic Interfaces):** External dependencies behind interfaces. Swap via config.
☐ **DNA-SCOPE:** Non-admin queries auto-inject userId filter. Cannot be bypassed.

### The Three Tests:
1. Can a business user change this without a developer? (YES = correct)
2. Does it work for entity types that do not exist yet? (YES = correct)
3. Can I swap the database/service/UI without changing this? (YES = correct)
