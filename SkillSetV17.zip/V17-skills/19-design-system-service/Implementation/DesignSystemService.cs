// XIIGen.Services.DesignSystem/DesignSystemService.cs - Skill 19 | .NET 9
using Microsoft.Extensions.Logging;
using XIIGen.Core.Base;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;
using XIIGen.Figma;

namespace XIIGen.Services.DesignSystem;

public class DesignSystemService : MicroserviceBase
{
    public DesignSystemService(IDatabaseService db, IQueueService queue, ILogger<DesignSystemService> logger)
        : base(db, queue, logger) { ServiceName = "design-system-service"; }

    public DesignTokens ExtractTokens(List<FigmaComponent> components)
    {
        var tokens = new DesignTokens();
        foreach (var c in components)
        {
            foreach (var (prop, value) in c.Css)
            {
                if (prop.Contains("color") || prop.Contains("background")) tokens.Colors.Add(value);
                if (prop.Contains("font-size")) tokens.FontSizes.Add(value);
                if (prop.Contains("font-weight")) tokens.FontWeights.Add(value);
                if (prop.Contains("border-radius")) tokens.BorderRadii.Add(value);
                if (prop.Contains("gap") || prop.Contains("padding") || prop.Contains("margin")) tokens.Spacing.Add(value);
            }
        }
        return tokens;
    }

    public async Task<DataProcessResult<DesignTokens>> SaveTokensAsync(string projectId, DesignTokens tokens, CancellationToken ct = default)
    {
        await StoreDocumentAsync("design-tokens", projectId, tokens, ct: ct);
        return DataProcessResult<DesignTokens>.Created(tokens);
    }
}

public class DesignTokens
{
    public HashSet<string> Colors { get; set; } = [];
    public HashSet<string> FontSizes { get; set; } = [];
    public HashSet<string> FontWeights { get; set; } = [];
    public HashSet<string> BorderRadii { get; set; } = [];
    public HashSet<string> Spacing { get; set; } = [];
    public HashSet<string> Shadows { get; set; } = [];
}
