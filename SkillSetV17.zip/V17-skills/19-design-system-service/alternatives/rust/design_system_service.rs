// Skill 19: Design System Service — Rust | serde + grass (SCSS)
use std::collections::{HashMap, HashSet};
use serde::{Deserialize, Serialize};
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub enum TokenCategory { Color, Typography, Spacing, Shadow, Border, Animation }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum StyleFormat { Css, Tailwind, ReactNative, Scss, TokenJson }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DesignToken { pub name: String, pub value: String, pub category: TokenCategory, pub semantic_alias: Option<String> }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ThemeDefinition { pub theme_id: String, pub name: String, pub tokens: HashMap<TokenCategory, Vec<DesignToken>> }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExtractionResult { pub nodes_scanned: usize, pub tokens_found: usize, pub duplicates: usize, pub tokens: Vec<DesignToken> }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StyleOutput { pub format: StyleFormat, pub file_name: String, pub content: String }

pub struct FigmaComponent { pub css: HashMap<String, String> }

fn classify(prop: &str, value: &str) -> Option<(TokenCategory, String)> {
    if prop.contains("color") || prop.contains("background") { return Some((TokenCategory::Color, format!("color-{}", value.replace('#', "").to_lowercase()))); }
    if prop.contains("font-size") { return Some((TokenCategory::Typography, format!("font-size-{}", value))); }
    if prop.contains("gap") || prop.contains("padding") || prop.contains("margin") { return Some((TokenCategory::Spacing, format!("space-{}", value))); }
    if prop.contains("shadow") { return Some((TokenCategory::Shadow, format!("shadow-{}", value.len()))); }
    if prop.contains("border-radius") { return Some((TokenCategory::Border, format!("radius-{}", value))); }
    None
}

fn kebab(s: &str) -> String { s.replace('_', "-").replace(' ', "-").to_lowercase() }
fn underscore_fn(s: &str) -> String { s.replace('-', "_").replace(' ', "_").to_lowercase() }

fn get_alias(cat: &TokenCategory, idx: usize) -> String {
    let aliases: HashMap<TokenCategory, Vec<&str>> = HashMap::from([
        (TokenCategory::Color, vec!["bg-primary", "bg-secondary", "text-primary", "text-secondary", "accent"]),
        (TokenCategory::Typography, vec!["text-base", "text-lg", "text-sm"]),
        (TokenCategory::Spacing, vec!["space-sm", "space-md", "space-lg"]),
    ]);
    aliases.get(cat).and_then(|a| a.get(idx)).map(|s| s.to_string()).unwrap_or_else(|| format!("{:?}-{}", cat, idx).to_lowercase())
}

pub fn extract_from_figma(components: &[FigmaComponent]) -> ExtractionResult {
    let mut seen = HashSet::new(); let mut tokens = Vec::new(); let mut dupes = 0;
    for comp in components {
        for (prop, value) in &comp.css {
            if let Some((cat, name)) = classify(prop, value) {
                let key = format!("{:?}:{}", cat, value);
                if !seen.insert(key) { dupes += 1; continue; }
                tokens.push(DesignToken { name, value: value.clone(), category: cat, semantic_alias: None });
            }
        }
    }
    ExtractionResult { nodes_scanned: components.len(), tokens_found: tokens.len(), duplicates: dupes, tokens }
}

pub fn build_theme(name: &str, tokens: Vec<DesignToken>) -> ThemeDefinition {
    let mut grouped: HashMap<TokenCategory, Vec<DesignToken>> = HashMap::new();
    for t in tokens {
        let list = grouped.entry(t.category.clone()).or_default();
        let alias = get_alias(&t.category, list.len());
        list.push(DesignToken { semantic_alias: Some(alias), ..t });
    }
    ThemeDefinition { theme_id: Uuid::new_v4().to_string(), name: name.into(), tokens: grouped }
}

pub fn generate_style_output(theme: &ThemeDefinition, format: &StyleFormat) -> StyleOutput {
    let all: Vec<&DesignToken> = theme.tokens.values().flat_map(|v| v.iter()).collect();
    match format {
        StyleFormat::Css => {
            let lines: Vec<String> = all.iter().map(|t| format!("  --{}: {};", kebab(t.semantic_alias.as_deref().unwrap_or(&t.name)), t.value)).collect();
            StyleOutput { format: StyleFormat::Css, file_name: "tokens.css".into(), content: format!("/* {} */\n:root {{\n{}\n}}", theme.name, lines.join("\n")) }
        }
        StyleFormat::Scss => {
            let lines: Vec<String> = all.iter().map(|t| format!("${}: {};", kebab(t.semantic_alias.as_deref().unwrap_or(&t.name)), t.value)).collect();
            StyleOutput { format: StyleFormat::Scss, file_name: "_tokens.scss".into(), content: lines.join("\n") }
        }
        StyleFormat::ReactNative => {
            let lines: Vec<String> = all.iter().map(|t| format!("  {}: '{}',", underscore_fn(t.semantic_alias.as_deref().unwrap_or(&t.name)), t.value)).collect();
            StyleOutput { format: StyleFormat::ReactNative, file_name: "theme.ts".into(), content: format!("export const theme = {{\n{}\n}};", lines.join("\n")) }
        }
        StyleFormat::TokenJson => {
            let json = serde_json::to_string_pretty(&serde_json::json!({ "theme": &theme.name, "tokens": &theme.tokens })).unwrap_or_default();
            StyleOutput { format: StyleFormat::TokenJson, file_name: "tokens.json".into(), content: json }
        }
        _ => StyleOutput { format: StyleFormat::Css, file_name: "tokens.txt".into(), content: "/* fallback */".into() }
    }
}

pub fn generate_all_formats(theme: &ThemeDefinition) -> Vec<StyleOutput> {
    vec![StyleFormat::Css, StyleFormat::Tailwind, StyleFormat::ReactNative, StyleFormat::Scss, StyleFormat::TokenJson]
        .iter().map(|f| generate_style_output(theme, f)).collect()
}
