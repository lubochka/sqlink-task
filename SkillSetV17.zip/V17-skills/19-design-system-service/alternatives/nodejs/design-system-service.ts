// Skill 19: Design System Service — Node.js/TypeScript | style-dictionary + PostCSS
type TokenCategory = "color" | "typography" | "spacing" | "shadow" | "border" | "animation";
type StyleFormat = "css" | "tailwind" | "reactNative" | "scss" | "tokenJson";
interface DesignToken { name: string; value: string; category: TokenCategory; semanticAlias?: string; }
interface ThemeDefinition { themeId: string; name: string; tokens: Record<TokenCategory, DesignToken[]>; }
interface ExtractionResult { nodesScanned: number; tokensFound: number; duplicates: number; tokens: DesignToken[]; }
interface StyleOutput { format: StyleFormat; fileName: string; content: string; }
interface FigmaComponent { css: Record<string, string>; }

function classifyProp(prop: string, value: string): { category: TokenCategory; name: string } | null {
  if (prop.includes("color") || prop.includes("background")) return { category: "color", name: `color-${value.replace("#", "").toLowerCase()}` };
  if (prop.includes("font-size")) return { category: "typography", name: `font-size-${value}` };
  if (prop.includes("font-weight")) return { category: "typography", name: `font-weight-${value}` };
  if (prop.includes("gap") || prop.includes("padding") || prop.includes("margin")) return { category: "spacing", name: `space-${value}` };
  if (prop.includes("shadow")) return { category: "shadow", name: `shadow-${value.length}` };
  if (prop.includes("border-radius")) return { category: "border", name: `radius-${value}` };
  return null;
}

const ALIASES: Record<TokenCategory, string[]> = {
  color: ["bg-primary", "bg-secondary", "text-primary", "text-secondary", "accent"],
  typography: ["text-base", "text-lg", "text-sm"], spacing: ["space-sm", "space-md", "space-lg"],
  shadow: ["shadow-sm", "shadow-md"], border: ["radius-sm", "radius-md"], animation: ["anim-fast"],
};

const kebab = (s: string) => s.replace(/_/g, "-").replace(/ /g, "-").toLowerCase();
const underscore = (s: string) => s.replace(/-/g, "_").replace(/ /g, "_").toLowerCase();

export function extractFromFigma(components: FigmaComponent[]): ExtractionResult {
  const seen = new Set<string>(); const tokens: DesignToken[] = []; let dupes = 0;
  for (const comp of components) {
    for (const [prop, value] of Object.entries(comp.css)) {
      const cls = classifyProp(prop, value); if (!cls) continue;
      const key = `${cls.category}:${value}`;
      if (seen.has(key)) { dupes++; continue; }
      seen.add(key); tokens.push({ name: cls.name, value, category: cls.category });
    }
  }
  return { nodesScanned: components.length, tokensFound: tokens.length, duplicates: dupes, tokens };
}

export function buildTheme(name: string, tokens: DesignToken[]): ThemeDefinition {
  const grouped: Record<TokenCategory, DesignToken[]> = {} as any;
  for (const t of tokens) {
    if (!grouped[t.category]) grouped[t.category] = [];
    const aliases = ALIASES[t.category] || [];
    const idx = grouped[t.category].length;
    grouped[t.category].push({ ...t, semanticAlias: aliases[idx] || `${t.category}-${idx}` });
  }
  return { themeId: crypto.randomUUID(), name, tokens: grouped };
}

export function generateStyleOutput(theme: ThemeDefinition, format: StyleFormat): StyleOutput {
  const all = Object.values(theme.tokens).flat();
  switch (format) {
    case "css": return { format, fileName: "tokens.css", content: `/* ${theme.name} */\n:root {\n${all.map(t => `  --${kebab(t.semanticAlias || t.name)}: ${t.value};`).join("\n")}\n}` };
    case "tailwind": {
      const colors = all.filter(t => t.category === "color").map(t => `        '${kebab(t.semanticAlias || t.name)}': '${t.value}',`).join("\n");
      const spacing = all.filter(t => t.category === "spacing").map(t => `        '${kebab(t.semanticAlias || t.name)}': '${t.value}',`).join("\n");
      return { format, fileName: "tailwind.extend.js", content: `module.exports = {\n  theme: {\n    extend: {\n      colors: {\n${colors}\n      },\n      spacing: {\n${spacing}\n      },\n    }\n  }\n}` };
    }
    case "reactNative": return { format, fileName: "theme.ts", content: `export const theme = {\n${all.map(t => `  ${underscore(t.semanticAlias || t.name)}: '${t.value}',`).join("\n")}\n};` };
    case "scss": return { format, fileName: "_tokens.scss", content: all.map(t => `$${kebab(t.semanticAlias || t.name)}: ${t.value};`).join("\n") };
    case "tokenJson": {
      const grouped: Record<string, Record<string, string>> = {};
      for (const t of all) { (grouped[t.category] ??= {})[t.semanticAlias || t.name] = t.value; }
      return { format, fileName: "tokens.json", content: JSON.stringify({ theme: theme.name, tokens: grouped }, null, 2) };
    }
  }
}

export function generateAllFormats(theme: ThemeDefinition): StyleOutput[] {
  return (["css", "tailwind", "reactNative", "scss", "tokenJson"] as StyleFormat[]).map(f => generateStyleOutput(theme, f));
}

export function registerRoutes(app: any) {
  app.post("/api/design-system/extract", (req: any) => extractFromFigma(req.body));
  app.post("/api/design-system/theme", (req: any) => buildTheme(req.body.name, req.body.tokens));
  app.post("/api/design-system/output", (req: any) => generateStyleOutput(req.body.theme, req.body.format));
}
