<?php
// Skill 19: Design System Service — PHP 8.3 | Collection pipeline + Laravel + enums
declare(strict_types=1);
namespace App\Services\DesignSystem;

enum TokenCategory: string { case Color = 'color'; case Typography = 'typography'; case Spacing = 'spacing'; case Shadow = 'shadow'; case Border = 'border'; case Animation = 'animation'; }
enum StyleFormat: string { case Css = 'css'; case Tailwind = 'tailwind'; case ReactNative = 'reactNative'; case Scss = 'scss'; case TokenJson = 'tokenJson'; }

readonly class DesignToken { public function __construct(public string $name, public string $value, public TokenCategory $category, public ?string $semanticAlias = null) {} }
readonly class ThemeDefinition { public function __construct(public string $themeId, public string $name, public array $tokens) {} }
readonly class ExtractionResult { public function __construct(public int $nodesScanned, public int $tokensFound, public int $duplicates, public array $tokens) {} }
readonly class StyleOutput { public function __construct(public StyleFormat $format, public string $fileName, public string $content) {} }

class DesignSystemService
{
    private const ALIASES = [
        'color' => ['bg-primary', 'bg-secondary', 'text-primary', 'text-secondary', 'accent'],
        'typography' => ['text-base', 'text-lg', 'text-sm'],
        'spacing' => ['space-sm', 'space-md', 'space-lg'],
    ];

    private function classify(string $prop, string $value): ?array
    {
        if (str_contains($prop, 'color') || str_contains($prop, 'background')) return [TokenCategory::Color, 'color-' . strtolower(str_replace('#', '', $value))];
        if (str_contains($prop, 'font-size')) return [TokenCategory::Typography, "font-size-$value"];
        if (str_contains($prop, 'gap') || str_contains($prop, 'padding') || str_contains($prop, 'margin')) return [TokenCategory::Spacing, "space-$value"];
        if (str_contains($prop, 'shadow')) return [TokenCategory::Shadow, 'shadow-' . strlen($value)];
        if (str_contains($prop, 'border-radius')) return [TokenCategory::Border, "radius-$value"];
        return null;
    }

    private function kebab(string $s): string { return strtolower(str_replace(['_', ' '], '-', $s)); }
    private function underscore(string $s): string { return strtolower(str_replace(['-', ' '], '_', $s)); }

    public function extractFromFigma(array $components): ExtractionResult
    {
        $seen = []; $tokens = []; $dupes = 0;
        foreach ($components as $comp) {
            foreach ($comp['css'] ?? [] as $prop => $value) {
                $cls = $this->classify($prop, $value); if (!$cls) continue;
                $key = "{$cls[0]->value}:$value";
                if (isset($seen[$key])) { $dupes++; continue; }
                $seen[$key] = true; $tokens[] = new DesignToken($cls[1], $value, $cls[0]);
            }
        }
        return new ExtractionResult(count($components), count($tokens), $dupes, $tokens);
    }

    public function buildTheme(string $name, array $tokens): ThemeDefinition
    {
        $grouped = [];
        foreach ($tokens as $t) {
            $cat = $t->category->value;
            if (!isset($grouped[$cat])) $grouped[$cat] = [];
            $aliases = self::ALIASES[$cat] ?? [];
            $idx = count($grouped[$cat]);
            $alias = $idx < count($aliases) ? $aliases[$idx] : "$cat-$idx";
            $grouped[$cat][] = new DesignToken($t->name, $t->value, $t->category, $alias);
        }
        return new ThemeDefinition(uniqid('theme-'), $name, $grouped);
    }

    public function generateStyleOutput(ThemeDefinition $theme, StyleFormat $format): StyleOutput
    {
        $all = array_merge(...array_values($theme->tokens));
        return match ($format) {
            StyleFormat::Css => $this->generateCss($theme->name, $all),
            StyleFormat::Tailwind => $this->generateTailwind($all),
            StyleFormat::ReactNative => $this->generateReactNative($theme->name, $all),
            StyleFormat::Scss => $this->generateScss($all),
            StyleFormat::TokenJson => $this->generateTokenJson($theme),
        };
    }

    private function generateCss(string $name, array $tokens): StyleOutput {
        $lines = array_map(fn($t) => "  --{$this->kebab($t->semanticAlias ?? $t->name)}: $t->value;", $tokens);
        return new StyleOutput(StyleFormat::Css, 'tokens.css', "/* $name */\n:root {\n" . implode("\n", $lines) . "\n}");
    }

    private function generateTailwind(array $tokens): StyleOutput {
        $colors = array_filter($tokens, fn($t) => $t->category === TokenCategory::Color);
        $c = implode("\n", array_map(fn($t) => "        '{$this->kebab($t->semanticAlias ?? $t->name)}': '$t->value',", $colors));
        return new StyleOutput(StyleFormat::Tailwind, 'tailwind.extend.js', "module.exports = {\n  theme: {\n    extend: {\n      colors: {\n$c\n      },\n    }\n  }\n}");
    }

    private function generateReactNative(string $name, array $tokens): StyleOutput {
        $lines = array_map(fn($t) => "  {$this->underscore($t->semanticAlias ?? $t->name)}: '$t->value',", $tokens);
        return new StyleOutput(StyleFormat::ReactNative, 'theme.ts', "export const theme = {\n" . implode("\n", $lines) . "\n};");
    }

    private function generateScss(array $tokens): StyleOutput {
        return new StyleOutput(StyleFormat::Scss, '_tokens.scss', implode("\n", array_map(fn($t) => "\${$this->kebab($t->semanticAlias ?? $t->name)}: $t->value;", $tokens)));
    }

    private function generateTokenJson(ThemeDefinition $theme): StyleOutput {
        $data = ['theme' => $theme->name, 'tokens' => []];
        foreach ($theme->tokens as $cat => $tokens) { foreach ($tokens as $t) { $data['tokens'][$cat][$t->semanticAlias ?? $t->name] = $t->value; } }
        return new StyleOutput(StyleFormat::TokenJson, 'tokens.json', json_encode($data, JSON_PRETTY_PRINT));
    }

    public function generateAllFormats(ThemeDefinition $theme): array {
        return array_map(fn($f) => $this->generateStyleOutput($theme, $f), StyleFormat::cases());
    }
}
