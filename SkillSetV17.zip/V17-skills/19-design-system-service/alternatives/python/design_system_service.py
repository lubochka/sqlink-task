# Skill 19: Design System Service — Python 3.12 | pydantic + cssutils
from dataclasses import dataclass, field
from enum import Enum
from uuid import uuid4
import json

class TokenCategory(Enum):
    COLOR = "color"; TYPOGRAPHY = "typography"; SPACING = "spacing"; SHADOW = "shadow"; BORDER = "border"; ANIMATION = "animation"

class StyleFormat(Enum):
    CSS = "css"; TAILWIND = "tailwind"; REACT_NATIVE = "reactNative"; SCSS = "scss"; TOKEN_JSON = "tokenJson"

@dataclass
class DesignToken:
    name: str; value: str; category: TokenCategory; semantic_alias: str | None = None

@dataclass
class ThemeDefinition:
    theme_id: str; name: str; tokens: dict[TokenCategory, list[DesignToken]]

@dataclass
class ExtractionResult:
    nodes_scanned: int; tokens_found: int; duplicates: int; tokens: list[DesignToken]

@dataclass
class StyleOutput:
    format: StyleFormat; file_name: str; content: str

ALIASES = {
    TokenCategory.COLOR: ["bg-primary", "bg-secondary", "text-primary", "text-secondary", "accent"],
    TokenCategory.TYPOGRAPHY: ["text-base", "text-lg", "text-sm"],
    TokenCategory.SPACING: ["space-sm", "space-md", "space-lg"],
}

def _classify(prop: str, value: str) -> tuple[TokenCategory, str] | None:
    if "color" in prop or "background" in prop: return (TokenCategory.COLOR, f"color-{value.replace('#','').lower()}")
    if "font-size" in prop: return (TokenCategory.TYPOGRAPHY, f"font-size-{value}")
    if "font-weight" in prop: return (TokenCategory.TYPOGRAPHY, f"font-weight-{value}")
    if any(k in prop for k in ("gap", "padding", "margin")): return (TokenCategory.SPACING, f"space-{value}")
    if "shadow" in prop: return (TokenCategory.SHADOW, f"shadow-{len(value)}")
    if "border-radius" in prop: return (TokenCategory.BORDER, f"radius-{value}")
    return None

kebab = lambda s: s.replace("_", "-").replace(" ", "-").lower()
underscore_fn = lambda s: s.replace("-", "_").replace(" ", "_").lower()

def extract_from_figma(components: list[dict]) -> ExtractionResult:
    seen, tokens, dupes = set(), [], 0
    for comp in components:
        for prop, value in comp.get("css", {}).items():
            cls = _classify(prop, value)
            if not cls: continue
            key = f"{cls[0].value}:{value}"
            if key in seen: dupes += 1; continue
            seen.add(key); tokens.append(DesignToken(cls[1], value, cls[0]))
    return ExtractionResult(len(components), len(tokens), dupes, tokens)

def build_theme(name: str, tokens: list[DesignToken]) -> ThemeDefinition:
    grouped: dict[TokenCategory, list[DesignToken]] = {}
    for t in tokens:
        if t.category not in grouped: grouped[t.category] = []
        aliases = ALIASES.get(t.category, [])
        idx = len(grouped[t.category])
        grouped[t.category].append(DesignToken(t.name, t.value, t.category, aliases[idx] if idx < len(aliases) else f"{t.category.value}-{idx}"))
    return ThemeDefinition(str(uuid4()), name, grouped)

def generate_css(theme: ThemeDefinition) -> StyleOutput:
    all_tokens = [t for ts in theme.tokens.values() for t in ts]
    lines = [f"  --{kebab(t.semantic_alias or t.name)}: {t.value};" for t in all_tokens]
    return StyleOutput(StyleFormat.CSS, "tokens.css", f"/* {theme.name} */\n:root {{\n" + "\n".join(lines) + "\n}")

def generate_tailwind(theme: ThemeDefinition) -> StyleOutput:
    all_tokens = [t for ts in theme.tokens.values() for t in ts]
    colors = [t for t in all_tokens if t.category == TokenCategory.COLOR]
    spacing = [t for t in all_tokens if t.category == TokenCategory.SPACING]
    c = "\n".join(f"        '{kebab(t.semantic_alias or t.name)}': '{t.value}'," for t in colors)
    s = "\n".join(f"        '{kebab(t.semantic_alias or t.name)}': '{t.value}'," for t in spacing)
    return StyleOutput(StyleFormat.TAILWIND, "tailwind.extend.js", f"module.exports = {{\n  theme: {{\n    extend: {{\n      colors: {{\n{c}\n      }},\n      spacing: {{\n{s}\n      }},\n    }}\n  }}\n}}")

def generate_react_native(theme: ThemeDefinition) -> StyleOutput:
    all_tokens = [t for ts in theme.tokens.values() for t in ts]
    lines = [f"  {underscore_fn(t.semantic_alias or t.name)}: '{t.value}'," for t in all_tokens]
    return StyleOutput(StyleFormat.REACT_NATIVE, "theme.ts", f"export const theme = {{\n" + "\n".join(lines) + "\n};")

def generate_scss(theme: ThemeDefinition) -> StyleOutput:
    all_tokens = [t for ts in theme.tokens.values() for t in ts]
    return StyleOutput(StyleFormat.SCSS, "_tokens.scss", "\n".join(f"${kebab(t.semantic_alias or t.name)}: {t.value};" for t in all_tokens))

def generate_token_json(theme: ThemeDefinition) -> StyleOutput:
    grouped = {}
    for cat, tokens in theme.tokens.items():
        grouped[cat.value] = {t.semantic_alias or t.name: t.value for t in tokens}
    return StyleOutput(StyleFormat.TOKEN_JSON, "tokens.json", json.dumps({"theme": theme.name, "tokens": grouped}, indent=2))

def generate_style_output(theme: ThemeDefinition, fmt: StyleFormat) -> StyleOutput:
    return {StyleFormat.CSS: generate_css, StyleFormat.TAILWIND: generate_tailwind, StyleFormat.REACT_NATIVE: generate_react_native,
            StyleFormat.SCSS: generate_scss, StyleFormat.TOKEN_JSON: generate_token_json}[fmt](theme)

def generate_all_formats(theme: ThemeDefinition) -> list[StyleOutput]:
    return [generate_style_output(theme, f) for f in StyleFormat]
