// Skill 19: Design System Service — Java 21 | Builder + Gson + records
package com.xiigen.designsystem;

import java.util.*;
import java.util.stream.*;

public class DesignSystemService {

    public enum TokenCategory { COLOR, TYPOGRAPHY, SPACING, SHADOW, BORDER, ANIMATION }
    public enum StyleFormat { CSS, TAILWIND, REACT_NATIVE, SCSS, TOKEN_JSON }

    public record DesignToken(String name, String value, TokenCategory category, String semanticAlias) {}
    public record ThemeDefinition(String themeId, String name, Map<TokenCategory, List<DesignToken>> tokens) {}
    public record ExtractionResult(int nodesScanned, int tokensFound, int duplicates, List<DesignToken> tokens) {}
    public record StyleOutput(StyleFormat format, String fileName, String content) {}

    private static final Map<TokenCategory, List<String>> ALIASES = Map.of(
        TokenCategory.COLOR, List.of("bg-primary", "bg-secondary", "text-primary", "text-secondary", "accent"),
        TokenCategory.TYPOGRAPHY, List.of("text-base", "text-lg", "text-sm"),
        TokenCategory.SPACING, List.of("space-sm", "space-md", "space-lg")
    );

    private record Classification(TokenCategory category, String name) {}

    private static Classification classify(String prop, String value) {
        if (prop.contains("color") || prop.contains("background")) return new Classification(TokenCategory.COLOR, "color-" + value.replace("#", "").toLowerCase());
        if (prop.contains("font-size")) return new Classification(TokenCategory.TYPOGRAPHY, "font-size-" + value);
        if (prop.contains("font-weight")) return new Classification(TokenCategory.TYPOGRAPHY, "font-weight-" + value);
        if (prop.contains("gap") || prop.contains("padding") || prop.contains("margin")) return new Classification(TokenCategory.SPACING, "space-" + value);
        if (prop.contains("shadow")) return new Classification(TokenCategory.SHADOW, "shadow-" + value.length());
        if (prop.contains("border-radius")) return new Classification(TokenCategory.BORDER, "radius-" + value);
        return null;
    }

    private static String kebab(String s) { return s.replace("_", "-").replace(" ", "-").toLowerCase(); }
    private static String underscore(String s) { return s.replace("-", "_").replace(" ", "_").toLowerCase(); }

    public ExtractionResult extractFromFigma(List<Map<String, Map<String, String>>> components) {
        var seen = new HashSet<String>(); var tokens = new ArrayList<DesignToken>(); int dupes = 0;
        for (var comp : components) {
            for (var e : comp.getOrDefault("css", Map.of()).entrySet()) {
                var cls = classify(e.getKey(), e.getValue()); if (cls == null) continue;
                var key = cls.category() + ":" + e.getValue();
                if (!seen.add(key)) { dupes++; continue; }
                tokens.add(new DesignToken(cls.name(), e.getValue(), cls.category(), null));
            }
        }
        return new ExtractionResult(components.size(), tokens.size(), dupes, tokens);
    }

    public ThemeDefinition buildTheme(String name, List<DesignToken> tokens) {
        var grouped = new LinkedHashMap<TokenCategory, List<DesignToken>>();
        for (var t : tokens) {
            grouped.computeIfAbsent(t.category(), k -> new ArrayList<>());
            var list = grouped.get(t.category());
            var aliases = ALIASES.getOrDefault(t.category(), List.of());
            var alias = list.size() < aliases.size() ? aliases.get(list.size()) : t.category().name().toLowerCase() + "-" + list.size();
            list.add(new DesignToken(t.name(), t.value(), t.category(), alias));
        }
        return new ThemeDefinition(UUID.randomUUID().toString(), name, grouped);
    }

    public StyleOutput generateStyleOutput(ThemeDefinition theme, StyleFormat format) {
        var all = theme.tokens().values().stream().flatMap(List::stream).toList();
        return switch (format) {
            case CSS -> generateCss(theme.name(), all);
            case TAILWIND -> generateTailwind(all);
            case REACT_NATIVE -> generateReactNative(theme.name(), all);
            case SCSS -> generateScss(all);
            case TOKEN_JSON -> generateTokenJson(theme);
        };
    }

    private StyleOutput generateCss(String name, List<DesignToken> tokens) {
        var lines = tokens.stream().map(t -> "  --" + kebab(t.semanticAlias() != null ? t.semanticAlias() : t.name()) + ": " + t.value() + ";").collect(Collectors.joining("\n"));
        return new StyleOutput(StyleFormat.CSS, "tokens.css", "/* " + name + " */\n:root {\n" + lines + "\n}");
    }

    private StyleOutput generateTailwind(List<DesignToken> tokens) {
        var colors = tokens.stream().filter(t -> t.category() == TokenCategory.COLOR)
            .map(t -> "        '" + kebab(t.semanticAlias() != null ? t.semanticAlias() : t.name()) + "': '" + t.value() + "',").collect(Collectors.joining("\n"));
        return new StyleOutput(StyleFormat.TAILWIND, "tailwind.extend.js", "module.exports = {\n  theme: {\n    extend: {\n      colors: {\n" + colors + "\n      },\n    }\n  }\n}");
    }

    private StyleOutput generateReactNative(String name, List<DesignToken> tokens) {
        var lines = tokens.stream().map(t -> "  " + underscore(t.semanticAlias() != null ? t.semanticAlias() : t.name()) + ": '" + t.value() + "',").collect(Collectors.joining("\n"));
        return new StyleOutput(StyleFormat.REACT_NATIVE, "theme.ts", "export const theme = {\n" + lines + "\n};");
    }

    private StyleOutput generateScss(List<DesignToken> tokens) {
        return new StyleOutput(StyleFormat.SCSS, "_tokens.scss", tokens.stream()
            .map(t -> "$" + kebab(t.semanticAlias() != null ? t.semanticAlias() : t.name()) + ": " + t.value() + ";").collect(Collectors.joining("\n")));
    }

    private StyleOutput generateTokenJson(ThemeDefinition theme) {
        var sb = new StringBuilder("{\n  \"theme\": \"" + theme.name() + "\",\n  \"tokens\": {\n");
        var cats = new ArrayList<>(theme.tokens().entrySet());
        for (int i = 0; i < cats.size(); i++) {
            var e = cats.get(i);
            sb.append("    \"").append(e.getKey().name().toLowerCase()).append("\": {\n");
            var tokens = e.getValue();
            for (int j = 0; j < tokens.size(); j++) {
                var t = tokens.get(j);
                sb.append("      \"").append(t.semanticAlias() != null ? t.semanticAlias() : t.name()).append("\": \"").append(t.value()).append("\"");
                if (j < tokens.size() - 1) sb.append(",");
                sb.append("\n");
            }
            sb.append("    }"); if (i < cats.size() - 1) sb.append(","); sb.append("\n");
        }
        sb.append("  }\n}");
        return new StyleOutput(StyleFormat.TOKEN_JSON, "tokens.json", sb.toString());
    }

    public List<StyleOutput> generateAllFormats(ThemeDefinition theme) {
        return Arrays.stream(StyleFormat.values()).map(f -> generateStyleOutput(theme, f)).toList();
    }
}
