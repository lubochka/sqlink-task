---
name: design-system-service
description: Extract design tokens from Figma, build themes, generate platform-specific styles
triggers: design tokens, theme generation, figma tokens, style system, design system
dependencies: [01-core-interfaces, 02-object-processor, 03-elasticsearch-datastore, 10-figma-parser]
layer: L5-Application
genie-dna: "Design tokens stored as dynamic documents. Theme configurations use ParseObjectAlternative for flexible schemas. All queries use BuildSearchFilter."
---

# Skill 19: Design System Service
## Extract design tokens from Figma, build themes, generate platform-specific style outputs

**Status:** Ready to Generate  
**Priority:** P1 — Bridge between Figma designs and generated code styling  
**Dependencies:** Skill 01 (Core Interfaces), Skill 03 (Database Fabric), Skill 06 (AI Providers), Skill 10 (Figma Connector)  
**Layer:** L5: Application  
**Phase:** 7  
**Estimated LOC:** ~400  

---

## Overview

The Design System Service is XIIGen's "brand department." It walks Figma node trees to discover recurring visual properties (colors, typography, spacing, shadows, borders), deduplicates them into design tokens, builds coherent themes with semantic aliases, and outputs platform-specific style files — CSS variables, Tailwind config, React Native StyleSheet, SCSS variables, and token JSON.

## Key Concepts

- **DesignToken** — A named value (e.g., `primary-blue: #3B82F6`) with category and metadata
- **TokenCategory** — Enum: Color, Typography, Spacing, Shadow, Border, Animation
- **ThemeDefinition** — Collection of tokens organized by category with semantic aliases
- **StyleOutputFormat** — Target format: CssVariables, TailwindConfig, ReactNative, Scss, TokenJson
- **Extraction** — Walking Figma nodes to discover design patterns; dedup via HashSet
- **Semantic Aliases** — Human-readable names like `bg-primary`, `text-secondary`

---

## Primary Implementation (.NET 9)

### Models

```csharp
// File: XIIGen.DesignSystem/Models/DesignTokenModels.cs
namespace XIIGen.DesignSystem.Models;

public enum TokenCategory { Color, Typography, Spacing, Shadow, Border, Animation }
public enum StyleOutputFormat { CssVariables, TailwindConfig, ReactNative, Scss, TokenJson }

public record DesignToken(
    string Name, string Value, TokenCategory Category,
    string? SemanticAlias = null, Dictionary<string, string>? Metadata = null
);

public record ThemeDefinition(
    string ThemeId, string Name,
    Dictionary<TokenCategory, List<DesignToken>> Tokens,
    DateTime CreatedAt = default
) { public DateTime CreatedAt { get; init; } = CreatedAt == default ? DateTime.UtcNow : CreatedAt; }

public record ExtractionResult(
    int NodesScanned, int TokensFound, int Duplicates,
    List<DesignToken> Tokens
);

public record StyleOutputResult(
    StyleOutputFormat Format, string FileName, string Content
);
```

### Service Interface

```csharp
// File: XIIGen.DesignSystem/IDesignSystemService.cs
namespace XIIGen.DesignSystem;

public interface IDesignSystemService
{
    ExtractionResult ExtractFromFigma(List<FigmaComponent> components);
    Task<ThemeDefinition> BuildThemeAsync(string name, List<DesignToken> tokens, CancellationToken ct = default);
    StyleOutputResult GenerateStyleOutput(ThemeDefinition theme, StyleOutputFormat format);
    Task<ThemeDefinition> MergeThemesAsync(ThemeDefinition baseTheme, ThemeDefinition overlay, CancellationToken ct = default);
    Task<List<StyleOutputResult>> GenerateAllFormatsAsync(ThemeDefinition theme, CancellationToken ct = default);
}
```

### Service Implementation

```csharp
// File: XIIGen.DesignSystem/DesignSystemService.cs
using Microsoft.Extensions.Logging;
using XIIGen.Core.Base;
using XIIGen.Core.Interfaces;
using XIIGen.Figma;
using System.Text;

namespace XIIGen.DesignSystem;

public class DesignSystemService : MicroserviceBase, IDesignSystemService
{
    public DesignSystemService(IDatabaseService db, IQueueService queue, ILogger<DesignSystemService> logger)
        : base(db, queue, logger) { ServiceName = "design-system-service"; }

    public ExtractionResult ExtractFromFigma(List<FigmaComponent> components)
    {
        var seen = new HashSet<string>();
        var tokens = new List<DesignToken>();
        int scanned = 0, dupes = 0;

        foreach (var comp in components)
        {
            scanned++;
            foreach (var (prop, value) in comp.Css)
            {
                var (cat, name) = ClassifyProperty(prop, value);
                if (cat == null) continue;
                var key = $"{cat}:{value}";
                if (!seen.Add(key)) { dupes++; continue; }
                tokens.Add(new DesignToken(name, value, cat.Value));
            }
        }
        return new ExtractionResult(scanned, tokens.Count, dupes, tokens);
    }

    public async Task<ThemeDefinition> BuildThemeAsync(string name, List<DesignToken> tokens, CancellationToken ct = default)
    {
        var grouped = tokens.GroupBy(t => t.Category)
            .ToDictionary(g => g.Key, g => g.Select((t, i) => t with
            {
                SemanticAlias = GenerateAlias(t.Category, i)
            }).ToList());

        var theme = new ThemeDefinition(Guid.NewGuid().ToString(), name, grouped);
        await StoreDocumentAsync("xiigen-design-tokens", theme.ThemeId, theme, ct: ct);
        return theme;
    }

    public StyleOutputResult GenerateStyleOutput(ThemeDefinition theme, StyleOutputFormat format)
    {
        var allTokens = theme.Tokens.SelectMany(kv => kv.Value).ToList();
        return format switch
        {
            StyleOutputFormat.CssVariables => GenerateCss(theme.Name, allTokens),
            StyleOutputFormat.TailwindConfig => GenerateTailwind(allTokens),
            StyleOutputFormat.ReactNative => GenerateReactNative(theme.Name, allTokens),
            StyleOutputFormat.Scss => GenerateScss(allTokens),
            StyleOutputFormat.TokenJson => GenerateTokenJson(theme, allTokens),
            _ => new StyleOutputResult(format, "tokens.txt", "/* Unknown format */")
        };
    }

    public async Task<ThemeDefinition> MergeThemesAsync(ThemeDefinition baseTheme, ThemeDefinition overlay, CancellationToken ct = default)
    {
        var merged = new Dictionary<TokenCategory, List<DesignToken>>(baseTheme.Tokens);
        foreach (var (cat, tokens) in overlay.Tokens)
        {
            if (merged.ContainsKey(cat))
                merged[cat] = merged[cat].Concat(tokens).GroupBy(t => t.Name).Select(g => g.Last()).ToList();
            else merged[cat] = tokens;
        }
        var result = new ThemeDefinition(Guid.NewGuid().ToString(), $"{baseTheme.Name}+{overlay.Name}", merged);
        await StoreDocumentAsync("xiigen-design-tokens", result.ThemeId, result, ct: ct);
        return result;
    }

    public async Task<List<StyleOutputResult>> GenerateAllFormatsAsync(ThemeDefinition theme, CancellationToken ct = default)
    {
        var results = Enum.GetValues<StyleOutputFormat>()
            .Select(f => GenerateStyleOutput(theme, f)).ToList();
        await Task.CompletedTask;
        return results;
    }

    // --- Output generators ---

    private static StyleOutputResult GenerateCss(string name, List<DesignToken> tokens)
    {
        var sb = new StringBuilder($"/* {name} Design Tokens */\n:root {{\n");
        foreach (var t in tokens)
            sb.AppendLine($"  --{Kebab(t.SemanticAlias ?? t.Name)}: {t.Value};");
        sb.Append('}');
        return new(StyleOutputFormat.CssVariables, "tokens.css", sb.ToString());
    }

    private static StyleOutputResult GenerateTailwind(List<DesignToken> tokens)
    {
        var colors = tokens.Where(t => t.Category == TokenCategory.Color);
        var spacing = tokens.Where(t => t.Category == TokenCategory.Spacing);
        var sb = new StringBuilder("/** @type {import('tailwindcss').Config} */\nmodule.exports = {\n  theme: {\n    extend: {\n");
        sb.AppendLine("      colors: {");
        foreach (var c in colors) sb.AppendLine($"        '{Kebab(c.SemanticAlias ?? c.Name)}': '{c.Value}',");
        sb.AppendLine("      },");
        sb.AppendLine("      spacing: {");
        foreach (var s in spacing) sb.AppendLine($"        '{Kebab(s.SemanticAlias ?? s.Name)}': '{s.Value}',");
        sb.AppendLine("      },\n    }\n  }\n}");
        return new(StyleOutputFormat.TailwindConfig, "tailwind.extend.js", sb.ToString());
    }

    private static StyleOutputResult GenerateReactNative(string name, List<DesignToken> tokens)
    {
        var sb = new StringBuilder($"// {name} Design Tokens\nexport const theme = {{\n");
        foreach (var t in tokens)
            sb.AppendLine($"  {Underscore(t.SemanticAlias ?? t.Name)}: '{t.Value}',");
        sb.Append("};");
        return new(StyleOutputFormat.ReactNative, "theme.ts", sb.ToString());
    }

    private static StyleOutputResult GenerateScss(List<DesignToken> tokens)
    {
        var sb = new StringBuilder("// Design Tokens (SCSS)\n");
        foreach (var t in tokens)
            sb.AppendLine($"${Kebab(t.SemanticAlias ?? t.Name)}: {t.Value};");
        return new(StyleOutputFormat.Scss, "_tokens.scss", sb.ToString());
    }

    private static StyleOutputResult GenerateTokenJson(ThemeDefinition theme, List<DesignToken> tokens)
    {
        var grouped = tokens.GroupBy(t => t.Category).ToDictionary(
            g => g.Key.ToString().ToLower(),
            g => g.ToDictionary(t => t.SemanticAlias ?? t.Name, t => t.Value));
        var json = System.Text.Json.JsonSerializer.Serialize(new { theme = theme.Name, tokens = grouped },
            new System.Text.Json.JsonSerializerOptions { WriteIndented = true });
        return new(StyleOutputFormat.TokenJson, "tokens.json", json);
    }

    // --- Helpers ---

    private static (TokenCategory?, string) ClassifyProperty(string prop, string value)
    {
        if (prop.Contains("color") || prop.Contains("background"))
            return (TokenCategory.Color, $"color-{value.Replace("#", "").ToLower()}");
        if (prop.Contains("font-size")) return (TokenCategory.Typography, $"font-size-{value}");
        if (prop.Contains("font-weight")) return (TokenCategory.Typography, $"font-weight-{value}");
        if (prop.Contains("gap") || prop.Contains("padding") || prop.Contains("margin"))
            return (TokenCategory.Spacing, $"space-{value}");
        if (prop.Contains("shadow")) return (TokenCategory.Shadow, $"shadow-{value.GetHashCode():x8}");
        if (prop.Contains("border-radius")) return (TokenCategory.Border, $"radius-{value}");
        return (null, "");
    }

    private static string GenerateAlias(TokenCategory cat, int index) => cat switch
    {
        TokenCategory.Color => index switch { 0 => "bg-primary", 1 => "bg-secondary", 2 => "text-primary",
            3 => "text-secondary", 4 => "accent", _ => $"color-{index}" },
        TokenCategory.Typography => index switch { 0 => "text-base", 1 => "text-lg", 2 => "text-sm", _ => $"font-{index}" },
        TokenCategory.Spacing => index switch { 0 => "space-sm", 1 => "space-md", 2 => "space-lg", _ => $"space-{index}" },
        _ => $"{cat.ToString().ToLower()}-{index}"
    };

    private static string Kebab(string s) => s.Replace("_", "-").Replace(" ", "-").ToLower();
    private static string Underscore(string s) => s.Replace("-", "_").Replace(" ", "_").ToLower();
}
```

### DI & API

```csharp
services.AddSingleton<IDesignSystemService, DesignSystemService>();

app.MapPost("/api/design-system/extract", (IDesignSystemService svc, List<FigmaComponent> components) =>
    Results.Ok(svc.ExtractFromFigma(components)));
app.MapPost("/api/design-system/theme", async (IDesignSystemService svc, BuildThemeRequest req, CancellationToken ct) =>
    Results.Ok(await svc.BuildThemeAsync(req.Name, req.Tokens, ct)));
app.MapPost("/api/design-system/output", (IDesignSystemService svc, OutputRequest req) =>
    Results.Ok(svc.GenerateStyleOutput(req.Theme, req.Format)));
```

### Elasticsearch Index: `xiigen-design-tokens`

---

## Tests

```csharp
[Fact] public void ExtractFromFigma_DeduplicatesColors()
{
    var components = new List<FigmaComponent>
    {
        new() { Css = new() { ["color"] = "#3B82F6", ["background"] = "#3B82F6" } },
        new() { Css = new() { ["color"] = "#EF4444" } }
    };
    var result = _svc.ExtractFromFigma(components);
    Assert.Equal(2, result.TokensFound);  // #3B82F6 deduped
    Assert.Equal(1, result.Duplicates);
}

[Fact] public void GenerateCss_IncludesAllTokens()
{
    var theme = new ThemeDefinition("t1", "Test", new() {
        [TokenCategory.Color] = [new("primary", "#3B82F6", TokenCategory.Color, "bg-primary")]
    });
    var css = _svc.GenerateStyleOutput(theme, StyleOutputFormat.CssVariables);
    Assert.Contains("--bg-primary: #3B82F6", css.Content);
    Assert.Contains(":root", css.Content);
}

[Fact] public async Task GenerateAllFormats_Returns5Outputs()
{
    var theme = new ThemeDefinition("t1", "Test", new() {
        [TokenCategory.Color] = [new("c1", "#000", TokenCategory.Color)]
    });
    var results = await _svc.GenerateAllFormatsAsync(theme);
    Assert.Equal(5, results.Count);
}
```

---

## Alternatives

| Stack | File | Key Libraries |
|-------|------|--------------|
| Node.js/TypeScript | `alternatives/nodejs/design-system-service.ts` | style-dictionary, PostCSS |
| Python 3.12 | `alternatives/python/design_system_service.py` | pydantic, cssutils, dataclasses |
| Java 21 | `alternatives/java/DesignSystemService.java` | Builder pattern, Gson, records |
| Rust | `alternatives/rust/design_system_service.rs` | serde, grass (SCSS), HashMap |
| PHP 8.3 | `alternatives/php/DesignSystemService.php` | Collection pipeline, Laravel, enums |

## Implementation Prompt → `prompts/implement.md`
