# Implement Skill 19: Design System Service

## Context
You are implementing the Design System Service for XIIGen. This service extracts design tokens from Figma components, builds themes, and generates platform-specific style outputs.

## Steps

1. **Read** `skills/19-design-system-service/SKILL.md` completely
2. **Create Models** — `TokenCategory` enum, `StyleOutputFormat` enum, `DesignToken`, `ThemeDefinition`, `ExtractionResult`, `StyleOutputResult`
3. **Create Interface** — `IDesignSystemService` with `ExtractFromFigma`, `BuildThemeAsync`, `GenerateStyleOutput`, `MergeThemesAsync`, `GenerateAllFormatsAsync`
4. **Implement Service** — `DesignSystemService` extending `MicroserviceBase`
   - CSS property classification → TokenCategory (color, typography, spacing, shadow, border)
   - Deduplication via HashSet on `category:value` keys
   - Semantic alias generation (bg-primary, text-base, space-sm, etc.)
   - 5 output format generators: CSS variables, Tailwind config, React Native, SCSS, Token JSON
   - Theme merging (base + overlay, last-write-wins per token name)
5. **Register DI** — `services.AddSingleton<IDesignSystemService, DesignSystemService>()`
6. **Add API Routes** — `POST /api/design-system/extract`, `POST /api/design-system/theme`, `POST /api/design-system/output`
7. **Write Tests** — Extraction deduplicates, CSS output includes all tokens, all 5 formats generated

## Verification Checklist
- [ ] Figma CSS properties classified into 6 token categories
- [ ] Duplicate tokens deduplicated (same category + value)
- [ ] Semantic aliases auto-generated (bg-primary, bg-secondary, etc.)
- [ ] CSS: `:root { --name: value; }` format
- [ ] Tailwind: `theme.extend.colors/spacing` structure
- [ ] React Native: `export const theme = { name: 'value' }` with underscores
- [ ] SCSS: `$name: value;` format
- [ ] Token JSON: grouped by category
- [ ] Theme merge combines base + overlay tokens
- [ ] Results stored in Elasticsearch index `xiigen-design-tokens`

## Key Files
- SKILL.md: `skills/19-design-system-service/SKILL.md`
- Existing .cs: `skills/19-design-system-service/Implementation/DesignSystemService.cs`
- Alternatives: `skills/19-design-system-service/alternatives/{nodejs,python,java,rust,php}/`


---

## Genie DNA Compliance — MANDATORY for All Implementations

> Before writing ANY code, classify each component:
> **MACHINE** (static): Infrastructure that enables freedom. Build once, generic, interface-based.
> **FREEDOM** (dynamic): Anything users define. No fixed models, config-driven.

### DNA Checklist — Every Implementation MUST:
☐ **DNA-1 (Dynamic Documents):** Store data as `Dictionary<string, object>` / `Record<string, any>` — NOT typed model classes. User fields preserved without schema changes.
☐ **DNA-2 (BuildSearchFilter):** All queries use BuildSearchFilter/equivalent. Empty fields auto-skipped. No entity-specific query code.
☐ **DNA-3 (MicroserviceBase):** Inherit base class with DB, queue, cache, logger built in.
☐ **DNA-5 (DataProcessResult):** All public methods return `DataProcessResult<T>`. Errors return failure, not throw exceptions.
☐ **DNA-6 (Generic Interfaces):** External dependencies behind interfaces. Swap via config.
☐ **DNA-SCOPE:** Non-admin queries auto-inject userId filter. Cannot be bypassed.

### The Three Tests:
1. Can a business user change this without a developer? (YES = correct)
2. Does it work for entity types that do not exist yet? (YES = correct)
3. Can I swap the database/service/UI without changing this? (YES = correct)
