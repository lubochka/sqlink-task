---
skill_id: "27"
name: k8s-deployment
title: "Kubernetes Deployment & Hosting"
layer: "L7: Infrastructure"
version: "17.1"
status: "active"
priority: "P0"
dependencies: ["01-core-interfaces", "32-devops-cicd", "37-safe-code"]
alternatives_hosting: [k8s-helm, docker-compose, railway, render, fly-io, aws-ecs, azure-aks, gke]
genie_dna:
  - "DNA-K8S: Each microservice is independently deployable and scalable"
  - "DNA-6: Deployment works across all hosting alternatives"
  - "DNA-3: Zero shared state between pods — all state in ES/Redis"
triggers: kubernetes, k8s, deployment, helm, docker, hosting, railway, render, fly.io, container, pods, scaling
estimated_loc: 800
---

# Skill 27: Kubernetes Deployment & Hosting
## Multi-Platform Deployment for XIIGen Microservices

**Classification:** MACHINE — K8s manifests are static config  
**Priority:** P0 — Required for any deployment  
**Dependencies:** Skill 01 (Core), Skill 32 (DevOps CI/CD), Skill 37 (Safe Code)  
**Layer:** L7: Infrastructure  
**Estimated LOC:** ~800  

---

## Overview

K8s Deployment manages containerization and deployment of all XIIGen microservices across multiple hosting platforms. Primary target is Kubernetes with Helm charts, but alternatives include Docker Compose (local dev), Railway, Render, Fly.io, AWS ECS, Azure AKS, and GKE. Each microservice gets its own Deployment, Service, ConfigMap, and Secret manifest, with HPA (Horizontal Pod Autoscaler) for automatic scaling. The skill generates deployment configs from service metadata, manages multi-environment promotion (dev→staging→prod), and provides health check and rollback capabilities.

## Key Concepts

- **Helm Chart Templates** — Each microservice is a Helm release. Shared chart template with per-service values.yaml for customization.
- **Multi-Environment** — dev, staging, production namespaces with environment-specific configs, secrets, and resource limits.
- **Health Probes** — Liveness (is it running?), readiness (can it serve traffic?), and startup (is it initialized?) probes for every service.
- **Resource Management** — CPU/memory requests and limits based on profiling data (Skill 38). HPA scales pods based on CPU/memory/custom metrics.
- **Secret Injection** — Kubernetes Secrets populated from Key Vault (Skill 37). Mounted as environment variables, never in manifests.
- **Hosting Abstraction** — `IDeploymentProvider` interface with implementations for K8s, Docker Compose, Railway, etc.

---

## DNA Integration

### Required Patterns
- **DataProcessResult** — Deployment operations return status, pod health, rollback availability.
- **Scope Isolation (DNA-3)** — Each microservice is independently deployable. Zero shared volumes or state.
- **Dynamic Document** — Deployment history, pod metrics, and scaling events stored as dynamic documents.
- **BuildSearchFilter** — Query deployment history by service, environment, status, date range.

### Anti-Patterns to AVOID
- ❌ Shared persistent volumes between services — use ES/Redis for all shared state
- ❌ Hardcoded resource limits — base on profiling data, scale with HPA
- ❌ Single replica for production — minimum 2 replicas with pod anti-affinity
- ❌ Secrets in ConfigMaps — always use Kubernetes Secrets with Key Vault sync
- ❌ Missing health probes — every service must have liveness + readiness

---

## Primary Implementation (Kubernetes + Helm)

### Helm Chart Structure

```
helm/
├── Chart.yaml
├── values.yaml                    # Default values
├── values-dev.yaml                # Dev overrides
├── values-staging.yaml            # Staging overrides
├── values-prod.yaml               # Production overrides
└── templates/
    ├── deployment.yaml            # Pod spec, containers, probes
    ├── service.yaml               # ClusterIP/LoadBalancer
    ├── configmap.yaml             # Non-secret config
    ├── secret.yaml                # Secret references
    ├── hpa.yaml                   # Horizontal Pod Autoscaler
    ├── ingress.yaml               # External routing
    └── serviceaccount.yaml        # RBAC
```

### Deployment Provider Interface

```csharp
namespace XIIGen.Deployment.Interfaces;

public interface IDeploymentProvider
{
    Task<DataProcessResult<DeploymentStatus>> DeployAsync(DeploymentConfig config, CancellationToken ct = default);
    Task<DataProcessResult<DeploymentStatus>> GetStatusAsync(string serviceId, string environment, CancellationToken ct = default);
    Task<DataProcessResult<bool>> RollbackAsync(string serviceId, string environment, CancellationToken ct = default);
    Task<DataProcessResult<ScalingResult>> ScaleAsync(string serviceId, int replicas, CancellationToken ct = default);
    Task<DataProcessResult<List<PodHealth>>> GetPodHealthAsync(string serviceId, CancellationToken ct = default);
}
```

### Models

```csharp
public record DeploymentConfig(
    string ServiceId, string Environment, string ImageTag,
    ResourceLimits Resources, int Replicas,
    Dictionary<string, string> EnvVars
);

public record DeploymentStatus(
    string ServiceId, string Environment, string Status,
    int DesiredReplicas, int ReadyReplicas,
    string ImageTag, DateTime DeployedAt
);

public record PodHealth(string PodName, string Status, bool Ready, TimeSpan Uptime);
public record ResourceLimits(string CpuRequest, string CpuLimit, string MemRequest, string MemLimit);
```

### DI Registration

```csharp
services.AddScoped<IDeploymentProvider>(sp =>
    config["HostingProvider"] switch {
        "k8s" => new KubernetesProvider(config),
        "docker-compose" => new DockerComposeProvider(config),
        "railway" => new RailwayProvider(config),
        "render" => new RenderProvider(config),
        "fly-io" => new FlyIoProvider(config),
        _ => new KubernetesProvider(config)
    });
```

---

## Test Scenarios

1. Generate Helm chart for .NET service → verify valid YAML with all templates
2. Deploy to dev namespace → verify pods running, health probes passing
3. Scale from 2 to 4 replicas → verify HPA config and pod count
4. Health check fails → verify readiness probe marks pod not-ready
5. Rollback to previous version → verify `kubectl rollout undo` equivalent
6. Generate Docker Compose for local dev → verify service starts with `docker-compose up`
7. Generate Railway config → verify valid railway.json with correct build/start commands

## Component Classification
- **Category:** Infrastructure Deployment
- **Inputs:** Service metadata, environment config, image tags, resource requirements
- **Outputs:** Helm charts, Docker Compose, platform configs, deployment status
- **Side Effects:** Deploys containers, scales pods, manages K8s resources
- **ES Indexes:** `deployment-history`, `pod-metrics`
