# XIIGen Skill 27: Kubernetes Deployment — Fly.io Alternative
# Deploy XIIGen microservices to Fly.io global edge network
# DNA: Each service independently deployable, zero shared state, scope isolation
# Fly.io excels at low-latency global distribution with Firecracker microVMs

# =============================================================================
# fly.toml — Service template (one per microservice)
# =============================================================================
# Each XIIGen service gets its own fly.toml in its directory.
# This is a template — replace {{SERVICE_NAME}} with actual service name.

app = "xiigen-{{SERVICE_NAME}}"
primary_region = "iad"  # US East (Virginia)

[build]
  dockerfile = "Dockerfile"

[env]
  ASPNETCORE_ENVIRONMENT = "Production"
  SERVICE_NAME = "{{SERVICE_NAME}}"
  LOG_LEVEL = "Information"
  SCOPE_ISOLATION = "true"
  PORT = "8080"

[http_service]
  internal_port = 8080
  force_https = true
  auto_stop_machines = true
  auto_start_machines = true
  min_machines_running = 1
  processes = ["app"]

  [http_service.concurrency]
    type = "requests"
    hard_limit = 250
    soft_limit = 200

  # DNA: Health checks for every service
  [[http_service.checks]]
    interval = "15s"
    timeout = "5s"
    grace_period = "30s"
    method = "GET"
    path = "/health/live"

[[vm]]
  cpu_kind = "shared"
  cpus = 1
  memory_mb = 512

# =============================================================================
# MULTI-SERVICE DEPLOYMENT SCRIPT — deploy-fly.sh
# =============================================================================
#!/bin/bash
set -euo pipefail

ENVIRONMENT="${1:-dev}"
REGION="${2:-iad}"
ORG="${3:-xiigen}"

echo "✈️  Deploying XIIGen to Fly.io (${ENVIRONMENT}) in region ${REGION}"

# Install flyctl if not present
if ! command -v flyctl &>/dev/null; then
  curl -L https://fly.io/install.sh | sh
fi

# Authenticate
flyctl auth login

# --- Create infrastructure services first ---

# Elasticsearch (using Fly Volumes for persistence)
echo "📦 Creating Elasticsearch..."
flyctl apps create "xiigen-elasticsearch-${ENVIRONMENT}" --org "${ORG}" 2>/dev/null || true
flyctl volumes create es_data --size 20 --region "${REGION}" \
  --app "xiigen-elasticsearch-${ENVIRONMENT}" 2>/dev/null || true

cat > /tmp/fly-es.toml << 'EOF'
app = "xiigen-elasticsearch-${ENVIRONMENT}"
primary_region = "${REGION}"

[build]
  image = "docker.elastic.co/elasticsearch/elasticsearch:8.12.0"

[env]
  discovery.type = "single-node"
  xpack.security.enabled = "false"
  ES_JAVA_OPTS = "-Xms512m -Xmx512m"
  cluster.name = "xiigen-fly"

[mounts]
  source = "es_data"
  destination = "/usr/share/elasticsearch/data"

[[services]]
  internal_port = 9200
  protocol = "tcp"

[[vm]]
  cpu_kind = "shared"
  cpus = 2
  memory_mb = 1024
EOF

flyctl deploy --config /tmp/fly-es.toml --app "xiigen-elasticsearch-${ENVIRONMENT}"

# Redis (using Fly's Upstash Redis or self-hosted)
echo "📦 Creating Redis..."
flyctl redis create "xiigen-redis-${ENVIRONMENT}" --region "${REGION}" \
  --plan free 2>/dev/null || true

# Get internal URLs for service mesh
ES_URL="xiigen-elasticsearch-${ENVIRONMENT}.internal:9200"
REDIS_URL=$(flyctl redis status "xiigen-redis-${ENVIRONMENT}" --json | jq -r '.url')

# --- Deploy core microservices ---
declare -A SERVICES=(
  ["api-gateway"]="skills/09-trace-manager/dotnet"
  ["flow-engine"]="skills/10-flow-engine/dotnet"
  ["ai-dispatcher"]="skills/07-ai-dispatcher/dotnet"
  ["rag-service"]="skills/00a-rag-interfaces/dotnet"
  ["feedback-service"]="skills/14-feedback-loop/dotnet"
  ["quality-scorer"]="skills/15-quality-scorer/dotnet"
  ["figma-parser"]="skills/16-figma-parser/dotnet"
  ["code-generator"]="skills/20-code-generator/dotnet"
)

for SERVICE_NAME in "${!SERVICES[@]}"; do
  SERVICE_PATH="${SERVICES[$SERVICE_NAME]}"
  APP_NAME="xiigen-${SERVICE_NAME}-${ENVIRONMENT}"
  
  echo "🚀 Deploying ${SERVICE_NAME}..."
  
  # Create app if not exists
  flyctl apps create "${APP_NAME}" --org "${ORG}" 2>/dev/null || true
  
  # Set secrets (DNA: never in code)
  flyctl secrets set \
    ELASTICSEARCH_URL="http://${ES_URL}" \
    REDIS_URL="${REDIS_URL}" \
    --app "${APP_NAME}" 2>/dev/null || true
  
  # Generate service-specific fly.toml
  cat > "${SERVICE_PATH}/fly.toml" << TOML
app = "${APP_NAME}"
primary_region = "${REGION}"

[build]
  dockerfile = "Dockerfile"

[env]
  ASPNETCORE_ENVIRONMENT = "${ENVIRONMENT}"
  SERVICE_NAME = "${SERVICE_NAME}"
  LOG_LEVEL = "Information"
  SCOPE_ISOLATION = "true"
  PORT = "8080"

[http_service]
  internal_port = 8080
  force_https = true
  auto_stop_machines = true
  auto_start_machines = true
  min_machines_running = 1

  [http_service.concurrency]
    type = "requests"
    hard_limit = 250
    soft_limit = 200

  [[http_service.checks]]
    interval = "15s"
    timeout = "5s"
    grace_period = "30s"
    method = "GET"
    path = "/health/live"

[[vm]]
  cpu_kind = "shared"
  cpus = 1
  memory_mb = 512
TOML
  
  # Deploy
  flyctl deploy --app "${APP_NAME}" --config "${SERVICE_PATH}/fly.toml" \
    --dockerfile "${SERVICE_PATH}/Dockerfile" --wait-timeout 300
  
  echo "✅ ${SERVICE_NAME} deployed at ${APP_NAME}.fly.dev"
done

# --- Deploy client ---
echo "🚀 Deploying client..."
CLIENT_APP="xiigen-client-${ENVIRONMENT}"
flyctl apps create "${CLIENT_APP}" --org "${ORG}" 2>/dev/null || true

flyctl secrets set \
  REACT_APP_API_URL="https://xiigen-api-gateway-${ENVIRONMENT}.fly.dev" \
  --app "${CLIENT_APP}"

flyctl deploy --app "${CLIENT_APP}" \
  --dockerfile "skills/26-web-flow-editor/alternatives/react/Dockerfile"

echo ""
echo "✅ All services deployed to Fly.io!"
echo "📊 Dashboard: https://fly.io/apps"
echo ""
echo "Services:"
for SERVICE_NAME in "${!SERVICES[@]}"; do
  echo "  ${SERVICE_NAME}: https://xiigen-${SERVICE_NAME}-${ENVIRONMENT}.fly.dev"
done
echo "  client: https://${CLIENT_APP}.fly.dev"

# =============================================================================
# FLY.IO FEATURES USED
# =============================================================================
# - Firecracker microVMs: Fast boot (~300ms), strong isolation
# - Fly Proxy: Global anycast, automatic TLS
# - Private networking: .internal DNS between services (no public exposure)
# - Auto-stop/start: Scale to zero when idle (cost savings)
# - Fly Volumes: Persistent SSD storage for ES/Redis
# - Fly Redis (Upstash): Managed Redis with REST API
# - Multi-region: Deploy to 30+ regions for low latency
#
# DNA Compliance:
# - Each service is a separate Fly app (independent deploy/scale)
# - Secrets via flyctl secrets (never in fly.toml)
# - Health checks on every service
# - Internal networking via .internal DNS (scope isolation)
# - Auto-scaling via machine count and concurrency limits

# =============================================================================
# SCALING COMMANDS
# =============================================================================
# Scale up:      flyctl scale count 3 --app xiigen-api-gateway-prod
# Scale memory:  flyctl scale memory 1024 --app xiigen-ai-dispatcher-prod
# Multi-region:  flyctl regions add lhr fra --app xiigen-api-gateway-prod
# Scale to zero: auto (auto_stop_machines = true in fly.toml)

# =============================================================================
# COST ESTIMATE (Fly.io pricing as of 2025)
# =============================================================================
# Shared CPU-1x, 256MB: ~$2/mo per machine
# Shared CPU-1x, 512MB: ~$4/mo per machine  
# Shared CPU-1x, 1GB:   ~$7/mo per machine
# Volumes: $0.15/GB/mo
# Bandwidth: First 100GB free, then $0.02/GB
# Auto-stop saves ~60-80% when services idle
# Estimated dev total: ~$30-60/mo (with auto-stop)
# Estimated prod total: ~$100-300/mo
