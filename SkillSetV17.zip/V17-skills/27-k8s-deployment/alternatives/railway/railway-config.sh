# XIIGen Skill 27: Kubernetes Deployment — Railway PaaS Alternative
# Deploy XIIGen microservices to Railway.app
# DNA: Each service independently deployable, zero shared state, scope isolation
# Railway uses nixpacks for auto-detection, or Dockerfile if present

# =============================================================================
# railway.json — Root project configuration
# =============================================================================
# {
#   "$schema": "https://railway.app/railway.schema.json",
#   "build": {
#     "builder": "DOCKERFILE",
#     "dockerfilePath": "./Dockerfile"
#   },
#   "deploy": {
#     "startCommand": "dotnet XIIGen.Service.dll",
#     "healthcheckPath": "/health/live",
#     "healthcheckTimeout": 30,
#     "restartPolicyType": "ON_FAILURE",
#     "restartPolicyMaxRetries": 3,
#     "numReplicas": 1
#   }
# }

# =============================================================================
# railway.toml — Service-level configuration (alternative format)
# =============================================================================
# [build]
# builder = "dockerfile"
# dockerfilePath = "./Dockerfile"
#
# [deploy]
# startCommand = "dotnet XIIGen.Service.dll"
# healthcheckPath = "/health/live"
# healthcheckTimeout = 30
# restartPolicyType = "ON_FAILURE"
# restartPolicyMaxRetries = 3
# numReplicas = 1

# =============================================================================
# DEPLOYMENT ARCHITECTURE (Railway Multi-Service Project)
# =============================================================================
# Railway Project: xiigen-{environment}
#
# Services (each from separate repo path or linked repo):
#   ├── api-gateway         → skills/09-trace-manager/dotnet
#   ├── flow-engine         → skills/10-flow-engine/dotnet
#   ├── ai-dispatcher       → skills/07-ai-dispatcher/dotnet
#   ├── rag-service         → skills/00a-rag-interfaces/dotnet
#   ├── feedback-service    → skills/14-feedback-loop/dotnet
#   ├── quality-scorer      → skills/15-quality-scorer/dotnet
#   ├── figma-parser        → skills/16-figma-parser/dotnet
#   ├── code-generator      → skills/20-code-generator/dotnet
#   ├── client-web          → skills/26-web-flow-editor/alternatives/react
#   ├── elasticsearch       → Plugin (Railway managed)
#   └── redis               → Plugin (Railway managed)
#
# DNA: Each service deployed independently with its own:
#   - Railway service entry
#   - Environment variables (scoped)
#   - Health check endpoint
#   - Resource allocation
#   - Auto-deploy on git push

# =============================================================================
# SETUP SCRIPT — deploy-railway.sh
# =============================================================================
#!/bin/bash
set -euo pipefail

PROJECT_NAME="${1:-xiigen}"
ENVIRONMENT="${2:-dev}"

echo "🚂 Setting up Railway project: ${PROJECT_NAME}-${ENVIRONMENT}"

# Install Railway CLI if not present
if ! command -v railway &>/dev/null; then
  npm install -g @railway/cli
fi

# Login (interactive)
railway login

# Create project
railway init --name "${PROJECT_NAME}-${ENVIRONMENT}"

# --- Add managed plugins ---
echo "📦 Adding Elasticsearch plugin..."
railway add --plugin elasticsearch

echo "📦 Adding Redis plugin..."
railway add --plugin redis

# --- Configure shared variables ---
railway variables set \
  ASPNETCORE_ENVIRONMENT="${ENVIRONMENT}" \
  LOG_LEVEL="Information" \
  SCOPE_ISOLATION="true"

# --- Deploy core services ---
SERVICES=(
  "api-gateway:skills/09-trace-manager/dotnet"
  "flow-engine:skills/10-flow-engine/dotnet"
  "ai-dispatcher:skills/07-ai-dispatcher/dotnet"
  "rag-service:skills/00a-rag-interfaces/dotnet"
  "feedback-service:skills/14-feedback-loop/dotnet"
  "quality-scorer:skills/15-quality-scorer/dotnet"
  "figma-parser:skills/16-figma-parser/dotnet"
  "code-generator:skills/20-code-generator/dotnet"
)

for entry in "${SERVICES[@]}"; do
  SERVICE_NAME="${entry%%:*}"
  SERVICE_PATH="${entry##*:}"
  
  echo "🚀 Deploying ${SERVICE_NAME} from ${SERVICE_PATH}..."
  
  # Create service
  railway service create "${SERVICE_NAME}"
  railway service "${SERVICE_NAME}"
  
  # Set service-specific variables
  railway variables set \
    SERVICE_NAME="${SERVICE_NAME}" \
    PORT="8080"
  
  # Link to source directory
  railway up --service "${SERVICE_NAME}" --directory "${SERVICE_PATH}"
  
  echo "✅ ${SERVICE_NAME} deployed"
done

# --- Deploy client ---
echo "🚀 Deploying client-web..."
railway service create "client-web"
railway service "client-web"
railway variables set \
  REACT_APP_API_URL="https://${PROJECT_NAME}-${ENVIRONMENT}-api-gateway.up.railway.app"
railway up --service "client-web" --directory "skills/26-web-flow-editor/alternatives/react"

echo "✅ All services deployed to Railway!"
echo "📊 Dashboard: https://railway.app/project"

# =============================================================================
# ENVIRONMENT VARIABLES (per service on Railway dashboard)
# =============================================================================
# Shared (Railway auto-injects plugin URLs):
#   ELASTICSEARCH_URL     → Auto from plugin
#   REDIS_URL             → Auto from plugin
#   ASPNETCORE_ENVIRONMENT → dev/staging/production
#   LOG_LEVEL             → Information/Warning/Error
#   SCOPE_ISOLATION       → true
#
# Service-specific:
#   AI_API_KEY            → Set per ai-dispatcher service
#   OPENAI_API_KEY        → Set per ai-dispatcher
#   ANTHROPIC_API_KEY     → Set per ai-dispatcher
#   FIGMA_ACCESS_TOKEN    → Set per figma-parser
#
# DNA: Secrets never in code, always Railway variables

# =============================================================================
# CI/CD — GitHub Actions integration
# =============================================================================
# Railway auto-deploys on push to linked branch.
# For manual control, add to .github/workflows/railway.yml:
#
# name: Deploy to Railway
# on:
#   push:
#     branches: [main, staging]
# jobs:
#   deploy:
#     runs-on: ubuntu-latest
#     steps:
#       - uses: actions/checkout@v4
#       - uses: railwayapp/railway-github-action@v1
#         with:
#           railway_token: ${{ secrets.RAILWAY_TOKEN }}
#           service: ${{ matrix.service }}
#     strategy:
#       matrix:
#         service: [api-gateway, flow-engine, ai-dispatcher, rag-service]

# =============================================================================
# COST ESTIMATE (Railway pricing as of 2025)
# =============================================================================
# Hobby plan: $5/mo + usage
# Pro plan: $20/mo + usage
# Per service: ~$5-15/mo depending on CPU/memory
# Elasticsearch plugin: ~$10-30/mo
# Redis plugin: ~$5-10/mo
# Estimated total (dev): ~$50-100/mo
# Estimated total (prod): ~$150-400/mo
