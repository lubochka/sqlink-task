# Skill 27: Kubernetes Deployment — Implementation Prompt

## Phase 1: Dockerfiles
Multi-stage Dockerfile per service. Base image optimization. Health check endpoint integration.

## Phase 2: Helm Charts
Configurable values.yaml for: database provider/URL, queue provider/URL, AI provider keys, replica count.
Generic — same chart works for all microservices with different values.

## Phase 3: K8s Resources
Deployment, Service, Ingress, ConfigMap, Secret manifests.
HPA based on queue depth (Redis Stream length) and CPU.
Pod disruption budgets for graceful rollouts.

## Phase 4: CI/CD Integration
GitHub Actions / GitLab CI pipeline. Build → test → push → deploy stages.
DNA validation gate: verify DataProcessResult usage, no typed models where dynamic docs required.

---

## Genie DNA Compliance — MANDATORY
☐ DNA-1: Dynamic Documents — `Dictionary<string, object>`, NOT typed models
☐ DNA-2: BuildSearchFilter — skip empty fields, no entity-specific query code
☐ DNA-3: MicroserviceBase — inherit DB, queue, cache, logger
☐ DNA-5: DataProcessResult<T> — all methods return result wrapper
☐ DNA-6: Generic Interfaces — external deps behind interfaces, swap via config
☐ DNA-SCOPE: Non-admin queries auto-inject userId filter
