# Skill 11: AI Transform Executor — Implementation Prompt

## Prerequisites
- Skill 01 (Core Interfaces): IStepExecutor, MicroserviceBase, DataProcessResult
- Skill 02 (Object Processor): Template variable injection, dynamic document parsing
- Skill 06 (AI Providers): IAiProvider interface
- Skill 07 (AI Dispatcher): Multi-model dispatch, fallback chains
- Skill 13 (Feedback Service): IFeedbackService for past feedback queries

## Implementation Steps

### Step 1: Configuration & Templates
1. Create `AiTransformConfig` with: defaultModel, temperature, maxTokens, parallelModels, maxFeedbackItems, retryOnParseFailure, maxRetries, promptTemplate
2. Define prompt templates as dynamic documents — at minimum `default-transform` and `figma-to-code`
3. Template variables: `{{input}}`, `{{feedback_positive}}`, `{{feedback_negative}}`, `{{language}}`, `{{framework}}`, `{{constraints}}`
4. Support conditionals: `{{#if var}}...{{/if}}` — only render block if variable is non-empty

### Step 2: Feedback Loading (Genie DNA-2)
1. Build search filter using **only non-empty fields** — flowId, stepType, componentSimilarity
2. Query FeedbackService with BuildSearchFilter pattern
3. Limit results to `maxFeedbackItems`
4. Graceful degradation: if feedback service unavailable, proceed without feedback
5. Separate results into positive (rating ≥ 4) and negative (rating ≤ 2)

### Step 3: Prompt Building
1. Load template by name from template store
2. Inject variables via ObjectProcessor (DNA-1: no fixed template class)
3. Process conditionals — remove empty sections
4. Inject positive feedback as "Patterns to Follow" section
5. Inject negative feedback as "Patterns to Avoid" section
6. Include system prompt from step configuration if present

### Step 4: AI Dispatch
1. Determine models: use `parallelModels` if set, otherwise single `defaultModel`
2. **Single dispatch**: await one model response via AiDispatcher (Skill 07)
3. **Parallel dispatch**: fan-out same prompt to N models via Task.WhenAll / Promise.all
4. Collect all responses as DataProcessResult items (DNA-5)
5. Implement retry: on failure, retry up to `maxRetries` with same prompt

### Step 5: Response Parsing
1. Extract fenced code blocks: regex ```` ```(\w*)\n([\s\S]*?)``` ````
2. Detect language from fence tag (default: "text")
3. Extract explanation: everything outside code blocks
4. Return structured: `{ codeBlocks: [{language, code}], explanation, rawContent }`

### Step 6: Debug Data & DI Registration
1. Capture: executionId, promptLength, templateUsed, feedbackLoaded, modelsUsed, codeBlocksExtracted, durationMs
2. Store via Skill 14 (Node Debugger) if available
3. Register as `IStepExecutor` with step type `"ai-transform"`
4. DI: `services.AddXIIGenAiTransform(config => { ... })`

## Genie DNA Checklist
- [ ] DNA-1: AI responses stored as Dictionary<string, object> — no fixed response class
- [ ] DNA-2: Feedback search uses BuildSearchFilter — empty fields auto-skipped
- [ ] DNA-5: DataProcessResult pattern for per-model success/failure tracking

## Validation
- Single model dispatch returns code blocks for valid input
- Multi-model dispatch returns results from all models
- Feedback injection: positive examples appear in "Follow" section, negative in "Avoid"
- Empty feedback: prompt renders without feedback sections
- Retry: failed parse triggers retry with same prompt
- Graceful degradation: works without feedback service
