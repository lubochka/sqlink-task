---
name: ai-transform-executor
description: Step executor that prepares prompts with feedback injection, dispatches to multiple AI models in parallel, and returns best transformation result
triggers: ai transform, code generation step, ai executor, prompt with feedback, multi-model dispatch
dependencies: [01-core-interfaces, 02-object-processor, 06-ai-providers, 07-ai-dispatcher, 13-feedback-service]
layer: L4-StepExecutors
genie-dna: AI responses stored as dynamic documents. Prompt templates use ObjectProcessor for variable injection. Feedback search uses BuildSearchFilter.
phase: 3
---

# Skill 11: AI Transform Executor
## The Main Chef — Prepares Prompts, Injects Feedback, Dispatches to AI

The core AI processing step in every flow. Takes input (parsed Figma components, user requirements, or any data), builds a rich prompt that includes relevant past feedback (positive examples to follow, negative examples to avoid), dispatches to one or more AI models via the AiDispatcher (Skill 07), and returns the best result.

---

## Architecture

```
FlowOrchestrator (Skill 09) calls ExecuteAsync(context)
       ↓
  AiTransformExecutor
       ↓ 1. Extract input data + step configuration
       ↓ 2. Load relevant feedback (Skill 13)
       ↓    └─ Search by: flowId, stepType, component similarity
       ↓    └─ Separate into positive/negative examples
       ↓ 3. Build prompt from template + input + feedback
       ↓    └─ Template variables: {{components}}, {{feedback_positive}},
       ↓       {{feedback_negative}}, {{language}}, {{framework}}, {{context}}
       ↓ 4. Dispatch to AI models (Skill 07)
       ↓    └─ Single model: await one response
       ↓    └─ Multi-model: fan-out to N models, collect all results
       ↓ 5. Parse AI response → structured output
       ↓ 6. Store debug data (prompt, response, tokens, duration)
       ↓
  StepExecutionResult { output, debugData }
```

## Key Features

### 1. Prompt Template System
Templates are stored as dynamic documents with variable placeholders. Variables are injected via ObjectProcessor — no string concatenation, no fixed template classes.

Built-in template variables:
- `{{input}}` — The step input data (serialized JSON)
- `{{feedback_positive}}` — Past successful outputs for similar inputs
- `{{feedback_negative}}` — Past failed outputs to avoid
- `{{feedback_text}}` — User's free-text feedback comments
- `{{language}}` — Target programming language
- `{{framework}}` — Target framework (React, Angular, etc.)
- `{{context}}` — Additional context from RAG (Skill 16)
- `{{system_prompt}}` — System-level instructions
- `{{constraints}}` — Output format constraints

### 2. Feedback Injection
Before every AI call, queries FeedbackService (Skill 13) for relevant past feedback:
- Searches by flowId + stepType for direct matches
- Searches by input similarity for related transformations
- Separates into positive (good ratings), negative (bad ratings), neutral
- Injects positive examples as "Follow these patterns" in the prompt
- Injects negative examples as "Avoid these patterns" in the prompt

### 3. Multi-Model Parallel Dispatch
Can dispatch to multiple AI models simultaneously:
- Fan-out via Task.WhenAll / Promise.all
- Each model gets the same prompt
- All responses collected for comparison (used by Skill 12 reviewer)
- Or single best response selected by configurable strategy

### 4. Response Parsing
AI responses are parsed into structured output:
- Code blocks extracted with language detection
- Metadata extracted (confidence scores, explanation)
- Validation against expected output format
- Error recovery: retry with clarified prompt on parsing failure

### 5. Debug Data Capture
Every execution records (stored via Skill 14):
- Full prompt text (with all injections)
- Model name, temperature, max tokens
- Raw response text
- Token counts (input + output)
- Duration in milliseconds
- Feedback items used (IDs + ratings)

## Configuration

```json
{
  "aiTransform": {
    "defaultModel": "claude-sonnet-4-20250514",
    "temperature": 0.3,
    "maxTokens": 4096,
    "parallelModels": ["claude-sonnet-4-20250514", "gpt-4o"],
    "maxFeedbackItems": 10,
    "feedbackSimilarityThreshold": 0.7,
    "retryOnParseFailure": true,
    "maxRetries": 2,
    "promptTemplate": "default-transform"
  }
}
```

## Genie DNA Integration
- DNA-1: AI responses stored as dynamic documents — no fixed response model
- DNA-2: Feedback search uses BuildSearchFilter — any combination of flowId, stepType, rating, dateRange
- DNA-5: DataProcessResult pattern for structured success/failure per model response

## Dependencies
| Skill | Usage |
|---|---|
| 01-core-interfaces | IStepExecutor, MicroserviceBase |
| 02-object-processor | Template variable injection, response parsing |
| 06-ai-providers | IAiProvider interface |
| 07-ai-dispatcher | Multi-model dispatch, fallback chains |
| 13-feedback-service | Load relevant past feedback |

## Alternatives
| Language | File | Notes |
|---|---|---|
| .NET 9 (primary) | `Implementation/AiTransformExecutor.cs` | Full feature set |
| Node.js/TypeScript | `alternatives/nodejs/ai-transform-executor.ts` | Async/await native |
| Python | `alternatives/python/ai_transform_executor.py` | ML pipeline friendly |
| Java | `alternatives/java/AiTransformExecutor.java` | Enterprise |
| Rust | `alternatives/rust/ai_transform_executor.rs` | Performance-critical |
| PHP | `alternatives/php/AiTransformExecutor.php` | CMS integration |
