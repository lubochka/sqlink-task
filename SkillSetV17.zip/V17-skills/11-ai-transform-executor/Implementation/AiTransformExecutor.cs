// XIIGen.FlowEngine/StepExecutors/AiTransformExecutor.cs - Skill 11 | .NET 9
// Enhanced: Prompt templates, feedback injection, multi-model dispatch, debug capture
using System.Diagnostics;
using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;
using XIIGen.AI.Dispatch;
using XIIGen.AI.Providers;

namespace XIIGen.FlowEngine.StepExecutors;

/// <summary>
/// Core AI processing step. Builds prompts with feedback injection,
/// dispatches to AI models, parses and returns structured results.
/// Implements IStepExecutor for flow engine integration.
/// </summary>
public class AiTransformExecutor : IStepExecutor
{
    public string NodeTypeName => "AiTransform";

    private readonly ILogger<AiTransformExecutor> _logger;
    private readonly IAiDispatcher _aiDispatcher;
    private readonly IFeedbackService _feedbackService;
    private readonly IObjectProcessor _objectProcessor;
    private readonly IDatabaseService _db;
    private readonly AiTransformConfig _config;

    public AiTransformExecutor(
        ILogger<AiTransformExecutor> logger,
        IAiDispatcher aiDispatcher,
        IFeedbackService feedbackService,
        IObjectProcessor objectProcessor,
        IDatabaseService db,
        AiTransformConfig config = null)
    {
        _logger = logger;
        _aiDispatcher = aiDispatcher;
        _feedbackService = feedbackService;
        _objectProcessor = objectProcessor;
        _db = db;
        _config = config ?? new AiTransformConfig();
    }

    public async Task<StepExecutionResult> ExecuteAsync(StepExecutionContext context, CancellationToken ct = default)
    {
        var sw = Stopwatch.StartNew();
        var traceId = context.TraceId;
        var stepId = context.StepId;

        try
        {
            // 1. Extract input and configuration
            var input = context.Input;
            var stepConfig = context.Configuration ?? new Dictionary<string, object>();
            var modelName = GetConfigValue(stepConfig, "model", _config.DefaultModel);
            var temperature = GetConfigDouble(stepConfig, "temperature", _config.Temperature);
            var maxTokens = GetConfigInt(stepConfig, "maxTokens", _config.MaxTokens);
            var templateName = GetConfigValue(stepConfig, "promptTemplate", _config.PromptTemplate);

            // 2. Load relevant feedback
            var feedback = await LoadRelevantFeedback(traceId, "AiTransform", input, ct);
            _logger.LogInformation("Loaded {Count} feedback items for trace {TraceId}", feedback.Count, traceId);

            // 3. Build prompt from template + input + feedback
            var prompt = BuildPrompt(templateName, input, feedback, stepConfig);

            // 4. Determine dispatch strategy
            var parallelModels = GetConfigList(stepConfig, "parallelModels", _config.ParallelModels);

            Dictionary<string, object> output;
            if (parallelModels != null && parallelModels.Count > 1)
            {
                // Multi-model parallel dispatch
                output = await DispatchParallel(prompt, parallelModels, temperature, maxTokens, ct);
            }
            else
            {
                // Single model dispatch
                output = await DispatchSingle(prompt, modelName, temperature, maxTokens, ct);
            }

            sw.Stop();

            // 5. Build debug data
            var debugData = new Dictionary<string, object>
            {
                ["prompt"] = prompt,
                ["model"] = modelName,
                ["temperature"] = temperature,
                ["maxTokens"] = maxTokens,
                ["feedbackCount"] = feedback.Count,
                ["feedbackIds"] = feedback.Select(f => f.GetValueOrDefault("id", "")).ToList(),
                ["durationMs"] = sw.ElapsedMilliseconds,
                ["parallelModels"] = parallelModels
            };

            // 6. Store execution record as dynamic document
            var execRecord = _objectProcessor.ParseObjectAlternative(new
            {
                traceId, stepId, stepType = "AiTransform",
                prompt = prompt.Length > 500 ? prompt[..500] + "..." : prompt,
                modelName, temperature, maxTokens,
                feedbackCount = feedback.Count,
                durationMs = sw.ElapsedMilliseconds,
                success = true,
                timestamp = DateTime.UtcNow.ToString("O")
            });
            await _db.UpsertAsync("xiigen-transform-executions", $"{traceId}_{stepId}", execRecord);

            return StepExecutionResult.Ok(output, debugData);
        }
        catch (Exception ex)
        {
            sw.Stop();
            _logger.LogError(ex, "AiTransform failed for trace {TraceId}, step {StepId}", traceId, stepId);

            // Retry logic
            var retryCount = context.GetRetryCount();
            if (_config.RetryOnParseFailure && retryCount < _config.MaxRetries)
            {
                _logger.LogWarning("Retrying AiTransform (attempt {Attempt}/{Max})", retryCount + 1, _config.MaxRetries);
                return StepExecutionResult.Retry(ex.Message, retryCount + 1);
            }

            return StepExecutionResult.Fail(ex.Message, new Dictionary<string, object>
            {
                ["durationMs"] = sw.ElapsedMilliseconds,
                ["error"] = ex.Message,
                ["retryCount"] = retryCount
            });
        }
    }

    // ── Feedback Loading ───────────────────────────────────────────────
    private async Task<List<Dictionary<string, object>>> LoadRelevantFeedback(
        string traceId, string stepType, object input, CancellationToken ct)
    {
        try
        {
            // Build search filter — Genie DNA-2: empty fields auto-skipped
            var filter = _objectProcessor.BuildSearchFilter(new
            {
                stepType,
                rating = "", // don't filter by rating — we want all
                limit = _config.MaxFeedbackItems
            });

            var allFeedback = await _feedbackService.SearchFeedbackAsync(filter, ct);

            // Separate into positive and negative
            return allFeedback?.Take(_config.MaxFeedbackItems).ToList()
                   ?? new List<Dictionary<string, object>>();
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to load feedback, continuing without it");
            return new List<Dictionary<string, object>>();
        }
    }

    // ── Prompt Building ────────────────────────────────────────────────
    public string BuildPrompt(string templateName, object input, List<Dictionary<string, object>> feedback, Dictionary<string, object> config)
    {
        var template = LoadTemplate(templateName);
        var inputJson = JsonSerializer.Serialize(input, new JsonSerializerOptions { WriteIndented = true });

        // Separate feedback by rating
        var positive = feedback.Where(f => IsPositive(f)).ToList();
        var negative = feedback.Where(f => IsNegative(f)).ToList();

        // Build feedback sections
        var positiveSec = positive.Count > 0
            ? "FOLLOW THESE SUCCESSFUL PATTERNS:\n" + string.Join("\n---\n",
                positive.Select(f => f.GetValueOrDefault("output", "").ToString()))
            : "";

        var negativeSec = negative.Count > 0
            ? "AVOID THESE FAILED PATTERNS:\n" + string.Join("\n---\n",
                negative.Select(f => $"Issue: {f.GetValueOrDefault("feedbackText", "")}\nFailed output: {f.GetValueOrDefault("output", "")}"))
            : "";

        var userFeedback = string.Join("\n",
            feedback.Where(f => !string.IsNullOrEmpty(f.GetValueOrDefault("feedbackText", "")?.ToString()))
                    .Select(f => f["feedbackText"].ToString()));

        // Inject variables into template
        var prompt = template
            .Replace("{{input}}", inputJson)
            .Replace("{{feedback_positive}}", positiveSec)
            .Replace("{{feedback_negative}}", negativeSec)
            .Replace("{{feedback_text}}", userFeedback)
            .Replace("{{language}}", config.GetValueOrDefault("language", "").ToString())
            .Replace("{{framework}}", config.GetValueOrDefault("framework", "").ToString())
            .Replace("{{context}}", config.GetValueOrDefault("context", "").ToString());

        return prompt;
    }

    private string LoadTemplate(string templateName)
    {
        // Default template — can be overridden by stored templates
        return templateName switch
        {
            "figma-to-code" => @"You are a senior frontend developer. Convert these Figma components to production-ready code.

Target Language: {{language}}
Target Framework: {{framework}}

## Input Components
{{input}}

## Additional Context
{{context}}

{{feedback_positive}}

{{feedback_negative}}

## User Feedback
{{feedback_text}}

## Output Requirements
- Production-ready, clean code
- Responsive layout
- Semantic HTML
- Proper component structure
- Include CSS/styles inline or as styled components
- Return code in ```code``` blocks with language tag",

            _ => @"Transform the following input according to the step requirements.

## Input
{{input}}

## Context
{{context}}

{{feedback_positive}}

{{feedback_negative}}

## User Feedback
{{feedback_text}}

## Requirements
- Return structured, well-formatted output
- Include code in ```code``` blocks if applicable
- Explain key decisions briefly"
        };
    }

    // ── AI Dispatch ────────────────────────────────────────────────────
    private async Task<Dictionary<string, object>> DispatchSingle(
        string prompt, string model, double temperature, int maxTokens, CancellationToken ct)
    {
        var response = await _aiDispatcher.SendAsync(new AiRequest
        {
            Model = model,
            Prompt = prompt,
            Temperature = temperature,
            MaxTokens = maxTokens
        }, ct);

        var parsed = ParseAiResponse(response);
        parsed["model"] = model;
        parsed["singleModel"] = true;
        return parsed;
    }

    private async Task<Dictionary<string, object>> DispatchParallel(
        string prompt, List<string> models, double temperature, int maxTokens, CancellationToken ct)
    {
        var tasks = models.Select(model => Task.Run(async () =>
        {
            try
            {
                var response = await _aiDispatcher.SendAsync(new AiRequest
                {
                    Model = model,
                    Prompt = prompt,
                    Temperature = temperature,
                    MaxTokens = maxTokens
                }, ct);

                var parsed = ParseAiResponse(response);
                parsed["model"] = model;
                parsed["success"] = true;
                return parsed;
            }
            catch (Exception ex)
            {
                return new Dictionary<string, object>
                {
                    ["model"] = model,
                    ["success"] = false,
                    ["error"] = ex.Message
                };
            }
        }, ct));

        var results = await Task.WhenAll(tasks);

        return new Dictionary<string, object>
        {
            ["responses"] = results.ToList(),
            ["successCount"] = results.Count(r => (bool)r.GetValueOrDefault("success", false)),
            ["totalModels"] = models.Count,
            ["parallelDispatch"] = true
        };
    }

    // ── Response Parsing ───────────────────────────────────────────────
    public Dictionary<string, object> ParseAiResponse(AiResponse response)
    {
        var text = response.Text ?? "";

        // Extract code blocks
        var codeBlocks = new List<Dictionary<string, object>>();
        var codeRegex = new Regex(@"```(\w+)?\n([\s\S]*?)```", RegexOptions.Multiline);
        foreach (Match match in codeRegex.Matches(text))
        {
            codeBlocks.Add(new Dictionary<string, object>
            {
                ["language"] = match.Groups[1].Value,
                ["code"] = match.Groups[2].Value.Trim()
            });
        }

        // Extract explanation (text outside code blocks)
        var explanation = codeRegex.Replace(text, "").Trim();

        return new Dictionary<string, object>
        {
            ["text"] = text,
            ["codeBlocks"] = codeBlocks,
            ["explanation"] = explanation,
            ["inputTokens"] = response.InputTokens,
            ["outputTokens"] = response.OutputTokens,
            ["finishReason"] = response.FinishReason ?? "stop"
        };
    }

    // ── Helpers ─────────────────────────────────────────────────────────
    private static bool IsPositive(Dictionary<string, object> f) =>
        f.GetValueOrDefault("rating", "").ToString().ToLower() is "positive" or "good";

    private static bool IsNegative(Dictionary<string, object> f) =>
        f.GetValueOrDefault("rating", "").ToString().ToLower() is "negative" or "bad";

    private static string GetConfigValue(Dictionary<string, object> config, string key, string def) =>
        config.TryGetValue(key, out var v) ? v?.ToString() ?? def : def;

    private static double GetConfigDouble(Dictionary<string, object> config, string key, double def) =>
        config.TryGetValue(key, out var v) && double.TryParse(v?.ToString(), out var d) ? d : def;

    private static int GetConfigInt(Dictionary<string, object> config, string key, int def) =>
        config.TryGetValue(key, out var v) && int.TryParse(v?.ToString(), out var i) ? i : def;

    private static List<string> GetConfigList(Dictionary<string, object> config, string key, List<string> def) =>
        config.TryGetValue(key, out var v) && v is IEnumerable<object> list ? list.Select(x => x.ToString()).ToList() : def;
}

/// <summary>Configuration for AiTransformExecutor.</summary>
public class AiTransformConfig
{
    public string DefaultModel { get; set; } = "claude-sonnet-4-20250514";
    public double Temperature { get; set; } = 0.3;
    public int MaxTokens { get; set; } = 4096;
    public List<string> ParallelModels { get; set; } = null;
    public int MaxFeedbackItems { get; set; } = 10;
    public double FeedbackSimilarityThreshold { get; set; } = 0.7;
    public bool RetryOnParseFailure { get; set; } = true;
    public int MaxRetries { get; set; } = 2;
    public string PromptTemplate { get; set; } = "default-transform";
}

/// <summary>DI registration extensions.</summary>
public static class AiTransformExtensions
{
    public static IServiceCollection AddXIIGenAiTransform(this IServiceCollection services, Action<AiTransformConfig> configure = null)
    {
        var config = new AiTransformConfig();
        configure?.Invoke(config);
        services.AddSingleton(config);
        services.AddTransient<AiTransformExecutor>();
        services.AddTransient<IStepExecutor>(sp => sp.GetRequiredService<AiTransformExecutor>());
        return services;
    }
}
