"""
Skill 11: AI Transform Executor — Python
Prepares prompts with feedback injection, dispatches to AI models, returns best result.
Genie DNA: Dynamic documents (dicts), BuildSearchFilter, DataProcessResult.
"""

import re
import json
import asyncio
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Protocol


# --- Interfaces (from core-interfaces) ---
class IFeedbackService(Protocol):
    async def search_feedback(self, filter_dict: dict[str, Any]) -> list[dict[str, Any]]: ...

class IAiDispatcher(Protocol):
    async def dispatch(self, request: dict[str, Any]) -> dict[str, Any]: ...


@dataclass
class AiTransformConfig:
    default_model: str = "claude-sonnet-4-20250514"
    temperature: float = 0.3
    max_tokens: int = 4096
    parallel_models: list[str] = field(default_factory=list)
    max_feedback_items: int = 10
    feedback_similarity_threshold: float = 0.7
    retry_on_parse_failure: bool = True
    max_retries: int = 2
    prompt_template: str = "default-transform"


# --- Prompt Templates ---
TEMPLATES: dict[str, str] = {
    "default-transform": """You are a code transformation AI.

Input:
{{input}}

{% if feedback_positive %}
## Patterns to Follow (from successful past outputs):
{{feedback_positive}}
{% endif %}

{% if feedback_negative %}
## Patterns to Avoid (from failed past outputs):
{{feedback_negative}}
{% endif %}

Target Language: {{language}}
Target Framework: {{framework}}

{% if constraints %}
Output Constraints: {{constraints}}
{% endif %}

Generate production-ready code. Return code in fenced code blocks with language tags.""",

    "figma-to-code": """You are a Figma-to-Code transformation AI.

## Design Components:
{{input}}

{% if feedback_positive %}
## Successful Past Transformations (follow these patterns):
{{feedback_positive}}
{% endif %}

{% if feedback_negative %}
## Failed Past Transformations (avoid these patterns):
{{feedback_negative}}
{% endif %}

Target: {{language}} with {{framework}}

Generate clean, responsive, production-ready components.
Return each component in a separate fenced code block.""",
}


class AiTransformExecutor:
    """Main AI Transform step executor with feedback injection and multi-model dispatch."""

    def __init__(
        self,
        config: AiTransformConfig | None = None,
        feedback_service: IFeedbackService | None = None,
        ai_dispatcher: IAiDispatcher | None = None,
    ):
        self.config = config or AiTransformConfig()
        self.feedback_service = feedback_service
        self.ai_dispatcher = ai_dispatcher

    async def execute_async(self, context: dict[str, Any]) -> dict[str, Any]:
        """Execute AI transform step: load feedback → build prompt → dispatch → parse."""
        start_time = datetime.now(timezone.utc)
        debug_data: dict[str, Any] = {
            "execution_id": str(uuid.uuid4()),
            "step_id": context.get("step_id", ""),
            "step_type": context.get("step_type", ""),
            "started_at": start_time.isoformat(),
        }

        try:
            step_config = self._merge_step_config(context.get("configuration", {}))

            # 1. Load relevant feedback (Genie DNA-2: BuildSearchFilter)
            feedback = await self._load_relevant_feedback(context, step_config)
            debug_data["feedback_loaded"] = len(feedback)

            # 2. Separate positive/negative
            positive, negative = self._separate_feedback(feedback)

            # 3. Build prompt from template
            template_name = step_config.prompt_template
            prompt = self._build_prompt(template_name, context, positive, negative)
            debug_data["prompt_length"] = len(prompt)
            debug_data["template_used"] = template_name

            # 4. Dispatch to model(s)
            models = (
                step_config.parallel_models
                if step_config.parallel_models
                else [step_config.default_model]
            )

            if len(models) > 1:
                results = await self._dispatch_parallel(prompt, models, step_config, context)
            else:
                results = [await self._dispatch_single(prompt, models[0], step_config, context)]

            debug_data["models_used"] = models
            debug_data["results_summary"] = [
                {"model": r["metadata"].get("model"), "success": r["success"]}
                for r in results
            ]

            # 5. Select best successful result
            successful = [r for r in results if r["success"]]
            if not successful:
                errors = "; ".join(r.get("error", "unknown") for r in results)
                raise RuntimeError(f"All {len(models)} model(s) failed: {errors}")

            best = successful[0]

            # 6. Parse structured output
            parsed = self._parse_ai_response(best["item"]["content"])
            debug_data["code_blocks_extracted"] = len(parsed["code_blocks"])

            duration_ms = int((datetime.now(timezone.utc) - start_time).total_seconds() * 1000)

            return {
                "success": True,
                "output": {
                    **parsed,
                    "model": best["metadata"]["model"],
                    "all_results": [r["item"] for r in results],
                },
                "debug_data": debug_data,
                "duration_ms": duration_ms,
            }

        except Exception as e:
            duration_ms = int((datetime.now(timezone.utc) - start_time).total_seconds() * 1000)
            debug_data["error"] = str(e)
            return {
                "success": False,
                "output": {},
                "debug_data": debug_data,
                "duration_ms": duration_ms,
                "error": str(e),
            }

    # --- Feedback (Genie DNA-2: BuildSearchFilter — skip empty fields) ---
    async def _load_relevant_feedback(
        self, context: dict[str, Any], config: AiTransformConfig
    ) -> list[dict[str, Any]]:
        if not self.feedback_service:
            return []

        # Build filter — only non-empty fields (DNA-2)
        search_filter: dict[str, Any] = {}
        if context.get("flow_id"):
            search_filter["flow_id"] = context["flow_id"]
        if context.get("step_type"):
            search_filter["step_type"] = context["step_type"]

        try:
            results = await self.feedback_service.search_feedback(search_filter)
            return results[: config.max_feedback_items]
        except Exception:
            return []

    def _separate_feedback(
        self, feedback: list[dict[str, Any]]
    ) -> tuple[str, str]:
        positive_items: list[str] = []
        negative_items: list[str] = []

        for item in feedback:
            rating = item.get("rating", 3)
            output = item.get("output", item.get("content", ""))
            comment = item.get("comment", "")
            entry = f"{output}\n(User note: {comment})" if comment else str(output)

            if rating >= 4:
                positive_items.append(entry)
            elif rating <= 2:
                negative_items.append(entry)

        return "\n---\n".join(positive_items), "\n---\n".join(negative_items)

    # --- Prompt Building ---
    def _build_prompt(
        self,
        template_name: str,
        context: dict[str, Any],
        positive: str,
        negative: str,
    ) -> str:
        template = TEMPLATES.get(template_name, TEMPLATES["default-transform"])
        config = context.get("configuration", {})

        variables = {
            "input": json.dumps(context.get("input", {}), indent=2),
            "feedback_positive": positive,
            "feedback_negative": negative,
            "language": config.get("language", "TypeScript"),
            "framework": config.get("framework", "React"),
            "constraints": config.get("constraints", ""),
        }

        # Handle conditionals {% if var %}...{% endif %}
        def replace_conditional(match: re.Match) -> str:
            var_name = match.group(1)
            content = match.group(2)
            return content if variables.get(var_name, "").strip() else ""

        result = re.sub(
            r"\{%\s*if\s+(\w+)\s*%\}([\s\S]*?)\{%\s*endif\s*%\}",
            replace_conditional,
            template,
        )

        # Replace {{var}} placeholders
        for key, value in variables.items():
            result = result.replace(f"{{{{{key}}}}}", value)

        return result

    # --- AI Dispatch ---
    async def _dispatch_single(
        self,
        prompt: str,
        model: str,
        config: AiTransformConfig,
        context: dict[str, Any],
    ) -> dict[str, Any]:
        """Dispatch to a single model with retry logic (Genie DNA-5: DataProcessResult)."""
        if not self.ai_dispatcher:
            return {
                "success": False,
                "item": {},
                "error": "No AI dispatcher configured",
                "metadata": {"model": model},
            }

        max_attempts = (config.max_retries + 1) if config.retry_on_parse_failure else 1
        last_error = ""

        for attempt in range(1, max_attempts + 1):
            try:
                request = {
                    "request_id": f"{context.get('trace_id', '')}-{uuid.uuid4().hex[:8]}",
                    "prompt": prompt,
                    "system_prompt": context.get("configuration", {}).get("system_prompt"),
                    "model": model,
                    "temperature": config.temperature,
                    "max_tokens": config.max_tokens,
                }

                response = await self.ai_dispatcher.dispatch(request)

                if not response.get("success"):
                    last_error = response.get("error", "Unknown error")
                    continue

                return {
                    "success": True,
                    "item": {"content": response["content"], "model": response["model"]},
                    "metadata": {
                        "model": response["model"],
                        "input_tokens": response.get("input_tokens", 0),
                        "output_tokens": response.get("output_tokens", 0),
                        "total_tokens": response.get("input_tokens", 0) + response.get("output_tokens", 0),
                        "duration_ms": response.get("duration_ms", 0),
                        "attempt": attempt,
                    },
                }
            except Exception as e:
                last_error = str(e)

        return {
            "success": False,
            "item": {},
            "error": f"Model {model} failed after {max_attempts} attempts: {last_error}",
            "metadata": {"model": model},
        }

    async def _dispatch_parallel(
        self,
        prompt: str,
        models: list[str],
        config: AiTransformConfig,
        context: dict[str, Any],
    ) -> list[dict[str, Any]]:
        """Fan-out to multiple models via asyncio.gather."""
        tasks = [self._dispatch_single(prompt, m, config, context) for m in models]
        return list(await asyncio.gather(*tasks))

    # --- Response Parsing ---
    def _parse_ai_response(self, content: str) -> dict[str, Any]:
        code_blocks: list[dict[str, str]] = []
        for match in re.finditer(r"```(\w*)\n([\s\S]*?)```", content):
            code_blocks.append({
                "language": match.group(1) or "text",
                "code": match.group(2).strip(),
            })

        explanation = re.sub(r"```\w*\n[\s\S]*?```", "", content).strip()
        return {"code_blocks": code_blocks, "explanation": explanation, "raw_content": content}

    def _merge_step_config(self, step_config: dict[str, Any]) -> AiTransformConfig:
        overrides = step_config.get("ai_transform", {})
        merged = AiTransformConfig()
        for key, value in overrides.items():
            if hasattr(merged, key) and value is not None:
                setattr(merged, key, value)
        return merged
