/**
 * Skill 11: AI Transform Executor — Java 21
 * Prepares prompts with feedback injection, dispatches to AI models in parallel.
 * Genie DNA: Dynamic documents (Map), BuildSearchFilter, DataProcessResult.
 */
package com.xiigen.skills.aitransform;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;
import java.util.stream.*;

// --- Interfaces ---
interface IFeedbackService {
    CompletableFuture<List<Map<String, Object>>> searchFeedback(Map<String, Object> filter);
}

interface IAiDispatcher {
    CompletableFuture<Map<String, Object>> dispatch(Map<String, Object> request);
}

// --- Configuration ---
record AiTransformConfig(
    String defaultModel,
    double temperature,
    int maxTokens,
    List<String> parallelModels,
    int maxFeedbackItems,
    double feedbackSimilarityThreshold,
    boolean retryOnParseFailure,
    int maxRetries,
    String promptTemplate
) {
    static AiTransformConfig defaults() {
        return new AiTransformConfig(
            "claude-sonnet-4-20250514", 0.3, 4096,
            List.of(), 10, 0.7, true, 2, "default-transform"
        );
    }

    AiTransformConfig merge(Map<String, Object> overrides) {
        if (overrides == null || overrides.isEmpty()) return this;
        var sub = castMap(overrides.getOrDefault("aiTransform", Map.of()));
        return new AiTransformConfig(
            getOr(sub, "defaultModel", defaultModel),
            getOrDouble(sub, "temperature", temperature),
            getOrInt(sub, "maxTokens", maxTokens),
            getOrList(sub, "parallelModels", parallelModels),
            getOrInt(sub, "maxFeedbackItems", maxFeedbackItems),
            getOrDouble(sub, "feedbackSimilarityThreshold", feedbackSimilarityThreshold),
            getOrBool(sub, "retryOnParseFailure", retryOnParseFailure),
            getOrInt(sub, "maxRetries", maxRetries),
            getOr(sub, "promptTemplate", promptTemplate)
        );
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> castMap(Object o) {
        return o instanceof Map ? (Map<String, Object>) o : Map.of();
    }
    @SuppressWarnings("unchecked")
    private static <T> T getOr(Map<String, Object> m, String k, T def) {
        return m.containsKey(k) ? (T) m.get(k) : def;
    }
    @SuppressWarnings("unchecked")
    private static List<String> getOrList(Map<String, Object> m, String k, List<String> def) {
        return m.containsKey(k) ? (List<String>) m.get(k) : def;
    }
    private static int getOrInt(Map<String, Object> m, String k, int def) {
        return m.containsKey(k) ? ((Number) m.get(k)).intValue() : def;
    }
    private static double getOrDouble(Map<String, Object> m, String k, double def) {
        return m.containsKey(k) ? ((Number) m.get(k)).doubleValue() : def;
    }
    private static boolean getOrBool(Map<String, Object> m, String k, boolean def) {
        return m.containsKey(k) ? (Boolean) m.get(k) : def;
    }
}

// --- Prompt Templates ---
final class PromptTemplates {
    private static final Map<String, String> TEMPLATES = Map.of(
        "default-transform", """
            You are a code transformation AI.

            Input:
            {{input}}

            {{feedback_section}}

            Target Language: {{language}}
            Target Framework: {{framework}}

            {{constraints_section}}

            Generate production-ready code in fenced code blocks with language tags.""",

        "figma-to-code", """
            You are a Figma-to-Code transformation AI.

            ## Design Components:
            {{input}}

            {{feedback_section}}

            Target: {{language}} with {{framework}}

            Generate clean, responsive, production-ready components in separate code blocks."""
    );

    static String get(String name) {
        return TEMPLATES.getOrDefault(name, TEMPLATES.get("default-transform"));
    }
}

// --- Main Executor ---
public class AiTransformExecutor {

    private final AiTransformConfig config;
    private final IFeedbackService feedbackService;
    private final IAiDispatcher aiDispatcher;
    private final ExecutorService executor;

    public AiTransformExecutor(
        AiTransformConfig config,
        IFeedbackService feedbackService,
        IAiDispatcher aiDispatcher
    ) {
        this.config = config != null ? config : AiTransformConfig.defaults();
        this.feedbackService = feedbackService;
        this.aiDispatcher = aiDispatcher;
        this.executor = Executors.newVirtualThreadPerTaskExecutor();
    }

    public CompletableFuture<Map<String, Object>> executeAsync(Map<String, Object> context) {
        return CompletableFuture.supplyAsync(() -> {
            long startTime = System.currentTimeMillis();
            var debugData = new LinkedHashMap<String, Object>();
            debugData.put("executionId", UUID.randomUUID().toString());
            debugData.put("stepId", context.getOrDefault("stepId", ""));
            debugData.put("startedAt", Instant.now().toString());

            try {
                var stepConfig = config.merge(castMap(context.get("configuration")));

                // 1. Load feedback (DNA-2: BuildSearchFilter)
                var feedback = loadRelevantFeedback(context, stepConfig).join();
                debugData.put("feedbackLoaded", feedback.size());

                // 2. Separate positive/negative
                var separated = separateFeedback(feedback);

                // 3. Build prompt
                String templateName = stepConfig.promptTemplate();
                String prompt = buildPrompt(templateName, context,
                    separated.get("positive"), separated.get("negative"));
                debugData.put("promptLength", prompt.length());

                // 4. Dispatch
                var models = stepConfig.parallelModels().isEmpty()
                    ? List.of(stepConfig.defaultModel())
                    : stepConfig.parallelModels();

                List<Map<String, Object>> results;
                if (models.size() > 1) {
                    results = dispatchParallel(prompt, models, stepConfig, context);
                } else {
                    results = List.of(dispatchSingle(prompt, models.getFirst(), stepConfig, context).join());
                }

                debugData.put("modelsUsed", models);

                // 5. Select best
                var successful = results.stream()
                    .filter(r -> Boolean.TRUE.equals(r.get("success")))
                    .toList();

                if (successful.isEmpty()) {
                    throw new RuntimeException("All model(s) failed");
                }

                var best = successful.getFirst();
                var bestItem = castMap(best.get("item"));

                // 6. Parse response
                var parsed = parseAiResponse((String) bestItem.get("content"));
                debugData.put("codeBlocksExtracted", ((List<?>) parsed.get("codeBlocks")).size());

                long durationMs = System.currentTimeMillis() - startTime;

                var output = new LinkedHashMap<String, Object>(parsed);
                output.put("model", castMap(best.get("metadata")).get("model"));

                return Map.of(
                    "success", true,
                    "output", output,
                    "debugData", debugData,
                    "durationMs", durationMs
                );
            } catch (Exception e) {
                long durationMs = System.currentTimeMillis() - startTime;
                debugData.put("error", e.getMessage());
                return Map.of(
                    "success", false,
                    "output", Map.of(),
                    "debugData", debugData,
                    "durationMs", durationMs,
                    "error", e.getMessage()
                );
            }
        }, executor);
    }

    // --- Feedback Loading (DNA-2) ---
    private CompletableFuture<List<Map<String, Object>>> loadRelevantFeedback(
        Map<String, Object> context, AiTransformConfig cfg
    ) {
        if (feedbackService == null) return CompletableFuture.completedFuture(List.of());

        var filter = new LinkedHashMap<String, Object>();
        putIfPresent(filter, "flowId", context.get("flowId"));
        putIfPresent(filter, "stepType", context.get("stepType"));

        return feedbackService.searchFeedback(filter)
            .thenApply(list -> list.stream().limit(cfg.maxFeedbackItems()).toList())
            .exceptionally(ex -> List.of());
    }

    private Map<String, String> separateFeedback(List<Map<String, Object>> feedback) {
        var positive = new ArrayList<String>();
        var negative = new ArrayList<String>();

        for (var item : feedback) {
            int rating = item.containsKey("rating") ? ((Number) item.get("rating")).intValue() : 3;
            String output = String.valueOf(item.getOrDefault("output", item.getOrDefault("content", "")));
            String comment = String.valueOf(item.getOrDefault("comment", ""));
            String entry = comment.isEmpty() ? output : output + "\n(User note: " + comment + ")";

            if (rating >= 4) positive.add(entry);
            else if (rating <= 2) negative.add(entry);
        }

        return Map.of(
            "positive", String.join("\n---\n", positive),
            "negative", String.join("\n---\n", negative)
        );
    }

    // --- Prompt Building ---
    private String buildPrompt(String templateName, Map<String, Object> context,
                                String positive, String negative) {
        String template = PromptTemplates.get(templateName);
        var cfg = castMap(context.get("configuration"));

        String feedbackSection = buildFeedbackSection(positive, negative);
        String constraintsSection = cfg.containsKey("constraints")
            ? "Output Constraints: " + cfg.get("constraints") : "";

        return template
            .replace("{{input}}", toJsonString(context.get("input")))
            .replace("{{feedback_section}}", feedbackSection)
            .replace("{{language}}", String.valueOf(cfg.getOrDefault("language", "TypeScript")))
            .replace("{{framework}}", String.valueOf(cfg.getOrDefault("framework", "React")))
            .replace("{{constraints_section}}", constraintsSection);
    }

    private String buildFeedbackSection(String positive, String negative) {
        var sb = new StringBuilder();
        if (!positive.isBlank()) {
            sb.append("## Patterns to Follow:\n").append(positive).append("\n\n");
        }
        if (!negative.isBlank()) {
            sb.append("## Patterns to Avoid:\n").append(negative).append("\n");
        }
        return sb.toString();
    }

    // --- AI Dispatch ---
    private CompletableFuture<Map<String, Object>> dispatchSingle(
        String prompt, String model, AiTransformConfig cfg, Map<String, Object> context
    ) {
        return CompletableFuture.supplyAsync(() -> {
            int maxAttempts = cfg.retryOnParseFailure() ? cfg.maxRetries() + 1 : 1;
            String lastError = "";

            for (int attempt = 1; attempt <= maxAttempts; attempt++) {
                try {
                    var request = Map.<String, Object>of(
                        "requestId", context.getOrDefault("traceId", "") + "-" + UUID.randomUUID().toString().substring(0, 8),
                        "prompt", prompt,
                        "model", model,
                        "temperature", cfg.temperature(),
                        "maxTokens", cfg.maxTokens()
                    );

                    var response = aiDispatcher.dispatch(request).join();
                    if (!Boolean.TRUE.equals(response.get("success"))) {
                        lastError = String.valueOf(response.getOrDefault("error", "Unknown"));
                        continue;
                    }

                    int inTokens = ((Number) response.getOrDefault("inputTokens", 0)).intValue();
                    int outTokens = ((Number) response.getOrDefault("outputTokens", 0)).intValue();

                    return Map.of(
                        "success", true,
                        "item", Map.of("content", response.get("content"), "model", response.get("model")),
                        "metadata", Map.of(
                            "model", response.get("model"),
                            "totalTokens", inTokens + outTokens,
                            "durationMs", response.getOrDefault("durationMs", 0),
                            "attempt", attempt
                        )
                    );
                } catch (Exception e) {
                    lastError = e.getMessage();
                }
            }

            return Map.<String, Object>of(
                "success", false, "item", Map.of(),
                "error", "Model %s failed after %d attempts: %s".formatted(model, maxAttempts, lastError),
                "metadata", Map.of("model", model)
            );
        }, executor);
    }

    private List<Map<String, Object>> dispatchParallel(
        String prompt, List<String> models, AiTransformConfig cfg, Map<String, Object> context
    ) {
        var futures = models.stream()
            .map(m -> dispatchSingle(prompt, m, cfg, context))
            .toList();
        return futures.stream().map(CompletableFuture::join).toList();
    }

    // --- Response Parsing ---
    private Map<String, Object> parseAiResponse(String content) {
        var pattern = Pattern.compile("```(\\w*)\\n([\\s\\S]*?)```");
        var matcher = pattern.matcher(content);
        var codeBlocks = new ArrayList<Map<String, String>>();

        while (matcher.find()) {
            codeBlocks.add(Map.of(
                "language", matcher.group(1).isEmpty() ? "text" : matcher.group(1),
                "code", matcher.group(2).trim()
            ));
        }

        String explanation = content.replaceAll("```\\w*\\n[\\s\\S]*?```", "").trim();
        return Map.of("codeBlocks", codeBlocks, "explanation", explanation, "rawContent", content);
    }

    // --- Helpers ---
    @SuppressWarnings("unchecked")
    private static Map<String, Object> castMap(Object o) {
        return o instanceof Map ? (Map<String, Object>) o : Map.of();
    }

    private static void putIfPresent(Map<String, Object> map, String key, Object value) {
        if (value != null && !String.valueOf(value).isBlank()) map.put(key, value);
    }

    private static String toJsonString(Object obj) {
        if (obj == null) return "{}";
        if (obj instanceof String s) return s;
        return obj.toString(); // In production, use Jackson ObjectMapper
    }
}
