<?php
/**
 * Skill 11: AI Transform Executor — PHP 8.3
 * Prepares prompts with feedback injection, dispatches to AI models.
 * Genie DNA: Dynamic documents (arrays), BuildSearchFilter, DataProcessResult.
 */

declare(strict_types=1);

namespace XIIGen\Skills\AiTransform;

// --- Interfaces ---
interface FeedbackServiceInterface
{
    /** @return array<int, array<string, mixed>> */
    public function searchFeedback(array $filter): array;
}

interface AiDispatcherInterface
{
    /** @return array{success: bool, content?: string, model?: string, inputTokens?: int, outputTokens?: int, durationMs?: int, error?: string} */
    public function dispatch(array $request): array;
}

// --- Configuration ---
readonly class AiTransformConfig
{
    public function __construct(
        public string $defaultModel = 'claude-sonnet-4-20250514',
        public float $temperature = 0.3,
        public int $maxTokens = 4096,
        public array $parallelModels = [],
        public int $maxFeedbackItems = 10,
        public float $feedbackSimilarityThreshold = 0.7,
        public bool $retryOnParseFailure = true,
        public int $maxRetries = 2,
        public string $promptTemplate = 'default-transform',
    ) {}

    public static function fromArray(array $data, ?self $base = null): self
    {
        $b = $base ?? new self();
        return new self(
            defaultModel: $data['defaultModel'] ?? $b->defaultModel,
            temperature: (float)($data['temperature'] ?? $b->temperature),
            maxTokens: (int)($data['maxTokens'] ?? $b->maxTokens),
            parallelModels: $data['parallelModels'] ?? $b->parallelModels,
            maxFeedbackItems: (int)($data['maxFeedbackItems'] ?? $b->maxFeedbackItems),
            feedbackSimilarityThreshold: (float)($data['feedbackSimilarityThreshold'] ?? $b->feedbackSimilarityThreshold),
            retryOnParseFailure: (bool)($data['retryOnParseFailure'] ?? $b->retryOnParseFailure),
            maxRetries: (int)($data['maxRetries'] ?? $b->maxRetries),
            promptTemplate: $data['promptTemplate'] ?? $b->promptTemplate,
        );
    }
}

// --- Prompt Templates ---
final class PromptTemplates
{
    private const TEMPLATES = [
        'default-transform' => <<<'TPL'
You are a code transformation AI.

Input:
{{input}}

{{feedback_section}}

Target Language: {{language}}
Target Framework: {{framework}}

{{constraints_section}}

Generate production-ready code in fenced code blocks with language tags.
TPL,

        'figma-to-code' => <<<'TPL'
You are a Figma-to-Code transformation AI.

## Design Components:
{{input}}

{{feedback_section}}

Target: {{language}} with {{framework}}

Generate clean, responsive, production-ready components in separate code blocks.
TPL,
    ];

    public static function get(string $name): string
    {
        return self::TEMPLATES[$name] ?? self::TEMPLATES['default-transform'];
    }
}

// --- Main Executor ---
class AiTransformExecutor
{
    public function __construct(
        private readonly AiTransformConfig $config = new AiTransformConfig(),
        private readonly ?FeedbackServiceInterface $feedbackService = null,
        private readonly ?AiDispatcherInterface $aiDispatcher = null,
    ) {}

    /**
     * Execute AI transform step: load feedback → build prompt → dispatch → parse.
     * @return array{success: bool, output: array, debugData: array, durationMs: int, error?: string}
     */
    public function execute(array $context): array
    {
        $startTime = hrtime(true);
        $debugData = [
            'executionId' => $this->uuid(),
            'stepId' => $context['stepId'] ?? '',
            'stepType' => $context['stepType'] ?? '',
            'startedAt' => date('c'),
        ];

        try {
            $stepConfig = $this->mergeStepConfig($context['configuration'] ?? []);

            // 1. Load relevant feedback (Genie DNA-2: BuildSearchFilter)
            $feedback = $this->loadRelevantFeedback($context, $stepConfig);
            $debugData['feedbackLoaded'] = count($feedback);

            // 2. Separate positive/negative
            ['positive' => $positive, 'negative' => $negative] = $this->separateFeedback($feedback);

            // 3. Build prompt from template
            $templateName = $stepConfig->promptTemplate;
            $prompt = $this->buildPrompt($templateName, $context, $positive, $negative);
            $debugData['promptLength'] = strlen($prompt);
            $debugData['templateUsed'] = $templateName;

            // 4. Dispatch to AI model(s)
            $models = !empty($stepConfig->parallelModels)
                ? $stepConfig->parallelModels
                : [$stepConfig->defaultModel];

            $results = count($models) > 1
                ? $this->dispatchParallel($prompt, $models, $stepConfig, $context)
                : [$this->dispatchSingle($prompt, $models[0], $stepConfig, $context)];

            $debugData['modelsUsed'] = $models;

            // 5. Select best successful result
            $successful = array_filter($results, fn(array $r) => $r['success'] === true);
            if (empty($successful)) {
                $errors = implode('; ', array_map(fn($r) => $r['error'] ?? 'unknown', $results));
                throw new \RuntimeException("All model(s) failed: {$errors}");
            }

            $best = reset($successful);

            // 6. Parse response
            $parsed = $this->parseAiResponse($best['item']['content'] ?? '');
            $debugData['codeBlocksExtracted'] = count($parsed['codeBlocks']);

            $durationMs = (int)((hrtime(true) - $startTime) / 1_000_000);

            return [
                'success' => true,
                'output' => [
                    ...$parsed,
                    'model' => $best['metadata']['model'] ?? '',
                    'allResults' => array_map(fn($r) => $r['item'], $results),
                ],
                'debugData' => $debugData,
                'durationMs' => $durationMs,
            ];
        } catch (\Throwable $e) {
            $durationMs = (int)((hrtime(true) - $startTime) / 1_000_000);
            $debugData['error'] = $e->getMessage();

            return [
                'success' => false,
                'output' => [],
                'debugData' => $debugData,
                'durationMs' => $durationMs,
                'error' => $e->getMessage(),
            ];
        }
    }

    // --- Feedback Loading (DNA-2: only include non-empty fields) ---
    private function loadRelevantFeedback(array $context, AiTransformConfig $config): array
    {
        if ($this->feedbackService === null) return [];

        $filter = [];
        if (!empty($context['flowId'])) $filter['flowId'] = $context['flowId'];
        if (!empty($context['stepType'])) $filter['stepType'] = $context['stepType'];

        try {
            $results = $this->feedbackService->searchFeedback($filter);
            return array_slice($results, 0, $config->maxFeedbackItems);
        } catch (\Throwable) {
            return [];
        }
    }

    /** @return array{positive: string, negative: string} */
    private function separateFeedback(array $feedback): array
    {
        $positive = [];
        $negative = [];

        foreach ($feedback as $item) {
            $rating = (int)($item['rating'] ?? 3);
            $output = $item['output'] ?? $item['content'] ?? '';
            $comment = $item['comment'] ?? '';
            $entry = $comment ? "{$output}\n(User note: {$comment})" : (string)$output;

            match (true) {
                $rating >= 4 => $positive[] = $entry,
                $rating <= 2 => $negative[] = $entry,
                default => null, // neutral — skip
            };
        }

        return [
            'positive' => implode("\n---\n", $positive),
            'negative' => implode("\n---\n", $negative),
        ];
    }

    // --- Prompt Building ---
    private function buildPrompt(string $templateName, array $context, string $positive, string $negative): string
    {
        $template = PromptTemplates::get($templateName);
        $config = $context['configuration'] ?? [];

        $feedbackSection = '';
        if ($positive !== '') $feedbackSection .= "## Patterns to Follow:\n{$positive}\n\n";
        if ($negative !== '') $feedbackSection .= "## Patterns to Avoid:\n{$negative}\n";

        $constraints = $config['constraints'] ?? '';
        $constraintsSection = $constraints ? "Output Constraints: {$constraints}" : '';

        $variables = [
            '{{input}}' => json_encode($context['input'] ?? [], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE),
            '{{feedback_section}}' => $feedbackSection,
            '{{language}}' => $config['language'] ?? 'TypeScript',
            '{{framework}}' => $config['framework'] ?? 'React',
            '{{constraints_section}}' => $constraintsSection,
        ];

        return str_replace(array_keys($variables), array_values($variables), $template);
    }

    // --- AI Dispatch (DNA-5: DataProcessResult) ---
    private function dispatchSingle(string $prompt, string $model, AiTransformConfig $config, array $context): array
    {
        if ($this->aiDispatcher === null) {
            return ['success' => false, 'item' => [], 'error' => 'No AI dispatcher', 'metadata' => ['model' => $model]];
        }

        $maxAttempts = $config->retryOnParseFailure ? $config->maxRetries + 1 : 1;
        $lastError = '';

        for ($attempt = 1; $attempt <= $maxAttempts; $attempt++) {
            try {
                $request = [
                    'requestId' => ($context['traceId'] ?? '') . '-' . substr($this->uuid(), 0, 8),
                    'prompt' => $prompt,
                    'systemPrompt' => $context['configuration']['systemPrompt'] ?? null,
                    'model' => $model,
                    'temperature' => $config->temperature,
                    'maxTokens' => $config->maxTokens,
                ];

                $response = $this->aiDispatcher->dispatch($request);

                if (!($response['success'] ?? false)) {
                    $lastError = $response['error'] ?? 'Unknown error';
                    continue;
                }

                $inTokens = $response['inputTokens'] ?? 0;
                $outTokens = $response['outputTokens'] ?? 0;

                return [
                    'success' => true,
                    'item' => ['content' => $response['content'], 'model' => $response['model']],
                    'metadata' => [
                        'model' => $response['model'],
                        'totalTokens' => $inTokens + $outTokens,
                        'durationMs' => $response['durationMs'] ?? 0,
                        'attempt' => $attempt,
                    ],
                ];
            } catch (\Throwable $e) {
                $lastError = $e->getMessage();
            }
        }

        return [
            'success' => false,
            'item' => [],
            'error' => "Model {$model} failed after {$maxAttempts} attempts: {$lastError}",
            'metadata' => ['model' => $model],
        ];
    }

    private function dispatchParallel(string $prompt, array $models, AiTransformConfig $config, array $context): array
    {
        // PHP doesn't have native async — dispatch sequentially (use Swoole/Fibers for true parallel)
        return array_map(
            fn(string $model) => $this->dispatchSingle($prompt, $model, $config, $context),
            $models
        );
    }

    // --- Response Parsing ---
    private function parseAiResponse(string $content): array
    {
        $codeBlocks = [];
        if (preg_match_all('/```(\w*)\n([\s\S]*?)```/', $content, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $codeBlocks[] = [
                    'language' => $match[1] ?: 'text',
                    'code' => trim($match[2]),
                ];
            }
        }

        $explanation = trim(preg_replace('/```\w*\n[\s\S]*?```/', '', $content));
        return ['codeBlocks' => $codeBlocks, 'explanation' => $explanation, 'rawContent' => $content];
    }

    // --- Helpers ---
    private function mergeStepConfig(array $stepConfig): AiTransformConfig
    {
        $overrides = $stepConfig['aiTransform'] ?? [];
        return AiTransformConfig::fromArray($overrides, $this->config);
    }

    private function uuid(): string
    {
        return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000, mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff));
    }
}
