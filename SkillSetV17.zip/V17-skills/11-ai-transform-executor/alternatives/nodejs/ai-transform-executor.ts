/**
 * Skill 11: AI Transform Executor — Node.js/TypeScript
 * Prepares prompts with feedback injection, dispatches to AI models, returns best result.
 * Genie DNA: Dynamic documents, BuildSearchFilter, DataProcessResult.
 */

import { randomUUID } from 'crypto';

// --- Interfaces (from core-interfaces) ---
interface StepExecutionContext {
  traceId: string;
  flowId: string;
  stepId: string;
  stepType: string;
  input: Record<string, any>;
  configuration: Record<string, any>;
  previousOutputs: Record<string, any>;
}

interface StepExecutionResult {
  success: boolean;
  output: Record<string, any>;
  debugData: Record<string, any>;
  durationMs: number;
  error?: string;
}

interface DataProcessResult {
  success: boolean;
  item: Record<string, any>;
  error?: string;
  metadata: Record<string, any>;
}

interface IFeedbackService {
  searchFeedback(filter: Record<string, any>): Promise<Record<string, any>[]>;
}

interface IAiDispatcher {
  dispatch(request: AiDispatchRequest): Promise<AiDispatchResponse>;
}

interface AiDispatchRequest {
  requestId: string;
  prompt: string;
  systemPrompt?: string;
  model: string;
  temperature: number;
  maxTokens: number;
}

interface AiDispatchResponse {
  requestId: string;
  content: string;
  model: string;
  inputTokens: number;
  outputTokens: number;
  durationMs: number;
  success: boolean;
  error?: string;
}

// --- Configuration ---
interface AiTransformConfig {
  defaultModel: string;
  temperature: number;
  maxTokens: number;
  parallelModels: string[];
  maxFeedbackItems: number;
  feedbackSimilarityThreshold: number;
  retryOnParseFailure: boolean;
  maxRetries: number;
  promptTemplate: string;
}

const DEFAULT_CONFIG: AiTransformConfig = {
  defaultModel: 'claude-sonnet-4-20250514',
  temperature: 0.3,
  maxTokens: 4096,
  parallelModels: [],
  maxFeedbackItems: 10,
  feedbackSimilarityThreshold: 0.7,
  retryOnParseFailure: true,
  maxRetries: 2,
  promptTemplate: 'default-transform',
};

// --- Prompt Templates ---
const TEMPLATES: Record<string, string> = {
  'default-transform': `You are a code transformation AI.

Input:
{{input}}

{{#if feedback_positive}}
## Patterns to Follow (from successful past outputs):
{{feedback_positive}}
{{/if}}

{{#if feedback_negative}}
## Patterns to Avoid (from failed past outputs):
{{feedback_negative}}
{{/if}}

Target Language: {{language}}
Target Framework: {{framework}}

{{#if constraints}}
Output Constraints: {{constraints}}
{{/if}}

Generate production-ready code. Return code in fenced code blocks with language tags.`,

  'figma-to-code': `You are a Figma-to-Code transformation AI.

## Design Components:
{{input}}

{{#if feedback_positive}}
## Successful Past Transformations (follow these patterns):
{{feedback_positive}}
{{/if}}

{{#if feedback_negative}}
## Failed Past Transformations (avoid these patterns):
{{feedback_negative}}
{{/if}}

Target: {{language}} with {{framework}}
Component naming: {{context.namingConvention}}

Generate clean, responsive, production-ready components.
Return each component in a separate fenced code block.`,
};

// --- Main Executor ---
export class AiTransformExecutor {
  private config: AiTransformConfig;
  private feedbackService: IFeedbackService;
  private aiDispatcher: IAiDispatcher;

  constructor(
    config: Partial<AiTransformConfig> = {},
    feedbackService: IFeedbackService,
    aiDispatcher: IAiDispatcher
  ) {
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.feedbackService = feedbackService;
    this.aiDispatcher = aiDispatcher;
  }

  async executeAsync(context: StepExecutionContext): Promise<StepExecutionResult> {
    const startTime = Date.now();
    const debugData: Record<string, any> = {
      executionId: randomUUID(),
      stepId: context.stepId,
      stepType: context.stepType,
      startedAt: new Date().toISOString(),
    };

    try {
      // 1. Extract config overrides from step
      const stepConfig = this.mergeStepConfig(context.configuration);

      // 2. Load relevant feedback (Genie DNA-2: BuildSearchFilter)
      const feedback = await this.loadRelevantFeedback(context, stepConfig);
      debugData.feedbackLoaded = feedback.length;
      debugData.feedbackIds = feedback.map((f) => f.id);

      // 3. Separate positive/negative feedback
      const { positive, negative } = this.separateFeedback(feedback);

      // 4. Build prompt from template
      const templateName = stepConfig.promptTemplate || this.config.promptTemplate;
      const prompt = this.buildPrompt(templateName, context, positive, negative);
      debugData.promptLength = prompt.length;
      debugData.templateUsed = templateName;

      // 5. Dispatch to AI model(s)
      let results: DataProcessResult[];
      const models = stepConfig.parallelModels?.length > 0
        ? stepConfig.parallelModels
        : [stepConfig.defaultModel || this.config.defaultModel];

      if (models.length > 1) {
        results = await this.dispatchParallel(prompt, models, stepConfig, context);
      } else {
        results = [await this.dispatchSingle(prompt, models[0], stepConfig, context)];
      }

      debugData.modelsUsed = models;
      debugData.results = results.map((r) => ({
        model: r.metadata.model,
        success: r.success,
        tokens: r.metadata.totalTokens,
        durationMs: r.metadata.durationMs,
      }));

      // 6. Select best result
      const successfulResults = results.filter((r) => r.success);
      if (successfulResults.length === 0) {
        throw new Error(`All ${models.length} model(s) failed: ${results.map((r) => r.error).join('; ')}`);
      }

      const bestResult = successfulResults[0]; // Skill 12 does advanced selection

      // 7. Parse structured output
      const parsed = this.parseAiResponse(bestResult.item.content as string);
      debugData.codeBlocksExtracted = parsed.codeBlocks.length;

      const durationMs = Date.now() - startTime;
      debugData.totalDurationMs = durationMs;

      return {
        success: true,
        output: {
          ...parsed,
          model: bestResult.metadata.model,
          allResults: results.map((r) => r.item),
        },
        debugData,
        durationMs,
      };
    } catch (error: any) {
      const durationMs = Date.now() - startTime;
      debugData.error = error.message;
      debugData.totalDurationMs = durationMs;

      return {
        success: false,
        output: {},
        debugData,
        durationMs,
        error: error.message,
      };
    }
  }

  // --- Feedback Loading (Genie DNA-2: BuildSearchFilter) ---
  private async loadRelevantFeedback(
    context: StepExecutionContext,
    config: AiTransformConfig
  ): Promise<Record<string, any>[]> {
    // Build filter — only include non-empty fields (DNA-2 pattern)
    const filter: Record<string, any> = {};
    if (context.flowId) filter.flowId = context.flowId;
    if (context.stepType) filter.stepType = context.stepType;
    // Empty fields automatically skipped — BuildSearchFilter pattern

    try {
      const allFeedback = await this.feedbackService.searchFeedback(filter);
      return allFeedback.slice(0, config.maxFeedbackItems || this.config.maxFeedbackItems);
    } catch {
      return []; // Graceful degradation — execute without feedback
    }
  }

  private separateFeedback(
    feedback: Record<string, any>[]
  ): { positive: string; negative: string } {
    const positive: string[] = [];
    const negative: string[] = [];

    for (const item of feedback) {
      const rating = item.rating as number;
      const output = item.output || item.content || '';
      const comment = item.comment || '';
      const entry = comment ? `${output}\n(User note: ${comment})` : output;

      if (rating >= 4) {
        positive.push(entry);
      } else if (rating <= 2) {
        negative.push(entry);
      }
    }

    return {
      positive: positive.join('\n---\n'),
      negative: negative.join('\n---\n'),
    };
  }

  // --- Prompt Building ---
  private buildPrompt(
    templateName: string,
    context: StepExecutionContext,
    positiveFeedback: string,
    negativeFeedback: string
  ): string {
    let template = TEMPLATES[templateName] || TEMPLATES['default-transform'];

    const variables: Record<string, string> = {
      input: JSON.stringify(context.input, null, 2),
      feedback_positive: positiveFeedback,
      feedback_negative: negativeFeedback,
      language: (context.configuration?.language as string) || 'TypeScript',
      framework: (context.configuration?.framework as string) || 'React',
      constraints: (context.configuration?.constraints as string) || '',
    };

    // Handle conditionals {{#if var}}...{{/if}}
    template = template.replace(
      /\{\{#if (\w+)\}\}([\s\S]*?)\{\{\/if\}\}/g,
      (_, varName, content) => (variables[varName]?.trim() ? content : '')
    );

    // Replace variables {{var}} and {{context.var}}
    template = template.replace(/\{\{(\w+(?:\.\w+)*)\}\}/g, (_, path: string) => {
      if (path.startsWith('context.')) {
        const key = path.substring(8);
        return (context.configuration?.[key] as string) || '';
      }
      return variables[path] || '';
    });

    return template;
  }

  // --- AI Dispatch ---
  private async dispatchSingle(
    prompt: string,
    model: string,
    config: AiTransformConfig,
    context: StepExecutionContext
  ): Promise<DataProcessResult> {
    const request: AiDispatchRequest = {
      requestId: `${context.traceId}-${context.stepId}-${randomUUID().slice(0, 8)}`,
      prompt,
      systemPrompt: (context.configuration?.systemPrompt as string) || undefined,
      model,
      temperature: config.temperature ?? this.config.temperature,
      maxTokens: config.maxTokens ?? this.config.maxTokens,
    };

    let lastError = '';
    const maxAttempts = config.retryOnParseFailure ? (config.maxRetries || this.config.maxRetries) + 1 : 1;

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        const response = await this.aiDispatcher.dispatch(request);
        if (!response.success) {
          lastError = response.error || 'Unknown dispatch error';
          continue;
        }

        return {
          success: true,
          item: { content: response.content, model: response.model },
          metadata: {
            model: response.model,
            inputTokens: response.inputTokens,
            outputTokens: response.outputTokens,
            totalTokens: response.inputTokens + response.outputTokens,
            durationMs: response.durationMs,
            attempt,
          },
        };
      } catch (err: any) {
        lastError = err.message;
      }
    }

    return {
      success: false,
      item: {},
      error: `Model ${model} failed after ${maxAttempts} attempts: ${lastError}`,
      metadata: { model },
    };
  }

  private async dispatchParallel(
    prompt: string,
    models: string[],
    config: AiTransformConfig,
    context: StepExecutionContext
  ): Promise<DataProcessResult[]> {
    const promises = models.map((model) =>
      this.dispatchSingle(prompt, model, config, context)
    );
    return Promise.all(promises);
  }

  // --- Response Parsing ---
  private parseAiResponse(content: string): {
    codeBlocks: { language: string; code: string }[];
    explanation: string;
    rawContent: string;
  } {
    const codeBlockRegex = /```(\w*)\n([\s\S]*?)```/g;
    const codeBlocks: { language: string; code: string }[] = [];
    let match: RegExpExecArray | null;

    while ((match = codeBlockRegex.exec(content)) !== null) {
      codeBlocks.push({
        language: match[1] || 'text',
        code: match[2].trim(),
      });
    }

    // Explanation = everything outside code blocks
    const explanation = content.replace(/```\w*\n[\s\S]*?```/g, '').trim();

    return { codeBlocks, explanation, rawContent: content };
  }

  // --- Config Merge ---
  private mergeStepConfig(stepConfig: Record<string, any>): AiTransformConfig {
    const overrides = (stepConfig?.aiTransform || {}) as Partial<AiTransformConfig>;
    return { ...this.config, ...overrides };
  }
}

export default AiTransformExecutor;
