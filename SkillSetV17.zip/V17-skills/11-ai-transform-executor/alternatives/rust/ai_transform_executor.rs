/// Skill 11: AI Transform Executor — Rust
/// Prepares prompts with feedback injection, dispatches to AI models, returns best result.
/// Genie DNA: Dynamic documents (serde_json::Value), BuildSearchFilter, DataProcessResult.

use regex::Regex;
use serde_json::{json, Map, Value};
use std::collections::HashMap;
use std::time::Instant;
use uuid::Uuid;

// --- Trait interfaces (from core-interfaces) ---
#[async_trait::async_trait]
pub trait FeedbackService: Send + Sync {
    async fn search_feedback(&self, filter: &Value) -> Result<Vec<Value>, Box<dyn std::error::Error + Send + Sync>>;
}

#[async_trait::async_trait]
pub trait AiDispatcher: Send + Sync {
    async fn dispatch(&self, request: &Value) -> Result<Value, Box<dyn std::error::Error + Send + Sync>>;
}

// --- Configuration ---
#[derive(Clone, Debug)]
pub struct AiTransformConfig {
    pub default_model: String,
    pub temperature: f64,
    pub max_tokens: u32,
    pub parallel_models: Vec<String>,
    pub max_feedback_items: usize,
    pub retry_on_parse_failure: bool,
    pub max_retries: u32,
    pub prompt_template: String,
}

impl Default for AiTransformConfig {
    fn default() -> Self {
        Self {
            default_model: "claude-sonnet-4-20250514".into(),
            temperature: 0.3,
            max_tokens: 4096,
            parallel_models: vec![],
            max_feedback_items: 10,
            retry_on_parse_failure: true,
            max_retries: 2,
            prompt_template: "default-transform".into(),
        }
    }
}

// --- Data structures ---
#[derive(Debug, Clone)]
pub struct CodeBlock {
    pub language: String,
    pub code: String,
}

#[derive(Debug)]
pub struct ParsedResponse {
    pub code_blocks: Vec<CodeBlock>,
    pub explanation: String,
    pub raw_content: String,
}

#[derive(Debug)]
pub struct StepExecutionResult {
    pub success: bool,
    pub output: Value,
    pub debug_data: Value,
    pub duration_ms: u64,
    pub error: Option<String>,
}

// --- Prompt Templates ---
fn get_template(name: &str) -> &'static str {
    match name {
        "figma-to-code" => r#"You are a Figma-to-Code transformation AI.

## Design Components:
{{input}}

{{feedback_section}}

Target: {{language}} with {{framework}}

Generate clean, responsive, production-ready components in separate code blocks."#,

        _ => r#"You are a code transformation AI.

Input:
{{input}}

{{feedback_section}}

Target Language: {{language}}
Target Framework: {{framework}}

{{constraints_section}}

Generate production-ready code in fenced code blocks with language tags."#,
    }
}

// --- Main Executor ---
pub struct AiTransformExecutor {
    config: AiTransformConfig,
    feedback_service: Option<Box<dyn FeedbackService>>,
    ai_dispatcher: Box<dyn AiDispatcher>,
}

impl AiTransformExecutor {
    pub fn new(
        config: AiTransformConfig,
        feedback_service: Option<Box<dyn FeedbackService>>,
        ai_dispatcher: Box<dyn AiDispatcher>,
    ) -> Self {
        Self { config, feedback_service, ai_dispatcher }
    }

    pub async fn execute_async(&self, context: &Value) -> StepExecutionResult {
        let start = Instant::now();
        let mut debug_data = json!({
            "executionId": Uuid::new_v4().to_string(),
            "stepId": context.get("stepId").and_then(|v| v.as_str()).unwrap_or(""),
            "stepType": context.get("stepType").and_then(|v| v.as_str()).unwrap_or(""),
        });

        match self.execute_inner(context, &mut debug_data).await {
            Ok(output) => {
                let duration_ms = start.elapsed().as_millis() as u64;
                debug_data["totalDurationMs"] = json!(duration_ms);
                StepExecutionResult {
                    success: true,
                    output,
                    debug_data,
                    duration_ms,
                    error: None,
                }
            }
            Err(e) => {
                let duration_ms = start.elapsed().as_millis() as u64;
                debug_data["error"] = json!(e.to_string());
                debug_data["totalDurationMs"] = json!(duration_ms);
                StepExecutionResult {
                    success: false,
                    output: json!({}),
                    debug_data,
                    duration_ms,
                    error: Some(e.to_string()),
                }
            }
        }
    }

    async fn execute_inner(
        &self,
        context: &Value,
        debug_data: &mut Value,
    ) -> Result<Value, Box<dyn std::error::Error + Send + Sync>> {
        let step_config = self.merge_step_config(context);

        // 1. Load feedback (Genie DNA-2: BuildSearchFilter — skip empty)
        let feedback = self.load_relevant_feedback(context, &step_config).await;
        debug_data["feedbackLoaded"] = json!(feedback.len());

        // 2. Separate positive/negative
        let (positive, negative) = separate_feedback(&feedback);

        // 3. Build prompt
        let template_name = &step_config.prompt_template;
        let prompt = build_prompt(template_name, context, &positive, &negative);
        debug_data["promptLength"] = json!(prompt.len());
        debug_data["templateUsed"] = json!(template_name);

        // 4. Dispatch to model(s)
        let models: Vec<String> = if step_config.parallel_models.is_empty() {
            vec![step_config.default_model.clone()]
        } else {
            step_config.parallel_models.clone()
        };

        let results = if models.len() > 1 {
            self.dispatch_parallel(&prompt, &models, &step_config, context).await
        } else {
            vec![self.dispatch_single(&prompt, &models[0], &step_config, context).await]
        };

        debug_data["modelsUsed"] = json!(models);

        // 5. Select best successful result
        let successful: Vec<&Value> = results.iter()
            .filter(|r| r.get("success").and_then(|v| v.as_bool()).unwrap_or(false))
            .collect();

        if successful.is_empty() {
            return Err(format!("All {} model(s) failed", models.len()).into());
        }

        let best = successful[0];
        let content = best.get("item")
            .and_then(|i| i.get("content"))
            .and_then(|c| c.as_str())
            .unwrap_or("");

        // 6. Parse response
        let parsed = parse_ai_response(content);
        debug_data["codeBlocksExtracted"] = json!(parsed.code_blocks.len());

        let code_blocks_json: Vec<Value> = parsed.code_blocks.iter()
            .map(|cb| json!({"language": cb.language, "code": cb.code}))
            .collect();

        Ok(json!({
            "codeBlocks": code_blocks_json,
            "explanation": parsed.explanation,
            "rawContent": parsed.raw_content,
            "model": best.get("metadata").and_then(|m| m.get("model")),
        }))
    }

    // --- Feedback Loading (DNA-2: BuildSearchFilter) ---
    async fn load_relevant_feedback(&self, context: &Value, config: &AiTransformConfig) -> Vec<Value> {
        let service = match &self.feedback_service {
            Some(s) => s,
            None => return vec![],
        };

        // Build filter — only non-empty fields (DNA-2 pattern)
        let mut filter = Map::new();
        if let Some(flow_id) = context.get("flowId").and_then(|v| v.as_str()) {
            if !flow_id.is_empty() { filter.insert("flowId".into(), json!(flow_id)); }
        }
        if let Some(step_type) = context.get("stepType").and_then(|v| v.as_str()) {
            if !step_type.is_empty() { filter.insert("stepType".into(), json!(step_type)); }
        }

        match service.search_feedback(&Value::Object(filter)).await {
            Ok(results) => results.into_iter().take(config.max_feedback_items).collect(),
            Err(_) => vec![],
        }
    }

    // --- AI Dispatch ---
    async fn dispatch_single(
        &self, prompt: &str, model: &str, config: &AiTransformConfig, context: &Value,
    ) -> Value {
        let max_attempts = if config.retry_on_parse_failure { config.max_retries + 1 } else { 1 };
        let mut last_error = String::new();

        for attempt in 1..=max_attempts {
            let request = json!({
                "requestId": format!("{}-{}", 
                    context.get("traceId").and_then(|v| v.as_str()).unwrap_or(""),
                    &Uuid::new_v4().to_string()[..8]),
                "prompt": prompt,
                "model": model,
                "temperature": config.temperature,
                "maxTokens": config.max_tokens,
            });

            match self.ai_dispatcher.dispatch(&request).await {
                Ok(response) => {
                    if response.get("success").and_then(|v| v.as_bool()).unwrap_or(false) {
                        let in_tok = response.get("inputTokens").and_then(|v| v.as_u64()).unwrap_or(0);
                        let out_tok = response.get("outputTokens").and_then(|v| v.as_u64()).unwrap_or(0);
                        return json!({
                            "success": true,
                            "item": { "content": response["content"], "model": response["model"] },
                            "metadata": {
                                "model": response["model"],
                                "totalTokens": in_tok + out_tok,
                                "durationMs": response.get("durationMs").unwrap_or(&json!(0)),
                                "attempt": attempt,
                            }
                        });
                    }
                    last_error = response.get("error").and_then(|v| v.as_str()).unwrap_or("Unknown").to_string();
                }
                Err(e) => last_error = e.to_string(),
            }
        }

        json!({
            "success": false,
            "item": {},
            "error": format!("Model {} failed after {} attempts: {}", model, max_attempts, last_error),
            "metadata": { "model": model }
        })
    }

    async fn dispatch_parallel(
        &self, prompt: &str, models: &[String], config: &AiTransformConfig, context: &Value,
    ) -> Vec<Value> {
        let mut handles = Vec::new();
        for model in models {
            // In production, use tokio::spawn for true parallelism
            handles.push(self.dispatch_single(prompt, model, config, context).await);
        }
        handles
    }

    fn merge_step_config(&self, context: &Value) -> AiTransformConfig {
        let mut cfg = self.config.clone();
        if let Some(overrides) = context.get("configuration")
            .and_then(|c| c.get("aiTransform")) {
            if let Some(m) = overrides.get("defaultModel").and_then(|v| v.as_str()) { cfg.default_model = m.into(); }
            if let Some(t) = overrides.get("temperature").and_then(|v| v.as_f64()) { cfg.temperature = t; }
            if let Some(t) = overrides.get("maxTokens").and_then(|v| v.as_u64()) { cfg.max_tokens = t as u32; }
            if let Some(tp) = overrides.get("promptTemplate").and_then(|v| v.as_str()) { cfg.prompt_template = tp.into(); }
        }
        cfg
    }
}

// --- Standalone Functions ---
fn separate_feedback(feedback: &[Value]) -> (String, String) {
    let mut positive = Vec::new();
    let mut negative = Vec::new();

    for item in feedback {
        let rating = item.get("rating").and_then(|v| v.as_i64()).unwrap_or(3);
        let output = item.get("output").or(item.get("content"))
            .and_then(|v| v.as_str()).unwrap_or("");
        let comment = item.get("comment").and_then(|v| v.as_str()).unwrap_or("");
        let entry = if comment.is_empty() {
            output.to_string()
        } else {
            format!("{}\n(User note: {})", output, comment)
        };

        if rating >= 4 { positive.push(entry); }
        else if rating <= 2 { negative.push(entry); }
    }

    (positive.join("\n---\n"), negative.join("\n---\n"))
}

fn build_prompt(template_name: &str, context: &Value, positive: &str, negative: &str) -> String {
    let template = get_template(template_name);
    let config = context.get("configuration").unwrap_or(&json!({}));

    let mut feedback_section = String::new();
    if !positive.is_empty() {
        feedback_section.push_str(&format!("## Patterns to Follow:\n{}\n\n", positive));
    }
    if !negative.is_empty() {
        feedback_section.push_str(&format!("## Patterns to Avoid:\n{}\n", negative));
    }

    let input_str = context.get("input")
        .map(|v| serde_json::to_string_pretty(v).unwrap_or_default())
        .unwrap_or_default();
    let language = config.get("language").and_then(|v| v.as_str()).unwrap_or("TypeScript");
    let framework = config.get("framework").and_then(|v| v.as_str()).unwrap_or("React");
    let constraints = config.get("constraints").and_then(|v| v.as_str()).unwrap_or("");
    let constraints_section = if constraints.is_empty() { String::new() }
        else { format!("Output Constraints: {}", constraints) };

    template.replace("{{input}}", &input_str)
        .replace("{{feedback_section}}", &feedback_section)
        .replace("{{language}}", language)
        .replace("{{framework}}", framework)
        .replace("{{constraints_section}}", &constraints_section)
}

fn parse_ai_response(content: &str) -> ParsedResponse {
    let re = Regex::new(r"```(\w*)\n([\s\S]*?)```").unwrap();
    let code_blocks: Vec<CodeBlock> = re.captures_iter(content)
        .map(|cap| CodeBlock {
            language: if cap[1].is_empty() { "text".into() } else { cap[1].to_string() },
            code: cap[2].trim().to_string(),
        })
        .collect();

    let explanation = re.replace_all(content, "").trim().to_string();

    ParsedResponse { code_blocks, explanation, raw_content: content.to_string() }
}
