# Permissions Service — Implementation Prompt | Skill 21

## Phase 1: Core RBAC
1. `IPermissionsService`: HasPermission, HasRole, Grant, Revoke
2. Store as dynamic docs: `{userId, permission, grantedAt}`
3. `BuildSearchFilter` for userId lookups; `DataProcessResult` returns

## Phase 2: Permission Cache
1. In-memory `ConcurrentDictionary<userId, HashSet<permission>>`
2. Invalidate on grant/revoke; optional TTL

## Phase 3: Role Management
1. Roles = `role:{roleName}` permissions; `AssignRole` grants role + perms
2. Events: `permissions.granted`, `permissions.revoked`

## Phase 4: Middleware & Testing
1. `[RequirePermission]` attribute + middleware
2. Integration with Skill 20 Auth for userId from JWT
3. **Genie DNA Checklist:** ☐ DataProcessResult ☐ BuildSearchFilter ☐ Dynamic docs ☐ MicroserviceBase


---

## Genie DNA Compliance — MANDATORY for All Implementations

> Before writing ANY code, classify each component:
> **MACHINE** (static): Infrastructure that enables freedom. Build once, generic, interface-based.
> **FREEDOM** (dynamic): Anything users define. No fixed models, config-driven.

### DNA Checklist — Every Implementation MUST:
☐ **DNA-1 (Dynamic Documents):** Store data as `Dictionary<string, object>` / `Record<string, any>` — NOT typed model classes. User fields preserved without schema changes.
☐ **DNA-2 (BuildSearchFilter):** All queries use BuildSearchFilter/equivalent. Empty fields auto-skipped. No entity-specific query code.
☐ **DNA-3 (MicroserviceBase):** Inherit base class with DB, queue, cache, logger built in.
☐ **DNA-5 (DataProcessResult):** All public methods return `DataProcessResult<T>`. Errors return failure, not throw exceptions.
☐ **DNA-6 (Generic Interfaces):** External dependencies behind interfaces. Swap via config.
☐ **DNA-SCOPE:** Non-admin queries auto-inject userId filter. Cannot be bypassed.

### The Three Tests:
1. Can a business user change this without a developer? (YES = correct)
2. Does it work for entity types that do not exist yet? (YES = correct)
3. Can I swap the database/service/UI without changing this? (YES = correct)
