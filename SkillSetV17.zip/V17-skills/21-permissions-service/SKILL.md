---
skill_id: "21"
name: permissions-service
title: "Permissions Service"
layer: "L6: Platform Services"
version: "17.0"
status: "active"
dependencies:
  - "01-core-interfaces"
  - "02-object-processor"
  - "03-elasticsearch-datastore"
  - "04-redis-queue-service"
  - "20-auth-service"
dotnet_namespace: "XIIGen.Services.Permissions"
di_registration: "services.AddXIIGenPermissionsService()"
es_index: "xiigen-permissions"
genie_dna:
  - "DNA-1: Permission records as dynamic documents"
  - "DNA-2: BuildSearchFilter for permission lookups (userId, role, resource — skip empty)"
  - "DNA-3: Inherits MicroserviceBase"
  - "DNA-5: DataProcessResult for all operations"
  - "DNA-MACHINE: Permission logic is STATIC. Permission DEFINITIONS are DYNAMIC."
  - "DNA-SCOPE: Provides scope injection data to BuildSearchFilter across ALL services"
triggers: permissions, RBAC, ACL, role, grant, revoke, access control, scope, scope isolation, authorization
---

# Skill 21: Permissions Service
## RBAC with Event-Driven Replication — The Scope Provider

**Classification: HYBRID — MACHINE logic, FREEDOM definitions**
The permission CHECK logic is static (non-negotiable security). But the permission DEFINITIONS (who has what role, which roles exist, what each role can access) are dynamic documents that admins configure.

---

## The Critical Role: Scope Provider

This service provides the data that enables **Pattern 5: Automatic Scope Isolation**. When BuildSearchFilter injects `userId` into queries, it's THIS service that determines:
- Is the user an admin? (skip injection)
- What roles does the user have? (role-based scoping)
- What specific resources are granted? (resource-level ACL)

### Replication Pattern (from Architecture.docx)
Permissions are **replicated to ALL services** via events. Each service has a LOCAL permission cache so scope checks are fast (no cross-service call per request):

```
PermissionService → publishes PermissionChanged event
→ ALL services update local cache
→ BuildSearchFilter reads LOCAL cache for scope injection
→ Sub-millisecond permission checks
```

---

## Genie DNA Integration

### Permission Records as Dynamic Documents (DNA-1)
```csharp
// Permission stored as dynamic document — supports any resource type
var permission = ObjectProcessor.ParseDocument(new {
    userId = "user_123",
    role = "finance_manager",
    resource = "vendor_invoices",
    actions = new[] { "read", "create", "update" },
    grantedBy = "admin_456",
    grantedAt = DateTime.UtcNow,
    expiresAt = (string)null  // null = never expires, skipped by BuildSearchFilter
});
await Database.UpsertAsync("xiigen-permissions", permId, permission);
```

### Role Definitions as Dynamic Documents
Roles themselves are dynamic — admins create new roles without code:
```json
{
  "roleName": "finance_reviewer",
  "permissions": ["vendor_invoices:read", "vendor_invoices:approve"],
  "description": "Can view and approve vendor invoices",
  "createdBy": "admin@company.com"
}
```

---

## Interface

```csharp
public interface IPermissionsService
{
    Task<DataProcessResult<bool>> HasPermissionAsync(string userId, string resource, string action);
    Task<DataProcessResult<bool>> HasRoleAsync(string userId, string role);
    Task<DataProcessResult<string>> GrantAsync(Dictionary<string, object> permissionDoc);
    Task<DataProcessResult<bool>> RevokeAsync(string userId, string resource);
    Task<DataProcessResult<List<string>>> GetUserPermissionsAsync(string userId);
    Task<DataProcessResult<UserScope>> BuildUserScopeAsync(string userId);
}
```

## Permission Matrix (Entity Definition Integration)

When an entity definition includes permissions:
```json
{ "entityName": "vendor_invoices", "permissions": {
    "create": ["admin", "finance"], "read": ["admin", "finance", "viewer"],
    "update": ["admin", "finance"], "delete": ["admin"]
}}
```
The PermissionsService enforces these rules automatically. Adding a new entity type with permissions = adding a definition, no code.

## Events

| Event | Purpose |
|---|---|
| `PermissionGranted` | All services update local cache |
| `PermissionRevoked` | All services invalidate cache entry |
| `RoleCreated` | Registry updated, available in UI |
| `RoleModified` | All services refresh role definitions |

## Alternatives
All alternatives MUST: store permissions as dynamic documents, replicate via events, provide scope data for BuildSearchFilter, return DataProcessResult.
