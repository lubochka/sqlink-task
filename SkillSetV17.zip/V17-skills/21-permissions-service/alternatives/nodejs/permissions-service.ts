// XIIGen Permissions Service — Node.js/TypeScript | Skill 21
import { IDatabaseService, IQueueService, DataProcessResult, MicroserviceBase } from '../../01-core-interfaces';

export class PermissionsService extends MicroserviceBase {
  private cache: Map<string, Set<string>> = new Map();
  protected serviceName = 'permissions-service';

  constructor(db: IDatabaseService, queue: IQueueService) { super(db, queue); }

  async hasPermission(userId: string, permission: string): Promise<boolean> {
    if (this.cache.has(userId)) return this.cache.get(userId)!.has(permission);
    const result = await this.searchDocuments('permissions', { userId }, 100);
    if (!result.isSuccess) return false;
    const perms = new Set<string>(result.data?.map((d: any) => d.permission) || []);
    this.cache.set(userId, perms);
    return perms.has(permission);
  }

  async hasRole(userId: string, role: string): Promise<boolean> { return this.hasPermission(userId, `role:${role}`); }

  async getPermissions(userId: string): Promise<string[]> {
    const result = await this.searchDocuments('permissions', { userId }, 100);
    return result.isSuccess ? result.data?.map((d: any) => d.permission) || [] : [];
  }

  async grant(userId: string, permission: string): Promise<DataProcessResult<boolean>> {
    await this.storeDocument('permissions', `${userId}:${permission}`, { userId, permission, grantedAt: new Date() });
    this.cache.delete(userId);
    await this.publishEvent('permissions.granted', { userId, permission });
    return DataProcessResult.success(true);
  }

  async revoke(userId: string, permission: string): Promise<DataProcessResult<boolean>> {
    await this.deleteDocument('permissions', `${userId}:${permission}`);
    this.cache.delete(userId);
    await this.publishEvent('permissions.revoked', { userId, permission });
    return DataProcessResult.success(true);
  }

  async assignRole(userId: string, role: string, permissions: string[]): Promise<DataProcessResult<boolean>> {
    await this.grant(userId, `role:${role}`);
    for (const p of permissions) await this.grant(userId, p);
    return DataProcessResult.success(true);
  }
}
