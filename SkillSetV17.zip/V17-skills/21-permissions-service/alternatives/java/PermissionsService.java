// XIIGen Permissions Service — Java | Skill 21
package com.xiigen.platform.permissions;
import com.xiigen.core.*;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class PermissionsService extends MicroserviceBase {
    private final Map<String, Set<String>> cache = new ConcurrentHashMap<>();
    public PermissionsService(IDatabaseService db, IQueueService queue) { super(db, queue, "permissions-service"); }

    public boolean hasPermission(String userId, String permission) throws Exception {
        if (cache.containsKey(userId)) return cache.get(userId).contains(permission);
        var result = searchDocuments("permissions", Map.of("userId", userId), 100);
        if (!result.isSuccess()) return false;
        Set<String> perms = new HashSet<>();
        for (var doc : result.getData()) perms.add(((Map<String, Object>) doc).getOrDefault("permission", "").toString());
        cache.put(userId, perms);
        return perms.contains(permission);
    }

    public boolean hasRole(String userId, String role) throws Exception { return hasPermission(userId, "role:" + role); }

    public DataProcessResult<Boolean> grant(String userId, String permission) throws Exception {
        storeDocument("permissions", userId + ":" + permission, Map.of("userId", userId, "permission", permission, "grantedAt", Instant.now().toString()));
        cache.remove(userId);
        publishEvent("permissions.granted", Map.of("userId", userId, "permission", permission));
        return DataProcessResult.success(true);
    }

    public DataProcessResult<Boolean> revoke(String userId, String permission) throws Exception {
        deleteDocument("permissions", userId + ":" + permission);
        cache.remove(userId);
        return DataProcessResult.success(true);
    }
}
