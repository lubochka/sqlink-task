# XIIGen Permissions Service — Python | Skill 21
from core_interfaces import IDatabaseService, IQueueService, DataProcessResult, MicroserviceBase

class PermissionsService(MicroserviceBase):
    service_name = "permissions-service"
    def __init__(self, db: IDatabaseService, queue: IQueueService):
        super().__init__(db, queue)
        self._cache: dict[str, set[str]] = {}

    async def has_permission(self, user_id: str, permission: str) -> bool:
        if user_id in self._cache: return permission in self._cache[user_id]
        result = await self.search_documents("permissions", {"userId": user_id}, 100)
        if not result.is_success: return False
        perms = {d.get("permission", "") for d in (result.data or [])}
        self._cache[user_id] = perms
        return permission in perms

    async def has_role(self, user_id: str, role: str) -> bool: return await self.has_permission(user_id, f"role:{role}")

    async def grant(self, user_id: str, permission: str) -> DataProcessResult:
        await self.store_document("permissions", f"{user_id}:{permission}", {"userId": user_id, "permission": permission})
        self._cache.pop(user_id, None)
        await self.publish_event("permissions.granted", {"userId": user_id, "permission": permission})
        return DataProcessResult.success(True)

    async def revoke(self, user_id: str, permission: str) -> DataProcessResult:
        await self.delete_document("permissions", f"{user_id}:{permission}")
        self._cache.pop(user_id, None)
        return DataProcessResult.success(True)
