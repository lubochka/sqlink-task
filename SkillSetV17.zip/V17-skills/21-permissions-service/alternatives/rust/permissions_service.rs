// XIIGen Permissions Service — Rust | Skill 21
use serde_json::json;
use std::collections::{HashMap, HashSet};
use std::sync::RwLock;
use crate::core::{DataProcessResult, IDatabaseService, IQueueService, MicroserviceBase};

pub struct PermissionsService {
    base: MicroserviceBase,
    cache: RwLock<HashMap<String, HashSet<String>>>,
}

impl PermissionsService {
    pub fn new(db: Box<dyn IDatabaseService>, queue: Box<dyn IQueueService>) -> Self {
        Self { base: MicroserviceBase::new(db, queue, "permissions-service"), cache: RwLock::new(HashMap::new()) }
    }

    pub async fn has_permission(&self, user_id: &str, permission: &str) -> bool {
        if let Ok(c) = self.cache.read() { if let Some(p) = c.get(user_id) { return p.contains(permission); } }
        let result = self.base.search_documents("permissions", &json!({"userId": user_id}), 100).await;
        if !result.is_success { return false; }
        let perms: HashSet<String> = result.data.iter().filter_map(|d| d.get("permission").and_then(|v| v.as_str()).map(String::from)).collect();
        let has = perms.contains(permission);
        if let Ok(mut c) = self.cache.write() { c.insert(user_id.to_string(), perms); }
        has
    }

    pub async fn grant(&self, user_id: &str, permission: &str) -> DataProcessResult<bool> {
        self.base.store_document("permissions", &format!("{}:{}", user_id, permission), &json!({"userId": user_id, "permission": permission})).await;
        if let Ok(mut c) = self.cache.write() { c.remove(user_id); }
        DataProcessResult::success(true)
    }

    pub async fn revoke(&self, user_id: &str, permission: &str) -> DataProcessResult<bool> {
        self.base.delete_document("permissions", &format!("{}:{}", user_id, permission)).await;
        if let Ok(mut c) = self.cache.write() { c.remove(user_id); }
        DataProcessResult::success(true)
    }
}
