<?php
// XIIGen Permissions Service — PHP | Skill 21
namespace XIIGen\Platform\Permissions;
use XIIGen\Core\{MicroserviceBase, DataProcessResult, IDatabaseService, IQueueService};

class PermissionsService extends MicroserviceBase {
    protected string $serviceName = 'permissions-service';
    private array $cache = [];

    public function __construct(IDatabaseService $db, IQueueService $queue) { parent::__construct($db, $queue); }

    public function hasPermission(string $userId, string $permission): bool {
        if (isset($this->cache[$userId])) return in_array($permission, $this->cache[$userId]);
        $result = $this->searchDocuments('permissions', ['userId' => $userId], 100);
        if (!$result->isSuccess) return false;
        $perms = array_map(fn($d) => $d['permission'] ?? '', $result->data ?? []);
        $this->cache[$userId] = $perms;
        return in_array($permission, $perms);
    }

    public function hasRole(string $userId, string $role): bool { return $this->hasPermission($userId, "role:$role"); }

    public function grant(string $userId, string $permission): DataProcessResult {
        $this->storeDocument('permissions', "$userId:$permission", ['userId' => $userId, 'permission' => $permission, 'grantedAt' => date('c')]);
        unset($this->cache[$userId]);
        $this->publishEvent('permissions.granted', ['userId' => $userId, 'permission' => $permission]);
        return DataProcessResult::success(true);
    }

    public function revoke(string $userId, string $permission): DataProcessResult {
        $this->deleteDocument('permissions', "$userId:$permission");
        unset($this->cache[$userId]);
        return DataProcessResult::success(true);
    }
}
