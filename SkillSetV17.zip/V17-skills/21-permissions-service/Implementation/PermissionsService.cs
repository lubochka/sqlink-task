// XIIGen.Platform.Permissions/PermissionsService.cs - Skill 21 | .NET 9
using Microsoft.Extensions.Logging;
using XIIGen.Core.Base;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Platform.Permissions;

public class PermissionsServiceImpl : MicroserviceBase, IPermissionsService
{
    private readonly Dictionary<string, HashSet<string>> _permissionCache = [];

    public PermissionsServiceImpl(IDatabaseService db, IQueueService queue, ILogger<PermissionsServiceImpl> logger, ICacheService cache = null)
        : base(db, queue, logger, cache) { ServiceName = "permissions-service"; }

    public async Task<bool> HasPermissionAsync(string userId, string permission, CancellationToken ct = default)
    {
        if (_permissionCache.TryGetValue(userId, out var perms)) return perms.Contains(permission);
        var result = await SearchDocumentsAsync("permissions", new { userId }, 100, ct);
        if (!result.IsSuccess) return false;
        var permissions = new HashSet<string>(result.Data?.SelectMany(d => new[] { d?.ToString() ?? "" }) ?? []);
        _permissionCache[userId] = permissions;
        return permissions.Contains(permission);
    }

    public async Task<bool> HasRoleAsync(string userId, string role, CancellationToken ct = default)
        => await HasPermissionAsync(userId, $"role:{role}", ct);

    public async Task<List<string>> GetPermissionsAsync(string userId, CancellationToken ct = default)
    {
        var result = await SearchDocumentsAsync("permissions", new { userId }, 100, ct);
        return result.IsSuccess ? result.Data?.Select(d => d?.ToString() ?? "").ToList() ?? [] : [];
    }

    public async Task<DataProcessResult<bool>> GrantPermissionAsync(string userId, string permission, CancellationToken ct = default)
    {
        await StoreDocumentAsync("permissions", $"{userId}:{permission}", new { userId, permission, grantedAt = DateTime.UtcNow }, ct: ct);
        _permissionCache.Remove(userId);
        await PublishEventAsync("permissions.granted", new { userId, permission }, ct);
        return DataProcessResult<bool>.Success(true);
    }

    public async Task<DataProcessResult<bool>> RevokePermissionAsync(string userId, string permission, CancellationToken ct = default)
    {
        await DeleteDocumentAsync("permissions", $"{userId}:{permission}", ct);
        _permissionCache.Remove(userId);
        await PublishEventAsync("permissions.revoked", new { userId, permission }, ct);
        return DataProcessResult<bool>.Success(true);
    }
}
