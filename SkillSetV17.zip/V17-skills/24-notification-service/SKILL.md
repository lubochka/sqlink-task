---
skill_id: "24"
name: notification-service
title: "Notification Service"
layer: "L6: Platform Services"
version: "17.0"
status: "active"
dependencies:
  - "01-core-interfaces"
  - "02-object-processor"
  - "03-elasticsearch-datastore"
  - "04-redis-queue-service"
  - "20-auth-service"
  - "21-permissions-service"
dotnet_namespace: "XIIGen.Services.Notification"
di_registration: "services.AddXIIGenNotificationService()"
es_index: "xiigen-notifications"
genie_dna:
  - "DNA-1: Notification records and templates as dynamic documents"
  - "DNA-2: BuildSearchFilter for notification queries (userId, channel, status — skip empty)"
  - "DNA-3: Inherits MicroserviceBase (component #14 '3rd party communications')"
  - "DNA-5: DataProcessResult for all operations"
  - "DNA-6: INotificationChannel generic interface — swap channels via config"
  - "DNA-7: Event-driven — subscribes to events from other services to trigger notifications"
  - "DNA-FREEDOM: Notification templates are DYNAMIC — admins define them without code"
triggers: notification, push, email, SMS, WhatsApp, internal, channel, template, notify, socket, SignalR
---

# Skill 24: Notification Service
## Multi-Channel Notifications — Component #14, SignalR Evolution

**Classification: HYBRID — MACHINE dispatch, FREEDOM templates**
From Architecture.docx: "Notifications — internal socket, push, email, SMS, WhatsApp." The dispatch MECHANISM is static. But notification TEMPLATES and routing RULES are dynamic documents.

---

## Genie DNA Integration

### Generic Channel Interface (DNA-6)
```csharp
public interface INotificationChannel
{
    string ChannelType { get; }  // "internal", "push", "email", "sms", "whatsapp"
    Task<DataProcessResult<bool>> SendAsync(Dictionary<string, object> notification);
}
// Swap channels via config — same interface, different implementations
// Adding a new channel = implement interface + register. No existing code changes.
```

### Notification Templates as Dynamic Documents (DNA-1, FREEDOM)
Admins create notification templates without code:
```json
{
  "templateName": "invoice_approved",
  "channels": ["internal", "email"],
  "subject": "Invoice {{invoiceId}} Approved",
  "body": "Your invoice for {{vendor}} ({{amount}}) has been approved by {{approverName}}.",
  "variables": ["invoiceId", "vendor", "amount", "approverName"],
  "createdBy": "admin@company.com"
}
```

### Event-Driven Triggers (DNA-7)
Notifications are triggered by events from other services:
```
Entity state change (Skill 09) → publishes InvoiceApproved event
→ NotificationService subscribes
→ Reads template "invoice_approved"
→ Fills variables from event payload
→ Dispatches to configured channels
```

---

## Interface

```csharp
public interface INotificationService
{
    Task<DataProcessResult<string>> SendAsync(
        string userId, string templateName, Dictionary<string, object> variables);
    Task<DataProcessResult<string>> SendMultiChannelAsync(
        string userId, string[] channels, Dictionary<string, object> notification);
    Task<DataProcessResult<List<Dictionary<string, object>>>> GetUserNotificationsAsync(
        string userId, Dictionary<string, object> filter);
    Task<DataProcessResult<bool>> MarkReadAsync(string notificationId);
    Task<DataProcessResult<string>> CreateTemplateAsync(Dictionary<string, object> templateDoc);
}
```

## Delivery Tracking
Status lifecycle: `queued → sent → delivered → read → failed`
Each status change stored as dynamic document update.

## Scope Isolation
Users can ONLY see their own notifications. BuildSearchFilter auto-injects userId for non-admin queries.

## Alternatives
All alternatives MUST: use INotificationChannel generic interface, store templates/records as dynamic documents, use BuildSearchFilter with scope isolation, return DataProcessResult, support event-driven triggers.
