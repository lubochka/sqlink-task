// XIIGen.Platform.Notifications/NotificationService.cs - Skill 24 | .NET 9
using Microsoft.Extensions.Logging;
using XIIGen.Core.Base;
using XIIGen.Core.Enums;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Platform.Notifications;

public class NotificationService : MicroserviceBase
{
    private readonly Dictionary<string, INotificationChannel> _channels = [];

    public NotificationService(IDatabaseService db, IQueueService queue, ILogger<NotificationService> logger)
        : base(db, queue, logger) { ServiceName = "notification-service"; }

    public void RegisterChannel(string name, INotificationChannel channel) => _channels[name] = channel;

    public async Task<DataProcessResult<string>> SendAsync(NotificationRequest request, CancellationToken ct = default)
    {
        var notificationId = Guid.NewGuid().ToString();
        foreach (var channel in request.Channels)
        {
            if (_channels.TryGetValue(channel, out var ch))
            {
                try { await ch.SendAsync(request.UserId, request.Title, request.Body, request.Data, ct); }
                catch (Exception ex) { await LogErrorAsync($"Notification failed on {channel}", ex); }
            }
        }
        await StoreDocumentAsync("notifications", notificationId, new { request, sentAt = DateTime.UtcNow, id = notificationId }, ct: ct);
        return DataProcessResult<string>.Success(notificationId);
    }

    protected override async Task OnStartedAsync(CancellationToken ct)
    {
        await RegisterEventHandlerAsync("xiigen.events.notification.*");
    }
}

public class NotificationRequest
{
    public string UserId { get; set; }
    public string Title { get; set; }
    public string Body { get; set; }
    public List<string> Channels { get; set; } = ["internal"]; // internal, push, email, sms, whatsapp
    public Dictionary<string, object> Data { get; set; } = [];
}

public interface INotificationChannel
{
    string ChannelName { get; }
    Task SendAsync(string userId, string title, string body, Dictionary<string, object> data, CancellationToken ct = default);
}

public class InternalNotificationChannel : INotificationChannel
{
    public string ChannelName => "internal";
    public Task SendAsync(string userId, string title, string body, Dictionary<string, object> data, CancellationToken ct = default)
    {
        // Push via SignalR/WebSocket to connected clients
        return Task.CompletedTask;
    }
}
