// XIIGen Notification Service — Rust | Skill 24
use async_trait::async_trait;
use serde_json::{json, Value};
use uuid::Uuid;
use chrono::Utc;
use std::collections::HashMap;
use crate::core::{DataProcessResult, IDatabaseService, IQueueService, MicroserviceBase};

#[async_trait]
pub trait NotificationChannel: Send + Sync { fn channel_name(&self) -> &str; async fn send(&self, user_id: &str, title: &str, body: &str, data: &Value); }

pub struct NotificationService {
    base: MicroserviceBase,
    channels: HashMap<String, Box<dyn NotificationChannel>>,
}

impl NotificationService {
    pub fn new(db: Box<dyn IDatabaseService>, queue: Box<dyn IQueueService>) -> Self {
        Self { base: MicroserviceBase::new(db, queue, "notification-service"), channels: HashMap::new() }
    }

    pub fn register_channel(&mut self, name: String, channel: Box<dyn NotificationChannel>) { self.channels.insert(name, channel); }

    pub async fn send(&self, user_id: &str, title: &str, body: &str, channel_names: Option<Vec<String>>, data: Option<Value>) -> DataProcessResult<String> {
        let nid = Uuid::new_v4().to_string();
        let targets = channel_names.unwrap_or_else(|| vec!["internal".to_string()]);
        for ch_name in &targets {
            if let Some(ch) = self.channels.get(ch_name) { ch.send(user_id, title, body, &data.clone().unwrap_or(json!({}))).await; }
        }
        self.base.store_document("notifications", &nid, &json!({"id": nid, "userId": user_id, "title": title, "body": body, "sentAt": Utc::now().to_rfc3339()})).await;
        DataProcessResult::success(nid)
    }
}
