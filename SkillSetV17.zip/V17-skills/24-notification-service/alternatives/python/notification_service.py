# XIIGen Notification Service — Python | Skill 24
import uuid
from abc import ABC, abstractmethod
from datetime import datetime, timezone
from core_interfaces import IDatabaseService, IQueueService, DataProcessResult, MicroserviceBase

class INotificationChannel(ABC):
    @abstractmethod
    async def send(self, user_id: str, title: str, body: str, data: dict) -> None: ...

class NotificationService(MicroserviceBase):
    service_name = "notification-service"
    def __init__(self, db: IDatabaseService, queue: IQueueService):
        super().__init__(db, queue)
        self._channels: dict[str, INotificationChannel] = {}

    def register_channel(self, name: str, channel: INotificationChannel): self._channels[name] = channel

    async def send(self, user_id: str, title: str, body: str, channels: list[str] = None, data: dict = None) -> DataProcessResult:
        nid = str(uuid.uuid4())
        for ch_name in (channels or ["internal"]):
            ch = self._channels.get(ch_name)
            if ch:
                try: await ch.send(user_id, title, body, data or {})
                except Exception as e: print(f"Channel {ch_name} failed: {e}")
        await self.store_document("notifications", nid, {"id": nid, "userId": user_id, "title": title, "body": body, "channels": channels, "sentAt": datetime.now(timezone.utc).isoformat()})
        return DataProcessResult.success(nid)

    async def send_batch(self, requests: list[dict]) -> DataProcessResult:
        ids = []
        for req in requests:
            result = await self.send(**req)
            if result.is_success: ids.append(result.data)
        return DataProcessResult.success(ids)
