<?php
// XIIGen Notification Service — PHP | Skill 24
namespace XIIGen\Platform\Notifications;
use XIIGen\Core\{MicroserviceBase, DataProcessResult, IDatabaseService, IQueueService};

interface INotificationChannel { public function getChannelName(): string; public function send(string $userId, string $title, string $body, array $data): void; }

class NotificationService extends MicroserviceBase {
    protected string $serviceName = 'notification-service';
    private array $channels = [];

    public function __construct(IDatabaseService $db, IQueueService $queue) { parent::__construct($db, $queue); }

    public function registerChannel(string $name, INotificationChannel $channel): void { $this->channels[$name] = $channel; }

    public function send(string $userId, string $title, string $body, array $channels = ['internal'], array $data = []): DataProcessResult {
        $nid = \Ramsey\Uuid\Uuid::uuid4()->toString();
        foreach ($channels as $chName) {
            $ch = $this->channels[$chName] ?? null;
            if ($ch) { try { $ch->send($userId, $title, $body, $data); } catch (\Exception $e) { /* log */ } }
        }
        $this->storeDocument('notifications', $nid, ['id' => $nid, 'userId' => $userId, 'title' => $title, 'body' => $body, 'sentAt' => date('c')]);
        return DataProcessResult::success($nid);
    }
}
