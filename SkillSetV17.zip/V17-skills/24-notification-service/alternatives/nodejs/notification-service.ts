// XIIGen Notification Service — Node.js/TypeScript | Skill 24
import { IDatabaseService, IQueueService, DataProcessResult, MicroserviceBase } from '../../01-core-interfaces';
import { randomUUID } from 'crypto';

interface INotificationChannel { channelName: string; send(userId: string, title: string, body: string, data: Record<string, any>): Promise<void>; }
interface NotificationRequest { userId: string; title: string; body: string; channels?: string[]; data?: Record<string, any>; }

export class NotificationService extends MicroserviceBase {
  private channels: Map<string, INotificationChannel> = new Map();
  protected serviceName = 'notification-service';

  constructor(db: IDatabaseService, queue: IQueueService) { super(db, queue); }

  registerChannel(name: string, channel: INotificationChannel) { this.channels.set(name, channel); }

  async send(request: NotificationRequest): Promise<DataProcessResult<string>> {
    const notificationId = randomUUID();
    const targets = request.channels || ['internal'];
    for (const ch of targets) {
      const channel = this.channels.get(ch);
      if (channel) { try { await channel.send(request.userId, request.title, request.body, request.data || {}); } catch (e) { console.error(`Channel ${ch} failed`, e); } }
    }
    await this.storeDocument('notifications', notificationId, { ...request, id: notificationId, sentAt: new Date() });
    return DataProcessResult.success(notificationId);
  }

  async sendBatch(requests: NotificationRequest[]): Promise<DataProcessResult<string[]>> {
    const ids: string[] = [];
    for (const req of requests) { const result = await this.send(req); if (result.isSuccess) ids.push(result.data); }
    return DataProcessResult.success(ids);
  }

  async getHistory(userId: string, limit = 20): Promise<any[]> {
    const result = await this.searchDocuments('notifications', { userId }, limit);
    return result.isSuccess ? result.data || [] : [];
  }
}
