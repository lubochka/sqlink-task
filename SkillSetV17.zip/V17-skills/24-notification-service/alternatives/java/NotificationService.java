// XIIGen Notification Service — Java | Skill 24
package com.xiigen.platform.notifications;
import com.xiigen.core.*;
import java.time.Instant;
import java.util.*;

public interface INotificationChannel { String getChannelName(); void send(String userId, String title, String body, Map<String, Object> data) throws Exception; }

public class NotificationService extends MicroserviceBase {
    private final Map<String, INotificationChannel> channels = new HashMap<>();
    public NotificationService(IDatabaseService db, IQueueService queue) { super(db, queue, "notification-service"); }

    public void registerChannel(String name, INotificationChannel channel) { channels.put(name, channel); }

    public DataProcessResult<String> send(String userId, String title, String body, List<String> channelNames, Map<String, Object> data) throws Exception {
        String nid = UUID.randomUUID().toString();
        for (String ch : channelNames != null ? channelNames : List.of("internal")) {
            var channel = channels.get(ch);
            if (channel != null) { try { channel.send(userId, title, body, data != null ? data : Map.of()); } catch (Exception e) { /* log */ } }
        }
        storeDocument("notifications", nid, Map.of("id", nid, "userId", userId, "title", title, "body", body, "sentAt", Instant.now().toString()));
        return DataProcessResult.success(nid);
    }
}
