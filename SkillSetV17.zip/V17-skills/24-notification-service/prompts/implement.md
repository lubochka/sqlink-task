# Notification Service — Implementation Prompt | Skill 24
## Phase 1: Core Interface + Channels
1. `INotificationChannel` interface: channelName, SendAsync
2. Channel registry: RegisterChannel/GetChannel
3. `NotificationService` extends MicroserviceBase

## Phase 2: Send + Multi-Channel
1. `SendAsync(request)` dispatches to all requested channels
2. Store notification record as dynamic doc; return notificationId
3. Error handling per channel (one failure doesn't block others)

## Phase 3: Templates + Batch
1. Template storage with `{{variable}}` substitution
2. `SendBatchAsync` for bulk notifications with personalization
3. Delivery tracking: queued→sent→delivered→read→failed

## Phase 4: Scheduling & Testing
1. Scheduled notifications with cron-like expressions
2. Retry with exponential backoff on failures
3. **Genie DNA Checklist:** ☐ DataProcessResult ☐ BuildSearchFilter ☐ Dynamic docs ☐ INotificationChannel interface


---

## Genie DNA Compliance — MANDATORY for All Implementations

> Before writing ANY code, classify each component:
> **MACHINE** (static): Infrastructure that enables freedom. Build once, generic, interface-based.
> **FREEDOM** (dynamic): Anything users define. No fixed models, config-driven.

### DNA Checklist — Every Implementation MUST:
☐ **DNA-1 (Dynamic Documents):** Store data as `Dictionary<string, object>` / `Record<string, any>` — NOT typed model classes. User fields preserved without schema changes.
☐ **DNA-2 (BuildSearchFilter):** All queries use BuildSearchFilter/equivalent. Empty fields auto-skipped. No entity-specific query code.
☐ **DNA-3 (MicroserviceBase):** Inherit base class with DB, queue, cache, logger built in.
☐ **DNA-5 (DataProcessResult):** All public methods return `DataProcessResult<T>`. Errors return failure, not throw exceptions.
☐ **DNA-6 (Generic Interfaces):** External dependencies behind interfaces. Swap via config.
☐ **DNA-SCOPE:** Non-admin queries auto-inject userId filter. Cannot be bypassed.

### The Three Tests:
1. Can a business user change this without a developer? (YES = correct)
2. Does it work for entity types that do not exist yet? (YES = correct)
3. Can I swap the database/service/UI without changing this? (YES = correct)
