# Skill 37: Security — Implementation Prompt

## Phase 1: Input Sanitization
Sanitization in ObjectProcessor. HTML entity escaping. SQL injection prevention.

## Phase 2: Scope Verification
Scan all query paths -> verify BuildSearchFilter receives UserScope.
Flag queries without scope as security violations.

## Phase 3: OWASP Compliance
Implement mitigations for OWASP Top 10. Security headers. CORS configuration.

## Phase 4: Security Monitoring
Security event logging. Threat detection. Alert on anomalous access patterns.

---

## Genie DNA Compliance — MANDATORY
☐ DNA-1: Dynamic Documents — Dictionary<string, object>, NOT typed models
☐ DNA-2: BuildSearchFilter — skip empty fields, no entity-specific query code
☐ DNA-3: MicroserviceBase — inherit DB, queue, cache, logger
☐ DNA-5: DataProcessResult<T> — all methods return result wrapper
☐ DNA-6: Generic Interfaces — swap via config
☐ DNA-SCOPE: Non-admin queries auto-inject userId filter
