---
skill_id: "37"
name: safe-code
title: "Safe Code — Security & Vulnerability Management"
layer: "L8: Quality Assurance"
version: "17.1"
status: "active"
priority: "P0"
dependencies: ["01-core-interfaces", "20-auth-service", "36-logging"]
alternatives_server: [azure-keyvault, aws-secrets, hashicorp-vault, dotnet-user-secrets, doppler]
genie_dna:
  - "DNA-SAFE: All secrets via Key Vault, never in code or config files"
  - "DNA-6: Security patterns work across all server alternatives"
  - "DNA-RESULT: Security scans return DataProcessResult with severity levels"
triggers: security, key vault, secrets, vulnerability, safe code, OWASP, dependency scan, encryption, secure coding
estimated_loc: 600
---

# Skill 37: Safe Code — Security & Vulnerability Management
## Key Vault Integration, Vulnerability Scanning, and Secure Coding Patterns

**Classification:** MACHINE — Security configs are static  
**Priority:** P0 — Critical for production readiness  
**Dependencies:** Skill 01 (Core), Skill 20 (Auth), Skill 36 (Logging)  
**Layer:** L8: Quality Assurance  
**Estimated LOC:** ~600  

---

## Overview

Safe Code manages security across the XIIGen platform: Key Vault integration for secrets management, automated vulnerability scanning for dependencies and code, OWASP compliance checks, encryption at rest and in transit, and secure coding pattern enforcement. It provides a unified security interface that works across Azure Key Vault, AWS Secrets Manager, HashiCorp Vault, and local dev secrets. Scan results are stored as dynamic documents for tracking remediation progress.

## Key Concepts

- **Secret Provider Abstraction** — Generic `ISecretProvider` interface. Swap between Azure Key Vault, AWS, HashiCorp Vault without code changes.
- **Dependency Scanning** — Automated NuGet/npm/pip/cargo audit integration. Fails CI/CD (Skill 32) if critical vulnerabilities found.
- **Code Pattern Scanner** — Static analysis rules that detect: hardcoded secrets, SQL injection risks, missing input validation, insecure deserialization.
- **Encryption Service** — AES-256 for data at rest, TLS 1.3 enforcement, field-level encryption for PII in dynamic documents.
- **Security Audit Trail** — All secret access, scan results, and remediation actions logged as dynamic documents.

---

## DNA Integration

### Required Patterns
- **DataProcessResult** — Security scans return `DataProcessResult<SecurityReport>` with findings categorized by severity.
- **Dynamic Document** — Vulnerability records, scan history, remediation tracking all stored as dynamic documents.
- **BuildSearchFilter** — Query vulnerabilities by severity, package, service, status — empty fields skipped.
- **Scope Isolation** — Each microservice has its own secret scope. Service A cannot access Service B's secrets.

### Anti-Patterns to AVOID
- ❌ Hardcoding secrets in code, config files, or environment variables checked into Git
- ❌ Using the same encryption key for all services — per-service key rotation
- ❌ Ignoring dependency vulnerabilities — fail CI/CD on critical/high
- ❌ Logging secrets or PII in plain text — use Skill 36 sanitizer
- ❌ Disabling HTTPS for "development convenience" — always TLS

---

## Primary Implementation (.NET 9)

### Secret Provider Interface

```csharp
namespace XIIGen.Security.Interfaces;

public interface ISecretProvider
{
    Task<DataProcessResult<string>> GetSecretAsync(string key, CancellationToken ct = default);
    Task<DataProcessResult<bool>> SetSecretAsync(string key, string value, TimeSpan? expiry = null, CancellationToken ct = default);
    Task<DataProcessResult<bool>> RotateSecretAsync(string key, CancellationToken ct = default);
    Task<DataProcessResult<List<string>>> ListSecretsAsync(string prefix = null, CancellationToken ct = default);
}

public interface ISecurityScanner
{
    Task<DataProcessResult<SecurityReport>> ScanDependenciesAsync(string serviceId, CancellationToken ct = default);
    Task<DataProcessResult<SecurityReport>> ScanCodePatternsAsync(string serviceId, string[] sourcePaths, CancellationToken ct = default);
    Task<DataProcessResult<SecurityReport>> RunOwaspCheckAsync(string serviceId, CancellationToken ct = default);
}

public interface IEncryptionService
{
    Task<DataProcessResult<string>> EncryptAsync(string plaintext, string scope, CancellationToken ct = default);
    Task<DataProcessResult<string>> DecryptAsync(string ciphertext, string scope, CancellationToken ct = default);
    Task<DataProcessResult<bool>> RotateKeyAsync(string scope, CancellationToken ct = default);
}
```

### Models

```csharp
public record SecurityReport(
    string ServiceId, string ScanType,
    List<Vulnerability> Findings,
    int Critical, int High, int Medium, int Low,
    bool PassesGate, DateTime ScannedAt
);

public record Vulnerability(
    string Id, string Package, string Severity,
    string Description, string Remediation, string Status
);
```

### DI Registration

```csharp
// Swap provider based on config
services.AddScoped<ISecretProvider>(sp => 
    config["SecretProvider"] switch {
        "azure" => new AzureKeyVaultProvider(config),
        "aws" => new AwsSecretsProvider(config),
        "hashicorp" => new HashiCorpVaultProvider(config),
        _ => new LocalDevSecretsProvider(config)
    });
services.AddScoped<ISecurityScanner, SecurityScanner>();
services.AddScoped<IEncryptionService, AesEncryptionService>();
```

---

## Test Scenarios

1. Get secret from Azure Key Vault → verify DataProcessResult with value
2. Swap to HashiCorp Vault → verify same interface works
3. Scan service with known vulnerable dependency → verify critical finding in report
4. Scan code with hardcoded API key → verify code pattern scanner detects it
5. Encrypt PII field → verify ciphertext stored in ES, decryption recovers original
6. Rotate encryption key → verify existing data still decryptable with key versioning
7. Query vulnerabilities by severity=critical → verify BuildSearchFilter pattern

## Component Classification
- **Category:** Security Management
- **Inputs:** Secret keys, source code paths, dependency manifests
- **Outputs:** Secrets, security reports, encrypted/decrypted data
- **Side Effects:** Accesses Key Vault, writes scan results to ES
- **ES Indexes:** `security-scans`, `vulnerability-tracking`
