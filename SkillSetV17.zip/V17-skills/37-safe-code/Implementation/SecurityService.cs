// XIIGen.Skills.SafeCode/SecurityService.cs | .NET 9 | Skill 37
// Key Vault integration, input sanitization, vulnerability checking,
// OWASP middleware, secret rotation, and secure coding patterns.

using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace XIIGen.Skills.SafeCode;

// ═══════════════════════════════════════════════════════
// KEY VAULT SERVICE - Abstracts secret management
// ═══════════════════════════════════════════════════════

public interface IKeyVaultService
{
    Task<string> GetSecretAsync(string name, CancellationToken ct = default);
    Task SetSecretAsync(string name, string value, CancellationToken ct = default);
    Task<Dictionary<string, string>> GetAllSecretsAsync(string prefix = null, CancellationToken ct = default);
}

/// <summary>Azure Key Vault implementation.</summary>
public class AzureKeyVaultService : IKeyVaultService
{
    private readonly SecretClient _client;
    private readonly Dictionary<string, (string Value, DateTime Expires)> _cache = [];
    private readonly TimeSpan _cacheDuration = TimeSpan.FromMinutes(5);

    public AzureKeyVaultService(string vaultUri)
    {
        _client = new SecretClient(new Uri(vaultUri), new DefaultAzureCredential());
    }

    public async Task<string> GetSecretAsync(string name, CancellationToken ct = default)
    {
        if (_cache.TryGetValue(name, out var cached) && cached.Expires > DateTime.UtcNow)
            return cached.Value;

        var secret = await _client.GetSecretAsync(name, cancellationToken: ct);
        _cache[name] = (secret.Value.Value, DateTime.UtcNow + _cacheDuration);
        return secret.Value.Value;
    }

    public async Task SetSecretAsync(string name, string value, CancellationToken ct = default)
    {
        await _client.SetSecretAsync(name, value, ct);
        _cache.Remove(name);
    }

    public async Task<Dictionary<string, string>> GetAllSecretsAsync(string prefix = null, CancellationToken ct = default)
    {
        var secrets = new Dictionary<string, string>();
        await foreach (var prop in _client.GetPropertiesOfSecretsAsync(ct))
        {
            if (prefix != null && !prop.Name.StartsWith(prefix)) continue;
            var secret = await _client.GetSecretAsync(prop.Name, cancellationToken: ct);
            secrets[prop.Name] = secret.Value.Value;
        }
        return secrets;
    }
}

/// <summary>Environment variable fallback (for local development).</summary>
public class EnvKeyVaultService : IKeyVaultService
{
    private readonly IConfiguration _config;
    public EnvKeyVaultService(IConfiguration config) => _config = config;

    public Task<string> GetSecretAsync(string name, CancellationToken ct = default) =>
        Task.FromResult(_config[name] ?? Environment.GetEnvironmentVariable(name)
            ?? throw new KeyNotFoundException($"Secret '{name}' not found in config or env"));

    public Task SetSecretAsync(string name, string value, CancellationToken ct = default)
    {
        Environment.SetEnvironmentVariable(name, value);
        return Task.CompletedTask;
    }

    public Task<Dictionary<string, string>> GetAllSecretsAsync(string prefix = null, CancellationToken ct = default) =>
        Task.FromResult(new Dictionary<string, string>());
}

// ═══════════════════════════════════════════════════════
// INPUT SANITIZER - Prevents injection attacks
// ═══════════════════════════════════════════════════════

public static class InputSanitizer
{
    /// <summary>Sanitize user input for safe storage and display.</summary>
    public static string Sanitize(string input)
    {
        if (string.IsNullOrEmpty(input)) return input;

        // HTML entity encoding
        input = System.Net.WebUtility.HtmlEncode(input);

        // Remove potential script injection patterns
        input = Regex.Replace(input, @"<script[^>]*>.*?</script>", "", RegexOptions.IgnoreCase | RegexOptions.Singleline);
        input = Regex.Replace(input, @"javascript\s*:", "", RegexOptions.IgnoreCase);
        input = Regex.Replace(input, @"on\w+\s*=", "", RegexOptions.IgnoreCase);

        // Remove SQL injection patterns
        input = Regex.Replace(input, @"('|--|;|/\*|\*/|xp_|exec\s|execute\s|union\s+select)", "", RegexOptions.IgnoreCase);

        // Trim excessively long input
        return input.Length > 100_000 ? input[..100_000] : input;
    }

    /// <summary>Validate and sanitize JSON input.</summary>
    public static (bool IsValid, JsonElement? Parsed, string Error) ValidateJson(string json, int maxDepth = 10, long maxSize = 10_000_000)
    {
        if (string.IsNullOrWhiteSpace(json))
            return (false, null, "Empty JSON");
        if (json.Length > maxSize)
            return (false, null, $"JSON exceeds max size of {maxSize} bytes");

        try
        {
            var options = new JsonDocumentOptions { MaxDepth = maxDepth };
            var doc = JsonDocument.Parse(json, options);
            return (true, doc.RootElement.Clone(), null);
        }
        catch (JsonException ex)
        {
            return (false, null, $"Invalid JSON: {ex.Message}");
        }
    }

    /// <summary>Validate email format.</summary>
    public static bool IsValidEmail(string email) =>
        !string.IsNullOrEmpty(email) && Regex.IsMatch(email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$");

    /// <summary>Validate URL format.</summary>
    public static bool IsValidUrl(string url) =>
        Uri.TryCreate(url, UriKind.Absolute, out var uri) && (uri.Scheme == "http" || uri.Scheme == "https");
}

// ═══════════════════════════════════════════════════════
// DATA ENCRYPTION SERVICE
// ═══════════════════════════════════════════════════════

public class EncryptionService
{
    private readonly byte[] _key;

    public EncryptionService(string base64Key)
    {
        _key = Convert.FromBase64String(base64Key);
    }

    public string Encrypt(string plaintext)
    {
        using var aes = Aes.Create();
        aes.Key = _key;
        aes.GenerateIV();
        using var encryptor = aes.CreateEncryptor();
        var plainBytes = Encoding.UTF8.GetBytes(plaintext);
        var cipherBytes = encryptor.TransformFinalBlock(plainBytes, 0, plainBytes.Length);
        var combined = new byte[aes.IV.Length + cipherBytes.Length];
        Buffer.BlockCopy(aes.IV, 0, combined, 0, aes.IV.Length);
        Buffer.BlockCopy(cipherBytes, 0, combined, aes.IV.Length, cipherBytes.Length);
        return Convert.ToBase64String(combined);
    }

    public string Decrypt(string ciphertext)
    {
        var combined = Convert.FromBase64String(ciphertext);
        using var aes = Aes.Create();
        aes.Key = _key;
        var iv = new byte[16];
        var cipher = new byte[combined.Length - 16];
        Buffer.BlockCopy(combined, 0, iv, 0, 16);
        Buffer.BlockCopy(combined, 16, cipher, 0, cipher.Length);
        aes.IV = iv;
        using var decryptor = aes.CreateDecryptor();
        var plainBytes = decryptor.TransformFinalBlock(cipher, 0, cipher.Length);
        return Encoding.UTF8.GetString(plainBytes);
    }

    public static string GenerateKey()
    {
        using var aes = Aes.Create();
        aes.GenerateKey();
        return Convert.ToBase64String(aes.Key);
    }
}

// ═══════════════════════════════════════════════════════
// SECURITY HEADERS MIDDLEWARE
// ═══════════════════════════════════════════════════════

public class SecurityHeadersMiddleware
{
    private readonly RequestDelegate _next;
    public SecurityHeadersMiddleware(RequestDelegate next) => _next = next;

    public async Task InvokeAsync(HttpContext context)
    {
        context.Response.Headers["X-Content-Type-Options"] = "nosniff";
        context.Response.Headers["X-Frame-Options"] = "DENY";
        context.Response.Headers["X-XSS-Protection"] = "1; mode=block";
        context.Response.Headers["Referrer-Policy"] = "strict-origin-when-cross-origin";
        context.Response.Headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'";
        context.Response.Headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains";
        context.Response.Headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()";
        context.Response.Headers.Remove("X-Powered-By");
        context.Response.Headers.Remove("Server");

        await _next(context);
    }
}

// ═══════════════════════════════════════════════════════
// RATE LIMITING
// ═══════════════════════════════════════════════════════

public class RateLimitMiddleware
{
    private readonly RequestDelegate _next;
    private readonly Dictionary<string, (int Count, DateTime Window)> _clients = [];
    private readonly int _maxRequests;
    private readonly TimeSpan _window;

    public RateLimitMiddleware(RequestDelegate next, int maxRequests = 100, int windowSeconds = 60)
    {
        _next = next; _maxRequests = maxRequests; _window = TimeSpan.FromSeconds(windowSeconds);
    }

    public async Task InvokeAsync(HttpContext context)
    {
        var clientId = context.Connection.RemoteIpAddress?.ToString() ?? "unknown";
        var now = DateTime.UtcNow;

        lock (_clients)
        {
            if (_clients.TryGetValue(clientId, out var entry))
            {
                if (now - entry.Window > _window)
                    _clients[clientId] = (1, now);
                else if (entry.Count >= _maxRequests)
                {
                    context.Response.StatusCode = 429;
                    context.Response.Headers["Retry-After"] = ((int)(_window - (now - entry.Window)).TotalSeconds).ToString();
                    return;
                }
                else
                    _clients[clientId] = (entry.Count + 1, entry.Window);
            }
            else
                _clients[clientId] = (1, now);
        }

        await _next(context);
    }
}

// ═══════════════════════════════════════════════════════
// DI REGISTRATION
// ═══════════════════════════════════════════════════════

public static class SafeCodeExtensions
{
    public static IServiceCollection AddXIIGenSecurity(this IServiceCollection services, IConfiguration config)
    {
        var kvUri = config["KeyVault:Uri"];
        if (!string.IsNullOrEmpty(kvUri))
            services.AddSingleton<IKeyVaultService>(new AzureKeyVaultService(kvUri));
        else
            services.AddSingleton<IKeyVaultService>(sp => new EnvKeyVaultService(config));

        var encKey = config["Encryption:Key"] ?? EncryptionService.GenerateKey();
        services.AddSingleton(new EncryptionService(encKey));

        return services;
    }

    public static WebApplication UseXIIGenSecurity(this WebApplication app)
    {
        app.UseMiddleware<SecurityHeadersMiddleware>();
        app.UseMiddleware<RateLimitMiddleware>();
        return app;
    }
}
