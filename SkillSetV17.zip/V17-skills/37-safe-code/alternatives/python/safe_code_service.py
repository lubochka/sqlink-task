"""
XIIGen Skill 37: Safe Code — Python Alternative
Vulnerability scanning, secret management, secure coding patterns
DNA: DataProcessResult, dynamic documents, BuildSearchFilter, scope isolation
"""
from dataclasses import dataclass, field
from typing import Any, Optional
from datetime import datetime
import subprocess, json, re, os

@dataclass
class DataProcessResult:
    success: bool; data: Any = None; message: str = ""

@dataclass
class VulnerabilityItem:
    id: str; severity: str; package: str; version: str
    title: str; fixed_version: Optional[str] = None; cve: Optional[str] = None

@dataclass
class ScanSummary:
    total: int = 0; critical: int = 0; high: int = 0; medium: int = 0; low: int = 0

class SafeCodeService:
    """Security scanning and secret management. DNA-compliant."""
    INDEX = "security-scans"

    def __init__(self, db_service, logger=None):
        self.db = db_service
        self.logger = logger

    async def scan_dependencies(self, scope_id: str, project_path: str, project_name: str) -> DataProcessResult:
        """Scan project dependencies for known vulnerabilities. DNA: DataProcessResult."""
        try:
            # Python: use pip-audit or safety
            result = subprocess.run(
                ["pip-audit", "--format=json", "-r", f"{project_path}/requirements.txt"],
                capture_output=True, text=True, timeout=120
            )
            audit_data = json.loads(result.stdout) if result.stdout else []
            vulns = [
                VulnerabilityItem(
                    id=f"pip-{v.get('name','')}-{v.get('id','')}", severity=v.get("fix_versions") and "high" or "medium",
                    package=v.get("name",""), version=v.get("version",""),
                    title=v.get("description","Vulnerability"), fixed_version=",".join(v.get("fix_versions",[])),
                    cve=v.get("id")
                ) for v in audit_data
            ]
            summary = self._build_summary(vulns)
            report = {
                "id": f"scan-{int(datetime.now().timestamp())}", "scopeId": scope_id,
                "projectName": project_name, "scanType": "dependency",
                "vulnerabilities": [v.__dict__ for v in vulns], "summary": summary.__dict__,
                "scannedAt": datetime.utcnow().isoformat()
            }
            await self.db.upsert(self.INDEX, report)
            return DataProcessResult(True, report, f"Found {summary.total} vulnerabilities")
        except Exception as e:
            return DataProcessResult(False, None, str(e))

    async def get_secret(self, provider: str, vault_url: str, secret_name: str) -> DataProcessResult:
        """Retrieve secret from vault provider. Supports azure, aws, hashicorp, env."""
        try:
            if provider == "azure-keyvault":
                from azure.identity import DefaultAzureCredential
                from azure.keyvault.secrets import SecretClient
                client = SecretClient(vault_url=vault_url, credential=DefaultAzureCredential())
                secret = client.get_secret(secret_name)
                return DataProcessResult(True, secret.value, "Secret retrieved from Azure Key Vault")
            elif provider == "env":
                return DataProcessResult(True, os.environ.get(secret_name, ""), "From environment")
            else:
                return DataProcessResult(False, None, f"Provider {provider} not yet implemented")
        except Exception as e:
            return DataProcessResult(False, None, str(e))

    async def scan_secrets(self, scope_id: str, project_path: str) -> DataProcessResult:
        """Scan codebase for hardcoded secrets. DNA: DataProcessResult."""
        try:
            patterns = [
                r'(?:password|secret|api[_-]?key|token)\s*[:=]\s*["'][^"']+["']',
                r'AKIA[0-9A-Z]{16}',
                r'eyJ[A-Za-z0-9\-_]+\.eyJ[A-Za-z0-9\-_]+',
            ]
            findings = []
            for root, _, files in os.walk(project_path):
                for fname in files:
                    if fname.endswith(('.py', '.js', '.ts', '.env', '.yaml', '.json')):
                        fpath = os.path.join(root, fname)
                        try:
                            with open(fpath) as f:
                                content = f.read()
                            for pat in patterns:
                                for match in re.finditer(pat, content):
                                    findings.append(VulnerabilityItem(
                                        id=f"secret-{len(findings)}", severity="critical",
                                        package=fname, version="", title=f"Potential secret in {fname}"
                                    ))
                        except: pass
            summary = self._build_summary(findings)
            report = {
                "id": f"secret-scan-{int(datetime.now().timestamp())}", "scopeId": scope_id,
                "projectName": project_path, "scanType": "secret",
                "vulnerabilities": [f.__dict__ for f in findings], "summary": summary.__dict__,
                "scannedAt": datetime.utcnow().isoformat()
            }
            await self.db.upsert(self.INDEX, report)
            return DataProcessResult(True, report, f"Found {summary.total} potential secrets")
        except Exception as e:
            return DataProcessResult(False, None, str(e))

    async def query_scans(self, filter_params: dict) -> DataProcessResult:
        """Query scan history. DNA: BuildSearchFilter — skip empty values."""
        try:
            clean = {k: v for k, v in filter_params.items() if v is not None and v != ""}
            results = await self.db.query(self.INDEX, clean)
            return DataProcessResult(True, results, f"Found {len(results)} scans")
        except Exception as e:
            return DataProcessResult(False, [], str(e))

    def security_middleware(self):
        """ASGI middleware for security headers."""
        async def middleware(request, call_next):
            response = await call_next(request)
            response.headers["X-Content-Type-Options"] = "nosniff"
            response.headers["X-Frame-Options"] = "DENY"
            response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
            response.headers["Content-Security-Policy"] = "default-src 'self'"
            return response
        return middleware

    def _build_summary(self, vulns) -> ScanSummary:
        return ScanSummary(
            total=len(vulns),
            critical=sum(1 for v in vulns if v.severity == "critical"),
            high=sum(1 for v in vulns if v.severity == "high"),
            medium=sum(1 for v in vulns if v.severity == "medium"),
            low=sum(1 for v in vulns if v.severity == "low"),
        )
