<?php
/**
 * XIIGen Skill 37: Safe Code — PHP Alternative
 * Vulnerability scanning, secret management, secure coding patterns
 * DNA: DataProcessResult, dynamic documents, BuildSearchFilter, scope isolation
 */
namespace XIIGen\Skills\SafeCode;

class DataProcessResult {
    public function __construct(
        public readonly bool $success,
        public readonly mixed $data,
        public readonly string $message = ""
    ) {}
}

class SafeCodeService {
    private const INDEX = "security-scans";

    public function __construct(
        private readonly object $dbService,
        private readonly ?object $logger = null
    ) {}

    /** Scan Composer dependencies for vulnerabilities. DNA: DataProcessResult. */
    public function scanDependencies(string $scopeId, string $projectPath, string $projectName): DataProcessResult {
        try {
            $output = shell_exec("cd {$projectPath} && composer audit --format=json 2>&1") ?? "{}";
            $audit = json_decode($output, true) ?: [];

            $vulns = [];
            foreach ($audit["advisories"] ?? [] as $pkg => $advisories) {
                foreach ($advisories as $adv) {
                    $vulns[] = [
                        "id" => "composer-" . ($adv["cve"] ?? uniqid()),
                        "severity" => $this->mapSeverity($adv["severity"] ?? "medium"),
                        "package" => $pkg,
                        "version" => $adv["affectedVersions"] ?? "",
                        "title" => $adv["title"] ?? "Vulnerability in {$pkg}",
                        "fixedVersion" => $adv["fixedVersion"] ?? null,
                        "cve" => $adv["cve"] ?? null,
                    ];
                }
            }

            $summary = $this->buildSummary($vulns);
            $report = [
                "id" => "scan-" . time(), "scopeId" => $scopeId,
                "projectName" => $projectName, "scanType" => "dependency",
                "vulnerabilities" => $vulns, "summary" => $summary,
                "scannedAt" => date("c"),
            ];
            // DNA: Store as dynamic document
            // $this->dbService->upsert(self::INDEX, $report);
            return new DataProcessResult(true, $report, "Found {$summary['total']} vulnerabilities");
        } catch (\Throwable $e) {
            return new DataProcessResult(false, null, $e->getMessage());
        }
    }

    /** Retrieve secret from vault provider. */
    public function getSecret(string $provider, string $vaultUrl, string $secretName): DataProcessResult {
        try {
            return match ($provider) {
                "env" => new DataProcessResult(true, getenv($secretName) ?: "", "From environment"),
                "azure-keyvault" => $this->getAzureSecret($vaultUrl, $secretName),
                default => new DataProcessResult(false, null, "Provider {$provider} not implemented"),
            };
        } catch (\Throwable $e) {
            return new DataProcessResult(false, null, $e->getMessage());
        }
    }

    /** Scan for hardcoded secrets. DNA: DataProcessResult. */
    public function scanSecrets(string $scopeId, string $projectPath): DataProcessResult {
        try {
            $patterns = [
                '/(?:password|secret|api[_-]?key|token)\s*[:=]\s*["'][^"']+["']/i',
                '/AKIA[0-9A-Z]{16}/',
                '/eyJ[A-Za-z0-9\-_]+\.eyJ[A-Za-z0-9\-_]+/',
            ];
            $findings = [];
            $iterator = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator($projectPath)
            );
            foreach ($iterator as $file) {
                if ($file->isFile() && in_array($file->getExtension(), ["php","js","ts","env","yaml","json"])) {
                    $content = file_get_contents($file->getPathname());
                    foreach ($patterns as $pat) {
                        if (preg_match_all($pat, $content, $matches)) {
                            foreach ($matches[0] as $match) {
                                $findings[] = [
                                    "id" => "secret-" . count($findings),
                                    "severity" => "critical", "package" => $file->getFilename(),
                                    "version" => "", "title" => "Potential secret in {$file->getFilename()}",
                                ];
                            }
                        }
                    }
                }
            }
            $summary = $this->buildSummary($findings);
            $report = [
                "id" => "secret-scan-" . time(), "scopeId" => $scopeId,
                "scanType" => "secret", "vulnerabilities" => $findings,
                "summary" => $summary, "scannedAt" => date("c"),
            ];
            return new DataProcessResult(true, $report, "Found {$summary['total']} potential secrets");
        } catch (\Throwable $e) {
            return new DataProcessResult(false, null, $e->getMessage());
        }
    }

    /** Query scan history. DNA: BuildSearchFilter — skip empty values. */
    public function queryScans(array $filter): DataProcessResult {
        try {
            $clean = array_filter($filter, fn($v) => $v !== null && $v !== "");
            // $results = $this->dbService->query(self::INDEX, $clean);
            return new DataProcessResult(true, [], "Query with " . count($clean) . " filters");
        } catch (\Throwable $e) {
            return new DataProcessResult(false, [], $e->getMessage());
        }
    }

    /** Laravel/Slim security headers middleware. */
    public function securityHeadersMiddleware(): \Closure {
        return function ($request, $handler) {
            $response = $handler->handle($request);
            return $response
                ->withHeader("X-Content-Type-Options", "nosniff")
                ->withHeader("X-Frame-Options", "DENY")
                ->withHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
                ->withHeader("Content-Security-Policy", "default-src 'self'")
                ->withHeader("Referrer-Policy", "strict-origin-when-cross-origin");
        };
    }

    private function getAzureSecret(string $vaultUrl, string $name): DataProcessResult {
        // Use microsoft/azure-storage or HTTP client to Azure Key Vault REST API
        return new DataProcessResult(false, null, "Azure KV: implement with HTTP client");
    }

    private function buildSummary(array $vulns): array {
        return [
            "total" => count($vulns),
            "critical" => count(array_filter($vulns, fn($v) => ($v["severity"] ?? "") === "critical")),
            "high" => count(array_filter($vulns, fn($v) => ($v["severity"] ?? "") === "high")),
            "medium" => count(array_filter($vulns, fn($v) => ($v["severity"] ?? "") === "medium")),
            "low" => count(array_filter($vulns, fn($v) => ($v["severity"] ?? "") === "low")),
        ];
    }

    private function mapSeverity(string $s): string {
        return match(strtolower($s)) {
            "critical" => "critical", "high" => "high", "medium" => "medium", default => "low"
        };
    }
}
