// XIIGen.Services.Context/AiContextService.cs — Skill 16 | .NET 9
// Assembles rich context packages for AI steps from RAG, feedback, history, and design patterns.
// Genie DNA: ParseObjectAlternative for dynamic docs, BuildSearchFilter for queries, DataProcessResult for all returns.

using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System.Collections.Concurrent;
using System.Text;
using System.Text.Json;
using XIIGen.Core.Base;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Services.Context;

// ─── Configuration ──────────────────────────────────────────────────

public class AiContextOptions
{
    public int DefaultTokenBudget { get; set; } = 4000;
    public int MaxPreviousSteps { get; set; } = 5;
    public int MaxSimilarJobs { get; set; } = 3;
    public int MaxFeedbackItems { get; set; } = 10;
    public int MaxDesignPatterns { get; set; } = 3;
    public double FeedbackPriorityWeight { get; set; } = 90;
    public double RagPriorityWeight { get; set; } = 80;
    public double HistoryPriorityWeight { get; set; } = 70;
    public double PatternPriorityWeight { get; set; } = 60;
    public double CustomPriorityWeight { get; set; } = 50;
    public string ContextIndex { get; set; } = "ai-context-cache";
    public int CacheTtlMinutes { get; set; } = 15;
}

// ─── Models ─────────────────────────────────────────────────────────

public record ContextRequest(
    string TraceId,
    string StepId,
    string StepType,
    string? Technology = null,
    int? TokenBudget = null,
    Dictionary<string, object>? CustomInjections = null
);

public record ContextPackage(
    string TraceId,
    string StepId,
    string FormattedXml,
    int TokensUsed,
    int TokenBudget,
    List<ContextSection> Sections,
    DateTime AssembledAt
);

public record ContextSection(
    string Source,        // rag, feedback, history, patterns, custom
    double Priority,
    int TokensUsed,
    bool WasTruncated,
    string Content
);

public record FeedbackEntry(
    string Id,
    string StepId,
    string Rating,       // positive, neutral, negative
    string Text,
    DateTime CreatedAt,
    Dictionary<string, object>? Metadata = null
);

public record DesignPatternHint(
    string PatternName,
    string Category,
    string WhenToUse,
    string XiigenUsage,
    string? CodeExample = null
);

// ─── Service ────────────────────────────────────────────────────────

public class AiContextService : MicroserviceBase
{
    private readonly AiContextOptions _options;
    private readonly IRagService? _ragService;
    private readonly ConcurrentDictionary<string, (ContextPackage Package, DateTime CachedAt)> _cache = new();

    public AiContextService(
        IDatabaseService db,
        IQueueService queue,
        ILogger<AiContextService> logger,
        IOptions<AiContextOptions> options,
        IRagService? ragService = null,
        ICacheService? cache = null)
        : base(db, queue, logger, cache)
    {
        ServiceName = "ai-context-service";
        _options = options.Value;
        _ragService = ragService;
    }

    // ─── Main Entry Point ───────────────────────────────────────────

    /// <summary>
    /// Assembles a complete context package for an AI step.
    /// Orchestrates: RAG query → feedback fetch → step history → pattern hints → custom injections.
    /// Token budget controls total size; low-priority sources truncated first.
    /// </summary>
    public async Task<DataProcessResult<ContextPackage>> BuildContextAsync(
        ContextRequest request, CancellationToken ct = default)
    {
        try
        {
            var cacheKey = $"{request.TraceId}:{request.StepId}:{request.StepType}";

            // Check cache
            if (_cache.TryGetValue(cacheKey, out var cached) &&
                (DateTime.UtcNow - cached.CachedAt).TotalMinutes < _options.CacheTtlMinutes)
            {
                Logger.LogDebug("Context cache hit for {CacheKey}", cacheKey);
                return DataProcessResult<ContextPackage>.Success(cached.Package);
            }

            var budget = request.TokenBudget ?? _options.DefaultTokenBudget;
            var sections = new List<ContextSection>();

            // 1. Feedback (highest priority)
            var feedbackSection = await BuildFeedbackSectionAsync(request, ct);
            if (feedbackSection != null) sections.Add(feedbackSection);

            // 2. RAG results (from RAG Planner 00b)
            var ragSection = await BuildRagSectionAsync(request, ct);
            if (ragSection != null) sections.Add(ragSection);

            // 3. Step history (previous steps in this trace)
            var historySection = await BuildHistorySectionAsync(request, ct);
            if (historySection != null) sections.Add(historySection);

            // 4. Design pattern hints
            var patternSection = await BuildPatternSectionAsync(request, ct);
            if (patternSection != null) sections.Add(patternSection);

            // 5. Custom injections
            if (request.CustomInjections?.Count > 0)
            {
                var customContent = FormatCustomInjections(request.CustomInjections);
                sections.Add(new ContextSection("custom", _options.CustomPriorityWeight,
                    EstimateTokens(customContent), false, customContent));
            }

            // Apply token budget — truncate low-priority sections first
            var budgetedSections = ApplyTokenBudget(sections, budget);
            var xml = FormatAsXml(budgetedSections, request);
            var tokensUsed = budgetedSections.Sum(s => s.TokensUsed);

            var package = new ContextPackage(
                request.TraceId, request.StepId, xml, tokensUsed, budget,
                budgetedSections, DateTime.UtcNow);

            // Cache the result
            _cache[cacheKey] = (package, DateTime.UtcNow);

            // Store context assembly record for debugging (Skill 14 integration)
            await StoreContextRecordAsync(request, package, ct);

            Logger.LogInformation("Context assembled for {StepId}: {Tokens}/{Budget} tokens, {Sections} sections",
                request.StepId, tokensUsed, budget, budgetedSections.Count);

            return DataProcessResult<ContextPackage>.Success(package);
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Failed to build context for {StepId}", request.StepId);
            return DataProcessResult<ContextPackage>.Failure($"Context assembly failed: {ex.Message}");
        }
    }

    // ─── Section Builders ───────────────────────────────────────────

    private async Task<ContextSection?> BuildFeedbackSectionAsync(ContextRequest request, CancellationToken ct)
    {
        try
        {
            // Genie DNA: BuildSearchFilter skips empty fields
            var filter = ObjectProcessor.BuildSearchFilter(new Dictionary<string, object?>
            {
                ["stepType"] = request.StepType,
                ["technology"] = request.Technology,
                ["rating"] = null // Don't filter by rating — get all
            });

            var result = await SearchDocumentsAsync("feedback", filter, _options.MaxFeedbackItems, ct);
            if (!result.IsSuccess || result.Data == null || result.Data.Count == 0) return null;

            var feedbacks = result.Data
                .Select(d => ObjectProcessor.ParseObjectAlternative<FeedbackEntry>(d))
                .Where(f => f != null)
                .OrderByDescending(f => f!.Rating == "positive" ? 2 : f.Rating == "negative" ? 1 : 0)
                .ThenByDescending(f => f!.CreatedAt)
                .Take(_options.MaxFeedbackItems)
                .ToList();

            if (feedbacks.Count == 0) return null;

            var sb = new StringBuilder();
            var positive = feedbacks.Where(f => f!.Rating == "positive").Take(3);
            var negative = feedbacks.Where(f => f!.Rating == "negative").Take(3);

            if (positive.Any())
            {
                sb.AppendLine("<what-worked>");
                foreach (var f in positive)
                    sb.AppendLine($"  <feedback date=\"{f!.CreatedAt:yyyy-MM-dd}\">{f.Text}</feedback>");
                sb.AppendLine("</what-worked>");
            }

            if (negative.Any())
            {
                sb.AppendLine("<what-to-avoid>");
                foreach (var f in negative)
                    sb.AppendLine($"  <feedback date=\"{f!.CreatedAt:yyyy-MM-dd}\">{f.Text}</feedback>");
                sb.AppendLine("</what-to-avoid>");
            }

            var content = sb.ToString();
            return new ContextSection("feedback", _options.FeedbackPriorityWeight,
                EstimateTokens(content), false, content);
        }
        catch (Exception ex)
        {
            Logger.LogWarning(ex, "Failed to build feedback section");
            return null;
        }
    }

    private async Task<ContextSection?> BuildRagSectionAsync(ContextRequest request, CancellationToken ct)
    {
        if (_ragService == null) return null;

        try
        {
            // Query RAG for relevant context (the RAG Planner 00b would normally plan these queries,
            // but we also support direct search for simpler cases)
            var filter = ObjectProcessor.BuildSearchFilter(new Dictionary<string, object?>
            {
                ["stepType"] = request.StepType,
                ["technology"] = request.Technology
            });

            // Use hybrid search if available, fall back to text search
            var searchText = $"{request.StepType} {request.Technology ?? ""} implementation context";

            DataProcessResult<List<object>>? ragResult = null;

            if (_ragService.Capabilities.SupportsHybrid)
            {
                ragResult = await SearchRagHybridAsync(searchText, filter, _options.MaxSimilarJobs, ct);
            }
            else
            {
                ragResult = await SearchDocumentsAsync("rag-knowledge", filter, _options.MaxSimilarJobs, ct);
            }

            if (ragResult?.IsSuccess != true || ragResult.Data == null || ragResult.Data.Count == 0) return null;

            var sb = new StringBuilder();
            sb.AppendLine("<rag-context>");
            foreach (var item in ragResult.Data.Take(_options.MaxSimilarJobs))
            {
                var doc = ObjectProcessor.ParseObjectAlternative<Dictionary<string, object>>(item);
                if (doc == null) continue;
                sb.AppendLine($"  <knowledge-item>");
                foreach (var (key, value) in doc.Take(5)) // Limit fields per item
                    sb.AppendLine($"    <{key}>{TruncateValue(value?.ToString(), 200)}</{key}>");
                sb.AppendLine($"  </knowledge-item>");
            }
            sb.AppendLine("</rag-context>");

            var content = sb.ToString();
            return new ContextSection("rag", _options.RagPriorityWeight,
                EstimateTokens(content), false, content);
        }
        catch (Exception ex)
        {
            Logger.LogWarning(ex, "Failed to build RAG section");
            return null;
        }
    }

    private async Task<ContextSection?> BuildHistorySectionAsync(ContextRequest request, CancellationToken ct)
    {
        try
        {
            var filter = ObjectProcessor.BuildSearchFilter(new Dictionary<string, object?>
            {
                ["traceId"] = request.TraceId,
                ["status"] = "Completed"
            });

            var result = await SearchDocumentsAsync("ai-jobs", filter, _options.MaxPreviousSteps, ct);
            if (!result.IsSuccess || result.Data == null || result.Data.Count == 0) return null;

            var sb = new StringBuilder();
            sb.AppendLine("<previous-steps>");
            foreach (var job in result.Data.Take(_options.MaxPreviousSteps))
            {
                var doc = ObjectProcessor.ParseObjectAlternative<Dictionary<string, object>>(job);
                if (doc == null) continue;
                var stepName = doc.GetValueOrDefault("stepName")?.ToString() ?? "unknown";
                var output = TruncateValue(doc.GetValueOrDefault("output")?.ToString(), 300);
                sb.AppendLine($"  <step name=\"{stepName}\">{output}</step>");
            }
            sb.AppendLine("</previous-steps>");

            var content = sb.ToString();
            return new ContextSection("history", _options.HistoryPriorityWeight,
                EstimateTokens(content), false, content);
        }
        catch (Exception ex)
        {
            Logger.LogWarning(ex, "Failed to build history section");
            return null;
        }
    }

    private async Task<ContextSection?> BuildPatternSectionAsync(ContextRequest request, CancellationToken ct)
    {
        try
        {
            // Query design patterns relevant to this step type
            var filter = ObjectProcessor.BuildSearchFilter(new Dictionary<string, object?>
            {
                ["stepType"] = request.StepType,
                ["technology"] = request.Technology
            });

            var result = await SearchDocumentsAsync("design-patterns", filter, _options.MaxDesignPatterns, ct);
            if (!result.IsSuccess || result.Data == null || result.Data.Count == 0) return null;

            var sb = new StringBuilder();
            sb.AppendLine("<design-pattern-hints>");
            foreach (var item in result.Data.Take(_options.MaxDesignPatterns))
            {
                var pattern = ObjectProcessor.ParseObjectAlternative<DesignPatternHint>(item);
                if (pattern == null) continue;
                sb.AppendLine($"  <pattern name=\"{pattern.PatternName}\" category=\"{pattern.Category}\">");
                sb.AppendLine($"    <when>{pattern.WhenToUse}</when>");
                sb.AppendLine($"    <xiigen-usage>{pattern.XiigenUsage}</xiigen-usage>");
                if (pattern.CodeExample != null)
                    sb.AppendLine($"    <example>{TruncateValue(pattern.CodeExample, 200)}</example>");
                sb.AppendLine($"  </pattern>");
            }
            sb.AppendLine("</design-pattern-hints>");

            var content = sb.ToString();
            return new ContextSection("patterns", _options.PatternPriorityWeight,
                EstimateTokens(content), false, content);
        }
        catch (Exception ex)
        {
            Logger.LogWarning(ex, "Failed to build pattern section");
            return null;
        }
    }

    // ─── Token Budget Management ────────────────────────────────────

    private List<ContextSection> ApplyTokenBudget(List<ContextSection> sections, int budget)
    {
        // Sort by priority descending — high priority keeps full content
        var sorted = sections.OrderByDescending(s => s.Priority).ToList();
        var result = new List<ContextSection>();
        var remaining = budget;

        foreach (var section in sorted)
        {
            if (remaining <= 0) break;

            if (section.TokensUsed <= remaining)
            {
                result.Add(section);
                remaining -= section.TokensUsed;
            }
            else
            {
                // Truncate to fit remaining budget
                var ratio = (double)remaining / section.TokensUsed;
                var truncatedContent = TruncateToTokens(section.Content, remaining);
                result.Add(section with
                {
                    Content = truncatedContent,
                    TokensUsed = remaining,
                    WasTruncated = true
                });
                remaining = 0;
            }
        }

        return result;
    }

    // ─── XML Formatting ─────────────────────────────────────────────

    private string FormatAsXml(List<ContextSection> sections, ContextRequest request)
    {
        var sb = new StringBuilder();
        sb.AppendLine($"<xiigen-context trace=\"{request.TraceId}\" step=\"{request.StepId}\" type=\"{request.StepType}\">");

        foreach (var section in sections.OrderByDescending(s => s.Priority))
        {
            sb.Append(section.Content);
        }

        sb.AppendLine("</xiigen-context>");
        return sb.ToString();
    }

    private string FormatCustomInjections(Dictionary<string, object> injections)
    {
        var sb = new StringBuilder();
        sb.AppendLine("<custom-context>");
        foreach (var (key, value) in injections)
        {
            sb.AppendLine($"  <{key}>{TruncateValue(value?.ToString(), 500)}</{key}>");
        }
        sb.AppendLine("</custom-context>");
        return sb.ToString();
    }

    // ─── Debug Record Storage ───────────────────────────────────────

    private async Task StoreContextRecordAsync(ContextRequest request, ContextPackage package, CancellationToken ct)
    {
        try
        {
            var record = new Dictionary<string, object>
            {
                ["traceId"] = request.TraceId,
                ["stepId"] = request.StepId,
                ["stepType"] = request.StepType,
                ["tokensUsed"] = package.TokensUsed,
                ["tokenBudget"] = package.TokenBudget,
                ["sectionCount"] = package.Sections.Count,
                ["sections"] = package.Sections.Select(s => new
                {
                    s.Source, s.Priority, s.TokensUsed, s.WasTruncated
                }).ToList(),
                ["assembledAt"] = package.AssembledAt,
                ["technology"] = request.Technology ?? "unspecified"
            };

            // Genie DNA: ParseObjectAlternative for dynamic storage
            var processed = ObjectProcessor.ParseObjectAlternative(record);
            await InsertDocumentAsync(_options.ContextIndex, processed, ct);
        }
        catch (Exception ex)
        {
            Logger.LogWarning(ex, "Failed to store context debug record");
            // Non-fatal — context still works without debug storage
        }
    }

    // ─── Helpers ────────────────────────────────────────────────────

    private async Task<DataProcessResult<List<object>>?> SearchRagHybridAsync(
        string text, Dictionary<string, object> filter, int topK, CancellationToken ct)
    {
        // Delegates to IRagService.HybridSearchAsync
        // This is a simplified wrapper — in production, RAG Planner (00b) plans the queries
        if (_ragService == null) return null;

        try
        {
            var request = new HybridSearchRequest
            {
                Collection = "xiigen-knowledge",
                TextQuery = text,
                TopK = topK,
                MinScore = 0.5,
                Filter = filter
            };
            var result = await _ragService.HybridSearchAsync(request, ct);
            if (!result.IsSuccess) return DataProcessResult<List<object>>.Failure(result.Error ?? "RAG search failed");

            var objects = result.Data?.Select(r => (object)r.Metadata).ToList() ?? new List<object>();
            return DataProcessResult<List<object>>.Success(objects);
        }
        catch (Exception ex)
        {
            return DataProcessResult<List<object>>.Failure($"RAG hybrid search failed: {ex.Message}");
        }
    }

    private static int EstimateTokens(string text)
    {
        // Rough estimate: ~4 chars per token for English/code
        return (int)Math.Ceiling(text.Length / 4.0);
    }

    private static string TruncateToTokens(string text, int maxTokens)
    {
        var maxChars = maxTokens * 4;
        if (text.Length <= maxChars) return text;
        return text[..maxChars] + "... [truncated]";
    }

    private static string TruncateValue(string? value, int maxLength)
    {
        if (string.IsNullOrEmpty(value)) return "";
        if (value.Length <= maxLength) return value;
        return value[..maxLength] + "...";
    }

    // ─── Cache Management ───────────────────────────────────────────

    public void InvalidateCache(string traceId)
    {
        var keysToRemove = _cache.Keys.Where(k => k.StartsWith(traceId + ":")).ToList();
        foreach (var key in keysToRemove)
            _cache.TryRemove(key, out _);
        Logger.LogDebug("Invalidated {Count} cached context entries for trace {TraceId}", keysToRemove.Count, traceId);
    }

    public void ClearCache()
    {
        var count = _cache.Count;
        _cache.Clear();
        Logger.LogInformation("Cleared all {Count} cached context entries", count);
    }

    // ─── DI Registration ────────────────────────────────────────────

    public static IServiceCollection AddAiContextService(IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<AiContextOptions>(configuration.GetSection("AiContext"));
        services.AddScoped<AiContextService>();
        return services;
    }
}
