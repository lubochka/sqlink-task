# Skill 16: AI Context Service — Implementation Guide

## Phase 1: Models & Configuration (20 min)
1. Create `AiContextOptions` with token budget, max items per source, priority weights
2. Create `ContextRequest` (traceId, stepId, stepType, technology, tokenBudget, customInjections)
3. Create `ContextPackage` (formatted XML, tokens used, sections list)
4. Create `ContextSection` (source, priority, tokens, truncated flag, content)
5. Configure via `appsettings.json` → `AiContext` section

## Phase 2: Section Builders (40 min)
Each builder fetches data from its source and formats as XML:
1. **Feedback section** — Query `feedback` index by stepType + technology, format positive/negative
2. **RAG section** — Call IRagService.HybridSearchAsync for relevant knowledge
3. **History section** — Query `ai-jobs` by traceId + status=Completed
4. **Pattern section** — Query `design-patterns` index by stepType
5. **Custom section** — Format injected key-value pairs
6. All builders: use BuildSearchFilter (Genie DNA), ParseObjectAlternative, DataProcessResult

## Phase 3: Token Budget Engine (20 min)
1. Sort sections by priority (descending) — feedback=90, rag=80, history=70, patterns=60
2. Allocate tokens greedily: high-priority sections get full content
3. Last section that exceeds budget gets truncated with `[truncated]` marker
4. Return budgeted sections list with accurate token counts

## Phase 4: XML Assembly & Caching (20 min)
1. Wrap all sections in `<xiigen-context trace="..." step="..." type="...">`
2. Implement in-memory cache with configurable TTL (default 15 min)
3. Cache key: `{traceId}:{stepId}:{stepType}`
4. `InvalidateCache(traceId)` for when feedback changes
5. Store debug record to `ai-context-cache` index for Skill 14 integration

## Phase 5: Integration Testing (20 min)
1. Mock IRagService, IDatabaseService, IQueueService
2. Test: empty context → minimal XML wrapper
3. Test: all sources present → correct priority ordering
4. Test: token budget exceeded → lowest priority truncated
5. Test: cache hit → no DB/RAG calls
6. Test: feedback with positive+negative → correct XML grouping

## Validation Checklist
- [ ] BuildContextAsync orchestrates all 5 source builders
- [ ] Token budget correctly truncates low-priority sections
- [ ] XML format matches `<xiigen-context>` wrapper spec
- [ ] Cache prevents redundant queries within TTL
- [ ] Debug record stored for Skill 14 visibility
- [ ] All DB queries use BuildSearchFilter (Genie DNA)
- [ ] All object parsing uses ParseObjectAlternative (Genie DNA)
- [ ] All returns use DataProcessResult (Genie DNA)
