---
name: ai-context-service
description: Assembles rich context packages for AI steps from RAG, feedback, history, and design patterns with token budget management.
triggers: ai context, context package, token budget, context assembly, prompt context, rag context, feedback injection
dependencies: [01-core-interfaces, 03-elasticsearch-datastore, 06-ai-providers, 00a-rag-interfaces, 00b-rag-planner, 13-feedback-service]
layer: L5-Application
genie-dna: All DB queries use BuildSearchFilter. Object parsing via ParseObjectAlternative. All returns use DataProcessResult.
---

# Skill 16: AI Context Service
## Assembles rich context packages for AI steps from RAG, feedback, history, and design patterns

**Dependencies:** 01, 03, 06, 00a, 00b, 13
**Layer:** L5: Application
**Phase:** 4 (Memory Library)

---

## Overview

The AI Context Service is the "book delivery cart" of XIIGen. It takes what the RAG Planner (00b) decided to look up, actually fetches the data from various sources, and assembles it into a structured context package that gets injected into every AI prompt. Without this service, AI calls would operate blind — no history, no feedback, no design patterns, no previous results.

It manages **token budgets** to ensure context doesn't exceed model limits, prioritizes the most relevant information, and formats everything in the XML injection format that all AI steps expect.

## Key Concepts

- **Context Package** — A structured bundle of: RAG results + feedback + previous step outputs + design pattern hints + custom data
- **Token Budget** — Max tokens allocated for context (default: 4000). Service prioritizes high-value items and truncates low-value ones
- **Context Sources** — Pluggable sources: RAG (00a), Feedback (13), Step History (14), Design Patterns (45), Custom Injections
- **XML Injection Format** — Consistent `<xiigen-context>` wrapper matching Skill 13's feedback format
- **Source Priority** — Each source has a weight (0-100). When budget is tight, low-priority sources get truncated first

---

## Primary Implementation (.NET 9)

### Models

```csharp
// File: XIIGen.Services.Context/Models/ContextModels.cs
namespace XIIGen.Services.Context.Models;

public record ContextRequest(
    string TraceId,
    string CurrentStepId,
    string StepType,
    string? Technology = null,
    string? TaskDescription = null,
    int MaxTokenBudget = 4000,
    Dictionary<string, string>? CustomInjections = null,
    bool IncludeDesignPatterns = true,
    bool IncludeFeedback = true,
    bool IncludeRagResults = true,
    bool IncludeStepHistory = true
);

public record ContextPackage(
    string TraceId,
    string CurrentStepId,
    List<ContextSection> Sections,
    int EstimatedTokens,
    DateTime AssembledAt = default
)
{
    public DateTime AssembledAt { get; init; } = AssembledAt == default ? DateTime.UtcNow : AssembledAt;
}

public record ContextSection(
    string Source,          // "rag", "feedback", "history", "patterns", "custom"
    string Title,
    string Content,
    int Priority,           // 0-100, higher = kept when budget tight
    int EstimatedTokens
);

public record ContextConfig(
    int DefaultTokenBudget = 4000,
    int MaxRagResults = 5,
    int MaxFeedbackItems = 10,
    int MaxHistorySteps = 5,
    int MaxDesignPatterns = 3,
    double FeedbackDecayDays = 30,
    Dictionary<string, int>? SourcePriorities = null
);
```

### Service Interface

```csharp
// File: XIIGen.Services.Context/Interfaces/IAiContextService.cs
namespace XIIGen.Services.Context.Interfaces;

public interface IAiContextService
{
    Task<DataProcessResult<ContextPackage>> BuildContextAsync(
        ContextRequest request, CancellationToken ct = default);
    string FormatForPrompt(ContextPackage package);
    Task<DataProcessResult<bool>> StoreResultsAsync(
        string traceId, string stepId, string stepType,
        object results, string? technology = null,
        CancellationToken ct = default);
    int EstimateTokens(string text);
}
```

### Service Implementation

```csharp
// File: XIIGen.Services.Context/Services/AiContextService.cs
namespace XIIGen.Services.Context.Services;

using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;
using XIIGen.Rag.Interfaces;
using XIIGen.Services.Context.Interfaces;
using XIIGen.Services.Context.Models;

public class AiContextService : IAiContextService
{
    private readonly IDatabaseService _db;
    private readonly IRagService _rag;
    private readonly IRagPlannerService _ragPlanner;
    private readonly ILogger<AiContextService> _logger;
    private readonly ContextConfig _config;

    private const string FeedbackIndex = "xiigen-feedback";
    private const string HistoryIndex = "xiigen-debug";

    private static readonly Dictionary<string, int> DefaultPriorities = new()
    {
        ["feedback"] = 90, ["rag"] = 80, ["custom"] = 70,
        ["history"] = 60, ["patterns"] = 50
    };

    public AiContextService(IDatabaseService db, IRagService rag,
        IRagPlannerService ragPlanner, ILogger<AiContextService> logger,
        IOptions<ContextConfig>? config = null)
    {
        _db = db; _rag = rag; _ragPlanner = ragPlanner;
        _logger = logger; _config = config?.Value ?? new ContextConfig();
    }

    public async Task<DataProcessResult<ContextPackage>> BuildContextAsync(
        ContextRequest request, CancellationToken ct = default)
    {
        try
        {
            var sections = new List<ContextSection>();
            var prio = _config.SourcePriorities ?? DefaultPriorities;

            // 1. RAG Results via AI-planned queries
            if (request.IncludeRagResults && !string.IsNullOrEmpty(request.TaskDescription))
            {
                var ragSections = await FetchRagContextAsync(request, prio.GetValueOrDefault("rag", 80), ct);
                sections.AddRange(ragSections);
            }

            // 2. Feedback History
            if (request.IncludeFeedback)
            {
                var fb = await FetchFeedbackAsync(request, prio.GetValueOrDefault("feedback", 90), ct);
                if (fb != null) sections.Add(fb);
            }

            // 3. Previous Step Outputs
            if (request.IncludeStepHistory)
            {
                var hist = await FetchStepHistoryAsync(request, prio.GetValueOrDefault("history", 60), ct);
                if (hist != null) sections.Add(hist);
            }

            // 4. Design Pattern Hints
            if (request.IncludeDesignPatterns)
            {
                var pat = FetchDesignPatterns(request, prio.GetValueOrDefault("patterns", 50));
                if (pat != null) sections.Add(pat);
            }

            // 5. Custom Injections
            if (request.CustomInjections?.Count > 0)
                foreach (var (k, v) in request.CustomInjections)
                    sections.Add(new("custom", k, v, prio.GetValueOrDefault("custom", 70), EstimateTokens(v)));

            var budgeted = ApplyTokenBudget(sections, request.MaxTokenBudget);
            var package = new ContextPackage(request.TraceId, request.CurrentStepId,
                budgeted, budgeted.Sum(s => s.EstimatedTokens));

            _logger.LogInformation("Context: {TraceId}/{StepId} → {Count} sections, ~{Tokens} tokens",
                request.TraceId, request.CurrentStepId, budgeted.Count, package.EstimatedTokens);
            return DataProcessResult<ContextPackage>.Success(package);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "BuildContext failed: {TraceId}/{StepId}", request.TraceId, request.CurrentStepId);
            return DataProcessResult<ContextPackage>.Error(ex.Message);
        }
    }

    public string FormatForPrompt(ContextPackage package)
    {
        var sb = new StringBuilder();
        sb.AppendLine("<xiigen-context>");
        sb.AppendLine($"  <trace id=\"{package.TraceId}\" step=\"{package.CurrentStepId}\">");
        foreach (var s in package.Sections.OrderByDescending(s => s.Priority))
        {
            sb.AppendLine($"  <context-section source=\"{s.Source}\" priority=\"{s.Priority}\">");
            sb.AppendLine($"    <title>{s.Title}</title>");
            sb.AppendLine($"    <content>{s.Content}</content>");
            sb.AppendLine("  </context-section>");
        }
        sb.AppendLine("  </trace>");
        sb.AppendLine("</xiigen-context>");
        return sb.ToString();
    }

    public async Task<DataProcessResult<bool>> StoreResultsAsync(
        string traceId, string stepId, string stepType,
        object results, string? technology = null, CancellationToken ct = default)
    {
        try
        {
            var json = JsonSerializer.Serialize(results);
            var storagePlan = await _ragPlanner.PlanStorageAsync(new StoragePlanRequest(
                $"Completed {stepType}", stepType, technology,
                json[..Math.Min(500, json.Length)], traceId), ct);

            if (storagePlan.IsSuccess && storagePlan.Data?.Operations?.Count > 0)
            {
                foreach (var op in storagePlan.Data.Operations)
                    await _rag.IndexAsync(op.Collection, new {
                        id = $"{traceId}-{stepId}-{op.Collection}",
                        traceId, stepId, stepType, technology,
                        content = op.ContentExtractor == "summary" ? json[..Math.Min(300, json.Length)] : json,
                        metadata = op.Metadata, tags = op.Tags, createdAt = DateTime.UtcNow
                    }, ct);
            }
            else
            {
                await _rag.IndexAsync("xiigen-results", new {
                    id = $"{traceId}-{stepId}", traceId, stepId, stepType, technology,
                    content = json, createdAt = DateTime.UtcNow
                }, ct);
            }
            return DataProcessResult<bool>.Success(true);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "StoreResults failed: {TraceId}/{StepId}", traceId, stepId);
            return DataProcessResult<bool>.Error(ex.Message);
        }
    }

    public int EstimateTokens(string text) =>
        string.IsNullOrEmpty(text) ? 0 : (int)Math.Ceiling(text.Length / 4.0);

    private async Task<List<ContextSection>> FetchRagContextAsync(
        ContextRequest req, int prio, CancellationToken ct)
    {
        var sections = new List<ContextSection>();
        try
        {
            var plan = await _ragPlanner.PlanQueryAsync(new QueryPlanRequest(
                req.TaskDescription!, req.StepType, req.Technology, req.TraceId), ct);
            if (!plan.IsSuccess || plan.Data == null) return sections;

            foreach (var q in plan.Data.Queries.Take(_config.MaxRagResults))
            {
                var res = await _rag.SearchAsync(q.Collection, q.QueryText, maxResults: 3, ct: ct);
                if (res.IsSuccess && res.Data?.Count > 0)
                {
                    var content = string.Join("\n", res.Data.Select(r => r.ToString()));
                    sections.Add(new("rag", $"RAG: {q.QueryText[..Math.Min(50, q.QueryText.Length)]}",
                        content, prio, EstimateTokens(content)));
                }
            }
        }
        catch (Exception ex) { _logger.LogWarning(ex, "RAG fetch failed"); }
        return sections;
    }

    private async Task<ContextSection?> FetchFeedbackAsync(
        ContextRequest req, int prio, CancellationToken ct)
    {
        try
        {
            var result = await _db.SearchAsync(FeedbackIndex,
                new { stepType = req.StepType, technology = req.Technology ?? "" },
                _config.MaxFeedbackItems, ct);
            if (!result.IsSuccess || result.Data?.Count == 0) return null;

            var sb = new StringBuilder("<feedback-history>\n");
            foreach (var item in result.Data!)
            {
                var json = JsonSerializer.Serialize(item);
                using var doc = JsonDocument.Parse(json);
                var rating = doc.RootElement.TryGetProperty("rating", out var r) ? r.GetString() : "neutral";
                var text = doc.RootElement.TryGetProperty("text", out var t) ? t.GetString() : "";
                if (!string.IsNullOrEmpty(text))
                    sb.AppendLine($"  <feedback rating=\"{rating}\">{text}</feedback>");
            }
            sb.AppendLine("</feedback-history>");
            var content = sb.ToString();
            return new("feedback", "User Feedback History", content, prio, EstimateTokens(content));
        }
        catch { return null; }
    }

    private async Task<ContextSection?> FetchStepHistoryAsync(
        ContextRequest req, int prio, CancellationToken ct)
    {
        try
        {
            var result = await _db.SearchAsync(HistoryIndex,
                new { traceId = req.TraceId, status = "Completed" }, _config.MaxHistorySteps, ct);
            if (!result.IsSuccess || result.Data?.Count == 0) return null;

            var sb = new StringBuilder("<previous-steps>\n");
            foreach (var step in result.Data!)
            {
                var json = JsonSerializer.Serialize(step);
                sb.AppendLine($"  <step>{(json.Length > 300 ? json[..300] + "..." : json)}</step>");
            }
            sb.AppendLine("</previous-steps>");
            var content = sb.ToString();
            return new("history", "Previous Steps in Flow", content, prio, EstimateTokens(content));
        }
        catch { return null; }
    }

    private ContextSection? FetchDesignPatterns(ContextRequest req, int prio)
    {
        var hints = req.StepType?.ToLowerInvariant() switch
        {
            "figma-parse" => new[] { "Strategy", "Adapter", "Visitor" },
            "ai-transform" => new[] { "Strategy", "Template Method", "Chain of Responsibility" },
            "ai-review" => new[] { "Observer", "Strategy", "Decorator" },
            "code-generate" => new[] { "Factory", "Builder", "Template Method" },
            "auth" => new[] { "Proxy", "Chain of Responsibility", "Singleton" },
            _ => new[] { "Strategy", "Factory" }
        };
        var sb = new StringBuilder("<design-pattern-hints>\n");
        foreach (var p in hints.Take(_config.MaxDesignPatterns))
            sb.AppendLine($"  <pattern name=\"{p}\">Consider {p} for this step type.</pattern>");
        sb.AppendLine("</design-pattern-hints>");
        var content = sb.ToString();
        return new("patterns", "Recommended Design Patterns", content, prio, EstimateTokens(content));
    }

    private static List<ContextSection> ApplyTokenBudget(List<ContextSection> sections, int maxTokens)
    {
        var result = new List<ContextSection>();
        var remaining = maxTokens;
        foreach (var s in sections.OrderByDescending(s => s.Priority))
        {
            if (remaining <= 0) break;
            if (s.EstimatedTokens <= remaining)
            { result.Add(s); remaining -= s.EstimatedTokens; }
            else if (remaining > 100)
            {
                result.Add(s with {
                    Content = s.Content[..Math.Min(s.Content.Length, remaining * 4)] + "\n[truncated]",
                    EstimatedTokens = remaining
                });
                remaining = 0;
            }
        }
        return result;
    }
}
```

### DI Registration

```csharp
// File: XIIGen.Services.Context/Extensions/ContextExtensions.cs
public static class ContextExtensions
{
    public static IServiceCollection AddXIIGenContext(
        this IServiceCollection services, Action<ContextConfig>? configure = null)
    {
        var config = new ContextConfig();
        configure?.Invoke(config);
        services.AddSingleton(Options.Create(config));
        services.AddSingleton<IAiContextService, AiContextService>();
        return services;
    }
}
```

### API Endpoints

```csharp
app.MapGroup("/api/context")
    .MapPost("/build", async (ContextRequest req, IAiContextService svc, CancellationToken ct) =>
        Results.Ok(await svc.BuildContextAsync(req, ct)))
    .MapPost("/store", async (StoreResultRequest req, IAiContextService svc, CancellationToken ct) =>
        Results.Ok(await svc.StoreResultsAsync(req.TraceId, req.StepId, req.StepType, req.Results, req.Technology, ct)));
```

---

## Tests

```csharp
public class AiContextServiceTests
{
    private readonly Mock<IDatabaseService> _mockDb = new();
    private readonly Mock<IRagService> _mockRag = new();
    private readonly Mock<IRagPlannerService> _mockPlanner = new();
    private readonly AiContextService _svc;

    public AiContextServiceTests()
    {
        _svc = new AiContextService(_mockDb.Object, _mockRag.Object, _mockPlanner.Object,
            Mock.Of<ILogger<AiContextService>>());
    }

    [Fact]
    public async Task BuildContext_WithFeedback_IncludesFeedbackSection()
    {
        var req = new ContextRequest("t1", "s1", "ai-transform",
            IncludeRagResults: false, IncludeDesignPatterns: false, IncludeStepHistory: false);
        _mockDb.Setup(d => d.SearchAsync("xiigen-feedback", It.IsAny<object>(), 10, It.IsAny<CancellationToken>()))
            .ReturnsAsync(DataProcessResult<List<object>>.Success(new List<object>
                { new { rating = "positive", text = "Good structure" } }));

        var result = await _svc.BuildContextAsync(req);
        Assert.True(result.IsSuccess);
        Assert.Contains(result.Data!.Sections, s => s.Source == "feedback");
    }

    [Fact]
    public async Task BuildContext_TightBudget_TruncatesLowPriority()
    {
        var req = new ContextRequest("t1", "s1", "ai-transform", MaxTokenBudget: 50,
            IncludeRagResults: false);
        _mockDb.Setup(d => d.SearchAsync(It.IsAny<string>(), It.IsAny<object>(), It.IsAny<int>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(DataProcessResult<List<object>>.Success(
                new List<object> { new { rating = "positive", text = new string('x', 1000) } }));
        var result = await _svc.BuildContextAsync(req);
        Assert.True(result.Data!.EstimatedTokens <= 50);
    }

    [Fact]
    public void FormatForPrompt_ProducesValidXml()
    {
        var pkg = new ContextPackage("t1", "s1", new List<ContextSection>
            { new("feedback", "FB", "Great!", 90, 5), new("rag", "R", "code", 80, 5) }, 10);
        var xml = _svc.FormatForPrompt(pkg);
        Assert.Contains("<xiigen-context>", xml);
        Assert.Contains("</xiigen-context>", xml);
    }

    [Fact]
    public void EstimateTokens_ReturnsCorrectEstimate()
    {
        Assert.Equal(25, _svc.EstimateTokens(new string('a', 100)));
        Assert.Equal(0, _svc.EstimateTokens(""));
    }
}
```

---

## Alternatives

| Language | File | Framework | Key Differences |
|----------|------|-----------|-----------------|
| Node.js | `alternatives/nodejs/ai-context-service.ts` | Fastify + TypeScript | tiktoken for accurate counts |
| Python | `alternatives/python/ai_context_service.py` | FastAPI + Pydantic | async generators for streaming |
| Java | `alternatives/java/AiContextService.java` | Spring Boot 3 | @Cacheable plan caching |
| Rust | `alternatives/rust/ai_context_service.rs` | Axum + Serde | Zero-copy context assembly |
| PHP | `alternatives/php/AiContextService.php` | Laravel 11 | Collection pipelines |
