# XIIGen Skill 16 — AI Context Service (Python/FastAPI)
from __future__ import annotations
import json
import math
from datetime import datetime, UTC
from typing import Optional
from dataclasses import dataclass, field
from fastapi import APIRouter, Depends
from pydantic import BaseModel

# --- Models ---
class ContextRequest(BaseModel):
    trace_id: str
    current_step_id: str
    step_type: str
    technology: Optional[str] = None
    task_description: Optional[str] = None
    max_token_budget: int = 4000
    custom_injections: Optional[dict[str, str]] = None
    include_design_patterns: bool = True
    include_feedback: bool = True
    include_rag_results: bool = True
    include_step_history: bool = True

@dataclass
class ContextSection:
    source: str  # rag, feedback, history, patterns, custom
    title: str
    content: str
    priority: int
    estimated_tokens: int

@dataclass
class ContextPackage:
    trace_id: str
    current_step_id: str
    sections: list[ContextSection]
    estimated_tokens: int
    assembled_at: datetime = field(default_factory=lambda: datetime.now(UTC))

DEFAULT_PRIORITIES = {"feedback": 90, "rag": 80, "custom": 70, "history": 60, "patterns": 50}

PATTERN_MAP = {
    "figma-parse": ["Strategy", "Adapter", "Visitor"],
    "ai-transform": ["Strategy", "Template Method", "Chain of Responsibility"],
    "ai-review": ["Observer", "Strategy", "Decorator"],
    "code-generate": ["Factory", "Builder", "Template Method"],
    "auth": ["Proxy", "Chain of Responsibility", "Singleton"],
}

# --- Service ---
class AiContextService:
    def __init__(self, db, rag, rag_planner, logger,
                 max_rag=5, max_feedback=10, max_history=5, max_patterns=3):
        self.db = db
        self.rag = rag
        self.rag_planner = rag_planner
        self.logger = logger
        self.max_rag = max_rag
        self.max_feedback = max_feedback
        self.max_history = max_history
        self.max_patterns = max_patterns

    @staticmethod
    def estimate_tokens(text: str) -> int:
        return math.ceil(len(text) / 4) if text else 0

    async def build_context(self, request: ContextRequest) -> ContextPackage:
        sections: list[ContextSection] = []

        # 1. RAG Results
        if request.include_rag_results and request.task_description:
            sections.extend(await self._fetch_rag(request))

        # 2. Feedback
        if request.include_feedback:
            fb = await self._fetch_feedback(request)
            if fb: sections.append(fb)

        # 3. Step History
        if request.include_step_history:
            hist = await self._fetch_history(request)
            if hist: sections.append(hist)

        # 4. Design Patterns
        if request.include_design_patterns:
            pat = self._fetch_patterns(request)
            if pat: sections.append(pat)

        # 5. Custom Injections
        if request.custom_injections:
            for key, value in request.custom_injections.items():
                sections.append(ContextSection(
                    "custom", key, value, DEFAULT_PRIORITIES["custom"],
                    self.estimate_tokens(value)))

        budgeted = self._apply_token_budget(sections, request.max_token_budget)
        return ContextPackage(
            trace_id=request.trace_id,
            current_step_id=request.current_step_id,
            sections=budgeted,
            estimated_tokens=sum(s.estimated_tokens for s in budgeted)
        )

    def format_for_prompt(self, pkg: ContextPackage) -> str:
        lines = ['<xiigen-context>',
                 f'  <trace id="{pkg.trace_id}" step="{pkg.current_step_id}">']
        for s in sorted(pkg.sections, key=lambda x: -x.priority):
            lines.append(f'  <context-section source="{s.source}" priority="{s.priority}">')
            lines.append(f'    <title>{s.title}</title>')
            lines.append(f'    <content>{s.content}</content>')
            lines.append('  </context-section>')
        lines.extend(['  </trace>', '</xiigen-context>'])
        return '\n'.join(lines)

    async def store_results(self, trace_id: str, step_id: str, step_type: str,
                            results: dict, technology: str | None = None) -> bool:
        try:
            js = json.dumps(results)
            plan = await self.rag_planner.plan_storage(
                task_description=f"Completed {step_type}", step_type=step_type,
                technology=technology, result_summary=js[:500], trace_id=trace_id)

            if plan and plan.operations:
                for op in plan.operations:
                    await self.rag.index(op.collection, {
                        "id": f"{trace_id}-{step_id}-{op.collection}",
                        "traceId": trace_id, "stepId": step_id,
                        "content": js[:300] if op.content_extractor == "summary" else js,
                        "metadata": op.metadata, "tags": op.tags,
                        "createdAt": datetime.now(UTC).isoformat()
                    })
            else:
                await self.rag.index("xiigen-results", {
                    "id": f"{trace_id}-{step_id}", "traceId": trace_id,
                    "stepId": step_id, "content": js,
                    "createdAt": datetime.now(UTC).isoformat()
                })
            return True
        except Exception as e:
            self.logger.error(f"StoreResults failed: {e}")
            return False

    # --- Private ---
    async def _fetch_rag(self, req: ContextRequest) -> list[ContextSection]:
        try:
            plan = await self.rag_planner.plan_query(
                task_description=req.task_description,
                step_type=req.step_type, technology=req.technology,
                trace_id=req.trace_id)
            if not plan or not plan.queries: return []

            sections = []
            for q in plan.queries[:self.max_rag]:
                results = await self.rag.search(q.collection, q.query_text, max_results=3)
                if results:
                    content = "\n".join(json.dumps(r) for r in results)
                    sections.append(ContextSection(
                        "rag", f"RAG: {q.query_text[:50]}", content,
                        DEFAULT_PRIORITIES["rag"], self.estimate_tokens(content)))
            return sections
        except: return []

    async def _fetch_feedback(self, req: ContextRequest) -> ContextSection | None:
        try:
            items = await self.db.search("xiigen-feedback",
                {"stepType": req.step_type, "technology": req.technology or ""},
                self.max_feedback)
            if not items: return None
            lines = ["<feedback-history>"]
            for item in items:
                if item.get("text"):
                    lines.append(f'  <feedback rating="{item.get("rating", "neutral")}">{item["text"]}</feedback>')
            lines.append("</feedback-history>")
            content = "\n".join(lines)
            return ContextSection("feedback", "User Feedback", content,
                                  DEFAULT_PRIORITIES["feedback"], self.estimate_tokens(content))
        except: return None

    async def _fetch_history(self, req: ContextRequest) -> ContextSection | None:
        try:
            steps = await self.db.search("xiigen-debug",
                {"traceId": req.trace_id, "status": "Completed"}, self.max_history)
            if not steps: return None
            lines = ["<previous-steps>"]
            for s in steps:
                js = json.dumps(s)
                lines.append(f"  <step>{js[:300]}{'...' if len(js)>300 else ''}</step>")
            lines.append("</previous-steps>")
            content = "\n".join(lines)
            return ContextSection("history", "Previous Steps", content,
                                  DEFAULT_PRIORITIES["history"], self.estimate_tokens(content))
        except: return None

    def _fetch_patterns(self, req: ContextRequest) -> ContextSection | None:
        hints = PATTERN_MAP.get(req.step_type.lower(), ["Strategy", "Factory"])
        lines = ["<design-pattern-hints>"]
        for p in hints[:self.max_patterns]:
            lines.append(f'  <pattern name="{p}">Consider {p} for this step type.</pattern>')
        lines.append("</design-pattern-hints>")
        content = "\n".join(lines)
        return ContextSection("patterns", "Recommended Patterns", content,
                              DEFAULT_PRIORITIES["patterns"], self.estimate_tokens(content))

    @staticmethod
    def _apply_token_budget(sections: list[ContextSection], max_tokens: int) -> list[ContextSection]:
        result, remaining = [], max_tokens
        for s in sorted(sections, key=lambda x: -x.priority):
            if remaining <= 0: break
            if s.estimated_tokens <= remaining:
                result.append(s); remaining -= s.estimated_tokens
            elif remaining > 100:
                result.append(ContextSection(
                    s.source, s.title, s.content[:remaining*4] + "\n[truncated]",
                    s.priority, remaining))
                remaining = 0
        return result


# --- FastAPI Router ---
router = APIRouter(prefix="/api/context")

@router.post("/build")
async def build_context(req: ContextRequest, svc: AiContextService = Depends()):
    return await svc.build_context(req)

@router.post("/store")
async def store_results(data: dict, svc: AiContextService = Depends()):
    return await svc.store_results(
        data["traceId"], data["stepId"], data["stepType"],
        data["results"], data.get("technology"))
