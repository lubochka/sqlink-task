// XIIGen Skill 16 — AI Context Service (Node.js/Fastify)
import Fastify, { FastifyInstance } from 'fastify';

// --- Models ---
interface ContextRequest {
  traceId: string;
  currentStepId: string;
  stepType: string;
  technology?: string;
  taskDescription?: string;
  maxTokenBudget?: number;
  customInjections?: Record<string, string>;
  includeDesignPatterns?: boolean;
  includeFeedback?: boolean;
  includeRagResults?: boolean;
  includeStepHistory?: boolean;
}

interface ContextSection {
  source: 'rag' | 'feedback' | 'history' | 'patterns' | 'custom';
  title: string;
  content: string;
  priority: number;
  estimatedTokens: number;
}

interface ContextPackage {
  traceId: string;
  currentStepId: string;
  sections: ContextSection[];
  estimatedTokens: number;
  assembledAt: Date;
}

// --- Service ---
const DEFAULT_PRIORITIES: Record<string, number> = {
  feedback: 90, rag: 80, custom: 70, history: 60, patterns: 50
};

const PATTERN_MAP: Record<string, string[]> = {
  'figma-parse': ['Strategy', 'Adapter', 'Visitor'],
  'ai-transform': ['Strategy', 'Template Method', 'Chain of Responsibility'],
  'ai-review': ['Observer', 'Strategy', 'Decorator'],
  'code-generate': ['Factory', 'Builder', 'Template Method'],
  'auth': ['Proxy', 'Chain of Responsibility', 'Singleton'],
};

class AiContextService {
  constructor(
    private db: any, // IDatabaseService
    private rag: any, // IRagService
    private ragPlanner: any, // IRagPlannerService
    private logger: any,
    private config = {
      maxRagResults: 5, maxFeedbackItems: 10,
      maxHistorySteps: 5, maxDesignPatterns: 3
    }
  ) {}

  estimateTokens(text: string): number {
    return text ? Math.ceil(text.length / 4) : 0;
  }

  async buildContext(request: ContextRequest): Promise<ContextPackage> {
    const sections: ContextSection[] = [];
    const budget = request.maxTokenBudget ?? 4000;

    // 1. RAG Results
    if (request.includeRagResults !== false && request.taskDescription) {
      const ragSections = await this.fetchRagContext(request);
      sections.push(...ragSections);
    }

    // 2. Feedback
    if (request.includeFeedback !== false) {
      const fb = await this.fetchFeedback(request);
      if (fb) sections.push(fb);
    }

    // 3. Step History
    if (request.includeStepHistory !== false) {
      const hist = await this.fetchStepHistory(request);
      if (hist) sections.push(hist);
    }

    // 4. Design Patterns
    if (request.includeDesignPatterns !== false) {
      const pat = this.fetchDesignPatterns(request);
      if (pat) sections.push(pat);
    }

    // 5. Custom Injections
    if (request.customInjections) {
      for (const [key, value] of Object.entries(request.customInjections)) {
        sections.push({
          source: 'custom', title: key, content: value,
          priority: DEFAULT_PRIORITIES.custom, estimatedTokens: this.estimateTokens(value)
        });
      }
    }

    const budgeted = this.applyTokenBudget(sections, budget);
    return {
      traceId: request.traceId,
      currentStepId: request.currentStepId,
      sections: budgeted,
      estimatedTokens: budgeted.reduce((sum, s) => sum + s.estimatedTokens, 0),
      assembledAt: new Date()
    };
  }

  formatForPrompt(pkg: ContextPackage): string {
    const sorted = [...pkg.sections].sort((a, b) => b.priority - a.priority);
    let xml = '<xiigen-context>\n';
    xml += `  <trace id="${pkg.traceId}" step="${pkg.currentStepId}">\n`;
    for (const s of sorted) {
      xml += `  <context-section source="${s.source}" priority="${s.priority}">\n`;
      xml += `    <title>${s.title}</title>\n`;
      xml += `    <content>${s.content}</content>\n`;
      xml += `  </context-section>\n`;
    }
    xml += '  </trace>\n</xiigen-context>';
    return xml;
  }

  async storeResults(
    traceId: string, stepId: string, stepType: string,
    results: any, technology?: string
  ): Promise<boolean> {
    const json = JSON.stringify(results);
    try {
      const plan = await this.ragPlanner.planStorage({
        taskDescription: `Completed ${stepType}`, stepType, technology,
        resultSummary: json.slice(0, 500), traceId
      });

      if (plan?.operations?.length > 0) {
        for (const op of plan.operations) {
          await this.rag.index(op.collection, {
            id: `${traceId}-${stepId}-${op.collection}`,
            traceId, stepId, stepType, technology,
            content: op.contentExtractor === 'summary' ? json.slice(0, 300) : json,
            metadata: op.metadata, tags: op.tags, createdAt: new Date()
          });
        }
      } else {
        await this.rag.index('xiigen-results', {
          id: `${traceId}-${stepId}`, traceId, stepId, stepType, technology,
          content: json, createdAt: new Date()
        });
      }
      return true;
    } catch (err) {
      this.logger.error({ err, traceId, stepId }, 'StoreResults failed');
      return false;
    }
  }

  // --- Private ---

  private async fetchRagContext(req: ContextRequest): Promise<ContextSection[]> {
    try {
      const plan = await this.ragPlanner.planQuery({
        taskDescription: req.taskDescription!, stepType: req.stepType,
        technology: req.technology, traceId: req.traceId
      });
      if (!plan?.queries?.length) return [];

      const sections: ContextSection[] = [];
      for (const q of plan.queries.slice(0, this.config.maxRagResults)) {
        const results = await this.rag.search(q.collection, q.queryText, 3);
        if (results?.length > 0) {
          const content = results.map((r: any) => JSON.stringify(r)).join('\n');
          sections.push({
            source: 'rag', title: `RAG: ${q.queryText.slice(0, 50)}`,
            content, priority: DEFAULT_PRIORITIES.rag, estimatedTokens: this.estimateTokens(content)
          });
        }
      }
      return sections;
    } catch { return []; }
  }

  private async fetchFeedback(req: ContextRequest): Promise<ContextSection | null> {
    try {
      const items = await this.db.search('xiigen-feedback',
        { stepType: req.stepType, technology: req.technology ?? '' },
        this.config.maxFeedbackItems);
      if (!items?.length) return null;

      let content = '<feedback-history>\n';
      for (const item of items) {
        if (item.text) content += `  <feedback rating="${item.rating ?? 'neutral'}">${item.text}</feedback>\n`;
      }
      content += '</feedback-history>';
      return { source: 'feedback', title: 'User Feedback History', content,
        priority: DEFAULT_PRIORITIES.feedback, estimatedTokens: this.estimateTokens(content) };
    } catch { return null; }
  }

  private async fetchStepHistory(req: ContextRequest): Promise<ContextSection | null> {
    try {
      const steps = await this.db.search('xiigen-debug',
        { traceId: req.traceId, status: 'Completed' }, this.config.maxHistorySteps);
      if (!steps?.length) return null;

      let content = '<previous-steps>\n';
      for (const s of steps) {
        const json = JSON.stringify(s);
        content += `  <step>${json.length > 300 ? json.slice(0, 300) + '...' : json}</step>\n`;
      }
      content += '</previous-steps>';
      return { source: 'history', title: 'Previous Steps', content,
        priority: DEFAULT_PRIORITIES.history, estimatedTokens: this.estimateTokens(content) };
    } catch { return null; }
  }

  private fetchDesignPatterns(req: ContextRequest): ContextSection | null {
    const hints = PATTERN_MAP[req.stepType?.toLowerCase()] ?? ['Strategy', 'Factory'];
    let content = '<design-pattern-hints>\n';
    for (const p of hints.slice(0, this.config.maxDesignPatterns))
      content += `  <pattern name="${p}">Consider ${p} for this step type.</pattern>\n`;
    content += '</design-pattern-hints>';
    return { source: 'patterns', title: 'Recommended Patterns', content,
      priority: DEFAULT_PRIORITIES.patterns, estimatedTokens: this.estimateTokens(content) };
  }

  private applyTokenBudget(sections: ContextSection[], maxTokens: number): ContextSection[] {
    const sorted = [...sections].sort((a, b) => b.priority - a.priority);
    const result: ContextSection[] = [];
    let remaining = maxTokens;
    for (const s of sorted) {
      if (remaining <= 0) break;
      if (s.estimatedTokens <= remaining) {
        result.push(s); remaining -= s.estimatedTokens;
      } else if (remaining > 100) {
        result.push({ ...s, content: s.content.slice(0, remaining * 4) + '\n[truncated]',
          estimatedTokens: remaining });
        remaining = 0;
      }
    }
    return result;
  }
}

// --- Fastify Plugin ---
export default async function contextPlugin(app: FastifyInstance) {
  const svc = new AiContextService(app.db, app.rag, app.ragPlanner, app.log);

  app.post('/api/context/build', async (req) => {
    return svc.buildContext(req.body as ContextRequest);
  });

  app.post('/api/context/store', async (req) => {
    const { traceId, stepId, stepType, results, technology } = req.body as any;
    return svc.storeResults(traceId, stepId, stepType, results, technology);
  });
}
