// XIIGen Skill 16 — AI Context Service (Java/Spring Boot 3)
package com.xiigen.context;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

// --- Models ---
record ContextRequest(
    String traceId, String currentStepId, String stepType,
    String technology, String taskDescription,
    int maxTokenBudget, Map<String, String> customInjections,
    boolean includeDesignPatterns, boolean includeFeedback,
    boolean includeRagResults, boolean includeStepHistory
) {
    ContextRequest {
        if (maxTokenBudget <= 0) maxTokenBudget = 4000;
        if (customInjections == null) customInjections = Map.of();
    }
}

record ContextSection(String source, String title, String content, int priority, int estimatedTokens) {}

record ContextPackage(
    String traceId, String currentStepId,
    List<ContextSection> sections, int estimatedTokens, Instant assembledAt
) {}

// --- Service ---
@Service
public class AiContextService {
    private static final Logger log = LoggerFactory.getLogger(AiContextService.class);
    private static final Map<String, Integer> DEFAULT_PRIORITIES = Map.of(
        "feedback", 90, "rag", 80, "custom", 70, "history", 60, "patterns", 50
    );
    private static final Map<String, List<String>> PATTERN_MAP = Map.of(
        "figma-parse", List.of("Strategy", "Adapter", "Visitor"),
        "ai-transform", List.of("Strategy", "Template Method", "Chain of Responsibility"),
        "ai-review", List.of("Observer", "Strategy", "Decorator"),
        "code-generate", List.of("Factory", "Builder", "Template Method"),
        "auth", List.of("Proxy", "Chain of Responsibility", "Singleton")
    );

    private final DatabaseService db;
    private final RagService rag;
    private final RagPlannerService ragPlanner;
    private final ObjectMapper mapper = new ObjectMapper();

    public AiContextService(DatabaseService db, RagService rag, RagPlannerService ragPlanner) {
        this.db = db; this.rag = rag; this.ragPlanner = ragPlanner;
    }

    public int estimateTokens(String text) {
        return text == null || text.isEmpty() ? 0 : (int) Math.ceil(text.length() / 4.0);
    }

    public ContextPackage buildContext(ContextRequest request) throws Exception {
        var sections = new ArrayList<ContextSection>();

        if (request.includeRagResults() && request.taskDescription() != null)
            sections.addAll(fetchRagContext(request));

        if (request.includeFeedback()) {
            var fb = fetchFeedback(request);
            if (fb != null) sections.add(fb);
        }

        if (request.includeStepHistory()) {
            var hist = fetchStepHistory(request);
            if (hist != null) sections.add(hist);
        }

        if (request.includeDesignPatterns()) {
            var pat = fetchDesignPatterns(request);
            if (pat != null) sections.add(pat);
        }

        for (var entry : request.customInjections().entrySet()) {
            sections.add(new ContextSection("custom", entry.getKey(), entry.getValue(),
                DEFAULT_PRIORITIES.getOrDefault("custom", 70), estimateTokens(entry.getValue())));
        }

        var budgeted = applyTokenBudget(sections, request.maxTokenBudget());
        int totalTokens = budgeted.stream().mapToInt(ContextSection::estimatedTokens).sum();

        log.info("Context: {}/{} → {} sections, ~{} tokens",
            request.traceId(), request.currentStepId(), budgeted.size(), totalTokens);

        return new ContextPackage(request.traceId(), request.currentStepId(),
            budgeted, totalTokens, Instant.now());
    }

    public String formatForPrompt(ContextPackage pkg) {
        var sb = new StringBuilder();
        sb.append("<xiigen-context>\n");
        sb.append("  <trace id=\"").append(pkg.traceId())
          .append("\" step=\"").append(pkg.currentStepId()).append("\">\n");

        pkg.sections().stream()
            .sorted(Comparator.comparingInt(ContextSection::priority).reversed())
            .forEach(s -> {
                sb.append("  <context-section source=\"").append(s.source())
                  .append("\" priority=\"").append(s.priority()).append("\">\n");
                sb.append("    <title>").append(s.title()).append("</title>\n");
                sb.append("    <content>").append(s.content()).append("</content>\n");
                sb.append("  </context-section>\n");
            });

        sb.append("  </trace>\n</xiigen-context>");
        return sb.toString();
    }

    public boolean storeResults(String traceId, String stepId, String stepType,
                                Object results, String technology) {
        try {
            String json = mapper.writeValueAsString(results);
            var plan = ragPlanner.planStorage(stepType, technology, json.substring(0, Math.min(500, json.length())), traceId);

            if (plan != null && !plan.operations().isEmpty()) {
                for (var op : plan.operations()) {
                    rag.index(op.collection(), Map.of(
                        "id", traceId + "-" + stepId + "-" + op.collection(),
                        "traceId", traceId, "stepId", stepId,
                        "content", "summary".equals(op.contentExtractor()) ? json.substring(0, Math.min(300, json.length())) : json,
                        "createdAt", Instant.now().toString()
                    ));
                }
            } else {
                rag.index("xiigen-results", Map.of(
                    "id", traceId + "-" + stepId, "traceId", traceId,
                    "content", json, "createdAt", Instant.now().toString()
                ));
            }
            return true;
        } catch (Exception e) {
            log.error("StoreResults failed: {}/{}", traceId, stepId, e);
            return false;
        }
    }

    // --- Private ---
    private List<ContextSection> fetchRagContext(ContextRequest req) {
        try {
            var plan = ragPlanner.planQuery(req.taskDescription(), req.stepType(), req.technology(), req.traceId());
            if (plan == null || plan.queries().isEmpty()) return List.of();

            return plan.queries().stream().limit(5)
                .map(q -> {
                    var results = rag.search(q.collection(), q.queryText(), 3);
                    if (results == null || results.isEmpty()) return null;
                    String content = results.stream().map(Object::toString).collect(Collectors.joining("\n"));
                    return new ContextSection("rag", "RAG: " + q.queryText().substring(0, Math.min(50, q.queryText().length())),
                        content, DEFAULT_PRIORITIES.get("rag"), estimateTokens(content));
                })
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
        } catch (Exception e) { return List.of(); }
    }

    private ContextSection fetchFeedback(ContextRequest req) {
        try {
            var items = db.search("xiigen-feedback",
                Map.of("stepType", req.stepType(), "technology", Objects.toString(req.technology(), "")), 10);
            if (items == null || items.isEmpty()) return null;

            var sb = new StringBuilder("<feedback-history>\n");
            for (var item : items) {
                var map = mapper.convertValue(item, Map.class);
                if (map.get("text") != null)
                    sb.append("  <feedback rating=\"").append(map.getOrDefault("rating", "neutral"))
                      .append("\">").append(map.get("text")).append("</feedback>\n");
            }
            sb.append("</feedback-history>");
            String content = sb.toString();
            return new ContextSection("feedback", "User Feedback", content,
                DEFAULT_PRIORITIES.get("feedback"), estimateTokens(content));
        } catch (Exception e) { return null; }
    }

    private ContextSection fetchStepHistory(ContextRequest req) {
        try {
            var steps = db.search("xiigen-debug", Map.of("traceId", req.traceId(), "status", "Completed"), 5);
            if (steps == null || steps.isEmpty()) return null;

            var sb = new StringBuilder("<previous-steps>\n");
            for (var s : steps) {
                String json = mapper.writeValueAsString(s);
                sb.append("  <step>").append(json.length() > 300 ? json.substring(0, 300) + "..." : json).append("</step>\n");
            }
            sb.append("</previous-steps>");
            String content = sb.toString();
            return new ContextSection("history", "Previous Steps", content,
                DEFAULT_PRIORITIES.get("history"), estimateTokens(content));
        } catch (Exception e) { return null; }
    }

    @Cacheable(value = "design-patterns", key = "#req.stepType()")
    private ContextSection fetchDesignPatterns(ContextRequest req) {
        var hints = PATTERN_MAP.getOrDefault(req.stepType().toLowerCase(), List.of("Strategy", "Factory"));
        var sb = new StringBuilder("<design-pattern-hints>\n");
        hints.stream().limit(3).forEach(p ->
            sb.append("  <pattern name=\"").append(p).append("\">Consider ").append(p).append(".</pattern>\n"));
        sb.append("</design-pattern-hints>");
        String content = sb.toString();
        return new ContextSection("patterns", "Design Patterns", content,
            DEFAULT_PRIORITIES.get("patterns"), estimateTokens(content));
    }

    private List<ContextSection> applyTokenBudget(List<ContextSection> sections, int maxTokens) {
        var sorted = sections.stream().sorted(Comparator.comparingInt(ContextSection::priority).reversed()).toList();
        var result = new ArrayList<ContextSection>();
        int remaining = maxTokens;
        for (var s : sorted) {
            if (remaining <= 0) break;
            if (s.estimatedTokens() <= remaining) {
                result.add(s); remaining -= s.estimatedTokens();
            } else if (remaining > 100) {
                result.add(new ContextSection(s.source(), s.title(),
                    s.content().substring(0, Math.min(s.content().length(), remaining * 4)) + "\n[truncated]",
                    s.priority(), remaining));
                remaining = 0;
            }
        }
        return result;
    }
}

// --- Controller ---
@RestController
@RequestMapping("/api/context")
class ContextController {
    private final AiContextService svc;
    ContextController(AiContextService svc) { this.svc = svc; }

    @PostMapping("/build")
    public ContextPackage build(@RequestBody ContextRequest req) throws Exception {
        return svc.buildContext(req);
    }

    @PostMapping("/store")
    public boolean store(@RequestBody Map<String, Object> body) {
        return svc.storeResults(
            (String) body.get("traceId"), (String) body.get("stepId"),
            (String) body.get("stepType"), body.get("results"),
            (String) body.get("technology"));
    }
}
