<?php
// XIIGen Skill 16 — AI Context Service (PHP/Laravel 11)
namespace App\Services;

use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;

// --- Models ---
class ContextRequest
{
    public function __construct(
        public string $traceId,
        public string $currentStepId,
        public string $stepType,
        public ?string $technology = null,
        public ?string $taskDescription = null,
        public int $maxTokenBudget = 4000,
        public array $customInjections = [],
        public bool $includeDesignPatterns = true,
        public bool $includeFeedback = true,
        public bool $includeRagResults = true,
        public bool $includeStepHistory = true,
    ) {}
}

class ContextSection
{
    public function __construct(
        public string $source,
        public string $title,
        public string $content,
        public int $priority,
        public int $estimatedTokens,
    ) {}
}

class ContextPackage
{
    public function __construct(
        public string $traceId,
        public string $currentStepId,
        public array $sections,
        public int $estimatedTokens,
        public \DateTimeImmutable $assembledAt = new \DateTimeImmutable(),
    ) {}
}

// --- Service ---
class AiContextService
{
    private const DEFAULT_PRIORITIES = [
        'feedback' => 90, 'rag' => 80, 'custom' => 70, 'history' => 60, 'patterns' => 50
    ];

    private const PATTERN_MAP = [
        'figma-parse' => ['Strategy', 'Adapter', 'Visitor'],
        'ai-transform' => ['Strategy', 'Template Method', 'Chain of Responsibility'],
        'ai-review' => ['Observer', 'Strategy', 'Decorator'],
        'code-generate' => ['Factory', 'Builder', 'Template Method'],
        'auth' => ['Proxy', 'Chain of Responsibility', 'Singleton'],
    ];

    public function __construct(
        private DatabaseService $db,
        private RagService $rag,
        private RagPlannerService $ragPlanner,
        private int $maxRag = 5,
        private int $maxFeedback = 10,
        private int $maxHistory = 5,
        private int $maxPatterns = 3,
    ) {}

    public static function estimateTokens(string $text): int
    {
        return $text ? (int) ceil(strlen($text) / 4) : 0;
    }

    public function buildContext(ContextRequest $request): ContextPackage
    {
        $sections = [];

        // 1. RAG Results
        if ($request->includeRagResults && $request->taskDescription) {
            $sections = array_merge($sections, $this->fetchRagContext($request));
        }

        // 2. Feedback
        if ($request->includeFeedback) {
            $fb = $this->fetchFeedback($request);
            if ($fb) $sections[] = $fb;
        }

        // 3. Step History
        if ($request->includeStepHistory) {
            $hist = $this->fetchStepHistory($request);
            if ($hist) $sections[] = $hist;
        }

        // 4. Design Patterns
        if ($request->includeDesignPatterns) {
            $pat = $this->fetchDesignPatterns($request);
            if ($pat) $sections[] = $pat;
        }

        // 5. Custom Injections
        foreach ($request->customInjections as $key => $value) {
            $sections[] = new ContextSection(
                'custom', $key, $value,
                self::DEFAULT_PRIORITIES['custom'],
                self::estimateTokens($value)
            );
        }

        $budgeted = $this->applyTokenBudget($sections, $request->maxTokenBudget);
        $totalTokens = collect($budgeted)->sum(fn($s) => $s->estimatedTokens);

        Log::info("Context: {$request->traceId}/{$request->currentStepId} → "
            . count($budgeted) . " sections, ~{$totalTokens} tokens");

        return new ContextPackage(
            $request->traceId, $request->currentStepId,
            $budgeted, $totalTokens
        );
    }

    public function formatForPrompt(ContextPackage $pkg): string
    {
        $sorted = collect($pkg->sections)->sortByDesc(fn($s) => $s->priority)->values();

        $xml = "<xiigen-context>\n";
        $xml .= "  <trace id=\"{$pkg->traceId}\" step=\"{$pkg->currentStepId}\">\n";

        foreach ($sorted as $s) {
            $xml .= "  <context-section source=\"{$s->source}\" priority=\"{$s->priority}\">\n";
            $xml .= "    <title>{$s->title}</title>\n";
            $xml .= "    <content>{$s->content}</content>\n";
            $xml .= "  </context-section>\n";
        }

        $xml .= "  </trace>\n</xiigen-context>";
        return $xml;
    }

    public function storeResults(
        string $traceId, string $stepId, string $stepType,
        mixed $results, ?string $technology = null
    ): bool {
        try {
            $json = json_encode($results);
            $plan = $this->ragPlanner->planStorage($stepType, $technology, substr($json, 0, 500), $traceId);

            if ($plan && !empty($plan->operations)) {
                foreach ($plan->operations as $op) {
                    $this->rag->index($op->collection, [
                        'id' => "{$traceId}-{$stepId}-{$op->collection}",
                        'traceId' => $traceId, 'stepId' => $stepId,
                        'content' => $op->contentExtractor === 'summary' ? substr($json, 0, 300) : $json,
                        'createdAt' => now()->toISOString(),
                    ]);
                }
            } else {
                $this->rag->index('xiigen-results', [
                    'id' => "{$traceId}-{$stepId}",
                    'traceId' => $traceId, 'content' => $json,
                    'createdAt' => now()->toISOString(),
                ]);
            }
            return true;
        } catch (\Exception $e) {
            Log::error("StoreResults failed: {$traceId}/{$stepId} — {$e->getMessage()}");
            return false;
        }
    }

    // --- Private ---

    private function fetchRagContext(ContextRequest $req): array
    {
        try {
            $plan = $this->ragPlanner->planQuery(
                $req->taskDescription, $req->stepType, $req->technology, $req->traceId);
            if (!$plan || empty($plan->queries)) return [];

            return collect($plan->queries)->take($this->maxRag)->map(function ($q) {
                $results = $this->rag->search($q->collection, $q->queryText, 3);
                if (empty($results)) return null;
                $content = collect($results)->map(fn($r) => json_encode($r))->implode("\n");
                return new ContextSection('rag', 'RAG: ' . substr($q->queryText, 0, 50),
                    $content, self::DEFAULT_PRIORITIES['rag'], self::estimateTokens($content));
            })->filter()->values()->all();
        } catch (\Exception $e) { return []; }
    }

    private function fetchFeedback(ContextRequest $req): ?ContextSection
    {
        try {
            $items = $this->db->search('xiigen-feedback',
                ['stepType' => $req->stepType, 'technology' => $req->technology ?? ''],
                $this->maxFeedback);
            if (empty($items)) return null;

            $content = "<feedback-history>\n";
            foreach ($items as $item) {
                if (!empty($item['text'])) {
                    $rating = $item['rating'] ?? 'neutral';
                    $content .= "  <feedback rating=\"{$rating}\">{$item['text']}</feedback>\n";
                }
            }
            $content .= "</feedback-history>";
            return new ContextSection('feedback', 'User Feedback', $content,
                self::DEFAULT_PRIORITIES['feedback'], self::estimateTokens($content));
        } catch (\Exception $e) { return null; }
    }

    private function fetchStepHistory(ContextRequest $req): ?ContextSection
    {
        try {
            $steps = $this->db->search('xiigen-debug',
                ['traceId' => $req->traceId, 'status' => 'Completed'], $this->maxHistory);
            if (empty($steps)) return null;

            $content = "<previous-steps>\n";
            foreach ($steps as $s) {
                $json = json_encode($s);
                $content .= "  <step>" . (strlen($json) > 300 ? substr($json, 0, 300) . '...' : $json) . "</step>\n";
            }
            $content .= "</previous-steps>";
            return new ContextSection('history', 'Previous Steps', $content,
                self::DEFAULT_PRIORITIES['history'], self::estimateTokens($content));
        } catch (\Exception $e) { return null; }
    }

    private function fetchDesignPatterns(ContextRequest $req): ?ContextSection
    {
        $hints = self::PATTERN_MAP[strtolower($req->stepType)] ?? ['Strategy', 'Factory'];
        $content = "<design-pattern-hints>\n";
        foreach (array_slice($hints, 0, $this->maxPatterns) as $p) {
            $content .= "  <pattern name=\"{$p}\">Consider {$p} for this step type.</pattern>\n";
        }
        $content .= "</design-pattern-hints>";
        return new ContextSection('patterns', 'Design Patterns', $content,
            self::DEFAULT_PRIORITIES['patterns'], self::estimateTokens($content));
    }

    private function applyTokenBudget(array $sections, int $maxTokens): array
    {
        usort($sections, fn($a, $b) => $b->priority - $a->priority);
        $result = [];
        $remaining = $maxTokens;
        foreach ($sections as $s) {
            if ($remaining <= 0) break;
            if ($s->estimatedTokens <= $remaining) {
                $result[] = $s; $remaining -= $s->estimatedTokens;
            } elseif ($remaining > 100) {
                $result[] = new ContextSection($s->source, $s->title,
                    substr($s->content, 0, $remaining * 4) . "\n[truncated]",
                    $s->priority, $remaining);
                $remaining = 0;
            }
        }
        return $result;
    }
}

// --- Laravel Routes (routes/api.php) ---
// Route::prefix('api/context')->group(function () {
//     Route::post('/build', [ContextController::class, 'build']);
//     Route::post('/store', [ContextController::class, 'store']);
// });
