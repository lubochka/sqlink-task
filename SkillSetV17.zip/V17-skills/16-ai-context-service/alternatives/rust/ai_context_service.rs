// XIIGen Skill 16 — AI Context Service (Rust/Axum)
use axum::{Router, routing::post, Json, extract::State};
use serde::{Serialize, Deserialize};
use std::sync::Arc;
use std::collections::HashMap;
use chrono::{DateTime, Utc};
use tracing::{info, warn, error};

// --- Models ---
#[derive(Deserialize)]
pub struct ContextRequest {
    pub trace_id: String,
    pub current_step_id: String,
    pub step_type: String,
    pub technology: Option<String>,
    pub task_description: Option<String>,
    #[serde(default = "default_budget")]
    pub max_token_budget: i32,
    pub custom_injections: Option<HashMap<String, String>>,
    #[serde(default = "default_true")]
    pub include_design_patterns: bool,
    #[serde(default = "default_true")]
    pub include_feedback: bool,
    #[serde(default = "default_true")]
    pub include_rag_results: bool,
    #[serde(default = "default_true")]
    pub include_step_history: bool,
}

fn default_budget() -> i32 { 4000 }
fn default_true() -> bool { true }

#[derive(Serialize, Clone)]
pub struct ContextSection {
    pub source: String,
    pub title: String,
    pub content: String,
    pub priority: i32,
    pub estimated_tokens: i32,
}

#[derive(Serialize)]
pub struct ContextPackage {
    pub trace_id: String,
    pub current_step_id: String,
    pub sections: Vec<ContextSection>,
    pub estimated_tokens: i32,
    pub assembled_at: DateTime<Utc>,
}

// --- Service ---
pub struct AiContextService {
    db: Arc<dyn DatabaseService>,
    rag: Arc<dyn RagService>,
    rag_planner: Arc<dyn RagPlannerService>,
}

lazy_static::lazy_static! {
    static ref DEFAULT_PRIORITIES: HashMap<&'static str, i32> = HashMap::from([
        ("feedback", 90), ("rag", 80), ("custom", 70), ("history", 60), ("patterns", 50)
    ]);
    static ref PATTERN_MAP: HashMap<&'static str, Vec<&'static str>> = HashMap::from([
        ("figma-parse", vec!["Strategy", "Adapter", "Visitor"]),
        ("ai-transform", vec!["Strategy", "Template Method", "Chain of Responsibility"]),
        ("ai-review", vec!["Observer", "Strategy", "Decorator"]),
        ("code-generate", vec!["Factory", "Builder", "Template Method"]),
        ("auth", vec!["Proxy", "Chain of Responsibility", "Singleton"]),
    ]);
}

impl AiContextService {
    pub fn new(
        db: Arc<dyn DatabaseService>,
        rag: Arc<dyn RagService>,
        rag_planner: Arc<dyn RagPlannerService>,
    ) -> Self {
        Self { db, rag, rag_planner }
    }

    pub fn estimate_tokens(text: &str) -> i32 {
        if text.is_empty() { 0 } else { (text.len() as f64 / 4.0).ceil() as i32 }
    }

    pub async fn build_context(&self, request: &ContextRequest) -> Result<ContextPackage, String> {
        let mut sections: Vec<ContextSection> = Vec::new();

        // 1. RAG Results
        if request.include_rag_results {
            if let Some(desc) = &request.task_description {
                if let Ok(rag_sections) = self.fetch_rag_context(request).await {
                    sections.extend(rag_sections);
                }
            }
        }

        // 2. Feedback
        if request.include_feedback {
            if let Ok(Some(fb)) = self.fetch_feedback(request).await {
                sections.push(fb);
            }
        }

        // 3. Step History
        if request.include_step_history {
            if let Ok(Some(hist)) = self.fetch_step_history(request).await {
                sections.push(hist);
            }
        }

        // 4. Design Patterns
        if request.include_design_patterns {
            if let Some(pat) = self.fetch_design_patterns(request) {
                sections.push(pat);
            }
        }

        // 5. Custom Injections
        if let Some(injections) = &request.custom_injections {
            for (key, value) in injections {
                sections.push(ContextSection {
                    source: "custom".into(), title: key.clone(), content: value.clone(),
                    priority: *DEFAULT_PRIORITIES.get("custom").unwrap_or(&70),
                    estimated_tokens: Self::estimate_tokens(value),
                });
            }
        }

        let budgeted = Self::apply_token_budget(sections, request.max_token_budget);
        let total: i32 = budgeted.iter().map(|s| s.estimated_tokens).sum();

        info!(trace_id = %request.trace_id, step_id = %request.current_step_id,
              sections = budgeted.len(), tokens = total, "Context built");

        Ok(ContextPackage {
            trace_id: request.trace_id.clone(),
            current_step_id: request.current_step_id.clone(),
            sections: budgeted, estimated_tokens: total, assembled_at: Utc::now(),
        })
    }

    pub fn format_for_prompt(pkg: &ContextPackage) -> String {
        let mut xml = String::from("<xiigen-context>\n");
        xml.push_str(&format!("  <trace id=\"{}\" step=\"{}\">\n",
                              pkg.trace_id, pkg.current_step_id));

        let mut sorted = pkg.sections.clone();
        sorted.sort_by(|a, b| b.priority.cmp(&a.priority));

        for s in &sorted {
            xml.push_str(&format!("  <context-section source=\"{}\" priority=\"{}\">\n", s.source, s.priority));
            xml.push_str(&format!("    <title>{}</title>\n", s.title));
            xml.push_str(&format!("    <content>{}</content>\n", s.content));
            xml.push_str("  </context-section>\n");
        }
        xml.push_str("  </trace>\n</xiigen-context>");
        xml
    }

    // --- Private helpers ---
    async fn fetch_rag_context(&self, req: &ContextRequest) -> Result<Vec<ContextSection>, String> {
        let plan = self.rag_planner.plan_query(
            req.task_description.as_deref().unwrap_or(""),
            &req.step_type, req.technology.as_deref(), &req.trace_id
        ).await.map_err(|e| e.to_string())?;

        let mut sections = Vec::new();
        for q in plan.queries.iter().take(5) {
            if let Ok(results) = self.rag.search(&q.collection, &q.query_text, 3).await {
                if !results.is_empty() {
                    let content: String = results.iter().map(|r| format!("{:?}", r)).collect::<Vec<_>>().join("\n");
                    let tokens = Self::estimate_tokens(&content);
                    sections.push(ContextSection {
                        source: "rag".into(),
                        title: format!("RAG: {}", &q.query_text[..q.query_text.len().min(50)]),
                        content, priority: *DEFAULT_PRIORITIES.get("rag").unwrap_or(&80),
                        estimated_tokens: tokens,
                    });
                }
            }
        }
        Ok(sections)
    }

    async fn fetch_feedback(&self, req: &ContextRequest) -> Result<Option<ContextSection>, String> {
        let items = self.db.search("xiigen-feedback",
            &serde_json::json!({"stepType": req.step_type, "technology": req.technology.as_deref().unwrap_or("")}),
            10).await.map_err(|e| e.to_string())?;

        if items.is_empty() { return Ok(None); }

        let mut content = String::from("<feedback-history>\n");
        for item in &items {
            if let (Some(rating), Some(text)) = (item.get("rating"), item.get("text")) {
                content.push_str(&format!("  <feedback rating=\"{}\">{}</feedback>\n",
                    rating.as_str().unwrap_or("neutral"), text.as_str().unwrap_or("")));
            }
        }
        content.push_str("</feedback-history>");
        let tokens = Self::estimate_tokens(&content);
        Ok(Some(ContextSection {
            source: "feedback".into(), title: "User Feedback".into(),
            content, priority: *DEFAULT_PRIORITIES.get("feedback").unwrap_or(&90),
            estimated_tokens: tokens,
        }))
    }

    async fn fetch_step_history(&self, req: &ContextRequest) -> Result<Option<ContextSection>, String> {
        let steps = self.db.search("xiigen-debug",
            &serde_json::json!({"traceId": req.trace_id, "status": "Completed"}),
            5).await.map_err(|e| e.to_string())?;

        if steps.is_empty() { return Ok(None); }

        let mut content = String::from("<previous-steps>\n");
        for s in &steps {
            let json = serde_json::to_string(s).unwrap_or_default();
            let truncated = if json.len() > 300 { format!("{}...", &json[..300]) } else { json };
            content.push_str(&format!("  <step>{}</step>\n", truncated));
        }
        content.push_str("</previous-steps>");
        let tokens = Self::estimate_tokens(&content);
        Ok(Some(ContextSection {
            source: "history".into(), title: "Previous Steps".into(), content,
            priority: *DEFAULT_PRIORITIES.get("history").unwrap_or(&60), estimated_tokens: tokens,
        }))
    }

    fn fetch_design_patterns(&self, req: &ContextRequest) -> Option<ContextSection> {
        let key = req.step_type.to_lowercase();
        let hints = PATTERN_MAP.get(key.as_str())
            .cloned().unwrap_or_else(|| vec!["Strategy", "Factory"]);

        let mut content = String::from("<design-pattern-hints>\n");
        for p in hints.iter().take(3) {
            content.push_str(&format!("  <pattern name=\"{}\">Consider {} for this step type.</pattern>\n", p, p));
        }
        content.push_str("</design-pattern-hints>");
        let tokens = Self::estimate_tokens(&content);
        Some(ContextSection {
            source: "patterns".into(), title: "Design Patterns".into(), content,
            priority: *DEFAULT_PRIORITIES.get("patterns").unwrap_or(&50), estimated_tokens: tokens,
        })
    }

    fn apply_token_budget(mut sections: Vec<ContextSection>, max_tokens: i32) -> Vec<ContextSection> {
        sections.sort_by(|a, b| b.priority.cmp(&a.priority));
        let mut result = Vec::new();
        let mut remaining = max_tokens;
        for s in sections {
            if remaining <= 0 { break; }
            if s.estimated_tokens <= remaining {
                remaining -= s.estimated_tokens;
                result.push(s);
            } else if remaining > 100 {
                let trunc_len = (remaining as usize * 4).min(s.content.len());
                result.push(ContextSection {
                    content: format!("{}\n[truncated]", &s.content[..trunc_len]),
                    estimated_tokens: remaining, ..s
                });
                remaining = 0;
            }
        }
        result
    }
}

// --- Axum Routes ---
pub fn routes() -> Router<AppState> {
    Router::new()
        .route("/api/context/build", post(build_handler))
        .route("/api/context/store", post(store_handler))
}

async fn build_handler(State(state): State<AppState>, Json(req): Json<ContextRequest>) -> Json<ContextPackage> {
    let pkg = state.context_svc.build_context(&req).await.unwrap();
    Json(pkg)
}

async fn store_handler(State(state): State<AppState>, Json(body): Json<serde_json::Value>) -> Json<bool> {
    let ok = state.context_svc.store_results(
        body["traceId"].as_str().unwrap(), body["stepId"].as_str().unwrap(),
        body["stepType"].as_str().unwrap(), &body["results"],
        body["technology"].as_str()
    ).await;
    Json(ok)
}
