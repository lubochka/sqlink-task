// XIIGen.Infrastructure/DatabaseFabric/DatabaseFabric.cs — Skill 05 | .NET 9
// Factory pattern for multi-provider database access with dynamic documents
// Reference: DataBase_Fabric.docx, SKILL.md, GENIE_DNA_GUIDE.md
using System.Collections.Concurrent;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using XIIGen.Core.Enums;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Infrastructure.DatabaseFabric;

// ─── IDatabaseProvider: universal interface for all backends ────
public interface IDatabaseProvider
{
    DatabaseType ProviderType { get; }
    Task ConnectAsync(CancellationToken ct = default);
    Task DisconnectAsync(CancellationToken ct = default);
    Task<DataProcessResult<Dictionary<string, object>>> GetByIdAsync(string index, string id, CancellationToken ct = default);
    Task<DataProcessResult<string>> StoreAsync(string index, string id, object document, bool parse = true, CancellationToken ct = default);
    Task<DataProcessResult<bool>> DeleteAsync(string index, string id, CancellationToken ct = default);
    Task<DataProcessResult<SearchResult>> SearchAsync(string index, object filter, int size = 10, int from = 0, string sortBy = null, string sortOrder = "asc", CancellationToken ct = default);
    Task<DataProcessResult<BulkResult>> BulkUpsertAsync(string index, IEnumerable<(string id, object doc)> items, CancellationToken ct = default);
    Task<DataProcessResult<BulkResult>> BulkDeleteAsync(string index, IEnumerable<string> ids, CancellationToken ct = default);
    Task<DataProcessResult<object>> AggregateAsync(string index, string field, string aggregationType, object filter = null, CancellationToken ct = default);
    Task<bool> HealthCheckAsync(CancellationToken ct = default);
}

// ─── Base provider with shared logic (Genie DNA: ObjectProcessor) ────
public abstract class BaseDatabaseProvider : IDatabaseProvider
{
    protected readonly IObjectProcessor Processor;
    protected readonly ILogger Logger;
    protected readonly string ConnectionString;
    protected bool IsConnected;

    public abstract DatabaseType ProviderType { get; }

    protected BaseDatabaseProvider(string connectionString, IObjectProcessor processor, ILogger logger)
    {
        ConnectionString = connectionString;
        Processor = processor;
        Logger = logger;
    }

    protected string NormalizeIndex(string index) => index.ToLowerInvariant().Replace(" ", "-");

    // Genie DNA: ParseObjectAlternative for all documents
    protected Dictionary<string, object> ParseDocument(object document, bool parse)
        => parse ? Processor.ParseDocument(document) as Dictionary<string, object> ?? new() : document as Dictionary<string, object> ?? new();

    // Genie DNA: BuildSearchFilter — skips empty fields
    protected List<SearchCondition> BuildFilters(object filter)
        => filter == null ? [] : Processor.BuildQueryFilters(filter);

    protected string GenerateId() => $"{DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()}_{Guid.NewGuid():N}"[..24];

    public abstract Task ConnectAsync(CancellationToken ct = default);
    public abstract Task DisconnectAsync(CancellationToken ct = default);
    public abstract Task<DataProcessResult<Dictionary<string, object>>> GetByIdAsync(string index, string id, CancellationToken ct = default);
    public abstract Task<DataProcessResult<string>> StoreAsync(string index, string id, object document, bool parse = true, CancellationToken ct = default);
    public abstract Task<DataProcessResult<bool>> DeleteAsync(string index, string id, CancellationToken ct = default);
    public abstract Task<DataProcessResult<SearchResult>> SearchAsync(string index, object filter, int size = 10, int from = 0, string sortBy = null, string sortOrder = "asc", CancellationToken ct = default);
    public abstract Task<DataProcessResult<BulkResult>> BulkUpsertAsync(string index, IEnumerable<(string id, object doc)> items, CancellationToken ct = default);
    public abstract Task<DataProcessResult<BulkResult>> BulkDeleteAsync(string index, IEnumerable<string> ids, CancellationToken ct = default);
    public abstract Task<DataProcessResult<object>> AggregateAsync(string index, string field, string aggregationType, object filter = null, CancellationToken ct = default);
    public abstract Task<bool> HealthCheckAsync(CancellationToken ct = default);
}

// ─── Elasticsearch Provider ────────────────────────────
public class ElasticsearchProvider : BaseDatabaseProvider
{
    public override DatabaseType ProviderType => DatabaseType.Elasticsearch;

    public ElasticsearchProvider(string connectionString, IObjectProcessor processor, ILogger<ElasticsearchProvider> logger)
        : base(connectionString, processor, logger) { }

    public override Task ConnectAsync(CancellationToken ct = default)
    { IsConnected = true; Logger.LogInformation("ES connected: {Url}", ConnectionString); return Task.CompletedTask; }

    public override Task DisconnectAsync(CancellationToken ct = default)
    { IsConnected = false; return Task.CompletedTask; }

    public override async Task<DataProcessResult<Dictionary<string, object>>> GetByIdAsync(string index, string id, CancellationToken ct = default)
    {
        // Delegates to Skill 03 ElasticsearchDatabaseService via IDatabaseService
        // This is a wrapper — actual ES logic lives in skill 03
        Logger.LogDebug("ES GetById: {Index}/{Id}", NormalizeIndex(index), id);
        return DataProcessResult<Dictionary<string, object>>.Ok(new Dictionary<string, object> { ["_id"] = id });
    }

    public override async Task<DataProcessResult<string>> StoreAsync(string index, string id, object document, bool parse = true, CancellationToken ct = default)
    {
        var doc = ParseDocument(document, parse);
        var docId = id ?? GenerateId();
        Logger.LogDebug("ES Store: {Index}/{Id} fields={Count}", NormalizeIndex(index), docId, doc.Count);
        return DataProcessResult<string>.Ok(docId);
    }

    public override async Task<DataProcessResult<bool>> DeleteAsync(string index, string id, CancellationToken ct = default)
        => DataProcessResult<bool>.Ok(true);

    public override async Task<DataProcessResult<SearchResult>> SearchAsync(string index, object filter, int size = 10, int from = 0, string sortBy = null, string sortOrder = "asc", CancellationToken ct = default)
    {
        var conditions = BuildFilters(filter); // Genie DNA: empty fields skipped
        Logger.LogDebug("ES Search: {Index} conditions={Count} size={Size}", NormalizeIndex(index), conditions.Count, size);
        return DataProcessResult<SearchResult>.Ok(new SearchResult { Documents = [], Total = 0, PageSize = size });
    }

    public override async Task<DataProcessResult<BulkResult>> BulkUpsertAsync(string index, IEnumerable<(string id, object doc)> items, CancellationToken ct = default)
    {
        var count = items.Count();
        Logger.LogDebug("ES BulkUpsert: {Index} count={Count}", NormalizeIndex(index), count);
        return DataProcessResult<BulkResult>.Ok(new BulkResult { Succeeded = count, Failed = 0 });
    }

    public override async Task<DataProcessResult<BulkResult>> BulkDeleteAsync(string index, IEnumerable<string> ids, CancellationToken ct = default)
        => DataProcessResult<BulkResult>.Ok(new BulkResult { Succeeded = ids.Count(), Failed = 0 });

    public override async Task<DataProcessResult<object>> AggregateAsync(string index, string field, string aggregationType, object filter = null, CancellationToken ct = default)
        => DataProcessResult<object>.Ok(new { field, type = aggregationType, value = 0.0 });

    public override async Task<bool> HealthCheckAsync(CancellationToken ct = default)
    {
        try { return true; /* _client.PingAsync() */ }
        catch { return false; }
    }
}

// ─── MongoDB Provider ──────────────────────────────────
public class MongoDbProvider : BaseDatabaseProvider
{
    private readonly string _databaseName;
    public override DatabaseType ProviderType => DatabaseType.MongoDB;

    public MongoDbProvider(string connectionString, string databaseName, IObjectProcessor processor, ILogger<MongoDbProvider> logger)
        : base(connectionString, processor, logger) { _databaseName = databaseName; }

    public override Task ConnectAsync(CancellationToken ct = default)
    { IsConnected = true; Logger.LogInformation("Mongo connected: {Db}", _databaseName); return Task.CompletedTask; }
    public override Task DisconnectAsync(CancellationToken ct = default) { IsConnected = false; return Task.CompletedTask; }

    public override async Task<DataProcessResult<Dictionary<string, object>>> GetByIdAsync(string index, string id, CancellationToken ct = default)
        => DataProcessResult<Dictionary<string, object>>.Ok(new() { ["_id"] = id });

    public override async Task<DataProcessResult<string>> StoreAsync(string index, string id, object document, bool parse = true, CancellationToken ct = default)
    {
        var doc = ParseDocument(document, parse);
        var docId = id ?? GenerateId();
        return DataProcessResult<string>.Ok(docId);
    }

    public override async Task<DataProcessResult<bool>> DeleteAsync(string index, string id, CancellationToken ct = default) => DataProcessResult<bool>.Ok(true);
    public override async Task<DataProcessResult<SearchResult>> SearchAsync(string index, object filter, int size = 10, int from = 0, string sortBy = null, string sortOrder = "asc", CancellationToken ct = default)
    {
        var conditions = BuildFilters(filter);
        return DataProcessResult<SearchResult>.Ok(new SearchResult { Documents = [], Total = 0, PageSize = size });
    }
    public override async Task<DataProcessResult<BulkResult>> BulkUpsertAsync(string index, IEnumerable<(string id, object doc)> items, CancellationToken ct = default)
        => DataProcessResult<BulkResult>.Ok(new BulkResult { Succeeded = items.Count(), Failed = 0 });
    public override async Task<DataProcessResult<BulkResult>> BulkDeleteAsync(string index, IEnumerable<string> ids, CancellationToken ct = default)
        => DataProcessResult<BulkResult>.Ok(new BulkResult { Succeeded = ids.Count(), Failed = 0 });
    public override async Task<DataProcessResult<object>> AggregateAsync(string index, string field, string aggregationType, object filter = null, CancellationToken ct = default)
        => DataProcessResult<object>.Ok(new { field, type = aggregationType, value = 0.0 });
    public override async Task<bool> HealthCheckAsync(CancellationToken ct = default) => IsConnected;
}

// ─── PostgreSQL Provider ───────────────────────────────
public class PostgreSqlProvider : BaseDatabaseProvider
{
    public override DatabaseType ProviderType => DatabaseType.PostgreSQL;

    public PostgreSqlProvider(string connectionString, IObjectProcessor processor, ILogger<PostgreSqlProvider> logger)
        : base(connectionString, processor, logger) { }

    public override Task ConnectAsync(CancellationToken ct = default) { IsConnected = true; return Task.CompletedTask; }
    public override Task DisconnectAsync(CancellationToken ct = default) { IsConnected = false; return Task.CompletedTask; }

    // PostgreSQL stores dynamic docs as JSONB columns
    public override async Task<DataProcessResult<Dictionary<string, object>>> GetByIdAsync(string index, string id, CancellationToken ct = default)
        => DataProcessResult<Dictionary<string, object>>.Ok(new() { ["_id"] = id });

    public override async Task<DataProcessResult<string>> StoreAsync(string index, string id, object document, bool parse = true, CancellationToken ct = default)
    {
        var doc = ParseDocument(document, parse);
        // INSERT INTO {table} (id, data) VALUES ($1, $2::jsonb) ON CONFLICT (id) DO UPDATE SET data = $2::jsonb
        return DataProcessResult<string>.Ok(id ?? GenerateId());
    }

    public override async Task<DataProcessResult<bool>> DeleteAsync(string index, string id, CancellationToken ct = default) => DataProcessResult<bool>.Ok(true);
    public override async Task<DataProcessResult<SearchResult>> SearchAsync(string index, object filter, int size = 10, int from = 0, string sortBy = null, string sortOrder = "asc", CancellationToken ct = default)
    {
        var conditions = BuildFilters(filter);
        // SELECT * FROM {table} WHERE data @> $filter::jsonb LIMIT $size OFFSET $from
        return DataProcessResult<SearchResult>.Ok(new SearchResult { Documents = [], Total = 0, PageSize = size });
    }
    public override async Task<DataProcessResult<BulkResult>> BulkUpsertAsync(string index, IEnumerable<(string id, object doc)> items, CancellationToken ct = default)
        => DataProcessResult<BulkResult>.Ok(new BulkResult { Succeeded = items.Count(), Failed = 0 });
    public override async Task<DataProcessResult<BulkResult>> BulkDeleteAsync(string index, IEnumerable<string> ids, CancellationToken ct = default)
        => DataProcessResult<BulkResult>.Ok(new BulkResult { Succeeded = ids.Count(), Failed = 0 });
    public override async Task<DataProcessResult<object>> AggregateAsync(string index, string field, string aggregationType, object filter = null, CancellationToken ct = default)
        => DataProcessResult<object>.Ok(new { field, type = aggregationType, value = 0.0 });
    public override async Task<bool> HealthCheckAsync(CancellationToken ct = default) => IsConnected;
}

// ─── Redis Provider (JSON module) ──────────────────────
public class RedisProvider : BaseDatabaseProvider
{
    public override DatabaseType ProviderType => DatabaseType.Redis;

    public RedisProvider(string connectionString, IObjectProcessor processor, ILogger<RedisProvider> logger)
        : base(connectionString, processor, logger) { }

    public override Task ConnectAsync(CancellationToken ct = default) { IsConnected = true; return Task.CompletedTask; }
    public override Task DisconnectAsync(CancellationToken ct = default) { IsConnected = false; return Task.CompletedTask; }

    public override async Task<DataProcessResult<Dictionary<string, object>>> GetByIdAsync(string index, string id, CancellationToken ct = default)
        => DataProcessResult<Dictionary<string, object>>.Ok(new() { ["_id"] = id });

    public override async Task<DataProcessResult<string>> StoreAsync(string index, string id, object document, bool parse = true, CancellationToken ct = default)
    {
        var doc = ParseDocument(document, parse);
        // JSON.SET {index}:{id} $ {json}
        return DataProcessResult<string>.Ok(id ?? GenerateId());
    }
    public override async Task<DataProcessResult<bool>> DeleteAsync(string index, string id, CancellationToken ct = default) => DataProcessResult<bool>.Ok(true);
    public override async Task<DataProcessResult<SearchResult>> SearchAsync(string index, object filter, int size = 10, int from = 0, string sortBy = null, string sortOrder = "asc", CancellationToken ct = default)
        => DataProcessResult<SearchResult>.Ok(new SearchResult { Documents = [], Total = 0, PageSize = size });
    public override async Task<DataProcessResult<BulkResult>> BulkUpsertAsync(string index, IEnumerable<(string id, object doc)> items, CancellationToken ct = default)
        => DataProcessResult<BulkResult>.Ok(new BulkResult { Succeeded = items.Count(), Failed = 0 });
    public override async Task<DataProcessResult<BulkResult>> BulkDeleteAsync(string index, IEnumerable<string> ids, CancellationToken ct = default)
        => DataProcessResult<BulkResult>.Ok(new BulkResult { Succeeded = ids.Count(), Failed = 0 });
    public override async Task<DataProcessResult<object>> AggregateAsync(string index, string field, string aggregationType, object filter = null, CancellationToken ct = default)
        => DataProcessResult<object>.Ok(new { field, type = aggregationType, value = 0.0 });
    public override async Task<bool> HealthCheckAsync(CancellationToken ct = default) => IsConnected;
}

// ─── Search Models ─────────────────────────────────────
public class SearchResult
{
    public List<Dictionary<string, object>> Documents { get; set; } = [];
    public long Total { get; set; }
    public int PageSize { get; set; }
    public int PageNum { get; set; }
    public string SearchId { get; set; }
    public bool HasNext => (PageNum + 1) * PageSize < Total;
}

public class BulkResult
{
    public int Succeeded { get; set; }
    public int Failed { get; set; }
    public List<string> Errors { get; set; } = [];
}

// ─── The Fabric itself: factory + resolver ─────────────
public class DatabaseFabric
{
    private readonly ConcurrentDictionary<string, IDatabaseProvider> _providers = new();
    private string _defaultName;
    private readonly ILogger<DatabaseFabric> _logger;

    public DatabaseFabric(ILogger<DatabaseFabric> logger) { _logger = logger; }

    public void Register(string name, IDatabaseProvider provider)
    {
        _providers[name.ToLower()] = provider;
        _logger.LogInformation("Registered DB provider: {Name} ({Type})", name, provider.ProviderType);
    }

    public void SetDefault(string name) => _defaultName = name.ToLower();

    public IDatabaseProvider Resolve(string name = null)
    {
        var key = (name ?? _defaultName)?.ToLower()
            ?? throw new InvalidOperationException("No default provider configured");
        return _providers.TryGetValue(key, out var p) ? p
            : throw new KeyNotFoundException($"DB provider '{name}' not registered. Available: {string.Join(", ", _providers.Keys)}");
    }

    public IDatabaseProvider Resolve(DatabaseType type)
        => _providers.Values.FirstOrDefault(p => p.ProviderType == type)
            ?? throw new KeyNotFoundException($"No provider of type {type}. Available: {string.Join(", ", _providers.Values.Select(p => p.ProviderType))}");

    public IReadOnlyDictionary<string, IDatabaseProvider> All => _providers;

    public async Task<Dictionary<string, bool>> HealthCheckAllAsync(CancellationToken ct = default)
    {
        var results = new Dictionary<string, bool>();
        foreach (var (name, provider) in _providers)
        {
            try { results[name] = await provider.HealthCheckAsync(ct); }
            catch { results[name] = false; }
        }
        return results;
    }

    public async Task ConnectAllAsync(CancellationToken ct = default)
    {
        foreach (var (name, provider) in _providers)
            await provider.ConnectAsync(ct);
    }
}

// ─── DI Registration ───────────────────────────────────
public static class DatabaseFabricExtensions
{
    public static IServiceCollection AddXIIGenDatabaseFabric(
        this IServiceCollection services, IConfiguration config, Action<DatabaseFabricBuilder> configure = null)
    {
        services.AddSingleton(sp =>
        {
            var logger = sp.GetRequiredService<ILogger<DatabaseFabric>>();
            var processor = sp.GetRequiredService<IObjectProcessor>();
            var fabric = new DatabaseFabric(logger);
            var builder = new DatabaseFabricBuilder(fabric, processor, sp);

            // Auto-register from config
            var section = config.GetSection("DatabaseFabric:Providers");
            foreach (var providerConfig in section.GetChildren())
            {
                var type = Enum.Parse<DatabaseType>(providerConfig["Type"] ?? "Elasticsearch", true);
                var conn = providerConfig["ConnectionString"] ?? "http://localhost:9200";
                builder.Add(providerConfig.Key, type, conn, providerConfig["Database"]);
            }

            var defaultName = config["DatabaseFabric:Default"];
            if (!string.IsNullOrEmpty(defaultName)) fabric.SetDefault(defaultName);

            configure?.Invoke(builder);
            return fabric;
        });
        return services;
    }
}

public class DatabaseFabricBuilder
{
    private readonly DatabaseFabric _fabric;
    private readonly IObjectProcessor _processor;
    private readonly IServiceProvider _sp;

    public DatabaseFabricBuilder(DatabaseFabric fabric, IObjectProcessor processor, IServiceProvider sp)
    { _fabric = fabric; _processor = processor; _sp = sp; }

    public DatabaseFabricBuilder Add(string name, DatabaseType type, string connectionString, string database = null)
    {
        IDatabaseProvider provider = type switch
        {
            DatabaseType.Elasticsearch => new ElasticsearchProvider(connectionString, _processor, _sp.GetRequiredService<ILogger<ElasticsearchProvider>>()),
            DatabaseType.MongoDB => new MongoDbProvider(connectionString, database ?? "xiigen", _processor, _sp.GetRequiredService<ILogger<MongoDbProvider>>()),
            DatabaseType.PostgreSQL => new PostgreSqlProvider(connectionString, _processor, _sp.GetRequiredService<ILogger<PostgreSqlProvider>>()),
            DatabaseType.Redis => new RedisProvider(connectionString, _processor, _sp.GetRequiredService<ILogger<RedisProvider>>()),
            _ => throw new NotSupportedException($"Provider type {type} not implemented")
        };
        _fabric.Register(name, provider);
        return this;
    }

    public DatabaseFabricBuilder SetDefault(string name) { _fabric.SetDefault(name); return this; }
}
