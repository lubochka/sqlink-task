# Skill 05: Database Fabric — Implementation Prompts

## Step 1: Create the IDatabaseProvider Interface
```
Create IDatabaseProvider with methods: connect, disconnect, getById, store, delete, search, bulkUpsert, bulkDelete, aggregate, healthCheck.
All methods accept dynamic documents (no typed models). Store runs through ObjectProcessor.ParseObjectAlternative.
Search uses ObjectProcessor.BuildSearchFilter which auto-skips empty fields.
Return DataProcessResult<T> for all operations.
```

## Step 2: Implement Elasticsearch Provider
```
Implement IDatabaseProvider for Elasticsearch 8.x using Elastic.Clients.Elasticsearch.
Use ObjectProcessor for document parsing and filter building (Genie DNA).
Auto-create indices on first write. Use Refresh.WaitFor for consistency.
Build BoolQuery from SearchConditions, mapping QueryType enum to ES query types.
```

## Step 3: Implement MongoDB Provider
```
Implement IDatabaseProvider for MongoDB using MongoDB.Driver.
Store dynamic documents as BsonDocument. Convert SearchConditions to FilterDefinition<BsonDocument>.
Use ReplaceOneAsync with IsUpsert=true for store operations.
```

## Step 4: Implement PostgreSQL Provider
```
Implement IDatabaseProvider for PostgreSQL using Npgsql.
Store dynamic documents as JSONB. Auto-create table: (id TEXT PK, data JSONB, created TIMESTAMPTZ, updated TIMESTAMPTZ).
Convert SearchConditions to WHERE clauses: data @> $filter::jsonb for equality, data->>'field' operators for comparisons.
```

## Step 5: Implement Redis Provider
```
Implement IDatabaseProvider for Redis using StackExchange.Redis with RedisJSON module.
Use JSON.SET for store, JSON.GET for retrieve. Search limited to key patterns or RediSearch FT.SEARCH.
```

## Step 6: Create DatabaseFabric Factory
```
Create factory class with: Register(name, provider), SetDefault(name), Resolve(name), Resolve(DatabaseType).
HealthCheckAll checks all registered providers. ConnectAll initializes all.
DI: AddXIIGenDatabaseFabric(config, builder => { builder.Add("es", DatabaseType.Elasticsearch, url); }).
Auto-read from config section DatabaseFabric:Providers.
```

## Step 7: Create Language Alternatives
```
For each of: Node.js/TypeScript, Python, Java, Rust, PHP —
Implement the same IDatabaseProvider interface with at least ES + MongoDB providers.
Use the language's ObjectProcessor equivalent for dynamic document handling.
Follow the same factory pattern.
```

## Troubleshooting
- If ES index not created: ensure auto-create mapping is enabled
- If filter returns no results: check ObjectProcessor is skipping empty fields correctly
- If provider not found: verify DI registration order (ObjectProcessor must be registered before DatabaseFabric)
