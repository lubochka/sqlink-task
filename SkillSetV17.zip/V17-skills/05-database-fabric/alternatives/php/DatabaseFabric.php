<?php
// Skill 05: Database Fabric — PHP 8.3
// Factory pattern for multi-provider database access with dynamic documents
// Same interface as .NET IDatabaseProvider — see SKILL.md
declare(strict_types=1);

namespace XIIGen\Infrastructure\DatabaseFabric;

use XIIGen\Core\{DataProcessResult, DatabaseType, ObjectProcessor, SearchCondition};

// ─── IDatabaseProvider interface ───────────────────────
interface IDatabaseProvider
{
    public function getProviderType(): DatabaseType;
    public function connect(): void;
    public function disconnect(): void;
    public function getById(string $index, string $id): DataProcessResult;
    public function store(string $index, ?string $id, mixed $document, bool $parse = true): DataProcessResult;
    public function delete(string $index, string $id): DataProcessResult;
    public function search(string $index, mixed $filter, int $size = 10, int $from = 0): DataProcessResult;
    public function bulkUpsert(string $index, array $items): DataProcessResult;
    public function healthCheck(): bool;
}

// ─── Base with ObjectProcessor (Genie DNA) ─────────────
abstract class BaseDatabaseProvider implements IDatabaseProvider
{
    protected ObjectProcessor $processor;
    protected bool $connected = false;

    public function __construct(protected readonly string $connectionString)
    {
        $this->processor = new ObjectProcessor();
    }

    protected function normalizeIndex(string $index): string
    {
        return strtolower(str_replace(' ', '-', $index));
    }

    /** Genie DNA: ParseObjectAlternative for all documents */
    protected function parseDoc(mixed $document, bool $parse): array
    {
        return $parse ? $this->processor->parseDocument($document) : (is_array($document) ? $document : []);
    }

    /** Genie DNA: BuildSearchFilter — skips empty fields */
    protected function buildFilters(mixed $filter): array
    {
        return $filter !== null ? $this->processor->buildQueryFilters($filter) : [];
    }

    protected function genId(): string
    {
        return (string)(int)(microtime(true) * 1000) . '_' . substr(bin2hex(random_bytes(5)), 0, 9);
    }
}

// ─── Elasticsearch Provider ────────────────────────────
final class ElasticsearchProvider extends BaseDatabaseProvider
{
    public function getProviderType(): DatabaseType { return DatabaseType::Elasticsearch; }
    public function connect(): void { $this->connected = true; }
    public function disconnect(): void { $this->connected = false; }

    public function getById(string $index, string $id): DataProcessResult
    {
        return DataProcessResult::ok(['_id' => $id]);
    }

    public function store(string $index, ?string $id, mixed $document, bool $parse = true): DataProcessResult
    {
        $doc = $this->parseDoc($document, $parse);
        $docId = $id ?? $this->genId();
        return DataProcessResult::ok($docId);
    }

    public function delete(string $index, string $id): DataProcessResult { return DataProcessResult::ok(true); }

    public function search(string $index, mixed $filter, int $size = 10, int $from = 0): DataProcessResult
    {
        $conditions = $this->buildFilters($filter); // Genie DNA: empty fields skipped
        return DataProcessResult::ok(['documents' => [], 'total' => 0, 'pageSize' => $size, 'hasNext' => false]);
    }

    public function bulkUpsert(string $index, array $items): DataProcessResult
    {
        return DataProcessResult::ok(['succeeded' => count($items), 'failed' => 0, 'errors' => []]);
    }

    public function healthCheck(): bool { return $this->connected; }
}

// ─── MongoDB Provider ──────────────────────────────────
final class MongoDbProvider extends BaseDatabaseProvider
{
    public function __construct(string $connectionString, private readonly string $dbName = 'xiigen')
    { parent::__construct($connectionString); }

    public function getProviderType(): DatabaseType { return DatabaseType::MongoDB; }
    public function connect(): void { $this->connected = true; }
    public function disconnect(): void { $this->connected = false; }
    public function getById(string $index, string $id): DataProcessResult { return DataProcessResult::ok(['_id' => $id]); }
    public function store(string $index, ?string $id, mixed $document, bool $parse = true): DataProcessResult {
        $this->parseDoc($document, $parse);
        return DataProcessResult::ok($id ?? $this->genId());
    }
    public function delete(string $index, string $id): DataProcessResult { return DataProcessResult::ok(true); }
    public function search(string $index, mixed $filter, int $size = 10, int $from = 0): DataProcessResult {
        $this->buildFilters($filter);
        return DataProcessResult::ok(['documents' => [], 'total' => 0, 'pageSize' => $size]);
    }
    public function bulkUpsert(string $index, array $items): DataProcessResult {
        return DataProcessResult::ok(['succeeded' => count($items), 'failed' => 0]);
    }
    public function healthCheck(): bool { return $this->connected; }
}

// ─── PostgreSQL Provider (JSONB) ───────────────────────
final class PostgreSqlProvider extends BaseDatabaseProvider
{
    public function getProviderType(): DatabaseType { return DatabaseType::PostgreSQL; }
    public function connect(): void { $this->connected = true; }
    public function disconnect(): void { $this->connected = false; }
    public function getById(string $index, string $id): DataProcessResult { return DataProcessResult::ok(['_id' => $id]); }
    public function store(string $index, ?string $id, mixed $document, bool $parse = true): DataProcessResult {
        $this->parseDoc($document, $parse);
        return DataProcessResult::ok($id ?? $this->genId());
    }
    public function delete(string $index, string $id): DataProcessResult { return DataProcessResult::ok(true); }
    public function search(string $index, mixed $filter, int $size = 10, int $from = 0): DataProcessResult {
        $this->buildFilters($filter);
        return DataProcessResult::ok(['documents' => [], 'total' => 0, 'pageSize' => $size]);
    }
    public function bulkUpsert(string $index, array $items): DataProcessResult {
        return DataProcessResult::ok(['succeeded' => count($items), 'failed' => 0]);
    }
    public function healthCheck(): bool { return $this->connected; }
}

// ─── Database Fabric: factory + resolver ───────────────
final class DatabaseFabric
{
    /** @var array<string, IDatabaseProvider> */
    private array $providers = [];
    private ?string $defaultName = null;

    public function register(string $name, IDatabaseProvider $provider): void
    {
        $this->providers[strtolower($name)] = $provider;
    }

    public function setDefault(string $name): void { $this->defaultName = strtolower($name); }

    public function resolve(?string $name = null): IDatabaseProvider
    {
        $key = strtolower($name ?? $this->defaultName ?? '');
        if (empty($key)) throw new \RuntimeException('No default provider configured');
        if (!isset($this->providers[$key]))
            throw new \InvalidArgumentException("Provider '$name' not registered. Available: " . implode(', ', array_keys($this->providers)));
        return $this->providers[$key];
    }

    public function resolveByType(DatabaseType $type): IDatabaseProvider
    {
        foreach ($this->providers as $p) {
            if ($p->getProviderType() === $type) return $p;
        }
        throw new \InvalidArgumentException("No provider of type $type->name");
    }

    /** @return array<string, bool> */
    public function healthCheckAll(): array
    {
        $results = [];
        foreach ($this->providers as $name => $p) {
            try { $results[$name] = $p->healthCheck(); } catch (\Throwable) { $results[$name] = false; }
        }
        return $results;
    }
}
