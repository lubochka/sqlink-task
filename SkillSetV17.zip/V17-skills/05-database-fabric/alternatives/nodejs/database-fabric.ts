// Skill 05: Database Fabric — Node.js/TypeScript
// Factory pattern for multi-provider database access with dynamic documents
// Same interface as .NET IDatabaseProvider — see SKILL.md
import { ObjectProcessor, DataProcessResult, ok, fail, SearchCondition, DatabaseType } from "./core-interfaces";

export interface SearchOptions { size?: number; from?: number; sortBy?: string; sortOrder?: "asc" | "desc"; }
export interface SearchResult { documents: Record<string, unknown>[]; total: number; pageSize: number; hasNext: boolean; }
export interface BulkResult { succeeded: number; failed: number; errors: string[]; }

export interface IDatabaseProvider {
  readonly providerType: DatabaseType;
  connect(): Promise<void>;
  disconnect(): Promise<void>;
  getById(index: string, id: string): Promise<DataProcessResult<Record<string, unknown>>>;
  store(index: string, id: string | null, document: unknown, parse?: boolean): Promise<DataProcessResult<string>>;
  remove(index: string, id: string): Promise<DataProcessResult<boolean>>;
  search(index: string, filter: unknown, options?: SearchOptions): Promise<DataProcessResult<SearchResult>>;
  bulkUpsert(index: string, items: { id: string; doc: unknown }[]): Promise<DataProcessResult<BulkResult>>;
  healthCheck(): Promise<boolean>;
}

// ─── Base provider with ObjectProcessor (Genie DNA) ────
abstract class BaseDatabaseProvider implements IDatabaseProvider {
  abstract readonly providerType: DatabaseType;
  protected processor = new ObjectProcessor();
  protected connected = false;

  constructor(protected connectionString: string) {}

  protected idx(index: string): string { return index.toLowerCase().replace(/ /g, "-"); }
  protected parseDoc(doc: unknown, parse: boolean): Record<string, unknown> {
    return parse ? this.processor.parseDocument(doc) : (doc as Record<string, unknown>);
  }
  protected buildFilters(filter: unknown): SearchCondition[] {
    return filter ? this.processor.buildQueryFilters(filter) : [];
  }
  protected genId(): string { return `${Date.now()}_${Math.random().toString(36).slice(2, 11)}`; }

  abstract connect(): Promise<void>;
  abstract disconnect(): Promise<void>;
  abstract getById(index: string, id: string): Promise<DataProcessResult<Record<string, unknown>>>;
  abstract store(index: string, id: string | null, document: unknown, parse?: boolean): Promise<DataProcessResult<string>>;
  abstract remove(index: string, id: string): Promise<DataProcessResult<boolean>>;
  abstract search(index: string, filter: unknown, options?: SearchOptions): Promise<DataProcessResult<SearchResult>>;
  abstract bulkUpsert(index: string, items: { id: string; doc: unknown }[]): Promise<DataProcessResult<BulkResult>>;
  abstract healthCheck(): Promise<boolean>;
}

// ─── Elasticsearch Provider ────────────────────────────
export class ElasticsearchProvider extends BaseDatabaseProvider {
  readonly providerType = DatabaseType.Elasticsearch;

  async connect() { this.connected = true; }
  async disconnect() { this.connected = false; }
  async getById(index: string, id: string) { return ok<Record<string, unknown>>({ _id: id }); }

  async store(index: string, id: string | null, document: unknown, parse = true) {
    const doc = this.parseDoc(document, parse);
    const docId = id ?? this.genId();
    // await this.client.index({ index: this.idx(index), id: docId, body: doc, refresh: "wait_for" });
    return ok(docId);
  }

  async remove(index: string, id: string) { return ok(true); }

  async search(index: string, filter: unknown, options: SearchOptions = {}) {
    const conditions = this.buildFilters(filter); // Genie DNA: empty fields skipped
    const { size = 10, from = 0 } = options;
    return ok<SearchResult>({ documents: [], total: 0, pageSize: size, hasNext: false });
  }

  async bulkUpsert(index: string, items: { id: string; doc: unknown }[]) {
    return ok<BulkResult>({ succeeded: items.length, failed: 0, errors: [] });
  }

  async healthCheck() { return this.connected; }
}

// ─── MongoDB Provider ──────────────────────────────────
export class MongoDbProvider extends BaseDatabaseProvider {
  readonly providerType = DatabaseType.MongoDB;

  constructor(connectionString: string, private dbName: string = "xiigen") { super(connectionString); }

  async connect() { this.connected = true; }
  async disconnect() { this.connected = false; }
  async getById(index: string, id: string) { return ok<Record<string, unknown>>({ _id: id }); }
  async store(index: string, id: string | null, document: unknown, parse = true) {
    const doc = this.parseDoc(document, parse);
    return ok(id ?? this.genId());
  }
  async remove(index: string, id: string) { return ok(true); }
  async search(index: string, filter: unknown, options: SearchOptions = {}) {
    const conditions = this.buildFilters(filter);
    return ok<SearchResult>({ documents: [], total: 0, pageSize: options.size ?? 10, hasNext: false });
  }
  async bulkUpsert(index: string, items: { id: string; doc: unknown }[]) {
    return ok<BulkResult>({ succeeded: items.length, failed: 0, errors: [] });
  }
  async healthCheck() { return this.connected; }
}

// ─── PostgreSQL Provider (JSONB) ───────────────────────
export class PostgreSqlProvider extends BaseDatabaseProvider {
  readonly providerType = DatabaseType.PostgreSQL;
  async connect() { this.connected = true; }
  async disconnect() { this.connected = false; }
  async getById(index: string, id: string) { return ok<Record<string, unknown>>({ _id: id }); }
  async store(index: string, id: string | null, document: unknown, parse = true) {
    const doc = this.parseDoc(document, parse);
    // INSERT INTO ${table} (id, data) VALUES ($1, $2::jsonb) ON CONFLICT DO UPDATE
    return ok(id ?? this.genId());
  }
  async remove(index: string, id: string) { return ok(true); }
  async search(index: string, filter: unknown, options: SearchOptions = {}) {
    const conditions = this.buildFilters(filter);
    return ok<SearchResult>({ documents: [], total: 0, pageSize: options.size ?? 10, hasNext: false });
  }
  async bulkUpsert(index: string, items: { id: string; doc: unknown }[]) {
    return ok<BulkResult>({ succeeded: items.length, failed: 0, errors: [] });
  }
  async healthCheck() { return this.connected; }
}

// ─── Database Fabric: factory + resolver ───────────────
export class DatabaseFabric {
  private providers = new Map<string, IDatabaseProvider>();
  private defaultName?: string;

  register(name: string, provider: IDatabaseProvider) { this.providers.set(name.toLowerCase(), provider); }
  setDefault(name: string) { this.defaultName = name.toLowerCase(); }

  resolve(name?: string): IDatabaseProvider {
    const key = (name ?? this.defaultName)?.toLowerCase();
    if (!key) throw new Error("No default provider configured");
    const p = this.providers.get(key);
    if (!p) throw new Error(`Provider '${name}' not registered. Available: ${[...this.providers.keys()]}`);
    return p;
  }

  resolveByType(type: DatabaseType): IDatabaseProvider {
    for (const p of this.providers.values()) if (p.providerType === type) return p;
    throw new Error(`No provider of type ${type}`);
  }

  async healthCheckAll(): Promise<Record<string, boolean>> {
    const results: Record<string, boolean> = {};
    for (const [name, p] of this.providers) {
      try { results[name] = await p.healthCheck(); } catch { results[name] = false; }
    }
    return results;
  }

  async connectAll(): Promise<void> {
    for (const p of this.providers.values()) await p.connect();
  }
}
