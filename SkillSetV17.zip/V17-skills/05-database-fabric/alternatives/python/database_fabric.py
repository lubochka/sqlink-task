# Skill 05: Database Fabric — Python 3.12+
# Factory pattern for multi-provider database access with dynamic documents
# Same interface as .NET IDatabaseProvider — see SKILL.md
from abc import ABC, abstractmethod
from enum import Enum
from typing import Any, Optional
from dataclasses import dataclass, field
from core_interfaces import DataProcessResult, ok, fail, ObjectProcessor, SearchCondition, DatabaseType
import time, uuid, logging

logger = logging.getLogger(__name__)

@dataclass
class SearchResult:
    documents: list[dict[str, Any]] = field(default_factory=list)
    total: int = 0
    page_size: int = 10
    has_next: bool = False

@dataclass
class BulkResult:
    succeeded: int = 0
    failed: int = 0
    errors: list[str] = field(default_factory=list)

class IDatabaseProvider(ABC):
    @property
    @abstractmethod
    def provider_type(self) -> DatabaseType: ...
    @abstractmethod
    async def connect(self) -> None: ...
    @abstractmethod
    async def disconnect(self) -> None: ...
    @abstractmethod
    async def get_by_id(self, index: str, id: str) -> DataProcessResult: ...
    @abstractmethod
    async def store(self, index: str, id: str | None, document: Any, parse: bool = True) -> DataProcessResult: ...
    @abstractmethod
    async def delete(self, index: str, id: str) -> DataProcessResult: ...
    @abstractmethod
    async def search(self, index: str, filter_obj: Any, size: int = 10, offset: int = 0) -> DataProcessResult: ...
    @abstractmethod
    async def bulk_upsert(self, index: str, items: list[tuple[str, Any]]) -> DataProcessResult: ...
    @abstractmethod
    async def health_check(self) -> bool: ...

class BaseDatabaseProvider(IDatabaseProvider):
    """Base with ObjectProcessor (Genie DNA) for dynamic document handling."""
    def __init__(self, connection_string: str):
        self.connection_string = connection_string
        self.processor = ObjectProcessor()
        self._connected = False

    def _idx(self, index: str) -> str:
        return index.lower().replace(" ", "-")

    def _parse_doc(self, doc: Any, parse: bool) -> dict:
        return self.processor.parse_document(doc) if parse else (doc if isinstance(doc, dict) else {})

    def _build_filters(self, filter_obj: Any) -> list[SearchCondition]:
        return self.processor.build_query_filters(filter_obj) if filter_obj else []

    @staticmethod
    def _gen_id() -> str:
        return f"{int(time.time() * 1000)}_{uuid.uuid4().hex[:9]}"

# ─── Elasticsearch Provider ────────────────────────────
class ElasticsearchProvider(BaseDatabaseProvider):
    @property
    def provider_type(self) -> DatabaseType: return DatabaseType.ELASTICSEARCH

    async def connect(self): self._connected = True
    async def disconnect(self): self._connected = False
    async def get_by_id(self, index, id): return ok({"_id": id})
    async def store(self, index, id, document, parse=True):
        doc = self._parse_doc(document, parse)
        doc_id = id or self._gen_id()
        return ok(doc_id)
    async def delete(self, index, id): return ok(True)
    async def search(self, index, filter_obj, size=10, offset=0):
        conditions = self._build_filters(filter_obj)  # Genie DNA: empty fields skipped
        return ok(SearchResult(documents=[], total=0, page_size=size))
    async def bulk_upsert(self, index, items):
        return ok(BulkResult(succeeded=len(items), failed=0))
    async def health_check(self): return self._connected

# ─── MongoDB Provider ──────────────────────────────────
class MongoDbProvider(BaseDatabaseProvider):
    def __init__(self, connection_string: str, db_name: str = "xiigen"):
        super().__init__(connection_string)
        self.db_name = db_name

    @property
    def provider_type(self) -> DatabaseType: return DatabaseType.MONGODB

    async def connect(self): self._connected = True
    async def disconnect(self): self._connected = False
    async def get_by_id(self, index, id): return ok({"_id": id})
    async def store(self, index, id, document, parse=True):
        doc = self._parse_doc(document, parse)
        return ok(id or self._gen_id())
    async def delete(self, index, id): return ok(True)
    async def search(self, index, filter_obj, size=10, offset=0):
        conditions = self._build_filters(filter_obj)
        return ok(SearchResult(documents=[], total=0, page_size=size))
    async def bulk_upsert(self, index, items):
        return ok(BulkResult(succeeded=len(items), failed=0))
    async def health_check(self): return self._connected

# ─── PostgreSQL Provider (JSONB) ───────────────────────
class PostgreSqlProvider(BaseDatabaseProvider):
    @property
    def provider_type(self) -> DatabaseType: return DatabaseType.POSTGRESQL

    async def connect(self): self._connected = True
    async def disconnect(self): self._connected = False
    async def get_by_id(self, index, id): return ok({"_id": id})
    async def store(self, index, id, document, parse=True):
        doc = self._parse_doc(document, parse)
        return ok(id or self._gen_id())
    async def delete(self, index, id): return ok(True)
    async def search(self, index, filter_obj, size=10, offset=0):
        conditions = self._build_filters(filter_obj)
        return ok(SearchResult(documents=[], total=0, page_size=size))
    async def bulk_upsert(self, index, items):
        return ok(BulkResult(succeeded=len(items), failed=0))
    async def health_check(self): return self._connected

# ─── Database Fabric: factory + resolver ───────────────
class DatabaseFabric:
    def __init__(self):
        self._providers: dict[str, IDatabaseProvider] = {}
        self._default: str | None = None

    def register(self, name: str, provider: IDatabaseProvider):
        self._providers[name.lower()] = provider
        logger.info("Registered DB provider: %s (%s)", name, provider.provider_type)

    def set_default(self, name: str): self._default = name.lower()

    def resolve(self, name: str | None = None) -> IDatabaseProvider:
        key = (name or self._default or "").lower()
        if not key: raise ValueError("No default provider configured")
        if key not in self._providers:
            raise KeyError(f"Provider '{name}' not registered. Available: {list(self._providers.keys())}")
        return self._providers[key]

    def resolve_by_type(self, db_type: DatabaseType) -> IDatabaseProvider:
        for p in self._providers.values():
            if p.provider_type == db_type: return p
        raise KeyError(f"No provider of type {db_type}")

    async def health_check_all(self) -> dict[str, bool]:
        results = {}
        for name, p in self._providers.items():
            try: results[name] = await p.health_check()
            except: results[name] = False
        return results

    async def connect_all(self):
        for p in self._providers.values(): await p.connect()
