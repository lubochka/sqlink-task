// Skill 05: Database Fabric — Rust
// Factory pattern for multi-provider database access with dynamic documents
// Same interface as .NET IDatabaseProvider — see SKILL.md
use std::collections::HashMap;
use std::sync::Arc;
use tokio::sync::RwLock;
use serde_json::Value;
use crate::core_interfaces::*;

// ─── IDatabaseProvider trait ───────────────────────────
#[async_trait::async_trait]
pub trait IDatabaseProvider: Send + Sync {
    fn provider_type(&self) -> DatabaseType;
    async fn connect(&mut self) -> Result<(), String>;
    async fn disconnect(&mut self) -> Result<(), String>;
    async fn get_by_id(&self, index: &str, id: &str) -> DataProcessResult<HashMap<String, Value>>;
    async fn store(&self, index: &str, id: Option<&str>, document: Value, parse: bool) -> DataProcessResult<String>;
    async fn delete(&self, index: &str, id: &str) -> DataProcessResult<bool>;
    async fn search(&self, index: &str, filter: Option<Value>, size: usize, from: usize) -> DataProcessResult<SearchResult>;
    async fn bulk_upsert(&self, index: &str, items: Vec<(String, Value)>) -> DataProcessResult<BulkResult>;
    async fn health_check(&self) -> bool;
}

#[derive(Debug, Clone)]
pub struct SearchResult {
    pub documents: Vec<HashMap<String, Value>>,
    pub total: u64,
    pub page_size: usize,
    pub has_next: bool,
}

#[derive(Debug, Clone)]
pub struct BulkResult {
    pub succeeded: usize,
    pub failed: usize,
    pub errors: Vec<String>,
}

// ─── Base provider helpers ─────────────────────────────
fn normalize_index(index: &str) -> String { index.to_lowercase().replace(' ', "-") }
fn gen_id() -> String {
    use std::time::{SystemTime, UNIX_EPOCH};
    let ts = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis();
    format!("{}_{}", ts, &uuid::Uuid::new_v4().to_string()[..9])
}

fn parse_doc(processor: &ObjectProcessor, document: Value, parse: bool) -> HashMap<String, Value> {
    if parse { processor.parse_document(document) } else {
        match document { Value::Object(m) => m.into_iter().collect(), _ => HashMap::new() }
    }
}

// ─── Elasticsearch Provider ────────────────────────────
pub struct ElasticsearchProvider {
    connection_string: String,
    processor: ObjectProcessor,
    connected: bool,
}

impl ElasticsearchProvider {
    pub fn new(connection_string: &str) -> Self {
        Self { connection_string: connection_string.to_string(), processor: ObjectProcessor, connected: false }
    }
}

#[async_trait::async_trait]
impl IDatabaseProvider for ElasticsearchProvider {
    fn provider_type(&self) -> DatabaseType { DatabaseType::Elasticsearch }
    async fn connect(&mut self) -> Result<(), String> { self.connected = true; Ok(()) }
    async fn disconnect(&mut self) -> Result<(), String> { self.connected = false; Ok(()) }

    async fn get_by_id(&self, _index: &str, id: &str) -> DataProcessResult<HashMap<String, Value>> {
        let mut doc = HashMap::new();
        doc.insert("_id".to_string(), Value::String(id.to_string()));
        DataProcessResult::ok(doc)
    }

    async fn store(&self, index: &str, id: Option<&str>, document: Value, parse: bool) -> DataProcessResult<String> {
        let _doc = parse_doc(&self.processor, document, parse);
        let doc_id = id.map(|s| s.to_string()).unwrap_or_else(gen_id);
        DataProcessResult::ok(doc_id)
    }

    async fn delete(&self, _index: &str, _id: &str) -> DataProcessResult<bool> { DataProcessResult::ok(true) }

    async fn search(&self, _index: &str, filter: Option<Value>, size: usize, _from: usize) -> DataProcessResult<SearchResult> {
        let _conditions = filter.map(|f| self.processor.build_query_filters(f)).unwrap_or_default();
        DataProcessResult::ok(SearchResult { documents: vec![], total: 0, page_size: size, has_next: false })
    }

    async fn bulk_upsert(&self, _index: &str, items: Vec<(String, Value)>) -> DataProcessResult<BulkResult> {
        DataProcessResult::ok(BulkResult { succeeded: items.len(), failed: 0, errors: vec![] })
    }

    async fn health_check(&self) -> bool { self.connected }
}

// ─── MongoDB Provider ──────────────────────────────────
pub struct MongoDbProvider {
    connection_string: String,
    db_name: String,
    processor: ObjectProcessor,
    connected: bool,
}

impl MongoDbProvider {
    pub fn new(connection_string: &str, db_name: &str) -> Self {
        Self { connection_string: connection_string.to_string(), db_name: db_name.to_string(), processor: ObjectProcessor, connected: false }
    }
}

#[async_trait::async_trait]
impl IDatabaseProvider for MongoDbProvider {
    fn provider_type(&self) -> DatabaseType { DatabaseType::MongoDB }
    async fn connect(&mut self) -> Result<(), String> { self.connected = true; Ok(()) }
    async fn disconnect(&mut self) -> Result<(), String> { self.connected = false; Ok(()) }
    async fn get_by_id(&self, _index: &str, id: &str) -> DataProcessResult<HashMap<String, Value>> {
        let mut doc = HashMap::new();
        doc.insert("_id".to_string(), Value::String(id.to_string()));
        DataProcessResult::ok(doc)
    }
    async fn store(&self, _index: &str, id: Option<&str>, document: Value, parse: bool) -> DataProcessResult<String> {
        let _doc = parse_doc(&self.processor, document, parse);
        DataProcessResult::ok(id.map(|s| s.to_string()).unwrap_or_else(gen_id))
    }
    async fn delete(&self, _index: &str, _id: &str) -> DataProcessResult<bool> { DataProcessResult::ok(true) }
    async fn search(&self, _index: &str, filter: Option<Value>, size: usize, _from: usize) -> DataProcessResult<SearchResult> {
        let _conditions = filter.map(|f| self.processor.build_query_filters(f)).unwrap_or_default();
        DataProcessResult::ok(SearchResult { documents: vec![], total: 0, page_size: size, has_next: false })
    }
    async fn bulk_upsert(&self, _index: &str, items: Vec<(String, Value)>) -> DataProcessResult<BulkResult> {
        DataProcessResult::ok(BulkResult { succeeded: items.len(), failed: 0, errors: vec![] })
    }
    async fn health_check(&self) -> bool { self.connected }
}

// ─── Database Fabric: factory + resolver ───────────────
pub struct DatabaseFabric {
    providers: Arc<RwLock<HashMap<String, Arc<dyn IDatabaseProvider>>>>,
    default_name: Option<String>,
}

impl DatabaseFabric {
    pub fn new() -> Self {
        Self { providers: Arc::new(RwLock::new(HashMap::new())), default_name: None }
    }

    pub async fn register(&self, name: &str, provider: Arc<dyn IDatabaseProvider>) {
        self.providers.write().await.insert(name.to_lowercase(), provider);
    }

    pub fn set_default(&mut self, name: &str) { self.default_name = Some(name.to_lowercase()); }

    pub async fn resolve(&self, name: Option<&str>) -> Result<Arc<dyn IDatabaseProvider>, String> {
        let key = name.map(|s| s.to_lowercase()).or(self.default_name.clone())
            .ok_or("No default provider configured")?;
        let providers = self.providers.read().await;
        providers.get(&key).cloned().ok_or(format!("Provider '{}' not registered", key))
    }

    pub async fn health_check_all(&self) -> HashMap<String, bool> {
        let providers = self.providers.read().await;
        let mut results = HashMap::new();
        for (name, p) in providers.iter() {
            results.insert(name.clone(), p.health_check().await);
        }
        results
    }
}
