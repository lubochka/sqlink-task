// Skill 05: Database Fabric — Java 21+ / Spring Boot
// Factory pattern for multi-provider database access with dynamic documents
// Same interface as .NET IDatabaseProvider — see SKILL.md
package com.xiigen.infrastructure.database;

import com.xiigen.core.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

// ─── IDatabaseProvider interface ───────────────────────
public interface IDatabaseProvider {
    DatabaseType getProviderType();
    void connect() throws Exception;
    void disconnect() throws Exception;
    DataProcessResult<Map<String, Object>> getById(String index, String id);
    DataProcessResult<String> store(String index, String id, Object document, boolean parse);
    DataProcessResult<Boolean> delete(String index, String id);
    DataProcessResult<SearchResult> search(String index, Object filter, int size, int from);
    DataProcessResult<BulkResult> bulkUpsert(String index, List<Map.Entry<String, Object>> items);
    boolean healthCheck();
}

// ─── Base with ObjectProcessor (Genie DNA) ─────────────
public abstract class BaseDatabaseProvider implements IDatabaseProvider {
    protected final String connectionString;
    protected final ObjectProcessor processor = new ObjectProcessor();
    protected boolean connected = false;
    protected static final Logger log = Logger.getLogger(BaseDatabaseProvider.class.getName());

    protected BaseDatabaseProvider(String connectionString) { this.connectionString = connectionString; }

    protected String normalizeIndex(String index) { return index.toLowerCase().replace(" ", "-"); }

    protected Map<String, Object> parseDoc(Object document, boolean parse) {
        if (!parse && document instanceof Map) return (Map<String, Object>) document;
        return processor.parseDocument(document);
    }

    protected List<SearchCondition> buildFilters(Object filter) {
        return filter != null ? processor.buildQueryFilters(filter) : Collections.emptyList();
    }

    protected String genId() { return System.currentTimeMillis() + "_" + UUID.randomUUID().toString().substring(0, 9); }
}

// ─── Elasticsearch Provider ────────────────────────────
public class ElasticsearchProvider extends BaseDatabaseProvider {
    public ElasticsearchProvider(String connectionString) { super(connectionString); }

    @Override public DatabaseType getProviderType() { return DatabaseType.ELASTICSEARCH; }
    @Override public void connect() { connected = true; }
    @Override public void disconnect() { connected = false; }

    @Override public DataProcessResult<Map<String, Object>> getById(String index, String id) {
        return DataProcessResult.ok(Map.of("_id", id));
    }

    @Override public DataProcessResult<String> store(String index, String id, Object document, boolean parse) {
        var doc = parseDoc(document, parse);
        var docId = id != null ? id : genId();
        return DataProcessResult.ok(docId);
    }

    @Override public DataProcessResult<Boolean> delete(String index, String id) { return DataProcessResult.ok(true); }

    @Override public DataProcessResult<SearchResult> search(String index, Object filter, int size, int from) {
        var conditions = buildFilters(filter); // Genie DNA: empty fields skipped
        return DataProcessResult.ok(new SearchResult(Collections.emptyList(), 0, size, false));
    }

    @Override public DataProcessResult<BulkResult> bulkUpsert(String index, List<Map.Entry<String, Object>> items) {
        return DataProcessResult.ok(new BulkResult(items.size(), 0, Collections.emptyList()));
    }

    @Override public boolean healthCheck() { return connected; }
}

// ─── MongoDB Provider ──────────────────────────────────
public class MongoDbProvider extends BaseDatabaseProvider {
    private final String dbName;
    public MongoDbProvider(String connectionString, String dbName) { super(connectionString); this.dbName = dbName; }
    @Override public DatabaseType getProviderType() { return DatabaseType.MONGODB; }
    @Override public void connect() { connected = true; }
    @Override public void disconnect() { connected = false; }
    @Override public DataProcessResult<Map<String, Object>> getById(String index, String id) { return DataProcessResult.ok(Map.of("_id", id)); }
    @Override public DataProcessResult<String> store(String index, String id, Object document, boolean parse) {
        var doc = parseDoc(document, parse);
        return DataProcessResult.ok(id != null ? id : genId());
    }
    @Override public DataProcessResult<Boolean> delete(String index, String id) { return DataProcessResult.ok(true); }
    @Override public DataProcessResult<SearchResult> search(String index, Object filter, int size, int from) {
        var conditions = buildFilters(filter);
        return DataProcessResult.ok(new SearchResult(Collections.emptyList(), 0, size, false));
    }
    @Override public DataProcessResult<BulkResult> bulkUpsert(String index, List<Map.Entry<String, Object>> items) {
        return DataProcessResult.ok(new BulkResult(items.size(), 0, Collections.emptyList()));
    }
    @Override public boolean healthCheck() { return connected; }
}

// ─── Search/Bulk Result Models ─────────────────────────
public record SearchResult(List<Map<String, Object>> documents, long total, int pageSize, boolean hasNext) {}
public record BulkResult(int succeeded, int failed, List<String> errors) {}

// ─── Database Fabric: factory + resolver ───────────────
public class DatabaseFabric {
    private final ConcurrentHashMap<String, IDatabaseProvider> providers = new ConcurrentHashMap<>();
    private String defaultName;

    public void register(String name, IDatabaseProvider provider) {
        providers.put(name.toLowerCase(), provider);
        log.info("Registered DB provider: " + name + " (" + provider.getProviderType() + ")");
    }

    public void setDefault(String name) { this.defaultName = name.toLowerCase(); }

    public IDatabaseProvider resolve(String name) {
        var key = (name != null ? name : defaultName);
        if (key == null) throw new IllegalStateException("No default provider configured");
        var p = providers.get(key.toLowerCase());
        if (p == null) throw new IllegalArgumentException("Provider '" + name + "' not registered. Available: " + providers.keySet());
        return p;
    }

    public IDatabaseProvider resolve() { return resolve(null); }

    public IDatabaseProvider resolveByType(DatabaseType type) {
        return providers.values().stream()
            .filter(p -> p.getProviderType() == type).findFirst()
            .orElseThrow(() -> new IllegalArgumentException("No provider of type " + type));
    }

    public Map<String, Boolean> healthCheckAll() {
        var results = new HashMap<String, Boolean>();
        providers.forEach((name, p) -> { try { results.put(name, p.healthCheck()); } catch (Exception e) { results.put(name, false); } });
        return results;
    }

    private static final Logger log = Logger.getLogger(DatabaseFabric.class.getName());
}
