---
name: database-fabric
description: Factory pattern for multi-provider database access. Swap ES/Mongo/PostgreSQL/Redis/MySQL/SQLServer via config with zero code changes.
triggers: database provider, db factory, switch database, multi-provider, DatabaseFabric, generic database, swap db
dependencies: [01-core-interfaces, 02-object-processor]
layer: L2-Infrastructure
genie-dna: All providers accept dynamic documents via ObjectProcessor. BuildSearchFilter skips empty fields across ALL backends.
---

# Skill 05: Database Fabric
## Factory Pattern for Multi-Provider Database Access

**Dependencies:** 01-core-interfaces, 02-object-processor
**Layer:** L2: Infrastructure
**Reference:** DataBase_Fabric.docx (full TypeScript implementation)

---

## Overview

Database Fabric is the **universal database layer** for XIIGen. It provides a single `IDatabaseProvider` interface that works identically across 6 database backends. You configure which backend to use, and the rest of the codebase never knows or cares which database is underneath.

**Core principle (Genie DNA):** All providers accept dynamic documents — no fixed schemas, no model classes, no migrations. Data goes through `ObjectProcessor.ParseObjectAlternative()` before storage, and queries use `BuildSearchFilter()` which automatically skips empty fields.

## When to Use

- Any time you need to store or retrieve data in XIIGen
- When a deployment needs to swap from Elasticsearch to MongoDB (or any other provider)
- When building a new microservice that needs data persistence
- When you want to query across providers with the same filter object

## Provider Comparison

| Provider | Best For | Dynamic Docs | Full-Text | Aggregations | Transactions |
|---|---|---|---|---|---|
| Elasticsearch | Search, analytics, logs | ✅ Native | ✅ Best | ✅ Best | ❌ |
| MongoDB | General purpose, flexible schema | ✅ Native | ✅ Atlas | ✅ Good | ✅ |
| PostgreSQL | Relational, ACID, complex joins | 🔧 JSONB | ✅ tsvector | ✅ SQL | ✅ Best |
| Redis | Cache, sessions, real-time | 🔧 JSON module | ❌ | ❌ | ❌ |
| MySQL | Legacy systems, simple CRUD | 🔧 JSON column | ✅ Basic | ✅ SQL | ✅ |
| SQL Server | Enterprise, .NET ecosystem | 🔧 NVARCHAR(MAX) | ✅ Basic | ✅ SQL | ✅ |

## Architecture

```
┌──────────────────────────────────────────────┐
│              DatabaseFabric                   │
│  ┌─────────────────────────────────────────┐ │
│  │ IDatabaseProvider                        │ │
│  │  connect() / disconnect()               │ │
│  │  getById() / store() / delete()         │ │
│  │  search(filter) / bulkUpsert()          │ │
│  │  aggregate()                            │ │
│  └────────┬────────┬────────┬──────────────┘ │
│           │        │        │                 │
│    ┌──────┴──┐ ┌───┴───┐ ┌─┴──────┐         │
│    │   ES    │ │ Mongo │ │ PgSQL  │ ...      │
│    └─────────┘ └───────┘ └────────┘          │
└──────────────────────────────────────────────┘
         ↑ All use ObjectProcessor for
           dynamic document handling
```

## API Reference

### IDatabaseProvider Interface

```csharp
public interface IDatabaseProvider
{
    DatabaseType ProviderType { get; }
    Task ConnectAsync(CancellationToken ct = default);
    Task DisconnectAsync(CancellationToken ct = default);
    Task<DataProcessResult<T>> GetByIdAsync<T>(string index, string id, CancellationToken ct = default);
    Task<DataProcessResult<string>> StoreAsync(string index, string id, object document, CancellationToken ct = default);
    Task<DataProcessResult<bool>> DeleteAsync(string index, string id, CancellationToken ct = default);
    Task<DataProcessResult<SearchResult>> SearchAsync(string index, object filter, SearchOptions options, CancellationToken ct = default);
    Task<DataProcessResult<BulkResult>> BulkUpsertAsync(string index, IEnumerable<(string id, object doc)> items, CancellationToken ct = default);
    Task<DataProcessResult<object>> AggregateAsync(string index, AggregationRequest request, CancellationToken ct = default);
    Task<bool> HealthCheckAsync(CancellationToken ct = default);
}
```

### DatabaseFabric Class

```csharp
// Resolve provider by type
var db = fabric.Resolve(DatabaseType.Elasticsearch);
await db.StoreAsync("users", "u1", new { name = "John", age = 30 });

// Resolve by config name
var db = fabric.Resolve("primary");

// Health check all providers
var health = await fabric.HealthCheckAllAsync();
```

## Configuration

```json
{
  "DatabaseFabric": {
    "Default": "elasticsearch",
    "Providers": {
      "elasticsearch": {
        "Type": "Elasticsearch",
        "ConnectionString": "http://localhost:9200"
      },
      "mongodb": {
        "Type": "MongoDB",
        "ConnectionString": "mongodb://localhost:27017",
        "Database": "xiigen"
      },
      "postgresql": {
        "Type": "PostgreSQL",
        "ConnectionString": "Host=localhost;Database=xiigen;Username=admin;Password=pass"
      }
    }
  }
}
```

## DI Registration

```csharp
services.AddXIIGenDatabaseFabric(config, builder =>
{
    builder.AddElasticsearch("primary", config["ES:Url"]);
    builder.AddMongoDB("secondary", config["Mongo:ConnectionString"], config["Mongo:Database"]);
    builder.SetDefault("primary");
});
```

## Genie DNA Integration

- **Dynamic Documents:** All `StoreAsync` calls run document through `ObjectProcessor.ParseObjectAlternative()` — no schema needed
- **Filter by non-empty:** All `SearchAsync` calls use `ObjectProcessor.BuildSearchFilter(filter)` — empty fields are automatically excluded
- **CreateQueryContainerList pattern:** The filter object can have any shape; only populated fields generate query conditions

## ES Indices

- `{service}-{entity}` — Per-service entity storage (e.g., `auth-users`, `flow-definitions`)
- Index auto-created on first write for ES and Mongo providers

## Test Scenarios

1. Store and retrieve a dynamic document with arbitrary fields
2. Search with partial filter (some fields null) — verify empty fields are skipped
3. Switch provider at runtime and verify same data operations work
4. Bulk upsert 1000 documents and verify all stored
5. Health check returns false when provider is unreachable
6. Concurrent writes from multiple threads — verify no data loss
