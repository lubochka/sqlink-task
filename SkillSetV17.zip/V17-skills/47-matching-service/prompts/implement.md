# Skill 47 — Matching Service: Implementation Prompt

## Overview
Implement a multi-criteria matching engine that computes compatibility scores between entities (user↔user, user↔event, user↔content, business↔business) using weighted scoring with configurable criteria. The service supports bidirectional computation, batch processing, and admin-configurable weight tables.

## Phase 1: Configuration & Models
1. Create `MatchingConfig`: matchResultsIndex ("match-results"), matchProfilesIndex ("match-profiles"), matchConfigIndex ("match-config"), defaultMinScore (0.3), defaultTopN (20), batchSize (100), defaultBidirectionalStrategy ("average")
2. All returns use `DataProcessResult<T>` (DNA-5)
3. **DNA-1**: Match profiles and results are `Dictionary<string, object>` — NOT typed models

## Phase 2: Similarity Functions (MACHINE)
Implement 4 core similarity functions, all pure and stateless:
1. `Jaccard(setA, setB)` — |A∩B| / |A∪B| for interests, goals, skills
2. `Exact(a, b)` — 1.0 if equal (case-insensitive), 0.0 otherwise for industry, category
3. `GeoDistance(locA, locB, maxKm)` — 1.0 - min(haversine(A,B)/maxKm, 1.0) for location
4. `Range(a, b)` — 1.0 - |a-b|/max(a,b) for numeric fields like experience, company size
5. `Compute(type, aVal, bVal, config)` — dispatches to correct function by type string

Helper: Haversine formula for geodesic distance in km.
Helper: ExtractSet — normalizes arrays/strings/JSON to HashSet<string>.
Helper: ExtractLocation — extracts {lat, lng} from dict/JSON.

## Phase 3: Profile Management
1. **ExtractProfile**: accept entity data + entityType, assign profileId = "type-entityId", copy all fields except sensitive ones (password, token), store in match-profiles index
2. **GetProfile**: try user/event/business type prefixes, return first found
3. Profiles are dynamic documents — any fields the entity has become matchable criteria

## Phase 4: Match Computation (Core)
1. **ComputeMatch(A, B, matchType)**:
   - Load both profiles
   - Load criteria config for matchType (FREEDOM)
   - Extract criteria list: [(field, weight, similarityType, fieldConfig), ...]
   - Compute: score = Σ(weight × similarity(A.field, B.field)) / Σ(weight)
   - If bidirectional: compute reverse, then apply strategy (average or minimum)
   - Store result with matchId, score, status="pending", criteriaBreakdown
   - Publish MatchCalculated event
2. **FindMatches(entityId, matchType, topN)**:
   - Load source profile
   - Query all candidate profiles of target type
   - Score each candidate, filter by minScoreThreshold
   - Return top-N sorted by score descending
3. **BatchMatch(entityId, candidateIds, matchType)**:
   - Iterate candidates, call ComputeMatch for each
   - Publish BatchMatchComplete event with count

## Phase 5: Match Management
1. **AcceptMatch**: verify scope (userId matches entityIdA or entityIdB), set status="accepted", publish MatchAccepted
2. **DeclineMatch**: verify scope, set status="declined", publish MatchDeclined
3. **ListMatches**: paginated query with BuildSearchFilter, always filtered by entityId (scope)

## Phase 6: Configuration (FREEDOM)
1. **GetCriteriaConfig**: load from match-config index by matchType, fall back to defaults
2. **UpdateCriteriaConfig**: store as dynamic document with criteria weights, similarity types, thresholds
3. Config structure per matchType:
   ```json
   {
     "criteria": {
       "interests": { "weight": 0.30, "similarity": "jaccard" },
       "location": { "weight": 0.20, "similarity": "geo-distance", "maxDistanceKm": 50 },
       "industry": { "weight": 0.25, "similarity": "exact" }
     },
     "minScoreThreshold": 0.3,
     "bidirectional": true,
     "bidirectionalStrategy": "average"
   }
   ```

## Phase 7: Integration
1. DI registration with IDatabaseService, IQueueService, IObjectProcessor
2. Subscribe: UserProfileUpdated → re-extract + recalculate, QuestionnaireCompleted → extract profile, EventCreated → batch match users, ConnectionAccepted → boost scores
3. API: POST /match/compute, GET /match/{entityId}/find, POST /match/batch, PUT /match/{matchId}/accept

## DNA Compliance Checklist
- [ ] All data stored as `Dictionary<string, object>` (DNA-1)
- [ ] All queries use `BuildSearchFilter` with empty-field skipping (DNA-2)
- [ ] All operations return `DataProcessResult<T>` (DNA-5)
- [ ] Scope isolation: users see only their own matches (DNA-SCOPE)
- [ ] Criteria weights and thresholds are dynamic config documents (DNA-FREEDOM)
- [ ] Events published for match computation, accept, decline (DNA-7)
- [ ] No typed model classes for profiles or match results

## Test Scenarios
1. Two users with 60% interest overlap, same industry → weighted score ~0.58 with default weights
2. Bidirectional: A→B = 0.8, B→A = 0.6 → average strategy returns 0.7
3. GeoDistance: 10km apart with maxKm=50 → location similarity = 0.8
4. Config update: increase interest weight → recalculated scores reflect change
5. FindMatches: returns candidates above threshold, sorted by score desc
6. Scope: user A cannot accept/decline user B's matches
7. BatchMatch: 100 candidates → results + BatchMatchComplete event

## Abstraction Prompt (for AI agents)
> Given a matching engine that computes weighted compatibility between diverse entity types,
> extract these patterns: (1) Pluggable similarity functions dispatched by type, (2) Weighted
> multi-criteria aggregation with configurable weights, (3) Bidirectional scoring with
> strategy selection, (4) Dynamic profile extraction from arbitrary entity data, (5) Batch
> computation with event-driven notification. These patterns apply to: recommendation engines,
> search ranking, fraud detection scoring, resource allocation, talent matching, content
> personalization, and any multi-factor decision system.
