// XIIGen Matching Service — Skill 47 | Java/Spring Boot Alternative
// Multi-criteria matching with weighted scoring, bidirectional computation
// Genie DNA: DNA-1 (Map<String,Object>), DNA-2 (buildSearchFilter), DNA-5 (DataProcessResult)

package com.xiigen.services.matching;

import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

// ─── Configuration ──────────────────────────────────────────────
record MatchingConfig(
    String matchResultsIndex, String matchProfilesIndex, String matchConfigIndex,
    double defaultMinScore, int defaultTopN, int batchSize, String defaultBidirectionalStrategy
) {
    static MatchingConfig defaults() {
        return new MatchingConfig("match-results", "match-profiles", "match-config", 0.3, 20, 100, "average");
    }
}

record DataProcessResult<T>(boolean success, T data, String message) {
    static <T> DataProcessResult<T> ok(T d, String m) { return new DataProcessResult<>(true, d, m); }
    static <T> DataProcessResult<T> error(String m) { return new DataProcessResult<>(false, null, m); }
}

record CriterionDef(String field, double weight, String similarity, Map<String, Object> config) {}

// ─── Interfaces ─────────────────────────────────────────────────
interface IDatabaseService {
    void upsert(String index, String id, Map<String, Object> doc);
    Map<String, Object> getById(String index, String id);
    List<Map<String, Object>> query(String index, Map<String, Object> filter, int limit, int offset);
}

interface IQueueService { void publish(String channel, Map<String, Object> message); }
interface IObjectProcessor {
    Map<String, Object> parseObjectAlternative(Object obj);
    Map<String, Object> buildSearchFilter(Map<String, Object> filter);
}

// ─── Similarity Functions ───────────────────────────────────────
class SimilarityFunctions {
    static double jaccard(Object aVal, Object bVal) {
        var setA = toStringSet(aVal);
        var setB = toStringSet(bVal);
        if (setA.isEmpty() && setB.isEmpty()) return 0;
        var intersection = new HashSet<>(setA); intersection.retainAll(setB);
        var union = new HashSet<>(setA); union.addAll(setB);
        return union.isEmpty() ? 0 : (double) intersection.size() / union.size();
    }

    static double exact(Object a, Object b) {
        return String.valueOf(a != null ? a : "").equalsIgnoreCase(String.valueOf(b != null ? b : "")) ? 1.0 : 0.0;
    }

    static double geoDistance(Object aVal, Object bVal, double maxKm) {
        var a = extractLoc(aVal); var b = extractLoc(bVal);
        if (a == null || b == null) return 0;
        double dist = haversineKm(a[0], a[1], b[0], b[1]);
        return Math.max(0, 1.0 - dist / maxKm);
    }

    static double rangeSim(Object aVal, Object bVal) {
        double a = toDouble(aVal), b = toDouble(bVal);
        if (a == 0 && b == 0) return 1;
        double max = Math.max(Math.abs(a), Math.abs(b));
        return max == 0 ? 1 : 1.0 - Math.abs(a - b) / max;
    }

    static double compute(String type, Object a, Object b, Map<String, Object> cfg) {
        return switch (type.toLowerCase()) {
            case "jaccard" -> jaccard(a, b);
            case "exact" -> exact(a, b);
            case "geo-distance", "geodistance" -> geoDistance(a, b, cfg != null ? toDouble(cfg.get("maxDistanceKm")) : 50);
            case "range" -> rangeSim(a, b);
            default -> exact(a, b);
        };
    }

    @SuppressWarnings("unchecked")
    private static Set<String> toStringSet(Object val) {
        if (val instanceof Collection<?> c) return c.stream().map(String::valueOf).collect(Collectors.toSet());
        if (val instanceof String s) return Set.of(s);
        return Set.of();
    }

    @SuppressWarnings("unchecked")
    private static double[] extractLoc(Object val) {
        if (val instanceof Map<?, ?> m) {
            try { return new double[]{toDouble(m.get("lat")), toDouble(m.get("lng"))}; } catch (Exception e) { return null; }
        }
        return null;
    }

    static double toDouble(Object v) {
        if (v instanceof Number n) return n.doubleValue();
        try { return Double.parseDouble(String.valueOf(v)); } catch (Exception e) { return 0; }
    }

    private static double haversineKm(double lat1, double lng1, double lat2, double lng2) {
        double R = 6371, dLat = Math.toRadians(lat2 - lat1), dLng = Math.toRadians(lng2 - lng1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                   Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                   Math.sin(dLng / 2) * Math.sin(dLng / 2);
        return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    }
}

// ─── Service Implementation ─────────────────────────────────────
@Service
public class MatchingService {
    private static final Logger log = LoggerFactory.getLogger(MatchingService.class);
    private final IDatabaseService db;
    private final IQueueService queue;
    private final IObjectProcessor op;
    private final MatchingConfig config;

    public MatchingService(IDatabaseService db, IQueueService queue, IObjectProcessor op) {
        this(db, queue, op, MatchingConfig.defaults());
    }

    public MatchingService(IDatabaseService db, IQueueService queue, IObjectProcessor op, MatchingConfig config) {
        this.db = db; this.queue = queue; this.op = op; this.config = config;
    }

    // ─── Profile ────────────────────────────────────────────────

    public DataProcessResult<Map<String, Object>> extractProfile(Map<String, Object> entityData, String entityType) {
        try {
            var doc = op.parseObjectAlternative(entityData);
            String entityId = getString(doc, "id").isEmpty() ? getString(doc, "entityId") : getString(doc, "id");
            if (entityId.isEmpty()) return DataProcessResult.error("Missing entityId or id");

            var profile = new HashMap<String, Object>();
            profile.put("profileId", entityType + "-" + entityId);
            profile.put("entityId", entityId);
            profile.put("entityType", entityType);
            profile.put("extractedAt", Instant.now().toString());
            doc.forEach((k, v) -> { if (!Set.of("id", "password", "token").contains(k)) profile.put(k, v); });

            db.upsert(config.matchProfilesIndex(), profile.get("profileId").toString(), profile);
            return DataProcessResult.ok(profile, "Profile extracted");
        } catch (Exception e) { return DataProcessResult.error(e.getMessage()); }
    }

    public DataProcessResult<Map<String, Object>> getProfile(String entityId) {
        for (String type : List.of("user", "event", "business")) {
            try {
                var p = db.getById(config.matchProfilesIndex(), type + "-" + entityId);
                if (p != null) return DataProcessResult.ok(op.parseObjectAlternative(p), "Found");
            } catch (Exception ignored) {}
        }
        return DataProcessResult.error("Profile not found");
    }

    // ─── Match Computation ──────────────────────────────────────

    public DataProcessResult<Map<String, Object>> computeMatch(String idA, String idB, String matchType) {
        try {
            var pa = getProfile(idA); var pb = getProfile(idB);
            if (!pa.success()) return DataProcessResult.error("Profile A not found: " + idA);
            if (!pb.success()) return DataProcessResult.error("Profile B not found: " + idB);

            var criteriaConfig = loadCriteriaConfig(matchType);
            var criteria = extractCriteria(criteriaConfig);

            double score = computeWeightedScore(pa.data(), pb.data(), criteria);

            if (Boolean.TRUE.equals(criteriaConfig.get("bidirectional"))) {
                double reverse = computeWeightedScore(pb.data(), pa.data(), criteria);
                String strategy = getString(criteriaConfig, "bidirectionalStrategy");
                score = "minimum".equals(strategy) ? Math.min(score, reverse) : (score + reverse) / 2;
            }

            var result = new HashMap<String, Object>(Map.of(
                "matchId", "match-" + idA + "-" + idB + "-" + matchType,
                "entityIdA", idA, "entityIdB", idB, "matchType", matchType,
                "score", Math.round(score * 10000.0) / 10000.0,
                "status", "pending", "computedAt", Instant.now().toString()
            ));
            result.put("criteriaBreakdown", computeBreakdown(pa.data(), pb.data(), criteria));

            db.upsert(config.matchResultsIndex(), result.get("matchId").toString(), result);
            queue.publish("match-events", Map.of(
                "eventType", "MatchCalculated", "matchId", result.get("matchId"),
                "entityIdA", idA, "entityIdB", idB, "score", result.get("score"),
                "timestamp", Instant.now().toString()));
            return DataProcessResult.ok(result, "Match computed");
        } catch (Exception e) { return DataProcessResult.error(e.getMessage()); }
    }

    public DataProcessResult<List<Map<String, Object>>> findMatches(String entityId, String matchType, int topN) {
        try {
            topN = Math.max(1, Math.min(topN, 100));
            String targetType = matchType.contains("-") ? matchType.substring(matchType.lastIndexOf('-') + 1) : "user";
            var filter = op.buildSearchFilter(Map.of("entityType", targetType));
            var candidates = db.query(config.matchProfilesIndex(), filter, config.batchSize(), 0);

            var criteriaConfig = loadCriteriaConfig(matchType);
            var criteria = extractCriteria(criteriaConfig);
            double minScore = SimilarityFunctions.toDouble(criteriaConfig.getOrDefault("minScoreThreshold", config.defaultMinScore()));

            var source = getProfile(entityId);
            if (!source.success()) return DataProcessResult.error("Source profile not found: " + entityId);

            List<Map<String, Object>> results = new ArrayList<>();
            for (var cand : candidates != null ? candidates : List.<Map<String, Object>>of()) {
                var parsed = op.parseObjectAlternative(cand);
                String cid = getString(parsed, "entityId");
                if (cid.equals(entityId)) continue;
                double score = computeWeightedScore(source.data(), parsed, criteria);
                if (score >= minScore)
                    results.add(Map.of("entityId", cid, "score", Math.round(score * 10000.0) / 10000.0, "matchType", matchType));
            }

            results.sort((a, b) -> Double.compare(SimilarityFunctions.toDouble(b.get("score")), SimilarityFunctions.toDouble(a.get("score"))));
            var top = results.stream().limit(topN).collect(Collectors.toList());
            return DataProcessResult.ok(top, "Found " + top.size() + " matches");
        } catch (Exception e) { return DataProcessResult.error(e.getMessage()); }
    }

    public DataProcessResult<List<Map<String, Object>>> batchMatch(String entityId, List<String> candidateIds, String matchType) {
        List<Map<String, Object>> results = new ArrayList<>();
        for (String cid : candidateIds) {
            var r = computeMatch(entityId, cid, matchType);
            if (r.success()) results.add(r.data());
        }
        queue.publish("match-events", Map.of("eventType", "BatchMatchComplete", "entityId", entityId,
            "matchCount", results.size(), "timestamp", Instant.now().toString()));
        return DataProcessResult.ok(results, "Batch computed " + results.size() + "/" + candidateIds.size());
    }

    // ─── Management ─────────────────────────────────────────────

    public DataProcessResult<Boolean> acceptMatch(String userId, String matchId) {
        return updateStatus(userId, matchId, "accepted", "MatchAccepted");
    }

    public DataProcessResult<Boolean> declineMatch(String userId, String matchId) {
        return updateStatus(userId, matchId, "declined", "MatchDeclined");
    }

    private DataProcessResult<Boolean> updateStatus(String userId, String matchId, String status, String eventType) {
        try {
            var item = db.getById(config.matchResultsIndex(), matchId);
            if (item == null) return DataProcessResult.error("Match not found");
            var parsed = op.parseObjectAlternative(item);
            if (!userId.equals(getString(parsed, "entityIdA")) && !userId.equals(getString(parsed, "entityIdB")))
                return DataProcessResult.error("Access denied — scope mismatch");
            parsed.put("status", status);
            parsed.put(status + "By", userId);
            parsed.put(status + "At", Instant.now().toString());
            db.upsert(config.matchResultsIndex(), matchId, parsed);
            queue.publish("match-events", Map.of("eventType", eventType, "matchId", matchId, status + "By", userId));
            return DataProcessResult.ok(true, "Match " + status);
        } catch (Exception e) { return DataProcessResult.error(e.getMessage()); }
    }

    public DataProcessResult<List<Map<String, Object>>> listMatches(String entityId, Map<String, Object> filter, int page, int pageSize) {
        try {
            pageSize = Math.max(1, Math.min(pageSize, 100));
            var base = new HashMap<String, Object>(); base.put("entityIdA", entityId);
            if (filter != null) base.putAll(filter);
            var results = db.query(config.matchResultsIndex(), op.buildSearchFilter(base), pageSize, page * pageSize);
            return DataProcessResult.ok((results != null ? results : List.<Map<String, Object>>of()).stream()
                .map(op::parseObjectAlternative).collect(Collectors.toList()), "Listed");
        } catch (Exception e) { return DataProcessResult.error(e.getMessage()); }
    }

    // ─── Config ─────────────────────────────────────────────────

    public DataProcessResult<Map<String, Object>> getCriteriaConfig(String matchType) {
        return DataProcessResult.ok(loadCriteriaConfig(matchType), "Config loaded");
    }

    public DataProcessResult<Map<String, Object>> updateCriteriaConfig(String matchType, Map<String, Object> cfg) {
        try {
            var doc = op.parseObjectAlternative(cfg);
            doc.put("configId", "match-criteria-" + matchType);
            doc.put("matchType", matchType);
            doc.put("updatedAt", Instant.now().toString());
            db.upsert(config.matchConfigIndex(), doc.get("configId").toString(), doc);
            return DataProcessResult.ok(doc, "Config updated");
        } catch (Exception e) { return DataProcessResult.error(e.getMessage()); }
    }

    // ─── Scoring Engine ─────────────────────────────────────────

    private double computeWeightedScore(Map<String, Object> a, Map<String, Object> b, List<CriterionDef> criteria) {
        double tw = 0, ws = 0;
        for (var c : criteria) {
            Object av = a.get(c.field()), bv = b.get(c.field());
            if (av == null && bv == null) continue;
            double sim = SimilarityFunctions.compute(c.similarity(), av, bv, c.config());
            ws += c.weight() * sim; tw += c.weight();
        }
        return tw == 0 ? 0 : ws / tw;
    }

    private Map<String, Object> computeBreakdown(Map<String, Object> a, Map<String, Object> b, List<CriterionDef> criteria) {
        var bd = new HashMap<String, Object>();
        for (var c : criteria) {
            double sim = SimilarityFunctions.compute(c.similarity(), a.get(c.field()), b.get(c.field()), c.config());
            bd.put(c.field(), Map.of("similarity", Math.round(sim * 10000.0) / 10000.0, "weight", c.weight(), "weighted", Math.round(sim * c.weight() * 10000.0) / 10000.0));
        }
        return bd;
    }

    @SuppressWarnings("unchecked")
    private List<CriterionDef> extractCriteria(Map<String, Object> config) {
        Object raw = config.get("criteria");
        if (raw instanceof Map<?, ?> m) {
            return m.entrySet().stream().map(e -> {
                var cfg = op.parseObjectAlternative(e.getValue());
                return new CriterionDef(e.getKey().toString(), SimilarityFunctions.toDouble(cfg.getOrDefault("weight", 1.0)),
                    getString(cfg, "similarity").isEmpty() ? "exact" : getString(cfg, "similarity"), cfg);
            }).collect(Collectors.toList());
        }
        return List.of(
            new CriterionDef("interests", 0.3, "jaccard", null),
            new CriterionDef("location", 0.2, "geo-distance", Map.of("maxDistanceKm", 50.0)),
            new CriterionDef("industry", 0.25, "exact", null),
            new CriterionDef("goals", 0.15, "jaccard", null),
            new CriterionDef("companySize", 0.1, "range", null));
    }

    private Map<String, Object> loadCriteriaConfig(String matchType) {
        try {
            var c = db.getById(config.matchConfigIndex(), "match-criteria-" + matchType);
            if (c != null) return op.parseObjectAlternative(c);
        } catch (Exception ignored) {}
        return new HashMap<>(Map.of("matchType", matchType, "minScoreThreshold", config.defaultMinScore(),
            "bidirectional", matchType.equals("user-user"), "bidirectionalStrategy", config.defaultBidirectionalStrategy()));
    }

    private String getString(Map<String, Object> m, String key) {
        Object v = m.get(key); return v != null ? v.toString() : "";
    }
}
