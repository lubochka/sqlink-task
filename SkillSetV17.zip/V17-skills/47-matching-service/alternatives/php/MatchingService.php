<?php
// XIIGen Matching Service — Skill 47 | PHP/Laravel Alternative
// Multi-criteria matching engine with weighted scoring, bidirectional computation
// Genie DNA: DNA-1 (array), DNA-2 (buildSearchFilter), DNA-5 (DataProcessResult)

namespace XIIGen\Services\Matching;

use Illuminate\Support\Str;
use Carbon\Carbon;

// ─── Configuration ──────────────────────────────────────────────
class MatchingConfig
{
    public function __construct(
        public string $matchResultsIndex = 'match-results',
        public string $matchProfilesIndex = 'match-profiles',
        public string $matchConfigIndex = 'match-config',
        public float $defaultMinScore = 0.3,
        public int $defaultTopN = 20,
        public int $batchSize = 100,
        public string $defaultBidirectionalStrategy = 'average',
    ) {}
}

// ─── Data Process Result (DNA-5) ────────────────────────────────
class DataProcessResult
{
    public function __construct(
        public bool $success,
        public mixed $data = null,
        public string $message = '',
    ) {}

    public static function ok(mixed $data, string $message = ''): self
    {
        return new self(true, $data, $message);
    }

    public static function error(string $message): self
    {
        return new self(false, null, $message);
    }
}

// ─── Interfaces (Genie DNA) ────────────────────────────────────
interface IDatabaseService
{
    public function upsert(string $index, string $id, array $doc): void;
    public function getById(string $index, string $id): ?array;
    public function query(string $index, array $filter, int $limit, int $offset): array;
    public function count(string $index, array $filter): int;
    public function delete(string $index, string $id): void;
}

interface IQueueService
{
    public function publish(string $channel, array $message): void;
}

interface IObjectProcessor
{
    public function parseObjectAlternative(mixed $obj): array;
    public function buildSearchFilter(array $filter): array;
}

// ─── Similarity Functions ───────────────────────────────────────
class SimilarityFunctions
{
    public static function jaccard(mixed $aVal, mixed $bVal): float
    {
        $setA = self::extractSet($aVal);
        $setB = self::extractSet($bVal);
        if (empty($setA) && empty($setB)) return 0.0;
        $intersection = count(array_intersect($setA, $setB));
        $union = count(array_unique(array_merge($setA, $setB)));
        return $union === 0 ? 0.0 : $intersection / $union;
    }

    public static function exact(mixed $aVal, mixed $bVal): float
    {
        $a = is_string($aVal) ? $aVal : (string)($aVal ?? '');
        $b = is_string($bVal) ? $bVal : (string)($bVal ?? '');
        return strtolower($a) === strtolower($b) ? 1.0 : 0.0;
    }

    public static function geoDistance(mixed $aVal, mixed $bVal, float $maxDistanceKm = 50.0): float
    {
        $locA = self::extractLocation($aVal);
        $locB = self::extractLocation($bVal);
        if ($locA === null || $locB === null) return 0.0;

        $distance = self::haversineKm($locA['lat'], $locA['lng'], $locB['lat'], $locB['lng']);
        return max(0.0, 1.0 - $distance / $maxDistanceKm);
    }

    public static function range(mixed $aVal, mixed $bVal): float
    {
        $a = (float)($aVal ?? 0);
        $b = (float)($bVal ?? 0);
        if ($a == 0 && $b == 0) return 1.0;
        $maxVal = max(abs($a), abs($b));
        return $maxVal == 0 ? 1.0 : 1.0 - abs($a - $b) / $maxVal;
    }

    public static function compute(string $type, mixed $aVal, mixed $bVal, ?array $config = null): float
    {
        return match (strtolower($type)) {
            'jaccard' => self::jaccard($aVal, $bVal),
            'exact' => self::exact($aVal, $bVal),
            'geo-distance', 'geodistance' => self::geoDistance(
                $aVal, $bVal, (float)($config['maxDistanceKm'] ?? 50.0)
            ),
            'range' => self::range($aVal, $bVal),
            default => self::exact($aVal, $bVal),
        };
    }

    private static function extractSet(mixed $val): array
    {
        if (is_array($val)) return array_values(array_filter(array_map('strval', $val)));
        if (is_string($val) && $val !== '') return [$val];
        return [];
    }

    private static function extractLocation(mixed $val): ?array
    {
        if (is_array($val) && isset($val['lat'], $val['lng'])) {
            return ['lat' => (float)$val['lat'], 'lng' => (float)$val['lng']];
        }
        return null;
    }

    private static function haversineKm(float $lat1, float $lng1, float $lat2, float $lng2): float
    {
        $R = 6371.0;
        $dLat = deg2rad($lat2 - $lat1);
        $dLng = deg2rad($lng2 - $lng1);
        $a = sin($dLat / 2) ** 2 +
             cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLng / 2) ** 2;
        return $R * 2 * atan2(sqrt($a), sqrt(1 - $a));
    }
}

// ─── Service Interface ──────────────────────────────────────────
interface IMatchingService
{
    public function extractProfile(array $entityData, string $entityType): DataProcessResult;
    public function getProfile(string $entityId): DataProcessResult;

    public function computeMatch(string $entityIdA, string $entityIdB, string $matchType): DataProcessResult;
    public function findMatches(string $entityId, string $matchType, int $topN): DataProcessResult;
    public function batchMatch(string $entityId, array $candidateIds, string $matchType): DataProcessResult;

    public function acceptMatch(string $userId, string $matchId): DataProcessResult;
    public function declineMatch(string $userId, string $matchId): DataProcessResult;
    public function listMatches(string $entityId, ?array $filter, int $page, int $pageSize): DataProcessResult;

    public function getCriteriaConfig(string $matchType): DataProcessResult;
    public function updateCriteriaConfig(string $matchType, array $config): DataProcessResult;
}

// ─── Service Implementation ─────────────────────────────────────
class MatchingService implements IMatchingService
{
    public function __construct(
        private IDatabaseService $db,
        private IQueueService $queue,
        private IObjectProcessor $objectProcessor,
        private MatchingConfig $config = new MatchingConfig(),
    ) {}

    // ─── Profile ────────────────────────────────────────────────

    public function extractProfile(array $entityData, string $entityType): DataProcessResult
    {
        try {
            $doc = $this->objectProcessor->parseObjectAlternative($entityData);
            $entityId = $doc['id'] ?? $doc['entityId'] ?? '';
            if (empty($entityId)) {
                return DataProcessResult::error('Missing entityId or id');
            }

            $profile = [
                'profileId' => "{$entityType}-{$entityId}",
                'entityId' => $entityId,
                'entityType' => $entityType,
                'extractedAt' => Carbon::now()->toISOString(),
            ];

            // DNA-1: Copy all fields dynamically
            foreach ($doc as $key => $value) {
                if (in_array($key, ['id', 'password', 'token'], true)) continue;
                $profile[$key] = $value;
            }

            $this->db->upsert($this->config->matchProfilesIndex, $profile['profileId'], $profile);
            return DataProcessResult::ok($profile, 'Profile extracted');
        } catch (\Throwable $e) {
            return DataProcessResult::error($e->getMessage());
        }
    }

    public function getProfile(string $entityId): DataProcessResult
    {
        try {
            foreach (['user', 'event', 'business'] as $type) {
                $profile = $this->db->getById($this->config->matchProfilesIndex, "{$type}-{$entityId}");
                if ($profile !== null) {
                    return DataProcessResult::ok($this->objectProcessor->parseObjectAlternative($profile));
                }
            }
            return DataProcessResult::error('Profile not found');
        } catch (\Throwable $e) {
            return DataProcessResult::error($e->getMessage());
        }
    }

    // ─── Match Computation ──────────────────────────────────────

    public function computeMatch(string $entityIdA, string $entityIdB, string $matchType): DataProcessResult
    {
        try {
            $profileA = $this->getProfile($entityIdA);
            $profileB = $this->getProfile($entityIdB);
            if (!$profileA->success) return DataProcessResult::error("Profile A not found: {$entityIdA}");
            if (!$profileB->success) return DataProcessResult::error("Profile B not found: {$entityIdB}");

            $criteriaConfig = $this->loadCriteriaConfig($matchType);
            $criteria = $this->extractCriteria($criteriaConfig);

            $score = $this->computeWeightedScore($profileA->data, $profileB->data, $criteria);

            // Bidirectional
            $bidirectional = (bool)($criteriaConfig['bidirectional'] ?? false);
            if ($bidirectional) {
                $reverseScore = $this->computeWeightedScore($profileB->data, $profileA->data, $criteria);
                $strategy = $criteriaConfig['bidirectionalStrategy'] ?? 'average';
                $score = $strategy === 'minimum'
                    ? min($score, $reverseScore)
                    : ($score + $reverseScore) / 2.0;
            }

            $matchResult = [
                'matchId' => "match-{$entityIdA}-{$entityIdB}-{$matchType}",
                'entityIdA' => $entityIdA,
                'entityIdB' => $entityIdB,
                'matchType' => $matchType,
                'score' => round($score, 4),
                'status' => 'pending',
                'criteriaBreakdown' => $this->computeBreakdown($profileA->data, $profileB->data, $criteria),
                'computedAt' => Carbon::now()->toISOString(),
            ];

            $this->db->upsert($this->config->matchResultsIndex, $matchResult['matchId'], $matchResult);

            $this->queue->publish('match-events', [
                'eventType' => 'MatchCalculated',
                'matchId' => $matchResult['matchId'],
                'entityIdA' => $entityIdA,
                'entityIdB' => $entityIdB,
                'score' => $matchResult['score'],
                'matchType' => $matchType,
                'timestamp' => Carbon::now()->toISOString(),
            ]);

            return DataProcessResult::ok($matchResult, 'Match computed');
        } catch (\Throwable $e) {
            return DataProcessResult::error($e->getMessage());
        }
    }

    public function findMatches(string $entityId, string $matchType, int $topN): DataProcessResult
    {
        try {
            $topN = max(1, min($topN, 100));
            $targetType = explode('-', $matchType);
            $targetType = end($targetType) ?: 'user';

            $filter = $this->objectProcessor->buildSearchFilter(['entityType' => $targetType]);
            $candidates = $this->db->query($this->config->matchProfilesIndex, $filter, $this->config->batchSize, 0);

            $criteriaConfig = $this->loadCriteriaConfig($matchType);
            $criteria = $this->extractCriteria($criteriaConfig);
            $minScore = (float)($criteriaConfig['minScoreThreshold'] ?? $this->config->defaultMinScore);

            $sourceProfile = $this->getProfile($entityId);
            if (!$sourceProfile->success) {
                return DataProcessResult::error("Source profile not found: {$entityId}");
            }

            $results = [];
            foreach ($candidates as $candidate) {
                $parsed = $this->objectProcessor->parseObjectAlternative($candidate);
                $candidateId = $parsed['entityId'] ?? '';
                if ($candidateId === $entityId) continue;

                $score = $this->computeWeightedScore($sourceProfile->data, $parsed, $criteria);
                if ($score >= $minScore) {
                    $results[] = [
                        'entityId' => $candidateId,
                        'score' => round($score, 4),
                        'matchType' => $matchType,
                        'breakdown' => $this->computeBreakdown($sourceProfile->data, $parsed, $criteria),
                    ];
                }
            }

            usort($results, fn($a, $b) => ($b['score'] ?? 0) <=> ($a['score'] ?? 0));
            $results = array_slice($results, 0, $topN);

            return DataProcessResult::ok($results, "Found " . count($results) . " matches above {$minScore}");
        } catch (\Throwable $e) {
            return DataProcessResult::error($e->getMessage());
        }
    }

    public function batchMatch(string $entityId, array $candidateIds, string $matchType): DataProcessResult
    {
        try {
            $results = [];
            foreach ($candidateIds as $candidateId) {
                $result = $this->computeMatch($entityId, $candidateId, $matchType);
                if ($result->success && $result->data !== null) {
                    $results[] = $result->data;
                }
            }

            $this->queue->publish('match-events', [
                'eventType' => 'BatchMatchComplete',
                'entityId' => $entityId,
                'matchType' => $matchType,
                'matchCount' => count($results),
                'timestamp' => Carbon::now()->toISOString(),
            ]);

            return DataProcessResult::ok($results, "Batch computed " . count($results) . "/" . count($candidateIds));
        } catch (\Throwable $e) {
            return DataProcessResult::error($e->getMessage());
        }
    }

    // ─── Management ─────────────────────────────────────────────

    public function acceptMatch(string $userId, string $matchId): DataProcessResult
    {
        try {
            $match = $this->db->getById($this->config->matchResultsIndex, $matchId);
            if (!$match) return DataProcessResult::error('Match not found');

            $parsed = $this->objectProcessor->parseObjectAlternative($match);
            if (($parsed['entityIdA'] ?? '') !== $userId && ($parsed['entityIdB'] ?? '') !== $userId) {
                return DataProcessResult::error('Access denied — scope mismatch');
            }

            $parsed['status'] = 'accepted';
            $parsed['acceptedBy'] = $userId;
            $parsed['acceptedAt'] = Carbon::now()->toISOString();
            $this->db->upsert($this->config->matchResultsIndex, $matchId, $parsed);

            $this->queue->publish('match-events', [
                'eventType' => 'MatchAccepted',
                'matchId' => $matchId,
                'acceptedBy' => $userId,
                'timestamp' => Carbon::now()->toISOString(),
            ]);

            return DataProcessResult::ok(true, 'Match accepted');
        } catch (\Throwable $e) {
            return DataProcessResult::error($e->getMessage());
        }
    }

    public function declineMatch(string $userId, string $matchId): DataProcessResult
    {
        try {
            $match = $this->db->getById($this->config->matchResultsIndex, $matchId);
            if (!$match) return DataProcessResult::error('Match not found');

            $parsed = $this->objectProcessor->parseObjectAlternative($match);
            if (($parsed['entityIdA'] ?? '') !== $userId && ($parsed['entityIdB'] ?? '') !== $userId) {
                return DataProcessResult::error('Access denied — scope mismatch');
            }

            $parsed['status'] = 'declined';
            $parsed['declinedBy'] = $userId;
            $parsed['declinedAt'] = Carbon::now()->toISOString();
            $this->db->upsert($this->config->matchResultsIndex, $matchId, $parsed);

            $this->queue->publish('match-events', [
                'eventType' => 'MatchDeclined',
                'matchId' => $matchId,
                'declinedBy' => $userId,
                'timestamp' => Carbon::now()->toISOString(),
            ]);

            return DataProcessResult::ok(true, 'Match declined');
        } catch (\Throwable $e) {
            return DataProcessResult::error($e->getMessage());
        }
    }

    public function listMatches(string $entityId, ?array $filter, int $page, int $pageSize): DataProcessResult
    {
        try {
            $pageSize = max(1, min($pageSize, 100));
            $baseFilter = ['entityIdA' => $entityId];
            if ($filter) {
                $baseFilter = array_merge($baseFilter, $filter);
            }
            $searchFilter = $this->objectProcessor->buildSearchFilter($baseFilter);
            $results = $this->db->query($this->config->matchResultsIndex, $searchFilter, $pageSize, $page * $pageSize);
            $mapped = array_map(fn($r) => $this->objectProcessor->parseObjectAlternative($r), $results);
            return DataProcessResult::ok($mapped);
        } catch (\Throwable $e) {
            return DataProcessResult::error($e->getMessage());
        }
    }

    // ─── Config (FREEDOM) ───────────────────────────────────────

    public function getCriteriaConfig(string $matchType): DataProcessResult
    {
        return DataProcessResult::ok($this->loadCriteriaConfig($matchType));
    }

    public function updateCriteriaConfig(string $matchType, array $config): DataProcessResult
    {
        try {
            $doc = $this->objectProcessor->parseObjectAlternative($config);
            $doc['configId'] = "match-criteria-{$matchType}";
            $doc['matchType'] = $matchType;
            $doc['updatedAt'] = Carbon::now()->toISOString();
            $this->db->upsert($this->config->matchConfigIndex, $doc['configId'], $doc);
            return DataProcessResult::ok($doc, 'Config updated');
        } catch (\Throwable $e) {
            return DataProcessResult::error($e->getMessage());
        }
    }

    // ─── Scoring Engine (MACHINE) ───────────────────────────────

    private function computeWeightedScore(array $profileA, array $profileB, array $criteria): float
    {
        $totalWeight = 0.0;
        $weightedScore = 0.0;

        foreach ($criteria as [$field, $weight, $similarity, $config]) {
            $aVal = $profileA[$field] ?? null;
            $bVal = $profileB[$field] ?? null;
            if ($aVal === null && $bVal === null) continue;

            $sim = SimilarityFunctions::compute($similarity, $aVal, $bVal, $config);
            $weightedScore += $weight * $sim;
            $totalWeight += $weight;
        }

        return $totalWeight == 0 ? 0.0 : $weightedScore / $totalWeight;
    }

    private function computeBreakdown(array $profileA, array $profileB, array $criteria): array
    {
        $breakdown = [];
        foreach ($criteria as [$field, $weight, $similarity, $config]) {
            $aVal = $profileA[$field] ?? null;
            $bVal = $profileB[$field] ?? null;
            $sim = SimilarityFunctions::compute($similarity, $aVal, $bVal, $config);
            $breakdown[$field] = [
                'similarity' => round($sim, 4),
                'weight' => $weight,
                'weighted' => round($sim * $weight, 4),
            ];
        }
        return $breakdown;
    }

    private function extractCriteria(array $criteriaConfig): array
    {
        $result = [];
        if (isset($criteriaConfig['criteria']) && is_array($criteriaConfig['criteria'])) {
            foreach ($criteriaConfig['criteria'] as $field => $fieldConfig) {
                $fc = is_array($fieldConfig) ? $fieldConfig : $this->objectProcessor->parseObjectAlternative($fieldConfig);
                $weight = (float)($fc['weight'] ?? 1.0);
                $similarity = $fc['similarity'] ?? 'exact';
                $result[] = [$field, $weight, $similarity, $fc];
            }
        }

        if (empty($result)) {
            $result = [
                ['interests', 0.3, 'jaccard', null],
                ['location', 0.2, 'geo-distance', ['maxDistanceKm' => 50.0]],
                ['industry', 0.25, 'exact', null],
                ['goals', 0.15, 'jaccard', null],
                ['companySize', 0.10, 'range', null],
            ];
        }

        return $result;
    }

    private function loadCriteriaConfig(string $matchType): array
    {
        try {
            $config = $this->db->getById($this->config->matchConfigIndex, "match-criteria-{$matchType}");
            if ($config) return $this->objectProcessor->parseObjectAlternative($config);
        } catch (\Throwable $e) { /* fall through */ }

        return [
            'matchType' => $matchType,
            'minScoreThreshold' => $this->config->defaultMinScore,
            'bidirectional' => $matchType === 'user-user',
            'bidirectionalStrategy' => $this->config->defaultBidirectionalStrategy,
        ];
    }
}
