// XIIGen Matching Service — Skill 47 | Node.js/TypeScript Alternative
// Multi-criteria matching with weighted scoring, bidirectional computation
// Genie DNA: DNA-1 (Record<string,any>), DNA-2 (buildSearchFilter), DNA-5 (DataProcessResult)

import { IDatabaseService, IQueueService, IObjectProcessor, DataProcessResult } from '../01-core-interfaces';

// ─── Configuration ──────────────────────────────────────────────
export interface MatchingConfig {
  matchResultsIndex: string;
  matchProfilesIndex: string;
  matchConfigIndex: string;
  defaultMinScore: number;
  defaultTopN: number;
  batchSize: number;
  defaultBidirectionalStrategy: string;
}

const DEFAULT_CONFIG: MatchingConfig = {
  matchResultsIndex: 'match-results',
  matchProfilesIndex: 'match-profiles',
  matchConfigIndex: 'match-config',
  defaultMinScore: 0.3,
  defaultTopN: 20,
  batchSize: 100,
  defaultBidirectionalStrategy: 'average',
};

type MatchDoc = Record<string, any>;

// ─── Similarity Functions ───────────────────────────────────────
export class SimilarityFunctions {
  static jaccard(aVal: any, bVal: any): number {
    const setA = new Set(SimilarityFunctions.extractArray(aVal));
    const setB = new Set(SimilarityFunctions.extractArray(bVal));
    if (setA.size === 0 && setB.size === 0) return 0;
    const intersection = [...setA].filter(x => setB.has(x)).length;
    const union = new Set([...setA, ...setB]).size;
    return union === 0 ? 0 : intersection / union;
  }

  static exact(aVal: any, bVal: any): number {
    return String(aVal ?? '').toLowerCase() === String(bVal ?? '').toLowerCase() ? 1 : 0;
  }

  static geoDistance(aVal: any, bVal: any, maxDistanceKm = 50): number {
    const locA = SimilarityFunctions.extractLocation(aVal);
    const locB = SimilarityFunctions.extractLocation(bVal);
    if (!locA || !locB) return 0;
    const dist = SimilarityFunctions.haversineKm(locA.lat, locA.lng, locB.lat, locB.lng);
    return Math.max(0, 1 - dist / maxDistanceKm);
  }

  static range(aVal: any, bVal: any): number {
    const a = Number(aVal) || 0;
    const b = Number(bVal) || 0;
    if (a === 0 && b === 0) return 1;
    const maxVal = Math.max(Math.abs(a), Math.abs(b));
    return maxVal === 0 ? 1 : 1 - Math.abs(a - b) / maxVal;
  }

  static compute(type: string, aVal: any, bVal: any, config?: MatchDoc): number {
    switch (type.toLowerCase()) {
      case 'jaccard': return SimilarityFunctions.jaccard(aVal, bVal);
      case 'exact': return SimilarityFunctions.exact(aVal, bVal);
      case 'geo-distance':
      case 'geodistance':
        return SimilarityFunctions.geoDistance(aVal, bVal, config?.maxDistanceKm ?? 50);
      case 'range': return SimilarityFunctions.range(aVal, bVal);
      default: return SimilarityFunctions.exact(aVal, bVal);
    }
  }

  private static extractArray(val: any): string[] {
    if (Array.isArray(val)) return val.map(String);
    if (typeof val === 'string') return [val];
    return [];
  }

  private static extractLocation(val: any): { lat: number; lng: number } | null {
    if (val && typeof val === 'object' && 'lat' in val && 'lng' in val) {
      return { lat: Number(val.lat), lng: Number(val.lng) };
    }
    return null;
  }

  private static haversineKm(lat1: number, lng1: number, lat2: number, lng2: number): number {
    const R = 6371;
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLng = ((lng2 - lng1) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) ** 2 +
      Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  }
}

// ─── Criteria Type ──────────────────────────────────────────────
interface CriterionDef {
  field: string;
  weight: number;
  similarity: string;
  config?: MatchDoc;
}

// ─── Service Interface ──────────────────────────────────────────
export interface IMatchingService {
  extractProfile(entityData: MatchDoc, entityType: string): Promise<DataProcessResult<MatchDoc>>;
  getProfile(entityId: string): Promise<DataProcessResult<MatchDoc>>;
  computeMatch(entityIdA: string, entityIdB: string, matchType: string): Promise<DataProcessResult<MatchDoc>>;
  findMatches(entityId: string, matchType: string, topN: number): Promise<DataProcessResult<MatchDoc[]>>;
  batchMatch(entityId: string, candidateIds: string[], matchType: string): Promise<DataProcessResult<MatchDoc[]>>;
  acceptMatch(userId: string, matchId: string): Promise<DataProcessResult<boolean>>;
  declineMatch(userId: string, matchId: string): Promise<DataProcessResult<boolean>>;
  listMatches(entityId: string, filter: MatchDoc | null, page: number, pageSize: number): Promise<DataProcessResult<MatchDoc[]>>;
  getCriteriaConfig(matchType: string): Promise<DataProcessResult<MatchDoc>>;
  updateCriteriaConfig(matchType: string, config: MatchDoc): Promise<DataProcessResult<MatchDoc>>;
}

// ─── Service Implementation ─────────────────────────────────────
export class MatchingService implements IMatchingService {
  constructor(
    private readonly db: IDatabaseService,
    private readonly queue: IQueueService,
    private readonly op: IObjectProcessor,
    private readonly config: MatchingConfig = DEFAULT_CONFIG,
    private readonly logger: Console = console,
  ) {}

  // ─── Profile ──────────────────────────────────────────────────

  async extractProfile(entityData: MatchDoc, entityType: string): Promise<DataProcessResult<MatchDoc>> {
    try {
      const doc = this.op.parseObjectAlternative(entityData);
      const entityId = doc.id ?? doc.entityId;
      if (!entityId) return { success: false, data: {}, message: 'Missing entityId or id' };

      const profile: MatchDoc = {
        profileId: `${entityType}-${entityId}`,
        entityId,
        entityType,
        extractedAt: new Date().toISOString(),
      };

      for (const [k, v] of Object.entries(doc)) {
        if (['id', 'password', 'token'].includes(k)) continue;
        profile[k] = v;
      }

      await this.db.upsert(this.config.matchProfilesIndex, profile.profileId, profile);
      this.logger.info(`Profile extracted for ${entityType} ${entityId}`);
      return { success: true, data: profile, message: 'Profile extracted' };
    } catch (error: any) {
      return { success: false, data: {}, message: error.message };
    }
  }

  async getProfile(entityId: string): Promise<DataProcessResult<MatchDoc>> {
    for (const type of ['user', 'event', 'business']) {
      try {
        const profile = await this.db.getById(this.config.matchProfilesIndex, `${type}-${entityId}`);
        if (profile) return { success: true, data: this.op.parseObjectAlternative(profile), message: 'Found' };
      } catch { /* try next */ }
    }
    return { success: false, data: {}, message: 'Profile not found' };
  }

  // ─── Match Computation ────────────────────────────────────────

  async computeMatch(entityIdA: string, entityIdB: string, matchType: string): Promise<DataProcessResult<MatchDoc>> {
    try {
      const profileA = await this.getProfile(entityIdA);
      const profileB = await this.getProfile(entityIdB);
      if (!profileA.success) return { success: false, data: {}, message: `Profile A not found: ${entityIdA}` };
      if (!profileB.success) return { success: false, data: {}, message: `Profile B not found: ${entityIdB}` };

      const criteriaConfig = await this.loadCriteriaConfig(matchType);
      const criteria = this.extractCriteria(criteriaConfig);

      let score = this.computeWeightedScore(profileA.data, profileB.data, criteria);

      // Bidirectional
      if (criteriaConfig.bidirectional) {
        const reverseScore = this.computeWeightedScore(profileB.data, profileA.data, criteria);
        score = criteriaConfig.bidirectionalStrategy === 'minimum'
          ? Math.min(score, reverseScore) : (score + reverseScore) / 2;
      }

      const matchResult: MatchDoc = {
        matchId: `match-${entityIdA}-${entityIdB}-${matchType}`,
        entityIdA, entityIdB, matchType,
        score: Math.round(score * 10000) / 10000,
        status: 'pending',
        criteriaBreakdown: this.computeBreakdown(profileA.data, profileB.data, criteria),
        computedAt: new Date().toISOString(),
      };

      await this.db.upsert(this.config.matchResultsIndex, matchResult.matchId, matchResult);

      await this.queue.publish('match-events', {
        eventType: 'MatchCalculated', matchId: matchResult.matchId,
        entityIdA, entityIdB, score: matchResult.score, matchType,
        timestamp: new Date().toISOString(),
      });

      return { success: true, data: matchResult, message: 'Match computed' };
    } catch (error: any) {
      return { success: false, data: {}, message: error.message };
    }
  }

  async findMatches(entityId: string, matchType: string, topN: number): Promise<DataProcessResult<MatchDoc[]>> {
    try {
      topN = Math.max(1, Math.min(topN, 100));
      const targetType = matchType.split('-').pop() ?? 'user';
      const filter = this.op.buildSearchFilter({ entityType: targetType });
      const candidates = await this.db.query(this.config.matchProfilesIndex, filter, this.config.batchSize, 0);

      const criteriaConfig = await this.loadCriteriaConfig(matchType);
      const criteria = this.extractCriteria(criteriaConfig);
      const minScore = Number(criteriaConfig.minScoreThreshold ?? this.config.defaultMinScore);

      const sourceProfile = await this.getProfile(entityId);
      if (!sourceProfile.success) return { success: false, data: [], message: `Source profile not found: ${entityId}` };

      const results: MatchDoc[] = [];
      for (const candidate of candidates ?? []) {
        const parsed = this.op.parseObjectAlternative(candidate);
        const candidateId = parsed.entityId;
        if (candidateId === entityId) continue;

        const score = this.computeWeightedScore(sourceProfile.data, parsed, criteria);
        if (score >= minScore) {
          results.push({
            entityId: candidateId, score: Math.round(score * 10000) / 10000,
            matchType, breakdown: this.computeBreakdown(sourceProfile.data, parsed, criteria),
          });
        }
      }

      results.sort((a, b) => (b.score ?? 0) - (a.score ?? 0));
      const top = results.slice(0, topN);
      return { success: true, data: top, message: `Found ${top.length} matches above ${minScore}` };
    } catch (error: any) {
      return { success: false, data: [], message: error.message };
    }
  }

  async batchMatch(entityId: string, candidateIds: string[], matchType: string): Promise<DataProcessResult<MatchDoc[]>> {
    try {
      const results: MatchDoc[] = [];
      for (const cid of candidateIds) {
        const r = await this.computeMatch(entityId, cid, matchType);
        if (r.success) results.push(r.data);
      }

      await this.queue.publish('match-events', {
        eventType: 'BatchMatchComplete', entityId, matchType,
        matchCount: results.length, timestamp: new Date().toISOString(),
      });

      return { success: true, data: results, message: `Batch computed ${results.length}/${candidateIds.length}` };
    } catch (error: any) {
      return { success: false, data: [], message: error.message };
    }
  }

  // ─── Management ───────────────────────────────────────────────

  async acceptMatch(userId: string, matchId: string): Promise<DataProcessResult<boolean>> {
    return this.updateMatchStatus(userId, matchId, 'accepted', 'MatchAccepted');
  }

  async declineMatch(userId: string, matchId: string): Promise<DataProcessResult<boolean>> {
    return this.updateMatchStatus(userId, matchId, 'declined', 'MatchDeclined');
  }

  private async updateMatchStatus(userId: string, matchId: string, status: string, eventType: string): Promise<DataProcessResult<boolean>> {
    try {
      const match = await this.db.getById(this.config.matchResultsIndex, matchId);
      if (!match) return { success: false, data: false, message: 'Match not found' };
      const parsed = this.op.parseObjectAlternative(match);
      if (parsed.entityIdA !== userId && parsed.entityIdB !== userId)
        return { success: false, data: false, message: 'Access denied — scope mismatch' };

      parsed.status = status;
      parsed[`${status}By`] = userId;
      parsed[`${status}At`] = new Date().toISOString();
      await this.db.upsert(this.config.matchResultsIndex, matchId, parsed);

      await this.queue.publish('match-events', {
        eventType, matchId, [`${status}By`]: userId, timestamp: new Date().toISOString(),
      });

      return { success: true, data: true, message: `Match ${status}` };
    } catch (error: any) {
      return { success: false, data: false, message: error.message };
    }
  }

  async listMatches(entityId: string, filter: MatchDoc | null, page: number, pageSize: number): Promise<DataProcessResult<MatchDoc[]>> {
    try {
      pageSize = Math.max(1, Math.min(pageSize, 100));
      const base: MatchDoc = { entityIdA: entityId, ...(filter ?? {}) };
      const searchFilter = this.op.buildSearchFilter(base);
      const results = await this.db.query(this.config.matchResultsIndex, searchFilter, pageSize, page * pageSize);
      return { success: true, data: (results ?? []).map((r: any) => this.op.parseObjectAlternative(r)), message: 'Listed' };
    } catch (error: any) {
      return { success: false, data: [], message: error.message };
    }
  }

  // ─── Config ───────────────────────────────────────────────────

  async getCriteriaConfig(matchType: string): Promise<DataProcessResult<MatchDoc>> {
    return { success: true, data: await this.loadCriteriaConfig(matchType), message: 'Config loaded' };
  }

  async updateCriteriaConfig(matchType: string, config: MatchDoc): Promise<DataProcessResult<MatchDoc>> {
    try {
      const doc = this.op.parseObjectAlternative(config);
      doc.configId = `match-criteria-${matchType}`;
      doc.matchType = matchType;
      doc.updatedAt = new Date().toISOString();
      await this.db.upsert(this.config.matchConfigIndex, doc.configId, doc);
      return { success: true, data: doc, message: 'Config updated' };
    } catch (error: any) {
      return { success: false, data: {}, message: error.message };
    }
  }

  // ─── Scoring Engine ───────────────────────────────────────────

  private computeWeightedScore(profileA: MatchDoc, profileB: MatchDoc, criteria: CriterionDef[]): number {
    let totalWeight = 0, weightedScore = 0;
    for (const { field, weight, similarity, config } of criteria) {
      const aVal = profileA[field];
      const bVal = profileB[field];
      if (aVal == null && bVal == null) continue;
      const sim = SimilarityFunctions.compute(similarity, aVal, bVal, config);
      weightedScore += weight * sim;
      totalWeight += weight;
    }
    return totalWeight === 0 ? 0 : weightedScore / totalWeight;
  }

  private computeBreakdown(profileA: MatchDoc, profileB: MatchDoc, criteria: CriterionDef[]): MatchDoc {
    const breakdown: MatchDoc = {};
    for (const { field, weight, similarity, config } of criteria) {
      const sim = SimilarityFunctions.compute(similarity, profileA[field], profileB[field], config);
      breakdown[field] = {
        similarity: Math.round(sim * 10000) / 10000,
        weight,
        weighted: Math.round(sim * weight * 10000) / 10000,
      };
    }
    return breakdown;
  }

  private extractCriteria(config: MatchDoc): CriterionDef[] {
    if (config.criteria && typeof config.criteria === 'object') {
      return Object.entries(config.criteria).map(([field, cfg]: [string, any]) => ({
        field,
        weight: Number(cfg?.weight ?? 1),
        similarity: cfg?.similarity ?? 'exact',
        config: cfg,
      }));
    }
    return [
      { field: 'interests', weight: 0.3, similarity: 'jaccard' },
      { field: 'location', weight: 0.2, similarity: 'geo-distance', config: { maxDistanceKm: 50 } },
      { field: 'industry', weight: 0.25, similarity: 'exact' },
      { field: 'goals', weight: 0.15, similarity: 'jaccard' },
      { field: 'companySize', weight: 0.1, similarity: 'range' },
    ];
  }

  private async loadCriteriaConfig(matchType: string): Promise<MatchDoc> {
    try {
      const c = await this.db.getById(this.config.matchConfigIndex, `match-criteria-${matchType}`);
      if (c) return this.op.parseObjectAlternative(c);
    } catch { /* fall through */ }
    return {
      matchType, minScoreThreshold: this.config.defaultMinScore,
      bidirectional: matchType === 'user-user',
      bidirectionalStrategy: this.config.defaultBidirectionalStrategy,
    };
  }
}
