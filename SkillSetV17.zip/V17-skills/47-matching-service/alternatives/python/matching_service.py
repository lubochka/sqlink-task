# XIIGen Matching Service — Skill 47 | Python/FastAPI Alternative
# Multi-criteria matching with weighted scoring, bidirectional computation
# Genie DNA: DNA-1 (dict[str,Any]), DNA-2 (build_search_filter), DNA-5 (DataProcessResult)

from __future__ import annotations
import math
import uuid
from datetime import datetime, timezone
from dataclasses import dataclass, field
from typing import Any, Optional, Protocol

# ─── Configuration ──────────────────────────────────────────────
@dataclass
class MatchingConfig:
    match_results_index: str = "match-results"
    match_profiles_index: str = "match-profiles"
    match_config_index: str = "match-config"
    default_min_score: float = 0.3
    default_top_n: int = 20
    batch_size: int = 100
    default_bidirectional_strategy: str = "average"

@dataclass
class DataProcessResult:
    success: bool
    data: Any = None
    message: str = ""

    @classmethod
    def ok(cls, data: Any, message: str = "") -> DataProcessResult:
        return cls(success=True, data=data, message=message)

    @classmethod
    def error(cls, message: str) -> DataProcessResult:
        return cls(success=False, data=None, message=message)

# ─── Protocols ──────────────────────────────────────────────────
class IDatabaseService(Protocol):
    async def upsert(self, index: str, doc_id: str, doc: dict[str, Any]) -> None: ...
    async def get_by_id(self, index: str, doc_id: str) -> Optional[dict[str, Any]]: ...
    async def query(self, index: str, filter_obj: dict, limit: int, offset: int) -> list[dict[str, Any]]: ...
    async def count(self, index: str, filter_obj: dict) -> int: ...

class IQueueService(Protocol):
    async def publish(self, channel: str, message: dict[str, Any]) -> None: ...

class IObjectProcessor(Protocol):
    def parse_object_alternative(self, obj: Any) -> dict[str, Any]: ...
    def build_search_filter(self, obj: dict[str, Any]) -> dict[str, Any]: ...

# ─── Similarity Functions ───────────────────────────────────────
class SimilarityFunctions:
    @staticmethod
    def jaccard(a_val: Any, b_val: Any) -> float:
        set_a = set(SimilarityFunctions._to_list(a_val))
        set_b = set(SimilarityFunctions._to_list(b_val))
        if not set_a and not set_b:
            return 0.0
        intersection = len(set_a & set_b)
        union = len(set_a | set_b)
        return intersection / union if union else 0.0

    @staticmethod
    def exact(a_val: Any, b_val: Any) -> float:
        return 1.0 if str(a_val or "").lower() == str(b_val or "").lower() else 0.0

    @staticmethod
    def geo_distance(a_val: Any, b_val: Any, max_distance_km: float = 50.0) -> float:
        loc_a = SimilarityFunctions._extract_location(a_val)
        loc_b = SimilarityFunctions._extract_location(b_val)
        if not loc_a or not loc_b:
            return 0.0
        dist = SimilarityFunctions._haversine_km(*loc_a, *loc_b)
        return max(0.0, 1.0 - dist / max_distance_km)

    @staticmethod
    def range_sim(a_val: Any, b_val: Any) -> float:
        a, b = float(a_val or 0), float(b_val or 0)
        if a == 0 and b == 0:
            return 1.0
        max_val = max(abs(a), abs(b))
        return 1.0 - abs(a - b) / max_val if max_val else 1.0

    @staticmethod
    def compute(sim_type: str, a_val: Any, b_val: Any, config: Optional[dict] = None) -> float:
        t = sim_type.lower()
        if t == "jaccard":
            return SimilarityFunctions.jaccard(a_val, b_val)
        elif t == "exact":
            return SimilarityFunctions.exact(a_val, b_val)
        elif t in ("geo-distance", "geodistance"):
            max_km = float((config or {}).get("maxDistanceKm", 50))
            return SimilarityFunctions.geo_distance(a_val, b_val, max_km)
        elif t == "range":
            return SimilarityFunctions.range_sim(a_val, b_val)
        return SimilarityFunctions.exact(a_val, b_val)

    @staticmethod
    def _to_list(val: Any) -> list[str]:
        if isinstance(val, (list, tuple, set)):
            return [str(v) for v in val]
        if isinstance(val, str):
            return [val]
        return []

    @staticmethod
    def _extract_location(val: Any) -> Optional[tuple[float, float]]:
        if isinstance(val, dict) and "lat" in val and "lng" in val:
            return (float(val["lat"]), float(val["lng"]))
        return None

    @staticmethod
    def _haversine_km(lat1: float, lng1: float, lat2: float, lng2: float) -> float:
        R = 6371.0
        d_lat = math.radians(lat2 - lat1)
        d_lng = math.radians(lng2 - lng1)
        a = (math.sin(d_lat / 2) ** 2 +
             math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) *
             math.sin(d_lng / 2) ** 2)
        return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

# ─── Criterion Definition ───────────────────────────────────────
@dataclass
class CriterionDef:
    field: str
    weight: float
    similarity: str
    config: Optional[dict[str, Any]] = None

# ─── Service Implementation ─────────────────────────────────────
class MatchingService:
    def __init__(
        self,
        db: IDatabaseService,
        queue: IQueueService,
        object_processor: IObjectProcessor,
        config: Optional[MatchingConfig] = None,
    ):
        self._db = db
        self._queue = queue
        self._op = object_processor
        self._config = config or MatchingConfig()

    # ─── Profile ────────────────────────────────────────────────

    async def extract_profile(self, entity_data: dict[str, Any], entity_type: str) -> DataProcessResult:
        try:
            doc = self._op.parse_object_alternative(entity_data)
            entity_id = doc.get("id") or doc.get("entityId")
            if not entity_id:
                return DataProcessResult.error("Missing entityId or id")

            profile: dict[str, Any] = {
                "profileId": f"{entity_type}-{entity_id}",
                "entityId": entity_id,
                "entityType": entity_type,
                "extractedAt": datetime.now(timezone.utc).isoformat(),
            }
            for k, v in doc.items():
                if k in ("id", "password", "token"):
                    continue
                profile[k] = v

            await self._db.upsert(self._config.match_profiles_index, profile["profileId"], profile)
            return DataProcessResult.ok(profile, "Profile extracted")
        except Exception as e:
            return DataProcessResult.error(str(e))

    async def get_profile(self, entity_id: str) -> DataProcessResult:
        for etype in ("user", "event", "business"):
            try:
                p = await self._db.get_by_id(self._config.match_profiles_index, f"{etype}-{entity_id}")
                if p:
                    return DataProcessResult.ok(self._op.parse_object_alternative(p))
            except Exception:
                continue
        return DataProcessResult.error("Profile not found")

    # ─── Match Computation ──────────────────────────────────────

    async def compute_match(self, entity_id_a: str, entity_id_b: str, match_type: str) -> DataProcessResult:
        try:
            pa = await self.get_profile(entity_id_a)
            pb = await self.get_profile(entity_id_b)
            if not pa.success:
                return DataProcessResult.error(f"Profile A not found: {entity_id_a}")
            if not pb.success:
                return DataProcessResult.error(f"Profile B not found: {entity_id_b}")

            criteria_config = await self._load_criteria_config(match_type)
            criteria = self._extract_criteria(criteria_config)

            score = self._compute_weighted_score(pa.data, pb.data, criteria)

            if criteria_config.get("bidirectional"):
                reverse = self._compute_weighted_score(pb.data, pa.data, criteria)
                strategy = criteria_config.get("bidirectionalStrategy", "average")
                score = min(score, reverse) if strategy == "minimum" else (score + reverse) / 2

            match_result = {
                "matchId": f"match-{entity_id_a}-{entity_id_b}-{match_type}",
                "entityIdA": entity_id_a,
                "entityIdB": entity_id_b,
                "matchType": match_type,
                "score": round(score, 4),
                "status": "pending",
                "criteriaBreakdown": self._compute_breakdown(pa.data, pb.data, criteria),
                "computedAt": datetime.now(timezone.utc).isoformat(),
            }

            await self._db.upsert(self._config.match_results_index, match_result["matchId"], match_result)
            await self._queue.publish("match-events", {
                "eventType": "MatchCalculated",
                "matchId": match_result["matchId"],
                "entityIdA": entity_id_a,
                "entityIdB": entity_id_b,
                "score": match_result["score"],
                "matchType": match_type,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            })
            return DataProcessResult.ok(match_result, "Match computed")
        except Exception as e:
            return DataProcessResult.error(str(e))

    async def find_matches(self, entity_id: str, match_type: str, top_n: int) -> DataProcessResult:
        try:
            top_n = max(1, min(top_n, 100))
            target_type = match_type.split("-")[-1] if "-" in match_type else "user"
            fltr = self._op.build_search_filter({"entityType": target_type})
            candidates = await self._db.query(self._config.match_profiles_index, fltr, self._config.batch_size, 0)

            criteria_config = await self._load_criteria_config(match_type)
            criteria = self._extract_criteria(criteria_config)
            min_score = float(criteria_config.get("minScoreThreshold", self._config.default_min_score))

            source = await self.get_profile(entity_id)
            if not source.success:
                return DataProcessResult.error(f"Source profile not found: {entity_id}")

            results = []
            for cand in candidates or []:
                parsed = self._op.parse_object_alternative(cand)
                cid = parsed.get("entityId")
                if cid == entity_id:
                    continue
                score = self._compute_weighted_score(source.data, parsed, criteria)
                if score >= min_score:
                    results.append({
                        "entityId": cid,
                        "score": round(score, 4),
                        "matchType": match_type,
                        "breakdown": self._compute_breakdown(source.data, parsed, criteria),
                    })

            results.sort(key=lambda x: x.get("score", 0), reverse=True)
            top = results[:top_n]
            return DataProcessResult.ok(top, f"Found {len(top)} matches above {min_score}")
        except Exception as e:
            return DataProcessResult.error(str(e))

    async def batch_match(self, entity_id: str, candidate_ids: list[str], match_type: str) -> DataProcessResult:
        try:
            results = []
            for cid in candidate_ids:
                r = await self.compute_match(entity_id, cid, match_type)
                if r.success:
                    results.append(r.data)

            await self._queue.publish("match-events", {
                "eventType": "BatchMatchComplete",
                "entityId": entity_id,
                "matchType": match_type,
                "matchCount": len(results),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            })
            return DataProcessResult.ok(results, f"Batch computed {len(results)}/{len(candidate_ids)}")
        except Exception as e:
            return DataProcessResult.error(str(e))

    # ─── Management ─────────────────────────────────────────────

    async def accept_match(self, user_id: str, match_id: str) -> DataProcessResult:
        return await self._update_match_status(user_id, match_id, "accepted", "MatchAccepted")

    async def decline_match(self, user_id: str, match_id: str) -> DataProcessResult:
        return await self._update_match_status(user_id, match_id, "declined", "MatchDeclined")

    async def _update_match_status(self, user_id: str, match_id: str, status: str, event_type: str) -> DataProcessResult:
        try:
            item = await self._db.get_by_id(self._config.match_results_index, match_id)
            if not item:
                return DataProcessResult.error("Match not found")
            parsed = self._op.parse_object_alternative(item)
            if parsed.get("entityIdA") != user_id and parsed.get("entityIdB") != user_id:
                return DataProcessResult.error("Access denied — scope mismatch")

            parsed["status"] = status
            parsed[f"{status}By"] = user_id
            parsed[f"{status}At"] = datetime.now(timezone.utc).isoformat()
            await self._db.upsert(self._config.match_results_index, match_id, parsed)
            await self._queue.publish("match-events", {
                "eventType": event_type, "matchId": match_id,
                f"{status}By": user_id, "timestamp": datetime.now(timezone.utc).isoformat(),
            })
            return DataProcessResult.ok(True, f"Match {status}")
        except Exception as e:
            return DataProcessResult.error(str(e))

    async def list_matches(self, entity_id: str, filter_obj: Optional[dict], page: int, page_size: int) -> DataProcessResult:
        try:
            page_size = max(1, min(page_size, 100))
            base = {"entityIdA": entity_id, **(filter_obj or {})}
            fltr = self._op.build_search_filter(base)
            results = await self._db.query(self._config.match_results_index, fltr, page_size, page * page_size)
            return DataProcessResult.ok([self._op.parse_object_alternative(r) for r in (results or [])])
        except Exception as e:
            return DataProcessResult.error(str(e))

    # ─── Config ─────────────────────────────────────────────────

    async def get_criteria_config(self, match_type: str) -> DataProcessResult:
        return DataProcessResult.ok(await self._load_criteria_config(match_type))

    async def update_criteria_config(self, match_type: str, config: dict[str, Any]) -> DataProcessResult:
        try:
            doc = self._op.parse_object_alternative(config)
            doc["configId"] = f"match-criteria-{match_type}"
            doc["matchType"] = match_type
            doc["updatedAt"] = datetime.now(timezone.utc).isoformat()
            await self._db.upsert(self._config.match_config_index, doc["configId"], doc)
            return DataProcessResult.ok(doc, "Config updated")
        except Exception as e:
            return DataProcessResult.error(str(e))

    # ─── Scoring Engine ─────────────────────────────────────────

    def _compute_weighted_score(self, profile_a: dict, profile_b: dict, criteria: list[CriterionDef]) -> float:
        total_weight = 0.0
        weighted_score = 0.0
        for c in criteria:
            a_val = profile_a.get(c.field)
            b_val = profile_b.get(c.field)
            if a_val is None and b_val is None:
                continue
            sim = SimilarityFunctions.compute(c.similarity, a_val, b_val, c.config)
            weighted_score += c.weight * sim
            total_weight += c.weight
        return weighted_score / total_weight if total_weight else 0.0

    def _compute_breakdown(self, profile_a: dict, profile_b: dict, criteria: list[CriterionDef]) -> dict:
        breakdown = {}
        for c in criteria:
            sim = SimilarityFunctions.compute(c.similarity, profile_a.get(c.field), profile_b.get(c.field), c.config)
            breakdown[c.field] = {
                "similarity": round(sim, 4),
                "weight": c.weight,
                "weighted": round(sim * c.weight, 4),
            }
        return breakdown

    def _extract_criteria(self, config: dict[str, Any]) -> list[CriterionDef]:
        criteria_raw = config.get("criteria")
        if isinstance(criteria_raw, dict):
            return [
                CriterionDef(
                    field=field,
                    weight=float(cfg.get("weight", 1)),
                    similarity=cfg.get("similarity", "exact"),
                    config=cfg if isinstance(cfg, dict) else None,
                )
                for field, cfg in criteria_raw.items()
                if isinstance(cfg, dict)
            ]
        return [
            CriterionDef("interests", 0.3, "jaccard"),
            CriterionDef("location", 0.2, "geo-distance", {"maxDistanceKm": 50}),
            CriterionDef("industry", 0.25, "exact"),
            CriterionDef("goals", 0.15, "jaccard"),
            CriterionDef("companySize", 0.1, "range"),
        ]

    async def _load_criteria_config(self, match_type: str) -> dict[str, Any]:
        try:
            c = await self._db.get_by_id(self._config.match_config_index, f"match-criteria-{match_type}")
            if c:
                return self._op.parse_object_alternative(c)
        except Exception:
            pass
        return {
            "matchType": match_type,
            "minScoreThreshold": self._config.default_min_score,
            "bidirectional": match_type == "user-user",
            "bidirectionalStrategy": self._config.default_bidirectional_strategy,
        }
