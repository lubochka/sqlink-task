// XIIGen Matching Service — Skill 47 | Rust/Axum Alternative
// Multi-criteria matching with weighted scoring, bidirectional computation
// Genie DNA: DNA-1 (HashMap<String,Value>), DNA-2 (build_search_filter), DNA-5 (DataProcessResult)

use async_trait::async_trait;
use chrono::Utc;
use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::collections::{HashMap, HashSet};
use tracing::{error, info};

type MatchDoc = HashMap<String, Value>;

// ─── Configuration ──────────────────────────────────────────────
#[derive(Clone, Debug)]
pub struct MatchingConfig {
    pub match_results_index: String,
    pub match_profiles_index: String,
    pub match_config_index: String,
    pub default_min_score: f64,
    pub default_top_n: usize,
    pub batch_size: usize,
    pub default_bidirectional_strategy: String,
}

impl Default for MatchingConfig {
    fn default() -> Self {
        Self {
            match_results_index: "match-results".into(),
            match_profiles_index: "match-profiles".into(),
            match_config_index: "match-config".into(),
            default_min_score: 0.3,
            default_top_n: 20,
            batch_size: 100,
            default_bidirectional_strategy: "average".into(),
        }
    }
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct DataProcessResult<T: Serialize> {
    pub success: bool,
    pub data: Option<T>,
    pub message: String,
}

impl<T: Serialize> DataProcessResult<T> {
    pub fn ok(data: T, msg: &str) -> Self { Self { success: true, data: Some(data), message: msg.into() } }
    pub fn error(msg: &str) -> Self { Self { success: false, data: None, message: msg.into() } }
}

// ─── Traits ─────────────────────────────────────────────────────
#[async_trait]
pub trait IDatabaseService: Send + Sync {
    async fn upsert(&self, index: &str, id: &str, doc: &MatchDoc) -> anyhow::Result<()>;
    async fn get_by_id(&self, index: &str, id: &str) -> anyhow::Result<Option<MatchDoc>>;
    async fn query(&self, index: &str, filter: &MatchDoc, limit: usize, offset: usize) -> anyhow::Result<Vec<MatchDoc>>;
}

#[async_trait]
pub trait IQueueService: Send + Sync {
    async fn publish(&self, channel: &str, message: &MatchDoc) -> anyhow::Result<()>;
}

pub trait IObjectProcessor: Send + Sync {
    fn parse_object_alternative(&self, obj: &Value) -> MatchDoc;
    fn build_search_filter(&self, filter: &MatchDoc) -> MatchDoc;
}

// ─── Criterion ──────────────────────────────────────────────────
#[derive(Clone, Debug)]
pub struct CriterionDef {
    pub field: String,
    pub weight: f64,
    pub similarity: String,
    pub config: Option<MatchDoc>,
}

// ─── Similarity Functions ───────────────────────────────────────
pub struct SimilarityFunctions;

impl SimilarityFunctions {
    pub fn jaccard(a: &Value, b: &Value) -> f64 {
        let sa = Self::to_set(a);
        let sb = Self::to_set(b);
        if sa.is_empty() && sb.is_empty() { return 0.0; }
        let inter = sa.intersection(&sb).count();
        let union = sa.union(&sb).count();
        if union == 0 { 0.0 } else { inter as f64 / union as f64 }
    }

    pub fn exact(a: &Value, b: &Value) -> f64 {
        let sa = Self::val_str(a).to_lowercase();
        let sb = Self::val_str(b).to_lowercase();
        if sa == sb { 1.0 } else { 0.0 }
    }

    pub fn geo_distance(a: &Value, b: &Value, max_km: f64) -> f64 {
        let la = Self::extract_loc(a);
        let lb = Self::extract_loc(b);
        match (la, lb) {
            (Some((lat1, lng1)), Some((lat2, lng2))) => {
                let dist = Self::haversine_km(lat1, lng1, lat2, lng2);
                (1.0 - dist / max_km).max(0.0)
            }
            _ => 0.0,
        }
    }

    pub fn range_sim(a: &Value, b: &Value) -> f64 {
        let va = Self::val_f64(a);
        let vb = Self::val_f64(b);
        if va == 0.0 && vb == 0.0 { return 1.0; }
        let mx = va.abs().max(vb.abs());
        if mx == 0.0 { 1.0 } else { 1.0 - (va - vb).abs() / mx }
    }

    pub fn compute(sim_type: &str, a: &Value, b: &Value, config: Option<&MatchDoc>) -> f64 {
        match sim_type.to_lowercase().as_str() {
            "jaccard" => Self::jaccard(a, b),
            "exact" => Self::exact(a, b),
            "geo-distance" | "geodistance" => {
                let max_km = config.and_then(|c| c.get("maxDistanceKm")).map(Self::val_f64).unwrap_or(50.0);
                Self::geo_distance(a, b, max_km)
            }
            "range" => Self::range_sim(a, b),
            _ => Self::exact(a, b),
        }
    }

    fn to_set(v: &Value) -> HashSet<String> {
        match v {
            Value::Array(arr) => arr.iter().map(Self::val_str).collect(),
            Value::String(s) => [s.clone()].into(),
            _ => HashSet::new(),
        }
    }

    fn val_str(v: &Value) -> String {
        match v { Value::String(s) => s.clone(), _ => v.to_string().trim_matches('"').to_string() }
    }

    fn val_f64(v: &Value) -> f64 {
        match v { Value::Number(n) => n.as_f64().unwrap_or(0.0), Value::String(s) => s.parse().unwrap_or(0.0), _ => 0.0 }
    }

    fn extract_loc(v: &Value) -> Option<(f64, f64)> {
        let obj = v.as_object()?;
        let lat = obj.get("lat").map(Self::val_f64)?;
        let lng = obj.get("lng").map(Self::val_f64)?;
        Some((lat, lng))
    }

    fn haversine_km(lat1: f64, lng1: f64, lat2: f64, lng2: f64) -> f64 {
        let r = 6371.0;
        let d_lat = (lat2 - lat1).to_radians();
        let d_lng = (lng2 - lng1).to_radians();
        let a = (d_lat / 2.0).sin().powi(2)
            + lat1.to_radians().cos() * lat2.to_radians().cos() * (d_lng / 2.0).sin().powi(2);
        r * 2.0 * a.sqrt().atan2((1.0 - a).sqrt())
    }
}

// ─── Service ────────────────────────────────────────────────────
pub struct MatchingService {
    db: Box<dyn IDatabaseService>,
    queue: Box<dyn IQueueService>,
    op: Box<dyn IObjectProcessor>,
    config: MatchingConfig,
}

impl MatchingService {
    pub fn new(db: Box<dyn IDatabaseService>, queue: Box<dyn IQueueService>,
               op: Box<dyn IObjectProcessor>, config: Option<MatchingConfig>) -> Self {
        Self { db, queue, op, config: config.unwrap_or_default() }
    }

    pub async fn extract_profile(&self, data: &Value, entity_type: &str) -> DataProcessResult<MatchDoc> {
        let doc = self.op.parse_object_alternative(data);
        let entity_id = get_str(&doc, "id").or_else(|| get_str(&doc, "entityId"));
        let Some(eid) = entity_id else { return DataProcessResult::error("Missing entityId or id"); };

        let mut profile = HashMap::new();
        profile.insert("profileId".into(), val_s(&format!("{}-{}", entity_type, eid)));
        profile.insert("entityId".into(), val_s(&eid));
        profile.insert("entityType".into(), val_s(entity_type));
        profile.insert("extractedAt".into(), val_s(&Utc::now().to_rfc3339()));
        for (k, v) in &doc {
            if !["id", "password", "token"].contains(&k.as_str()) { profile.insert(k.clone(), v.clone()); }
        }

        let pid = format!("{}-{}", entity_type, eid);
        let _ = self.db.upsert(&self.config.match_profiles_index, &pid, &profile).await;
        info!("Profile extracted for {} {}", entity_type, eid);
        DataProcessResult::ok(profile, "Profile extracted")
    }

    pub async fn get_profile(&self, entity_id: &str) -> DataProcessResult<MatchDoc> {
        for t in &["user", "event", "business"] {
            let pid = format!("{}-{}", t, entity_id);
            if let Ok(Some(p)) = self.db.get_by_id(&self.config.match_profiles_index, &pid).await {
                return DataProcessResult::ok(self.op.parse_object_alternative(&serde_json::to_value(&p).unwrap()), "Found");
            }
        }
        DataProcessResult::error("Profile not found")
    }

    pub async fn compute_match(&self, id_a: &str, id_b: &str, match_type: &str) -> DataProcessResult<MatchDoc> {
        let pa = self.get_profile(id_a).await;
        let pb = self.get_profile(id_b).await;
        if !pa.success { return DataProcessResult::error(&format!("Profile A not found: {}", id_a)); }
        if !pb.success { return DataProcessResult::error(&format!("Profile B not found: {}", id_b)); }
        let pa_data = pa.data.unwrap();
        let pb_data = pb.data.unwrap();

        let criteria_config = self.load_criteria_config(match_type).await;
        let criteria = self.extract_criteria(&criteria_config);

        let mut score = self.compute_weighted_score(&pa_data, &pb_data, &criteria);

        if criteria_config.get("bidirectional").and_then(|v| v.as_bool()).unwrap_or(false) {
            let reverse = self.compute_weighted_score(&pb_data, &pa_data, &criteria);
            let strategy = get_str(&criteria_config, "bidirectionalStrategy").unwrap_or_default();
            score = if strategy == "minimum" { score.min(reverse) } else { (score + reverse) / 2.0 };
        }

        let match_id = format!("match-{}-{}-{}", id_a, id_b, match_type);
        let mut result = HashMap::new();
        result.insert("matchId".into(), val_s(&match_id));
        result.insert("entityIdA".into(), val_s(id_a));
        result.insert("entityIdB".into(), val_s(id_b));
        result.insert("matchType".into(), val_s(match_type));
        result.insert("score".into(), serde_json::to_value((score * 10000.0).round() / 10000.0).unwrap());
        result.insert("status".into(), val_s("pending"));
        result.insert("computedAt".into(), val_s(&Utc::now().to_rfc3339()));

        let _ = self.db.upsert(&self.config.match_results_index, &match_id, &result).await;

        let mut event = HashMap::new();
        event.insert("eventType".into(), val_s("MatchCalculated"));
        event.insert("matchId".into(), val_s(&match_id));
        event.insert("score".into(), result.get("score").cloned().unwrap_or_default());
        let _ = self.queue.publish("match-events", &event).await;

        DataProcessResult::ok(result, "Match computed")
    }

    pub async fn find_matches(&self, entity_id: &str, match_type: &str, top_n: usize) -> DataProcessResult<Vec<MatchDoc>> {
        let top_n = top_n.clamp(1, 100);
        let target_type = match_type.rsplit('-').next().unwrap_or("user");
        let mut filter = HashMap::new();
        filter.insert("entityType".into(), val_s(target_type));
        let filter = self.op.build_search_filter(&filter);
        let candidates = self.db.query(&self.config.match_profiles_index, &filter, self.config.batch_size, 0).await.unwrap_or_default();

        let criteria_config = self.load_criteria_config(match_type).await;
        let criteria = self.extract_criteria(&criteria_config);
        let min_score = get_f64(&criteria_config, "minScoreThreshold", self.config.default_min_score);

        let source = self.get_profile(entity_id).await;
        if !source.success { return DataProcessResult::error(&format!("Source not found: {}", entity_id)); }
        let source_data = source.data.unwrap();

        let mut results: Vec<MatchDoc> = Vec::new();
        for cand in &candidates {
            let parsed = self.op.parse_object_alternative(&serde_json::to_value(cand).unwrap());
            let cid = get_str(&parsed, "entityId").unwrap_or_default();
            if cid == entity_id { continue; }
            let score = self.compute_weighted_score(&source_data, &parsed, &criteria);
            if score >= min_score {
                let mut r = HashMap::new();
                r.insert("entityId".into(), val_s(&cid));
                r.insert("score".into(), serde_json::to_value((score * 10000.0).round() / 10000.0).unwrap());
                r.insert("matchType".into(), val_s(match_type));
                results.push(r);
            }
        }

        results.sort_by(|a, b| get_f64(b, "score", 0.0).partial_cmp(&get_f64(a, "score", 0.0)).unwrap());
        results.truncate(top_n);
        DataProcessResult::ok(results, "Matches found")
    }

    pub async fn accept_match(&self, user_id: &str, match_id: &str) -> DataProcessResult<bool> {
        self.update_status(user_id, match_id, "accepted", "MatchAccepted").await
    }

    pub async fn decline_match(&self, user_id: &str, match_id: &str) -> DataProcessResult<bool> {
        self.update_status(user_id, match_id, "declined", "MatchDeclined").await
    }

    async fn update_status(&self, user_id: &str, match_id: &str, status: &str, event_type: &str) -> DataProcessResult<bool> {
        match self.db.get_by_id(&self.config.match_results_index, match_id).await {
            Ok(Some(item)) => {
                let mut parsed = self.op.parse_object_alternative(&serde_json::to_value(&item).unwrap());
                let ea = get_str(&parsed, "entityIdA").unwrap_or_default();
                let eb = get_str(&parsed, "entityIdB").unwrap_or_default();
                if ea != user_id && eb != user_id { return DataProcessResult::error("Access denied — scope mismatch"); }
                parsed.insert("status".into(), val_s(status));
                parsed.insert(format!("{}By", status), val_s(user_id));
                parsed.insert(format!("{}At", status), val_s(&Utc::now().to_rfc3339()));
                let _ = self.db.upsert(&self.config.match_results_index, match_id, &parsed).await;
                let mut ev = HashMap::new();
                ev.insert("eventType".into(), val_s(event_type));
                ev.insert("matchId".into(), val_s(match_id));
                let _ = self.queue.publish("match-events", &ev).await;
                DataProcessResult::ok(true, &format!("Match {}", status))
            }
            _ => DataProcessResult::error("Match not found"),
        }
    }

    // ─── Scoring ────────────────────────────────────────────────

    fn compute_weighted_score(&self, a: &MatchDoc, b: &MatchDoc, criteria: &[CriterionDef]) -> f64 {
        let (mut tw, mut ws) = (0.0, 0.0);
        for c in criteria {
            let av = a.get(&c.field).unwrap_or(&Value::Null);
            let bv = b.get(&c.field).unwrap_or(&Value::Null);
            if av.is_null() && bv.is_null() { continue; }
            let sim = SimilarityFunctions::compute(&c.similarity, av, bv, c.config.as_ref());
            ws += c.weight * sim;
            tw += c.weight;
        }
        if tw == 0.0 { 0.0 } else { ws / tw }
    }

    fn extract_criteria(&self, config: &MatchDoc) -> Vec<CriterionDef> {
        if let Some(Value::Object(m)) = config.get("criteria") {
            return m.iter().map(|(field, cfg)| {
                let c = self.op.parse_object_alternative(cfg);
                CriterionDef {
                    field: field.clone(),
                    weight: get_f64(&c, "weight", 1.0),
                    similarity: get_str(&c, "similarity").unwrap_or("exact".into()),
                    config: Some(c),
                }
            }).collect();
        }
        vec![
            CriterionDef { field: "interests".into(), weight: 0.3, similarity: "jaccard".into(), config: None },
            CriterionDef { field: "location".into(), weight: 0.2, similarity: "geo-distance".into(),
                config: Some([("maxDistanceKm".into(), serde_json::to_value(50.0).unwrap())].into()) },
            CriterionDef { field: "industry".into(), weight: 0.25, similarity: "exact".into(), config: None },
            CriterionDef { field: "goals".into(), weight: 0.15, similarity: "jaccard".into(), config: None },
            CriterionDef { field: "companySize".into(), weight: 0.1, similarity: "range".into(), config: None },
        ]
    }

    async fn load_criteria_config(&self, match_type: &str) -> MatchDoc {
        let cid = format!("match-criteria-{}", match_type);
        if let Ok(Some(c)) = self.db.get_by_id(&self.config.match_config_index, &cid).await {
            return self.op.parse_object_alternative(&serde_json::to_value(&c).unwrap());
        }
        let mut d = HashMap::new();
        d.insert("matchType".into(), val_s(match_type));
        d.insert("minScoreThreshold".into(), serde_json::to_value(self.config.default_min_score).unwrap());
        d.insert("bidirectional".into(), Value::Bool(match_type == "user-user"));
        d.insert("bidirectionalStrategy".into(), val_s(&self.config.default_bidirectional_strategy));
        d
    }
}

// ─── Helpers ────────────────────────────────────────────────────
fn val_s(s: &str) -> Value { Value::String(s.to_string()) }
fn get_str(m: &MatchDoc, k: &str) -> Option<String> {
    m.get(k).map(|v| match v { Value::String(s) => s.clone(), _ => v.to_string().trim_matches('"').to_string() })
}
fn get_f64(m: &MatchDoc, k: &str, fallback: f64) -> f64 {
    m.get(k).and_then(|v| match v { Value::Number(n) => n.as_f64(), Value::String(s) => s.parse().ok(), _ => None }).unwrap_or(fallback)
}
