// XIIGen.Services.Matching/MatchingService.cs — Skill 47 | .NET 9
// Multi-criteria matching engine with weighted scoring, bidirectional computation
// Genie DNA: DNA-1 (Dictionary<string,object>), DNA-2 (BuildSearchFilter), DNA-5 (DataProcessResult)

using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System.Text.Json;
using XIIGen.Core.Base;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Services.Matching;

// ─── Configuration ──────────────────────────────────────────────
public class MatchingConfig
{
    public string MatchResultsIndex { get; set; } = "match-results";
    public string MatchProfilesIndex { get; set; } = "match-profiles";
    public string MatchConfigIndex { get; set; } = "match-config";
    public double DefaultMinScore { get; set; } = 0.3;
    public int DefaultTopN { get; set; } = 20;
    public int BatchSize { get; set; } = 100;
    public string DefaultBidirectionalStrategy { get; set; } = "average";
}

// ─── Similarity Functions ───────────────────────────────────────
public static class SimilarityFunctions
{
    public static double Jaccard(object? aVal, object? bVal)
    {
        var setA = ExtractSet(aVal);
        var setB = ExtractSet(bVal);
        if (setA.Count == 0 && setB.Count == 0) return 0.0;
        var intersection = setA.Intersect(setB).Count();
        var union = setA.Union(setB).Count();
        return union == 0 ? 0.0 : (double)intersection / union;
    }

    public static double Exact(object? aVal, object? bVal)
    {
        var a = aVal?.ToString() ?? "";
        var b = bVal?.ToString() ?? "";
        return a.Equals(b, StringComparison.OrdinalIgnoreCase) ? 1.0 : 0.0;
    }

    public static double GeoDistance(object? aVal, object? bVal, double maxDistanceKm = 50.0)
    {
        var locA = ExtractLocation(aVal);
        var locB = ExtractLocation(bVal);
        if (locA == null || locB == null) return 0.0;

        var distance = HaversineKm(locA.Value.lat, locA.Value.lng, locB.Value.lat, locB.Value.lng);
        return Math.Max(0.0, 1.0 - distance / maxDistanceKm);
    }

    public static double Range(object? aVal, object? bVal)
    {
        var a = ToDouble(aVal);
        var b = ToDouble(bVal);
        if (a == 0 && b == 0) return 1.0;
        var maxVal = Math.Max(Math.Abs(a), Math.Abs(b));
        return maxVal == 0 ? 1.0 : 1.0 - Math.Abs(a - b) / maxVal;
    }

    public static double Compute(string similarityType, object? aVal, object? bVal, Dictionary<string, object>? config = null)
    {
        return similarityType.ToLowerInvariant() switch
        {
            "jaccard" => Jaccard(aVal, bVal),
            "exact" => Exact(aVal, bVal),
            "geo-distance" or "geodistance" =>
                GeoDistance(aVal, bVal, config != null ? GetDouble(config, "maxDistanceKm", 50.0) : 50.0),
            "range" => Range(aVal, bVal),
            _ => Exact(aVal, bVal)
        };
    }

    // ─── Helpers ────────────────────────────────────────────────

    private static HashSet<string> ExtractSet(object? val)
    {
        if (val is JsonElement je)
        {
            if (je.ValueKind == JsonValueKind.Array)
                return je.EnumerateArray().Select(e => e.GetString() ?? "").Where(s => s != "").ToHashSet();
            return [je.GetString() ?? ""];
        }
        if (val is IEnumerable<object> list) return list.Select(o => o.ToString() ?? "").ToHashSet();
        if (val is string s) return [s];
        return [];
    }

    private static (double lat, double lng)? ExtractLocation(object? val)
    {
        if (val is Dictionary<string, object> dict)
        {
            var lat = GetDouble(dict, "lat", double.NaN);
            var lng = GetDouble(dict, "lng", double.NaN);
            if (!double.IsNaN(lat) && !double.IsNaN(lng)) return (lat, lng);
        }
        if (val is JsonElement je && je.ValueKind == JsonValueKind.Object)
        {
            if (je.TryGetProperty("lat", out var latEl) && je.TryGetProperty("lng", out var lngEl))
            {
                if (latEl.TryGetDouble(out var lat) && lngEl.TryGetDouble(out var lng))
                    return (lat, lng);
            }
        }
        return null;
    }

    private static double HaversineKm(double lat1, double lng1, double lat2, double lng2)
    {
        const double R = 6371.0;
        var dLat = (lat2 - lat1) * Math.PI / 180;
        var dLng = (lng2 - lng1) * Math.PI / 180;
        var a = Math.Sin(dLat / 2) * Math.Sin(dLat / 2) +
                Math.Cos(lat1 * Math.PI / 180) * Math.Cos(lat2 * Math.PI / 180) *
                Math.Sin(dLng / 2) * Math.Sin(dLng / 2);
        return R * 2 * Math.Atan2(Math.Sqrt(a), Math.Sqrt(1 - a));
    }

    private static double ToDouble(object? val)
    {
        if (val is double d) return d;
        if (val is int i) return i;
        if (val is long l) return l;
        if (val is JsonElement je && je.TryGetDouble(out var jd)) return jd;
        if (double.TryParse(val?.ToString(), out var parsed)) return parsed;
        return 0.0;
    }

    internal static double GetDouble(Dictionary<string, object> doc, string key, double fallback)
    {
        if (doc.TryGetValue(key, out var val)) return ToDouble(val);
        return fallback;
    }
}

// ─── Service Interface ──────────────────────────────────────────
public interface IMatchingService
{
    // Profile
    Task<DataProcessResult<Dictionary<string, object>>> ExtractProfileAsync(
        Dictionary<string, object> entityData, string entityType, CancellationToken ct = default);
    Task<DataProcessResult<Dictionary<string, object>>> GetProfileAsync(
        string entityId, CancellationToken ct = default);

    // Matching
    Task<DataProcessResult<Dictionary<string, object>>> ComputeMatchAsync(
        string entityIdA, string entityIdB, string matchType, CancellationToken ct = default);
    Task<DataProcessResult<List<Dictionary<string, object>>>> FindMatchesAsync(
        string entityId, string matchType, int topN, CancellationToken ct = default);
    Task<DataProcessResult<List<Dictionary<string, object>>>> BatchMatchAsync(
        string entityId, List<string> candidateIds, string matchType, CancellationToken ct = default);

    // Management
    Task<DataProcessResult<bool>> AcceptMatchAsync(string userId, string matchId, CancellationToken ct = default);
    Task<DataProcessResult<bool>> DeclineMatchAsync(string userId, string matchId, CancellationToken ct = default);
    Task<DataProcessResult<List<Dictionary<string, object>>>> ListMatchesAsync(
        string entityId, Dictionary<string, object>? filter, int page, int pageSize, CancellationToken ct = default);

    // Config
    Task<DataProcessResult<Dictionary<string, object>>> GetCriteriaConfigAsync(
        string matchType, CancellationToken ct = default);
    Task<DataProcessResult<Dictionary<string, object>>> UpdateCriteriaConfigAsync(
        string matchType, Dictionary<string, object> config, CancellationToken ct = default);
}

// ─── Service Implementation ─────────────────────────────────────
public class MatchingService : IMatchingService
{
    private readonly IDatabaseService _db;
    private readonly IQueueService _queue;
    private readonly IObjectProcessor _objectProcessor;
    private readonly ILogger<MatchingService> _logger;
    private readonly MatchingConfig _config;

    public MatchingService(
        IDatabaseService db, IQueueService queue, IObjectProcessor objectProcessor,
        ILogger<MatchingService> logger, MatchingConfig? config = null)
    {
        _db = db; _queue = queue; _objectProcessor = objectProcessor;
        _logger = logger; _config = config ?? new MatchingConfig();
    }

    // ─── Profile ────────────────────────────────────────────────

    public async Task<DataProcessResult<Dictionary<string, object>>> ExtractProfileAsync(
        Dictionary<string, object> entityData, string entityType, CancellationToken ct = default)
    {
        try
        {
            var doc = _objectProcessor.ParseObjectAlternative(entityData);
            var entityId = GetString(doc, "id") != "" ? GetString(doc, "id") : GetString(doc, "entityId");
            if (string.IsNullOrEmpty(entityId))
                return DataProcessResult<Dictionary<string, object>>.Error("Missing entityId or id");

            var profile = new Dictionary<string, object>
            {
                ["profileId"] = $"{entityType}-{entityId}",
                ["entityId"] = entityId,
                ["entityType"] = entityType,
                ["extractedAt"] = DateTime.UtcNow.ToString("o")
            };

            // Copy all fields from entity data into profile (DNA-1: dynamic)
            foreach (var kvp in doc)
            {
                if (kvp.Key is "id" or "password" or "token") continue;
                profile[kvp.Key] = kvp.Value;
            }

            await _db.UpsertAsync(_config.MatchProfilesIndex, profile["profileId"].ToString()!, profile, ct);

            _logger.LogInformation("Profile extracted for {EntityType} {EntityId}", entityType, entityId);
            return DataProcessResult<Dictionary<string, object>>.Success(profile);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "ExtractProfile failed");
            return DataProcessResult<Dictionary<string, object>>.Error(ex.Message);
        }
    }

    public async Task<DataProcessResult<Dictionary<string, object>>> GetProfileAsync(
        string entityId, CancellationToken ct = default)
    {
        try
        {
            // Try user type first, then event, then business
            foreach (var type in new[] { "user", "event", "business" })
            {
                var profile = await _db.GetByIdAsync(_config.MatchProfilesIndex, $"{type}-{entityId}", ct);
                if (profile != null)
                    return DataProcessResult<Dictionary<string, object>>.Success(
                        _objectProcessor.ParseObjectAlternative(profile));
            }
            return DataProcessResult<Dictionary<string, object>>.Error("Profile not found");
        }
        catch (Exception ex)
        {
            return DataProcessResult<Dictionary<string, object>>.Error(ex.Message);
        }
    }

    // ─── Match Computation ──────────────────────────────────────

    public async Task<DataProcessResult<Dictionary<string, object>>> ComputeMatchAsync(
        string entityIdA, string entityIdB, string matchType, CancellationToken ct = default)
    {
        try
        {
            var profileA = await GetProfileAsync(entityIdA, ct);
            var profileB = await GetProfileAsync(entityIdB, ct);
            if (!profileA.Success) return DataProcessResult<Dictionary<string, object>>.Error($"Profile A not found: {entityIdA}");
            if (!profileB.Success) return DataProcessResult<Dictionary<string, object>>.Error($"Profile B not found: {entityIdB}");

            var criteriaConfig = await LoadCriteriaConfigAsync(matchType, ct);
            var criteria = ExtractCriteria(criteriaConfig);

            // Compute weighted score
            var score = ComputeWeightedScore(profileA.Data!, profileB.Data!, criteria);

            // Bidirectional check
            var bidirectional = GetBool(criteriaConfig, "bidirectional", false);
            if (bidirectional)
            {
                var reverseScore = ComputeWeightedScore(profileB.Data!, profileA.Data!, criteria);
                var strategy = GetString(criteriaConfig, "bidirectionalStrategy");
                score = strategy == "minimum" ? Math.Min(score, reverseScore) : (score + reverseScore) / 2.0;
            }

            var matchResult = new Dictionary<string, object>
            {
                ["matchId"] = $"match-{entityIdA}-{entityIdB}-{matchType}",
                ["entityIdA"] = entityIdA,
                ["entityIdB"] = entityIdB,
                ["matchType"] = matchType,
                ["score"] = Math.Round(score, 4),
                ["status"] = "pending",
                ["criteriaBreakdown"] = ComputeBreakdown(profileA.Data!, profileB.Data!, criteria),
                ["computedAt"] = DateTime.UtcNow.ToString("o")
            };

            await _db.UpsertAsync(_config.MatchResultsIndex, matchResult["matchId"].ToString()!, matchResult, ct);

            await _queue.PublishAsync("match-events", new Dictionary<string, object>
            {
                ["eventType"] = "MatchCalculated",
                ["matchId"] = matchResult["matchId"],
                ["entityIdA"] = entityIdA,
                ["entityIdB"] = entityIdB,
                ["score"] = matchResult["score"],
                ["matchType"] = matchType,
                ["timestamp"] = DateTime.UtcNow.ToString("o")
            }, ct);

            return DataProcessResult<Dictionary<string, object>>.Success(matchResult);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "ComputeMatch failed for {A}↔{B}", entityIdA, entityIdB);
            return DataProcessResult<Dictionary<string, object>>.Error(ex.Message);
        }
    }

    public async Task<DataProcessResult<List<Dictionary<string, object>>>> FindMatchesAsync(
        string entityId, string matchType, int topN, CancellationToken ct = default)
    {
        try
        {
            topN = Math.Clamp(topN, 1, 100);

            // Get all profiles of the target entity type
            var targetType = matchType.Split('-').LastOrDefault() ?? "user";
            var filter = _objectProcessor.BuildSearchFilter(new Dictionary<string, object>
            {
                ["entityType"] = targetType
            });
            var candidates = await _db.QueryAsync(_config.MatchProfilesIndex, filter, _config.BatchSize, 0, ct);

            var criteriaConfig = await LoadCriteriaConfigAsync(matchType, ct);
            var criteria = ExtractCriteria(criteriaConfig);
            var minScore = SimilarityFunctions.GetDouble(criteriaConfig, "minScoreThreshold", _config.DefaultMinScore);

            var sourceProfile = await GetProfileAsync(entityId, ct);
            if (!sourceProfile.Success)
                return DataProcessResult<List<Dictionary<string, object>>>.Error($"Source profile not found: {entityId}");

            var results = new List<Dictionary<string, object>>();
            foreach (var candidate in candidates ?? [])
            {
                var parsed = _objectProcessor.ParseObjectAlternative(candidate);
                var candidateId = GetString(parsed, "entityId");
                if (candidateId == entityId) continue; // skip self

                var score = ComputeWeightedScore(sourceProfile.Data!, parsed, criteria);
                if (score >= minScore)
                {
                    results.Add(new Dictionary<string, object>
                    {
                        ["entityId"] = candidateId,
                        ["score"] = Math.Round(score, 4),
                        ["matchType"] = matchType,
                        ["breakdown"] = ComputeBreakdown(sourceProfile.Data!, parsed, criteria)
                    });
                }
            }

            var sorted = results
                .OrderByDescending(r => SimilarityFunctions.GetDouble(r, "score", 0))
                .Take(topN)
                .ToList();

            return DataProcessResult<List<Dictionary<string, object>>>.Success(sorted,
                $"Found {sorted.Count} matches above {minScore} threshold");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "FindMatches failed for {EntityId}", entityId);
            return DataProcessResult<List<Dictionary<string, object>>>.Error(ex.Message);
        }
    }

    public async Task<DataProcessResult<List<Dictionary<string, object>>>> BatchMatchAsync(
        string entityId, List<string> candidateIds, string matchType, CancellationToken ct = default)
    {
        try
        {
            var results = new List<Dictionary<string, object>>();
            foreach (var candidateId in candidateIds)
            {
                var result = await ComputeMatchAsync(entityId, candidateId, matchType, ct);
                if (result.Success && result.Data != null)
                    results.Add(result.Data);
            }

            await _queue.PublishAsync("match-events", new Dictionary<string, object>
            {
                ["eventType"] = "BatchMatchComplete",
                ["entityId"] = entityId,
                ["matchType"] = matchType,
                ["matchCount"] = results.Count,
                ["timestamp"] = DateTime.UtcNow.ToString("o")
            }, ct);

            return DataProcessResult<List<Dictionary<string, object>>>.Success(results,
                $"Batch computed {results.Count}/{candidateIds.Count} matches");
        }
        catch (Exception ex)
        {
            return DataProcessResult<List<Dictionary<string, object>>>.Error(ex.Message);
        }
    }

    // ─── Management ─────────────────────────────────────────────

    public async Task<DataProcessResult<bool>> AcceptMatchAsync(
        string userId, string matchId, CancellationToken ct = default)
    {
        try
        {
            var match = await _db.GetByIdAsync(_config.MatchResultsIndex, matchId, ct);
            if (match == null) return DataProcessResult<bool>.Error("Match not found");

            var parsed = _objectProcessor.ParseObjectAlternative(match);
            if (GetString(parsed, "entityIdA") != userId && GetString(parsed, "entityIdB") != userId)
                return DataProcessResult<bool>.Error("Access denied — scope mismatch");

            parsed["status"] = "accepted";
            parsed["acceptedBy"] = userId;
            parsed["acceptedAt"] = DateTime.UtcNow.ToString("o");
            await _db.UpsertAsync(_config.MatchResultsIndex, matchId, parsed, ct);

            await _queue.PublishAsync("match-events", new Dictionary<string, object>
            {
                ["eventType"] = "MatchAccepted",
                ["matchId"] = matchId,
                ["acceptedBy"] = userId,
                ["timestamp"] = DateTime.UtcNow.ToString("o")
            }, ct);

            return DataProcessResult<bool>.Success(true, "Match accepted");
        }
        catch (Exception ex)
        {
            return DataProcessResult<bool>.Error(ex.Message);
        }
    }

    public async Task<DataProcessResult<bool>> DeclineMatchAsync(
        string userId, string matchId, CancellationToken ct = default)
    {
        try
        {
            var match = await _db.GetByIdAsync(_config.MatchResultsIndex, matchId, ct);
            if (match == null) return DataProcessResult<bool>.Error("Match not found");

            var parsed = _objectProcessor.ParseObjectAlternative(match);
            if (GetString(parsed, "entityIdA") != userId && GetString(parsed, "entityIdB") != userId)
                return DataProcessResult<bool>.Error("Access denied — scope mismatch");

            parsed["status"] = "declined";
            parsed["declinedBy"] = userId;
            parsed["declinedAt"] = DateTime.UtcNow.ToString("o");
            await _db.UpsertAsync(_config.MatchResultsIndex, matchId, parsed, ct);

            await _queue.PublishAsync("match-events", new Dictionary<string, object>
            {
                ["eventType"] = "MatchDeclined",
                ["matchId"] = matchId,
                ["declinedBy"] = userId,
                ["timestamp"] = DateTime.UtcNow.ToString("o")
            }, ct);

            return DataProcessResult<bool>.Success(true, "Match declined");
        }
        catch (Exception ex)
        {
            return DataProcessResult<bool>.Error(ex.Message);
        }
    }

    public async Task<DataProcessResult<List<Dictionary<string, object>>>> ListMatchesAsync(
        string entityId, Dictionary<string, object>? filter, int page, int pageSize,
        CancellationToken ct = default)
    {
        try
        {
            pageSize = Math.Clamp(pageSize, 1, 100);
            var baseFilter = new Dictionary<string, object> { ["entityIdA"] = entityId };
            if (filter != null)
                foreach (var kvp in filter)
                    baseFilter[kvp.Key] = kvp.Value;

            var searchFilter = _objectProcessor.BuildSearchFilter(baseFilter);
            var results = await _db.QueryAsync(_config.MatchResultsIndex, searchFilter,
                pageSize, page * pageSize, ct);

            return DataProcessResult<List<Dictionary<string, object>>>.Success(
                (results ?? []).Select(r => _objectProcessor.ParseObjectAlternative(r)).ToList());
        }
        catch (Exception ex)
        {
            return DataProcessResult<List<Dictionary<string, object>>>.Error(ex.Message);
        }
    }

    // ─── Config (FREEDOM) ───────────────────────────────────────

    public async Task<DataProcessResult<Dictionary<string, object>>> GetCriteriaConfigAsync(
        string matchType, CancellationToken ct = default)
    {
        var config = await LoadCriteriaConfigAsync(matchType, ct);
        return DataProcessResult<Dictionary<string, object>>.Success(config);
    }

    public async Task<DataProcessResult<Dictionary<string, object>>> UpdateCriteriaConfigAsync(
        string matchType, Dictionary<string, object> config, CancellationToken ct = default)
    {
        try
        {
            var doc = _objectProcessor.ParseObjectAlternative(config);
            doc["configId"] = $"match-criteria-{matchType}";
            doc["matchType"] = matchType;
            doc["updatedAt"] = DateTime.UtcNow.ToString("o");

            await _db.UpsertAsync(_config.MatchConfigIndex, doc["configId"].ToString()!, doc, ct);
            return DataProcessResult<Dictionary<string, object>>.Success(doc);
        }
        catch (Exception ex)
        {
            return DataProcessResult<Dictionary<string, object>>.Error(ex.Message);
        }
    }

    // ─── Scoring Engine (MACHINE) ───────────────────────────────

    private double ComputeWeightedScore(
        Dictionary<string, object> profileA,
        Dictionary<string, object> profileB,
        List<(string field, double weight, string similarity, Dictionary<string, object>? config)> criteria)
    {
        double totalWeight = 0, weightedScore = 0;
        foreach (var (field, weight, similarity, config) in criteria)
        {
            profileA.TryGetValue(field, out var aVal);
            profileB.TryGetValue(field, out var bVal);
            if (aVal == null && bVal == null) continue;

            var sim = SimilarityFunctions.Compute(similarity, aVal, bVal, config);
            weightedScore += weight * sim;
            totalWeight += weight;
        }
        return totalWeight == 0 ? 0 : weightedScore / totalWeight;
    }

    private Dictionary<string, object> ComputeBreakdown(
        Dictionary<string, object> profileA,
        Dictionary<string, object> profileB,
        List<(string field, double weight, string similarity, Dictionary<string, object>? config)> criteria)
    {
        var breakdown = new Dictionary<string, object>();
        foreach (var (field, weight, similarity, config) in criteria)
        {
            profileA.TryGetValue(field, out var aVal);
            profileB.TryGetValue(field, out var bVal);
            var sim = SimilarityFunctions.Compute(similarity, aVal, bVal, config);
            breakdown[field] = new Dictionary<string, object>
            {
                ["similarity"] = Math.Round(sim, 4),
                ["weight"] = weight,
                ["weighted"] = Math.Round(sim * weight, 4)
            };
        }
        return breakdown;
    }

    private List<(string field, double weight, string similarity, Dictionary<string, object>? config)>
        ExtractCriteria(Dictionary<string, object> criteriaConfig)
    {
        var result = new List<(string, double, string, Dictionary<string, object>?)>();
        if (criteriaConfig.TryGetValue("criteria", out var criteriaObj))
        {
            var criteriaDict = _objectProcessor.ParseObjectAlternative(criteriaObj);
            foreach (var kvp in criteriaDict)
            {
                var fieldConfig = _objectProcessor.ParseObjectAlternative(kvp.Value);
                var weight = SimilarityFunctions.GetDouble(fieldConfig, "weight", 1.0);
                var similarity = GetString(fieldConfig, "similarity");
                if (string.IsNullOrEmpty(similarity)) similarity = "exact";
                result.Add((kvp.Key, weight, similarity, fieldConfig));
            }
        }
        if (result.Count == 0)
        {
            // Default criteria
            result.Add(("interests", 0.3, "jaccard", null));
            result.Add(("location", 0.2, "geo-distance", new Dictionary<string, object> { ["maxDistanceKm"] = 50.0 }));
            result.Add(("industry", 0.25, "exact", null));
            result.Add(("goals", 0.15, "jaccard", null));
            result.Add(("companySize", 0.10, "range", null));
        }
        return result;
    }

    private async Task<Dictionary<string, object>> LoadCriteriaConfigAsync(string matchType, CancellationToken ct)
    {
        try
        {
            var config = await _db.GetByIdAsync(_config.MatchConfigIndex, $"match-criteria-{matchType}", ct);
            if (config != null) return _objectProcessor.ParseObjectAlternative(config);
        }
        catch { }
        return new Dictionary<string, object>
        {
            ["matchType"] = matchType,
            ["minScoreThreshold"] = _config.DefaultMinScore,
            ["bidirectional"] = matchType == "user-user",
            ["bidirectionalStrategy"] = _config.DefaultBidirectionalStrategy
        };
    }

    // ─── Helpers ────────────────────────────────────────────────

    private static string GetString(Dictionary<string, object> doc, string key)
    {
        if (doc.TryGetValue(key, out var val))
        {
            if (val is JsonElement je) return je.GetString() ?? "";
            return val?.ToString() ?? "";
        }
        return "";
    }

    private static bool GetBool(Dictionary<string, object> doc, string key, bool fallback)
    {
        if (doc.TryGetValue(key, out var val))
        {
            if (val is bool b) return b;
            if (val is JsonElement je && je.ValueKind == JsonValueKind.True) return true;
            if (val is JsonElement je2 && je2.ValueKind == JsonValueKind.False) return false;
        }
        return fallback;
    }
}

// ─── DI Registration ────────────────────────────────────────────
public static class MatchingServiceExtensions
{
    public static IServiceCollection AddXIIGenMatchingService(
        this IServiceCollection services, Action<MatchingConfig>? configure = null)
    {
        var config = new MatchingConfig();
        configure?.Invoke(config);
        services.AddSingleton(config);
        services.AddSingleton<IMatchingService, MatchingService>();
        return services;
    }
}
