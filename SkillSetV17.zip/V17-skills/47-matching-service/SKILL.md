---
skill_id: "47"
name: "matching-service"
title: "Matching Service"
layer: "L9: Social Engine"
version: "17.0"
status: "active"
dependencies:
  - "01-core-interfaces"
  - "02-object-processor"
  - "03-elasticsearch-datastore"
  - "04-redis-queue-service"
  - "43-calculator-metrics"
  - "57-weight-calculator"
dotnet_namespace: "XIIGen.Services.Matching"
di_registration: "services.AddXIIGenMatchingService()"
es_indices:
  - "match-results"
  - "match-profiles"
  - "match-config"
genie_dna:
  - "DNA-1: Match profiles and results as Dictionary<string,object> — arbitrary criteria fields"
  - "DNA-2: BuildSearchFilter for match queries — score range, category, status — skip empty"
  - "DNA-3: Inherits MicroserviceBase with all 19 architectural components"
  - "DNA-5: All operations return DataProcessResult<T>"
  - "DNA-SCOPE: Users see only their own matches; admins see all; match pairs see shared match"
  - "DNA-FREEDOM: Match criteria weights, score thresholds, and category definitions are dynamic documents — admins configure without code changes"
  - "DNA-7: Event-driven — publishes MatchCalculated, MatchAccepted, MatchDeclined; subscribes to UserProfileUpdated, QuestionnaireCompleted, EventCreated"
component_classification:
  machine_parts:
    - "Multi-criteria scoring algorithm (weighted dot-product)"
    - "Profile vector extraction (normalize diverse fields)"
    - "Batch matching engine (compute scores for N×M pairs)"
  freedom_parts:
    - "Match criteria definitions (admin-managed weight configurations)"
    - "Score thresholds (admin-configurable minimum match scores)"
    - "Category weights (admin-tunable per match type)"
    - "Match type definitions (user↔user, user↔event, business↔business)"
---

# Skill 47: Matching Service

## Purpose
Computes compatibility scores between entities across the XIIGen social platform. The Matching
Service is the highest-frequency domain service across all 8 UML diagrams (appears in 7 of 8),
powering user-to-user connections, user-to-event recommendations, business-to-business partnerships,
and content-to-audience targeting. It uses a multi-criteria weighted scoring algorithm where match
criteria and weights are FREEDOM components — admins define what matters and how much, while the
scoring engine (MACHINE) computes results.

## Architecture

```
┌──────────────┐     ┌───────────────────────┐     ┌─────────────────┐
│ User Profile │────▶│                       │     │  Elasticsearch  │
│ (Skill 20)   │     │   Matching Service    │────▶│ "match-results" │
├──────────────┤     │                       │     │ "match-profiles"│
│ Questionnaire│────▶│  ┌─────────────────┐  │     └─────────────────┘
│ (Skill 51)   │     │  │ Extract Profile │  │            │
├──────────────┤     │  │ Compute Score   │  │◀───────────┘
│ Event Mgmt   │────▶│  │ Rank Matches    │  │     ┌─────────────────┐
│ (Skill 53)   │     │  │ Batch Process   │  │────▶│  Event Bus      │
├──────────────┤     │  └─────────────────┘  │     │ MatchCalculated │
│ Weight Calc  │────▶│                       │     │ MatchAccepted   │
│ (Skill 57)   │     └───────────────────────┘     └─────────────────┘
                              │
                     ┌────────▼────────┐
                     │  Match Config   │
                     │  (dynamic docs) │
                     │  criteria defs  │
                     │  weight tables  │
                     │  thresholds     │
                     └─────────────────┘
```

## Key Concepts

- **Match Profile** — A normalized vector extracted from an entity's data (user, event, business). Contains weighted fields like interests, location, industry, skills, goals. Stored as a dynamic document.
- **Multi-Criteria Scoring** — Score = Σ(weight_i × similarity(field_i_A, field_i_B)) / Σ(weight_i). Each criterion (interests, location, industry) has an admin-configurable weight. Similarity functions vary by field type (Jaccard for sets, geo-distance for location, exact match for categories).
- **Match Types** — user↔user, user↔event, user↔content, business↔business. Each type has its own criteria configuration and weight table (FREEDOM).
- **Batch Matching** — For fan-out scenarios (new event → find all matching users), the service computes scores in bulk with configurable parallelism.
- **Bidirectional Scoring** — For user↔user matches, both directions are computed and the minimum/average is used (configurable).

## Core Operations

### 1. Profile Management
| Method | Description | Returns |
|--------|-------------|---------|
| `ExtractProfileAsync` | Build match profile from entity data | DataProcessResult<Dictionary> |
| `UpdateProfileAsync` | Update existing match profile | DataProcessResult<Dictionary> |
| `GetProfileAsync` | Retrieve match profile by entity ID | DataProcessResult<Dictionary> |

### 2. Match Computation
| Method | Description | Returns |
|--------|-------------|---------|
| `ComputeMatchAsync` | Score between two specific entities | DataProcessResult<Dictionary> |
| `FindMatchesAsync` | Find top-N matches for an entity | DataProcessResult<List<Dictionary>> |
| `BatchMatchAsync` | Compute matches for entity against N candidates | DataProcessResult<List<Dictionary>> |

### 3. Match Management
| Method | Description | Returns |
|--------|-------------|---------|
| `GetMatchResultAsync` | Get specific match result | DataProcessResult<Dictionary> |
| `AcceptMatchAsync` | User accepts a match suggestion | DataProcessResult<bool> |
| `DeclineMatchAsync` | User declines a match | DataProcessResult<bool> |
| `ListMatchesAsync` | Paginated matches for entity with filters | DataProcessResult<List<Dictionary>> |

### 4. Configuration (FREEDOM)
| Method | Description | Returns |
|--------|-------------|---------|
| `GetCriteriaConfigAsync` | Retrieve matching criteria for a type | DataProcessResult<Dictionary> |
| `UpdateCriteriaConfigAsync` | Admin updates criteria weights | DataProcessResult<Dictionary> |

## DNA Integration

### DNA-1: Dynamic Documents
Match profiles are `Dictionary<string, object>` with arbitrary fields:
```csharp
var profile = ObjectProcessor.ParseObjectAlternative(new {
    entityId = userId,
    entityType = "user",
    interests = new[] { "tech", "finance", "networking" },
    location = new { lat = 32.07, lng = 34.78, city = "Tel Aviv" },
    industry = "technology",
    goals = new[] { "investment", "partnership" },
    experienceYears = 15,
    companySize = "50-200",
    extractedAt = DateTime.UtcNow
});
```

### DNA-2: BuildSearchFilter
All match queries skip empty criteria:
```csharp
var filter = ObjectProcessor.BuildSearchFilter(new {
    entityType = matchType,        // "user", "event", etc.
    minScore = threshold,          // null → skipped
    status = statusFilter,         // null → skipped ("pending", "accepted")
    category = categoryFilter      // null → skipped
});
```

### DNA-FREEDOM: Dynamic Criteria
Weight tables stored as dynamic documents:
```json
{
  "configId": "match-criteria-user-user",
  "matchType": "user-user",
  "criteria": {
    "interests": { "weight": 0.30, "similarity": "jaccard" },
    "location": { "weight": 0.20, "similarity": "geo-distance", "maxDistanceKm": 50 },
    "industry": { "weight": 0.25, "similarity": "exact" },
    "goals": { "weight": 0.15, "similarity": "jaccard" },
    "companySize": { "weight": 0.10, "similarity": "range" }
  },
  "minScoreThreshold": 0.3,
  "bidirectional": true,
  "bidirectionalStrategy": "average"
}
```

## Similarity Functions

| Type | Fields | Algorithm |
|------|--------|-----------|
| `jaccard` | interests, goals, skills | |A∩B| / |A∪B| |
| `exact` | industry, category | 1.0 if equal, 0.0 if not |
| `geo-distance` | location | 1.0 - min(distance/maxDistance, 1.0) |
| `range` | companySize, experience | 1.0 - |a-b|/max(a,b) |
| `cosine` | embedding vectors | dot(A,B) / (‖A‖×‖B‖) |

## Events

### Published
- `MatchCalculated` — new match score computed between two entities
- `MatchAccepted` — user accepted a match suggestion
- `MatchDeclined` — user declined a match
- `BatchMatchComplete` — bulk matching job finished
- `MatchScoreUpdated` — recalculated score (triggers feed reorder)

### Subscribed
- `UserProfileUpdated` (from Skill 20) → re-extract profile, recalculate affected matches
- `QuestionnaireCompleted` (from Skill 51) → extract profile from answers, compute new matches
- `EventCreated` (from Skill 53) → compute user↔event matches for targeting
- `ConnectionAccepted` (from Skill 49) → boost match scores for shared connections

## Anti-Patterns

```csharp
// ❌ BAD: Hardcoded matching criteria
if (user1.Industry == user2.Industry) score += 25;
if (user1.City == user2.City) score += 20;

// ❌ BAD: Fixed model for profiles
public class MatchProfile { string Industry; string City; List<string> Interests; }

// ❌ BAD: No weights — all criteria treated equally
score = matchingFields.Count / totalFields.Count;

// ❌ BAD: No scope isolation
var allMatches = await _db.QueryAsync("match-results", new {});
```

## Test Scenarios

1. **User↔User Match**: Two users with overlapping interests (60% Jaccard) → score reflects weighted criteria
2. **User↔Event Match**: User interests align with event tags → high match score
3. **Bidirectional**: User A→B score=0.8, B→A score=0.6 → average=0.7 returned
4. **Config Update**: Admin changes interest weight from 0.3 to 0.5 → recalculated scores reflect change
5. **Batch Match**: New event → compute matches against 1000 users → ranked list returned
6. **Scope Isolation**: User A can see their own matches, not User B's
7. **Accept/Decline**: Accept triggers MatchAccepted event, Decline triggers MatchDeclined
8. **Profile Update**: User changes interests → profile re-extracted, affected matches recalculated
