// Skill 03: Elasticsearch Datastore — Node.js/TypeScript
// IDatabaseService implementation using @elastic/elasticsearch v8
import { Client } from "@elastic/elasticsearch";
import { IDatabaseService, DataProcessResult, BulkResult, SearchCondition, ok, fail, notFound, DatabaseType, QueryType } from "./core-interfaces";
import { ObjectProcessor } from "./object-processor";

export class ElasticsearchDatabaseService implements IDatabaseService {
  readonly databaseType = DatabaseType.Elasticsearch;
  private client: Client;
  private processor = new ObjectProcessor();

  constructor(connectionUrl = "http://localhost:9200") {
    this.client = new Client({ node: connectionUrl });
  }

  private idx(prefix: string, name: string) { return `${prefix}_${name}`.toLowerCase(); }

  async storeDocument(indexName: string, prefix: string, id: string, document: unknown, needToParse = true): Promise<DataProcessResult<unknown>> {
    const index = this.idx(prefix, indexName);
    const doc = needToParse ? this.processor.parseDocument(document) : document;
    try {
      await this.client.index({ index, id, body: doc, refresh: "wait_for" });
      return ok(doc);
    } catch (e: any) { return fail(e.message); }
  }

  async searchDocuments(indexName: string, prefix: string, filter: unknown, size = 10): Promise<DataProcessResult<unknown[]>> {
    const index = this.idx(prefix, indexName);
    const conditions = this.processor.buildQueryFilters(filter);
    const must = conditions.map(c => this.buildQuery(c));
    try {
      const r = await this.client.search({ index, size, body: { query: { bool: { must } } } });
      return ok(r.hits.hits.map(h => h._source));
    } catch (e: any) { return fail(e.message); }
  }

  async getDocument(indexName: string, prefix: string, id: string): Promise<DataProcessResult<unknown>> {
    try {
      const r = await this.client.get({ index: this.idx(prefix, indexName), id });
      return r.found ? ok(r._source) : notFound(`${id} not found`);
    } catch (e: any) { return e.statusCode === 404 ? notFound(`${id} not found`) : fail(e.message); }
  }

  async deleteDocument(indexName: string, prefix: string, id: string): Promise<DataProcessResult<boolean>> {
    try {
      await this.client.delete({ index: this.idx(prefix, indexName), id, refresh: "wait_for" });
      return ok(true);
    } catch (e: any) { return fail(e.message); }
  }

  async bulkUpsert(indexName: string, prefix: string, documents: Array<{ key: string; value: unknown }>): Promise<DataProcessResult<BulkResult>> {
    const index = this.idx(prefix, indexName);
    const ops = documents.flatMap(d => [{ index: { _index: index, _id: d.key } }, this.processor.parseDocument(d.value)]);
    try {
      const r = await this.client.bulk({ body: ops, refresh: "wait_for" });
      const errors = r.items.filter(i => i.index?.error).map(i => i.index!.error!.reason ?? "unknown");
      return ok({ succeeded: documents.length - errors.length, failed: errors.length, errors });
    } catch (e: any) { return fail(e.message); }
  }

  async bulkDelete(indexName: string, prefix: string, ids: string[]): Promise<DataProcessResult<BulkResult>> {
    const index = this.idx(prefix, indexName);
    const ops = ids.map(id => ({ delete: { _index: index, _id: id } }));
    try {
      const r = await this.client.bulk({ body: ops, refresh: "wait_for" });
      return ok({ succeeded: ids.length, failed: 0, errors: [] });
    } catch (e: any) { return fail(e.message); }
  }

  async getFilters(indexName: string, prefix: string, fieldName: string): Promise<DataProcessResult<Record<string, number>>> {
    try {
      const r = await this.client.search({ index: this.idx(prefix, indexName), size: 0,
        body: { aggs: { values: { terms: { field: fieldName, size: 1000 } } } } });
      const buckets = (r.aggregations?.values as any)?.buckets ?? [];
      return ok(Object.fromEntries(buckets.map((b: any) => [b.key, b.doc_count])));
    } catch (e: any) { return fail(e.message); }
  }

  async aggregate(indexName: string, prefix: string, filter: unknown, aggregations: Record<string, string>): Promise<DataProcessResult<Record<string, unknown>>> {
    const aggs: Record<string, any> = {};
    for (const [name, field] of Object.entries(aggregations)) aggs[name] = { terms: { field, size: 100 } };
    try {
      const r = await this.client.search({ index: this.idx(prefix, indexName), size: 0, body: { aggs } });
      return ok(r.aggregations as Record<string, unknown>);
    } catch (e: any) { return fail(e.message); }
  }

  async indexExists(indexName: string, prefix: string): Promise<boolean> {
    try { return await this.client.indices.exists({ index: this.idx(prefix, indexName) }).then(r => !!r); }
    catch { return false; }
  }

  async createIndex(indexName: string, prefix: string): Promise<DataProcessResult<boolean>> {
    try { await this.client.indices.create({ index: this.idx(prefix, indexName) }); return ok(true); }
    catch (e: any) { return fail(e.message); }
  }

  private buildQuery(c: SearchCondition): Record<string, any> {
    switch (c.queryType) {
      case QueryType.Equals: return { term: { [c.property]: c.value } };
      case QueryType.Contains: return { match: { [c.property]: c.value } };
      case QueryType.In: return { terms: { [c.property]: c.value } };
      case QueryType.GreaterThan: return { range: { [c.property]: { gt: c.value } } };
      case QueryType.LessThan: return { range: { [c.property]: { lt: c.value } } };
      case QueryType.Prefix: return { prefix: { [c.property]: c.value } };
      case QueryType.Exists: return { exists: { field: c.property } };
      default: return { term: { [c.property]: c.value } };
    }
  }
}
