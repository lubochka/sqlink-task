<?php
// Skill 03: Elasticsearch Datastore — PHP 8.3 / elasticsearch-php 8.x
declare(strict_types=1);

namespace XIIGen\Infrastructure\Elasticsearch;

use Elastic\Elasticsearch\ClientBuilder;
use Elastic\Elasticsearch\Client;
use XIIGen\Core\{IDatabaseService, DataProcessResult, DatabaseType, SearchCondition, QueryType, ObjectProcessor};

final class ElasticsearchDatabaseService implements IDatabaseService
{
    private readonly Client $client;
    private readonly ObjectProcessor $processor;

    public function __construct(string $connectionUrl = 'http://localhost:9200')
    {
        $this->client = ClientBuilder::create()->setHosts([$connectionUrl])->build();
        $this->processor = new ObjectProcessor();
    }

    public function databaseType(): DatabaseType { return DatabaseType::ELASTICSEARCH; }

    private function idx(string $prefix, string $name): string { return strtolower("{$prefix}_{$name}"); }

    public function storeDocument(string $indexName, string $prefix, string $id, mixed $document, bool $needToParse = true): DataProcessResult
    {
        $idx = $this->idx($prefix, $indexName);
        $doc = $needToParse ? $this->processor->parseDocument($document) : $document;
        try {
            $this->client->index(['index' => $idx, 'id' => $id, 'body' => $doc, 'refresh' => 'wait_for']);
            return DataProcessResult::ok($doc);
        } catch (\Throwable $e) { return DataProcessResult::fail($e->getMessage()); }
    }

    public function searchDocuments(string $indexName, string $prefix, mixed $filter, int $size = 10): DataProcessResult
    {
        $idx = $this->idx($prefix, $indexName);
        $conditions = $this->processor->buildQueryFilters($filter);
        $must = array_map(fn(SearchCondition $c) => $this->buildQuery($c), $conditions);
        try {
            $r = $this->client->search(['index' => $idx, 'body' => ['query' => ['bool' => ['must' => $must]], 'size' => $size]]);
            $hits = array_map(fn($h) => $h['_source'], $r['hits']['hits'] ?? []);
            return DataProcessResult::ok($hits);
        } catch (\Throwable $e) { return DataProcessResult::fail($e->getMessage()); }
    }

    public function getDocument(string $indexName, string $prefix, string $id): DataProcessResult
    {
        try {
            $r = $this->client->get(['index' => $this->idx($prefix, $indexName), 'id' => $id]);
            return ($r['found'] ?? false) ? DataProcessResult::ok($r['_source']) : DataProcessResult::notFound("{$id} not found");
        } catch (\Throwable $e) { return DataProcessResult::fail($e->getMessage()); }
    }

    public function deleteDocument(string $indexName, string $prefix, string $id): DataProcessResult
    {
        try {
            $this->client->delete(['index' => $this->idx($prefix, $indexName), 'id' => $id, 'refresh' => 'wait_for']);
            return DataProcessResult::ok(true);
        } catch (\Throwable $e) { return DataProcessResult::fail($e->getMessage()); }
    }

    public function bulkUpsert(string $indexName, string $prefix, array $documents): DataProcessResult
    {
        $idx = $this->idx($prefix, $indexName);
        $params = ['body' => [], 'refresh' => 'wait_for'];
        foreach ($documents as [$key, $value]) {
            $params['body'][] = ['index' => ['_index' => $idx, '_id' => $key]];
            $params['body'][] = $this->processor->parseDocument($value);
        }
        try {
            $r = $this->client->bulk($params);
            $errors = array_filter($r['items'] ?? [], fn($i) => isset($i['index']['error']));
            return DataProcessResult::ok(['succeeded' => count($documents) - count($errors), 'failed' => count($errors), 'errors' => array_column(array_column($errors, 'index'), 'error')]);
        } catch (\Throwable $e) { return DataProcessResult::fail($e->getMessage()); }
    }

    public function bulkDelete(string $indexName, string $prefix, array $ids): DataProcessResult
    {
        $idx = $this->idx($prefix, $indexName);
        $params = ['body' => array_map(fn($id) => ['delete' => ['_index' => $idx, '_id' => $id]], $ids), 'refresh' => 'wait_for'];
        try {
            $this->client->bulk($params);
            return DataProcessResult::ok(['succeeded' => count($ids), 'failed' => 0, 'errors' => []]);
        } catch (\Throwable $e) { return DataProcessResult::fail($e->getMessage()); }
    }

    public function getFilters(string $indexName, string $prefix, string $fieldName): DataProcessResult
    {
        try {
            $r = $this->client->search(['index' => $this->idx($prefix, $indexName), 'body' => ['size' => 0, 'aggs' => ['vals' => ['terms' => ['field' => $fieldName, 'size' => 1000]]]]]);
            $result = [];
            foreach ($r['aggregations']['vals']['buckets'] ?? [] as $b) { $result[$b['key']] = $b['doc_count']; }
            return DataProcessResult::ok($result);
        } catch (\Throwable $e) { return DataProcessResult::fail($e->getMessage()); }
    }

    public function aggregate(string $indexName, string $prefix, mixed $filter, array $aggregations): DataProcessResult
    {
        $aggs = [];
        foreach ($aggregations as $name => $field) { $aggs[$name] = ['terms' => ['field' => $field, 'size' => 100]]; }
        try {
            $r = $this->client->search(['index' => $this->idx($prefix, $indexName), 'body' => ['size' => 0, 'aggs' => $aggs]]);
            return DataProcessResult::ok($r['aggregations'] ?? []);
        } catch (\Throwable $e) { return DataProcessResult::fail($e->getMessage()); }
    }

    private function buildQuery(SearchCondition $c): array
    {
        return match ($c->queryType) {
            QueryType::EQUALS  => ['term'   => [$c->property => $c->value]],
            QueryType::CONTAINS=> ['match'  => [$c->property => $c->value]],
            QueryType::IN      => ['terms'  => [$c->property => $c->value]],
            QueryType::GT      => ['range'  => [$c->property => ['gt' => $c->value]]],
            QueryType::LT      => ['range'  => [$c->property => ['lt' => $c->value]]],
            QueryType::PREFIX  => ['prefix' => [$c->property => $c->value]],
            default            => ['term'   => [$c->property => $c->value]],
        };
    }
}
