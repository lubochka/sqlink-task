# Skill 03: Elasticsearch Datastore — Python / elasticsearch-py 8.x
from elasticsearch import AsyncElasticsearch
from core_interfaces import IDatabaseService, DataProcessResult, DatabaseType, SearchCondition, QueryType
from object_processor import ObjectProcessor

class ElasticsearchDatabaseService(IDatabaseService):
    def __init__(self, connection_url="http://localhost:9200"):
        self.client = AsyncElasticsearch(connection_url)
        self.processor = ObjectProcessor()

    @property
    def database_type(self) -> DatabaseType: return DatabaseType.ELASTICSEARCH

    def _idx(self, prefix: str, name: str) -> str: return f"{prefix}_{name}".lower()

    async def store_document(self, index_name, prefix, id, document, need_to_parse=True):
        idx = self._idx(prefix, index_name)
        doc = self.processor.parse_document(document) if need_to_parse else document
        try:
            await self.client.index(index=idx, id=id, body=doc, refresh="wait_for")
            return DataProcessResult.ok(doc)
        except Exception as e: return DataProcessResult.fail(str(e))

    async def search_documents(self, index_name, prefix, filter_obj, size=10):
        idx = self._idx(prefix, index_name)
        conditions = self.processor.build_query_filters(filter_obj)
        must = [self._build_query(c) for c in conditions]
        try:
            r = await self.client.search(index=idx, body={"query": {"bool": {"must": must}}, "size": size})
            return DataProcessResult.ok([h["_source"] for h in r["hits"]["hits"]])
        except Exception as e: return DataProcessResult.fail(str(e))

    async def get_document(self, index_name, prefix, id):
        try:
            r = await self.client.get(index=self._idx(prefix, index_name), id=id)
            return DataProcessResult.ok(r["_source"]) if r["found"] else DataProcessResult.not_found(f"{id} not found")
        except Exception as e: return DataProcessResult.fail(str(e))

    async def delete_document(self, index_name, prefix, id):
        try:
            await self.client.delete(index=self._idx(prefix, index_name), id=id, refresh="wait_for")
            return DataProcessResult.ok(True)
        except Exception as e: return DataProcessResult.fail(str(e))

    async def bulk_upsert(self, index_name, prefix, documents):
        idx = self._idx(prefix, index_name)
        actions = []
        for key, value in documents:
            actions.append({"index": {"_index": idx, "_id": key}})
            actions.append(self.processor.parse_document(value))
        try:
            r = await self.client.bulk(body=actions, refresh="wait_for")
            errors = [i.get("error", {}).get("reason", "") for i in r.get("items", []) if "error" in i.get("index", {})]
            return DataProcessResult.ok({"succeeded": len(documents) - len(errors), "failed": len(errors), "errors": errors})
        except Exception as e: return DataProcessResult.fail(str(e))

    async def bulk_delete(self, index_name, prefix, ids):
        idx = self._idx(prefix, index_name)
        actions = [{"delete": {"_index": idx, "_id": id}} for id in ids]
        try:
            await self.client.bulk(body=actions, refresh="wait_for")
            return DataProcessResult.ok({"succeeded": len(ids), "failed": 0, "errors": []})
        except Exception as e: return DataProcessResult.fail(str(e))

    async def get_filters(self, index_name, prefix, field_name):
        try:
            r = await self.client.search(index=self._idx(prefix, index_name), body={"size": 0, "aggs": {"vals": {"terms": {"field": field_name, "size": 1000}}}})
            return DataProcessResult.ok({b["key"]: b["doc_count"] for b in r["aggregations"]["vals"]["buckets"]})
        except Exception as e: return DataProcessResult.fail(str(e))

    async def aggregate(self, index_name, prefix, filter_obj, aggregations):
        aggs = {name: {"terms": {"field": field, "size": 100}} for name, field in aggregations.items()}
        try:
            r = await self.client.search(index=self._idx(prefix, index_name), body={"size": 0, "aggs": aggs})
            return DataProcessResult.ok(r.get("aggregations", {}))
        except Exception as e: return DataProcessResult.fail(str(e))

    async def index_exists(self, index_name, prefix) -> bool:
        try: return await self.client.indices.exists(index=self._idx(prefix, index_name))
        except: return False

    async def create_index(self, index_name, prefix):
        try:
            await self.client.indices.create(index=self._idx(prefix, index_name))
            return DataProcessResult.ok(True)
        except Exception as e: return DataProcessResult.fail(str(e))

    def _build_query(self, c: SearchCondition) -> dict:
        match c.query_type:
            case QueryType.EQUALS: return {"term": {c.property: c.value}}
            case QueryType.CONTAINS: return {"match": {c.property: c.value}}
            case QueryType.IN: return {"terms": {c.property: c.value}}
            case QueryType.GT: return {"range": {c.property: {"gt": c.value}}}
            case QueryType.LT: return {"range": {c.property: {"lt": c.value}}}
            case QueryType.PREFIX: return {"prefix": {c.property: c.value}}
            case _: return {"term": {c.property: c.value}}
