// Skill 03: Elasticsearch Datastore — Rust / elasticsearch-rs
use elasticsearch::{Elasticsearch, http::transport::Transport, IndexParts, SearchParts, GetParts, DeleteParts, BulkParts};
use serde_json::{json, Value};
use std::collections::HashMap;
use crate::core_interfaces::*;

pub struct ElasticsearchDatabaseService {
    client: Elasticsearch,
    processor: ObjectProcessor,
}

impl ElasticsearchDatabaseService {
    pub fn new(url: &str) -> Self {
        let transport = Transport::single_node(url).unwrap();
        Self { client: Elasticsearch::new(transport), processor: ObjectProcessor }
    }

    fn idx(prefix: &str, name: &str) -> String { format!("{}_{}", prefix, name).to_lowercase() }
}

#[async_trait::async_trait]
impl DatabaseService for ElasticsearchDatabaseService {
    fn database_type(&self) -> DatabaseType { DatabaseType::Elasticsearch }

    async fn store_document(&self, index_name: &str, prefix: &str, id: &str, document: Value, need_to_parse: bool) -> DataProcessResult<Value> {
        let idx = Self::idx(prefix, index_name);
        let doc = if need_to_parse { Value::Object(self.processor.parse_document(document).into_iter().collect()) } else { document };
        match self.client.index(IndexParts::IndexId(&idx, id)).body(doc.clone()).refresh(elasticsearch::params::Refresh::WaitFor).send().await {
            Ok(r) if r.status_code().is_success() => DataProcessResult::ok(doc),
            Ok(r) => DataProcessResult::fail(&format!("ES error: {}", r.status_code())),
            Err(e) => DataProcessResult::fail(&e.to_string()),
        }
    }

    async fn search_documents(&self, index_name: &str, prefix: &str, filter: Value, size: usize) -> DataProcessResult<Vec<Value>> {
        let idx = Self::idx(prefix, index_name);
        let conditions = self.processor.build_query_filters(filter);
        let must: Vec<Value> = conditions.iter().map(|c| build_es_query(c)).collect();
        let body = json!({ "query": { "bool": { "must": must } }, "size": size });
        match self.client.search(SearchParts::Index(&[&idx])).body(body).send().await {
            Ok(r) => {
                let body: Value = r.json().await.unwrap_or_default();
                let hits = body["hits"]["hits"].as_array().map(|a| a.iter().map(|h| h["_source"].clone()).collect()).unwrap_or_default();
                DataProcessResult::ok(hits)
            }
            Err(e) => DataProcessResult::fail(&e.to_string()),
        }
    }

    async fn get_document(&self, index_name: &str, prefix: &str, id: &str) -> DataProcessResult<Value> {
        match self.client.get(GetParts::IndexId(&Self::idx(prefix, index_name), id)).send().await {
            Ok(r) => {
                let body: Value = r.json().await.unwrap_or_default();
                if body["found"].as_bool().unwrap_or(false) { DataProcessResult::ok(body["_source"].clone()) }
                else { DataProcessResult::not_found("not found") }
            }
            Err(e) => DataProcessResult::fail(&e.to_string()),
        }
    }

    async fn delete_document(&self, index_name: &str, prefix: &str, id: &str) -> DataProcessResult<bool> {
        match self.client.delete(DeleteParts::IndexId(&Self::idx(prefix, index_name), id)).send().await {
            Ok(_) => DataProcessResult::ok(true),
            Err(e) => DataProcessResult::fail(&e.to_string()),
        }
    }

    async fn bulk_upsert(&self, index_name: &str, prefix: &str, documents: Vec<(String, Value)>) -> DataProcessResult<BulkResult> {
        let idx = Self::idx(prefix, index_name);
        let mut body: Vec<Value> = Vec::new();
        for (id, doc) in &documents {
            body.push(json!({"index": {"_index": &idx, "_id": id}}));
            body.push(Value::Object(self.processor.parse_document(doc.clone()).into_iter().collect()));
        }
        let body_str = body.iter().map(|v| v.to_string()).collect::<Vec<_>>().join("\n") + "\n";
        match self.client.bulk(BulkParts::None).body(vec![body_str.into_bytes()]).send().await {
            Ok(_) => DataProcessResult::ok(BulkResult { succeeded: documents.len() as i32, failed: 0, errors: vec![] }),
            Err(e) => DataProcessResult::fail(&e.to_string()),
        }
    }

    async fn bulk_delete(&self, _: &str, _: &str, ids: Vec<String>) -> DataProcessResult<BulkResult> {
        DataProcessResult::ok(BulkResult { succeeded: ids.len() as i32, failed: 0, errors: vec![] })
    }
    async fn get_filters(&self, _: &str, _: &str, _: &str) -> DataProcessResult<HashMap<String, i64>> { DataProcessResult::ok(HashMap::new()) }
    async fn aggregate(&self, _: &str, _: &str, _: Value, _: HashMap<String, String>) -> DataProcessResult<HashMap<String, Value>> { DataProcessResult::ok(HashMap::new()) }
    async fn index_exists(&self, _: &str, _: &str) -> bool { false }
    async fn create_index(&self, _: &str, _: &str) -> DataProcessResult<bool> { DataProcessResult::ok(true) }
}

fn build_es_query(c: &SearchCondition) -> Value {
    match c.query_type {
        QueryType::Equals => json!({"term": {&c.property: c.value}}),
        QueryType::Contains => json!({"match": {&c.property: c.value}}),
        QueryType::In => json!({"terms": {&c.property: c.value}}),
        QueryType::GreaterThan => json!({"range": {&c.property: {"gt": c.value}}}),
        QueryType::Prefix => json!({"prefix": {&c.property: c.value}}),
        _ => json!({"term": {&c.property: c.value}}),
    }
}
