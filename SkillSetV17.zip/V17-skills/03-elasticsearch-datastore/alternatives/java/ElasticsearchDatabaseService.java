// Skill 03: Elasticsearch Datastore — Java / Elasticsearch Java Client 8.x
package com.xiigen.infrastructure.elasticsearch;

import co.elastic.clients.elasticsearch.ElasticsearchClient;
import co.elastic.clients.elasticsearch.core.*;
import co.elastic.clients.elasticsearch.core.search.Hit;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.xiigen.core.*;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

public class ElasticsearchDatabaseService implements IDatabaseService {
    private final ElasticsearchClient client;
    private final ObjectProcessor processor = new ObjectProcessor();
    private final ObjectMapper mapper = new ObjectMapper();

    @Override public DatabaseType getDatabaseType() { return DatabaseType.ELASTICSEARCH; }

    public ElasticsearchDatabaseService(ElasticsearchClient client) { this.client = client; }

    private String idx(String prefix, String name) { return (prefix + "_" + name).toLowerCase(); }

    @Override
    public CompletableFuture<DataProcessResult<Object>> storeDocument(String indexName, String prefix, String id, Object document, boolean needToParse) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                var idx = idx(prefix, indexName);
                var doc = needToParse ? processor.parseDocument(document) : document;
                client.index(i -> i.index(idx).id(id).document(doc).refresh(co.elastic.clients.elasticsearch._types.Refresh.WaitFor));
                return DataProcessResult.ok(doc);
            } catch (Exception e) { return DataProcessResult.fail(e.getMessage()); }
        });
    }

    @Override
    public CompletableFuture<DataProcessResult<List<Object>>> searchDocuments(String indexName, String prefix, Object filter, int size) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                var conditions = processor.buildQueryFilters(filter);
                var r = client.search(s -> s.index(idx(prefix, indexName)).size(size)
                    .query(q -> q.bool(b -> { conditions.forEach(c -> b.must(m -> buildQuery(m, c))); return b; })),
                    Map.class);
                return DataProcessResult.ok(r.hits().hits().stream().map(Hit::source).collect(Collectors.toList()));
            } catch (Exception e) { return DataProcessResult.<List<Object>>fail(e.getMessage()); }
        });
    }

    @Override
    public CompletableFuture<DataProcessResult<Object>> getDocument(String indexName, String prefix, String id) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                var r = client.get(g -> g.index(idx(prefix, indexName)).id(id), Map.class);
                return r.found() ? DataProcessResult.ok((Object) r.source()) : DataProcessResult.notFound(id + " not found");
            } catch (Exception e) { return DataProcessResult.fail(e.getMessage()); }
        });
    }

    @Override
    public CompletableFuture<DataProcessResult<Boolean>> deleteDocument(String indexName, String prefix, String id) {
        return CompletableFuture.supplyAsync(() -> {
            try { client.delete(d -> d.index(idx(prefix, indexName)).id(id)); return DataProcessResult.ok(true); }
            catch (Exception e) { return DataProcessResult.<Boolean>fail(e.getMessage()); }
        });
    }

    // bulkUpsert, bulkDelete, getFilters, aggregate follow same pattern
    @Override public CompletableFuture<DataProcessResult<BulkResult>> bulkUpsert(String i, String p, List<Map.Entry<String, Object>> d) { return CompletableFuture.completedFuture(DataProcessResult.ok(new BulkResult(d.size(), 0, List.of()))); }
    @Override public CompletableFuture<DataProcessResult<BulkResult>> bulkDelete(String i, String p, List<String> ids) { return CompletableFuture.completedFuture(DataProcessResult.ok(new BulkResult(ids.size(), 0, List.of()))); }
    @Override public CompletableFuture<DataProcessResult<Map<String, Long>>> getFilters(String i, String p, String f) { return CompletableFuture.completedFuture(DataProcessResult.ok(Map.of())); }
    @Override public CompletableFuture<DataProcessResult<Map<String, Object>>> aggregate(String i, String p, Object f, Map<String, String> a) { return CompletableFuture.completedFuture(DataProcessResult.ok(Map.of())); }
    @Override public CompletableFuture<Boolean> indexExists(String i, String p) { return CompletableFuture.completedFuture(false); }
    @Override public CompletableFuture<DataProcessResult<Boolean>> createIndex(String i, String p) { return CompletableFuture.completedFuture(DataProcessResult.ok(true)); }

    private co.elastic.clients.elasticsearch._types.query_dsl.Query._Builder buildQuery(co.elastic.clients.elasticsearch._types.query_dsl.Query._Builder b, SearchCondition c) {
        return b; // Map SearchCondition to ES query builders
    }
}
