# Skill 03: Elasticsearch Datastore — Implementation Prompt

## Prerequisites
- Skill 01 (Core Interfaces) implemented — `IDatabaseService`, `DataProcessResult<T>`, `SearchCondition`, enums
- Skill 02 (Object Processor) implemented — `ObjectProcessor` with `ParseDocument()` and `BuildQueryFilters()`
- Elasticsearch 8.x running (Docker: `docker run -d -p 9200:9200 -e discovery.type=single-node -e xpack.security.enabled=false elasticsearch:8.15.0`)

## .NET Implementation Steps

### 1. Add NuGet Package
```bash
dotnet add package Elastic.Clients.Elasticsearch --version 8.*
```

### 2. Create Service File
**Path:** `XIIGen.Infrastructure/Elasticsearch/ElasticsearchDatabaseService.cs`

Copy the implementation from `Implementation/ElasticsearchDatabaseService.cs` (203 lines).

Key patterns to follow:
- Index naming: `{prefix}_{indexName}` always lowercased
- Auto-create index if not exists via `EnsureIndexAsync()`
- Use `ObjectProcessor.ParseDocument()` before indexing
- Use `ObjectProcessor.BuildQueryFilters()` for search → only non-empty fields become conditions
- `Refresh.WaitFor` for write operations (use `Refresh.False` in production bulk)
- All methods return `DataProcessResult<T>` — never throw

### 3. Register in DI
```csharp
// In XIIGen.Infrastructure/DependencyInjection.cs
services.AddSingleton<IDatabaseService>(sp =>
{
    var settings = new ElasticsearchClientSettings(new Uri(config["Elasticsearch:Url"] ?? "http://localhost:9200"));
    return new ElasticsearchDatabaseService(new ElasticsearchClient(settings), sp.GetRequiredService<ObjectProcessor>());
});
```

### 4. Configuration
```json
// appsettings.json
{ "Elasticsearch": { "Url": "http://localhost:9200", "IndexPrefix": "xiigen" } }
```

### 5. Verify
```csharp
var db = serviceProvider.GetRequiredService<IDatabaseService>();
var result = await db.StoreDocumentAsync("test", "xiigen", "1", new { Name = "Test", Age = 25 });
Assert.Equal(DataProcessStatus.Ok, result.Status);

var search = await db.SearchDocumentsAsync("test", "xiigen", new { Name = "Test" }, 10);
Assert.True(search.Data.Count > 0);

// Verify empty-field skipping: Age is 0/null → not included in query
var partial = await db.SearchDocumentsAsync("test", "xiigen", new { Name = "Test", Age = 0 }, 10);
Assert.True(partial.Data.Count > 0); // Still finds "Test" — Age=0 was skipped
```

## Alternative Stack Instructions

| Stack | Package | File |
|-------|---------|------|
| Node.js | `@elastic/elasticsearch@8` | `alternatives/nodejs/elasticsearch-datastore.ts` |
| Python | `elasticsearch[async]>=8` | `alternatives/python/elasticsearch_datastore.py` |
| Java | `co.elastic.clients:elasticsearch-java:8.+` | `alternatives/java/ElasticsearchDatabaseService.java` |
| Rust | `elasticsearch = "8"` | `alternatives/rust/elasticsearch_datastore.rs` |
| PHP | `elasticsearch/elasticsearch:^8` | `alternatives/php/ElasticsearchDatabaseService.php` |

All alternatives implement the same `IDatabaseService` interface from Skill 01 in their respective language.

## Anti-Patterns
- ❌ Don't hardcode index names — always use `{prefix}_{indexName}` pattern
- ❌ Don't skip `EnsureIndexAsync` — auto-create prevents missing index errors
- ❌ Don't use `Refresh.True` in production — it forces immediate refresh, destroying performance
- ❌ Don't build query conditions manually — use `ObjectProcessor.BuildQueryFilters()` for automatic empty-field skipping
- ❌ Don't throw exceptions from service methods — always return `DataProcessResult.Fail()`
