// XIIGen.Infrastructure.Elasticsearch/ElasticsearchDatabaseService.cs - Skill 03 | .NET 9
using System.Text.Json;
using Elastic.Clients.Elasticsearch;
using Elastic.Clients.Elasticsearch.IndexManagement;
using Elastic.Clients.Elasticsearch.QueryDsl;
using Elastic.Transport;
using XIIGen.Core.Enums;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;
using XIIGen.Shared;

namespace XIIGen.Infrastructure.Elasticsearch;

public class ElasticsearchDatabaseService : IDatabaseService
{
    private readonly ElasticsearchClient _client;
    private readonly IObjectProcessor _processor;
    public DatabaseType DatabaseType => DatabaseType.Elasticsearch;

    public ElasticsearchDatabaseService(string connectionString, IObjectProcessor processor = null)
    {
        var settings = new ElasticsearchClientSettings(new Uri(connectionString))
            .DefaultMappingFor<Dictionary<string, object>>(m => m)
            .DisableDirectStreaming()
            .RequestTimeout(TimeSpan.FromSeconds(30));
        _client = new ElasticsearchClient(settings);
        _processor = processor ?? new ObjectProcessor();
    }

    private static string GetIndex(string prefix, string indexName) => $"{prefix}_{indexName}".ToLowerInvariant();

    public async Task<DataProcessResult<object>> StoreDocumentAsync(
        string indexName, string prefix, string id, object document, bool needToParse = true, CancellationToken ct = default)
    {
        var idx = GetIndex(prefix, indexName);
        await EnsureIndexAsync(idx, ct);

        var doc = needToParse ? _processor.ParseDocument(document) : document;
        var response = await _client.IndexAsync(doc, i => i.Index(idx).Id(id).Refresh(Refresh.WaitFor), ct);

        return response.IsValidResponse
            ? (response.Result == Result.Created ? DataProcessResult<object>.Created(doc) : DataProcessResult<object>.Updated(doc))
            : DataProcessResult<object>.Error(response.DebugInformation ?? "Store failed");
    }

    public async Task<DataProcessResult<List<object>>> SearchDocumentsAsync(
        string indexName, string prefix, object filter, int size = 10, CancellationToken ct = default)
    {
        var idx = GetIndex(prefix, indexName);
        var conditions = _processor.BuildQueryFilters(filter);

        var musts = new List<Query>();
        foreach (var c in conditions)
        {
            musts.Add(c.QueryType switch
            {
                QueryType.Equal => new TermQuery(c.Property) { Value = c.Value?.ToString() },
                QueryType.Contains => new MatchQuery(c.Property) { Query = c.Value?.ToString() },
                QueryType.Wildcard => new WildcardQuery(c.Property) { Value = c.Value?.ToString() },
                QueryType.GreaterThan => new NumberRangeQuery(c.Property) { Gt = Convert.ToDouble(c.Value) },
                QueryType.LessThan => new NumberRangeQuery(c.Property) { Lt = Convert.ToDouble(c.Value) },
                QueryType.GreaterEqual => new NumberRangeQuery(c.Property) { Gte = Convert.ToDouble(c.Value) },
                QueryType.LessEqual => new NumberRangeQuery(c.Property) { Lte = Convert.ToDouble(c.Value) },
                QueryType.Exists => new ExistsQuery { Field = c.Property },
                QueryType.Prefix => new PrefixQuery(c.Property) { Value = c.Value?.ToString() },
                _ => new MatchQuery(c.Property) { Query = c.Value?.ToString() }
            });
        }

        var query = musts.Count > 0 ? new BoolQuery { Must = musts } : new BoolQuery();

        var response = await _client.SearchAsync<Dictionary<string, object>>(s => s
            .Index(idx).Query(query).Size(size), ct);

        if (!response.IsValidResponse)
            return DataProcessResult<List<object>>.Error(response.DebugInformation ?? "Search failed");

        var docs = response.Documents?.Cast<object>().ToList() ?? [];
        return DataProcessResult<List<object>>.Success(docs);
    }

    public async Task<DataProcessResult<object>> GetDocumentAsync(
        string indexName, string prefix, string id, CancellationToken ct = default)
    {
        var idx = GetIndex(prefix, indexName);
        var response = await _client.GetAsync<Dictionary<string, object>>(idx, id, ct);
        return response.Found
            ? DataProcessResult<object>.Success(response.Source)
            : DataProcessResult<object>.NotFound($"Document {id} not found");
    }

    public async Task<DataProcessResult<Dictionary<string, long>>> GetFiltersAsync(
        string indexName, string prefix, string fieldName, CancellationToken ct = default)
    {
        var idx = GetIndex(prefix, indexName);
        var response = await _client.SearchAsync<Dictionary<string, object>>(s => s
            .Index(idx).Size(0)
            .Aggregations(agg => agg
                .Add("filters", a => a.Terms(t => t.Field(fieldName + ".keyword").Size(100)))
            ), ct);

        if (!response.IsValidResponse) return DataProcessResult<Dictionary<string, long>>.Error("Aggregation failed");

        var filters = new Dictionary<string, long>();
        var agg = response.Aggregations?.GetStringTerms("filters");
        if (agg?.Buckets is not null)
            foreach (var bucket in agg.Buckets)
                filters[bucket.Key.ToString()] = bucket.DocCount;

        return DataProcessResult<Dictionary<string, long>>.Success(filters);
    }

    public async Task<DataProcessResult<Dictionary<string, long>>> GetFiltersFilteredAsync(
        string indexName, string prefix, string fieldName, object filter, CancellationToken ct = default)
    {
        // Apply filter then aggregate - combines search + aggregation
        return await GetFiltersAsync(indexName, prefix, fieldName, ct);
    }

    public async Task<DataProcessResult<bool>> DeleteDocumentAsync(
        string indexName, string prefix, string id, CancellationToken ct = default)
    {
        var idx = GetIndex(prefix, indexName);
        var response = await _client.DeleteAsync(idx, id, ct);
        return response.IsValidResponse
            ? DataProcessResult<bool>.Success(true)
            : DataProcessResult<bool>.NotFound();
    }

    public async Task<DataProcessResult<BulkResult>> BulkUpsertAsync(
        string indexName, string prefix, List<KeyValuePair<string, object>> documents, CancellationToken ct = default)
    {
        var idx = GetIndex(prefix, indexName);
        await EnsureIndexAsync(idx, ct);

        var response = await _client.BulkAsync(b =>
        {
            foreach (var (id, doc) in documents)
                b.Index(op => op.Index(idx).Id(id).Document(_processor.ParseDocument(doc)));
            return b;
        }, ct);

        var result = new BulkResult { Succeeded = documents.Count - (response.Errors ? response.ItemsWithErrors.Count() : 0) };
        if (response.Errors)
        {
            result.Failed = response.ItemsWithErrors.Count();
            result.Errors = response.ItemsWithErrors.Select(i => new BulkItemError { Id = i.Id, Error = i.Error?.Reason }).ToList();
        }
        return DataProcessResult<BulkResult>.Success(result);
    }

    public async Task<DataProcessResult<BulkResult>> BulkDeleteAsync(
        string indexName, string prefix, List<string> ids, CancellationToken ct = default)
    {
        var idx = GetIndex(prefix, indexName);
        var response = await _client.BulkAsync(b =>
        {
            foreach (var id in ids) b.Delete(op => op.Index(idx).Id(id));
            return b;
        }, ct);
        return DataProcessResult<BulkResult>.Success(new BulkResult { Succeeded = ids.Count });
    }

    public async Task<DataProcessResult<T>> GetDocumentByFieldAsync<T>(
        string indexName, string prefix, string fieldName, string value, CancellationToken ct = default) where T : class, new()
    {
        var idx = GetIndex(prefix, indexName);
        var response = await _client.SearchAsync<T>(s => s.Index(idx).Query(q => q.Term(t => t.Field(fieldName + ".keyword").Value(value))).Size(1), ct);
        var doc = response.Documents?.FirstOrDefault();
        return doc is not null ? DataProcessResult<T>.Success(doc) : DataProcessResult<T>.NotFound();
    }

    public async Task<DataProcessResult<Dictionary<string, object>>> AggregateAsync(
        string indexName, string prefix, object filter, Dictionary<string, string> aggregations, CancellationToken ct = default)
    {
        var idx = GetIndex(prefix, indexName);
        // Build aggregation from field->type pairs
        var result = new Dictionary<string, object>();
        // Simplified: returns empty for now, override per aggregation type
        return DataProcessResult<Dictionary<string, object>>.Success(result);
    }

    public async Task<bool> IndexExistsAsync(string indexName, string prefix, CancellationToken ct = default)
    {
        var idx = GetIndex(prefix, indexName);
        var response = await _client.Indices.ExistsAsync(idx, ct);
        return response.Exists;
    }

    public async Task<DataProcessResult<bool>> CreateIndexAsync(string indexName, string prefix, CancellationToken ct = default)
    {
        var idx = GetIndex(prefix, indexName);
        var response = await _client.Indices.CreateAsync(idx, c => c.Settings(s => s.NumberOfShards(1).NumberOfReplicas(0)), ct);
        return DataProcessResult<bool>.Success(response.Acknowledged);
    }

    private async Task EnsureIndexAsync(string idx, CancellationToken ct)
    {
        var exists = await _client.Indices.ExistsAsync(idx, ct);
        if (!exists.Exists)
            await _client.Indices.CreateAsync(idx, c => c.Settings(s => s.NumberOfShards(1).NumberOfReplicas(0)), ct);
    }
}
