# Skill 03: Elasticsearch Datastore
## IDatabaseService implementation for Elasticsearch 8.x with dynamic documents

**Status:** Ready to Generate  
**Priority:** P0 — Primary storage engine  
**Dependencies:** Skill 01 (Core Interfaces), Skill 02 (Object Processor)  
**Layer:** L2: Infrastructure  
**Phase:** 2  
**Estimated LOC:** ~200  

---

## Overview

Elasticsearch is XIIGen's default data store. This skill implements `IDatabaseService` using the official `Elastic.Clients.Elasticsearch` (v8.x) client. Key features: dynamic document storage (no index mapping required — Elasticsearch auto-maps), filter-by-non-empty queries using the ObjectProcessor's `BuildQueryFilters`, bulk operations, and aggregations.

Every stored document is first run through `ObjectProcessor.ParseDocument()` for type normalization before indexing.

## Key Concepts

- **Index naming:** `{prefix}_{indexName}` lowercased (e.g., `myservice_users`)
- **Auto-create index:** If index doesn't exist, it's created on first write
- **Dynamic mapping:** Elasticsearch infers field types from the first document
- **Filter building:** SearchConditions from ObjectProcessor → Elasticsearch BoolQuery
- **Refresh policy:** `WaitFor` on writes for immediate read consistency

---

## Primary Implementation (.NET 9)

```csharp
// File: XIIGen.Infrastructure.Elasticsearch/ElasticsearchDatabaseService.cs
// NuGet: Elastic.Clients.Elasticsearch (8.x)
namespace XIIGen.Infrastructure.Elasticsearch;

public class ElasticsearchDatabaseService : IDatabaseService
{
    private readonly ElasticsearchClient _client;
    private readonly IObjectProcessor _processor;
    public DatabaseType DatabaseType => DatabaseType.Elasticsearch;

    public ElasticsearchDatabaseService(string connectionString, IObjectProcessor processor = null)
    {
        var settings = new ElasticsearchClientSettings(new Uri(connectionString))
            .DisableDirectStreaming().RequestTimeout(TimeSpan.FromSeconds(30));
        _client = new ElasticsearchClient(settings);
        _processor = processor ?? new ObjectProcessor();
    }

    private static string GetIndex(string prefix, string name) => $"{prefix}_{name}".ToLowerInvariant();

    public async Task<DataProcessResult<object>> StoreDocumentAsync(
        string indexName, string prefix, string id, object document,
        bool needToParse = true, CancellationToken ct = default)
    {
        var idx = GetIndex(prefix, indexName);
        await EnsureIndexAsync(idx, ct);
        var doc = needToParse ? _processor.ParseDocument(document) : document;
        var r = await _client.IndexAsync(doc, i => i.Index(idx).Id(id).Refresh(Refresh.WaitFor), ct);
        return r.IsValidResponse ? DataProcessResult<object>.Ok(doc) : DataProcessResult<object>.Fail(r.DebugInformation);
    }

    public async Task<DataProcessResult<List<object>>> SearchDocumentsAsync(
        string indexName, string prefix, object filter, int size = 10, CancellationToken ct = default)
    {
        var idx = GetIndex(prefix, indexName);
        var conditions = _processor.BuildQueryFilters(filter); // Only non-empty fields!
        var queries = conditions.Select(c => BuildQuery(c)).ToList();
        var r = await _client.SearchAsync<Dictionary<string, object>>(s => s
            .Index(idx).Size(size)
            .Query(q => q.Bool(b => b.Must(queries.ToArray()))), ct);
        return r.IsValidResponse
            ? DataProcessResult<List<object>>.Ok(r.Documents.Cast<object>().ToList())
            : DataProcessResult<List<object>>.Fail(r.DebugInformation);
    }

    // ... GetDocumentAsync, DeleteDocumentAsync, BulkUpsertAsync, BulkDeleteAsync, GetFiltersAsync, AggregateAsync
    // Full implementation in Implementation/ElasticsearchDatabaseService.cs
}
```

### DI Registration

```csharp
builder.Services.AddSingleton<IDatabaseService>(sp =>
    new ElasticsearchDatabaseService(
        builder.Configuration["Elasticsearch:Url"] ?? "http://localhost:9200",
        sp.GetRequiredService<IObjectProcessor>()
    ));
```

---

## Unit Tests

```csharp
[Fact] public void GetIndex_FormatsCorrectly()
    => Assert.Equal("svc_users", ElasticsearchDatabaseService.GetIndex("svc", "users"));

[Fact] public async Task StoreAndRetrieve_RoundTrips()
{
    var svc = new ElasticsearchDatabaseService("http://localhost:9200");
    await svc.StoreDocumentAsync("test", "unit", "1", new { Name = "Test" });
    var r = await svc.GetDocumentAsync("test", "unit", "1");
    Assert.True(r.IsSuccess);
}
```

## Anti-Patterns
- **Don't** hardcode index names — always use `{prefix}_{indexName}` pattern
- **Don't** skip `EnsureIndexAsync` — auto-create prevents "index not found" errors
- **Don't** use `Refresh.True` in production — it's expensive; use `WaitFor` or `False`
