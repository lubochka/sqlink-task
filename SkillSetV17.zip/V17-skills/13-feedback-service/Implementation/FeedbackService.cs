// XIIGen.Services.Feedback/FeedbackService.cs - Skill 13 | .NET 9
// Feedback CRUD + similarity matching + prompt injection
// Genie DNA: DNA-1 (Dictionary<string,object>), DNA-2 (BuildSearchFilter), DNA-5 (DataProcessResult)

using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System.Text;
using System.Text.Json;
using XIIGen.Core.Base;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Services.Feedback;

// ─── Configuration ──────────────────────────────────────────────
public class FeedbackConfig
{
    public string IndexName { get; set; } = "feedback";
    public int MaxPositiveExamples { get; set; } = 3;
    public int MaxNegativeExamples { get; set; } = 3;
    public string[] SimilarityFields { get; set; } = ["flowId", "stepType", "componentType", "technology"];
    public int MinRatingForPositive { get; set; } = 4;
    public int MaxRatingForNegative { get; set; } = 2;
    public bool IncludeSnippetsInInjection { get; set; } = true;
    public int MaxSnippetLength { get; set; } = 500;
    public int DefaultPageSize { get; set; } = 20;
}

// ─── Feedback Injector (transforms feedback → prompt section) ───
public class FeedbackInjector
{
    private readonly FeedbackConfig _config;

    public FeedbackInjector(FeedbackConfig config)
    {
        _config = config;
    }

    /// <summary>
    /// Build a prompt injection string from a list of feedback records.
    /// Separates into positive (rating >= MinRatingForPositive) and
    /// negative (rating <= MaxRatingForNegative). Rating 3 excluded.
    /// </summary>
    public string BuildInjection(List<Dictionary<string, object>> feedbackList)
    {
        if (feedbackList == null || feedbackList.Count == 0)
            return string.Empty;

        var positive = feedbackList
            .Where(f => GetInt(f, "rating") >= _config.MinRatingForPositive)
            .OrderByDescending(f => GetInt(f, "rating"))
            .Take(_config.MaxPositiveExamples)
            .ToList();

        var negative = feedbackList
            .Where(f => GetInt(f, "rating") <= _config.MaxRatingForNegative)
            .OrderBy(f => GetInt(f, "rating"))
            .Take(_config.MaxNegativeExamples)
            .ToList();

        if (positive.Count == 0 && negative.Count == 0)
            return string.Empty;

        var sb = new StringBuilder();
        sb.AppendLine("\n## Feedback from previous similar tasks:\n");

        if (positive.Count > 0)
        {
            sb.AppendLine("### ✅ What worked well (from highly-rated outputs):");
            foreach (var fb in positive)
            {
                var text = GetString(fb, "text");
                var rating = GetInt(fb, "rating");
                var component = GetString(fb, "componentType");
                var tech = GetString(fb, "technology");
                var context = !string.IsNullOrEmpty(component) && !string.IsNullOrEmpty(tech)
                    ? $" (Rating: {rating}/5, Task: {component}/{tech})"
                    : $" (Rating: {rating}/5)";
                sb.AppendLine($"- {text}{context}");

                if (_config.IncludeSnippetsInInjection)
                    AppendSnippet(sb, fb);
            }
            sb.AppendLine();
        }

        if (negative.Count > 0)
        {
            sb.AppendLine("### ❌ What to avoid (from poorly-rated outputs):");
            foreach (var fb in negative)
            {
                var text = GetString(fb, "text");
                var rating = GetInt(fb, "rating");
                sb.AppendLine($"- {text} (Rating: {rating}/5)");

                if (_config.IncludeSnippetsInInjection)
                    AppendSnippet(sb, fb);
            }
            sb.AppendLine();
        }

        sb.AppendLine("---\n");
        return sb.ToString();
    }

    /// <summary>Prepend injection before original prompt.</summary>
    public string InjectIntoPrompt(string originalPrompt, List<Dictionary<string, object>> feedback)
    {
        var injection = BuildInjection(feedback);
        return string.IsNullOrEmpty(injection) ? originalPrompt : injection + originalPrompt;
    }

    private void AppendSnippet(StringBuilder sb, Dictionary<string, object> fb)
    {
        var snippet = GetString(fb, "outputSnippet");
        if (string.IsNullOrEmpty(snippet)) return;
        if (snippet.Length > _config.MaxSnippetLength)
            snippet = snippet[.._config.MaxSnippetLength] + "...";
        sb.AppendLine($"  ```\n  {snippet}\n  ```");
    }

    private static string GetString(Dictionary<string, object> dict, string key)
        => dict.TryGetValue(key, out var val) ? val?.ToString() ?? "" : "";

    private static int GetInt(Dictionary<string, object> dict, string key)
    {
        if (!dict.TryGetValue(key, out var val)) return 0;
        if (val is int i) return i;
        if (val is long l) return (int)l;
        if (val is JsonElement je && je.TryGetInt32(out var ji)) return ji;
        return int.TryParse(val?.ToString(), out var parsed) ? parsed : 0;
    }
}

// ─── Core Feedback Service ──────────────────────────────────────
public class FeedbackService : MicroserviceBase
{
    private readonly FeedbackConfig _config;
    private readonly FeedbackInjector _injector;

    public FeedbackService(
        IDatabaseService db,
        IQueueService queue,
        ILogger<FeedbackService> logger,
        FeedbackConfig config = null,
        ICacheService cache = null)
        : base(db, queue, logger, cache)
    {
        ServiceName = "feedback-service";
        _config = config ?? new FeedbackConfig();
        _injector = new FeedbackInjector(_config);
    }

    // ─── CRUD: Create ───────────────────────────────────────────

    /// <summary>Submit new feedback. Assigns ID and timestamps automatically.</summary>
    public async Task<DataProcessResult<Dictionary<string, object>>> SubmitFeedbackAsync(
        Dictionary<string, object> feedback, CancellationToken ct = default)
    {
        try
        {
            // Ensure required fields
            if (!feedback.ContainsKey("rating"))
                return DataProcessResult<Dictionary<string, object>>.Error("Rating is required");

            var id = feedback.TryGetValue("feedbackId", out var existingId) && existingId != null
                ? existingId.ToString()!
                : $"fb-{Guid.NewGuid():N}";

            feedback["feedbackId"] = id;
            feedback["createdAt"] = DateTime.UtcNow.ToString("o");
            feedback["isDeleted"] = false;

            // Set rating label
            var rating = GetInt(feedback, "rating");
            feedback["ratingLabel"] = rating switch
            {
                5 => "Excellent",
                4 => "Good",
                3 => "Acceptable",
                2 => "Poor",
                1 => "Bad",
                _ => "Unknown"
            };

            await StoreDocumentAsync(_config.IndexName, id, feedback, ct: ct);
            Logger.LogInformation("Feedback {Id} submitted: rating={Rating}", id, rating);
            return DataProcessResult<Dictionary<string, object>>.Created(feedback);
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Failed to submit feedback");
            return DataProcessResult<Dictionary<string, object>>.Error(ex.Message);
        }
    }

    // ─── CRUD: Read ─────────────────────────────────────────────

    /// <summary>Get feedback by ID.</summary>
    public async Task<DataProcessResult<Dictionary<string, object>>> GetFeedbackByIdAsync(
        string feedbackId, CancellationToken ct = default)
    {
        try
        {
            var result = await GetDocumentAsync(_config.IndexName, feedbackId, ct);
            if (!result.IsSuccess)
                return DataProcessResult<Dictionary<string, object>>.NotFound($"Feedback {feedbackId} not found");

            var doc = result.Data as Dictionary<string, object>;
            if (doc != null && doc.TryGetValue("isDeleted", out var deleted) && deleted is true)
                return DataProcessResult<Dictionary<string, object>>.NotFound($"Feedback {feedbackId} has been deleted");

            return DataProcessResult<Dictionary<string, object>>.Success(doc!);
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Failed to get feedback {Id}", feedbackId);
            return DataProcessResult<Dictionary<string, object>>.Error(ex.Message);
        }
    }

    // ─── CRUD: Update ───────────────────────────────────────────

    /// <summary>Update feedback fields. Merges with existing document.</summary>
    public async Task<DataProcessResult<Dictionary<string, object>>> UpdateFeedbackAsync(
        string feedbackId, Dictionary<string, object> updates, CancellationToken ct = default)
    {
        try
        {
            var existing = await GetFeedbackByIdAsync(feedbackId, ct);
            if (!existing.IsSuccess)
                return existing;

            var doc = existing.Data!;
            foreach (var kv in updates)
            {
                if (kv.Key == "feedbackId" || kv.Key == "createdAt") continue; // immutable
                doc[kv.Key] = kv.Value;
            }
            doc["updatedAt"] = DateTime.UtcNow.ToString("o");

            // Recalculate rating label if rating changed
            if (updates.ContainsKey("rating"))
            {
                var rating = GetInt(doc, "rating");
                doc["ratingLabel"] = rating switch
                {
                    5 => "Excellent", 4 => "Good", 3 => "Acceptable",
                    2 => "Poor", 1 => "Bad", _ => "Unknown"
                };
            }

            await StoreDocumentAsync(_config.IndexName, feedbackId, doc, ct: ct);
            Logger.LogInformation("Feedback {Id} updated", feedbackId);
            return DataProcessResult<Dictionary<string, object>>.Success(doc);
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Failed to update feedback {Id}", feedbackId);
            return DataProcessResult<Dictionary<string, object>>.Error(ex.Message);
        }
    }

    // ─── CRUD: Delete (soft) ────────────────────────────────────

    /// <summary>Soft-delete feedback by setting isDeleted = true.</summary>
    public async Task<DataProcessResult<bool>> DeleteFeedbackAsync(
        string feedbackId, CancellationToken ct = default)
    {
        try
        {
            var updateResult = await UpdateFeedbackAsync(feedbackId,
                new Dictionary<string, object> { ["isDeleted"] = true }, ct);

            if (!updateResult.IsSuccess)
                return DataProcessResult<bool>.Error(updateResult.Message);

            Logger.LogInformation("Feedback {Id} soft-deleted", feedbackId);
            return DataProcessResult<bool>.Success(true);
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Failed to delete feedback {Id}", feedbackId);
            return DataProcessResult<bool>.Error(ex.Message);
        }
    }

    // ─── CRUD: List ─────────────────────────────────────────────

    /// <summary>List feedback with optional filters, paginated.</summary>
    public async Task<DataProcessResult<List<Dictionary<string, object>>>> ListFeedbackAsync(
        Dictionary<string, object> filters = null,
        int page = 0,
        int pageSize = 0,
        CancellationToken ct = default)
    {
        try
        {
            filters ??= new Dictionary<string, object>();
            filters["isDeleted"] = false; // always exclude deleted

            if (pageSize <= 0) pageSize = _config.DefaultPageSize;

            // DNA-2: BuildSearchFilter auto-skips empty/null fields
            var result = await SearchDocumentsAsync(_config.IndexName, filters, pageSize, ct);
            if (!result.IsSuccess)
                return DataProcessResult<List<Dictionary<string, object>>>.Error(result.Message);

            var list = result.Data?
                .Cast<Dictionary<string, object>>()
                .Skip(page * pageSize)
                .Take(pageSize)
                .ToList() ?? [];

            return DataProcessResult<List<Dictionary<string, object>>>.Success(list);
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Failed to list feedback");
            return DataProcessResult<List<Dictionary<string, object>>>.Error(ex.Message);
        }
    }

    // ─── Similarity Search ──────────────────────────────────────

    /// <summary>
    /// Search for similar feedback using multi-field matching.
    /// Uses BuildSearchFilter (DNA-2) — null/empty fields auto-excluded.
    /// </summary>
    public async Task<DataProcessResult<List<Dictionary<string, object>>>> SearchSimilarAsync(
        string flowId = null,
        string stepType = null,
        string componentType = null,
        string technology = null,
        string[] tags = null,
        int limit = 10,
        CancellationToken ct = default)
    {
        try
        {
            // Build filter with only non-empty fields (DNA-2 pattern)
            var filter = new Dictionary<string, object> { ["isDeleted"] = false };

            if (!string.IsNullOrEmpty(flowId)) filter["flowId"] = flowId;
            if (!string.IsNullOrEmpty(stepType)) filter["stepType"] = stepType;
            if (!string.IsNullOrEmpty(componentType)) filter["componentType"] = componentType;
            if (!string.IsNullOrEmpty(technology)) filter["technology"] = technology;
            if (tags != null && tags.Length > 0) filter["tags"] = tags;

            var result = await SearchDocumentsAsync(_config.IndexName, filter, limit, ct);
            if (!result.IsSuccess)
                return DataProcessResult<List<Dictionary<string, object>>>.Error(result.Message);

            var list = result.Data?
                .Cast<Dictionary<string, object>>()
                .ToList() ?? [];

            Logger.LogDebug("Similarity search returned {Count} results for flow={Flow}, step={Step}",
                list.Count, flowId, stepType);

            return DataProcessResult<List<Dictionary<string, object>>>.Success(list);
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Similarity search failed");
            return DataProcessResult<List<Dictionary<string, object>>>.Error(ex.Message);
        }
    }

    // ─── Feedback for Prompt Injection ──────────────────────────

    /// <summary>
    /// Get feedback suitable for prompt injection: similar feedback
    /// split into positive (≥ MinRating) and negative (≤ MaxRating).
    /// </summary>
    public async Task<DataProcessResult<List<Dictionary<string, object>>>> GetFeedbackForInjectionAsync(
        string flowId = null,
        string stepType = null,
        string componentType = null,
        string technology = null,
        CancellationToken ct = default)
    {
        var maxNeeded = _config.MaxPositiveExamples + _config.MaxNegativeExamples + 5; // buffer
        var searchResult = await SearchSimilarAsync(flowId, stepType, componentType, technology, limit: maxNeeded, ct: ct);

        if (!searchResult.IsSuccess)
            return searchResult;

        // Filter out neutral (rating 3) — they provide ambiguous signal
        var filtered = searchResult.Data!
            .Where(f =>
            {
                var r = GetInt(f, "rating");
                return r >= _config.MinRatingForPositive || r <= _config.MaxRatingForNegative;
            })
            .ToList();

        return DataProcessResult<List<Dictionary<string, object>>>.Success(filtered);
    }

    // ─── Prompt Injection Delegates ─────────────────────────────

    /// <summary>Build injection string from feedback list.</summary>
    public string BuildInjectionString(List<Dictionary<string, object>> feedback)
        => _injector.BuildInjection(feedback);

    /// <summary>Inject feedback into an existing prompt.</summary>
    public string InjectFeedbackIntoPrompt(string originalPrompt, List<Dictionary<string, object>> feedback)
        => _injector.InjectIntoPrompt(originalPrompt, feedback);

    /// <summary>
    /// Convenience: search + inject in one call.
    /// Used by Skill 11 (AI Transform) before generating output.
    /// </summary>
    public async Task<string> EnrichPromptWithFeedbackAsync(
        string originalPrompt,
        string flowId = null,
        string stepType = null,
        string componentType = null,
        string technology = null,
        CancellationToken ct = default)
    {
        var feedbackResult = await GetFeedbackForInjectionAsync(flowId, stepType, componentType, technology, ct);

        if (!feedbackResult.IsSuccess || feedbackResult.Data!.Count == 0)
            return originalPrompt;

        return InjectFeedbackIntoPrompt(originalPrompt, feedbackResult.Data!);
    }

    // ─── Helpers ────────────────────────────────────────────────

    private static int GetInt(Dictionary<string, object> dict, string key)
    {
        if (!dict.TryGetValue(key, out var val)) return 0;
        if (val is int i) return i;
        if (val is long l) return (int)l;
        if (val is JsonElement je && je.TryGetInt32(out var ji)) return ji;
        return int.TryParse(val?.ToString(), out var parsed) ? parsed : 0;
    }
}

// ─── DI Registration ────────────────────────────────────────────
public static class FeedbackServiceExtensions
{
    public static IServiceCollection AddXIIGenFeedbackService(
        this IServiceCollection services,
        Action<FeedbackConfig> configure = null)
    {
        var config = new FeedbackConfig();
        configure?.Invoke(config);
        services.AddSingleton(config);
        services.AddSingleton<FeedbackInjector>();
        services.AddTransient<FeedbackService>();
        return services;
    }
}
