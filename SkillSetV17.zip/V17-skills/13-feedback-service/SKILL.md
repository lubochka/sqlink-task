---
skill_id: "13"
name: "feedback-service"
title: "Feedback Service"
layer: "L4: Step Executors"
version: "17.0"
status: "active"
dependencies:
  - "01-core-interfaces"
  - "02-object-processor"
  - "03-elasticsearch-datastore"
dotnet_namespace: "XIIGen.Services.Feedback"
di_registration: "services.AddXIIGenFeedbackService()"
es_index: "feedback"
genie_dna:
  - "DNA-1: Feedback records as Dictionary<string, object>"
  - "DNA-2: BuildSearchFilter for similarity queries"
  - "DNA-5: DataProcessResult per CRUD operation"
---

# Skill 13: Feedback Service

## Purpose
Manages the feedback loop that drives continuous AI improvement across the XIIGen platform.
Captures user ratings and comments on AI-generated outputs, stores them in Elasticsearch,
performs similarity-based retrieval to find relevant past feedback, and injects curated
positive/negative examples into future AI prompts. This is the mechanism that makes every
subsequent generation better than the last.

## Architecture

```
┌─────────────┐     ┌──────────────────┐     ┌─────────────────┐
│  User / UI  │────▶│ FeedbackService  │────▶│  Elasticsearch  │
│  (rate 1-5) │     │                  │     │  "feedback" idx  │
└─────────────┘     │  ┌────────────┐  │     └─────────────────┘
                    │  │ Submit     │  │              │
                    │  │ Search     │  │◀─────────────┘
                    │  │ Inject     │  │
                    │  └────────────┘  │     ┌─────────────────┐
┌─────────────┐     │                  │────▶│ AI Transform    │
│ Skill 11    │◀────│  InjectFeedback  │     │ (Skill 11)      │
│ AI Transform│     │  into prompts    │     │ gets improved   │
└─────────────┘     └──────────────────┘     │ prompts         │
                                             └─────────────────┘
```

## Core Operations

### 1. CRUD Operations
| Method | Description | Returns |
|--------|-------------|---------|
| `SubmitFeedbackAsync` | Create new feedback with rating, text, metadata | DataProcessResult<Dictionary> |
| `GetFeedbackByIdAsync` | Retrieve single feedback by ID | DataProcessResult<Dictionary> |
| `UpdateFeedbackAsync` | Update existing feedback (text, rating, tags) | DataProcessResult<Dictionary> |
| `DeleteFeedbackAsync` | Soft-delete feedback entry | DataProcessResult<bool> |
| `ListFeedbackAsync` | Paginated list with filters | DataProcessResult<List<Dictionary>> |

### 2. Similarity Search
Find relevant past feedback for a given context using multi-field matching:
- **flowId**: Same flow definition
- **stepType**: Same step type (e.g., "ai-transform", "ai-review")
- **componentType**: Similar UI component (e.g., "button", "form", "card")
- **technology**: Same target tech stack (e.g., "react", "angular")
- **tags**: Overlapping tags for domain matching

Query uses BuildSearchFilter (DNA-2) — empty fields are automatically excluded,
so partial context still returns useful results.

### 3. Feedback Injection
Transforms retrieved feedback into prompt sections:

```
## Feedback from previous similar tasks:

### ✅ What worked well (from highly-rated outputs):
- Clean component separation with proper prop typing (Rating: 5/5, Task: login-form/react)
- Responsive grid layout that handles edge cases (Rating: 4/5, Task: dashboard/react)

### ❌ What to avoid (from poorly-rated outputs):
- Do NOT use inline styles — use CSS modules or Tailwind (Rating: 1/5)
- Avoid deeply nested ternary expressions (Rating: 2/5)
---
```

### 4. Rating System
| Rating | Label | Prompt Category | Weight |
|--------|-------|----------------|--------|
| 5 | Excellent | positive | 1.0 |
| 4 | Good | positive | 0.8 |
| 3 | Acceptable | (excluded) | 0.0 |
| 2 | Poor | negative | 0.8 |
| 1 | Bad | negative | 1.0 |

Rating 3 (neutral) is stored but excluded from prompt injection to keep signal clear.

## Feedback Document Schema (DNA-1)

```json
{
  "feedbackId": "fb-uuid-001",
  "traceId": "trace-abc-123",
  "flowId": "figma-to-code",
  "stepId": "step-transform-01",
  "stepType": "ai-transform",
  "rating": 4,
  "ratingLabel": "Good",
  "text": "Clean React component but missing error boundary",
  "tags": ["react", "component", "error-handling"],
  "componentType": "login-form",
  "technology": "react",
  "framework": "next.js",
  "modelUsed": "claude-sonnet-4-20250514",
  "inputSnippet": "{ nodes: [...], screenName: 'LoginScreen' }",
  "outputSnippet": "export default function LoginForm() { ... }",
  "createdAt": "2025-02-07T20:00:00Z",
  "updatedAt": null,
  "isDeleted": false,
  "metadata": {}
}
```

All fields optional except `feedbackId` and `rating`. Empty fields skipped
in queries via BuildSearchFilter (DNA-2).

## Configuration

```csharp
services.AddXIIGenFeedbackService(opts => {
    opts.IndexName = "feedback";
    opts.MaxPositiveExamples = 3;
    opts.MaxNegativeExamples = 3;
    opts.SimilarityFields = ["flowId", "stepType", "componentType", "technology"];
    opts.MinRatingForPositive = 4;
    opts.MaxRatingForNegative = 2;
    opts.IncludeSnippetsInInjection = true;
    opts.MaxSnippetLength = 500;
});
```

## Key Classes

| Class | Responsibility |
|-------|---------------|
| `FeedbackService` | Core CRUD + similarity search + prompt injection |
| `FeedbackConfig` | Configuration POCO for DI |
| `FeedbackInjector` | Transforms feedback list → prompt section string |
| `FeedbackServiceExtensions` | DI registration |

## Integration Points

### With Skill 11 (AI Transform Executor)
```csharp
var feedback = await feedbackService.SearchSimilarAsync(flowId, stepType, componentType, tech);
var enrichedPrompt = feedbackService.InjectFeedbackIntoPrompt(originalPrompt, feedback);
```

### With Skill 12 (AI Review Executor)
After review verdict, auto-generate feedback:
```csharp
await feedbackService.SubmitFeedbackAsync(new Dictionary<string, object> {
    ["traceId"] = traceId, ["flowId"] = flowId,
    ["rating"] = verdict == "APPROVE" ? 5 : verdict == "REVISE" ? 3 : 1,
    ["text"] = reviewSummary, ["modelUsed"] = model
});
```

### REST Endpoints (via Skill 15 API Gateway)
- `POST /api/feedback` — Submit
- `GET /api/feedback/{id}` — Get by ID
- `GET /api/feedback?flowId=...&stepType=...` — Search
- `PUT /api/feedback/{id}` — Update
- `DELETE /api/feedback/{id}` — Soft delete
- `POST /api/feedback/inject` — Get injection string

## Genie DNA Compliance

| DNA Rule | Application |
|----------|------------|
| DNA-1 | Feedback stored/returned as Dictionary<string, object> |
| DNA-2 | SearchSimilarAsync uses BuildSearchFilter — null/empty auto-excluded |
| DNA-5 | Every operation returns DataProcessResult |

## Positive Example
```
1. User rates Figma→React output 2/5: "Used inline styles, no TypeScript types"
2. Next similar request: feedback injected as "What to avoid: inline styles, missing types"
3. AI generates cleaner output with Tailwind + TypeScript → rated 5/5
4. Future prompts include BOTH as positive/negative examples → continuous improvement
```

## Negative Example
- Storing feedback with fixed C# model classes (violates DNA-1)
- Querying with hardcoded field checks instead of BuildSearchFilter (violates DNA-2)
- Injecting ALL feedback regardless of relevance (noise drowns signal)
- Including rating-3 in injection (ambiguous signal)
- Not truncating snippets (wastes AI context window)
