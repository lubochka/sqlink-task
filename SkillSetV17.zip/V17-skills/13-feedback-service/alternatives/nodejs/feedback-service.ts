// XIIGen Feedback Service - Skill 13 | Node.js/TypeScript Alternative
// Feedback CRUD + similarity matching + prompt injection
// Genie DNA: DNA-1 (Record<string,any>), DNA-2 (buildSearchFilter), DNA-5 (DataProcessResult)

import { IDatabaseService, IQueueService, ICacheService } from '../01-core-interfaces';
import { DataProcessResult, MicroserviceBase } from '../01-core-interfaces';

// ─── Configuration ──────────────────────────────────────────────
export interface FeedbackConfig {
  indexName: string;
  maxPositiveExamples: number;
  maxNegativeExamples: number;
  similarityFields: string[];
  minRatingForPositive: number;
  maxRatingForNegative: number;
  includeSnippetsInInjection: boolean;
  maxSnippetLength: number;
  defaultPageSize: number;
}

const DEFAULT_CONFIG: FeedbackConfig = {
  indexName: 'feedback',
  maxPositiveExamples: 3,
  maxNegativeExamples: 3,
  similarityFields: ['flowId', 'stepType', 'componentType', 'technology'],
  minRatingForPositive: 4,
  maxRatingForNegative: 2,
  includeSnippetsInInjection: true,
  maxSnippetLength: 500,
  defaultPageSize: 20,
};

type FeedbackDoc = Record<string, any>;

// ─── Feedback Injector ──────────────────────────────────────────
export class FeedbackInjector {
  constructor(private config: FeedbackConfig) {}

  buildInjection(feedbackList: FeedbackDoc[]): string {
    if (!feedbackList?.length) return '';

    const positive = feedbackList
      .filter(f => (f.rating ?? 0) >= this.config.minRatingForPositive)
      .sort((a, b) => (b.rating ?? 0) - (a.rating ?? 0))
      .slice(0, this.config.maxPositiveExamples);

    const negative = feedbackList
      .filter(f => (f.rating ?? 0) <= this.config.maxRatingForNegative)
      .sort((a, b) => (a.rating ?? 0) - (b.rating ?? 0))
      .slice(0, this.config.maxNegativeExamples);

    if (!positive.length && !negative.length) return '';

    const lines: string[] = ['\n## Feedback from previous similar tasks:\n'];

    if (positive.length) {
      lines.push('### ✅ What worked well (from highly-rated outputs):');
      for (const fb of positive) {
        const ctx = fb.componentType && fb.technology
          ? ` (Rating: ${fb.rating}/5, Task: ${fb.componentType}/${fb.technology})`
          : ` (Rating: ${fb.rating}/5)`;
        lines.push(`- ${fb.text ?? ''}${ctx}`);
        if (this.config.includeSnippetsInInjection && fb.outputSnippet)
          lines.push(`  \`\`\`\n  ${this.truncate(fb.outputSnippet)}\n  \`\`\``);
      }
      lines.push('');
    }

    if (negative.length) {
      lines.push('### ❌ What to avoid (from poorly-rated outputs):');
      for (const fb of negative) {
        lines.push(`- ${fb.text ?? ''} (Rating: ${fb.rating}/5)`);
        if (this.config.includeSnippetsInInjection && fb.outputSnippet)
          lines.push(`  \`\`\`\n  ${this.truncate(fb.outputSnippet)}\n  \`\`\``);
      }
      lines.push('');
    }

    lines.push('---\n');
    return lines.join('\n');
  }

  injectIntoPrompt(originalPrompt: string, feedback: FeedbackDoc[]): string {
    const injection = this.buildInjection(feedback);
    return injection ? injection + originalPrompt : originalPrompt;
  }

  private truncate(text: string): string {
    return text.length > this.config.maxSnippetLength
      ? text.substring(0, this.config.maxSnippetLength) + '...'
      : text;
  }
}

// ─── Core Feedback Service ──────────────────────────────────────
export class FeedbackService extends MicroserviceBase {
  private config: FeedbackConfig;
  private injector: FeedbackInjector;

  constructor(
    db: IDatabaseService,
    queue: IQueueService,
    config?: Partial<FeedbackConfig>,
    cache?: ICacheService
  ) {
    super(db, queue, 'feedback-service', cache);
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.injector = new FeedbackInjector(this.config);
  }

  // ─── CRUD: Create ───────────────────────────────────────────
  async submitFeedback(feedback: FeedbackDoc): Promise<DataProcessResult<FeedbackDoc>> {
    try {
      if (feedback.rating === undefined) return DataProcessResult.error('Rating is required');

      const id = feedback.feedbackId ?? `fb-${crypto.randomUUID()}`;
      feedback.feedbackId = id;
      feedback.createdAt = new Date().toISOString();
      feedback.isDeleted = false;
      feedback.ratingLabel = this.ratingLabel(feedback.rating);

      await this.storeDocument(this.config.indexName, id, feedback);
      this.logger.info(`Feedback ${id} submitted: rating=${feedback.rating}`);
      return DataProcessResult.created(feedback);
    } catch (err: any) {
      return DataProcessResult.error(err.message);
    }
  }

  // ─── CRUD: Read ─────────────────────────────────────────────
  async getFeedbackById(id: string): Promise<DataProcessResult<FeedbackDoc>> {
    try {
      const result = await this.getDocument(this.config.indexName, id);
      if (!result.isSuccess) return DataProcessResult.notFound(`Feedback ${id} not found`);
      if (result.data?.isDeleted) return DataProcessResult.notFound(`Feedback ${id} deleted`);
      return DataProcessResult.success(result.data!);
    } catch (err: any) {
      return DataProcessResult.error(err.message);
    }
  }

  // ─── CRUD: Update ───────────────────────────────────────────
  async updateFeedback(id: string, updates: FeedbackDoc): Promise<DataProcessResult<FeedbackDoc>> {
    try {
      const existing = await this.getFeedbackById(id);
      if (!existing.isSuccess) return existing;

      const doc = { ...existing.data! };
      for (const [key, val] of Object.entries(updates)) {
        if (key === 'feedbackId' || key === 'createdAt') continue;
        doc[key] = val;
      }
      doc.updatedAt = new Date().toISOString();
      if (updates.rating !== undefined) doc.ratingLabel = this.ratingLabel(doc.rating);

      await this.storeDocument(this.config.indexName, id, doc);
      return DataProcessResult.success(doc);
    } catch (err: any) {
      return DataProcessResult.error(err.message);
    }
  }

  // ─── CRUD: Delete (soft) ────────────────────────────────────
  async deleteFeedback(id: string): Promise<DataProcessResult<boolean>> {
    const result = await this.updateFeedback(id, { isDeleted: true });
    return result.isSuccess
      ? DataProcessResult.success(true)
      : DataProcessResult.error(result.message);
  }

  // ─── Similarity Search (DNA-2) ────────────────────────────────
  async searchSimilar(
    flowId?: string, stepType?: string, componentType?: string,
    technology?: string, tags?: string[], limit = 10
  ): Promise<DataProcessResult<FeedbackDoc[]>> {
    try {
      const filter: Record<string, any> = { isDeleted: false };
      if (flowId) filter.flowId = flowId;
      if (stepType) filter.stepType = stepType;
      if (componentType) filter.componentType = componentType;
      if (technology) filter.technology = technology;
      if (tags?.length) filter.tags = tags;

      const result = await this.searchDocuments(this.config.indexName, filter, limit);
      return DataProcessResult.success(result.data ?? []);
    } catch (err: any) {
      return DataProcessResult.error(err.message);
    }
  }

  // ─── Feedback for Injection ───────────────────────────────────
  async getFeedbackForInjection(
    flowId?: string, stepType?: string, componentType?: string, technology?: string
  ): Promise<DataProcessResult<FeedbackDoc[]>> {
    const max = this.config.maxPositiveExamples + this.config.maxNegativeExamples + 5;
    const result = await this.searchSimilar(flowId, stepType, componentType, technology, undefined, max);
    if (!result.isSuccess) return result;

    const filtered = result.data!.filter(f => {
      const r = f.rating ?? 0;
      return r >= this.config.minRatingForPositive || r <= this.config.maxRatingForNegative;
    });
    return DataProcessResult.success(filtered);
  }

  // ─── Prompt Injection ─────────────────────────────────────────
  buildInjectionString(feedback: FeedbackDoc[]): string {
    return this.injector.buildInjection(feedback);
  }

  injectFeedbackIntoPrompt(prompt: string, feedback: FeedbackDoc[]): string {
    return this.injector.injectIntoPrompt(prompt, feedback);
  }

  async enrichPromptWithFeedback(
    prompt: string, flowId?: string, stepType?: string,
    componentType?: string, technology?: string
  ): Promise<string> {
    const result = await this.getFeedbackForInjection(flowId, stepType, componentType, technology);
    if (!result.isSuccess || !result.data!.length) return prompt;
    return this.injectFeedbackIntoPrompt(prompt, result.data!);
  }

  // ─── Helpers ──────────────────────────────────────────────────
  private ratingLabel(rating: number): string {
    return { 5: 'Excellent', 4: 'Good', 3: 'Acceptable', 2: 'Poor', 1: 'Bad' }[rating] ?? 'Unknown';
  }
}
