# XIIGen Feedback Service - Skill 13 | Python Alternative
# Feedback CRUD + similarity matching + prompt injection
# Genie DNA: DNA-1 (dict), DNA-2 (build_search_filter), DNA-5 (DataProcessResult)

from __future__ import annotations
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional

from core_interfaces import IDatabaseService, IQueueService, ICacheService
from core_interfaces import DataProcessResult, MicroserviceBase


# ─── Configuration ──────────────────────────────────────────────
@dataclass
class FeedbackConfig:
    index_name: str = "feedback"
    max_positive_examples: int = 3
    max_negative_examples: int = 3
    similarity_fields: list[str] = field(default_factory=lambda: ["flowId", "stepType", "componentType", "technology"])
    min_rating_for_positive: int = 4
    max_rating_for_negative: int = 2
    include_snippets_in_injection: bool = True
    max_snippet_length: int = 500
    default_page_size: int = 20


# ─── Feedback Injector ──────────────────────────────────────────
class FeedbackInjector:
    def __init__(self, config: FeedbackConfig):
        self._config = config

    def build_injection(self, feedback_list: list[dict[str, Any]]) -> str:
        if not feedback_list:
            return ""

        positive = sorted(
            [f for f in feedback_list if (f.get("rating", 0) or 0) >= self._config.min_rating_for_positive],
            key=lambda f: f.get("rating", 0), reverse=True
        )[:self._config.max_positive_examples]

        negative = sorted(
            [f for f in feedback_list if (f.get("rating", 0) or 0) <= self._config.max_rating_for_negative],
            key=lambda f: f.get("rating", 0)
        )[:self._config.max_negative_examples]

        if not positive and not negative:
            return ""

        lines = ["\n## Feedback from previous similar tasks:\n"]

        if positive:
            lines.append("### ✅ What worked well (from highly-rated outputs):")
            for fb in positive:
                comp, tech = fb.get("componentType", ""), fb.get("technology", "")
                ctx = f" (Rating: {fb['rating']}/5, Task: {comp}/{tech})" if comp and tech else f" (Rating: {fb['rating']}/5)"
                lines.append(f"- {fb.get('text', '')}{ctx}")
                if self._config.include_snippets_in_injection and fb.get("outputSnippet"):
                    snippet = self._truncate(fb["outputSnippet"])
                    lines.append(f"  ```\n  {snippet}\n  ```")
            lines.append("")

        if negative:
            lines.append("### ❌ What to avoid (from poorly-rated outputs):")
            for fb in negative:
                lines.append(f"- {fb.get('text', '')} (Rating: {fb['rating']}/5)")
                if self._config.include_snippets_in_injection and fb.get("outputSnippet"):
                    snippet = self._truncate(fb["outputSnippet"])
                    lines.append(f"  ```\n  {snippet}\n  ```")
            lines.append("")

        lines.append("---\n")
        return "\n".join(lines)

    def inject_into_prompt(self, original_prompt: str, feedback: list[dict]) -> str:
        injection = self.build_injection(feedback)
        return (injection + original_prompt) if injection else original_prompt

    def _truncate(self, text: str) -> str:
        if len(text) > self._config.max_snippet_length:
            return text[:self._config.max_snippet_length] + "..."
        return text


# ─── Core Feedback Service ──────────────────────────────────────
class FeedbackService(MicroserviceBase):
    RATING_LABELS = {5: "Excellent", 4: "Good", 3: "Acceptable", 2: "Poor", 1: "Bad"}

    def __init__(
        self, db: IDatabaseService, queue: IQueueService,
        config: FeedbackConfig | None = None, cache: ICacheService | None = None
    ):
        super().__init__(db, queue, "feedback-service", cache)
        self._config = config or FeedbackConfig()
        self._injector = FeedbackInjector(self._config)

    # ─── CRUD: Create ───────────────────────────────────────────
    async def submit_feedback(self, feedback: dict[str, Any]) -> DataProcessResult:
        try:
            if "rating" not in feedback:
                return DataProcessResult.error("Rating is required")

            fb_id = feedback.get("feedbackId") or f"fb-{uuid.uuid4().hex}"
            feedback["feedbackId"] = fb_id
            feedback["createdAt"] = datetime.now(timezone.utc).isoformat()
            feedback["isDeleted"] = False
            feedback["ratingLabel"] = self.RATING_LABELS.get(feedback["rating"], "Unknown")

            await self.store_document(self._config.index_name, fb_id, feedback)
            self.logger.info(f"Feedback {fb_id} submitted: rating={feedback['rating']}")
            return DataProcessResult.created(feedback)
        except Exception as ex:
            return DataProcessResult.error(str(ex))

    # ─── CRUD: Read ─────────────────────────────────────────────
    async def get_feedback_by_id(self, feedback_id: str) -> DataProcessResult:
        try:
            result = await self.get_document(self._config.index_name, feedback_id)
            if not result.is_success:
                return DataProcessResult.not_found(f"Feedback {feedback_id} not found")
            if result.data.get("isDeleted"):
                return DataProcessResult.not_found(f"Feedback {feedback_id} deleted")
            return DataProcessResult.success(result.data)
        except Exception as ex:
            return DataProcessResult.error(str(ex))

    # ─── CRUD: Update ───────────────────────────────────────────
    async def update_feedback(self, feedback_id: str, updates: dict[str, Any]) -> DataProcessResult:
        try:
            existing = await self.get_feedback_by_id(feedback_id)
            if not existing.is_success:
                return existing

            doc = {**existing.data}
            for key, val in updates.items():
                if key in ("feedbackId", "createdAt"):
                    continue
                doc[key] = val
            doc["updatedAt"] = datetime.now(timezone.utc).isoformat()
            if "rating" in updates:
                doc["ratingLabel"] = self.RATING_LABELS.get(doc["rating"], "Unknown")

            await self.store_document(self._config.index_name, feedback_id, doc)
            return DataProcessResult.success(doc)
        except Exception as ex:
            return DataProcessResult.error(str(ex))

    # ─── CRUD: Delete (soft) ────────────────────────────────────
    async def delete_feedback(self, feedback_id: str) -> DataProcessResult:
        result = await self.update_feedback(feedback_id, {"isDeleted": True})
        return DataProcessResult.success(True) if result.is_success else result

    # ─── Similarity Search (DNA-2) ──────────────────────────────
    async def search_similar(
        self, flow_id: str = None, step_type: str = None,
        component_type: str = None, technology: str = None,
        tags: list[str] = None, limit: int = 10
    ) -> DataProcessResult:
        try:
            search_filter: dict[str, Any] = {"isDeleted": False}
            if flow_id: search_filter["flowId"] = flow_id
            if step_type: search_filter["stepType"] = step_type
            if component_type: search_filter["componentType"] = component_type
            if technology: search_filter["technology"] = technology
            if tags: search_filter["tags"] = tags

            result = await self.search_documents(self._config.index_name, search_filter, limit)
            return DataProcessResult.success(result.data or [])
        except Exception as ex:
            return DataProcessResult.error(str(ex))

    # ─── Feedback for Injection ─────────────────────────────────
    async def get_feedback_for_injection(
        self, flow_id: str = None, step_type: str = None,
        component_type: str = None, technology: str = None
    ) -> DataProcessResult:
        max_needed = self._config.max_positive_examples + self._config.max_negative_examples + 5
        result = await self.search_similar(flow_id, step_type, component_type, technology, limit=max_needed)
        if not result.is_success:
            return result

        filtered = [
            f for f in result.data
            if (f.get("rating", 0) or 0) >= self._config.min_rating_for_positive
            or (f.get("rating", 0) or 0) <= self._config.max_rating_for_negative
        ]
        return DataProcessResult.success(filtered)

    # ─── Prompt Injection ───────────────────────────────────────
    def build_injection_string(self, feedback: list[dict]) -> str:
        return self._injector.build_injection(feedback)

    def inject_feedback_into_prompt(self, prompt: str, feedback: list[dict]) -> str:
        return self._injector.inject_into_prompt(prompt, feedback)

    async def enrich_prompt_with_feedback(
        self, prompt: str, flow_id: str = None, step_type: str = None,
        component_type: str = None, technology: str = None
    ) -> str:
        result = await self.get_feedback_for_injection(flow_id, step_type, component_type, technology)
        if not result.is_success or not result.data:
            return prompt
        return self.inject_feedback_into_prompt(prompt, result.data)
