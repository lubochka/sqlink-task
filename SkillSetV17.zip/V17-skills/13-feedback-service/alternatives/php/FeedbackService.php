<?php
// =============================================================================
// Skill 13 — Feedback Service (PHP 8.3+)
// Feedback CRUD + similarity matching + AI prompt injection
// Genie DNA: Dynamic documents (array), buildSearchFilter, DataProcessResult
// =============================================================================

declare(strict_types=1);

namespace XIIGen\Services\Feedback;

// ---------------------------------------------------------------------------
// Interfaces
// ---------------------------------------------------------------------------
interface DatabaseProviderInterface {
    /** @return array<int, array<string, mixed>> */
    public function query(string $index, array $filters): array;
    /** @return array<string, mixed> */
    public function upsert(string $index, string $docId, array $doc): array;
    public function delete(string $index, string $docId): void;
}

interface ObjectProcessorInterface {
    /** @param array<string, mixed> $doc @return array<string, mixed> */
    public function parseObjectAlternative(array $doc): array;
    /** @param array<string, mixed> $params @return array<string, mixed> */
    public function buildSearchFilter(array $params): array;
}

interface NodeDebuggerInterface {
    /** @param array<string, mixed> $data */
    public function snapshot(string $traceId, string $nodeId, string $phase, array $data): void;
}

// ---------------------------------------------------------------------------
// Models
// ---------------------------------------------------------------------------
readonly class FeedbackConfig {
    /** @param list<string> $similarityFields */
    public function __construct(
        public string $indexName = 'feedback',
        public int $maxPositiveExamples = 3,
        public int $maxNegativeExamples = 3,
        public array $similarityFields = ['flowId', 'stepType', 'componentType', 'technology'],
        public int $minRatingForPositive = 4,
        public int $maxRatingForNegative = 2,
        public bool $includeSnippetsInInjection = true,
        public int $maxSnippetLength = 500,
        public int $defaultPageSize = 20,
    ) {}
}

readonly class FeedbackEntry {
    public function __construct(
        public ?string $feedbackId = null,
        public string $traceId = '',
        public string $nodeId = '',
        public ?string $flowId = null,
        public ?string $stepType = null,
        public ?string $componentType = null,
        public ?string $technology = null,
        public int $rating = 3,
        public ?string $userComment = null,
        public ?string $codeSnippet = null,
        /** @var array<string, mixed>|null */
        public ?array $metadata = null,
    ) {}
}

readonly class FeedbackQuery {
    public function __construct(
        public ?string $flowId = null,
        public ?string $stepType = null,
        public ?string $componentType = null,
        public ?string $technology = null,
        public ?int $minRating = null,
        public ?int $maxRating = null,
        public int $page = 0,
        public int $pageSize = 20,
    ) {}
}

/** @template T */
readonly class DataProcessResult {
    /** @param T|null $data */
    public function __construct(
        public bool $success,
        public mixed $data = null,
        public ?string $error = null,
    ) {}

    /** @param T $data @return self<T> */
    public static function ok(mixed $data): self { return new self(true, $data); }
    public static function fail(string $err): self { return new self(false, error: $err); }
}

// ---------------------------------------------------------------------------
// Feedback Injector
// ---------------------------------------------------------------------------
class FeedbackInjector {
    public function __construct(private readonly FeedbackConfig $cfg) {}

    /** @param list<array<string, mixed>> $feedbackList */
    public function buildInjection(array $feedbackList): string
    {
        if (empty($feedbackList)) return '';

        $positive = array_slice(
            array_filter($feedbackList, fn($f) => ($f['rating'] ?? 0) >= $this->cfg->minRatingForPositive),
            0, $this->cfg->maxPositiveExamples
        );
        usort($positive, fn($a, $b) => ($b['rating'] ?? 0) <=> ($a['rating'] ?? 0));

        $negative = array_slice(
            array_filter($feedbackList, fn($f) => ($f['rating'] ?? 5) <= $this->cfg->maxRatingForNegative),
            0, $this->cfg->maxNegativeExamples
        );
        usort($negative, fn($a, $b) => ($a['rating'] ?? 0) <=> ($b['rating'] ?? 0));

        if (empty($positive) && empty($negative)) return '';

        $out = "\n--- FEEDBACK FROM PREVIOUS JOBS ---\n";

        if (!empty($positive)) {
            $out .= "\n✅ POSITIVE EXAMPLES (replicate these patterns):\n";
            foreach ($positive as $i => $f) {
                $out .= $this->formatEntry($f, $i + 1);
            }
        }
        if (!empty($negative)) {
            $out .= "\n❌ NEGATIVE EXAMPLES (avoid these patterns):\n";
            foreach ($negative as $i => $f) {
                $out .= $this->formatEntry($f, $i + 1);
            }
        }
        $out .= "\n--- END FEEDBACK ---\n";
        return $out;
    }

    /** @param array<string, mixed> $f */
    private function formatEntry(array $f, int $idx): string
    {
        $line = "{$idx}. Rating: " . ($f['rating'] ?? 0) . "/5";
        $comment = trim($f['userComment'] ?? '');
        if ($comment !== '') $line .= " — {$comment}";
        $line .= "\n";

        if ($this->cfg->includeSnippetsInInjection) {
            $snippet = trim($f['codeSnippet'] ?? '');
            if ($snippet !== '') {
                $trimmed = mb_strlen($snippet) > $this->cfg->maxSnippetLength
                    ? mb_substr($snippet, 0, $this->cfg->maxSnippetLength) . '...'
                    : $snippet;
                $line .= "   Code: {$trimmed}\n";
            }
        }
        return $line;
    }
}

// ---------------------------------------------------------------------------
// Service
// ---------------------------------------------------------------------------
class FeedbackService {
    private readonly FeedbackConfig $cfg;
    private readonly FeedbackInjector $injector;

    public function __construct(
        private readonly DatabaseProviderInterface $db,
        private readonly ObjectProcessorInterface $obj,
        private readonly NodeDebuggerInterface $debugger,
        ?FeedbackConfig $config = null,
    ) {
        $this->cfg = $config ?? new FeedbackConfig();
        $this->injector = new FeedbackInjector($this->cfg);
    }

    /** @return DataProcessResult<array<string,mixed>> */
    public function submit(string $traceId, string $nodeId, FeedbackEntry $entry): DataProcessResult
    {
        try {
            $feedbackId = $entry->feedbackId ?? bin2hex(random_bytes(16));
            $sentiment = self::deriveSentiment($entry->rating);

            $doc = $this->obj->parseObjectAlternative([
                'feedbackId' => $feedbackId,
                'traceId' => $traceId,
                'nodeId' => $nodeId,
                'flowId' => $entry->flowId ?? '',
                'stepType' => $entry->stepType ?? '',
                'componentType' => $entry->componentType ?? '',
                'technology' => $entry->technology ?? '',
                'rating' => $entry->rating,
                'sentiment' => $sentiment,
                'userComment' => $entry->userComment ?? '',
                'codeSnippet' => $entry->codeSnippet ?? '',
                'createdAt' => date('c'),
            ]);

            $result = $this->db->upsert($this->cfg->indexName, $feedbackId, $doc);

            $this->debugger->snapshot($traceId, $nodeId, 'feedback-submit', [
                'feedbackId' => $feedbackId,
                'rating' => $entry->rating,
                'sentiment' => $sentiment,
            ]);

            return DataProcessResult::ok($result);
        } catch (\Throwable $ex) {
            error_log("FeedbackService::submit failed: {$ex->getMessage()}");
            return DataProcessResult::fail($ex->getMessage());
        }
    }

    /** @return DataProcessResult<list<array<string,mixed>>> */
    public function query(FeedbackQuery $q): DataProcessResult
    {
        try {
            $params = array_filter([
                'flowId' => $q->flowId,
                'stepType' => $q->stepType,
                'componentType' => $q->componentType,
                'technology' => $q->technology,
            ], fn($v) => $v !== null);

            $filter = $this->obj->buildSearchFilter($params);
            $docs = $this->db->query($this->cfg->indexName, $filter);

            $filtered = array_filter($docs, function ($d) use ($q) {
                $r = (int)($d['rating'] ?? 3);
                if ($q->minRating !== null && $r < $q->minRating) return false;
                if ($q->maxRating !== null && $r > $q->maxRating) return false;
                return true;
            });

            return DataProcessResult::ok(array_values($filtered));
        } catch (\Throwable $ex) {
            return DataProcessResult::fail($ex->getMessage());
        }
    }

    /** @return DataProcessResult<string> */
    public function getSimilarFeedbackPrompt(
        ?string $flowId, ?string $stepType, ?string $componentType, ?string $technology
    ): DataProcessResult {
        try {
            $params = array_filter([
                'flowId' => $flowId,
                'stepType' => $stepType,
                'componentType' => $componentType,
                'technology' => $technology,
            ], fn($v) => $v !== null);

            $filter = $this->obj->buildSearchFilter($params);
            $docs = $this->db->query($this->cfg->indexName, $filter);
            $injection = $this->injector->buildInjection($docs);
            return DataProcessResult::ok($injection);
        } catch (\Throwable) {
            return DataProcessResult::ok(''); // graceful degradation
        }
    }

    /** @return DataProcessResult<bool> */
    public function delete(string $feedbackId): DataProcessResult
    {
        try {
            $this->db->delete($this->cfg->indexName, $feedbackId);
            return DataProcessResult::ok(true);
        } catch (\Throwable $ex) {
            return DataProcessResult::fail($ex->getMessage());
        }
    }

    private static function deriveSentiment(int $rating): string
    {
        if ($rating >= 4) return 'positive';
        if ($rating <= 2) return 'negative';
        return 'neutral';
    }
}
