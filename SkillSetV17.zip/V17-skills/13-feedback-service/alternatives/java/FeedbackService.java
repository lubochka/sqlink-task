// =============================================================================
// Skill 13 — Feedback Service (Java 21+)
// Feedback CRUD + similarity matching + AI prompt injection
// Genie DNA: Dynamic documents (Map), buildSearchFilter, DataProcessResult
// =============================================================================

package com.xiigen.services.feedback;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Logger;
import java.util.stream.Collectors;

// ---------------------------------------------------------------------------
// Interfaces
// ---------------------------------------------------------------------------
interface DatabaseProvider {
    CompletableFuture<List<Map<String, Object>>> query(String index, Map<String, Object> filters);
    CompletableFuture<Map<String, Object>> upsert(String index, String docId, Map<String, Object> doc);
    CompletableFuture<Void> delete(String index, String docId);
}

interface ObjectProcessor {
    Map<String, Object> parseObjectAlternative(Map<String, Object> doc);
    Map<String, Object> buildSearchFilter(Map<String, Object> params);
}

interface NodeDebugger {
    CompletableFuture<Void> snapshot(String traceId, String nodeId, String phase,
                                     Map<String, Object> data);
}

// ---------------------------------------------------------------------------
// Models
// ---------------------------------------------------------------------------
record FeedbackConfig(
    String indexName,
    int maxPositiveExamples,
    int maxNegativeExamples,
    List<String> similarityFields,
    int minRatingForPositive,
    int maxRatingForNegative,
    boolean includeSnippetsInInjection,
    int maxSnippetLength,
    int defaultPageSize
) {
    static FeedbackConfig defaults() {
        return new FeedbackConfig("feedback", 3, 3,
            List.of("flowId", "stepType", "componentType", "technology"),
            4, 2, true, 500, 20);
    }
}

record FeedbackEntry(
    String feedbackId, String traceId, String nodeId, String flowId,
    String stepType, String componentType, String technology,
    int rating, String sentiment, String userComment,
    String codeSnippet, Map<String, Object> metadata,
    Instant createdAt
) {}

record FeedbackQuery(
    String flowId, String stepType, String componentType,
    String technology, Integer minRating, Integer maxRating,
    int page, int pageSize
) {
    FeedbackQuery {
        if (page < 0) page = 0;
        if (pageSize <= 0) pageSize = 20;
    }
}

record DataProcessResult<T>(boolean success, T data, String error, Map<String, Object> metadata) {
    static <T> DataProcessResult<T> ok(T data) { return new DataProcessResult<>(true, data, null, Map.of()); }
    static <T> DataProcessResult<T> fail(String err) { return new DataProcessResult<>(false, null, err, Map.of()); }
}

// ---------------------------------------------------------------------------
// Feedback Injector — transforms feedback → AI prompt section
// ---------------------------------------------------------------------------
class FeedbackInjector {
    private final FeedbackConfig cfg;

    FeedbackInjector(FeedbackConfig cfg) { this.cfg = cfg; }

    String buildInjection(List<Map<String, Object>> feedbackList) {
        if (feedbackList == null || feedbackList.isEmpty()) return "";

        var positive = feedbackList.stream()
            .filter(f -> getInt(f, "rating") >= cfg.minRatingForPositive())
            .sorted(Comparator.comparingInt((Map<String, Object> f) -> getInt(f, "rating")).reversed())
            .limit(cfg.maxPositiveExamples())
            .toList();

        var negative = feedbackList.stream()
            .filter(f -> getInt(f, "rating") <= cfg.maxRatingForNegative())
            .sorted(Comparator.comparingInt(f -> getInt(f, "rating")))
            .limit(cfg.maxNegativeExamples())
            .toList();

        if (positive.isEmpty() && negative.isEmpty()) return "";

        var sb = new StringBuilder("\n--- FEEDBACK FROM PREVIOUS JOBS ---\n");
        if (!positive.isEmpty()) {
            sb.append("\n✅ POSITIVE EXAMPLES (replicate these patterns):\n");
            for (int i = 0; i < positive.size(); i++) {
                appendFeedbackEntry(sb, positive.get(i), i + 1);
            }
        }
        if (!negative.isEmpty()) {
            sb.append("\n❌ NEGATIVE EXAMPLES (avoid these patterns):\n");
            for (int i = 0; i < negative.size(); i++) {
                appendFeedbackEntry(sb, negative.get(i), i + 1);
            }
        }
        sb.append("\n--- END FEEDBACK ---\n");
        return sb.toString();
    }

    private void appendFeedbackEntry(StringBuilder sb, Map<String, Object> f, int idx) {
        sb.append("%d. Rating: %d/5".formatted(idx, getInt(f, "rating")));
        var comment = getString(f, "userComment");
        if (!comment.isBlank()) sb.append(" — ").append(comment);
        sb.append("\n");
        if (cfg.includeSnippetsInInjection()) {
            var snippet = getString(f, "codeSnippet");
            if (!snippet.isBlank()) {
                var trimmed = snippet.length() > cfg.maxSnippetLength()
                    ? snippet.substring(0, cfg.maxSnippetLength()) + "..."
                    : snippet;
                sb.append("   Code: ").append(trimmed).append("\n");
            }
        }
    }

    private static int getInt(Map<String, Object> m, String key) {
        var v = m.get(key);
        return v instanceof Number n ? n.intValue() : 0;
    }

    private static String getString(Map<String, Object> m, String key) {
        var v = m.get(key);
        return v instanceof String s ? s : "";
    }
}

// ---------------------------------------------------------------------------
// Service
// ---------------------------------------------------------------------------
public class FeedbackService {
    private static final Logger log = Logger.getLogger(FeedbackService.class.getName());

    private final DatabaseProvider db;
    private final ObjectProcessor obj;
    private final NodeDebugger debugger;
    private final FeedbackConfig cfg;
    private final FeedbackInjector injector;

    public FeedbackService(DatabaseProvider db, ObjectProcessor obj,
                           NodeDebugger debugger, FeedbackConfig cfg) {
        this.db = db;
        this.obj = obj;
        this.debugger = debugger;
        this.cfg = cfg != null ? cfg : FeedbackConfig.defaults();
        this.injector = new FeedbackInjector(this.cfg);
    }

    // -- Submit feedback --------------------------------------------------
    public CompletableFuture<DataProcessResult<Map<String, Object>>> submit(
            String traceId, String nodeId, FeedbackEntry entry) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                var sentiment = deriveSentiment(entry.rating());
                var doc = obj.parseObjectAlternative(new HashMap<>(Map.of(
                    "feedbackId", entry.feedbackId() != null ? entry.feedbackId() : UUID.randomUUID().toString(),
                    "traceId", traceId,
                    "nodeId", nodeId,
                    "flowId", Optional.ofNullable(entry.flowId()).orElse(""),
                    "stepType", Optional.ofNullable(entry.stepType()).orElse(""),
                    "componentType", Optional.ofNullable(entry.componentType()).orElse(""),
                    "technology", Optional.ofNullable(entry.technology()).orElse(""),
                    "rating", entry.rating(),
                    "sentiment", sentiment
                )));
                doc.put("userComment", Optional.ofNullable(entry.userComment()).orElse(""));
                doc.put("codeSnippet", Optional.ofNullable(entry.codeSnippet()).orElse(""));
                doc.put("createdAt", Instant.now().toString());

                String docId = (String) doc.get("feedbackId");
                var result = db.upsert(cfg.indexName(), docId, doc).join();

                debugger.snapshot(traceId, nodeId, "feedback-submit",
                    Map.of("feedbackId", docId, "rating", entry.rating(), "sentiment", sentiment)).join();

                return DataProcessResult.ok(result);
            } catch (Exception ex) {
                log.severe("Feedback submit failed: " + ex.getMessage());
                return DataProcessResult.fail(ex.getMessage());
            }
        });
    }

    // -- Query feedback ---------------------------------------------------
    public CompletableFuture<DataProcessResult<List<Map<String, Object>>>> query(FeedbackQuery q) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                var params = new HashMap<String, Object>();
                if (q.flowId() != null) params.put("flowId", q.flowId());
                if (q.stepType() != null) params.put("stepType", q.stepType());
                if (q.componentType() != null) params.put("componentType", q.componentType());
                if (q.technology() != null) params.put("technology", q.technology());

                var filter = obj.buildSearchFilter(params);
                var docs = db.query(cfg.indexName(), filter).join();

                // Apply rating filters client-side (or could add to ES query)
                var filtered = docs.stream()
                    .filter(d -> {
                        int r = d.get("rating") instanceof Number n ? n.intValue() : 3;
                        if (q.minRating() != null && r < q.minRating()) return false;
                        if (q.maxRating() != null && r > q.maxRating()) return false;
                        return true;
                    })
                    .toList();

                return DataProcessResult.ok(filtered);
            } catch (Exception ex) {
                log.severe("Feedback query failed: " + ex.getMessage());
                return DataProcessResult.fail(ex.getMessage());
            }
        });
    }

    // -- Get similar feedback for prompt injection ------------------------
    public CompletableFuture<DataProcessResult<String>> getSimilarFeedbackPrompt(
            String flowId, String stepType, String componentType, String technology) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                var params = new HashMap<String, Object>();
                if (flowId != null) params.put("flowId", flowId);
                if (stepType != null) params.put("stepType", stepType);
                if (componentType != null) params.put("componentType", componentType);
                if (technology != null) params.put("technology", technology);

                var filter = obj.buildSearchFilter(params);
                var docs = db.query(cfg.indexName(), filter).join();
                String injection = injector.buildInjection(docs);
                return DataProcessResult.ok(injection);
            } catch (Exception ex) {
                log.warning("Similarity feedback failed: " + ex.getMessage());
                return DataProcessResult.ok(""); // graceful degradation
            }
        });
    }

    // -- Delete feedback --------------------------------------------------
    public CompletableFuture<DataProcessResult<Boolean>> delete(String feedbackId) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                db.delete(cfg.indexName(), feedbackId).join();
                return DataProcessResult.ok(true);
            } catch (Exception ex) {
                return DataProcessResult.fail(ex.getMessage());
            }
        });
    }

    // -- Helpers ----------------------------------------------------------
    private static String deriveSentiment(int rating) {
        if (rating >= 4) return "positive";
        if (rating <= 2) return "negative";
        return "neutral";
    }
}
