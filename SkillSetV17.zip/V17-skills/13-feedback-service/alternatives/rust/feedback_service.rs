// =============================================================================
// Skill 13 — Feedback Service (Rust)
// Feedback CRUD + similarity matching + AI prompt injection
// Genie DNA: Dynamic documents (serde_json::Value), build_search_filter, DataProcessResult
// =============================================================================

use async_trait::async_trait;
use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::collections::HashMap;
use uuid::Uuid;

// ---------------------------------------------------------------------------
// Interfaces (traits)
// ---------------------------------------------------------------------------
#[async_trait]
pub trait DatabaseProvider: Send + Sync {
    async fn query(&self, index: &str, filters: Value) -> Result<Vec<Value>, Box<dyn std::error::Error>>;
    async fn upsert(&self, index: &str, doc_id: &str, doc: Value) -> Result<Value, Box<dyn std::error::Error>>;
    async fn delete(&self, index: &str, doc_id: &str) -> Result<(), Box<dyn std::error::Error>>;
}

pub trait ObjectProcessor: Send + Sync {
    fn parse_object_alternative(&self, doc: Value) -> Value;
    fn build_search_filter(&self, params: &HashMap<String, String>) -> Value;
}

#[async_trait]
pub trait NodeDebugger: Send + Sync {
    async fn snapshot(&self, trace_id: &str, node_id: &str, phase: &str,
                      data: Value) -> Result<(), Box<dyn std::error::Error>>;
}

// ---------------------------------------------------------------------------
// Models
// ---------------------------------------------------------------------------
#[derive(Clone, Debug)]
pub struct FeedbackConfig {
    pub index_name: String,
    pub max_positive_examples: usize,
    pub max_negative_examples: usize,
    pub similarity_fields: Vec<String>,
    pub min_rating_for_positive: i32,
    pub max_rating_for_negative: i32,
    pub include_snippets_in_injection: bool,
    pub max_snippet_length: usize,
    pub default_page_size: usize,
}

impl Default for FeedbackConfig {
    fn default() -> Self {
        Self {
            index_name: "feedback".into(),
            max_positive_examples: 3,
            max_negative_examples: 3,
            similarity_fields: vec!["flowId", "stepType", "componentType", "technology"]
                .into_iter().map(String::from).collect(),
            min_rating_for_positive: 4,
            max_rating_for_negative: 2,
            include_snippets_in_injection: true,
            max_snippet_length: 500,
            default_page_size: 20,
        }
    }
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct FeedbackEntry {
    pub feedback_id: Option<String>,
    pub trace_id: String,
    pub node_id: String,
    pub flow_id: Option<String>,
    pub step_type: Option<String>,
    pub component_type: Option<String>,
    pub technology: Option<String>,
    pub rating: i32,
    pub user_comment: Option<String>,
    pub code_snippet: Option<String>,
    pub metadata: Option<Value>,
}

#[derive(Clone, Debug)]
pub struct FeedbackQuery {
    pub flow_id: Option<String>,
    pub step_type: Option<String>,
    pub component_type: Option<String>,
    pub technology: Option<String>,
    pub min_rating: Option<i32>,
    pub max_rating: Option<i32>,
}

#[derive(Clone, Debug)]
pub struct DataProcessResult<T> {
    pub success: bool,
    pub data: Option<T>,
    pub error: Option<String>,
}

impl<T> DataProcessResult<T> {
    pub fn ok(data: T) -> Self { Self { success: true, data: Some(data), error: None } }
    pub fn fail(err: String) -> Self { Self { success: false, data: None, error: Some(err) } }
}

// ---------------------------------------------------------------------------
// Feedback Injector
// ---------------------------------------------------------------------------
struct FeedbackInjector {
    cfg: FeedbackConfig,
}

impl FeedbackInjector {
    fn new(cfg: FeedbackConfig) -> Self { Self { cfg } }

    fn build_injection(&self, feedback_list: &[Value]) -> String {
        if feedback_list.is_empty() { return String::new(); }

        let mut positive: Vec<&Value> = feedback_list.iter()
            .filter(|f| get_i64(f, "rating") >= self.cfg.min_rating_for_positive as i64)
            .collect();
        positive.sort_by(|a, b| get_i64(b, "rating").cmp(&get_i64(a, "rating")));
        positive.truncate(self.cfg.max_positive_examples);

        let mut negative: Vec<&Value> = feedback_list.iter()
            .filter(|f| get_i64(f, "rating") <= self.cfg.max_rating_for_negative as i64)
            .collect();
        negative.sort_by(|a, b| get_i64(a, "rating").cmp(&get_i64(b, "rating")));
        negative.truncate(self.cfg.max_negative_examples);

        if positive.is_empty() && negative.is_empty() { return String::new(); }

        let mut out = String::from("\n--- FEEDBACK FROM PREVIOUS JOBS ---\n");
        if !positive.is_empty() {
            out.push_str("\n✅ POSITIVE EXAMPLES (replicate these patterns):\n");
            for (i, f) in positive.iter().enumerate() {
                self.append_entry(&mut out, f, i + 1);
            }
        }
        if !negative.is_empty() {
            out.push_str("\n❌ NEGATIVE EXAMPLES (avoid these patterns):\n");
            for (i, f) in negative.iter().enumerate() {
                self.append_entry(&mut out, f, i + 1);
            }
        }
        out.push_str("\n--- END FEEDBACK ---\n");
        out
    }

    fn append_entry(&self, out: &mut String, f: &Value, idx: usize) {
        out.push_str(&format!("{}. Rating: {}/5", idx, get_i64(f, "rating")));
        let comment = get_str(f, "userComment");
        if !comment.is_empty() {
            out.push_str(&format!(" — {}", comment));
        }
        out.push('\n');
        if self.cfg.include_snippets_in_injection {
            let snippet = get_str(f, "codeSnippet");
            if !snippet.is_empty() {
                let trimmed = if snippet.len() > self.cfg.max_snippet_length {
                    format!("{}...", &snippet[..self.cfg.max_snippet_length])
                } else {
                    snippet.to_string()
                };
                out.push_str(&format!("   Code: {}\n", trimmed));
            }
        }
    }
}

fn get_i64(v: &Value, key: &str) -> i64 {
    v.get(key).and_then(|v| v.as_i64()).unwrap_or(0)
}

fn get_str<'a>(v: &'a Value, key: &str) -> &'a str {
    v.get(key).and_then(|v| v.as_str()).unwrap_or("")
}

// ---------------------------------------------------------------------------
// Service
// ---------------------------------------------------------------------------
pub struct FeedbackService {
    db: Box<dyn DatabaseProvider>,
    obj: Box<dyn ObjectProcessor>,
    debugger: Box<dyn NodeDebugger>,
    cfg: FeedbackConfig,
    injector: FeedbackInjector,
}

impl FeedbackService {
    pub fn new(
        db: Box<dyn DatabaseProvider>,
        obj: Box<dyn ObjectProcessor>,
        debugger: Box<dyn NodeDebugger>,
        cfg: Option<FeedbackConfig>,
    ) -> Self {
        let cfg = cfg.unwrap_or_default();
        let injector = FeedbackInjector::new(cfg.clone());
        Self { db, obj, debugger, cfg, injector }
    }

    /// Submit new feedback
    pub async fn submit(
        &self, trace_id: &str, node_id: &str, entry: &FeedbackEntry,
    ) -> DataProcessResult<Value> {
        let feedback_id = entry.feedback_id.clone()
            .unwrap_or_else(|| Uuid::new_v4().to_string());
        let sentiment = derive_sentiment(entry.rating);

        let doc = self.obj.parse_object_alternative(json!({
            "feedbackId": feedback_id,
            "traceId": trace_id,
            "nodeId": node_id,
            "flowId": entry.flow_id.as_deref().unwrap_or(""),
            "stepType": entry.step_type.as_deref().unwrap_or(""),
            "componentType": entry.component_type.as_deref().unwrap_or(""),
            "technology": entry.technology.as_deref().unwrap_or(""),
            "rating": entry.rating,
            "sentiment": sentiment,
            "userComment": entry.user_comment.as_deref().unwrap_or(""),
            "codeSnippet": entry.code_snippet.as_deref().unwrap_or(""),
            "createdAt": Utc::now().to_rfc3339(),
        }));

        match self.db.upsert(&self.cfg.index_name, &feedback_id, doc).await {
            Ok(result) => {
                let _ = self.debugger.snapshot(trace_id, node_id, "feedback-submit", json!({
                    "feedbackId": feedback_id, "rating": entry.rating, "sentiment": sentiment,
                })).await;
                DataProcessResult::ok(result)
            }
            Err(e) => DataProcessResult::fail(format!("Submit failed: {}", e)),
        }
    }

    /// Query feedback records
    pub async fn query(&self, q: &FeedbackQuery) -> DataProcessResult<Vec<Value>> {
        let mut params = HashMap::new();
        if let Some(ref v) = q.flow_id { params.insert("flowId".into(), v.clone()); }
        if let Some(ref v) = q.step_type { params.insert("stepType".into(), v.clone()); }
        if let Some(ref v) = q.component_type { params.insert("componentType".into(), v.clone()); }
        if let Some(ref v) = q.technology { params.insert("technology".into(), v.clone()); }

        let filter = self.obj.build_search_filter(&params);
        match self.db.query(&self.cfg.index_name, filter).await {
            Ok(docs) => {
                let filtered: Vec<Value> = docs.into_iter().filter(|d| {
                    let r = get_i64(d, "rating") as i32;
                    if let Some(min) = q.min_rating { if r < min { return false; } }
                    if let Some(max) = q.max_rating { if r > max { return false; } }
                    true
                }).collect();
                DataProcessResult::ok(filtered)
            }
            Err(e) => DataProcessResult::fail(format!("Query failed: {}", e)),
        }
    }

    /// Get feedback injection string for AI prompts
    pub async fn get_similar_feedback_prompt(
        &self, flow_id: Option<&str>, step_type: Option<&str>,
        component_type: Option<&str>, technology: Option<&str>,
    ) -> DataProcessResult<String> {
        let mut params = HashMap::new();
        if let Some(v) = flow_id { params.insert("flowId".into(), v.into()); }
        if let Some(v) = step_type { params.insert("stepType".into(), v.into()); }
        if let Some(v) = component_type { params.insert("componentType".into(), v.into()); }
        if let Some(v) = technology { params.insert("technology".into(), v.into()); }

        let filter = self.obj.build_search_filter(&params);
        match self.db.query(&self.cfg.index_name, filter).await {
            Ok(docs) => {
                let injection = self.injector.build_injection(&docs);
                DataProcessResult::ok(injection)
            }
            Err(_) => DataProcessResult::ok(String::new()), // graceful degradation
        }
    }

    /// Delete a feedback record
    pub async fn delete(&self, feedback_id: &str) -> DataProcessResult<bool> {
        match self.db.delete(&self.cfg.index_name, feedback_id).await {
            Ok(_) => DataProcessResult::ok(true),
            Err(e) => DataProcessResult::fail(format!("Delete failed: {}", e)),
        }
    }
}

fn derive_sentiment(rating: i32) -> &'static str {
    if rating >= 4 { "positive" }
    else if rating <= 2 { "negative" }
    else { "neutral" }
}
