# Skill 13 — Feedback Service: Implementation Prompt

## Overview
Implement a feedback collection and injection service that stores user ratings (1-5) with comments, matches similar past feedback, and injects positive/negative examples into AI prompts for continuous improvement.

## Phase 1: Models & Interfaces
1. Create `FeedbackConfig`: indexName, maxPositiveExamples (3), maxNegativeExamples (3), similarityFields, minRatingForPositive (4), maxRatingForNegative (2), includeSnippetsInInjection, maxSnippetLength (500)
2. Create `FeedbackEntry`: feedbackId, traceId, nodeId, flowId, stepType, componentType, technology, rating (1-5), sentiment (derived), userComment, codeSnippet, metadata, createdAt
3. Create `FeedbackQuery`: flowId, stepType, componentType, technology, minRating, maxRating, page, pageSize
4. All returns use `DataProcessResult<T>` (Genie DNA)

## Phase 2: FeedbackInjector (Core Value)
1. Accept list of feedback records → split into positive (rating ≥ 4) and negative (rating ≤ 2)
2. Sort positive by rating DESC, negative by rating ASC
3. Limit each to max configured examples
4. Build formatted injection string with sections:
   - `✅ POSITIVE EXAMPLES (replicate these patterns):`
   - `❌ NEGATIVE EXAMPLES (avoid these patterns):`
5. Include code snippets (trimmed to maxSnippetLength) if configured
6. Return empty string if no matching feedback

## Phase 3: CRUD Operations
1. **Submit**: Auto-generate feedbackId if missing, derive sentiment from rating, store via `parseObjectAlternative()`, debug snapshot
2. **Query**: Build filter via `buildSearchFilter()` with similarity fields, apply rating range filter, paginate
3. **Delete**: Remove by feedbackId
4. **Get Similar**: Query by similarity fields → pass to FeedbackInjector → return injection string

## Phase 4: Similarity Matching
1. Use `buildSearchFilter()` with configurable similarity fields (flowId, stepType, componentType, technology)
2. Empty fields automatically skipped (Genie DNA-2)
3. Most recent feedback prioritized
4. Graceful degradation: return empty string on any failure

## Phase 5: Integration
1. Wire into DI container with DatabaseProvider, ObjectProcessor, NodeDebugger
2. AI Transform (Skill 11) calls `getSimilarFeedbackPrompt()` during prompt assembly
3. API Gateway (Skill 15) exposes submit/query endpoints
4. Debug snapshots at submit with feedbackId, rating, sentiment

### Test Scenarios
| # | Scenario | Expected |
|---|----------|----------|
| 1 | Submit rating 5 with comment | Stored as positive sentiment |
| 2 | Submit rating 1 with snippet | Stored as negative, snippet preserved |
| 3 | Query by flowId + technology | Matching records returned |
| 4 | Get similar with mixed ratings | Injection has positive + negative sections |
| 5 | Get similar with no matches | Empty string returned |
| 6 | Delete existing feedback | Record removed |
| 7 | Rating 3 (neutral) | Excluded from both positive and negative injection |

## Genie DNA Checklist
- [ ] All documents via `ObjectProcessor.parseObjectAlternative()` — no fixed schemas
- [ ] Queries via `buildSearchFilter()` with automatic empty-field skipping
- [ ] All returns wrapped in `DataProcessResult<T>`
- [ ] Database via `IDatabaseProvider` interface (swappable)
- [ ] Graceful degradation on all external calls

## Dependencies
- **Skill 01** (Core Interfaces) — base types
- **Skill 02** (Object Processor) — dynamic document handling
- **Skill 05** (Database Fabric) — storage backend
- **Skill 11** (AI Transform) — consumes injection strings
- **Skill 14** (Node Debugger) — debug snapshots
