# Skill 36: Advanced Logging — Implementation Prompt

## Phase 1: Structured Logger
JSON log entries with traceId correlation. Dynamic fields per service.

## Phase 2: UI Error Capture
Client-side error capture as dynamic documents. Browser/device context.

## Phase 3: Cross-Service Correlation
TraceId flows through all services. Single search returns full request journey.

## Phase 4: AI Analysis
Pattern detection on log data. Anomaly alerting.

---

## Genie DNA Compliance — MANDATORY
☐ DNA-1: Dynamic Documents — Dictionary<string, object>, NOT typed models
☐ DNA-2: BuildSearchFilter — skip empty fields, no entity-specific query code
☐ DNA-3: MicroserviceBase — inherit DB, queue, cache, logger
☐ DNA-5: DataProcessResult<T> — all methods return result wrapper
☐ DNA-6: Generic Interfaces — swap via config
☐ DNA-SCOPE: Non-admin queries auto-inject userId filter
