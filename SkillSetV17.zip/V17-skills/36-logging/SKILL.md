---
skill_id: "36"
name: logging
title: "Advanced Logging & Exception Middleware"
layer: "L8: Quality Assurance"
version: "17.1"
status: "active"
priority: "P0"
dependencies: ["01-core-interfaces", "03-elasticsearch-datastore", "22-logger-service"]
alternatives_server: [serilog, winston, log4j2, tracing-rs, monolog]
genie_dna:
  - "DNA-LOG: Structured logging with trace correlation across microservices"
  - "DNA-6: Log format is generic — works across all server alternatives"
  - "DNA-RESULT: Exception middleware wraps all errors in DataProcessResult"
triggers: logging, logs, exception middleware, error handling, structured logging, trace correlation, log aggregation, UI logging
estimated_loc: 600
---

# Skill 36: Advanced Logging & Exception Middleware
## Structured Logging with Trace Correlation and UI Error Capture

**Classification:** MACHINE/HUMAN — Log configs are static, analysis is human/AI  
**Priority:** P0 — Critical for debugging and production monitoring  
**Dependencies:** Skill 01 (Core), Skill 03 (Elasticsearch), Skill 22 (Logger Service)  
**Layer:** L8: Quality Assurance  
**Estimated LOC:** ~600  

---

## Overview

Advanced Logging provides structured, trace-correlated logging across all XIIGen microservices and the client UI. The exception middleware catches all unhandled errors and wraps them in DataProcessResult with full context (trace ID, user ID, request path, stack trace). Logs flow to Elasticsearch for querying, Kibana dashboards, and AI-assisted root cause analysis. UI-side logging captures client errors, performance metrics, and user actions for full-stack debugging.

## Key Concepts

- **Trace Correlation** — Every request carries a traceId that propagates across all microservices. Query all logs for a single user action across 10+ services with one filter.
- **Exception Middleware** — ASP.NET middleware that catches exceptions, creates structured log entries, and returns DataProcessResult error responses — never exposes raw stack traces to clients.
- **UI Logging** — Client-side error boundary captures React Native crashes, API call failures, and performance metrics — sends to same Elasticsearch index with trace correlation.
- **Log Levels with Context** — Beyond standard levels (Debug/Info/Warn/Error/Fatal), logs include: service name, operation name, duration, input size, output size, user context.
- **AI Log Analysis** — Logs are available to RAG (Skill 00a) for AI-assisted debugging: "Why did trace X fail?" → AI searches logs, identifies root cause.

---

## DNA Integration

### Required Patterns
- **DataProcessResult** — Exception middleware always returns DataProcessResult with error details. Never raw 500 responses.
- **Dynamic Document** — Log entries are dynamic documents with flexible fields per service. No fixed schema across services.
- **BuildSearchFilter** — Query logs by traceId, service, level, dateRange, userId — empty fields skipped.
- **Scope Isolation** — Each microservice logs to its own index prefix. Cross-service queries use trace ID only.

### Anti-Patterns to AVOID
- ❌ Logging sensitive data (passwords, tokens, PII) — sanitize before logging
- ❌ Swallowing exceptions without logging — always log, then wrap in DataProcessResult
- ❌ Console.WriteLine for logging — use structured ILogger with Elasticsearch sink
- ❌ Missing trace IDs on any request — middleware must ensure propagation

---

## Primary Implementation (.NET 9)

### Exception Middleware

```csharp
namespace XIIGen.Logging.Middleware;

public class ExceptionMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<ExceptionMiddleware> _logger;

    public async Task InvokeAsync(HttpContext context)
    {
        try { await _next(context); }
        catch (Exception ex)
        {
            var traceId = context.Request.Headers["X-Trace-Id"].FirstOrDefault() ?? Guid.NewGuid().ToString();
            _logger.LogError(ex, "Unhandled exception | TraceId={TraceId} Path={Path} User={User}",
                traceId, context.Request.Path, context.User?.Identity?.Name);

            context.Response.StatusCode = 500;
            context.Response.ContentType = "application/json";
            await context.Response.WriteAsJsonAsync(DataProcessResult<object>.Fail(
                $"Internal error. TraceId: {traceId}. Contact support with this ID."));
        }
    }
}
```

### Structured Log Entry Model

```csharp
public record StructuredLogEntry(
    string Id, string TraceId, string ServiceName,
    string OperationName, string Level,
    string Message, Dictionary<string, object> Context,
    string ExceptionType, string StackTrace,
    TimeSpan Duration, DateTime Timestamp
);
```

### Service Interface

```csharp
public interface IAdvancedLogger
{
    Task LogStructuredAsync(StructuredLogEntry entry, CancellationToken ct = default);
    Task<DataProcessResult<List<StructuredLogEntry>>> QueryLogsAsync(Dictionary<string, object> filters, CancellationToken ct = default);
    Task<DataProcessResult<TraceTimeline>> GetTraceTimelineAsync(string traceId, CancellationToken ct = default);
    Task LogUiEventAsync(UiLogEntry entry, CancellationToken ct = default);
}
```

### DI Registration

```csharp
app.UseMiddleware<ExceptionMiddleware>();
services.AddScoped<IAdvancedLogger, ElasticsearchAdvancedLogger>();
services.AddSingleton<ILogSanitizer, PiiLogSanitizer>();
```

---

## Test Scenarios

1. Throw unhandled exception → verify DataProcessResult returned with traceId, no stack trace exposed
2. Make request across 3 services → verify all logs share same traceId
3. Query logs by traceId → verify timeline shows all 3 services in order
4. Log entry with PII → verify sanitizer removes sensitive fields
5. UI error boundary fires → verify client log entry arrives in Elasticsearch
6. BuildSearchFilter with empty dateRange → verify filter skips it
7. AI queries "why did trace X fail" → verify relevant logs returned for RAG

## Component Classification
- **Category:** Observability & Error Handling
- **Inputs:** HTTP requests, exceptions, UI events, performance metrics
- **Outputs:** Structured log entries, trace timelines, error responses
- **Side Effects:** Writes to Elasticsearch log indexes, sanitizes PII
- **ES Indexes:** `logs-{service}`, `logs-ui`, `traces`
