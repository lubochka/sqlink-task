/**
 * XIIGen Skill 36: Advanced Logging & Exception Middleware — Node.js Alternative
 * Structured logging with trace correlation and UI error capture
 * DNA: DataProcessResult, dynamic documents, BuildSearchFilter, scope isolation
 */
import { DataProcessResult, IDatabaseService } from '../../01-core-interfaces/alternatives/nodejs/core-interfaces';
import * as winston from 'winston';

interface LogEntry {
  level: 'debug' | 'info' | 'warn' | 'error' | 'fatal';
  message: string; traceId: string; serviceName: string;
  scopeId: string; timestamp: string; metadata?: Record<string, any>;
  stackTrace?: string; duration?: number; userId?: string;
}

interface LogQueryFilter {
  traceId?: string; serviceName?: string; level?: string;
  scopeId?: string; userId?: string;
  from?: string; to?: string;
}

export class LoggingService {
  private readonly INDEX = 'service-logs';
  private logger: winston.Logger;

  constructor(private db: IDatabaseService, serviceName: string) {
    this.logger = winston.createLogger({
      level: 'debug',
      format: winston.format.combine(
        winston.format.timestamp(), winston.format.json(),
        winston.format.printf(({ timestamp, level, message, ...meta }) =>
          JSON.stringify({ timestamp, level, message, service: serviceName, ...meta }))
      ),
      transports: [
        new winston.transports.Console(),
        new winston.transports.File({ filename: 'error.log', level: 'error' }),
      ]
    });
  }

  /** Log with trace correlation. DNA: dynamic document storage. */
  async log(entry: LogEntry): Promise<DataProcessResult<void>> {
    try {
      this.logger.log(entry.level, entry.message, {
        traceId: entry.traceId, service: entry.serviceName, scope: entry.scopeId
      });
      await this.db.upsert(this.INDEX, {
        id: `${entry.traceId}-${Date.now()}`, ...entry,
        timestamp: entry.timestamp || new Date().toISOString()
      });
      return { success: true, data: undefined, message: 'Logged' };
    } catch (error: any) {
      return { success: false, data: undefined, message: error.message };
    }
  }

  /** Query logs. DNA: BuildSearchFilter — skip empty values. */
  async queryLogs(filter: LogQueryFilter): Promise<DataProcessResult<LogEntry[]>> {
    try {
      const clean = Object.entries(filter)
        .filter(([_, v]) => v !== null && v !== undefined && v !== '')
        .reduce((acc, [k, v]) => ({ ...acc, [k]: v }), {} as Record<string, any>);
      const results = await this.db.query(this.INDEX, clean);
      return { success: true, data: results as LogEntry[], message: `Found ${results.length} logs` };
    } catch (error: any) {
      return { success: false, data: [], message: error.message };
    }
  }

  /** Exception middleware for Express. DNA: wraps errors in DataProcessResult. */
  createExceptionMiddleware() {
    return (err: any, req: any, res: any, next: any) => {
      const traceId = req.headers['x-trace-id'] || `trace-${Date.now()}`;
      this.log({
        level: 'error', message: err.message, traceId, serviceName: 'api',
        scopeId: req.headers['x-scope-id'] || '', timestamp: new Date().toISOString(),
        stackTrace: err.stack, metadata: { url: req.url, method: req.method, body: req.body }
      });
      res.status(err.status || 500).json({
        success: false, data: null, message: err.message, traceId
      });
    };
  }

  /** Request logging middleware with duration tracking. */
  createRequestMiddleware() {
    return (req: any, res: any, next: any) => {
      const start = Date.now();
      const traceId = req.headers['x-trace-id'] || `trace-${Date.now()}`;
      req.traceId = traceId;
      res.on('finish', () => {
        this.log({
          level: res.statusCode >= 400 ? 'warn' : 'info',
          message: `${req.method} ${req.url} ${res.statusCode}`,
          traceId, serviceName: 'api', scopeId: req.headers['x-scope-id'] || '',
          timestamp: new Date().toISOString(),
          duration: Date.now() - start,
          metadata: { statusCode: res.statusCode, userAgent: req.headers['user-agent'] }
        });
      });
      next();
    };
  }

  /** Aggregate log stats by level or service. */
  async getLogStats(scopeId: string, groupBy: 'level' | 'serviceName'): Promise<DataProcessResult<Record<string, number>>> {
    try {
      const logs = await this.db.query(this.INDEX, { scopeId });
      const stats: Record<string, number> = {};
      for (const log of logs) {
        const key = (log as any)[groupBy] || 'unknown';
        stats[key] = (stats[key] || 0) + 1;
      }
      return { success: true, data: stats, message: `Stats by ${groupBy}` };
    } catch (error: any) {
      return { success: false, data: {}, message: error.message };
    }
  }
}
