<?php
/**
 * XIIGen Skill 36: Advanced Logging — PHP Alternative
 * DNA: DataProcessResult, dynamic documents, BuildSearchFilter, scope isolation
 */
namespace XIIGen\Logging;

class DataProcessResult {
    public function __construct(public readonly bool $success, public readonly mixed $data, public readonly string $message) {}
    public static function ok(mixed $data, string $msg): self { return new self(true, $data, $msg); }
    public static function error(string $msg): self { return new self(false, null, $msg); }
}

class LoggingService {
    private const INDEX = 'service-logs';

    public function __construct(
        private readonly object $db,
        private readonly string $serviceName
    ) {}

    /** Log with trace correlation. DNA: dynamic document storage. */
    public function log(array $entry): DataProcessResult {
        try {
            $level = $entry['level'] ?? 'info';
            $message = $entry['message'] ?? '';
            $traceId = $entry['traceId'] ?? '';
            error_log("[{$level}] [{$traceId}] [{$this->serviceName}] {$message}");

            $doc = array_merge($entry, [
                'id' => "{$traceId}-" . intval(microtime(true) * 1000),
                'timestamp' => $entry['timestamp'] ?? date('c'),
                'serviceName' => $entry['serviceName'] ?? $this->serviceName,
            ]);
            $this->db->upsert(self::INDEX, $doc);
            return DataProcessResult::ok(null, 'Logged');
        } catch (\Throwable $e) {
            return DataProcessResult::error($e->getMessage());
        }
    }

    /** Query logs. DNA: BuildSearchFilter — skip empty. */
    public function queryLogs(array $filters): DataProcessResult {
        try {
            $clean = array_filter($filters, fn($v) => $v !== null && $v !== '');
            $results = $this->db->query(self::INDEX, $clean);
            return DataProcessResult::ok($results, 'Found ' . count($results) . ' logs');
        } catch (\Throwable $e) {
            return DataProcessResult::error($e->getMessage());
        }
    }

    /** Exception middleware for Laravel/Slim. DNA: wraps errors in DataProcessResult. */
    public function exceptionHandler(\Throwable $e, ?string $traceId = null): array {
        $traceId = $traceId ?: 'trace-' . intval(microtime(true) * 1000);
        $this->log([
            'level' => 'error', 'message' => $e->getMessage(), 'traceId' => $traceId,
            'serviceName' => 'api', 'scopeId' => '',
            'stackTrace' => $e->getTraceAsString(),
        ]);
        return ['success' => false, 'data' => null, 'message' => $e->getMessage(), 'traceId' => $traceId];
    }

    /** Aggregate log stats. */
    public function getLogStats(string $scopeId, string $groupBy = 'level'): DataProcessResult {
        try {
            $logs = $this->db->query(self::INDEX, ['scopeId' => $scopeId]);
            $stats = [];
            foreach ($logs as $log) {
                $key = $log[$groupBy] ?? 'unknown';
                $stats[$key] = ($stats[$key] ?? 0) + 1;
            }
            return DataProcessResult::ok($stats, "Stats by {$groupBy}");
        } catch (\Throwable $e) {
            return DataProcessResult::error($e->getMessage());
        }
    }
}
