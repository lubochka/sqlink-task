/**
 * XIIGen Skill 36: Advanced Logging — Java Alternative
 * DNA: DataProcessResult, dynamic documents, BuildSearchFilter, scope isolation
 */
package com.xiigen.logging;

import org.slf4j.Logger; import org.slf4j.LoggerFactory;
import java.time.Instant; import java.util.*;
import java.util.stream.Collectors;

public class LoggingService {
    private static final String INDEX = "service-logs";
    private final IDatabaseService db;
    private final Logger logger;
    private final String serviceName;

    public LoggingService(IDatabaseService db, String serviceName) {
        this.db = db; this.serviceName = serviceName;
        this.logger = LoggerFactory.getLogger(serviceName);
    }

    /** Log with trace correlation. DNA: dynamic document storage. */
    public DataProcessResult<Void> log(Map<String, Object> entry) {
        try {
            String level = (String) entry.getOrDefault("level", "info");
            String msg = (String) entry.getOrDefault("message", "");
            String traceId = (String) entry.getOrDefault("traceId", "");
            switch (level) {
                case "error" -> logger.error("[{}] {}", traceId, msg);
                case "warn"  -> logger.warn("[{}] {}", traceId, msg);
                case "debug" -> logger.debug("[{}] {}", traceId, msg);
                default      -> logger.info("[{}] {}", traceId, msg);
            }
            Map<String, Object> doc = new HashMap<>(entry);
            doc.put("id", traceId + "-" + System.currentTimeMillis());
            doc.putIfAbsent("timestamp", Instant.now().toString());
            doc.putIfAbsent("serviceName", serviceName);
            db.upsert(INDEX, doc);
            return DataProcessResult.success(null, "Logged");
        } catch (Exception e) {
            return DataProcessResult.error(e.getMessage());
        }
    }

    /** Query logs. DNA: BuildSearchFilter — skip null/empty. */
    public DataProcessResult<List<Map<String, Object>>> queryLogs(Map<String, Object> filters) {
        try {
            Map<String, Object> clean = filters.entrySet().stream()
                .filter(e -> e.getValue() != null && !"".equals(e.getValue()))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
            List<Map<String, Object>> results = db.query(INDEX, clean);
            return DataProcessResult.success(results, "Found " + results.size() + " logs");
        } catch (Exception e) { return DataProcessResult.error(e.getMessage()); }
    }

    /** Aggregate log stats by field. */
    public DataProcessResult<Map<String, Integer>> getLogStats(String scopeId, String groupBy) {
        try {
            List<Map<String, Object>> logs = db.query(INDEX, Map.of("scopeId", scopeId));
            Map<String, Integer> stats = new HashMap<>();
            for (Map<String, Object> log : logs) {
                String key = String.valueOf(log.getOrDefault(groupBy, "unknown"));
                stats.merge(key, 1, Integer::sum);
            }
            return DataProcessResult.success(stats, "Stats by " + groupBy);
        } catch (Exception e) { return DataProcessResult.error(e.getMessage()); }
    }

    // Spring Boot @ControllerAdvice exception handler pattern
    // @ExceptionHandler(Exception.class) → wraps in DataProcessResult
}
