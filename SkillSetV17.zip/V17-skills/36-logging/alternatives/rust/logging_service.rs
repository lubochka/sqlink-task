// XIIGen Skill 36: Advanced Logging — Rust Alternative
// DNA: DataProcessResult, dynamic documents, BuildSearchFilter, scope isolation
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use chrono::Utc;
use tracing::{info, warn, error, debug};

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct DataProcessResult<T> { pub success: bool, pub data: T, pub message: String }
impl<T: Default> DataProcessResult<T> {
    pub fn ok(data: T, msg: &str) -> Self { Self { success: true, data, message: msg.into() } }
    pub fn err(msg: &str) -> Self { Self { success: false, data: T::default(), message: msg.into() } }
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct LogEntry {
    pub level: String, pub message: String, pub trace_id: String,
    pub service_name: String, pub scope_id: String,
    pub timestamp: Option<String>, pub metadata: Option<serde_json::Value>,
    pub stack_trace: Option<String>, pub duration: Option<f64>,
}

#[async_trait::async_trait]
pub trait IDatabaseService: Send + Sync {
    async fn upsert(&self, index: &str, doc: serde_json::Value) -> Result<(), Box<dyn std::error::Error>>;
    async fn query(&self, index: &str, filter: serde_json::Value) -> Result<Vec<serde_json::Value>, Box<dyn std::error::Error>>;
}

pub struct LoggingService {
    db: Box<dyn IDatabaseService>,
    service_name: String,
}

impl LoggingService {
    const INDEX: &'static str = "service-logs";
    pub fn new(db: Box<dyn IDatabaseService>, service_name: &str) -> Self {
        Self { db, service_name: service_name.to_string() }
    }

    /// Log with trace correlation. DNA: dynamic document storage.
    pub async fn log(&self, entry: &LogEntry) -> DataProcessResult<()> {
        match entry.level.as_str() {
            "error" => error!(trace_id=%entry.trace_id, "{}", entry.message),
            "warn" => warn!(trace_id=%entry.trace_id, "{}", entry.message),
            "debug" => debug!(trace_id=%entry.trace_id, "{}", entry.message),
            _ => info!(trace_id=%entry.trace_id, "{}", entry.message),
        };
        let ts = entry.timestamp.clone().unwrap_or_else(|| Utc::now().to_rfc3339());
        match self.db.upsert(Self::INDEX, serde_json::json!({
            "id": format!("{}-{}", entry.trace_id, Utc::now().timestamp_millis()),
            "level": entry.level, "message": entry.message, "traceId": entry.trace_id,
            "serviceName": entry.service_name, "scopeId": entry.scope_id,
            "timestamp": ts, "metadata": entry.metadata, "stackTrace": entry.stack_trace,
            "duration": entry.duration,
        })).await {
            Ok(_) => DataProcessResult::ok((), "Logged"),
            Err(e) => DataProcessResult::err(&e.to_string()),
        }
    }

    /// Query logs. DNA: BuildSearchFilter.
    pub async fn query_logs(&self, filters: HashMap<String, String>) -> DataProcessResult<Vec<serde_json::Value>> {
        let clean: HashMap<&str, &str> = filters.iter()
            .filter(|(_, v)| !v.is_empty()).map(|(k, v)| (k.as_str(), v.as_str())).collect();
        match self.db.query(Self::INDEX, serde_json::to_value(&clean).unwrap_or_default()).await {
            Ok(r) => { let c = r.len(); DataProcessResult::ok(r, &format!("Found {} logs", c)) }
            Err(e) => DataProcessResult::err(&e.to_string()),
        }
    }

    /// Exception middleware for Axum. DNA: wraps errors in DataProcessResult.
    pub fn error_response(trace_id: &str, err: &dyn std::error::Error) -> serde_json::Value {
        serde_json::json!({"success": false, "data": null, "message": err.to_string(), "traceId": trace_id})
    }
}
