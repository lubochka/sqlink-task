"""
XIIGen Skill 36: Advanced Logging & Exception Middleware — Python Alternative
Structured logging with trace correlation and UI error capture
DNA: DataProcessResult, dynamic documents, BuildSearchFilter, scope isolation
"""
import logging, json, time, traceback
from dataclasses import dataclass
from typing import Any, Optional
from datetime import datetime


@dataclass
class DataProcessResult:
    success: bool; data: Any; message: str


@dataclass
class LogEntry:
    level: str; message: str; trace_id: str; service_name: str
    scope_id: str; timestamp: Optional[str] = None
    metadata: Optional[dict] = None; stack_trace: Optional[str] = None
    duration: Optional[float] = None; user_id: Optional[str] = None


class LoggingService:
    """Structured logging with trace correlation. DNA: DataProcessResult, dynamic docs, BuildSearchFilter."""
    INDEX = "service-logs"

    def __init__(self, db, service_name: str):
        self._db = db
        self._service_name = service_name
        self._logger = logging.getLogger(service_name)
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter(json.dumps({
            "time": "%(asctime)s", "level": "%(levelname)s", "service": service_name,
            "message": "%(message)s"
        })))
        self._logger.addHandler(handler)
        self._logger.setLevel(logging.DEBUG)

    async def log(self, entry: LogEntry) -> DataProcessResult:
        """Log with trace correlation. DNA: dynamic document storage."""
        try:
            getattr(self._logger, entry.level, self._logger.info)(
                entry.message, extra={"traceId": entry.trace_id, "scope": entry.scope_id})
            await self._db.upsert(self.INDEX, {
                "id": f"{entry.trace_id}-{int(time.time()*1000)}",
                "level": entry.level, "message": entry.message,
                "traceId": entry.trace_id, "serviceName": entry.service_name,
                "scopeId": entry.scope_id,
                "timestamp": entry.timestamp or datetime.utcnow().isoformat(),
                "metadata": entry.metadata, "stackTrace": entry.stack_trace,
                "duration": entry.duration, "userId": entry.user_id,
            })
            return DataProcessResult(True, None, "Logged")
        except Exception as e:
            return DataProcessResult(False, None, str(e))

    async def query_logs(self, **filters) -> DataProcessResult:
        """DNA: BuildSearchFilter — skip empty values."""
        try:
            clean = {k: v for k, v in filters.items() if v is not None and v != ""}
            results = await self._db.query(self.INDEX, clean)
            return DataProcessResult(True, results, f"Found {len(results)} logs")
        except Exception as e:
            return DataProcessResult(False, [], str(e))

    def create_exception_middleware(self):
        """ASGI/FastAPI exception handler. DNA: wraps errors in DataProcessResult."""
        from fastapi import Request
        from fastapi.responses import JSONResponse

        async def handler(request: Request, exc: Exception):
            trace_id = request.headers.get("x-trace-id", f"trace-{int(time.time()*1000)}")
            await self.log(LogEntry(
                level="error", message=str(exc), trace_id=trace_id,
                service_name="api", scope_id=request.headers.get("x-scope-id", ""),
                stack_trace=traceback.format_exc(),
                metadata={"url": str(request.url), "method": request.method}
            ))
            return JSONResponse(status_code=500, content={
                "success": False, "data": None, "message": str(exc), "traceId": trace_id
            })
        return handler

    async def get_log_stats(self, scope_id: str, group_by: str = "level") -> DataProcessResult:
        """Aggregate log stats."""
        try:
            logs = await self._db.query(self.INDEX, {"scopeId": scope_id})
            stats: dict[str, int] = {}
            for log in logs:
                key = log.get(group_by, "unknown")
                stats[key] = stats.get(key, 0) + 1
            return DataProcessResult(True, stats, f"Stats by {group_by}")
        except Exception as e:
            return DataProcessResult(False, {}, str(e))
