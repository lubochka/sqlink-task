// XIIGen.Skills.Logging/UiErrorLogger.cs | Skill 36 continued
// UI error capture endpoint + client-side logging SDK

using System.Text.Json;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using XIIGen.Core.Interfaces;

namespace XIIGen.Skills.Logging;

/// <summary>
/// Endpoint that receives UI errors from client-side JavaScript/React Native.
/// POST /api/log/ui-error
/// </summary>
public static class UiErrorEndpoints
{
    public static void MapUiErrorLogging(this WebApplication app)
    {
        app.MapPost("/api/log/ui-error", async (HttpContext ctx, IDatabaseService db, ILogger<UiErrorEndpoints> logger) =>
        {
            var body = await JsonSerializer.DeserializeAsync<UiErrorReport>(ctx.Request.Body);
            if (body == null) return Results.BadRequest("Invalid error report");

            var traceId = ctx.Request.Headers["X-Trace-Id"].FirstOrDefault() ?? Guid.NewGuid().ToString();

            logger.LogError("UI ERROR [{Level}] {Component}: {Message} | URL: {Url} | trace:{TraceId}",
                body.Level, body.Component, body.Message, body.Url, traceId);

            await db.StoreDocumentAsync("ui-logs", "xiigen", $"ui-{traceId}-{DateTime.UtcNow:HHmmssfff}", new
            {
                type = "ui-error",
                traceId,
                level = body.Level,
                component = body.Component,
                message = body.Message,
                stack = body.Stack,
                url = body.Url,
                userAgent = body.UserAgent,
                userId = body.UserId,
                sessionId = body.SessionId,
                metadata = body.Metadata,
                breadcrumbs = body.Breadcrumbs, // Last N user actions before error
                timestamp = DateTime.UtcNow
            });

            return Results.Ok(new { logged = true, traceId });
        });

        // Batch endpoint for multiple UI events
        app.MapPost("/api/log/ui-events", async (HttpContext ctx, IDatabaseService db) =>
        {
            var events = await JsonSerializer.DeserializeAsync<List<UiEvent>>(ctx.Request.Body);
            if (events == null) return Results.BadRequest();

            var docs = events.Select((e, i) => ($"evt-{DateTime.UtcNow:HHmmssfff}-{i}", (object)new
            {
                type = "ui-event",
                e.EventType, e.Component, e.Action, e.Duration,
                e.UserId, e.SessionId, e.Metadata,
                timestamp = DateTime.UtcNow
            })).ToList();

            await db.BulkUpsertAsync("ui-logs", "xiigen", docs);
            return Results.Ok(new { logged = docs.Count });
        });
    }
}

public class UiErrorReport
{
    public string Level { get; set; } = "error"; // error, warning, info
    public string Component { get; set; }
    public string Message { get; set; }
    public string Stack { get; set; }
    public string Url { get; set; }
    public string UserAgent { get; set; }
    public string UserId { get; set; }
    public string SessionId { get; set; }
    public Dictionary<string, object> Metadata { get; set; }
    public List<BreadcrumbEntry> Breadcrumbs { get; set; }
}
public class BreadcrumbEntry
{
    public string Type { get; set; } // click, navigation, api-call, console
    public string Message { get; set; }
    public string Data { get; set; }
    public DateTime Timestamp { get; set; }
}
public class UiEvent
{
    public string EventType { get; set; } // page-view, click, api-call, error
    public string Component { get; set; }
    public string Action { get; set; }
    public int? Duration { get; set; }
    public string UserId { get; set; }
    public string SessionId { get; set; }
    public Dictionary<string, object> Metadata { get; set; }
}

public class ErrorResponse
{
    public string TraceId { get; set; }
    public int Status { get; set; }
    public string Error { get; set; }
    public string Message { get; set; }
    public DateTime Timestamp { get; set; }
    public string Path { get; set; }
}

// ─── Client-Side Logger (TypeScript) ─────────────────

// xiigen-ui-logger.ts - Drop-in client logging SDK
/*
export class XIIGenLogger {
  private apiBase: string;
  private sessionId = crypto.randomUUID();
  private breadcrumbs: Array<{type: string; message: string; timestamp: string}> = [];
  private maxBreadcrumbs = 50;

  constructor(apiBase = '/api/log') {
    this.apiBase = apiBase;
    this.setupGlobalHandlers();
  }

  private setupGlobalHandlers() {
    // Catch unhandled JS errors
    window.onerror = (msg, url, line, col, error) => {
      this.logError({ component: 'global', message: String(msg), stack: error?.stack, url: String(url) });
    };

    // Catch unhandled promise rejections
    window.onunhandledrejection = (event) => {
      this.logError({ component: 'promise', message: event.reason?.message || String(event.reason), stack: event.reason?.stack });
    };

    // Track navigation
    const origPush = history.pushState;
    history.pushState = (...args) => {
      this.addBreadcrumb('navigation', `Navigate to ${args[2]}`);
      origPush.apply(history, args);
    };

    // Track clicks
    document.addEventListener('click', (e) => {
      const target = e.target as HTMLElement;
      const id = target.id || target.dataset?.testid || target.tagName;
      this.addBreadcrumb('click', `Clicked ${id}`);
    });

    // Track API calls
    const origFetch = window.fetch;
    window.fetch = async (...args) => {
      const start = Date.now();
      try {
        const resp = await origFetch(...args);
        this.addBreadcrumb('api-call', `${args[0]} => ${resp.status} (${Date.now() - start}ms)`);
        return resp;
      } catch (err) {
        this.addBreadcrumb('api-call', `${args[0]} => FAILED (${Date.now() - start}ms)`);
        throw err;
      }
    };
  }

  addBreadcrumb(type: string, message: string) {
    this.breadcrumbs.push({ type, message, timestamp: new Date().toISOString() });
    if (this.breadcrumbs.length > this.maxBreadcrumbs)
      this.breadcrumbs = this.breadcrumbs.slice(-this.maxBreadcrumbs);
  }

  async logError(data: { component: string; message: string; stack?: string; url?: string }) {
    try {
      await fetch(`${this.apiBase}/ui-error`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...data, level: 'error', sessionId: this.sessionId,
          userAgent: navigator.userAgent, url: data.url || location.href,
          breadcrumbs: [...this.breadcrumbs]
        })
      });
    } catch { /* Silent fail for logging */ }
  }

  // React Error Boundary integration
  static createErrorBoundary() {
    return class XIIGenErrorBoundary extends React.Component {
      state = { hasError: false, error: null };
      static getDerivedStateFromError(error) { return { hasError: true, error }; }
      componentDidCatch(error, info) {
        new XIIGenLogger().logError({
          component: 'ErrorBoundary', message: error.message,
          stack: error.stack + '\n\nComponent Stack:\n' + info.componentStack
        });
      }
      render() {
        if (this.state.hasError) return <div>Something went wrong. Please refresh.</div>;
        return this.props.children;
      }
    };
  }
}
*/
