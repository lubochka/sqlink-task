// XIIGen.Skills.Logging/UIErrorLogger.cs | .NET 9 | Skill 36 (continued)
// UI error capture endpoint + Elasticsearch structured logging sink

using System.Text.Json;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using XIIGen.Core.Interfaces;

namespace XIIGen.Skills.Logging;

// ═══════════════════════════════════════════════════════
// UI ERROR LOGGING ENDPOINT
// ═══════════════════════════════════════════════════════

public static class UIErrorLoggingEndpoints
{
    /// <summary>
    /// Maps endpoints for UI clients to report errors, performance, and user actions.
    /// POST /api/logs/ui-error    → JavaScript errors, React error boundaries
    /// POST /api/logs/ui-perf     → Performance metrics (LCP, FID, CLS)
    /// POST /api/logs/ui-action   → User action audit trail
    /// </summary>
    public static WebApplication MapUILoggingEndpoints(this WebApplication app)
    {
        var group = app.MapGroup("/api/logs").WithTags("UI Logging");

        group.MapPost("/ui-error", async (UIErrorLog error, IDatabaseService db, ILogger<UIErrorLog> logger) =>
        {
            logger.LogError("UI ERROR [{Component}]: {Message} at {Url}\n{Stack}",
                error.Component, error.Message, error.Url, error.StackTrace);

            var id = $"ui-err-{DateTime.UtcNow:yyyyMMdd-HHmmssfff}";
            await db.StoreDocumentAsync("ui-logs", "xiigen", id, new
            {
                type = "ui-error",
                error.Message, error.StackTrace, error.Component,
                error.Url, error.UserAgent, error.UserId,
                error.SessionId, error.ViewportWidth, error.ViewportHeight,
                error.BrowserInfo, error.ReactErrorBoundary,
                level = "Error",
                timestamp = DateTime.UtcNow
            });

            return Results.Ok(new { id, logged = true });
        });

        group.MapPost("/ui-perf", async (UIPerformanceLog perf, IDatabaseService db) =>
        {
            var id = $"ui-perf-{DateTime.UtcNow:yyyyMMdd-HHmmssfff}";
            await db.StoreDocumentAsync("ui-logs", "xiigen", id, new
            {
                type = "ui-performance",
                perf.Url, perf.PageName,
                perf.LargestContentfulPaint, perf.FirstInputDelay,
                perf.CumulativeLayoutShift, perf.TimeToFirstByte,
                perf.DomContentLoaded, perf.FullPageLoad,
                perf.JsBundleSize, perf.ApiCallCount, perf.ApiTotalMs,
                perf.MemoryUsageMb, perf.SessionId, perf.UserId,
                level = "Information",
                timestamp = DateTime.UtcNow
            });

            return Results.Ok(new { id, logged = true });
        });

        group.MapPost("/ui-action", async (UIActionLog action, IDatabaseService db) =>
        {
            var id = $"ui-act-{DateTime.UtcNow:yyyyMMdd-HHmmssfff}";
            await db.StoreDocumentAsync("ui-logs", "xiigen", id, new
            {
                type = "ui-action",
                action.Action, action.Component, action.Details,
                action.SessionId, action.UserId, action.Url,
                level = "Information",
                timestamp = DateTime.UtcNow
            });

            return Results.Ok(new { id });
        });

        // Log search endpoint
        group.MapGet("/search", async (string index, string level, string traceId,
            int? limit, IDatabaseService db) =>
        {
            var conditions = new List<SearchCondition>();
            if (!string.IsNullOrEmpty(level))
                conditions.Add(new() { Property = "level", Value = level, QueryType = QueryType.Equal });
            if (!string.IsNullOrEmpty(traceId))
                conditions.Add(new() { Property = "traceId", Value = traceId, QueryType = QueryType.Equal });

            var results = await db.SearchDocumentsAsync<object>(
                index ?? "service-logs", "xiigen",
                new SearchOptions { Conditions = conditions, Size = limit ?? 50, SortField = "timestamp", SortDescending = true });

            return Results.Ok(results.Data);
        });

        return app;
    }
}

// ═══════════════════════════════════════════════════════
// UI CLIENT-SIDE LOGGING (TypeScript / React)
// ═══════════════════════════════════════════════════════
// Include this in your React app's error boundary and global error handler:
//
// ```typescript
// // hooks/useLogger.ts
// const API = process.env.REACT_APP_API_URL;
//
// export const logUIError = async (error: Error, component?: string) => {
//   await fetch(`${API}/api/logs/ui-error`, {
//     method: 'POST',
//     headers: { 'Content-Type': 'application/json' },
//     body: JSON.stringify({
//       message: error.message,
//       stackTrace: error.stack,
//       component: component || 'unknown',
//       url: window.location.href,
//       userAgent: navigator.userAgent,
//       sessionId: sessionStorage.getItem('sessionId'),
//       viewportWidth: window.innerWidth,
//       viewportHeight: window.innerHeight,
//       browserInfo: { language: navigator.language, platform: navigator.platform },
//     }),
//   }).catch(() => {}); // Never let logging break the app
// };
//
// // ErrorBoundary.tsx
// class ErrorBoundary extends React.Component {
//   componentDidCatch(error, errorInfo) {
//     logUIError(error, errorInfo.componentStack);
//   }
// }
//
// // Global handlers
// window.onerror = (msg, src, line, col, error) => logUIError(error || new Error(msg));
// window.onunhandledrejection = (event) => logUIError(new Error(event.reason));
// ```

// ═══════════════════════════════════════════════════════
// ELASTICSEARCH STRUCTURED LOGGING SINK
// ═══════════════════════════════════════════════════════

public class ElasticsearchLoggerProvider : ILoggerProvider
{
    private readonly IDatabaseService _db;
    private readonly string _serviceName;
    private readonly LogLevel _minLevel;

    public ElasticsearchLoggerProvider(IDatabaseService db, string serviceName, LogLevel minLevel = LogLevel.Information)
    {
        _db = db; _serviceName = serviceName; _minLevel = minLevel;
    }

    public ILogger CreateLogger(string categoryName) => new ElasticsearchLogger(_db, _serviceName, categoryName, _minLevel);
    public void Dispose() { }
}

public class ElasticsearchLogger : ILogger
{
    private readonly IDatabaseService _db;
    private readonly string _service;
    private readonly string _category;
    private readonly LogLevel _minLevel;

    public ElasticsearchLogger(IDatabaseService db, string service, string category, LogLevel minLevel)
    {
        _db = db; _service = service; _category = category; _minLevel = minLevel;
    }

    public bool IsEnabled(LogLevel level) => level >= _minLevel;

    public void Log<TState>(LogLevel level, EventId eventId, TState state, Exception exception, Func<TState, Exception, string> formatter)
    {
        if (!IsEnabled(level)) return;

        var traceId = Activity.Current?.Id ?? "none";
        var id = $"log-{DateTime.UtcNow:yyyyMMddHHmmssfff}-{Random.Shared.Next(1000):D3}";

        // Fire-and-forget to ES (don't block the caller)
        _ = Task.Run(async () =>
        {
            try
            {
                await _db.StoreDocumentAsync("service-logs", "xiigen", id, new
                {
                    service = _service,
                    category = _category,
                    level = level.ToString(),
                    message = formatter(state, exception),
                    traceId,
                    eventId = eventId.Id,
                    eventName = eventId.Name,
                    exceptionType = exception?.GetType().FullName,
                    exceptionMessage = exception?.Message,
                    exceptionStack = exception?.StackTrace,
                    machineName = Environment.MachineName,
                    threadId = Environment.CurrentManagedThreadId,
                    timestamp = DateTime.UtcNow
                });
            }
            catch { /* Swallow logging failures */ }
        });
    }

    public IDisposable BeginScope<TState>(TState state) where TState : notnull => NullScope.Instance;
    private class NullScope : IDisposable { public static NullScope Instance = new(); public void Dispose() { } }
}

// ═══════════════════════════════════════════════════════
// DI REGISTRATION
// ═══════════════════════════════════════════════════════

public static class LoggingServiceExtensions
{
    public static IServiceCollection AddXIIGenLogging(this IServiceCollection services, string serviceName)
    {
        services.AddSingleton<ILoggerProvider>(sp =>
            new ElasticsearchLoggerProvider(sp.GetRequiredService<IDatabaseService>(), serviceName, LogLevel.Information));
        return services;
    }

    public static WebApplication UseXIIGenExceptionHandling(this WebApplication app)
    {
        app.UseMiddleware<GlobalExceptionMiddleware>();
        return app;
    }
}

// ─── Models ──────────────────────────────────────────────
public class UIErrorLog
{
    public string Message { get; set; }
    public string StackTrace { get; set; }
    public string Component { get; set; }
    public string Url { get; set; }
    public string UserAgent { get; set; }
    public string UserId { get; set; }
    public string SessionId { get; set; }
    public int ViewportWidth { get; set; }
    public int ViewportHeight { get; set; }
    public Dictionary<string, string> BrowserInfo { get; set; } = [];
    public bool ReactErrorBoundary { get; set; }
}

public class UIPerformanceLog
{
    public string Url { get; set; }
    public string PageName { get; set; }
    public double LargestContentfulPaint { get; set; }
    public double FirstInputDelay { get; set; }
    public double CumulativeLayoutShift { get; set; }
    public double TimeToFirstByte { get; set; }
    public double DomContentLoaded { get; set; }
    public double FullPageLoad { get; set; }
    public long JsBundleSize { get; set; }
    public int ApiCallCount { get; set; }
    public double ApiTotalMs { get; set; }
    public double MemoryUsageMb { get; set; }
    public string SessionId { get; set; }
    public string UserId { get; set; }
}

public class UIActionLog
{
    public string Action { get; set; }
    public string Component { get; set; }
    public Dictionary<string, object> Details { get; set; } = [];
    public string SessionId { get; set; }
    public string UserId { get; set; }
    public string Url { get; set; }
}

public class ErrorResponse
{
    public string TraceId { get; set; }
    public int Status { get; set; }
    public string Error { get; set; }
    public string Message { get; set; }
    public DateTime Timestamp { get; set; }
    public string Path { get; set; }
}

public class SearchCondition { public string Property { get; set; } public object Value { get; set; } public QueryType QueryType { get; set; } }
public class SearchOptions { public List<SearchCondition> Conditions { get; set; } = []; public int Size { get; set; } = 10; public string SortField { get; set; } public bool SortDescending { get; set; } }
public enum QueryType { Equal, Contains, GreaterThan, LessThan, Range }
