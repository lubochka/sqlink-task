// XIIGen.Services.Connections/ConnectionService.cs — Skill 49 | .NET 9
// Social graph: friend requests, connections, blocking, strength calc, graph traversal
// Genie DNA: DNA-1 (Dictionary<string,object>), DNA-2 (BuildSearchFilter), DNA-5 (DataProcessResult)

using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System.Text.Json;
using XIIGen.Core.Base;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Services.Connections;

// ─── Configuration ──────────────────────────────────────────────
public class ConnectionConfig
{
    public string ConnectionsIndex { get; set; } = "connections";
    public string RequestsIndex { get; set; } = "connection-requests";
    public string BlockedIndex { get; set; } = "blocked-users";
    public string ConfigIndex { get; set; } = "connection-config";
    public int DefaultPageSize { get; set; } = 20;
    public int RequestExpirationDays { get; set; } = 30;
    public int MaxTraversalDepth { get; set; } = 3;
    public int SuggestionLimit { get; set; } = 50;
    public double AutoAcceptMinMatchScore { get; set; } = 0.8;
}

// ─── Connection Page ────────────────────────────────────────────
public class ConnectionPage
{
    public List<Dictionary<string, object>> Items { get; set; } = [];
    public string? Cursor { get; set; }
    public int TotalCount { get; set; }
    public bool HasMore { get; set; }
}

// ─── Strength Factor Weights (FREEDOM — admin-configurable) ────
public static class DefaultStrengthWeights
{
    public const double MatchScore = 0.30;
    public const double SharedGroups = 0.20;
    public const double CoAttendedEvents = 0.20;
    public const double MessageFrequency = 0.15;
    public const double ProfileSimilarity = 0.15;
}

// ─── Request State Machine (MACHINE) ───────────────────────────
public static class RequestStatus
{
    public const string Pending = "pending";
    public const string Accepted = "accepted";
    public const string Rejected = "rejected";
    public const string Expired = "expired";
    public const string Cancelled = "cancelled";

    public static bool CanTransition(string from, string to)
    {
        return (from, to) switch
        {
            (Pending, Accepted) => true,
            (Pending, Rejected) => true,
            (Pending, Cancelled) => true,
            (Pending, Expired) => true,
            _ => false
        };
    }
}

// ─── Strength Calculator (MACHINE logic, FREEDOM weights) ──────
public class ConnectionStrengthCalculator
{
    public double Calculate(Dictionary<string, object> factors, Dictionary<string, object> weights)
    {
        double total = 0.0;
        double weightSum = 0.0;

        var factorDefs = new[]
        {
            ("matchScore", DefaultStrengthWeights.MatchScore),
            ("sharedGroups", DefaultStrengthWeights.SharedGroups),
            ("coAttendedEvents", DefaultStrengthWeights.CoAttendedEvents),
            ("messageFrequency", DefaultStrengthWeights.MessageFrequency),
            ("profileSimilarity", DefaultStrengthWeights.ProfileSimilarity)
        };

        foreach (var (key, defaultWeight) in factorDefs)
        {
            var factorValue = GetDouble(factors, key, 0.0);
            var weight = GetDouble(weights, $"{key}Weight", defaultWeight);
            total += NormalizeFactor(key, factorValue) * weight;
            weightSum += weight;
        }

        return weightSum > 0 ? Math.Clamp(total / weightSum, 0.0, 1.0) : 0.0;
    }

    private static double NormalizeFactor(string key, double raw)
    {
        return key switch
        {
            "matchScore" => Math.Clamp(raw, 0.0, 1.0),
            "sharedGroups" => Math.Min(raw / 10.0, 1.0),        // 10+ groups = max
            "coAttendedEvents" => Math.Min(raw / 5.0, 1.0),     // 5+ events = max
            "messageFrequency" => Math.Clamp(raw, 0.0, 1.0),    // already normalized
            "profileSimilarity" => Math.Clamp(raw, 0.0, 1.0),   // already normalized
            _ => Math.Clamp(raw, 0.0, 1.0)
        };
    }

    private static double GetDouble(Dictionary<string, object> doc, string key, double fallback)
    {
        if (doc.TryGetValue(key, out var val))
        {
            if (val is double d) return d;
            if (val is int i) return i;
            if (val is long l) return l;
            if (val is float f) return f;
            if (val is JsonElement je && je.TryGetDouble(out var jd)) return jd;
            if (double.TryParse(val?.ToString(), out var parsed)) return parsed;
        }
        return fallback;
    }
}

// ─── Graph Traversal Engine (MACHINE) ──────────────────────────
public class GraphTraversal
{
    private readonly IDatabaseService _db;
    private readonly string _connectionsIndex;
    private readonly ILogger _logger;

    public GraphTraversal(IDatabaseService db, string connectionsIndex, ILogger logger)
    {
        _db = db;
        _connectionsIndex = connectionsIndex;
        _logger = logger;
    }

    /// <summary>
    /// BFS traversal to find connections at a given depth.
    /// Depth 1 = direct connections, Depth 2 = friend-of-friend, etc.
    /// </summary>
    public async Task<List<string>> GetUserIdsAtDepthAsync(
        string userId, int depth, int maxResults, CancellationToken ct = default)
    {
        if (depth < 1) return [];

        var visited = new HashSet<string> { userId };
        var currentLevel = new HashSet<string> { userId };
        var results = new List<string>();

        for (int d = 0; d < depth; d++)
        {
            var nextLevel = new HashSet<string>();

            foreach (var uid in currentLevel)
            {
                if (ct.IsCancellationRequested) break;

                var filter = BuildConnectionFilter(uid, "accepted");
                var connections = await _db.QueryAsync(_connectionsIndex, filter, ct);

                foreach (var conn in connections)
                {
                    var peerId = GetPeerId(conn, uid);
                    if (peerId != null && visited.Add(peerId))
                    {
                        nextLevel.Add(peerId);
                        if (d == depth - 1) // Only collect at target depth
                        {
                            results.Add(peerId);
                            if (results.Count >= maxResults) return results;
                        }
                    }
                }
            }

            currentLevel = nextLevel;
            if (currentLevel.Count == 0) break;
        }

        return results;
    }

    /// <summary>
    /// Find mutual connections between two users (intersection of direct connections).
    /// </summary>
    public async Task<List<Dictionary<string, object>>> GetMutualConnectionsAsync(
        string userA, string userB, CancellationToken ct = default)
    {
        var filterA = BuildConnectionFilter(userA, "accepted");
        var filterB = BuildConnectionFilter(userB, "accepted");

        var connectionsA = await _db.QueryAsync(_connectionsIndex, filterA, ct);
        var connectionsB = await _db.QueryAsync(_connectionsIndex, filterB, ct);

        var peersA = connectionsA.Select(c => GetPeerId(c, userA)).Where(p => p != null).ToHashSet();
        var peersB = connectionsB.Select(c => GetPeerId(c, userB)).Where(p => p != null).ToHashSet();

        var mutualIds = peersA.Intersect(peersB);

        return connectionsA
            .Where(c => mutualIds.Contains(GetPeerId(c, userA)))
            .ToList();
    }

    /// <summary>
    /// BFS shortest path between two users. Returns -1 if not connected within maxDepth.
    /// </summary>
    public async Task<int> GetShortestPathAsync(
        string fromUser, string toUser, int maxDepth, CancellationToken ct = default)
    {
        if (fromUser == toUser) return 0;

        var visited = new HashSet<string> { fromUser };
        var currentLevel = new HashSet<string> { fromUser };

        for (int depth = 1; depth <= maxDepth; depth++)
        {
            var nextLevel = new HashSet<string>();

            foreach (var uid in currentLevel)
            {
                if (ct.IsCancellationRequested) return -1;

                var filter = BuildConnectionFilter(uid, "accepted");
                var connections = await _db.QueryAsync(_connectionsIndex, filter, ct);

                foreach (var conn in connections)
                {
                    var peerId = GetPeerId(conn, uid);
                    if (peerId == toUser) return depth;
                    if (peerId != null && visited.Add(peerId))
                        nextLevel.Add(peerId);
                }
            }

            currentLevel = nextLevel;
            if (currentLevel.Count == 0) break;
        }

        return -1; // Not connected within maxDepth
    }

    private static Dictionary<string, object> BuildConnectionFilter(string userId, string status)
    {
        // DNA-2: BuildSearchFilter — only include non-empty values
        var filter = new Dictionary<string, object>();
        if (!string.IsNullOrEmpty(userId))
            filter["_or_userId"] = new Dictionary<string, object>
            {
                ["fromUserId"] = userId,
                ["toUserId"] = userId
            };
        if (!string.IsNullOrEmpty(status))
            filter["status"] = status;
        return filter;
    }

    private static string? GetPeerId(Dictionary<string, object> connection, string userId)
    {
        var from = connection.TryGetValue("fromUserId", out var f) ? f?.ToString() : null;
        var to = connection.TryGetValue("toUserId", out var t) ? t?.ToString() : null;
        return from == userId ? to : (to == userId ? from : null);
    }
}

// ─── Main Connection Service ───────────────────────────────────
public class ConnectionService
{
    private readonly IDatabaseService _db;
    private readonly IQueueService _queue;
    private readonly IObjectProcessor _processor;
    private readonly ConnectionConfig _config;
    private readonly ConnectionStrengthCalculator _strengthCalc;
    private readonly GraphTraversal _graphTraversal;
    private readonly ILogger<ConnectionService> _logger;

    public ConnectionService(
        IDatabaseService db,
        IQueueService queue,
        IObjectProcessor processor,
        ConnectionConfig config,
        ILogger<ConnectionService> logger)
    {
        _db = db;
        _queue = queue;
        _processor = processor;
        _config = config;
        _strengthCalc = new ConnectionStrengthCalculator();
        _graphTraversal = new GraphTraversal(db, config.ConnectionsIndex, logger);
        _logger = logger;
    }

    // ─── Connection Requests ───────────────────────────────────

    /// <summary>Send a connection request. Checks for existing connections, blocks, and auto-accept rules.</summary>
    public async Task<DataProcessResult<Dictionary<string, object>>> SendRequestAsync(
        Dictionary<string, object> requestData, CancellationToken ct = default)
    {
        try
        {
            var parsed = _processor.ParseObjectAlternative(requestData);
            var fromUserId = GetString(parsed, "fromUserId");
            var toUserId = GetString(parsed, "toUserId");

            if (string.IsNullOrEmpty(fromUserId) || string.IsNullOrEmpty(toUserId))
                return DataProcessResult<Dictionary<string, object>>.Failure(
                    "fromUserId and toUserId are required");

            if (fromUserId == toUserId)
                return DataProcessResult<Dictionary<string, object>>.Failure(
                    "Cannot send connection request to yourself");

            // Check if blocked
            if (await IsBlockedInternalAsync(fromUserId, toUserId, ct))
                return DataProcessResult<Dictionary<string, object>>.Failure(
                    "Cannot connect with this user");

            // Check if already connected
            var existingConn = await FindExistingConnectionAsync(fromUserId, toUserId, ct);
            if (existingConn != null)
                return DataProcessResult<Dictionary<string, object>>.Failure(
                    "Connection already exists");

            // Check for pending request
            var existingReq = await FindPendingRequestAsync(fromUserId, toUserId, ct);
            if (existingReq != null)
                return DataProcessResult<Dictionary<string, object>>.Failure(
                    "Connection request already pending");

            // Build request document (DNA-1: dynamic document)
            var requestId = $"req_{Guid.NewGuid():N}";
            var request = new Dictionary<string, object>
            {
                ["requestId"] = requestId,
                ["fromUserId"] = fromUserId,
                ["toUserId"] = toUserId,
                ["type"] = GetString(parsed, "type") ?? "friend",
                ["status"] = RequestStatus.Pending,
                ["message"] = GetString(parsed, "message") ?? "",
                ["createdAt"] = DateTime.UtcNow.ToString("O"),
                ["expiresAt"] = DateTime.UtcNow.AddDays(_config.RequestExpirationDays).ToString("O"),
                ["scopeId"] = GetString(parsed, "scopeId") ?? "default"
            };

            // Copy any additional metadata fields
            foreach (var kvp in parsed)
            {
                if (!request.ContainsKey(kvp.Key))
                    request[kvp.Key] = kvp.Value;
            }

            await _db.UpsertAsync(_config.RequestsIndex, requestId, request, ct);

            // Check auto-accept rules
            var config = await GetConfigInternalAsync(GetString(parsed, "scopeId") ?? "default", ct);
            var autoAcceptMin = GetDouble(config, "autoAcceptMinMatchScore", _config.AutoAcceptMinMatchScore);

            if (parsed.TryGetValue("matchScore", out var ms) && GetDoubleVal(ms) >= autoAcceptMin)
            {
                _logger.LogInformation("Auto-accepting request {RequestId} (matchScore >= threshold)", requestId);
                return await AcceptRequestAsync(requestId, toUserId, ct);
            }

            // Publish event
            await _queue.PublishAsync("connection-events", new Dictionary<string, object>
            {
                ["eventType"] = "FriendRequestSent",
                ["requestId"] = requestId,
                ["fromUserId"] = fromUserId,
                ["toUserId"] = toUserId,
                ["timestamp"] = DateTime.UtcNow.ToString("O")
            }, ct);

            _logger.LogInformation("Connection request {RequestId} sent from {From} to {To}",
                requestId, fromUserId, toUserId);

            return DataProcessResult<Dictionary<string, object>>.Success(request);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error sending connection request");
            return DataProcessResult<Dictionary<string, object>>.Failure(ex.Message);
        }
    }

    /// <summary>Accept a pending connection request. Creates the connection and calculates initial strength.</summary>
    public async Task<DataProcessResult<Dictionary<string, object>>> AcceptRequestAsync(
        string requestId, string acceptingUserId, CancellationToken ct = default)
    {
        try
        {
            var request = await _db.GetByIdAsync(_config.RequestsIndex, requestId, ct);
            if (request == null)
                return DataProcessResult<Dictionary<string, object>>.Failure("Request not found");

            var status = GetString(request, "status");
            if (!RequestStatus.CanTransition(status ?? "", RequestStatus.Accepted))
                return DataProcessResult<Dictionary<string, object>>.Failure(
                    $"Cannot accept request in status '{status}'");

            var toUserId = GetString(request, "toUserId");
            if (toUserId != acceptingUserId)
                return DataProcessResult<Dictionary<string, object>>.Failure(
                    "Only the target user can accept this request");

            // Check expiration
            if (request.TryGetValue("expiresAt", out var exp) &&
                DateTime.TryParse(exp?.ToString(), out var expiresAt) &&
                expiresAt < DateTime.UtcNow)
            {
                request["status"] = RequestStatus.Expired;
                await _db.UpsertAsync(_config.RequestsIndex, requestId, request, ct);
                return DataProcessResult<Dictionary<string, object>>.Failure("Request has expired");
            }

            // Update request status
            request["status"] = RequestStatus.Accepted;
            request["acceptedAt"] = DateTime.UtcNow.ToString("O");
            await _db.UpsertAsync(_config.RequestsIndex, requestId, request, ct);

            var fromUserId = GetString(request, "fromUserId")!;

            // Create connection document (DNA-1)
            var connectionId = $"conn_{Guid.NewGuid():N}";
            var connection = new Dictionary<string, object>
            {
                ["connectionId"] = connectionId,
                ["fromUserId"] = fromUserId,
                ["toUserId"] = toUserId!,
                ["type"] = GetString(request, "type") ?? "friend",
                ["status"] = "accepted",
                ["strength"] = 0.0,
                ["strengthFactors"] = new Dictionary<string, object>(),
                ["requestId"] = requestId,
                ["createdAt"] = DateTime.UtcNow.ToString("O"),
                ["updatedAt"] = DateTime.UtcNow.ToString("O"),
                ["scopeId"] = GetString(request, "scopeId") ?? "default"
            };

            await _db.UpsertAsync(_config.ConnectionsIndex, connectionId, connection, ct);

            // Calculate initial strength async
            _ = Task.Run(async () =>
            {
                try
                {
                    await RecalculateStrengthInternalAsync(connectionId, fromUserId, toUserId!, ct);
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Background strength calc failed for {ConnId}", connectionId);
                }
            }, ct);

            // Publish event
            await _queue.PublishAsync("connection-events", new Dictionary<string, object>
            {
                ["eventType"] = "FriendRequestAccepted",
                ["connectionId"] = connectionId,
                ["requestId"] = requestId,
                ["fromUserId"] = fromUserId,
                ["toUserId"] = toUserId!,
                ["timestamp"] = DateTime.UtcNow.ToString("O")
            }, ct);

            _logger.LogInformation("Request {RequestId} accepted, connection {ConnectionId} created",
                requestId, connectionId);

            return DataProcessResult<Dictionary<string, object>>.Success(connection);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error accepting request {RequestId}", requestId);
            return DataProcessResult<Dictionary<string, object>>.Failure(ex.Message);
        }
    }

    /// <summary>Reject a pending connection request.</summary>
    public async Task<DataProcessResult<Dictionary<string, object>>> RejectRequestAsync(
        string requestId, string rejectingUserId, CancellationToken ct = default)
    {
        try
        {
            var request = await _db.GetByIdAsync(_config.RequestsIndex, requestId, ct);
            if (request == null)
                return DataProcessResult<Dictionary<string, object>>.Failure("Request not found");

            if (GetString(request, "toUserId") != rejectingUserId)
                return DataProcessResult<Dictionary<string, object>>.Failure(
                    "Only the target user can reject this request");

            if (!RequestStatus.CanTransition(GetString(request, "status") ?? "", RequestStatus.Rejected))
                return DataProcessResult<Dictionary<string, object>>.Failure("Cannot reject this request");

            request["status"] = RequestStatus.Rejected;
            request["rejectedAt"] = DateTime.UtcNow.ToString("O");
            await _db.UpsertAsync(_config.RequestsIndex, requestId, request, ct);

            await _queue.PublishAsync("connection-events", new Dictionary<string, object>
            {
                ["eventType"] = "FriendRequestRejected",
                ["requestId"] = requestId,
                ["timestamp"] = DateTime.UtcNow.ToString("O")
            }, ct);

            return DataProcessResult<Dictionary<string, object>>.Success(request);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error rejecting request {RequestId}", requestId);
            return DataProcessResult<Dictionary<string, object>>.Failure(ex.Message);
        }
    }

    /// <summary>Cancel a sent connection request (only sender can cancel).</summary>
    public async Task<DataProcessResult<Dictionary<string, object>>> CancelRequestAsync(
        string requestId, string cancellingUserId, CancellationToken ct = default)
    {
        try
        {
            var request = await _db.GetByIdAsync(_config.RequestsIndex, requestId, ct);
            if (request == null)
                return DataProcessResult<Dictionary<string, object>>.Failure("Request not found");

            if (GetString(request, "fromUserId") != cancellingUserId)
                return DataProcessResult<Dictionary<string, object>>.Failure(
                    "Only the sender can cancel this request");

            if (!RequestStatus.CanTransition(GetString(request, "status") ?? "", RequestStatus.Cancelled))
                return DataProcessResult<Dictionary<string, object>>.Failure("Cannot cancel this request");

            request["status"] = RequestStatus.Cancelled;
            request["cancelledAt"] = DateTime.UtcNow.ToString("O");
            await _db.UpsertAsync(_config.RequestsIndex, requestId, request, ct);

            return DataProcessResult<Dictionary<string, object>>.Success(request);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error cancelling request {RequestId}", requestId);
            return DataProcessResult<Dictionary<string, object>>.Failure(ex.Message);
        }
    }

    /// <summary>Get pending requests (inbound or outbound) for a user with scope isolation.</summary>
    public async Task<DataProcessResult<List<Dictionary<string, object>>>> GetPendingRequestsAsync(
        string userId, string direction = "inbound", CancellationToken ct = default)
    {
        try
        {
            // DNA-2: BuildSearchFilter — skip empty fields
            var filter = new Dictionary<string, object>
            {
                ["status"] = RequestStatus.Pending
            };

            if (direction == "inbound")
                filter["toUserId"] = userId;
            else
                filter["fromUserId"] = userId;

            var results = await _db.QueryAsync(_config.RequestsIndex, filter, ct);

            // Filter out expired
            var active = results.Where(r =>
            {
                if (r.TryGetValue("expiresAt", out var exp) &&
                    DateTime.TryParse(exp?.ToString(), out var expiresAt))
                    return expiresAt > DateTime.UtcNow;
                return true;
            }).ToList();

            return DataProcessResult<List<Dictionary<string, object>>>.Success(active);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting pending requests for {UserId}", userId);
            return DataProcessResult<List<Dictionary<string, object>>>.Failure(ex.Message);
        }
    }

    // ─── Connection Management ─────────────────────────────────

    /// <summary>Get paginated connections for a user, ordered by strength.</summary>
    public async Task<DataProcessResult<ConnectionPage>> GetConnectionsAsync(
        string userId, int page = 0, int? pageSize = null, string? typeFilter = null,
        CancellationToken ct = default)
    {
        try
        {
            var size = pageSize ?? _config.DefaultPageSize;

            // DNA-2: BuildSearchFilter — only non-empty values
            var filter = new Dictionary<string, object>();

            // Scope: user sees only their connections
            filter["_or_userId"] = new Dictionary<string, object>
            {
                ["fromUserId"] = userId,
                ["toUserId"] = userId
            };
            filter["status"] = "accepted";

            if (!string.IsNullOrEmpty(typeFilter))
                filter["type"] = typeFilter;

            // Also exclude connections where peer is blocked
            var blockedIds = await GetBlockedUserIdsAsync(userId, ct);

            var allResults = await _db.QueryAsync(_config.ConnectionsIndex, filter, ct);

            // Filter out blocked users
            var filtered = allResults
                .Where(c =>
                {
                    var peerId = GetPeerId(c, userId);
                    return peerId != null && !blockedIds.Contains(peerId);
                })
                .OrderByDescending(c => GetDoubleVal(c.GetValueOrDefault("strength", 0.0)))
                .ToList();

            var total = filtered.Count;
            var paged = filtered.Skip(page * size).Take(size).ToList();

            return DataProcessResult<ConnectionPage>.Success(new ConnectionPage
            {
                Items = paged,
                TotalCount = total,
                HasMore = (page + 1) * size < total,
                Cursor = paged.Count > 0 ? $"{page + 1}" : null
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting connections for {UserId}", userId);
            return DataProcessResult<ConnectionPage>.Failure(ex.Message);
        }
    }

    /// <summary>Get a specific connection by ID with scope check.</summary>
    public async Task<DataProcessResult<Dictionary<string, object>>> GetConnectionByIdAsync(
        string connectionId, string requestingUserId, CancellationToken ct = default)
    {
        try
        {
            var conn = await _db.GetByIdAsync(_config.ConnectionsIndex, connectionId, ct);
            if (conn == null)
                return DataProcessResult<Dictionary<string, object>>.Failure("Connection not found");

            // Scope isolation: only participants can view
            var from = GetString(conn, "fromUserId");
            var to = GetString(conn, "toUserId");
            if (from != requestingUserId && to != requestingUserId)
                return DataProcessResult<Dictionary<string, object>>.Failure("Access denied");

            return DataProcessResult<Dictionary<string, object>>.Success(conn);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting connection {ConnId}", connectionId);
            return DataProcessResult<Dictionary<string, object>>.Failure(ex.Message);
        }
    }

    /// <summary>Remove an active connection (both sides).</summary>
    public async Task<DataProcessResult<Dictionary<string, object>>> RemoveConnectionAsync(
        string connectionId, string removingUserId, CancellationToken ct = default)
    {
        try
        {
            var conn = await _db.GetByIdAsync(_config.ConnectionsIndex, connectionId, ct);
            if (conn == null)
                return DataProcessResult<Dictionary<string, object>>.Failure("Connection not found");

            var from = GetString(conn, "fromUserId");
            var to = GetString(conn, "toUserId");
            if (from != removingUserId && to != removingUserId)
                return DataProcessResult<Dictionary<string, object>>.Failure("Access denied");

            conn["status"] = "removed";
            conn["removedAt"] = DateTime.UtcNow.ToString("O");
            conn["removedBy"] = removingUserId;
            await _db.UpsertAsync(_config.ConnectionsIndex, connectionId, conn, ct);

            await _queue.PublishAsync("connection-events", new Dictionary<string, object>
            {
                ["eventType"] = "ConnectionRemoved",
                ["connectionId"] = connectionId,
                ["fromUserId"] = from!,
                ["toUserId"] = to!,
                ["removedBy"] = removingUserId,
                ["timestamp"] = DateTime.UtcNow.ToString("O")
            }, ct);

            return DataProcessResult<Dictionary<string, object>>.Success(conn);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error removing connection {ConnId}", connectionId);
            return DataProcessResult<Dictionary<string, object>>.Failure(ex.Message);
        }
    }

    /// <summary>Update connection type (e.g., friend → mentor).</summary>
    public async Task<DataProcessResult<Dictionary<string, object>>> UpdateConnectionTypeAsync(
        string connectionId, string newType, string requestingUserId, CancellationToken ct = default)
    {
        try
        {
            var conn = await _db.GetByIdAsync(_config.ConnectionsIndex, connectionId, ct);
            if (conn == null)
                return DataProcessResult<Dictionary<string, object>>.Failure("Connection not found");

            var from = GetString(conn, "fromUserId");
            var to = GetString(conn, "toUserId");
            if (from != requestingUserId && to != requestingUserId)
                return DataProcessResult<Dictionary<string, object>>.Failure("Access denied");

            conn["type"] = newType;
            conn["updatedAt"] = DateTime.UtcNow.ToString("O");
            await _db.UpsertAsync(_config.ConnectionsIndex, connectionId, conn, ct);

            return DataProcessResult<Dictionary<string, object>>.Success(conn);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating type for {ConnId}", connectionId);
            return DataProcessResult<Dictionary<string, object>>.Failure(ex.Message);
        }
    }

    // ─── Blocking ──────────────────────────────────────────────

    /// <summary>Block a user. Removes any existing connection.</summary>
    public async Task<DataProcessResult<Dictionary<string, object>>> BlockUserAsync(
        string blockingUserId, string blockedUserId, CancellationToken ct = default)
    {
        try
        {
            if (blockingUserId == blockedUserId)
                return DataProcessResult<Dictionary<string, object>>.Failure("Cannot block yourself");

            // Remove existing connection if any
            var existing = await FindExistingConnectionAsync(blockingUserId, blockedUserId, ct);
            if (existing != null)
            {
                var connId = GetString(existing, "connectionId");
                if (connId != null)
                    await RemoveConnectionAsync(connId, blockingUserId, ct);
            }

            // Cancel any pending requests
            var pendingReq = await FindPendingRequestAsync(blockingUserId, blockedUserId, ct);
            if (pendingReq != null)
            {
                var reqId = GetString(pendingReq, "requestId");
                if (reqId != null)
                {
                    pendingReq["status"] = RequestStatus.Cancelled;
                    await _db.UpsertAsync(_config.RequestsIndex, reqId, pendingReq, ct);
                }
            }

            // Create block record
            var blockId = $"block_{blockingUserId}_{blockedUserId}";
            var blockDoc = new Dictionary<string, object>
            {
                ["blockId"] = blockId,
                ["blockingUserId"] = blockingUserId,
                ["blockedUserId"] = blockedUserId,
                ["createdAt"] = DateTime.UtcNow.ToString("O")
            };

            await _db.UpsertAsync(_config.BlockedIndex, blockId, blockDoc, ct);

            await _queue.PublishAsync("connection-events", new Dictionary<string, object>
            {
                ["eventType"] = "ConnectionBlocked",
                ["blockingUserId"] = blockingUserId,
                ["blockedUserId"] = blockedUserId,
                ["timestamp"] = DateTime.UtcNow.ToString("O")
            }, ct);

            return DataProcessResult<Dictionary<string, object>>.Success(blockDoc);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error blocking user {BlockedId}", blockedUserId);
            return DataProcessResult<Dictionary<string, object>>.Failure(ex.Message);
        }
    }

    /// <summary>Unblock a previously blocked user.</summary>
    public async Task<DataProcessResult<Dictionary<string, object>>> UnblockUserAsync(
        string blockingUserId, string blockedUserId, CancellationToken ct = default)
    {
        try
        {
            var blockId = $"block_{blockingUserId}_{blockedUserId}";
            var blockDoc = await _db.GetByIdAsync(_config.BlockedIndex, blockId, ct);
            if (blockDoc == null)
                return DataProcessResult<Dictionary<string, object>>.Failure("Block not found");

            await _db.DeleteAsync(_config.BlockedIndex, blockId, ct);

            await _queue.PublishAsync("connection-events", new Dictionary<string, object>
            {
                ["eventType"] = "ConnectionUnblocked",
                ["blockingUserId"] = blockingUserId,
                ["blockedUserId"] = blockedUserId,
                ["timestamp"] = DateTime.UtcNow.ToString("O")
            }, ct);

            return DataProcessResult<Dictionary<string, object>>.Success(
                new Dictionary<string, object> { ["unblocked"] = true, ["blockedUserId"] = blockedUserId });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error unblocking user {BlockedId}", blockedUserId);
            return DataProcessResult<Dictionary<string, object>>.Failure(ex.Message);
        }
    }

    /// <summary>Get list of blocked users for a user.</summary>
    public async Task<DataProcessResult<List<Dictionary<string, object>>>> GetBlockedUsersAsync(
        string userId, CancellationToken ct = default)
    {
        try
        {
            var filter = new Dictionary<string, object> { ["blockingUserId"] = userId };
            var results = await _db.QueryAsync(_config.BlockedIndex, filter, ct);
            return DataProcessResult<List<Dictionary<string, object>>>.Success(results);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting blocked users for {UserId}", userId);
            return DataProcessResult<List<Dictionary<string, object>>>.Failure(ex.Message);
        }
    }

    /// <summary>Check if two users are blocked (bidirectional).</summary>
    public async Task<DataProcessResult<bool>> IsBlockedAsync(
        string userA, string userB, CancellationToken ct = default)
    {
        try
        {
            var blocked = await IsBlockedInternalAsync(userA, userB, ct);
            return DataProcessResult<bool>.Success(blocked);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error checking block between {A} and {B}", userA, userB);
            return DataProcessResult<bool>.Failure(ex.Message);
        }
    }

    // ─── Graph Operations ──────────────────────────────────────

    /// <summary>Get mutual connections between two users.</summary>
    public async Task<DataProcessResult<List<Dictionary<string, object>>>> GetMutualConnectionsAsync(
        string userA, string userB, CancellationToken ct = default)
    {
        try
        {
            var mutuals = await _graphTraversal.GetMutualConnectionsAsync(userA, userB, ct);
            return DataProcessResult<List<Dictionary<string, object>>>.Success(mutuals);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting mutual connections");
            return DataProcessResult<List<Dictionary<string, object>>>.Failure(ex.Message);
        }
    }

    /// <summary>Get friend-of-friend suggestions with scoring.</summary>
    public async Task<DataProcessResult<List<Dictionary<string, object>>>> GetSuggestionsAsync(
        string userId, int? limit = null, CancellationToken ct = default)
    {
        try
        {
            var maxSuggestions = limit ?? _config.SuggestionLimit;
            var depth2Users = await _graphTraversal.GetUserIdsAtDepthAsync(userId, 2, maxSuggestions * 2, ct);

            // For each suggestion, count mutual connections and calculate a score
            var suggestions = new List<Dictionary<string, object>>();
            foreach (var suggestedId in depth2Users.Take(maxSuggestions))
            {
                var mutuals = await _graphTraversal.GetMutualConnectionsAsync(userId, suggestedId, ct);
                suggestions.Add(new Dictionary<string, object>
                {
                    ["suggestedUserId"] = suggestedId,
                    ["mutualCount"] = mutuals.Count,
                    ["score"] = Math.Min(mutuals.Count / 5.0, 1.0), // Simple scoring
                    ["reason"] = $"{mutuals.Count} mutual connection(s)"
                });
            }

            var sorted = suggestions.OrderByDescending(s => GetDoubleVal(s["score"])).ToList();
            return DataProcessResult<List<Dictionary<string, object>>>.Success(sorted);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting suggestions for {UserId}", userId);
            return DataProcessResult<List<Dictionary<string, object>>>.Failure(ex.Message);
        }
    }

    /// <summary>Get shortest path length between two users.</summary>
    public async Task<DataProcessResult<int>> GetNetworkDepthAsync(
        string fromUser, string toUser, CancellationToken ct = default)
    {
        try
        {
            var depth = await _graphTraversal.GetShortestPathAsync(
                fromUser, toUser, _config.MaxTraversalDepth, ct);
            return DataProcessResult<int>.Success(depth);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting network depth");
            return DataProcessResult<int>.Failure(ex.Message);
        }
    }

    /// <summary>Get connection strength between two users.</summary>
    public async Task<DataProcessResult<double>> GetConnectionStrengthAsync(
        string userA, string userB, CancellationToken ct = default)
    {
        try
        {
            var conn = await FindExistingConnectionAsync(userA, userB, ct);
            if (conn == null)
                return DataProcessResult<double>.Success(0.0);

            var strength = GetDoubleVal(conn.GetValueOrDefault("strength", 0.0));
            return DataProcessResult<double>.Success(strength);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting strength between {A} and {B}", userA, userB);
            return DataProcessResult<double>.Failure(ex.Message);
        }
    }

    // ─── Strength Recalculation ────────────────────────────────

    /// <summary>Recalculate strength for a specific connection.</summary>
    public async Task<DataProcessResult<Dictionary<string, object>>> RecalculateStrengthAsync(
        string connectionId, CancellationToken ct = default)
    {
        try
        {
            var conn = await _db.GetByIdAsync(_config.ConnectionsIndex, connectionId, ct);
            if (conn == null)
                return DataProcessResult<Dictionary<string, object>>.Failure("Connection not found");

            var from = GetString(conn, "fromUserId")!;
            var to = GetString(conn, "toUserId")!;

            return await RecalculateStrengthInternalAsync(connectionId, from, to, ct);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error recalculating strength for {ConnId}", connectionId);
            return DataProcessResult<Dictionary<string, object>>.Failure(ex.Message);
        }
    }

    /// <summary>Batch recalculate strengths for all connections (scheduled job).</summary>
    public async Task<DataProcessResult<int>> BatchRecalculateAsync(CancellationToken ct = default)
    {
        try
        {
            var filter = new Dictionary<string, object> { ["status"] = "accepted" };
            var all = await _db.QueryAsync(_config.ConnectionsIndex, filter, ct);

            int updated = 0;
            foreach (var conn in all)
            {
                if (ct.IsCancellationRequested) break;

                var connId = GetString(conn, "connectionId");
                var from = GetString(conn, "fromUserId");
                var to = GetString(conn, "toUserId");

                if (connId != null && from != null && to != null)
                {
                    var result = await RecalculateStrengthInternalAsync(connId, from, to, ct);
                    if (result.IsSuccess) updated++;
                }
            }

            _logger.LogInformation("Batch recalculated {Count} connection strengths", updated);
            return DataProcessResult<int>.Success(updated);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in batch recalculation");
            return DataProcessResult<int>.Failure(ex.Message);
        }
    }

    // ─── Configuration (FREEDOM) ───────────────────────────────

    /// <summary>Get connection config for a scope.</summary>
    public async Task<DataProcessResult<Dictionary<string, object>>> GetConfigAsync(
        string scopeId, CancellationToken ct = default)
    {
        try
        {
            var config = await GetConfigInternalAsync(scopeId, ct);
            return DataProcessResult<Dictionary<string, object>>.Success(config);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting config for scope {ScopeId}", scopeId);
            return DataProcessResult<Dictionary<string, object>>.Failure(ex.Message);
        }
    }

    /// <summary>Update connection config (admin only).</summary>
    public async Task<DataProcessResult<Dictionary<string, object>>> UpdateConfigAsync(
        Dictionary<string, object> configData, CancellationToken ct = default)
    {
        try
        {
            var parsed = _processor.ParseObjectAlternative(configData);
            var scopeId = GetString(parsed, "scopeId") ?? "default";
            parsed["configId"] = $"conn-config-{scopeId}";
            parsed["updatedAt"] = DateTime.UtcNow.ToString("O");

            await _db.UpsertAsync(_config.ConfigIndex, $"conn-config-{scopeId}", parsed, ct);
            return DataProcessResult<Dictionary<string, object>>.Success(parsed);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating config");
            return DataProcessResult<Dictionary<string, object>>.Failure(ex.Message);
        }
    }

    // ─── Internal Helpers ──────────────────────────────────────

    private async Task<bool> IsBlockedInternalAsync(string userA, string userB, CancellationToken ct)
    {
        var blockAB = await _db.GetByIdAsync(_config.BlockedIndex, $"block_{userA}_{userB}", ct);
        if (blockAB != null) return true;
        var blockBA = await _db.GetByIdAsync(_config.BlockedIndex, $"block_{userB}_{userA}", ct);
        return blockBA != null;
    }

    private async Task<Dictionary<string, object>?> FindExistingConnectionAsync(
        string userA, string userB, CancellationToken ct)
    {
        var filter = new Dictionary<string, object>
        {
            ["fromUserId"] = userA,
            ["toUserId"] = userB,
            ["status"] = "accepted"
        };
        var results = await _db.QueryAsync(_config.ConnectionsIndex, filter, ct);
        if (results.Count > 0) return results[0];

        // Check reverse direction
        filter["fromUserId"] = userB;
        filter["toUserId"] = userA;
        results = await _db.QueryAsync(_config.ConnectionsIndex, filter, ct);
        return results.Count > 0 ? results[0] : null;
    }

    private async Task<Dictionary<string, object>?> FindPendingRequestAsync(
        string fromUser, string toUser, CancellationToken ct)
    {
        var filter = new Dictionary<string, object>
        {
            ["fromUserId"] = fromUser,
            ["toUserId"] = toUser,
            ["status"] = RequestStatus.Pending
        };
        var results = await _db.QueryAsync(_config.RequestsIndex, filter, ct);
        if (results.Count > 0) return results[0];

        // Check reverse
        filter["fromUserId"] = toUser;
        filter["toUserId"] = fromUser;
        results = await _db.QueryAsync(_config.RequestsIndex, filter, ct);
        return results.Count > 0 ? results[0] : null;
    }

    private async Task<Dictionary<string, object>> GetConfigInternalAsync(string scopeId, CancellationToken ct)
    {
        var config = await _db.GetByIdAsync(_config.ConfigIndex, $"conn-config-{scopeId}", ct);
        return config ?? new Dictionary<string, object>
        {
            ["autoAcceptMinMatchScore"] = _config.AutoAcceptMinMatchScore,
            ["requestExpirationDays"] = _config.RequestExpirationDays,
            ["maxTraversalDepth"] = _config.MaxTraversalDepth,
            ["suggestionLimit"] = _config.SuggestionLimit,
            ["matchScoreWeight"] = DefaultStrengthWeights.MatchScore,
            ["sharedGroupsWeight"] = DefaultStrengthWeights.SharedGroups,
            ["coAttendedEventsWeight"] = DefaultStrengthWeights.CoAttendedEvents,
            ["messageFrequencyWeight"] = DefaultStrengthWeights.MessageFrequency,
            ["profileSimilarityWeight"] = DefaultStrengthWeights.ProfileSimilarity
        };
    }

    private async Task<DataProcessResult<Dictionary<string, object>>> RecalculateStrengthInternalAsync(
        string connectionId, string fromUser, string toUser, CancellationToken ct)
    {
        var conn = await _db.GetByIdAsync(_config.ConnectionsIndex, connectionId, ct);
        if (conn == null)
            return DataProcessResult<Dictionary<string, object>>.Failure("Connection not found");

        var config = await GetConfigInternalAsync(GetString(conn, "scopeId") ?? "default", ct);

        // Gather strength factors
        var factors = new Dictionary<string, object>();
        if (conn.TryGetValue("strengthFactors", out var existingFactors) &&
            existingFactors is Dictionary<string, object> ef)
        {
            foreach (var kv in ef) factors[kv.Key] = kv.Value;
        }

        // Calculate composite strength
        var strength = _strengthCalc.Calculate(factors, config);
        var previousStrength = GetDoubleVal(conn.GetValueOrDefault("strength", 0.0));

        conn["strength"] = strength;
        conn["updatedAt"] = DateTime.UtcNow.ToString("O");
        await _db.UpsertAsync(_config.ConnectionsIndex, connectionId, conn, ct);

        // Publish if significant change (>0.1 delta)
        if (Math.Abs(strength - previousStrength) > 0.1)
        {
            await _queue.PublishAsync("connection-events", new Dictionary<string, object>
            {
                ["eventType"] = "ConnectionStrengthUpdated",
                ["connectionId"] = connectionId,
                ["fromUserId"] = fromUser,
                ["toUserId"] = toUser,
                ["previousStrength"] = previousStrength,
                ["newStrength"] = strength,
                ["timestamp"] = DateTime.UtcNow.ToString("O")
            }, ct);
        }

        return DataProcessResult<Dictionary<string, object>>.Success(conn);
    }

    private async Task<HashSet<string>> GetBlockedUserIdsAsync(string userId, CancellationToken ct)
    {
        var blocked = new HashSet<string>();
        var filterBlocking = new Dictionary<string, object> { ["blockingUserId"] = userId };
        var filterBlocked = new Dictionary<string, object> { ["blockedUserId"] = userId };

        var blocking = await _db.QueryAsync(_config.BlockedIndex, filterBlocking, ct);
        var blockedBy = await _db.QueryAsync(_config.BlockedIndex, filterBlocked, ct);

        foreach (var b in blocking)
        {
            var id = GetString(b, "blockedUserId");
            if (id != null) blocked.Add(id);
        }
        foreach (var b in blockedBy)
        {
            var id = GetString(b, "blockingUserId");
            if (id != null) blocked.Add(id);
        }

        return blocked;
    }

    private static string? GetString(Dictionary<string, object> doc, string key)
    {
        return doc.TryGetValue(key, out var val) ? val?.ToString() : null;
    }

    private static string? GetPeerId(Dictionary<string, object> conn, string userId)
    {
        var from = GetString(conn, "fromUserId");
        var to = GetString(conn, "toUserId");
        return from == userId ? to : (to == userId ? from : null);
    }

    private static double GetDoubleVal(object? val)
    {
        if (val is double d) return d;
        if (val is int i) return i;
        if (val is long l) return l;
        if (val is float f) return f;
        if (val is JsonElement je && je.TryGetDouble(out var jd)) return jd;
        if (double.TryParse(val?.ToString(), out var parsed)) return parsed;
        return 0.0;
    }
}

// ─── DI Registration Extension ─────────────────────────────────
public static class ConnectionServiceExtensions
{
    public static IServiceCollection AddXIIGenConnectionService(
        this IServiceCollection services, Action<ConnectionConfig>? configure = null)
    {
        var config = new ConnectionConfig();
        configure?.Invoke(config);
        services.AddSingleton(config);
        services.AddScoped<ConnectionStrengthCalculator>();
        services.AddScoped<ConnectionService>();
        return services;
    }
}
