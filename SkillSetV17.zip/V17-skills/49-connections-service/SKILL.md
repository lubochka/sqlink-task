---
skill_id: "49"
name: "connections-service"
title: "Connection Service"
layer: "L10: Social Graph"
version: "17.0"
status: "active"
dependencies:
  - "01-core-interfaces"
  - "02-object-processor"
  - "03-elasticsearch-datastore"
  - "04-redis-queue-service"
  - "43-calculator-metrics"
  - "47-matching-service"
dotnet_namespace: "XIIGen.Services.Connections"
di_registration: "services.AddXIIGenConnectionService()"
es_indices:
  - "connections"
  - "connection-requests"
  - "connection-config"
genie_dna:
  - "DNA-1: Connections as Dictionary<string,object> — supports friends, professional contacts, mentors, any relation type"
  - "DNA-2: BuildSearchFilter for connection queries — userId, status, type, strength — skip empty fields"
  - "DNA-3: Inherits MicroserviceBase with all 19 architectural components"
  - "DNA-5: All operations return DataProcessResult<T>"
  - "DNA-SCOPE: Users see ONLY their own connections; admins see all; moderators see flagged"
  - "DNA-FREEDOM: Connection types, strength thresholds, and auto-accept rules are dynamic documents — admins configure without code"
  - "DNA-7: Event-driven — publishes FriendRequestSent, FriendRequestAccepted, ConnectionBlocked, ConnectionStrengthUpdated; subscribes to MatchScoreUpdated, EventAttended, GroupJoined"
component_classification:
  machine_parts:
    - "Graph traversal engine (BFS/DFS for mutual connections, shortest path)"
    - "Connection strength calculator (weighted multi-factor formula)"
    - "Request lifecycle FSM (pending → accepted/rejected/expired)"
    - "Block enforcement (bidirectional visibility filter)"
  freedom_parts:
    - "Connection types (admin-defined: friend, colleague, mentor, vendor, custom)"
    - "Strength weight formulas (admin-configurable factor weights)"
    - "Auto-accept rules (admin-defined criteria for automatic approval)"
    - "Request expiration periods (admin-tunable TTL per connection type)"
    - "Network depth limits (admin-set max traversal depth for suggestions)"
alternatives:
  server: [nodejs, python, java, rust, php]
  database: [elasticsearch, neo4j, mongodb, postgresql, redis-graph]
  queue: [redis-streams, kafka, rabbitmq, sqs, azure-service-bus]
---

# Skill 49: Connection Service

## Purpose
Manages the social graph — all relationships between users on the XIIGen platform. Handles
friend requests (send, accept, reject, cancel), connection blocking, connection strength
calculation, and network traversal for suggestions and mutual-friend analysis. This service
appears in 4 of 8 UML diagrams and is the foundational service for all social interactions,
as most platform features depend on knowing WHO is connected to WHOM and HOW STRONGLY.

## Architecture

```
┌──────────────────┐     ┌────────────────────────┐     ┌─────────────────┐
│ Matching Engine  │────▶│                        │     │  Elasticsearch  │
│ (Skill 47)       │     │  Connection Service    │────▶│  "connections"  │
├──────────────────┤     │                        │     │  "conn-requests"│
│ Groups Service   │────▶│  ┌──────────────────┐  │     └─────────────────┘
│ (Skill 50)       │     │  │ Request Manager  │  │            │
├──────────────────┤     │  │ Graph Traversal  │  │◀───────────┘
│ Events Service   │────▶│  │ Strength Calc    │  │     ┌─────────────────┐
│ (Skill 53)       │     │  │ Block Enforcer   │  │────▶│  Redis Cache    │
├──────────────────┤     │  │ Suggestions      │  │     │  graph lookups  │
│ Feed Service     │◀────│  └──────────────────┘  │     └─────────────────┘
│ (Skill 46)       │     │                        │            │
└──────────────────┘     └────────────────────────┘     ┌──────▼──────────┐
                                  │                     │  Event Bus      │
                         ┌────────▼────────┐            │  RequestSent    │
                         │  Connection     │            │  Accepted       │
                         │  Config (dyn)   │            │  Blocked        │
                         │  types, weights │            │  StrengthUpdate │
                         │  auto-accept    │            └─────────────────┘
                         └─────────────────┘
```

## Key Concepts

- **Connection as Dynamic Document** — A connection is NOT a typed model. It's a `Dictionary<string,object>` with standard fields (fromUserId, toUserId, type, status, strength) plus any admin-defined custom fields (e.g., businessCategory, referralSource). This follows DNA-1 for maximum flexibility.
- **Connection Strength** — A composite score (0.0-1.0) calculated from multiple weighted factors: matching score, shared groups, co-attended events, message frequency, profile similarity. Factor weights are FREEDOM — admins tune them.
- **Graph Traversal** — BFS-based traversal for finding mutual connections (depth 1), friend-of-friend suggestions (depth 2), and shortest path between users. Depth limit is configurable (FREEDOM).
- **Request Lifecycle** — FSM: `pending → accepted | rejected | expired | cancelled`. Auto-accept rules can bypass pending state based on admin criteria (e.g., matching score > 0.8).
- **Block Enforcement** — Bidirectional: if A blocks B, neither A nor B can see each other's connections, profiles, or content. Enforced at query level via BuildSearchFilter.
- **Scope Isolation** — Users see only their own connections. Admin sees all. Moderator sees flagged connections. All queries add scope filter automatically.

## Core Operations

### 1. Connection Requests
| Method | Description | Returns |
|--------|-------------|---------|
| `SendRequestAsync` | Send a connection request to another user | DataProcessResult<Dictionary> |
| `AcceptRequestAsync` | Accept a pending request | DataProcessResult<Dictionary> |
| `RejectRequestAsync` | Reject a pending request | DataProcessResult<Dictionary> |
| `CancelRequestAsync` | Cancel a sent request | DataProcessResult<Dictionary> |
| `GetPendingRequestsAsync` | List pending requests (inbound/outbound) | DataProcessResult<List<Dictionary>> |

### 2. Connection Management
| Method | Description | Returns |
|--------|-------------|---------|
| `GetConnectionsAsync` | Paginated list of active connections | DataProcessResult<ConnectionPage> |
| `GetConnectionByIdAsync` | Get specific connection details | DataProcessResult<Dictionary> |
| `RemoveConnectionAsync` | Remove an active connection | DataProcessResult<Dictionary> |
| `UpdateConnectionTypeAsync` | Change connection type (friend → mentor) | DataProcessResult<Dictionary> |

### 3. Blocking
| Method | Description | Returns |
|--------|-------------|---------|
| `BlockUserAsync` | Block a user (removes connection if exists) | DataProcessResult<Dictionary> |
| `UnblockUserAsync` | Remove block | DataProcessResult<Dictionary> |
| `GetBlockedUsersAsync` | List of blocked users | DataProcessResult<List<Dictionary>> |
| `IsBlockedAsync` | Check if two users are blocked | DataProcessResult<bool> |

### 4. Graph Operations
| Method | Description | Returns |
|--------|-------------|---------|
| `GetMutualConnectionsAsync` | Find shared connections between two users | DataProcessResult<List<Dictionary>> |
| `GetSuggestionsAsync` | Friend-of-friend suggestions with scores | DataProcessResult<List<Dictionary>> |
| `GetNetworkDepthAsync` | Shortest path length between two users | DataProcessResult<int> |
| `GetConnectionStrengthAsync` | Calculate strength between two users | DataProcessResult<double> |

### 5. Strength Calculation
| Method | Description | Returns |
|--------|-------------|---------|
| `RecalculateStrengthAsync` | Recompute strength for a connection pair | DataProcessResult<Dictionary> |
| `BatchRecalculateAsync` | Batch update strengths (scheduled) | DataProcessResult<int> |

### 6. Configuration (FREEDOM)
| Method | Description | Returns |
|--------|-------------|---------|
| `GetConfigAsync` | Load connection config by scope | DataProcessResult<Dictionary> |
| `UpdateConfigAsync` | Admin-update config (types, weights, rules) | DataProcessResult<Dictionary> |

## Events Published
- `FriendRequestSent` — when a new request is created
- `FriendRequestAccepted` — when a request transitions to accepted
- `FriendRequestRejected` — when a request is rejected
- `ConnectionRemoved` — when an active connection is dissolved
- `ConnectionBlocked` — when a user blocks another
- `ConnectionUnblocked` — when a block is removed
- `ConnectionStrengthUpdated` — when strength score changes significantly (>0.1 delta)

## Events Subscribed
- `MatchScoreUpdated` (from Skill 47) → recalculate strength
- `EventAttended` (from Skill 53) → increase strength for co-attendees
- `GroupJoined` (from Skill 50) → increase strength for co-members
- `MessageSent` (from Skill 42) → increase strength for active conversations

## DNA Compliance Notes

### MACHINE vs FREEDOM
- **MACHINE:** Request FSM transitions, graph traversal algorithms, block enforcement logic, deduplication
- **FREEDOM:** Connection types, strength weights, auto-accept rules, expiration periods, traversal depth limits, suggestion algorithms

### Data Model
```
// Connection document (DNA-1: Dictionary<string,object>)
{
  "connectionId": "conn_abc123",
  "fromUserId": "user_001",
  "toUserId": "user_002",
  "type": "friend",              // FREEDOM: admin-defined types
  "status": "accepted",          // MACHINE: FSM state
  "strength": 0.72,              // calculated composite score
  "strengthFactors": {           // breakdown for transparency
    "matchScore": 0.85,
    "sharedGroups": 3,
    "coAttendedEvents": 2,
    "messageFrequency": 0.6
  },
  "metadata": {                  // extensible custom fields
    "referralSource": "event_xyz",
    "businessCategory": "tech"
  },
  "createdAt": "2026-01-15T10:00:00Z",
  "updatedAt": "2026-02-01T14:30:00Z",
  "scopeId": "tenant_main"
}
```

### Anti-Patterns to Avoid
- ❌ Fixed `Connection` class with hardcoded fields — use Dictionary<string,object>
- ❌ SQL JOINs for graph traversal — use iterative BFS with caching
- ❌ Checking permissions inline — use scope filter in BuildSearchFilter
- ❌ Synchronous strength calculation — use event-driven recalculation
- ❌ Storing blocked users in connection doc — separate blocked-users index

## Test Scenarios

### Happy Path
1. User A sends request to User B → request stored with status "pending"
2. User B accepts → status changes to "accepted", strength calculated, events published
3. GetConnections returns paginated list with strength-ordered results

### Edge Cases
1. Send request to already-connected user → return error "already connected"
2. Send request to blocked user → return error "user not available"
3. Accept expired request → return error "request expired"
4. Remove connection → verify both sides updated, events published
5. Block user → verify connection removed, mutual visibility eliminated

### Performance
1. GetSuggestions with 10K+ connections → must complete in < 2s with caching
2. BatchRecalculateStrength for 1000 connections → use parallel processing
3. Graph traversal depth 3 with 50K users → bounded by depth limit config

## API Endpoints
```
POST   /connections/request                    → SendRequestAsync
PUT    /connections/request/{requestId}/accept  → AcceptRequestAsync
PUT    /connections/request/{requestId}/reject  → RejectRequestAsync
DELETE /connections/request/{requestId}         → CancelRequestAsync
GET    /connections/request/pending             → GetPendingRequestsAsync

GET    /connections                             → GetConnectionsAsync
GET    /connections/{connectionId}              → GetConnectionByIdAsync
DELETE /connections/{connectionId}              → RemoveConnectionAsync
PUT    /connections/{connectionId}/type         → UpdateConnectionTypeAsync

POST   /connections/block/{userId}              → BlockUserAsync
DELETE /connections/block/{userId}              → UnblockUserAsync
GET    /connections/blocked                     → GetBlockedUsersAsync

GET    /connections/mutual/{userId}             → GetMutualConnectionsAsync
GET    /connections/suggestions                 → GetSuggestionsAsync
GET    /connections/network-depth/{userId}      → GetNetworkDepthAsync
GET    /connections/strength/{userId}           → GetConnectionStrengthAsync

GET    /connections/config                      → GetConfigAsync
PUT    /connections/config                      → UpdateConfigAsync
```

## Abstraction Extraction Prompt
> When implementing this skill, identify patterns that could be reused: the graph traversal engine could become a generic `IGraphTraversal<T>` interface. The strength calculator could become a generic `ICompositeScoreCalculator` pattern. The request lifecycle FSM could become a reusable `IStateMachine<TState, TEvent>`. Extract these as shared utilities if you see 2+ services needing similar patterns.
