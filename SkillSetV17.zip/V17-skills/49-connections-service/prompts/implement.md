# Skill 49: Connection Service — Implementation Prompt

## Context
You are implementing the Connection Service for the XIIGen platform. This service manages social graph connections between users: friend requests, accept/reject/block, connection strength calculation, and graph traversal for network analysis.

## Prerequisites
- Skill 01 (Core Interfaces): IDatabaseService, IQueueService, DataProcessResult<T>
- Skill 03 (Elasticsearch): Document storage with BuildSearchFilter
- Skill 04 (Redis Queue): Event publishing via Redis Streams
- Skill 43 (Calculator Metrics): Weight/score computation patterns
- Skill 47 (Matching Service): Match score as strength factor input

## Step-by-Step Implementation

### Step 1: Create Elasticsearch Indices
```
PUT connections       — connectionId, fromUserId, toUserId, type, status, strength, strengthFactors{}, metadata{}
PUT connection-requests — requestId, fromUserId, toUserId, status (pending/accepted/rejected/cancelled/expired), metadata{}
PUT connection-blocks   — blockId, blockerId, blockedId, createdAt
PUT connection-config   — configId, scopeId, settings (autoAcceptThreshold, maxTraversalDepth, strengthWeights, etc.)
```

### Step 2: Implement Request State Machine
Valid transitions from PENDING only:
- PENDING → ACCEPTED (toUser only)
- PENDING → REJECTED (toUser only)
- PENDING → CANCELLED (fromUser only)
- PENDING → EXPIRED (system, check expiresAt)

All other transitions must be rejected.

### Step 3: Implement Core Connection CRUD
1. `SendRequestAsync(fromUserId, toUserId, metadata)` — Validate no existing connection, no blocks, no pending request. Create request doc. Check auto-accept threshold.
2. `AcceptRequestAsync(requestId, acceptingUserId)` — Validate recipient, validate pending status, check expiration. Create connection doc with initial strength 0.0.
3. `RejectRequestAsync / CancelRequestAsync` — Similar pattern with appropriate user validation.
4. `GetConnectionsAsync(userId, page, pageSize, type?, minStrength?)` — Use BuildSearchFilter with `_or_userId` for bidirectional query.
5. `RemoveConnectionAsync(connectionId, userId)` — Validate participant, delete doc, publish event.

### Step 4: Implement Block System
1. `BlockUserAsync(blockerId, blockedId)` — Create block doc + remove all existing connections between users. Bidirectional enforcement.
2. `IsBlockedAsync(userA, userB)` — Check BOTH directions (A blocks B OR B blocks A).
3. All other operations must check `IsBlocked` before proceeding.

### Step 5: Implement Graph Traversal (BFS)
```
function getConnectionsAtDepth(userId, targetDepth, maxDepth):
    visited = {userId}
    currentLevel = [userId]
    for depth = 0 to min(targetDepth, maxDepth):
        nextLevel = []
        for each uid in currentLevel:
            connections = query(filter: _or_userId=uid, status=accepted)
            for each conn in connections:
                peer = getPeerId(conn, uid)
                if peer NOT in visited:
                    visited.add(peer)
                    nextLevel.add(peer)
                    if depth+1 == targetDepth: results.add(peer)
        currentLevel = nextLevel
    return results
```

### Step 6: Implement Strength Calculator
Composite score with configurable weights:
- matchScore (30%) — from Matching Service, normalize 0-1
- sharedGroups (20%) — count / 10, cap at 1.0
- coAttendedEvents (20%) — count / 5, cap at 1.0
- messageFrequency (15%) — normalize 0-1
- profileSimilarity (15%) — normalize 0-1

Formula: `strength = Σ(normalize(factor) × weight) / Σ(weights)`

### Step 7: Wire Events
**Publish:** FriendRequestSent, FriendRequestAccepted, FriendRequestRejected, UserBlocked, UserUnblocked, ConnectionRemoved, ConnectionStrengthUpdated
**Subscribe to:** MatchScoreUpdated, EventAttended, GroupJoined, MessageSent → trigger strength recalculation

### Step 8: Register DI & Test
Register service in DI container. Write tests covering:
- Happy path: request → accept → strength calc
- Duplicate prevention (both directions)
- Block enforcement (bidirectional)
- Expired request handling
- Graph traversal with 3+ depth levels
- Batch strength recalculation

## DNA Compliance Checklist
- [ ] All data stored as Dictionary<string,object> (no typed models for user data)
- [ ] BuildSearchFilter with empty-field skipping
- [ ] DataProcessResult<T> for all public methods
- [ ] Scope isolation (users see only their connections)
- [ ] MACHINE vs FREEDOM classification documented
- [ ] Events published for all state changes
- [ ] Configuration as dynamic document in Elasticsearch
