<?php
/**
 * Skill 49: Connection Service — PHP Implementation
 * DNA-compliant social graph management with dynamic documents
 * 
 * Requires: PHP 8.3+, ext-json
 * Interfaces: IDatabaseService, IQueueService from Skill 01
 */

declare(strict_types=1);

namespace XIIGen\Connections;

use XIIGen\Core\IDatabaseService;
use XIIGen\Core\IQueueService;
use XIIGen\Core\DataProcessResult;

// ─── Configuration ───────────────────────────────────────────────

class ConnectionConfig
{
    public function __construct(
        public string $connectionsIndex = 'connections',
        public string $requestsIndex = 'connection-requests',
        public string $blocksIndex = 'connection-blocks',
        public string $configIndex = 'connection-config',
        public int $defaultPageSize = 20,
        public int $requestExpirationDays = 30,
        public float $autoAcceptThreshold = 0.0,
        public int $maxTraversalDepth = 3,
        public int $maxConnectionsPerUser = 5000,
    ) {}
}

// ─── Request Status FSM ──────────────────────────────────────────

class RequestStatus
{
    public const PENDING   = 'pending';
    public const ACCEPTED  = 'accepted';
    public const REJECTED  = 'rejected';
    public const CANCELLED = 'cancelled';
    public const EXPIRED   = 'expired';
}

// ─── Default Strength Weights ────────────────────────────────────

class DefaultStrengthWeights
{
    public const WEIGHTS = [
        'matchScore'        => 0.30,
        'sharedGroups'      => 0.20,
        'coAttendedEvents'  => 0.20,
        'messageFrequency'  => 0.15,
        'profileSimilarity' => 0.15,
    ];
}

// ─── Connection Strength Calculator ──────────────────────────────

class ConnectionStrengthCalculator
{
    /** @param array<string, float> $weights */
    public function __construct(
        private array $weights = DefaultStrengthWeights::WEIGHTS
    ) {}

    /** @param array<string, mixed> $factors */
    public function calculate(array $factors): float
    {
        $totalWeight = 0.0;
        $weightedSum = 0.0;

        foreach ($this->weights as $factor => $weight) {
            $raw = (float) ($factors[$factor] ?? 0.0);
            $normalized = $this->normalize($factor, $raw);
            $weightedSum += $normalized * $weight;
            $totalWeight += $weight;
        }

        return $totalWeight > 0 ? round($weightedSum / $totalWeight, 4) : 0.0;
    }

    private function normalize(string $factor, float $raw): float
    {
        return match ($factor) {
            'sharedGroups'      => min($raw / 10.0, 1.0),
            'coAttendedEvents'  => min($raw / 5.0, 1.0),
            default             => max(0.0, min($raw, 1.0)),
        };
    }
}

// ─── Graph Traversal Engine ──────────────────────────────────────

class GraphTraversal
{
    public function __construct(
        private IDatabaseService $db,
        private string $index,
    ) {}

    /**
     * BFS traversal to find connections at specific depth
     * @return string[]
     */
    public function getConnectionsAtDepth(string $userId, int $depth, int $maxDepth): array
    {
        $visited = [$userId => true];
        $currentLevel = [$userId];
        $results = [];

        for ($d = 0; $d < min($depth, $maxDepth); $d++) {
            $nextLevel = [];
            foreach ($currentLevel as $uid) {
                $filter = [
                    '_or_userId' => ['fromUserId' => $uid, 'toUserId' => $uid],
                    'status' => 'accepted',
                ];
                $docs = $this->db->searchDocuments($this->index, $filter);

                foreach ($docs as $conn) {
                    $peer = $this->getPeerId($conn, $uid);
                    if ($peer && !isset($visited[$peer])) {
                        $visited[$peer] = true;
                        $nextLevel[] = $peer;
                        if ($d + 1 === $depth) {
                            $results[] = $peer;
                        }
                    }
                }
            }
            $currentLevel = $nextLevel;
            if (empty($currentLevel)) {
                break;
            }
        }

        return $results;
    }

    /**
     * Find mutual connections between two users
     * @return string[]
     */
    public function getMutualConnections(string $userA, string $userB): array
    {
        $connectionsA = $this->getDirectConnections($userA);
        $connectionsB = $this->getDirectConnections($userB);

        return array_values(array_intersect($connectionsA, $connectionsB));
    }

    /** @return string[] */
    private function getDirectConnections(string $userId): array
    {
        $filter = [
            '_or_userId' => ['fromUserId' => $userId, 'toUserId' => $userId],
            'status' => 'accepted',
        ];
        $docs = $this->db->searchDocuments($this->index, $filter);
        $peers = [];

        foreach ($docs as $conn) {
            $peer = $this->getPeerId($conn, $userId);
            if ($peer) {
                $peers[] = $peer;
            }
        }

        return $peers;
    }

    /**
     * Shortest path length between two users (-1 if not connected)
     */
    public function getShortestPath(string $fromId, string $toId, int $maxDepth): int
    {
        $visited = [$fromId => true];
        $currentLevel = [$fromId];

        for ($depth = 1; $depth <= $maxDepth; $depth++) {
            $nextLevel = [];
            foreach ($currentLevel as $uid) {
                $filter = [
                    '_or_userId' => ['fromUserId' => $uid, 'toUserId' => $uid],
                    'status' => 'accepted',
                ];
                $docs = $this->db->searchDocuments($this->index, $filter);

                foreach ($docs as $conn) {
                    $peer = $this->getPeerId($conn, $uid);
                    if ($peer === $toId) {
                        return $depth;
                    }
                    if ($peer && !isset($visited[$peer])) {
                        $visited[$peer] = true;
                        $nextLevel[] = $peer;
                    }
                }
            }
            $currentLevel = $nextLevel;
            if (empty($currentLevel)) {
                break;
            }
        }

        return -1;
    }

    private function getPeerId(array $conn, string $userId): ?string
    {
        $from = $conn['fromUserId'] ?? null;
        $to = $conn['toUserId'] ?? null;

        return ($from === $userId) ? $to : (($to === $userId) ? $from : null);
    }
}

// ─── Connection Service ──────────────────────────────────────────

class ConnectionService
{
    private ConnectionStrengthCalculator $strengthCalc;
    private GraphTraversal $graph;

    public function __construct(
        private IDatabaseService $db,
        private IQueueService $queue,
        private ConnectionConfig $config = new ConnectionConfig(),
    ) {
        $this->strengthCalc = new ConnectionStrengthCalculator();
        $this->graph = new GraphTraversal($db, $config->connectionsIndex);
    }

    // ── Connection Requests ──────────────────────────────────────

    public function sendRequest(string $fromUserId, string $toUserId, array $metadata = []): DataProcessResult
    {
        try {
            if ($fromUserId === $toUserId) {
                return DataProcessResult::failure('Cannot connect with yourself');
            }
            if ($this->isBlocked($fromUserId, $toUserId)->data) {
                return DataProcessResult::failure('User is blocked');
            }

            // Check existing connection
            $existingFilter = [
                '_or_direction' => [
                    ['fromUserId' => $fromUserId, 'toUserId' => $toUserId],
                    ['fromUserId' => $toUserId, 'toUserId' => $fromUserId],
                ],
                'status' => 'accepted',
            ];
            $existing = $this->db->searchDocuments($this->config->connectionsIndex, $existingFilter);
            if (!empty($existing)) {
                return DataProcessResult::failure('Already connected');
            }

            // Check pending request
            $pendingFilter = [
                '_or_direction' => [
                    ['fromUserId' => $fromUserId, 'toUserId' => $toUserId],
                    ['fromUserId' => $toUserId, 'toUserId' => $fromUserId],
                ],
                'status' => RequestStatus::PENDING,
            ];
            $pendingDocs = $this->db->searchDocuments($this->config->requestsIndex, $pendingFilter);
            if (!empty($pendingDocs)) {
                return DataProcessResult::failure('Request already pending');
            }

            $requestId = 'req_' . bin2hex(random_bytes(12));
            $now = gmdate('Y-m-d\TH:i:s\Z');

            $request = [
                'requestId'  => $requestId,
                'fromUserId' => $fromUserId,
                'toUserId'   => $toUserId,
                'status'     => RequestStatus::PENDING,
                'metadata'   => $metadata,
                'createdAt'  => $now,
                'expiresAt'  => gmdate('Y-m-d\TH:i:s\Z', time() + $this->config->requestExpirationDays * 86400),
            ];

            $this->db->saveDocument($this->config->requestsIndex, $request);

            // Auto-accept if match score meets threshold
            $matchScore = (float) ($metadata['matchScore'] ?? 0.0);
            if ($this->config->autoAcceptThreshold > 0 && $matchScore >= $this->config->autoAcceptThreshold) {
                return $this->acceptRequest($requestId, $toUserId);
            }

            $this->queue->publish('connection.events', [
                'type'    => 'FriendRequestSent',
                'payload' => $request,
            ]);

            return DataProcessResult::success($request);
        } catch (\Throwable $e) {
            return DataProcessResult::failure('SendRequest failed: ' . $e->getMessage());
        }
    }

    public function acceptRequest(string $requestId, string $acceptingUserId): DataProcessResult
    {
        try {
            $request = $this->db->getDocument($this->config->requestsIndex, $requestId);
            if (!$request) {
                return DataProcessResult::failure('Request not found');
            }
            if ($request['toUserId'] !== $acceptingUserId) {
                return DataProcessResult::failure('Only recipient can accept');
            }
            if ($request['status'] !== RequestStatus::PENDING) {
                return DataProcessResult::failure("Cannot accept request in '{$request['status']}' status");
            }

            // Check expiration
            $expiresAt = strtotime($request['expiresAt'] ?? '');
            if ($expiresAt && $expiresAt < time()) {
                $request['status'] = RequestStatus::EXPIRED;
                $this->db->saveDocument($this->config->requestsIndex, $request);
                return DataProcessResult::failure('Request has expired');
            }

            $request['status'] = RequestStatus::ACCEPTED;
            $request['acceptedAt'] = gmdate('Y-m-d\TH:i:s\Z');
            $this->db->saveDocument($this->config->requestsIndex, $request);

            // Create connection
            $connectionId = 'conn_' . bin2hex(random_bytes(12));
            $now = gmdate('Y-m-d\TH:i:s\Z');

            $connection = [
                'connectionId'  => $connectionId,
                'fromUserId'    => $request['fromUserId'],
                'toUserId'      => $request['toUserId'],
                'type'          => $request['metadata']['connectionType'] ?? 'friend',
                'status'        => 'accepted',
                'strength'      => 0.0,
                'strengthFactors' => [],
                'metadata'      => $request['metadata'] ?? [],
                'createdAt'     => $now,
                'updatedAt'     => $now,
            ];

            $this->db->saveDocument($this->config->connectionsIndex, $connection);

            $this->queue->publish('connection.events', [
                'type'    => 'FriendRequestAccepted',
                'payload' => $connection,
            ]);

            return DataProcessResult::success($connection);
        } catch (\Throwable $e) {
            return DataProcessResult::failure('AcceptRequest failed: ' . $e->getMessage());
        }
    }

    public function rejectRequest(string $requestId, string $rejectingUserId): DataProcessResult
    {
        try {
            $request = $this->db->getDocument($this->config->requestsIndex, $requestId);
            if (!$request) {
                return DataProcessResult::failure('Request not found');
            }
            if ($request['toUserId'] !== $rejectingUserId) {
                return DataProcessResult::failure('Only recipient can reject');
            }
            if ($request['status'] !== RequestStatus::PENDING) {
                return DataProcessResult::failure("Cannot reject from '{$request['status']}' status");
            }

            $request['status'] = RequestStatus::REJECTED;
            $request['rejectedAt'] = gmdate('Y-m-d\TH:i:s\Z');
            $this->db->saveDocument($this->config->requestsIndex, $request);

            $this->queue->publish('connection.events', [
                'type'    => 'FriendRequestRejected',
                'payload' => $request,
            ]);

            return DataProcessResult::success($request);
        } catch (\Throwable $e) {
            return DataProcessResult::failure('RejectRequest failed: ' . $e->getMessage());
        }
    }

    // ── Connection Management ────────────────────────────────────

    public function getConnections(
        string $userId,
        int $page = 0,
        int $pageSize = 0,
        ?string $type = null,
        ?float $minStrength = null,
    ): DataProcessResult {
        try {
            $size = $pageSize > 0 ? $pageSize : $this->config->defaultPageSize;
            $filter = [
                '_or_userId' => ['fromUserId' => $userId, 'toUserId' => $userId],
                'status' => 'accepted',
            ];
            if ($type !== null) {
                $filter['type'] = $type;
            }
            if ($minStrength !== null) {
                $filter['_gte_strength'] = $minStrength;
            }

            $all = $this->db->searchDocuments($this->config->connectionsIndex, $filter);
            $total = count($all);
            $items = array_slice($all, $page * $size, $size);

            return DataProcessResult::success([
                'items'      => $items,
                'total'      => $total,
                'page'       => $page,
                'pageSize'   => $size,
                'totalPages' => (int) ceil($total / $size),
            ]);
        } catch (\Throwable $e) {
            return DataProcessResult::failure('GetConnections failed: ' . $e->getMessage());
        }
    }

    public function removeConnection(string $connectionId, string $userId): DataProcessResult
    {
        try {
            $conn = $this->db->getDocument($this->config->connectionsIndex, $connectionId);
            if (!$conn) {
                return DataProcessResult::failure('Connection not found');
            }
            if ($conn['fromUserId'] !== $userId && $conn['toUserId'] !== $userId) {
                return DataProcessResult::failure('Not a participant');
            }

            $this->db->deleteDocument($this->config->connectionsIndex, $connectionId);

            $this->queue->publish('connection.events', [
                'type'    => 'ConnectionRemoved',
                'payload' => $conn,
            ]);

            return DataProcessResult::success(['removed' => $connectionId]);
        } catch (\Throwable $e) {
            return DataProcessResult::failure('RemoveConnection failed: ' . $e->getMessage());
        }
    }

    // ── Blocking ─────────────────────────────────────────────────

    public function blockUser(string $blockerId, string $blockedId): DataProcessResult
    {
        try {
            if ($blockerId === $blockedId) {
                return DataProcessResult::failure('Cannot block yourself');
            }

            $blockDoc = [
                'blockId'   => 'blk_' . bin2hex(random_bytes(12)),
                'blockerId' => $blockerId,
                'blockedId' => $blockedId,
                'createdAt' => gmdate('Y-m-d\TH:i:s\Z'),
            ];
            $this->db->saveDocument($this->config->blocksIndex, $blockDoc);

            // Remove existing connections between users
            $filter = [
                '_or_direction' => [
                    ['fromUserId' => $blockerId, 'toUserId' => $blockedId],
                    ['fromUserId' => $blockedId, 'toUserId' => $blockerId],
                ],
            ];
            $existing = $this->db->searchDocuments($this->config->connectionsIndex, $filter);
            foreach ($existing as $conn) {
                $this->db->deleteDocument($this->config->connectionsIndex, $conn['connectionId']);
            }

            $this->queue->publish('connection.events', [
                'type'    => 'UserBlocked',
                'payload' => $blockDoc,
            ]);

            return DataProcessResult::success($blockDoc);
        } catch (\Throwable $e) {
            return DataProcessResult::failure('BlockUser failed: ' . $e->getMessage());
        }
    }

    public function unblockUser(string $blockerId, string $blockedId): DataProcessResult
    {
        try {
            $filter = ['blockerId' => $blockerId, 'blockedId' => $blockedId];
            $blocks = $this->db->searchDocuments($this->config->blocksIndex, $filter);

            foreach ($blocks as $block) {
                $this->db->deleteDocument($this->config->blocksIndex, $block['blockId']);
            }

            $this->queue->publish('connection.events', [
                'type'    => 'UserUnblocked',
                'payload' => ['blockerId' => $blockerId, 'blockedId' => $blockedId],
            ]);

            return DataProcessResult::success(['unblocked' => $blockedId]);
        } catch (\Throwable $e) {
            return DataProcessResult::failure('UnblockUser failed: ' . $e->getMessage());
        }
    }

    public function isBlocked(string $userA, string $userB): DataProcessResult
    {
        try {
            // Bidirectional check
            $filterAB = ['blockerId' => $userA, 'blockedId' => $userB];
            $filterBA = ['blockerId' => $userB, 'blockedId' => $userA];

            $blocksAB = $this->db->searchDocuments($this->config->blocksIndex, $filterAB);
            $blocksBA = $this->db->searchDocuments($this->config->blocksIndex, $filterBA);

            return DataProcessResult::success(!empty($blocksAB) || !empty($blocksBA));
        } catch (\Throwable $e) {
            return DataProcessResult::failure('IsBlocked failed: ' . $e->getMessage());
        }
    }

    // ── Graph Operations ─────────────────────────────────────────

    public function getMutualConnections(string $userA, string $userB): DataProcessResult
    {
        try {
            $mutuals = $this->graph->getMutualConnections($userA, $userB);
            return DataProcessResult::success($mutuals);
        } catch (\Throwable $e) {
            return DataProcessResult::failure('GetMutualConnections failed: ' . $e->getMessage());
        }
    }

    public function getSuggestions(string $userId, int $limit = 10): DataProcessResult
    {
        try {
            // Get friend-of-friend (depth 2)
            $candidates = $this->graph->getConnectionsAtDepth($userId, 2, $this->config->maxTraversalDepth);

            // Score by mutual connection count
            $scored = [];
            foreach (array_slice($candidates, 0, 50) as $candidateId) {
                if ($this->isBlocked($userId, $candidateId)->data) {
                    continue;
                }
                $mutuals = $this->graph->getMutualConnections($userId, $candidateId);
                $scored[] = [
                    'userId'          => $candidateId,
                    'mutualCount'     => count($mutuals),
                    'mutualUserIds'   => array_slice($mutuals, 0, 5),
                ];
            }

            usort($scored, fn(array $a, array $b) => $b['mutualCount'] <=> $a['mutualCount']);

            return DataProcessResult::success(array_slice($scored, 0, $limit));
        } catch (\Throwable $e) {
            return DataProcessResult::failure('GetSuggestions failed: ' . $e->getMessage());
        }
    }

    public function getNetworkDepth(string $fromUserId, string $toUserId): DataProcessResult
    {
        try {
            $depth = $this->graph->getShortestPath($fromUserId, $toUserId, $this->config->maxTraversalDepth);
            return DataProcessResult::success($depth);
        } catch (\Throwable $e) {
            return DataProcessResult::failure('GetNetworkDepth failed: ' . $e->getMessage());
        }
    }

    // ── Strength Calculation ─────────────────────────────────────

    public function recalculateStrength(string $connectionId): DataProcessResult
    {
        try {
            $conn = $this->db->getDocument($this->config->connectionsIndex, $connectionId);
            if (!$conn) {
                return DataProcessResult::failure('Connection not found');
            }

            $factors = $conn['strengthFactors'] ?? [];
            $oldStrength = (float) ($conn['strength'] ?? 0.0);
            $newStrength = $this->strengthCalc->calculate($factors);

            $conn['strength'] = $newStrength;
            $conn['updatedAt'] = gmdate('Y-m-d\TH:i:s\Z');
            $this->db->saveDocument($this->config->connectionsIndex, $conn);

            if (abs($newStrength - $oldStrength) > 0.1) {
                $this->queue->publish('connection.events', [
                    'type'    => 'ConnectionStrengthUpdated',
                    'payload' => [
                        'connectionId' => $connectionId,
                        'oldStrength'  => $oldStrength,
                        'newStrength'  => $newStrength,
                    ],
                ]);
            }

            return DataProcessResult::success($conn);
        } catch (\Throwable $e) {
            return DataProcessResult::failure('RecalculateStrength failed: ' . $e->getMessage());
        }
    }

    /**
     * Batch recalculate strength for all connections of a user
     * @return DataProcessResult with array of results
     */
    public function batchRecalculate(string $userId): DataProcessResult
    {
        try {
            $filter = [
                '_or_userId' => ['fromUserId' => $userId, 'toUserId' => $userId],
                'status' => 'accepted',
            ];
            $connections = $this->db->searchDocuments($this->config->connectionsIndex, $filter);

            $results = [];
            foreach ($connections as $conn) {
                $result = $this->recalculateStrength($conn['connectionId']);
                $results[] = [
                    'connectionId' => $conn['connectionId'],
                    'success'      => $result->isSuccess,
                    'strength'     => $result->isSuccess ? ($result->data['strength'] ?? 0) : null,
                ];
            }

            return DataProcessResult::success($results);
        } catch (\Throwable $e) {
            return DataProcessResult::failure('BatchRecalculate failed: ' . $e->getMessage());
        }
    }
}
