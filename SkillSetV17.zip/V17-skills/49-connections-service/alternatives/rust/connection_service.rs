// XIIGen Connection Service — Skill 49 | Rust Alternative
// Social graph: friend requests, connections, blocking, strength calc, graph traversal
// Genie DNA: DNA-1 (HashMap<String,Value>), DNA-2 (build_search_filter), DNA-5 (DataProcessResult)

use std::collections::{HashMap, HashSet};
use chrono::{Utc, Duration};
use serde_json::Value;
use uuid::Uuid;

type Doc = HashMap<String, Value>;

// ─── Configuration ──────────────────────────────────────────────
#[derive(Clone)]
pub struct ConnectionConfig {
    pub connections_index: String,
    pub requests_index: String,
    pub blocked_index: String,
    pub config_index: String,
    pub default_page_size: usize,
    pub request_expiration_days: i64,
    pub max_traversal_depth: usize,
    pub suggestion_limit: usize,
    pub auto_accept_min_match_score: f64,
}

impl Default for ConnectionConfig {
    fn default() -> Self {
        Self {
            connections_index: "connections".into(),
            requests_index: "connection-requests".into(),
            blocked_index: "blocked-users".into(),
            config_index: "connection-config".into(),
            default_page_size: 20,
            request_expiration_days: 30,
            max_traversal_depth: 3,
            suggestion_limit: 50,
            auto_accept_min_match_score: 0.8,
        }
    }
}

// ─── Connection Page ────────────────────────────────────────────
pub struct ConnectionPage {
    pub items: Vec<Doc>,
    pub cursor: Option<String>,
    pub total_count: usize,
    pub has_more: bool,
}

// ─── DataProcessResult (DNA-5) ─────────────────────────────────
pub struct DataProcessResult<T> {
    pub is_success: bool,
    pub data: Option<T>,
    pub error: Option<String>,
}

impl<T> DataProcessResult<T> {
    pub fn success(data: T) -> Self { Self { is_success: true, data: Some(data), error: None } }
    pub fn failure(err: &str) -> Self { Self { is_success: false, data: None, error: Some(err.to_string()) } }
}

// ─── Request Status FSM (MACHINE) ──────────────────────────────
pub mod request_status {
    pub const PENDING: &str = "pending";
    pub const ACCEPTED: &str = "accepted";
    pub const REJECTED: &str = "rejected";
    pub const EXPIRED: &str = "expired";
    pub const CANCELLED: &str = "cancelled";

    pub fn can_transition(from: &str, to: &str) -> bool {
        matches!((from, to),
            ("pending", "accepted") | ("pending", "rejected") |
            ("pending", "cancelled") | ("pending", "expired"))
    }
}

// ─── Strength Calculator (MACHINE logic, FREEDOM weights) ──────
pub struct ConnectionStrengthCalculator;

impl ConnectionStrengthCalculator {
    const FACTOR_DEFS: [(&'static str, &'static str, f64); 5] = [
        ("matchScore", "matchScoreWeight", 0.30),
        ("sharedGroups", "sharedGroupsWeight", 0.20),
        ("coAttendedEvents", "coAttendedEventsWeight", 0.20),
        ("messageFrequency", "messageFrequencyWeight", 0.15),
        ("profileSimilarity", "profileSimilarityWeight", 0.15),
    ];

    pub fn calculate(&self, factors: &Doc, weights: &Doc) -> f64 {
        let mut total = 0.0_f64;
        let mut weight_sum = 0.0_f64;
        for &(key, weight_key, default_w) in &Self::FACTOR_DEFS {
            let factor_val = Self::normalize(key, get_f64(factors, key, 0.0));
            let weight = get_f64(weights, weight_key, default_w);
            total += factor_val * weight;
            weight_sum += weight;
        }
        if weight_sum > 0.0 { (total / weight_sum).clamp(0.0, 1.0) } else { 0.0 }
    }

    fn normalize(key: &str, raw: f64) -> f64 {
        match key {
            "sharedGroups" => (raw / 10.0).min(1.0),
            "coAttendedEvents" => (raw / 5.0).min(1.0),
            _ => raw.clamp(0.0, 1.0),
        }
    }
}

// ─── Graph Traversal Engine (MACHINE) ──────────────────────────
pub struct GraphTraversal<'a> {
    db: &'a dyn IDatabaseService,
    connections_index: String,
}

impl<'a> GraphTraversal<'a> {
    pub fn new(db: &'a dyn IDatabaseService, idx: &str) -> Self {
        Self { db, connections_index: idx.to_string() }
    }

    pub async fn get_user_ids_at_depth(&self, user_id: &str, depth: usize, max_results: usize) -> Vec<String> {
        if depth < 1 { return vec![]; }
        let mut visited: HashSet<String> = HashSet::from([user_id.to_string()]);
        let mut current_level: HashSet<String> = HashSet::from([user_id.to_string()]);
        let mut results: Vec<String> = Vec::new();

        for d in 0..depth {
            let mut next_level: HashSet<String> = HashSet::new();
            for uid in &current_level {
                let filter = build_conn_filter(uid, "accepted");
                if let Ok(conns) = self.db.query(&self.connections_index, &filter).await {
                    for conn in &conns {
                        if let Some(peer) = get_peer_id(conn, uid) {
                            if visited.insert(peer.clone()) {
                                next_level.insert(peer.clone());
                                if d == depth - 1 {
                                    results.push(peer);
                                    if results.len() >= max_results { return results; }
                                }
                            }
                        }
                    }
                }
            }
            current_level = next_level;
            if current_level.is_empty() { break; }
        }
        results
    }

    pub async fn get_mutual_connections(&self, user_a: &str, user_b: &str) -> Vec<Doc> {
        let conns_a = self.db.query(&self.connections_index, &build_conn_filter(user_a, "accepted")).await.unwrap_or_default();
        let conns_b = self.db.query(&self.connections_index, &build_conn_filter(user_b, "accepted")).await.unwrap_or_default();
        let peers_a: HashSet<String> = conns_a.iter().filter_map(|c| get_peer_id(c, user_a)).collect();
        let peers_b: HashSet<String> = conns_b.iter().filter_map(|c| get_peer_id(c, user_b)).collect();
        let mutual: HashSet<&String> = peers_a.intersection(&peers_b).collect();
        conns_a.into_iter().filter(|c| get_peer_id(c, user_a).map_or(false, |p| mutual.contains(&p))).collect()
    }

    pub async fn get_shortest_path(&self, from: &str, to: &str, max_depth: usize) -> i32 {
        if from == to { return 0; }
        let mut visited = HashSet::from([from.to_string()]);
        let mut current: HashSet<String> = HashSet::from([from.to_string()]);
        for depth in 1..=max_depth {
            let mut next: HashSet<String> = HashSet::new();
            for uid in &current {
                if let Ok(conns) = self.db.query(&self.connections_index, &build_conn_filter(uid, "accepted")).await {
                    for conn in &conns {
                        if let Some(peer) = get_peer_id(conn, uid) {
                            if peer == to { return depth as i32; }
                            if visited.insert(peer.clone()) { next.insert(peer); }
                        }
                    }
                }
            }
            current = next;
            if current.is_empty() { break; }
        }
        -1
    }
}

// ─── Main Connection Service ───────────────────────────────────
pub struct ConnectionService<'a> {
    db: &'a dyn IDatabaseService,
    queue: &'a dyn IQueueService,
    processor: &'a dyn IObjectProcessor,
    config: ConnectionConfig,
    strength_calc: ConnectionStrengthCalculator,
}

impl<'a> ConnectionService<'a> {
    pub fn new(db: &'a dyn IDatabaseService, queue: &'a dyn IQueueService, processor: &'a dyn IObjectProcessor, config: Option<ConnectionConfig>) -> Self {
        Self { db, queue, processor, config: config.unwrap_or_default(), strength_calc: ConnectionStrengthCalculator }
    }

    pub async fn send_request(&self, data: Doc) -> DataProcessResult<Doc> {
        let parsed = self.processor.parse_object_alternative(&data);
        let from = get_str(&parsed, "fromUserId");
        let to = get_str(&parsed, "toUserId");
        if from.is_empty() || to.is_empty() { return DataProcessResult::failure("fromUserId and toUserId required"); }
        if from == to { return DataProcessResult::failure("Cannot request yourself"); }
        if self.is_blocked_internal(&from, &to).await { return DataProcessResult::failure("User not available"); }
        if self.find_existing(&from, &to).await.is_some() { return DataProcessResult::failure("Already connected"); }
        if self.find_pending(&from, &to).await.is_some() { return DataProcessResult::failure("Request already pending"); }

        let req_id = format!("req_{}", Uuid::new_v4().simple());
        let now = Utc::now();
        let mut request = Doc::new();
        request.insert("requestId".into(), Value::String(req_id.clone()));
        request.insert("fromUserId".into(), Value::String(from.clone()));
        request.insert("toUserId".into(), Value::String(to.clone()));
        request.insert("type".into(), Value::String(get_str(&parsed, "type").unwrap_or("friend".into())));
        request.insert("status".into(), Value::String(request_status::PENDING.into()));
        request.insert("createdAt".into(), Value::String(now.to_rfc3339()));
        request.insert("expiresAt".into(), Value::String((now + Duration::days(self.config.request_expiration_days)).to_rfc3339()));
        request.insert("scopeId".into(), Value::String(get_str(&parsed, "scopeId").unwrap_or("default".into())));
        for (k, v) in &parsed { request.entry(k.clone()).or_insert(v.clone()); }

        let _ = self.db.upsert(&self.config.requests_index, &req_id, &request).await;
        let _ = self.queue.publish("connection-events", &doc_event("FriendRequestSent", &[("requestId", &req_id), ("fromUserId", &from), ("toUserId", &to)])).await;
        DataProcessResult::success(request)
    }

    pub async fn accept_request(&self, request_id: &str, accepting_uid: &str) -> DataProcessResult<Doc> {
        let req = match self.db.get_by_id(&self.config.requests_index, request_id).await {
            Ok(Some(r)) => r, _ => return DataProcessResult::failure("Request not found"),
        };
        if !request_status::can_transition(&get_str(&req, "status").unwrap_or_default(), request_status::ACCEPTED) {
            return DataProcessResult::failure("Cannot accept");
        }
        if get_str(&req, "toUserId").as_deref() != Some(accepting_uid) {
            return DataProcessResult::failure("Only target user can accept");
        }

        let mut req = req;
        req.insert("status".into(), Value::String(request_status::ACCEPTED.into()));
        req.insert("acceptedAt".into(), Value::String(Utc::now().to_rfc3339()));
        let _ = self.db.upsert(&self.config.requests_index, request_id, &req).await;

        let conn_id = format!("conn_{}", Uuid::new_v4().simple());
        let mut conn = Doc::new();
        conn.insert("connectionId".into(), Value::String(conn_id.clone()));
        conn.insert("fromUserId".into(), req.get("fromUserId").cloned().unwrap_or(Value::Null));
        conn.insert("toUserId".into(), req.get("toUserId").cloned().unwrap_or(Value::Null));
        conn.insert("type".into(), req.get("type").cloned().unwrap_or(Value::String("friend".into())));
        conn.insert("status".into(), Value::String("accepted".into()));
        conn.insert("strength".into(), Value::from(0.0_f64));
        conn.insert("strengthFactors".into(), Value::Object(serde_json::Map::new()));
        conn.insert("createdAt".into(), Value::String(Utc::now().to_rfc3339()));
        conn.insert("updatedAt".into(), Value::String(Utc::now().to_rfc3339()));
        let _ = self.db.upsert(&self.config.connections_index, &conn_id, &conn).await;

        let _ = self.queue.publish("connection-events", &doc_event("FriendRequestAccepted", &[("connectionId", &conn_id), ("requestId", request_id)])).await;
        DataProcessResult::success(conn)
    }

    pub async fn block_user(&self, blocking: &str, blocked: &str) -> DataProcessResult<Doc> {
        if blocking == blocked { return DataProcessResult::failure("Cannot block yourself"); }
        if let Some(existing) = self.find_existing(blocking, blocked).await {
            if let Some(cid) = get_str(&existing, "connectionId") {
                let _ = self.remove_connection(&cid, blocking).await;
            }
        }
        let block_id = format!("block_{}_{}", blocking, blocked);
        let mut doc = Doc::new();
        doc.insert("blockId".into(), Value::String(block_id.clone()));
        doc.insert("blockingUserId".into(), Value::String(blocking.into()));
        doc.insert("blockedUserId".into(), Value::String(blocked.into()));
        doc.insert("createdAt".into(), Value::String(Utc::now().to_rfc3339()));
        let _ = self.db.upsert(&self.config.blocked_index, &block_id, &doc).await;
        let _ = self.queue.publish("connection-events", &doc_event("ConnectionBlocked", &[("blockingUserId", blocking), ("blockedUserId", blocked)])).await;
        DataProcessResult::success(doc)
    }

    pub async fn get_connections(&self, user_id: &str, page: usize, page_size: Option<usize>) -> DataProcessResult<ConnectionPage> {
        let size = page_size.unwrap_or(self.config.default_page_size);
        let filter = build_conn_filter(user_id, "accepted");
        let all = self.db.query(&self.config.connections_index, &filter).await.unwrap_or_default();
        let blocked = self.get_blocked_ids(user_id).await;
        let mut filtered: Vec<Doc> = all.into_iter()
            .filter(|c| get_peer_id(c, user_id).map_or(false, |p| !blocked.contains(&p)))
            .collect();
        filtered.sort_by(|a, b| get_f64(b, "strength", 0.0).partial_cmp(&get_f64(a, "strength", 0.0)).unwrap());
        let total = filtered.len();
        let paged: Vec<Doc> = filtered.into_iter().skip(page * size).take(size).collect();
        DataProcessResult::success(ConnectionPage { items: paged, total_count: total, has_more: (page + 1) * size < total, cursor: if total > 0 { Some(format!("{}", page + 1)) } else { None } })
    }

    pub async fn get_mutual_connections(&self, user_a: &str, user_b: &str) -> DataProcessResult<Vec<Doc>> {
        let graph = GraphTraversal::new(self.db, &self.config.connections_index);
        DataProcessResult::success(graph.get_mutual_connections(user_a, user_b).await)
    }

    pub async fn get_suggestions(&self, user_id: &str, limit: Option<usize>) -> DataProcessResult<Vec<Doc>> {
        let graph = GraphTraversal::new(self.db, &self.config.connections_index);
        let mx = limit.unwrap_or(self.config.suggestion_limit);
        let depth2 = graph.get_user_ids_at_depth(user_id, 2, mx * 2).await;
        let mut suggestions: Vec<Doc> = Vec::new();
        for sid in depth2.iter().take(mx) {
            let mutuals = graph.get_mutual_connections(user_id, sid).await;
            let mc = mutuals.len();
            let mut s = Doc::new();
            s.insert("suggestedUserId".into(), Value::String(sid.clone()));
            s.insert("mutualCount".into(), Value::from(mc as i64));
            s.insert("score".into(), Value::from((mc as f64 / 5.0).min(1.0)));
            suggestions.push(s);
        }
        suggestions.sort_by(|a, b| get_f64(b, "score", 0.0).partial_cmp(&get_f64(a, "score", 0.0)).unwrap());
        DataProcessResult::success(suggestions)
    }

    pub async fn get_network_depth(&self, from: &str, to: &str) -> DataProcessResult<i32> {
        let graph = GraphTraversal::new(self.db, &self.config.connections_index);
        DataProcessResult::success(graph.get_shortest_path(from, to, self.config.max_traversal_depth).await)
    }

    pub async fn recalculate_strength(&self, connection_id: &str) -> DataProcessResult<Doc> {
        let mut conn = match self.db.get_by_id(&self.config.connections_index, connection_id).await {
            Ok(Some(c)) => c, _ => return DataProcessResult::failure("Not found"),
        };
        let scope = get_str(&conn, "scopeId").unwrap_or("default".into());
        let cfg = self.get_config_internal(&scope).await;
        let factors = conn.get("strengthFactors").and_then(|v| v.as_object()).map(|o| o.iter().map(|(k, v)| (k.clone(), v.clone())).collect::<Doc>()).unwrap_or_default();
        let strength = self.strength_calc.calculate(&factors, &cfg);
        conn.insert("strength".into(), Value::from(strength));
        conn.insert("updatedAt".into(), Value::String(Utc::now().to_rfc3339()));
        let _ = self.db.upsert(&self.config.connections_index, connection_id, &conn).await;
        DataProcessResult::success(conn)
    }

    pub async fn remove_connection(&self, connection_id: &str, removing_uid: &str) -> DataProcessResult<Doc> {
        let mut conn = match self.db.get_by_id(&self.config.connections_index, connection_id).await {
            Ok(Some(c)) => c, _ => return DataProcessResult::failure("Not found"),
        };
        let from = get_str(&conn, "fromUserId").unwrap_or_default();
        let to = get_str(&conn, "toUserId").unwrap_or_default();
        if from != removing_uid && to != removing_uid { return DataProcessResult::failure("Access denied"); }
        conn.insert("status".into(), Value::String("removed".into()));
        conn.insert("removedAt".into(), Value::String(Utc::now().to_rfc3339()));
        let _ = self.db.upsert(&self.config.connections_index, connection_id, &conn).await;
        DataProcessResult::success(conn)
    }

    // ─── Internal ──────────────────────────────────────────────
    async fn is_blocked_internal(&self, a: &str, b: &str) -> bool {
        self.db.get_by_id(&self.config.blocked_index, &format!("block_{}_{}", a, b)).await.ok().flatten().is_some()
        || self.db.get_by_id(&self.config.blocked_index, &format!("block_{}_{}", b, a)).await.ok().flatten().is_some()
    }

    async fn find_existing(&self, a: &str, b: &str) -> Option<Doc> {
        let mut f = Doc::new();
        f.insert("fromUserId".into(), Value::String(a.into()));
        f.insert("toUserId".into(), Value::String(b.into()));
        f.insert("status".into(), Value::String("accepted".into()));
        if let Ok(r) = self.db.query(&self.config.connections_index, &f).await { if !r.is_empty() { return Some(r[0].clone()); } }
        f.insert("fromUserId".into(), Value::String(b.into()));
        f.insert("toUserId".into(), Value::String(a.into()));
        if let Ok(r) = self.db.query(&self.config.connections_index, &f).await { if !r.is_empty() { return Some(r[0].clone()); } }
        None
    }

    async fn find_pending(&self, a: &str, b: &str) -> Option<Doc> {
        let mut f = Doc::new();
        f.insert("fromUserId".into(), Value::String(a.into()));
        f.insert("toUserId".into(), Value::String(b.into()));
        f.insert("status".into(), Value::String(request_status::PENDING.into()));
        if let Ok(r) = self.db.query(&self.config.requests_index, &f).await { if !r.is_empty() { return Some(r[0].clone()); } }
        f.insert("fromUserId".into(), Value::String(b.into()));
        f.insert("toUserId".into(), Value::String(a.into()));
        if let Ok(r) = self.db.query(&self.config.requests_index, &f).await { if !r.is_empty() { return Some(r[0].clone()); } }
        None
    }

    async fn get_config_internal(&self, scope_id: &str) -> Doc {
        if let Ok(Some(c)) = self.db.get_by_id(&self.config.config_index, &format!("conn-config-{}", scope_id)).await { return c; }
        let mut d = Doc::new();
        d.insert("autoAcceptMinMatchScore".into(), Value::from(self.config.auto_accept_min_match_score));
        d.insert("matchScoreWeight".into(), Value::from(0.30));
        d.insert("sharedGroupsWeight".into(), Value::from(0.20));
        d.insert("coAttendedEventsWeight".into(), Value::from(0.20));
        d.insert("messageFrequencyWeight".into(), Value::from(0.15));
        d.insert("profileSimilarityWeight".into(), Value::from(0.15));
        d
    }

    async fn get_blocked_ids(&self, user_id: &str) -> HashSet<String> {
        let mut blocked = HashSet::new();
        let mut f = Doc::new(); f.insert("blockingUserId".into(), Value::String(user_id.into()));
        if let Ok(r) = self.db.query(&self.config.blocked_index, &f).await { for b in r { if let Some(id) = get_str(&b, "blockedUserId") { blocked.insert(id); } } }
        f.clear(); f.insert("blockedUserId".into(), Value::String(user_id.into()));
        if let Ok(r) = self.db.query(&self.config.blocked_index, &f).await { for b in r { if let Some(id) = get_str(&b, "blockingUserId") { blocked.insert(id); } } }
        blocked
    }
}

// ─── Helpers ───────────────────────────────────────────────────
fn get_str(doc: &Doc, key: &str) -> Option<String> {
    doc.get(key).and_then(|v| v.as_str()).map(|s| s.to_string())
}

fn get_f64(doc: &Doc, key: &str, fallback: f64) -> f64 {
    doc.get(key).and_then(|v| v.as_f64()).unwrap_or(fallback)
}

fn get_peer_id(conn: &Doc, user_id: &str) -> Option<String> {
    let from = get_str(conn, "fromUserId").unwrap_or_default();
    let to = get_str(conn, "toUserId").unwrap_or_default();
    if from == user_id { Some(to) } else if to == user_id { Some(from) } else { None }
}

fn build_conn_filter(user_id: &str, status: &str) -> Doc {
    let mut f = Doc::new();
    if !user_id.is_empty() {
        let mut or = Doc::new();
        or.insert("fromUserId".into(), Value::String(user_id.into()));
        or.insert("toUserId".into(), Value::String(user_id.into()));
        f.insert("_or_userId".into(), serde_json::to_value(or).unwrap());
    }
    if !status.is_empty() { f.insert("status".into(), Value::String(status.into())); }
    f
}

fn doc_event(event_type: &str, fields: &[(&str, &str)]) -> Doc {
    let mut doc = Doc::new();
    doc.insert("eventType".into(), Value::String(event_type.into()));
    doc.insert("timestamp".into(), Value::String(Utc::now().to_rfc3339()));
    for (k, v) in fields { doc.insert(k.to_string(), Value::String(v.to_string())); }
    doc
}

// ─── Trait Interfaces (to be provided by core-interfaces) ──────
#[async_trait::async_trait]
pub trait IDatabaseService: Send + Sync {
    async fn get_by_id(&self, index: &str, id: &str) -> Result<Option<Doc>, Box<dyn std::error::Error>>;
    async fn upsert(&self, index: &str, id: &str, doc: &Doc) -> Result<(), Box<dyn std::error::Error>>;
    async fn delete(&self, index: &str, id: &str) -> Result<(), Box<dyn std::error::Error>>;
    async fn query(&self, index: &str, filter: &Doc) -> Result<Vec<Doc>, Box<dyn std::error::Error>>;
}

#[async_trait::async_trait]
pub trait IQueueService: Send + Sync {
    async fn publish(&self, channel: &str, data: &Doc) -> Result<(), Box<dyn std::error::Error>>;
}

pub trait IObjectProcessor: Send + Sync {
    fn parse_object_alternative(&self, data: &Doc) -> Doc;
}
