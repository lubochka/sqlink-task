# XIIGen Connection Service — Skill 49 | Python Alternative
# Social graph: friend requests, connections, blocking, strength calc, graph traversal
# Genie DNA: DNA-1 (Dict[str,Any]), DNA-2 (build_search_filter), DNA-5 (DataProcessResult)

from __future__ import annotations
import uuid
from datetime import datetime, timedelta, timezone
from dataclasses import dataclass, field
from typing import Any, Optional
from collections import deque

Doc = dict[str, Any]


@dataclass
class ConnectionConfig:
    connections_index: str = "connections"
    requests_index: str = "connection-requests"
    blocked_index: str = "blocked-users"
    config_index: str = "connection-config"
    default_page_size: int = 20
    request_expiration_days: int = 30
    max_traversal_depth: int = 3
    suggestion_limit: int = 50
    auto_accept_min_match_score: float = 0.8


@dataclass
class ConnectionPage:
    items: list[Doc] = field(default_factory=list)
    cursor: Optional[str] = None
    total_count: int = 0
    has_more: bool = False


@dataclass
class DataProcessResult:
    is_success: bool
    data: Any = None
    error: Optional[str] = None

    @classmethod
    def success(cls, data: Any) -> DataProcessResult:
        return cls(is_success=True, data=data)

    @classmethod
    def failure(cls, error: str) -> DataProcessResult:
        return cls(is_success=False, error=error)


# ─── Request Status FSM (MACHINE) ──────────────────────────────
class RequestStatus:
    PENDING = "pending"
    ACCEPTED = "accepted"
    REJECTED = "rejected"
    EXPIRED = "expired"
    CANCELLED = "cancelled"

    @staticmethod
    def can_transition(from_status: str, to_status: str) -> bool:
        if from_status != RequestStatus.PENDING:
            return False
        return to_status in (
            RequestStatus.ACCEPTED, RequestStatus.REJECTED,
            RequestStatus.CANCELLED, RequestStatus.EXPIRED,
        )


# ─── Default Weights (FREEDOM — admin-configurable) ────────────
DEFAULT_WEIGHTS = {
    "match_score_weight": 0.30,
    "shared_groups_weight": 0.20,
    "co_attended_events_weight": 0.20,
    "message_frequency_weight": 0.15,
    "profile_similarity_weight": 0.15,
}


# ─── Strength Calculator (MACHINE logic, FREEDOM weights) ──────
class ConnectionStrengthCalculator:
    FACTOR_DEFS = [
        ("match_score", "match_score_weight", 0.30),
        ("shared_groups", "shared_groups_weight", 0.20),
        ("co_attended_events", "co_attended_events_weight", 0.20),
        ("message_frequency", "message_frequency_weight", 0.15),
        ("profile_similarity", "profile_similarity_weight", 0.15),
    ]

    def calculate(self, factors: Doc, weights: Doc) -> float:
        total = 0.0
        weight_sum = 0.0
        for key, weight_key, default_w in self.FACTOR_DEFS:
            factor_val = self._normalize(key, float(factors.get(key, 0)))
            weight = float(weights.get(weight_key, default_w))
            total += factor_val * weight
            weight_sum += weight
        return max(0.0, min(1.0, total / weight_sum)) if weight_sum > 0 else 0.0

    def _normalize(self, key: str, raw: float) -> float:
        if key == "shared_groups":
            return min(raw / 10.0, 1.0)
        if key == "co_attended_events":
            return min(raw / 5.0, 1.0)
        return max(0.0, min(1.0, raw))


# ─── Graph Traversal Engine (MACHINE) ──────────────────────────
class GraphTraversal:
    def __init__(self, db, connections_index: str):
        self._db = db
        self._idx = connections_index

    async def get_user_ids_at_depth(self, user_id: str, depth: int, max_results: int) -> list[str]:
        if depth < 1:
            return []
        visited = {user_id}
        current_level = {user_id}
        results: list[str] = []
        for d in range(depth):
            next_level: set[str] = set()
            for uid in current_level:
                conns = await self._db.query(self._idx, self._filter(uid, "accepted"))
                for c in conns:
                    peer = self._peer(c, uid)
                    if peer and peer not in visited:
                        visited.add(peer)
                        next_level.add(peer)
                        if d == depth - 1:
                            results.append(peer)
                            if len(results) >= max_results:
                                return results
            current_level = next_level
            if not current_level:
                break
        return results

    async def get_mutual_connections(self, user_a: str, user_b: str) -> list[Doc]:
        conns_a = await self._db.query(self._idx, self._filter(user_a, "accepted"))
        conns_b = await self._db.query(self._idx, self._filter(user_b, "accepted"))
        peers_a = {self._peer(c, user_a) for c in conns_a} - {None}
        peers_b = {self._peer(c, user_b) for c in conns_b} - {None}
        mutual_ids = peers_a & peers_b
        return [c for c in conns_a if self._peer(c, user_a) in mutual_ids]

    async def get_shortest_path(self, from_user: str, to_user: str, max_depth: int) -> int:
        if from_user == to_user:
            return 0
        visited = {from_user}
        current_level = {from_user}
        for depth in range(1, max_depth + 1):
            next_level: set[str] = set()
            for uid in current_level:
                conns = await self._db.query(self._idx, self._filter(uid, "accepted"))
                for c in conns:
                    peer = self._peer(c, uid)
                    if peer == to_user:
                        return depth
                    if peer and peer not in visited:
                        visited.add(peer)
                        next_level.add(peer)
            current_level = next_level
            if not current_level:
                break
        return -1

    @staticmethod
    def _filter(user_id: str, status: str) -> Doc:
        f: Doc = {}
        if user_id:
            f["_or_userId"] = {"fromUserId": user_id, "toUserId": user_id}
        if status:
            f["status"] = status
        return f

    @staticmethod
    def _peer(conn: Doc, user_id: str) -> Optional[str]:
        fr = str(conn.get("fromUserId", ""))
        to = str(conn.get("toUserId", ""))
        return to if fr == user_id else (fr if to == user_id else None)


# ─── Main Connection Service ───────────────────────────────────
class ConnectionService:
    def __init__(self, db, queue, processor, config: Optional[ConnectionConfig] = None):
        self._db = db
        self._queue = queue
        self._processor = processor
        self._config = config or ConnectionConfig()
        self._strength_calc = ConnectionStrengthCalculator()
        self._graph = GraphTraversal(db, self._config.connections_index)

    # ─── Requests ───────────────────────────────────────────────

    async def send_request(self, request_data: Doc) -> DataProcessResult:
        try:
            parsed = self._processor.parse_object_alternative(request_data)
            from_uid = parsed.get("fromUserId")
            to_uid = parsed.get("toUserId")
            if not from_uid or not to_uid:
                return DataProcessResult.failure("fromUserId and toUserId required")
            if from_uid == to_uid:
                return DataProcessResult.failure("Cannot request yourself")
            if await self._is_blocked(from_uid, to_uid):
                return DataProcessResult.failure("User not available")
            if await self._find_existing(from_uid, to_uid):
                return DataProcessResult.failure("Already connected")
            if await self._find_pending(from_uid, to_uid):
                return DataProcessResult.failure("Request already pending")

            req_id = f"req_{uuid.uuid4().hex}"
            now = datetime.now(timezone.utc)
            request: Doc = {
                "requestId": req_id, "fromUserId": from_uid, "toUserId": to_uid,
                "type": parsed.get("type", "friend"), "status": RequestStatus.PENDING,
                "message": parsed.get("message", ""), "createdAt": now.isoformat(),
                "expiresAt": (now + timedelta(days=self._config.request_expiration_days)).isoformat(),
                "scopeId": parsed.get("scopeId", "default"),
            }
            for k, v in parsed.items():
                if k not in request:
                    request[k] = v

            await self._db.upsert(self._config.requests_index, req_id, request)

            cfg = await self._get_config(parsed.get("scopeId", "default"))
            threshold = float(cfg.get("auto_accept_min_match_score", self._config.auto_accept_min_match_score))
            if parsed.get("matchScore") and float(parsed["matchScore"]) >= threshold:
                return await self.accept_request(req_id, to_uid)

            await self._queue.publish("connection-events", {
                "eventType": "FriendRequestSent", "requestId": req_id,
                "fromUserId": from_uid, "toUserId": to_uid, "timestamp": now.isoformat(),
            })
            return DataProcessResult.success(request)
        except Exception as e:
            return DataProcessResult.failure(str(e))

    async def accept_request(self, request_id: str, accepting_user_id: str) -> DataProcessResult:
        try:
            req = await self._db.get_by_id(self._config.requests_index, request_id)
            if not req:
                return DataProcessResult.failure("Request not found")
            if not RequestStatus.can_transition(req.get("status", ""), RequestStatus.ACCEPTED):
                return DataProcessResult.failure(f"Cannot accept in status '{req.get('status')}'")
            if req.get("toUserId") != accepting_user_id:
                return DataProcessResult.failure("Only target user can accept")
            if req.get("expiresAt") and datetime.fromisoformat(req["expiresAt"]) < datetime.now(timezone.utc):
                req["status"] = RequestStatus.EXPIRED
                await self._db.upsert(self._config.requests_index, request_id, req)
                return DataProcessResult.failure("Request expired")

            req["status"] = RequestStatus.ACCEPTED
            req["acceptedAt"] = datetime.now(timezone.utc).isoformat()
            await self._db.upsert(self._config.requests_index, request_id, req)

            conn_id = f"conn_{uuid.uuid4().hex}"
            conn: Doc = {
                "connectionId": conn_id, "fromUserId": req["fromUserId"], "toUserId": req["toUserId"],
                "type": req.get("type", "friend"), "status": "accepted",
                "strength": 0.0, "strengthFactors": {}, "requestId": request_id,
                "createdAt": datetime.now(timezone.utc).isoformat(),
                "updatedAt": datetime.now(timezone.utc).isoformat(),
                "scopeId": req.get("scopeId", "default"),
            }
            await self._db.upsert(self._config.connections_index, conn_id, conn)

            await self._queue.publish("connection-events", {
                "eventType": "FriendRequestAccepted", "connectionId": conn_id,
                "requestId": request_id, "fromUserId": req["fromUserId"],
                "toUserId": req["toUserId"], "timestamp": datetime.now(timezone.utc).isoformat(),
            })
            return DataProcessResult.success(conn)
        except Exception as e:
            return DataProcessResult.failure(str(e))

    async def reject_request(self, request_id: str, rejecting_user_id: str) -> DataProcessResult:
        try:
            req = await self._db.get_by_id(self._config.requests_index, request_id)
            if not req:
                return DataProcessResult.failure("Not found")
            if req.get("toUserId") != rejecting_user_id:
                return DataProcessResult.failure("Only target can reject")
            if not RequestStatus.can_transition(req.get("status", ""), RequestStatus.REJECTED):
                return DataProcessResult.failure("Cannot reject")
            req["status"] = RequestStatus.REJECTED
            req["rejectedAt"] = datetime.now(timezone.utc).isoformat()
            await self._db.upsert(self._config.requests_index, request_id, req)
            return DataProcessResult.success(req)
        except Exception as e:
            return DataProcessResult.failure(str(e))

    # ─── Connections ────────────────────────────────────────────

    async def get_connections(self, user_id: str, page: int = 0, page_size: Optional[int] = None, type_filter: Optional[str] = None) -> DataProcessResult:
        try:
            size = page_size or self._config.default_page_size
            f: Doc = {"_or_userId": {"fromUserId": user_id, "toUserId": user_id}, "status": "accepted"}
            if type_filter:
                f["type"] = type_filter
            blocked = await self._get_blocked_ids(user_id)
            all_conns = await self._db.query(self._config.connections_index, f)
            filtered = [c for c in all_conns if self._peer(c, user_id) not in blocked]
            filtered.sort(key=lambda c: float(c.get("strength", 0)), reverse=True)
            total = len(filtered)
            paged = filtered[page * size:(page + 1) * size]
            return DataProcessResult.success(ConnectionPage(items=paged, total_count=total, has_more=(page + 1) * size < total, cursor=str(page + 1) if paged else None))
        except Exception as e:
            return DataProcessResult.failure(str(e))

    async def remove_connection(self, connection_id: str, removing_user_id: str) -> DataProcessResult:
        try:
            conn = await self._db.get_by_id(self._config.connections_index, connection_id)
            if not conn:
                return DataProcessResult.failure("Not found")
            if conn.get("fromUserId") != removing_user_id and conn.get("toUserId") != removing_user_id:
                return DataProcessResult.failure("Access denied")
            conn["status"] = "removed"
            conn["removedAt"] = datetime.now(timezone.utc).isoformat()
            await self._db.upsert(self._config.connections_index, connection_id, conn)
            await self._queue.publish("connection-events", {"eventType": "ConnectionRemoved", "connectionId": connection_id, "timestamp": datetime.now(timezone.utc).isoformat()})
            return DataProcessResult.success(conn)
        except Exception as e:
            return DataProcessResult.failure(str(e))

    # ─── Blocking ───────────────────────────────────────────────

    async def block_user(self, blocking_uid: str, blocked_uid: str) -> DataProcessResult:
        try:
            if blocking_uid == blocked_uid:
                return DataProcessResult.failure("Cannot block yourself")
            existing = await self._find_existing(blocking_uid, blocked_uid)
            if existing and existing.get("connectionId"):
                await self.remove_connection(existing["connectionId"], blocking_uid)
            block_id = f"block_{blocking_uid}_{blocked_uid}"
            doc: Doc = {"blockId": block_id, "blockingUserId": blocking_uid, "blockedUserId": blocked_uid, "createdAt": datetime.now(timezone.utc).isoformat()}
            await self._db.upsert(self._config.blocked_index, block_id, doc)
            await self._queue.publish("connection-events", {"eventType": "ConnectionBlocked", "blockingUserId": blocking_uid, "blockedUserId": blocked_uid, "timestamp": datetime.now(timezone.utc).isoformat()})
            return DataProcessResult.success(doc)
        except Exception as e:
            return DataProcessResult.failure(str(e))

    async def unblock_user(self, blocking_uid: str, blocked_uid: str) -> DataProcessResult:
        try:
            await self._db.delete(self._config.blocked_index, f"block_{blocking_uid}_{blocked_uid}")
            return DataProcessResult.success({"unblocked": True, "blockedUserId": blocked_uid})
        except Exception as e:
            return DataProcessResult.failure(str(e))

    # ─── Graph Operations ───────────────────────────────────────

    async def get_mutual_connections(self, user_a: str, user_b: str) -> DataProcessResult:
        try:
            return DataProcessResult.success(await self._graph.get_mutual_connections(user_a, user_b))
        except Exception as e:
            return DataProcessResult.failure(str(e))

    async def get_suggestions(self, user_id: str, limit: Optional[int] = None) -> DataProcessResult:
        try:
            mx = limit or self._config.suggestion_limit
            depth2 = await self._graph.get_user_ids_at_depth(user_id, 2, mx * 2)
            suggestions: list[Doc] = []
            for sid in depth2[:mx]:
                mutuals = await self._graph.get_mutual_connections(user_id, sid)
                suggestions.append({"suggestedUserId": sid, "mutualCount": len(mutuals), "score": min(len(mutuals) / 5.0, 1.0), "reason": f"{len(mutuals)} mutual connection(s)"})
            suggestions.sort(key=lambda s: s["score"], reverse=True)
            return DataProcessResult.success(suggestions)
        except Exception as e:
            return DataProcessResult.failure(str(e))

    async def get_network_depth(self, from_user: str, to_user: str) -> DataProcessResult:
        try:
            return DataProcessResult.success(await self._graph.get_shortest_path(from_user, to_user, self._config.max_traversal_depth))
        except Exception as e:
            return DataProcessResult.failure(str(e))

    async def get_connection_strength(self, user_a: str, user_b: str) -> DataProcessResult:
        try:
            conn = await self._find_existing(user_a, user_b)
            return DataProcessResult.success(float(conn.get("strength", 0)) if conn else 0.0)
        except Exception as e:
            return DataProcessResult.failure(str(e))

    async def recalculate_strength(self, connection_id: str) -> DataProcessResult:
        try:
            conn = await self._db.get_by_id(self._config.connections_index, connection_id)
            if not conn:
                return DataProcessResult.failure("Not found")
            cfg = await self._get_config(conn.get("scopeId", "default"))
            factors = conn.get("strengthFactors", {})
            strength = self._strength_calc.calculate(factors, cfg)
            prev = float(conn.get("strength", 0))
            conn["strength"] = strength
            conn["updatedAt"] = datetime.now(timezone.utc).isoformat()
            await self._db.upsert(self._config.connections_index, connection_id, conn)
            if abs(strength - prev) > 0.1:
                await self._queue.publish("connection-events", {"eventType": "ConnectionStrengthUpdated", "connectionId": connection_id, "previousStrength": prev, "newStrength": strength, "timestamp": datetime.now(timezone.utc).isoformat()})
            return DataProcessResult.success(conn)
        except Exception as e:
            return DataProcessResult.failure(str(e))

    # ─── Config (FREEDOM) ──────────────────────────────────────

    async def get_config(self, scope_id: str) -> DataProcessResult:
        try:
            return DataProcessResult.success(await self._get_config(scope_id))
        except Exception as e:
            return DataProcessResult.failure(str(e))

    async def update_config(self, config_data: Doc) -> DataProcessResult:
        try:
            parsed = self._processor.parse_object_alternative(config_data)
            scope_id = parsed.get("scopeId", "default")
            parsed["configId"] = f"conn-config-{scope_id}"
            parsed["updatedAt"] = datetime.now(timezone.utc).isoformat()
            await self._db.upsert(self._config.config_index, parsed["configId"], parsed)
            return DataProcessResult.success(parsed)
        except Exception as e:
            return DataProcessResult.failure(str(e))

    # ─── Internal ──────────────────────────────────────────────

    async def _is_blocked(self, a: str, b: str) -> bool:
        try:
            r = await self._db.get_by_id(self._config.blocked_index, f"block_{a}_{b}")
            if r: return True
        except Exception: pass
        try:
            r = await self._db.get_by_id(self._config.blocked_index, f"block_{b}_{a}")
            return r is not None
        except Exception: return False

    async def _find_existing(self, a: str, b: str) -> Optional[Doc]:
        r = await self._db.query(self._config.connections_index, {"fromUserId": a, "toUserId": b, "status": "accepted"})
        if r: return r[0]
        r = await self._db.query(self._config.connections_index, {"fromUserId": b, "toUserId": a, "status": "accepted"})
        return r[0] if r else None

    async def _find_pending(self, a: str, b: str) -> Optional[Doc]:
        r = await self._db.query(self._config.requests_index, {"fromUserId": a, "toUserId": b, "status": RequestStatus.PENDING})
        if r: return r[0]
        r = await self._db.query(self._config.requests_index, {"fromUserId": b, "toUserId": a, "status": RequestStatus.PENDING})
        return r[0] if r else None

    async def _get_config(self, scope_id: str) -> Doc:
        try:
            c = await self._db.get_by_id(self._config.config_index, f"conn-config-{scope_id}")
            if c: return c
        except Exception: pass
        return {**DEFAULT_WEIGHTS, "auto_accept_min_match_score": self._config.auto_accept_min_match_score}

    async def _get_blocked_ids(self, user_id: str) -> set[str]:
        blocked: set[str] = set()
        for b in await self._db.query(self._config.blocked_index, {"blockingUserId": user_id}):
            if b.get("blockedUserId"): blocked.add(b["blockedUserId"])
        for b in await self._db.query(self._config.blocked_index, {"blockedUserId": user_id}):
            if b.get("blockingUserId"): blocked.add(b["blockingUserId"])
        return blocked

    @staticmethod
    def _peer(conn: Doc, user_id: str) -> Optional[str]:
        fr = str(conn.get("fromUserId", ""))
        to = str(conn.get("toUserId", ""))
        return to if fr == user_id else (fr if to == user_id else None)
