// XIIGen Connection Service — Skill 49 | Node.js/TypeScript Alternative
// Social graph: friend requests, connections, blocking, strength calc, graph traversal
// Genie DNA: DNA-1 (Record<string,any>), DNA-2 (buildSearchFilter), DNA-5 (DataProcessResult)

import { IDatabaseService, IQueueService, IObjectProcessor } from '../01-core-interfaces';
import { DataProcessResult } from '../01-core-interfaces';

// ─── Configuration ──────────────────────────────────────────────
export interface ConnectionConfig {
  connectionsIndex: string;
  requestsIndex: string;
  blockedIndex: string;
  configIndex: string;
  defaultPageSize: number;
  requestExpirationDays: number;
  maxTraversalDepth: number;
  suggestionLimit: number;
  autoAcceptMinMatchScore: number;
}

const DEFAULT_CONFIG: ConnectionConfig = {
  connectionsIndex: 'connections',
  requestsIndex: 'connection-requests',
  blockedIndex: 'blocked-users',
  configIndex: 'connection-config',
  defaultPageSize: 20,
  requestExpirationDays: 30,
  maxTraversalDepth: 3,
  suggestionLimit: 50,
  autoAcceptMinMatchScore: 0.8,
};

type ConnDoc = Record<string, any>;

export interface ConnectionPage {
  items: ConnDoc[];
  cursor?: string;
  totalCount: number;
  hasMore: boolean;
}

// ─── Request Status FSM (MACHINE) ──────────────────────────────
const REQUEST_STATUS = {
  PENDING: 'pending',
  ACCEPTED: 'accepted',
  REJECTED: 'rejected',
  EXPIRED: 'expired',
  CANCELLED: 'cancelled',
} as const;

function canTransition(from: string, to: string): boolean {
  if (from !== REQUEST_STATUS.PENDING) return false;
  return [REQUEST_STATUS.ACCEPTED, REQUEST_STATUS.REJECTED, REQUEST_STATUS.CANCELLED, REQUEST_STATUS.EXPIRED].includes(to as any);
}

// ─── Default Strength Weights (FREEDOM — admin-configurable) ───
const DEFAULT_WEIGHTS: ConnDoc = {
  matchScoreWeight: 0.30,
  sharedGroupsWeight: 0.20,
  coAttendedEventsWeight: 0.20,
  messageFrequencyWeight: 0.15,
  profileSimilarityWeight: 0.15,
};

// ─── Strength Calculator (MACHINE logic, FREEDOM weights) ──────
export class ConnectionStrengthCalculator {
  calculate(factors: ConnDoc, weights: ConnDoc): number {
    const factorDefs = [
      { key: 'matchScore', weightKey: 'matchScoreWeight', default: 0.30 },
      { key: 'sharedGroups', weightKey: 'sharedGroupsWeight', default: 0.20 },
      { key: 'coAttendedEvents', weightKey: 'coAttendedEventsWeight', default: 0.20 },
      { key: 'messageFrequency', weightKey: 'messageFrequencyWeight', default: 0.15 },
      { key: 'profileSimilarity', weightKey: 'profileSimilarityWeight', default: 0.15 },
    ];

    let total = 0;
    let weightSum = 0;

    for (const { key, weightKey, default: defW } of factorDefs) {
      const factorValue = this.normalizeFactor(key, Number(factors[key] ?? 0));
      const weight = Number(weights[weightKey] ?? defW);
      total += factorValue * weight;
      weightSum += weight;
    }

    return weightSum > 0 ? Math.max(0, Math.min(1, total / weightSum)) : 0;
  }

  private normalizeFactor(key: string, raw: number): number {
    switch (key) {
      case 'matchScore': return Math.max(0, Math.min(1, raw));
      case 'sharedGroups': return Math.min(raw / 10, 1);
      case 'coAttendedEvents': return Math.min(raw / 5, 1);
      case 'messageFrequency': return Math.max(0, Math.min(1, raw));
      case 'profileSimilarity': return Math.max(0, Math.min(1, raw));
      default: return Math.max(0, Math.min(1, raw));
    }
  }
}

// ─── Graph Traversal Engine (MACHINE) ──────────────────────────
export class GraphTraversal {
  constructor(
    private db: IDatabaseService,
    private connectionsIndex: string,
  ) {}

  async getUserIdsAtDepth(userId: string, depth: number, maxResults: number): Promise<string[]> {
    if (depth < 1) return [];
    const visited = new Set<string>([userId]);
    let currentLevel = new Set<string>([userId]);
    const results: string[] = [];

    for (let d = 0; d < depth; d++) {
      const nextLevel = new Set<string>();
      for (const uid of currentLevel) {
        const filter = this.buildConnectionFilter(uid, 'accepted');
        const connections = await this.db.query(this.connectionsIndex, filter);
        for (const conn of connections) {
          const peerId = this.getPeerId(conn, uid);
          if (peerId && !visited.has(peerId)) {
            visited.add(peerId);
            nextLevel.add(peerId);
            if (d === depth - 1) {
              results.push(peerId);
              if (results.length >= maxResults) return results;
            }
          }
        }
      }
      currentLevel = nextLevel;
      if (currentLevel.size === 0) break;
    }
    return results;
  }

  async getMutualConnections(userA: string, userB: string): Promise<ConnDoc[]> {
    const filterA = this.buildConnectionFilter(userA, 'accepted');
    const filterB = this.buildConnectionFilter(userB, 'accepted');
    const connectionsA = await this.db.query(this.connectionsIndex, filterA);
    const connectionsB = await this.db.query(this.connectionsIndex, filterB);

    const peersA = new Set(connectionsA.map(c => this.getPeerId(c, userA)).filter(Boolean));
    const peersB = new Set(connectionsB.map(c => this.getPeerId(c, userB)).filter(Boolean));
    const mutualIds = new Set([...peersA].filter(id => peersB.has(id)));

    return connectionsA.filter(c => mutualIds.has(this.getPeerId(c, userA)));
  }

  async getShortestPath(fromUser: string, toUser: string, maxDepth: number): Promise<number> {
    if (fromUser === toUser) return 0;
    const visited = new Set<string>([fromUser]);
    let currentLevel = new Set<string>([fromUser]);

    for (let depth = 1; depth <= maxDepth; depth++) {
      const nextLevel = new Set<string>();
      for (const uid of currentLevel) {
        const filter = this.buildConnectionFilter(uid, 'accepted');
        const connections = await this.db.query(this.connectionsIndex, filter);
        for (const conn of connections) {
          const peerId = this.getPeerId(conn, uid);
          if (peerId === toUser) return depth;
          if (peerId && !visited.has(peerId)) {
            visited.add(peerId);
            nextLevel.add(peerId);
          }
        }
      }
      currentLevel = nextLevel;
      if (currentLevel.size === 0) break;
    }
    return -1;
  }

  private buildConnectionFilter(userId: string, status: string): ConnDoc {
    const filter: ConnDoc = {};
    if (userId) filter._or_userId = { fromUserId: userId, toUserId: userId };
    if (status) filter.status = status;
    return filter;
  }

  private getPeerId(conn: ConnDoc, userId: string): string | null {
    const from = conn.fromUserId?.toString();
    const to = conn.toUserId?.toString();
    return from === userId ? to : (to === userId ? from : null);
  }
}

// ─── Main Connection Service ───────────────────────────────────
export class ConnectionService {
  private config: ConnectionConfig;
  private strengthCalc: ConnectionStrengthCalculator;
  private graphTraversal: GraphTraversal;

  constructor(
    private db: IDatabaseService,
    private queue: IQueueService,
    private processor: IObjectProcessor,
    config?: Partial<ConnectionConfig>,
  ) {
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.strengthCalc = new ConnectionStrengthCalculator();
    this.graphTraversal = new GraphTraversal(db, this.config.connectionsIndex);
  }

  // ─── Connection Requests ─────────────────────────────────────

  async sendRequest(requestData: ConnDoc): Promise<DataProcessResult<ConnDoc>> {
    try {
      const parsed = this.processor.parseObjectAlternative(requestData);
      const { fromUserId, toUserId } = parsed;
      if (!fromUserId || !toUserId) return DataProcessResult.failure('fromUserId and toUserId required');
      if (fromUserId === toUserId) return DataProcessResult.failure('Cannot request yourself');
      if (await this.isBlockedInternal(fromUserId, toUserId)) return DataProcessResult.failure('User not available');

      const existing = await this.findExistingConnection(fromUserId, toUserId);
      if (existing) return DataProcessResult.failure('Already connected');

      const pendingReq = await this.findPendingRequest(fromUserId, toUserId);
      if (pendingReq) return DataProcessResult.failure('Request already pending');

      const requestId = `req_${crypto.randomUUID().replace(/-/g, '')}`;
      const request: ConnDoc = {
        requestId, fromUserId, toUserId,
        type: parsed.type ?? 'friend',
        status: REQUEST_STATUS.PENDING,
        message: parsed.message ?? '',
        createdAt: new Date().toISOString(),
        expiresAt: new Date(Date.now() + this.config.requestExpirationDays * 86400000).toISOString(),
        scopeId: parsed.scopeId ?? 'default',
      };
      // Copy additional metadata
      for (const [k, v] of Object.entries(parsed)) {
        if (!(k in request)) request[k] = v;
      }

      await this.db.upsert(this.config.requestsIndex, requestId, request);

      // Auto-accept check
      const cfg = await this.getConfigInternal(parsed.scopeId ?? 'default');
      if (parsed.matchScore && Number(parsed.matchScore) >= Number(cfg.autoAcceptMinMatchScore ?? this.config.autoAcceptMinMatchScore)) {
        return this.acceptRequest(requestId, toUserId);
      }

      await this.queue.publish('connection-events', {
        eventType: 'FriendRequestSent', requestId, fromUserId, toUserId,
        timestamp: new Date().toISOString(),
      });
      return DataProcessResult.success(request);
    } catch (err: any) {
      return DataProcessResult.failure(err.message);
    }
  }

  async acceptRequest(requestId: string, acceptingUserId: string): Promise<DataProcessResult<ConnDoc>> {
    try {
      const request = await this.db.getById(this.config.requestsIndex, requestId);
      if (!request) return DataProcessResult.failure('Request not found');
      if (!canTransition(request.status, REQUEST_STATUS.ACCEPTED))
        return DataProcessResult.failure(`Cannot accept in status '${request.status}'`);
      if (request.toUserId !== acceptingUserId)
        return DataProcessResult.failure('Only target user can accept');
      if (request.expiresAt && new Date(request.expiresAt) < new Date()) {
        request.status = REQUEST_STATUS.EXPIRED;
        await this.db.upsert(this.config.requestsIndex, requestId, request);
        return DataProcessResult.failure('Request expired');
      }

      request.status = REQUEST_STATUS.ACCEPTED;
      request.acceptedAt = new Date().toISOString();
      await this.db.upsert(this.config.requestsIndex, requestId, request);

      const connectionId = `conn_${crypto.randomUUID().replace(/-/g, '')}`;
      const connection: ConnDoc = {
        connectionId, fromUserId: request.fromUserId, toUserId: request.toUserId,
        type: request.type ?? 'friend', status: 'accepted',
        strength: 0, strengthFactors: {}, requestId,
        createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(),
        scopeId: request.scopeId ?? 'default',
      };
      await this.db.upsert(this.config.connectionsIndex, connectionId, connection);

      // Background strength calc
      this.recalculateStrengthInternal(connectionId, request.fromUserId, request.toUserId).catch(() => {});

      await this.queue.publish('connection-events', {
        eventType: 'FriendRequestAccepted', connectionId, requestId,
        fromUserId: request.fromUserId, toUserId: request.toUserId,
        timestamp: new Date().toISOString(),
      });
      return DataProcessResult.success(connection);
    } catch (err: any) {
      return DataProcessResult.failure(err.message);
    }
  }

  async rejectRequest(requestId: string, rejectingUserId: string): Promise<DataProcessResult<ConnDoc>> {
    try {
      const request = await this.db.getById(this.config.requestsIndex, requestId);
      if (!request) return DataProcessResult.failure('Request not found');
      if (request.toUserId !== rejectingUserId) return DataProcessResult.failure('Only target user can reject');
      if (!canTransition(request.status, REQUEST_STATUS.REJECTED)) return DataProcessResult.failure('Cannot reject');
      request.status = REQUEST_STATUS.REJECTED;
      request.rejectedAt = new Date().toISOString();
      await this.db.upsert(this.config.requestsIndex, requestId, request);
      await this.queue.publish('connection-events', { eventType: 'FriendRequestRejected', requestId, timestamp: new Date().toISOString() });
      return DataProcessResult.success(request);
    } catch (err: any) { return DataProcessResult.failure(err.message); }
  }

  async cancelRequest(requestId: string, cancellingUserId: string): Promise<DataProcessResult<ConnDoc>> {
    try {
      const request = await this.db.getById(this.config.requestsIndex, requestId);
      if (!request) return DataProcessResult.failure('Request not found');
      if (request.fromUserId !== cancellingUserId) return DataProcessResult.failure('Only sender can cancel');
      if (!canTransition(request.status, REQUEST_STATUS.CANCELLED)) return DataProcessResult.failure('Cannot cancel');
      request.status = REQUEST_STATUS.CANCELLED;
      request.cancelledAt = new Date().toISOString();
      await this.db.upsert(this.config.requestsIndex, requestId, request);
      return DataProcessResult.success(request);
    } catch (err: any) { return DataProcessResult.failure(err.message); }
  }

  async getPendingRequests(userId: string, direction: 'inbound' | 'outbound' = 'inbound'): Promise<DataProcessResult<ConnDoc[]>> {
    try {
      const filter: ConnDoc = { status: REQUEST_STATUS.PENDING };
      if (direction === 'inbound') filter.toUserId = userId; else filter.fromUserId = userId;
      const results = await this.db.query(this.config.requestsIndex, filter);
      const active = results.filter((r: ConnDoc) => !r.expiresAt || new Date(r.expiresAt) > new Date());
      return DataProcessResult.success(active);
    } catch (err: any) { return DataProcessResult.failure(err.message); }
  }

  // ─── Connection Management ───────────────────────────────────

  async getConnections(userId: string, page = 0, pageSize?: number, typeFilter?: string): Promise<DataProcessResult<ConnectionPage>> {
    try {
      const size = pageSize ?? this.config.defaultPageSize;
      const filter: ConnDoc = { _or_userId: { fromUserId: userId, toUserId: userId }, status: 'accepted' };
      if (typeFilter) filter.type = typeFilter;
      const blockedIds = await this.getBlockedUserIds(userId);
      const all = await this.db.query(this.config.connectionsIndex, filter);
      const filtered = all
        .filter((c: ConnDoc) => { const p = this.getPeerId(c, userId); return p && !blockedIds.has(p); })
        .sort((a: ConnDoc, b: ConnDoc) => Number(b.strength ?? 0) - Number(a.strength ?? 0));
      const total = filtered.length;
      const paged = filtered.slice(page * size, (page + 1) * size);
      return DataProcessResult.success({ items: paged, totalCount: total, hasMore: (page + 1) * size < total, cursor: paged.length > 0 ? `${page + 1}` : undefined });
    } catch (err: any) { return DataProcessResult.failure(err.message); }
  }

  async removeConnection(connectionId: string, removingUserId: string): Promise<DataProcessResult<ConnDoc>> {
    try {
      const conn = await this.db.getById(this.config.connectionsIndex, connectionId);
      if (!conn) return DataProcessResult.failure('Not found');
      if (conn.fromUserId !== removingUserId && conn.toUserId !== removingUserId) return DataProcessResult.failure('Access denied');
      conn.status = 'removed'; conn.removedAt = new Date().toISOString(); conn.removedBy = removingUserId;
      await this.db.upsert(this.config.connectionsIndex, connectionId, conn);
      await this.queue.publish('connection-events', { eventType: 'ConnectionRemoved', connectionId, fromUserId: conn.fromUserId, toUserId: conn.toUserId, removedBy: removingUserId, timestamp: new Date().toISOString() });
      return DataProcessResult.success(conn);
    } catch (err: any) { return DataProcessResult.failure(err.message); }
  }

  // ─── Blocking ────────────────────────────────────────────────

  async blockUser(blockingUserId: string, blockedUserId: string): Promise<DataProcessResult<ConnDoc>> {
    try {
      if (blockingUserId === blockedUserId) return DataProcessResult.failure('Cannot block yourself');
      const existing = await this.findExistingConnection(blockingUserId, blockedUserId);
      if (existing?.connectionId) await this.removeConnection(existing.connectionId, blockingUserId);
      const blockId = `block_${blockingUserId}_${blockedUserId}`;
      const blockDoc: ConnDoc = { blockId, blockingUserId, blockedUserId, createdAt: new Date().toISOString() };
      await this.db.upsert(this.config.blockedIndex, blockId, blockDoc);
      await this.queue.publish('connection-events', { eventType: 'ConnectionBlocked', blockingUserId, blockedUserId, timestamp: new Date().toISOString() });
      return DataProcessResult.success(blockDoc);
    } catch (err: any) { return DataProcessResult.failure(err.message); }
  }

  async unblockUser(blockingUserId: string, blockedUserId: string): Promise<DataProcessResult<ConnDoc>> {
    try {
      const blockId = `block_${blockingUserId}_${blockedUserId}`;
      await this.db.delete(this.config.blockedIndex, blockId);
      await this.queue.publish('connection-events', { eventType: 'ConnectionUnblocked', blockingUserId, blockedUserId, timestamp: new Date().toISOString() });
      return DataProcessResult.success({ unblocked: true, blockedUserId });
    } catch (err: any) { return DataProcessResult.failure(err.message); }
  }

  async isBlocked(userA: string, userB: string): Promise<DataProcessResult<boolean>> {
    try { return DataProcessResult.success(await this.isBlockedInternal(userA, userB)); }
    catch (err: any) { return DataProcessResult.failure(err.message); }
  }

  // ─── Graph Operations ────────────────────────────────────────

  async getMutualConnections(userA: string, userB: string): Promise<DataProcessResult<ConnDoc[]>> {
    try {
      const mutuals = await this.graphTraversal.getMutualConnections(userA, userB);
      return DataProcessResult.success(mutuals);
    } catch (err: any) { return DataProcessResult.failure(err.message); }
  }

  async getSuggestions(userId: string, limit?: number): Promise<DataProcessResult<ConnDoc[]>> {
    try {
      const max = limit ?? this.config.suggestionLimit;
      const depth2Users = await this.graphTraversal.getUserIdsAtDepth(userId, 2, max * 2);
      const suggestions: ConnDoc[] = [];
      for (const sugId of depth2Users.slice(0, max)) {
        const mutuals = await this.graphTraversal.getMutualConnections(userId, sugId);
        suggestions.push({ suggestedUserId: sugId, mutualCount: mutuals.length, score: Math.min(mutuals.length / 5, 1), reason: `${mutuals.length} mutual connection(s)` });
      }
      suggestions.sort((a, b) => b.score - a.score);
      return DataProcessResult.success(suggestions);
    } catch (err: any) { return DataProcessResult.failure(err.message); }
  }

  async getNetworkDepth(fromUser: string, toUser: string): Promise<DataProcessResult<number>> {
    try {
      const depth = await this.graphTraversal.getShortestPath(fromUser, toUser, this.config.maxTraversalDepth);
      return DataProcessResult.success(depth);
    } catch (err: any) { return DataProcessResult.failure(err.message); }
  }

  async getConnectionStrength(userA: string, userB: string): Promise<DataProcessResult<number>> {
    try {
      const conn = await this.findExistingConnection(userA, userB);
      return DataProcessResult.success(conn ? Number(conn.strength ?? 0) : 0);
    } catch (err: any) { return DataProcessResult.failure(err.message); }
  }

  async recalculateStrength(connectionId: string): Promise<DataProcessResult<ConnDoc>> {
    try {
      const conn = await this.db.getById(this.config.connectionsIndex, connectionId);
      if (!conn) return DataProcessResult.failure('Not found');
      return this.recalculateStrengthInternal(connectionId, conn.fromUserId, conn.toUserId);
    } catch (err: any) { return DataProcessResult.failure(err.message); }
  }

  async batchRecalculate(): Promise<DataProcessResult<number>> {
    try {
      const all = await this.db.query(this.config.connectionsIndex, { status: 'accepted' });
      let updated = 0;
      for (const conn of all) {
        const r = await this.recalculateStrengthInternal(conn.connectionId, conn.fromUserId, conn.toUserId);
        if (r.isSuccess) updated++;
      }
      return DataProcessResult.success(updated);
    } catch (err: any) { return DataProcessResult.failure(err.message); }
  }

  // ─── Config (FREEDOM) ────────────────────────────────────────

  async getConfig(scopeId: string): Promise<DataProcessResult<ConnDoc>> {
    try { return DataProcessResult.success(await this.getConfigInternal(scopeId)); }
    catch (err: any) { return DataProcessResult.failure(err.message); }
  }

  async updateConfig(configData: ConnDoc): Promise<DataProcessResult<ConnDoc>> {
    try {
      const parsed = this.processor.parseObjectAlternative(configData);
      const scopeId = parsed.scopeId ?? 'default';
      parsed.configId = `conn-config-${scopeId}`;
      parsed.updatedAt = new Date().toISOString();
      await this.db.upsert(this.config.configIndex, parsed.configId, parsed);
      return DataProcessResult.success(parsed);
    } catch (err: any) { return DataProcessResult.failure(err.message); }
  }

  // ─── Internal Helpers ────────────────────────────────────────

  private async isBlockedInternal(userA: string, userB: string): Promise<boolean> {
    const ab = await this.db.getById(this.config.blockedIndex, `block_${userA}_${userB}`).catch(() => null);
    if (ab) return true;
    const ba = await this.db.getById(this.config.blockedIndex, `block_${userB}_${userA}`).catch(() => null);
    return !!ba;
  }

  private async findExistingConnection(userA: string, userB: string): Promise<ConnDoc | null> {
    let results = await this.db.query(this.config.connectionsIndex, { fromUserId: userA, toUserId: userB, status: 'accepted' });
    if (results.length > 0) return results[0];
    results = await this.db.query(this.config.connectionsIndex, { fromUserId: userB, toUserId: userA, status: 'accepted' });
    return results.length > 0 ? results[0] : null;
  }

  private async findPendingRequest(fromUser: string, toUser: string): Promise<ConnDoc | null> {
    let results = await this.db.query(this.config.requestsIndex, { fromUserId: fromUser, toUserId: toUser, status: REQUEST_STATUS.PENDING });
    if (results.length > 0) return results[0];
    results = await this.db.query(this.config.requestsIndex, { fromUserId: toUser, toUserId: fromUser, status: REQUEST_STATUS.PENDING });
    return results.length > 0 ? results[0] : null;
  }

  private async getConfigInternal(scopeId: string): Promise<ConnDoc> {
    const config = await this.db.getById(this.config.configIndex, `conn-config-${scopeId}`).catch(() => null);
    return config ?? { ...DEFAULT_WEIGHTS, autoAcceptMinMatchScore: this.config.autoAcceptMinMatchScore, requestExpirationDays: this.config.requestExpirationDays, maxTraversalDepth: this.config.maxTraversalDepth, suggestionLimit: this.config.suggestionLimit };
  }

  private async recalculateStrengthInternal(connectionId: string, fromUser: string, toUser: string): Promise<DataProcessResult<ConnDoc>> {
    const conn = await this.db.getById(this.config.connectionsIndex, connectionId);
    if (!conn) return DataProcessResult.failure('Not found');
    const cfg = await this.getConfigInternal(conn.scopeId ?? 'default');
    const factors = conn.strengthFactors ?? {};
    const strength = this.strengthCalc.calculate(factors, cfg);
    const prev = Number(conn.strength ?? 0);
    conn.strength = strength; conn.updatedAt = new Date().toISOString();
    await this.db.upsert(this.config.connectionsIndex, connectionId, conn);
    if (Math.abs(strength - prev) > 0.1) {
      await this.queue.publish('connection-events', { eventType: 'ConnectionStrengthUpdated', connectionId, fromUserId: fromUser, toUserId: toUser, previousStrength: prev, newStrength: strength, timestamp: new Date().toISOString() });
    }
    return DataProcessResult.success(conn);
  }

  private async getBlockedUserIds(userId: string): Promise<Set<string>> {
    const blocked = new Set<string>();
    const blocking = await this.db.query(this.config.blockedIndex, { blockingUserId: userId });
    const blockedBy = await this.db.query(this.config.blockedIndex, { blockedUserId: userId });
    for (const b of blocking) if (b.blockedUserId) blocked.add(b.blockedUserId);
    for (const b of blockedBy) if (b.blockingUserId) blocked.add(b.blockingUserId);
    return blocked;
  }

  private getPeerId(conn: ConnDoc, userId: string): string | null {
    const from = conn.fromUserId?.toString();
    const to = conn.toUserId?.toString();
    return from === userId ? to : (to === userId ? from : null);
  }
}
