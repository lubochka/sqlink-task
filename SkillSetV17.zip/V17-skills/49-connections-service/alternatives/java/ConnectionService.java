// XIIGen Connection Service — Skill 49 | Java Alternative
// Social graph: friend requests, connections, blocking, strength calc, graph traversal
// Genie DNA: DNA-1 (Map<String,Object>), DNA-2 (buildSearchFilter), DNA-5 (DataProcessResult)

package com.xiigen.services.connections;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

// ─── Configuration ──────────────────────────────────────────────
public class ConnectionConfig {
    public String connectionsIndex = "connections";
    public String requestsIndex = "connection-requests";
    public String blockedIndex = "blocked-users";
    public String configIndex = "connection-config";
    public int defaultPageSize = 20;
    public int requestExpirationDays = 30;
    public int maxTraversalDepth = 3;
    public int suggestionLimit = 50;
    public double autoAcceptMinMatchScore = 0.8;
}

// ─── Connection Page ────────────────────────────────────────────
class ConnectionPage {
    public List<Map<String, Object>> items = new ArrayList<>();
    public String cursor;
    public int totalCount;
    public boolean hasMore;
}

// ─── DataProcessResult (DNA-5) ─────────────────────────────────
class DataProcessResult<T> {
    public boolean isSuccess;
    public T data;
    public String error;

    public static <T> DataProcessResult<T> success(T data) {
        var r = new DataProcessResult<T>();
        r.isSuccess = true;
        r.data = data;
        return r;
    }

    public static <T> DataProcessResult<T> failure(String error) {
        var r = new DataProcessResult<T>();
        r.isSuccess = false;
        r.error = error;
        return r;
    }
}

// ─── Request Status FSM (MACHINE) ──────────────────────────────
class RequestStatus {
    static final String PENDING = "pending";
    static final String ACCEPTED = "accepted";
    static final String REJECTED = "rejected";
    static final String EXPIRED = "expired";
    static final String CANCELLED = "cancelled";

    static boolean canTransition(String from, String to) {
        if (!PENDING.equals(from)) return false;
        return ACCEPTED.equals(to) || REJECTED.equals(to) || CANCELLED.equals(to) || EXPIRED.equals(to);
    }
}

// ─── Strength Calculator (MACHINE logic, FREEDOM weights) ──────
class ConnectionStrengthCalculator {
    private static final String[][] FACTOR_DEFS = {
        {"matchScore", "matchScoreWeight", "0.30"},
        {"sharedGroups", "sharedGroupsWeight", "0.20"},
        {"coAttendedEvents", "coAttendedEventsWeight", "0.20"},
        {"messageFrequency", "messageFrequencyWeight", "0.15"},
        {"profileSimilarity", "profileSimilarityWeight", "0.15"},
    };

    public double calculate(Map<String, Object> factors, Map<String, Object> weights) {
        double total = 0.0, weightSum = 0.0;
        for (String[] def : FACTOR_DEFS) {
            double factorVal = normalizeFactor(def[0], getDouble(factors, def[0], 0.0));
            double weight = getDouble(weights, def[1], Double.parseDouble(def[2]));
            total += factorVal * weight;
            weightSum += weight;
        }
        return weightSum > 0 ? Math.max(0.0, Math.min(1.0, total / weightSum)) : 0.0;
    }

    private double normalizeFactor(String key, double raw) {
        return switch (key) {
            case "sharedGroups" -> Math.min(raw / 10.0, 1.0);
            case "coAttendedEvents" -> Math.min(raw / 5.0, 1.0);
            default -> Math.max(0.0, Math.min(1.0, raw));
        };
    }

    @SuppressWarnings("unchecked")
    static double getDouble(Map<String, Object> doc, String key, double fallback) {
        Object val = doc.get(key);
        if (val instanceof Number n) return n.doubleValue();
        if (val instanceof String s) { try { return Double.parseDouble(s); } catch (Exception e) { return fallback; } }
        return fallback;
    }
}

// ─── Graph Traversal Engine (MACHINE) ──────────────────────────
class GraphTraversal {
    private final IDatabaseService db;
    private final String connectionsIndex;

    GraphTraversal(IDatabaseService db, String connectionsIndex) {
        this.db = db;
        this.connectionsIndex = connectionsIndex;
    }

    public List<String> getUserIdsAtDepth(String userId, int depth, int maxResults) throws Exception {
        if (depth < 1) return List.of();
        Set<String> visited = new HashSet<>();
        visited.add(userId);
        Set<String> currentLevel = new HashSet<>();
        currentLevel.add(userId);
        List<String> results = new ArrayList<>();

        for (int d = 0; d < depth; d++) {
            Set<String> nextLevel = new HashSet<>();
            for (String uid : currentLevel) {
                var filter = buildFilter(uid, "accepted");
                var connections = db.query(connectionsIndex, filter);
                for (var conn : connections) {
                    String peer = getPeerId(conn, uid);
                    if (peer != null && visited.add(peer)) {
                        nextLevel.add(peer);
                        if (d == depth - 1) {
                            results.add(peer);
                            if (results.size() >= maxResults) return results;
                        }
                    }
                }
            }
            currentLevel = nextLevel;
            if (currentLevel.isEmpty()) break;
        }
        return results;
    }

    public List<Map<String, Object>> getMutualConnections(String userA, String userB) throws Exception {
        var connsA = db.query(connectionsIndex, buildFilter(userA, "accepted"));
        var connsB = db.query(connectionsIndex, buildFilter(userB, "accepted"));
        Set<String> peersA = connsA.stream().map(c -> getPeerId(c, userA)).filter(Objects::nonNull).collect(Collectors.toSet());
        Set<String> peersB = connsB.stream().map(c -> getPeerId(c, userB)).filter(Objects::nonNull).collect(Collectors.toSet());
        peersA.retainAll(peersB);
        return connsA.stream().filter(c -> peersA.contains(getPeerId(c, userA))).collect(Collectors.toList());
    }

    public int getShortestPath(String fromUser, String toUser, int maxDepth) throws Exception {
        if (fromUser.equals(toUser)) return 0;
        Set<String> visited = new HashSet<>();
        visited.add(fromUser);
        Set<String> currentLevel = Set.of(fromUser);
        for (int depth = 1; depth <= maxDepth; depth++) {
            Set<String> nextLevel = new HashSet<>();
            for (String uid : currentLevel) {
                for (var conn : db.query(connectionsIndex, buildFilter(uid, "accepted"))) {
                    String peer = getPeerId(conn, uid);
                    if (toUser.equals(peer)) return depth;
                    if (peer != null && visited.add(peer)) nextLevel.add(peer);
                }
            }
            currentLevel = nextLevel;
            if (currentLevel.isEmpty()) break;
        }
        return -1;
    }

    private static Map<String, Object> buildFilter(String userId, String status) {
        Map<String, Object> filter = new HashMap<>();
        if (userId != null && !userId.isEmpty())
            filter.put("_or_userId", Map.of("fromUserId", userId, "toUserId", userId));
        if (status != null && !status.isEmpty()) filter.put("status", status);
        return filter;
    }

    static String getPeerId(Map<String, Object> conn, String userId) {
        String from = conn.getOrDefault("fromUserId", "").toString();
        String to = conn.getOrDefault("toUserId", "").toString();
        return from.equals(userId) ? to : (to.equals(userId) ? from : null);
    }
}

// ─── Main Connection Service ───────────────────────────────────
public class ConnectionService {
    private final IDatabaseService db;
    private final IQueueService queue;
    private final IObjectProcessor processor;
    private final ConnectionConfig config;
    private final ConnectionStrengthCalculator strengthCalc;
    private final GraphTraversal graphTraversal;

    public ConnectionService(IDatabaseService db, IQueueService queue, IObjectProcessor processor, ConnectionConfig config) {
        this.db = db;
        this.queue = queue;
        this.processor = processor;
        this.config = config != null ? config : new ConnectionConfig();
        this.strengthCalc = new ConnectionStrengthCalculator();
        this.graphTraversal = new GraphTraversal(db, this.config.connectionsIndex);
    }

    // ─── Requests ──────────────────────────────────────────────

    public DataProcessResult<Map<String, Object>> sendRequest(Map<String, Object> requestData) {
        try {
            var parsed = processor.parseObjectAlternative(requestData);
            String fromUid = str(parsed, "fromUserId"), toUid = str(parsed, "toUserId");
            if (fromUid == null || toUid == null) return DataProcessResult.failure("fromUserId and toUserId required");
            if (fromUid.equals(toUid)) return DataProcessResult.failure("Cannot request yourself");
            if (isBlockedInternal(fromUid, toUid)) return DataProcessResult.failure("User not available");
            if (findExisting(fromUid, toUid) != null) return DataProcessResult.failure("Already connected");
            if (findPending(fromUid, toUid) != null) return DataProcessResult.failure("Request already pending");

            String reqId = "req_" + UUID.randomUUID().toString().replace("-", "");
            var now = Instant.now();
            var request = new HashMap<String, Object>();
            request.put("requestId", reqId);
            request.put("fromUserId", fromUid);
            request.put("toUserId", toUid);
            request.put("type", parsed.getOrDefault("type", "friend"));
            request.put("status", RequestStatus.PENDING);
            request.put("message", parsed.getOrDefault("message", ""));
            request.put("createdAt", now.toString());
            request.put("expiresAt", now.plus(config.requestExpirationDays, ChronoUnit.DAYS).toString());
            request.put("scopeId", parsed.getOrDefault("scopeId", "default"));
            parsed.forEach(request::putIfAbsent);

            db.upsert(config.requestsIndex, reqId, request);

            var cfg = getConfigInternal(str(parsed, "scopeId"));
            double threshold = ConnectionStrengthCalculator.getDouble(cfg, "autoAcceptMinMatchScore", config.autoAcceptMinMatchScore);
            if (parsed.containsKey("matchScore") && ConnectionStrengthCalculator.getDouble(parsed, "matchScore", 0) >= threshold) {
                return acceptRequest(reqId, toUid);
            }

            queue.publish("connection-events", Map.of("eventType", "FriendRequestSent", "requestId", reqId, "fromUserId", fromUid, "toUserId", toUid, "timestamp", now.toString()));
            return DataProcessResult.success(request);
        } catch (Exception e) { return DataProcessResult.failure(e.getMessage()); }
    }

    public DataProcessResult<Map<String, Object>> acceptRequest(String requestId, String acceptingUserId) {
        try {
            var req = db.getById(config.requestsIndex, requestId);
            if (req == null) return DataProcessResult.failure("Request not found");
            if (!RequestStatus.canTransition(str(req, "status"), RequestStatus.ACCEPTED))
                return DataProcessResult.failure("Cannot accept in status '" + str(req, "status") + "'");
            if (!acceptingUserId.equals(str(req, "toUserId")))
                return DataProcessResult.failure("Only target user can accept");

            req.put("status", RequestStatus.ACCEPTED);
            req.put("acceptedAt", Instant.now().toString());
            db.upsert(config.requestsIndex, requestId, req);

            String connId = "conn_" + UUID.randomUUID().toString().replace("-", "");
            var conn = new HashMap<String, Object>();
            conn.put("connectionId", connId);
            conn.put("fromUserId", str(req, "fromUserId"));
            conn.put("toUserId", str(req, "toUserId"));
            conn.put("type", req.getOrDefault("type", "friend"));
            conn.put("status", "accepted");
            conn.put("strength", 0.0);
            conn.put("strengthFactors", new HashMap<>());
            conn.put("requestId", requestId);
            conn.put("createdAt", Instant.now().toString());
            conn.put("updatedAt", Instant.now().toString());
            conn.put("scopeId", req.getOrDefault("scopeId", "default"));
            db.upsert(config.connectionsIndex, connId, conn);

            queue.publish("connection-events", Map.of("eventType", "FriendRequestAccepted", "connectionId", connId, "requestId", requestId, "timestamp", Instant.now().toString()));
            return DataProcessResult.success(conn);
        } catch (Exception e) { return DataProcessResult.failure(e.getMessage()); }
    }

    public DataProcessResult<Map<String, Object>> rejectRequest(String requestId, String rejectingUserId) {
        try {
            var req = db.getById(config.requestsIndex, requestId);
            if (req == null) return DataProcessResult.failure("Not found");
            if (!rejectingUserId.equals(str(req, "toUserId"))) return DataProcessResult.failure("Only target can reject");
            if (!RequestStatus.canTransition(str(req, "status"), RequestStatus.REJECTED)) return DataProcessResult.failure("Cannot reject");
            req.put("status", RequestStatus.REJECTED);
            req.put("rejectedAt", Instant.now().toString());
            db.upsert(config.requestsIndex, requestId, req);
            return DataProcessResult.success(req);
        } catch (Exception e) { return DataProcessResult.failure(e.getMessage()); }
    }

    // ─── Connections ───────────────────────────────────────────

    public DataProcessResult<ConnectionPage> getConnections(String userId, int page, Integer pageSize, String typeFilter) {
        try {
            int size = pageSize != null ? pageSize : config.defaultPageSize;
            var filter = new HashMap<String, Object>();
            filter.put("_or_userId", Map.of("fromUserId", userId, "toUserId", userId));
            filter.put("status", "accepted");
            if (typeFilter != null && !typeFilter.isEmpty()) filter.put("type", typeFilter);
            var blocked = getBlockedUserIds(userId);
            var all = db.query(config.connectionsIndex, filter);
            var filtered = all.stream()
                .filter(c -> { var p = GraphTraversal.getPeerId(c, userId); return p != null && !blocked.contains(p); })
                .sorted((a, b) -> Double.compare(ConnectionStrengthCalculator.getDouble(b, "strength", 0), ConnectionStrengthCalculator.getDouble(a, "strength", 0)))
                .collect(Collectors.toList());
            int total = filtered.size();
            var paged = filtered.subList(Math.min(page * size, total), Math.min((page + 1) * size, total));
            var cp = new ConnectionPage();
            cp.items = paged; cp.totalCount = total; cp.hasMore = (page + 1) * size < total;
            cp.cursor = !paged.isEmpty() ? String.valueOf(page + 1) : null;
            return DataProcessResult.success(cp);
        } catch (Exception e) { return DataProcessResult.failure(e.getMessage()); }
    }

    public DataProcessResult<Map<String, Object>> removeConnection(String connectionId, String removingUserId) {
        try {
            var conn = db.getById(config.connectionsIndex, connectionId);
            if (conn == null) return DataProcessResult.failure("Not found");
            if (!removingUserId.equals(str(conn, "fromUserId")) && !removingUserId.equals(str(conn, "toUserId")))
                return DataProcessResult.failure("Access denied");
            conn.put("status", "removed"); conn.put("removedAt", Instant.now().toString());
            db.upsert(config.connectionsIndex, connectionId, conn);
            queue.publish("connection-events", Map.of("eventType", "ConnectionRemoved", "connectionId", connectionId, "timestamp", Instant.now().toString()));
            return DataProcessResult.success(conn);
        } catch (Exception e) { return DataProcessResult.failure(e.getMessage()); }
    }

    // ─── Blocking ──────────────────────────────────────────────

    public DataProcessResult<Map<String, Object>> blockUser(String blockingUid, String blockedUid) {
        try {
            if (blockingUid.equals(blockedUid)) return DataProcessResult.failure("Cannot block yourself");
            var existing = findExisting(blockingUid, blockedUid);
            if (existing != null && existing.containsKey("connectionId")) removeConnection(str(existing, "connectionId"), blockingUid);
            String blockId = "block_" + blockingUid + "_" + blockedUid;
            var doc = Map.<String, Object>of("blockId", blockId, "blockingUserId", blockingUid, "blockedUserId", blockedUid, "createdAt", Instant.now().toString());
            db.upsert(config.blockedIndex, blockId, new HashMap<>(doc));
            queue.publish("connection-events", Map.of("eventType", "ConnectionBlocked", "blockingUserId", blockingUid, "blockedUserId", blockedUid, "timestamp", Instant.now().toString()));
            return DataProcessResult.success(new HashMap<>(doc));
        } catch (Exception e) { return DataProcessResult.failure(e.getMessage()); }
    }

    // ─── Graph Operations ──────────────────────────────────────

    public DataProcessResult<List<Map<String, Object>>> getMutualConnections(String userA, String userB) {
        try { return DataProcessResult.success(graphTraversal.getMutualConnections(userA, userB)); }
        catch (Exception e) { return DataProcessResult.failure(e.getMessage()); }
    }

    public DataProcessResult<List<Map<String, Object>>> getSuggestions(String userId, Integer limit) {
        try {
            int mx = limit != null ? limit : config.suggestionLimit;
            var depth2 = graphTraversal.getUserIdsAtDepth(userId, 2, mx * 2);
            var suggestions = new ArrayList<Map<String, Object>>();
            for (String sid : depth2.subList(0, Math.min(mx, depth2.size()))) {
                var mutuals = graphTraversal.getMutualConnections(userId, sid);
                suggestions.add(Map.of("suggestedUserId", sid, "mutualCount", mutuals.size(), "score", Math.min(mutuals.size() / 5.0, 1.0), "reason", mutuals.size() + " mutual connection(s)"));
            }
            suggestions.sort((a, b) -> Double.compare((double)b.get("score"), (double)a.get("score")));
            return DataProcessResult.success(suggestions);
        } catch (Exception e) { return DataProcessResult.failure(e.getMessage()); }
    }

    public DataProcessResult<Integer> getNetworkDepth(String fromUser, String toUser) {
        try { return DataProcessResult.success(graphTraversal.getShortestPath(fromUser, toUser, config.maxTraversalDepth)); }
        catch (Exception e) { return DataProcessResult.failure(e.getMessage()); }
    }

    // ─── Strength ──────────────────────────────────────────────

    @SuppressWarnings("unchecked")
    public DataProcessResult<Map<String, Object>> recalculateStrength(String connectionId) {
        try {
            var conn = db.getById(config.connectionsIndex, connectionId);
            if (conn == null) return DataProcessResult.failure("Not found");
            var cfg = getConfigInternal(str(conn, "scopeId"));
            var factors = conn.containsKey("strengthFactors") ? (Map<String, Object>) conn.get("strengthFactors") : Map.<String, Object>of();
            double strength = strengthCalc.calculate(factors, cfg);
            double prev = ConnectionStrengthCalculator.getDouble(conn, "strength", 0);
            conn.put("strength", strength); conn.put("updatedAt", Instant.now().toString());
            db.upsert(config.connectionsIndex, connectionId, conn);
            if (Math.abs(strength - prev) > 0.1) {
                queue.publish("connection-events", Map.of("eventType", "ConnectionStrengthUpdated", "connectionId", connectionId, "previousStrength", prev, "newStrength", strength, "timestamp", Instant.now().toString()));
            }
            return DataProcessResult.success(conn);
        } catch (Exception e) { return DataProcessResult.failure(e.getMessage()); }
    }

    // ─── Config (FREEDOM) ──────────────────────────────────────

    public DataProcessResult<Map<String, Object>> getConfig(String scopeId) {
        try { return DataProcessResult.success(getConfigInternal(scopeId)); }
        catch (Exception e) { return DataProcessResult.failure(e.getMessage()); }
    }

    public DataProcessResult<Map<String, Object>> updateConfig(Map<String, Object> configData) {
        try {
            var parsed = processor.parseObjectAlternative(configData);
            String scopeId = (String) parsed.getOrDefault("scopeId", "default");
            parsed.put("configId", "conn-config-" + scopeId);
            parsed.put("updatedAt", Instant.now().toString());
            db.upsert(config.configIndex, "conn-config-" + scopeId, parsed);
            return DataProcessResult.success(parsed);
        } catch (Exception e) { return DataProcessResult.failure(e.getMessage()); }
    }

    // ─── Internal ──────────────────────────────────────────────

    private boolean isBlockedInternal(String a, String b) throws Exception {
        try { if (db.getById(config.blockedIndex, "block_" + a + "_" + b) != null) return true; } catch (Exception e) {}
        try { return db.getById(config.blockedIndex, "block_" + b + "_" + a) != null; } catch (Exception e) { return false; }
    }

    private Map<String, Object> findExisting(String a, String b) throws Exception {
        var r = db.query(config.connectionsIndex, Map.of("fromUserId", a, "toUserId", b, "status", "accepted"));
        if (!r.isEmpty()) return r.get(0);
        r = db.query(config.connectionsIndex, Map.of("fromUserId", b, "toUserId", a, "status", "accepted"));
        return !r.isEmpty() ? r.get(0) : null;
    }

    private Map<String, Object> findPending(String a, String b) throws Exception {
        var r = db.query(config.requestsIndex, Map.of("fromUserId", a, "toUserId", b, "status", RequestStatus.PENDING));
        if (!r.isEmpty()) return r.get(0);
        r = db.query(config.requestsIndex, Map.of("fromUserId", b, "toUserId", a, "status", RequestStatus.PENDING));
        return !r.isEmpty() ? r.get(0) : null;
    }

    private Map<String, Object> getConfigInternal(String scopeId) throws Exception {
        if (scopeId == null || scopeId.isEmpty()) scopeId = "default";
        try { var c = db.getById(config.configIndex, "conn-config-" + scopeId); if (c != null) return c; } catch (Exception e) {}
        return Map.of("autoAcceptMinMatchScore", config.autoAcceptMinMatchScore, "matchScoreWeight", 0.30, "sharedGroupsWeight", 0.20, "coAttendedEventsWeight", 0.20, "messageFrequencyWeight", 0.15, "profileSimilarityWeight", 0.15);
    }

    private Set<String> getBlockedUserIds(String userId) throws Exception {
        Set<String> blocked = new HashSet<>();
        for (var b : db.query(config.blockedIndex, Map.of("blockingUserId", userId)))
            if (b.containsKey("blockedUserId")) blocked.add(b.get("blockedUserId").toString());
        for (var b : db.query(config.blockedIndex, Map.of("blockedUserId", userId)))
            if (b.containsKey("blockingUserId")) blocked.add(b.get("blockingUserId").toString());
        return blocked;
    }

    private static String str(Map<String, Object> doc, String key) {
        Object v = doc.get(key);
        return v != null ? v.toString() : null;
    }
}
