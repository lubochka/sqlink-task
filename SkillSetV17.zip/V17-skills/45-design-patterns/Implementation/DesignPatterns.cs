// XIIGen Skill 45 — Design Patterns (.NET 9/C# 13)
// All 19 patterns implemented with modern C# idioms and XIIGen-specific examples.
// Each pattern: interface → implementation → XIIGen usage context.

using System.Collections.Concurrent;
using System.Text.Json;

namespace XIIGen.Patterns;

// ═══════════════════════════════════════════════
// 1. SINGLETON — Thread-safe lazy initialization
// ═══════════════════════════════════════════════

/// <summary>XIIGen usage: AppConfig, Logger, CacheService — single shared instance.</summary>
public sealed class AppConfig
{
    private static readonly Lazy<AppConfig> _instance = new(() => new AppConfig());
    public static AppConfig Instance => _instance.Value;
    private AppConfig() { DbUrl = Environment.GetEnvironmentVariable("DB_URL") ?? ""; }
    public string DbUrl { get; }
    public string QueueUrl { get; init; } = "";
}

// ═══════════════════════════════════════════════
// 2. FACTORY — Registry-based provider creation
// ═══════════════════════════════════════════════

/// <summary>XIIGen usage: DatabaseFabric, AiProviderFactory, RagServiceFactory.</summary>
public interface IDatabaseService
{
    Task<List<object>> SearchAsync(string index, Dictionary<string, object> filter, int limit);
}

public static class DatabaseFactory
{
    private static readonly Dictionary<string, Func<IDatabaseService>> _registry = new();
    public static void Register(string provider, Func<IDatabaseService> factory) => _registry[provider.ToLower()] = factory;
    public static IDatabaseService Create(string provider)
    {
        if (!_registry.TryGetValue(provider.ToLower(), out var factory))
            throw new InvalidOperationException($"Unknown provider: {provider}. Available: {string.Join(", ", _registry.Keys)}");
        return factory();
    }
}

// ═══════════════════════════════════════════════
// 3. BUILDER — Fluent construction with validation
// ═══════════════════════════════════════════════

/// <summary>XIIGen usage: FlowDefinitionBuilder, ContextPackageBuilder, QueryBuilder.</summary>
public class FlowDefinitionBuilder
{
    private readonly List<FlowStep> _steps = [];
    private readonly List<FlowEdge> _edges = [];
    private string _name = "";

    public FlowDefinitionBuilder WithName(string name) { _name = name; return this; }
    public FlowDefinitionBuilder AddStep(string id, string type, Dictionary<string, object>? config = null)
    { _steps.Add(new(id, type, config ?? [])); return this; }
    public FlowDefinitionBuilder AddEdge(string from, string to, string? condition = null)
    { _edges.Add(new(from, to, condition)); return this; }

    public FlowDefinition Build()
    {
        if (string.IsNullOrEmpty(_name)) throw new InvalidOperationException("Flow name required");
        if (_steps.Count == 0) throw new InvalidOperationException("At least one step required");
        return new(_name, [.. _steps], [.. _edges]);
    }
}
public record FlowStep(string Id, string Type, Dictionary<string, object> Config);
public record FlowEdge(string From, string To, string? Condition);
public record FlowDefinition(string Name, List<FlowStep> Steps, List<FlowEdge> Edges);

// ═══════════════════════════════════════════════
// 4. PROTOTYPE — Deep clone via serialization
// ═══════════════════════════════════════════════

/// <summary>XIIGen usage: FlowStep templates, ContextSection cloning.</summary>
public interface ICloneable<T> { T Clone(); }

public class StepTemplate : ICloneable<StepTemplate>
{
    public string Type { get; set; } = "";
    public Dictionary<string, object> DefaultConfig { get; set; } = [];

    public StepTemplate Clone()
    {
        var json = JsonSerializer.Serialize(this);
        return JsonSerializer.Deserialize<StepTemplate>(json)!;
    }
}

// ═══════════════════════════════════════════════
// 5. ADAPTER — Bridge incompatible interfaces
// ═══════════════════════════════════════════════

/// <summary>XIIGen usage: Adapt external AI SDKs to IAiProvider interface.</summary>
public interface IAiProvider { Task<string> GenerateAsync(string prompt, Dictionary<string, object>? options = null); }

// External SDK has different signature
public class ExternalOpenAiSdk { public async Task<string> Complete(string text, int maxTokens) => await Task.FromResult($"[OpenAI] {text}"); }

public class OpenAiAdapter : IAiProvider
{
    private readonly ExternalOpenAiSdk _sdk = new();
    public async Task<string> GenerateAsync(string prompt, Dictionary<string, object>? options = null)
    {
        var maxTokens = options?.GetValueOrDefault("maxTokens") is int mt ? mt : 1000;
        return await _sdk.Complete(prompt, maxTokens);
    }
}

// ═══════════════════════════════════════════════
// 6. DECORATOR — Add behavior without modifying original
// ═══════════════════════════════════════════════

/// <summary>XIIGen usage: Logging, caching, retry decorators on any service.</summary>
public class LoggingAiProvider : IAiProvider
{
    private readonly IAiProvider _inner;
    private readonly Action<string> _log;
    public LoggingAiProvider(IAiProvider inner, Action<string> log) { _inner = inner; _log = log; }
    public async Task<string> GenerateAsync(string prompt, Dictionary<string, object>? options = null)
    {
        _log($"AI call: {prompt[..Math.Min(50, prompt.Length)]}...");
        var result = await _inner.GenerateAsync(prompt, options);
        _log($"AI result: {result.Length} chars");
        return result;
    }
}

public class RetryAiProvider : IAiProvider
{
    private readonly IAiProvider _inner;
    private readonly int _maxRetries;
    public RetryAiProvider(IAiProvider inner, int maxRetries = 3) { _inner = inner; _maxRetries = maxRetries; }
    public async Task<string> GenerateAsync(string prompt, Dictionary<string, object>? options = null)
    {
        for (int i = 0; i < _maxRetries; i++)
        {
            try { return await _inner.GenerateAsync(prompt, options); }
            catch when (i < _maxRetries - 1) { await Task.Delay(TimeSpan.FromSeconds(Math.Pow(2, i))); }
        }
        throw new InvalidOperationException("All retries exhausted");
    }
}

// ═══════════════════════════════════════════════
// 7. OBSERVER — Event-driven notifications
// ═══════════════════════════════════════════════

/// <summary>XIIGen usage: Flow step completion events, feedback triggers.</summary>
public interface IFlowObserver { Task OnStepCompleted(string traceId, string stepId, object result); }

public class FlowEventBus
{
    private readonly List<IFlowObserver> _observers = [];
    public void Subscribe(IFlowObserver observer) => _observers.Add(observer);
    public void Unsubscribe(IFlowObserver observer) => _observers.Remove(observer);
    public async Task NotifyStepCompleted(string traceId, string stepId, object result)
    {
        foreach (var obs in _observers)
            try { await obs.OnStepCompleted(traceId, stepId, result); } catch { /* log */ }
    }
}

// ═══════════════════════════════════════════════
// 8. STRATEGY — Swappable algorithms
// ═══════════════════════════════════════════════

/// <summary>XIIGen usage: Merge strategies for multi-model results, scoring algorithms.</summary>
public interface IMergeStrategy { List<object> Merge(List<List<object>> results); }

public class UnionMerge : IMergeStrategy
{
    public List<object> Merge(List<List<object>> results) => results.SelectMany(r => r).Distinct().ToList();
}
public class IntersectionMerge : IMergeStrategy
{
    public List<object> Merge(List<List<object>> results)
    {
        if (results.Count == 0) return [];
        IEnumerable<object> intersection = results[0];
        foreach (var r in results.Skip(1)) intersection = intersection.Intersect(r);
        return intersection.ToList();
    }
}
public class WeightedMerge : IMergeStrategy
{
    private readonly double[] _weights;
    public WeightedMerge(params double[] weights) => _weights = weights;
    public List<object> Merge(List<List<object>> results)
    {
        var scored = new Dictionary<object, double>();
        for (int i = 0; i < results.Count; i++)
        {
            var w = i < _weights.Length ? _weights[i] : 1.0;
            foreach (var item in results[i])
                scored[item] = scored.GetValueOrDefault(item) + w;
        }
        return scored.OrderByDescending(kv => kv.Value).Select(kv => kv.Key).ToList();
    }
}

// ═══════════════════════════════════════════════
// 9. COMMAND — Encapsulate operations as objects
// ═══════════════════════════════════════════════

/// <summary>XIIGen usage: Undo/redo in flow editor, queued operations.</summary>
public interface ICommand { Task ExecuteAsync(); Task UndoAsync(); }

public class CommandHistory
{
    private readonly Stack<ICommand> _executed = new();
    private readonly Stack<ICommand> _undone = new();

    public async Task ExecuteAsync(ICommand cmd)
    {
        await cmd.ExecuteAsync();
        _executed.Push(cmd);
        _undone.Clear();
    }
    public async Task UndoAsync()
    {
        if (_executed.Count == 0) return;
        var cmd = _executed.Pop();
        await cmd.UndoAsync();
        _undone.Push(cmd);
    }
    public async Task RedoAsync()
    {
        if (_undone.Count == 0) return;
        var cmd = _undone.Pop();
        await cmd.ExecuteAsync();
        _executed.Push(cmd);
    }
}

// ═══════════════════════════════════════════════
// 10. CHAIN OF RESPONSIBILITY — Pipeline processing
// ═══════════════════════════════════════════════

/// <summary>XIIGen usage: Request middleware, validation chains, AI review pipeline.</summary>
public abstract class PipelineHandler<T>
{
    private PipelineHandler<T>? _next;
    public PipelineHandler<T> SetNext(PipelineHandler<T> next) { _next = next; return next; }
    public virtual async Task<T> HandleAsync(T request)
    {
        if (_next != null) return await _next.HandleAsync(request);
        return request;
    }
}

// Example: Auth → Validate → Process
public class AuthHandler : PipelineHandler<Dictionary<string, object>>
{
    public override async Task<Dictionary<string, object>> HandleAsync(Dictionary<string, object> req)
    {
        if (!req.ContainsKey("token")) throw new UnauthorizedAccessException("Missing token");
        req["authenticated"] = true;
        return await base.HandleAsync(req);
    }
}

// ═══════════════════════════════════════════════
// 11. MEDIATOR — Decouple component communication
// ═══════════════════════════════════════════════

/// <summary>XIIGen usage: Orchestrator dispatching between microservices.</summary>
public interface IMediator { Task<object?> SendAsync(string channel, object message); }

public class ServiceMediator : IMediator
{
    private readonly Dictionary<string, Func<object, Task<object?>>> _handlers = [];
    public void Register(string channel, Func<object, Task<object?>> handler) => _handlers[channel] = handler;
    public async Task<object?> SendAsync(string channel, object message)
    {
        if (!_handlers.TryGetValue(channel, out var handler))
            throw new InvalidOperationException($"No handler for channel: {channel}");
        return await handler(message);
    }
}

// ═══════════════════════════════════════════════
// 12. STATE — State machine for flow execution
// ═══════════════════════════════════════════════

/// <summary>XIIGen usage: Flow step states (Pending→Running→Completed/Failed/Cancelled).</summary>
public enum StepState { Pending, Running, Completed, Failed, Cancelled }

public class StepStateMachine
{
    private static readonly Dictionary<StepState, HashSet<StepState>> _transitions = new()
    {
        [StepState.Pending] = [StepState.Running, StepState.Cancelled],
        [StepState.Running] = [StepState.Completed, StepState.Failed, StepState.Cancelled],
        [StepState.Completed] = [],
        [StepState.Failed] = [StepState.Pending], // Retry
        [StepState.Cancelled] = [],
    };

    public StepState Current { get; private set; } = StepState.Pending;

    public void Transition(StepState target)
    {
        if (!_transitions[Current].Contains(target))
            throw new InvalidOperationException($"Invalid transition: {Current} → {target}");
        Current = target;
    }
}

// ═══════════════════════════════════════════════
// 13. PROXY — Lazy/cached access
// ═══════════════════════════════════════════════

/// <summary>XIIGen usage: Lazy service initialization, cached DB results.</summary>
public class CachedDatabaseProxy : IDatabaseService
{
    private readonly IDatabaseService _real;
    private readonly ConcurrentDictionary<string, (List<object> Data, DateTime CachedAt)> _cache = new();
    private readonly TimeSpan _ttl;

    public CachedDatabaseProxy(IDatabaseService real, TimeSpan? ttl = null)
    { _real = real; _ttl = ttl ?? TimeSpan.FromMinutes(5); }

    public async Task<List<object>> SearchAsync(string index, Dictionary<string, object> filter, int limit)
    {
        var key = $"{index}:{JsonSerializer.Serialize(filter)}:{limit}";
        if (_cache.TryGetValue(key, out var cached) && DateTime.UtcNow - cached.CachedAt < _ttl)
            return cached.Data;
        var data = await _real.SearchAsync(index, filter, limit);
        _cache[key] = (data, DateTime.UtcNow);
        return data;
    }
}

// ═══════════════════════════════════════════════
// 14. TEMPLATE METHOD — Algorithm skeleton with hooks
// ═══════════════════════════════════════════════

/// <summary>XIIGen usage: MicroserviceBase, flow step execution template.</summary>
public abstract class FlowStepExecutor
{
    public async Task<object> ExecuteAsync(Dictionary<string, object> input)
    {
        var validated = await ValidateInputAsync(input);
        var context = await BuildContextAsync(validated);
        var result = await ProcessAsync(validated, context);
        await StoreResultAsync(result);
        return result;
    }

    protected abstract Task<Dictionary<string, object>> ValidateInputAsync(Dictionary<string, object> input);
    protected abstract Task<object> BuildContextAsync(Dictionary<string, object> input);
    protected abstract Task<object> ProcessAsync(Dictionary<string, object> input, object context);
    protected virtual Task StoreResultAsync(object result) => Task.CompletedTask;
}

// ═══════════════════════════════════════════════
// 15. COMPOSITE — Tree structures
// ═══════════════════════════════════════════════

/// <summary>XIIGen usage: Figma node trees, flow subgraphs, permission hierarchies.</summary>
public interface IFigmaNode
{
    string Id { get; }
    string Type { get; }
    List<IFigmaNode> Children { get; }
    void Accept(IFigmaVisitor visitor);
}

public class FigmaContainer : IFigmaNode
{
    public string Id { get; init; } = "";
    public string Type { get; init; } = "FRAME";
    public List<IFigmaNode> Children { get; } = [];
    public void Accept(IFigmaVisitor visitor)
    {
        visitor.VisitContainer(this);
        foreach (var child in Children) child.Accept(visitor);
    }
}

// ═══════════════════════════════════════════════
// 16. VISITOR — Operations on tree nodes
// ═══════════════════════════════════════════════

/// <summary>XIIGen usage: Figma tree analysis, component extraction, code generation.</summary>
public interface IFigmaVisitor
{
    void VisitContainer(FigmaContainer container);
    void VisitLeaf(FigmaLeaf leaf);
}

public class FigmaLeaf : IFigmaNode
{
    public string Id { get; init; } = "";
    public string Type { get; init; } = "TEXT";
    public string Value { get; init; } = "";
    public List<IFigmaNode> Children => [];
    public void Accept(IFigmaVisitor visitor) => visitor.VisitLeaf(this);
}

public class ComponentExtractor : IFigmaVisitor
{
    public List<string> Components { get; } = [];
    public void VisitContainer(FigmaContainer c) { if (c.Type == "COMPONENT") Components.Add(c.Id); }
    public void VisitLeaf(FigmaLeaf l) { }
}

// ═══════════════════════════════════════════════
// 17. ITERATOR — Sequential access without exposing structure
// ═══════════════════════════════════════════════

/// <summary>XIIGen usage: Paginated DB results, flow step traversal.</summary>
public class PaginatedIterator<T>
{
    private readonly Func<int, int, Task<List<T>>> _fetcher;
    private readonly int _pageSize;
    private int _currentPage;

    public PaginatedIterator(Func<int, int, Task<List<T>>> fetcher, int pageSize = 20)
    { _fetcher = fetcher; _pageSize = pageSize; }

    public async Task<List<T>> NextPageAsync()
    {
        var results = await _fetcher(_currentPage * _pageSize, _pageSize);
        _currentPage++;
        return results;
    }

    public bool HasMore { get; private set; } = true;
}

// ═══════════════════════════════════════════════
// 18. FACADE — Simplified interface to complex subsystem
// ═══════════════════════════════════════════════

/// <summary>XIIGen usage: FlowFacade hiding orchestrator + context + AI + feedback complexity.</summary>
public class FlowFacade
{
    private readonly IMediator _mediator;
    public FlowFacade(IMediator mediator) => _mediator = mediator;

    public async Task<object?> RunFlowAsync(string flowId, Dictionary<string, object> input)
    {
        // Hides: context assembly → AI dispatch → review → feedback → storage
        await _mediator.SendAsync("context.build", new { flowId, input });
        var result = await _mediator.SendAsync("ai.dispatch", new { flowId, input });
        await _mediator.SendAsync("feedback.record", new { flowId, result });
        return result;
    }
}

// ═══════════════════════════════════════════════
// 19. REPOSITORY — Data access abstraction
// ═══════════════════════════════════════════════

/// <summary>XIIGen usage: Generic repo over DatabaseFabric — dynamic documents only.</summary>
public class DynamicRepository
{
    private readonly IDatabaseService _db;
    private readonly string _index;

    public DynamicRepository(IDatabaseService db, string index) { _db = db; _index = index; }

    public async Task<string> InsertAsync(Dictionary<string, object> doc)
    {
        // Genie DNA: ParseObjectAlternative before storage
        var processed = ParseObjectAlternative(doc);
        var result = await _db.SearchAsync(_index, new() { ["_action"] = "insert", ["doc"] = processed }, 1);
        return result.FirstOrDefault()?.ToString() ?? "";
    }

    public async Task<List<object>> QueryAsync(Dictionary<string, object> filter, int limit = 10)
    {
        // Genie DNA: BuildSearchFilter skips empty fields
        var cleaned = BuildSearchFilter(filter);
        return await _db.SearchAsync(_index, cleaned, limit);
    }

    // ─── Genie DNA Helpers ──────────────────────────────────────

    private static Dictionary<string, object> BuildSearchFilter(Dictionary<string, object> filter)
    {
        var clean = new Dictionary<string, object>();
        foreach (var (key, value) in filter)
        {
            if (value == null) continue;
            if (value is string s && string.IsNullOrEmpty(s)) continue;
            if (value is ICollection<object> c && c.Count == 0) continue;
            clean[key] = value;
        }
        return clean;
    }

    private static Dictionary<string, object> ParseObjectAlternative(Dictionary<string, object> obj, int depth = 0)
    {
        if (depth > 10) return obj;
        var result = new Dictionary<string, object>();
        foreach (var (key, value) in obj)
        {
            if (value == null) continue;
            if (value is Dictionary<string, object> nested)
                result[key] = ParseObjectAlternative(nested, depth + 1);
            else
                result[key] = value;
        }
        return result;
    }
}

// ═══════════════════════════════════════════════
// PATTERN CATALOG — For AI Context Service (Skill 16) to query
// ═══════════════════════════════════════════════

public static class PatternCatalog
{
    public record PatternInfo(string Name, string Category, string WhenToUse, string XiigenUsage, string[] Combinations);

    public static readonly PatternInfo[] AllPatterns =
    [
        new("Singleton", "Creational", "Single shared instance (config, logging, cache)", "AppConfig, ICacheService, Logger", ["Factory", "Facade"]),
        new("Factory", "Creational", "Create objects without specifying concrete class", "DatabaseFabric, AiProviderFactory, RagServiceFactory", ["Singleton", "Strategy"]),
        new("Builder", "Creational", "Complex object construction with many options", "FlowDefinitionBuilder, ContextPackageBuilder", ["Composite", "Prototype"]),
        new("Prototype", "Creational", "Clone existing objects to avoid costly creation", "FlowStep templates, ContextSection cloning", ["Factory", "Builder"]),
        new("Adapter", "Structural", "Bridge incompatible interfaces", "External AI SDK → IAiProvider, legacy DB → IDatabaseService", ["Facade", "Decorator"]),
        new("Decorator", "Structural", "Add behavior without modifying original", "Logging, caching, retry wrappers on any service", ["Adapter", "Proxy"]),
        new("Observer", "Behavioral", "Event-driven notifications", "Flow step events, feedback triggers, queue listeners", ["Mediator", "Command"]),
        new("Strategy", "Behavioral", "Swappable algorithms", "Merge strategies, scoring, distance metrics", ["Factory", "Template Method"]),
        new("Command", "Behavioral", "Encapsulate operations as objects", "Undo/redo in flow editor, queued operations", ["Observer", "Mediator"]),
        new("Chain of Responsibility", "Behavioral", "Pipeline processing", "Request middleware, validation, AI review pipeline", ["Decorator", "Strategy"]),
        new("Mediator", "Behavioral", "Decouple component communication", "Orchestrator dispatching between microservices", ["Observer", "Command"]),
        new("State", "Behavioral", "State machine", "Flow step states (Pending→Running→Completed/Failed)", ["Strategy", "Observer"]),
        new("Proxy", "Structural", "Lazy/cached access", "Lazy service init, cached DB results", ["Decorator", "Adapter"]),
        new("Template Method", "Behavioral", "Algorithm skeleton with hooks", "MicroserviceBase, FlowStepExecutor template", ["Strategy", "Factory"]),
        new("Composite", "Structural", "Tree structures", "Figma node trees, flow subgraphs, permission hierarchies", ["Visitor", "Iterator"]),
        new("Visitor", "Behavioral", "Operations on tree nodes", "Figma tree analysis, component extraction, code gen", ["Composite", "Iterator"]),
        new("Iterator", "Behavioral", "Sequential access", "Paginated DB results, flow step traversal", ["Composite", "Visitor"]),
        new("Facade", "Structural", "Simplified interface to complex subsystem", "FlowFacade hiding orchestrator complexity", ["Mediator", "Adapter"]),
        new("Repository", "Architectural", "Data access abstraction", "Generic repo over DatabaseFabric — dynamic docs", ["Factory", "Proxy"]),
    ];
}
