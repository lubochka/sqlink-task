# Skill 45: Design Patterns Library — Implementation Guide

## Phase 1: Pattern Catalog Setup (20 min)
1. Create `PatternCatalog` static class with all 19 patterns as records
2. Each pattern: Name, Category (Creational/Structural/Behavioral/Architectural), WhenToUse, XiigenUsage, Combinations
3. Store catalog in Elasticsearch `design-patterns` index for AI Context Service (Skill 16) to query
4. Index by: category, pattern name, XIIGen component references

## Phase 2: Creational Patterns (30 min)
Implement with XIIGen-specific examples:
1. **Singleton** — AppConfig, Logger (thread-safe lazy)
2. **Factory** — DatabaseFabric registry pattern (already in Skill 05)
3. **Builder** — FlowDefinitionBuilder with fluent API + validation
4. **Prototype** — StepTemplate deep clone via serialization

## Phase 3: Structural Patterns (30 min)
1. **Adapter** — External AI SDK → IAiProvider (already in Skill 06)
2. **Decorator** — Logging + Retry + Caching wrappers (stackable)
3. **Proxy** — CachedDatabaseProxy with TTL
4. **Composite** — Figma node tree (IFigmaNode with children)
5. **Facade** — FlowFacade hiding orchestrator complexity

## Phase 4: Behavioral Patterns (40 min)
1. **Observer** — FlowEventBus with subscribe/notify
2. **Strategy** — IMergeStrategy (Union/Intersection/Weighted)
3. **Command** — CommandHistory with execute/undo/redo
4. **Chain of Responsibility** — PipelineHandler<T> middleware chain
5. **Mediator** — ServiceMediator channel-based dispatch
6. **State** — StepStateMachine with valid transitions
7. **Template Method** — FlowStepExecutor abstract base
8. **Visitor** — IFigmaVisitor for tree analysis
9. **Iterator** — PaginatedIterator with async fetch

## Phase 5: Repository + Genie DNA (20 min)
1. **Repository** — DynamicRepository over DatabaseFabric
2. Integrate BuildSearchFilter (skip empty fields)
3. Integrate ParseObjectAlternative (recursive dynamic processing)
4. Ensure all dynamic document patterns match Genie DNA

## Phase 6: AI Context Integration (15 min)
1. Ensure PatternCatalog is queryable by Skill 16 (AI Context Service)
2. Pattern hints injected into AI prompts based on stepType
3. Test: "figma-parse" step → gets Composite + Visitor hints
4. Test: "ai-dispatch" step → gets Strategy + Factory hints

## Validation Checklist
- [ ] All 19 patterns implemented with XIIGen-specific examples
- [ ] Each pattern has: interface → implementation → usage context
- [ ] PatternCatalog indexable for Skill 16 queries
- [ ] Genie DNA patterns (BuildSearchFilter, ParseObjectAlternative) in Repository
- [ ] All 6 language alternatives follow same pattern structure
- [ ] Common combinations documented per pattern
