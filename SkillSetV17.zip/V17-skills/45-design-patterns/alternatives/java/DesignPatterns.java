// XIIGen Skill 45 — Design Patterns (Java 21 / Spring Boot 3)
// Key patterns with Java idioms: records, sealed, pattern matching
package com.xiigen.patterns;

import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;

// ═══════════════════════════════════════════════
// 1. SINGLETON — Spring @Bean or enum
// ═══════════════════════════════════════════════
enum AppConfig {
    INSTANCE;
    private String dbUrl;
    public String getDbUrl() { return dbUrl; }
    public void setDbUrl(String url) { this.dbUrl = url; }
}

// ═══════════════════════════════════════════════
// 2. FACTORY — Registry map
// ═══════════════════════════════════════════════
interface DatabaseService {
    List<Object> search(String index, Map<String, Object> filter, int limit);
}

class DatabaseFactory {
    private final Map<String, Supplier<DatabaseService>> registry = new HashMap<>();
    public void register(String name, Supplier<DatabaseService> factory) { registry.put(name, factory); }
    public DatabaseService create(String provider) {
        var factory = registry.get(provider);
        if (factory == null) throw new IllegalArgumentException("Unknown: " + provider);
        return factory.get();
    }
}

// ═══════════════════════════════════════════════
// 3. BUILDER — Fluent with validation
// ═══════════════════════════════════════════════
record FlowStep(String id, String type, Map<String, Object> config) {}
record FlowEdge(String from, String to, String condition) {}
record FlowDefinition(String name, List<FlowStep> steps, List<FlowEdge> edges) {}

class FlowDefinitionBuilder {
    private String name;
    private final List<FlowStep> steps = new ArrayList<>();
    private final List<FlowEdge> edges = new ArrayList<>();

    FlowDefinitionBuilder withName(String n) { this.name = n; return this; }
    FlowDefinitionBuilder addStep(String id, String type) { steps.add(new FlowStep(id, type, Map.of())); return this; }
    FlowDefinitionBuilder addEdge(String from, String to) { edges.add(new FlowEdge(from, to, null)); return this; }

    FlowDefinition build() {
        Objects.requireNonNull(name, "Flow name required");
        if (steps.isEmpty()) throw new IllegalStateException("At least one step required");
        return new FlowDefinition(name, List.copyOf(steps), List.copyOf(edges));
    }
}

// ═══════════════════════════════════════════════
// 5. ADAPTER
// ═══════════════════════════════════════════════
record PluginElement(String id, String tag, Map<String, String> style, List<PluginElement> children) {}
record FigmaNode(String id, String type, Map<String, String> css, List<FigmaNode> children) {}

class FigmaPluginAdapter {
    private static final Map<String, String> TYPE_MAP = Map.of("div","FRAME","text","TEXT","img","RECTANGLE","svg","VECTOR");
    
    FigmaNode adapt(PluginElement elem) {
        return new FigmaNode(elem.id(), TYPE_MAP.getOrDefault(elem.tag(), "FRAME"), elem.style(),
            elem.children() == null ? List.of() : elem.children().stream().map(this::adapt).toList());
    }
}

// ═══════════════════════════════════════════════
// 6. DECORATOR — Logging wrapper
// ═══════════════════════════════════════════════
class LoggingDatabaseDecorator implements DatabaseService {
    private final DatabaseService inner;
    LoggingDatabaseDecorator(DatabaseService inner) { this.inner = inner; }

    @Override public List<Object> search(String index, Map<String, Object> filter, int limit) {
        long start = System.currentTimeMillis();
        var result = inner.search(index, filter, limit);
        System.out.printf("DB.search(%s) → %d results in %dms%n", index, result.size(), System.currentTimeMillis()-start);
        return result;
    }
}

// ═══════════════════════════════════════════════
// 11. STRATEGY
// ═══════════════════════════════════════════════
interface AiProvider { CompletableFuture<Object> complete(Map<String, Object> request); }
interface DispatchStrategy { CompletableFuture<Object> execute(List<AiProvider> providers, Map<String, Object> request); }

class AllParallelStrategy implements DispatchStrategy {
    public CompletableFuture<Object> execute(List<AiProvider> providers, Map<String, Object> request) {
        var futures = providers.stream().map(p -> p.complete(request)).toList();
        return CompletableFuture.allOf(futures.toArray(new CompletableFuture[0]))
            .thenApply(v -> futures.stream().map(CompletableFuture::join).toList());
    }
}

class FallbackStrategy implements DispatchStrategy {
    public CompletableFuture<Object> execute(List<AiProvider> providers, Map<String, Object> request) {
        return CompletableFuture.supplyAsync(() -> {
            for (var p : providers) {
                try { return p.complete(request).join(); } catch (Exception ignored) {}
            }
            throw new RuntimeException("All providers failed");
        });
    }
}

// ═══════════════════════════════════════════════
// 12. OBSERVER — Java Flow API
// ═══════════════════════════════════════════════
class EventBus {
    private final Map<String, List<Consumer<Object>>> handlers = new ConcurrentHashMap<>();

    public Runnable on(String event, Consumer<Object> handler) {
        handlers.computeIfAbsent(event, k -> new CopyOnWriteArrayList<>()).add(handler);
        return () -> handlers.getOrDefault(event, List.of()).remove(handler);
    }

    public void emit(String event, Object data) {
        handlers.getOrDefault(event, List.of()).forEach(h -> h.accept(data));
    }
}

// ═══════════════════════════════════════════════
// 15. STATE — Sealed + pattern matching
// ═══════════════════════════════════════════════
enum FlowStatus { CREATED, RUNNING, PAUSED, COMPLETED, FAILED, CANCELLED }

class FlowStateMachine {
    private static final Map<String, FlowStatus> TRANSITIONS = Map.of(
        "CREATED:start", FlowStatus.RUNNING, "RUNNING:pause", FlowStatus.PAUSED,
        "RUNNING:complete", FlowStatus.COMPLETED, "RUNNING:fail", FlowStatus.FAILED,
        "PAUSED:resume", FlowStatus.RUNNING, "PAUSED:cancel", FlowStatus.CANCELLED
    );

    FlowStatus transition(FlowStatus current, String action) {
        var key = current.name() + ":" + action;
        var next = TRANSITIONS.get(key);
        if (next == null) throw new IllegalStateException("Invalid: " + key);
        return next;
    }
}

// ═══════════════════════════════════════════════
// 16. TEMPLATE METHOD
// ═══════════════════════════════════════════════
abstract class StepExecutorBase {
    public final Object execute(Map<String, Object> input) throws Exception {
        var context = buildContext(input);
        var result = process(context);
        storeResult((String) input.get("traceId"), result);
        return result;
    }
    protected abstract Object buildContext(Map<String, Object> input) throws Exception;
    protected abstract Object process(Object context) throws Exception;
    protected void storeResult(String traceId, Object result) { /* DB insert */ }
}

// ═══════════════════════════════════════════════
// 18. MEMENTO
// ═══════════════════════════════════════════════
record FlowCheckpoint(String flowId, String traceId, FlowStatus status,
                       Map<String, Object> stepStates, java.time.Instant savedAt) {}

class CheckpointManager {
    private final Map<String, FlowCheckpoint> store = new ConcurrentHashMap<>();
    FlowCheckpoint save(String flowId, String traceId, FlowStatus status, Map<String, Object> states) {
        var cp = new FlowCheckpoint(flowId, traceId, status, Map.copyOf(states), java.time.Instant.now());
        store.put(traceId, cp); return cp;
    }
    Optional<FlowCheckpoint> restore(String traceId) { return Optional.ofNullable(store.get(traceId)); }
}

// ═══════════════════════════════════════════════
// 19. VISITOR
// ═══════════════════════════════════════════════
interface NodeVisitor<T> {
    T visitFrame(FigmaNode node);
    T visitText(FigmaNode node);
    T visitRectangle(FigmaNode node);
    T visitVector(FigmaNode node);
}

class HtmlGeneratorVisitor implements NodeVisitor<String> {
    public String visit(FigmaNode node) {
        return switch (node.type()) {
            case "FRAME" -> visitFrame(node);
            case "TEXT" -> visitText(node);
            case "RECTANGLE" -> visitRectangle(node);
            case "VECTOR" -> visitVector(node);
            default -> visitFrame(node);
        };
    }

    public String visitFrame(FigmaNode n) {
        var children = n.children().stream().map(this::visit).reduce("", String::concat);
        return "<div style=\"" + cssString(n) + "\">" + children + "</div>";
    }
    public String visitText(FigmaNode n) { return "<span style=\"" + cssString(n) + "\">text</span>"; }
    public String visitRectangle(FigmaNode n) { return "<div style=\"" + cssString(n) + "\"></div>"; }
    public String visitVector(FigmaNode n) { return "<svg></svg>"; }

    private String cssString(FigmaNode n) {
        return n.css().entrySet().stream().map(e -> e.getKey()+":"+e.getValue()).reduce((a,b)->a+";"+b).orElse("");
    }
}
