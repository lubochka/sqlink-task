# XIIGen Skill 45 — Design Patterns (Python 3.12)
# All 19 patterns with Python idioms: dataclasses, ABC, protocols, match

from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Protocol, Any, Callable
from copy import deepcopy
from enum import Enum
import asyncio

# ═══════════════════════════════════════════════
# 1. SINGLETON — Module-level or metaclass
# ═══════════════════════════════════════════════
class SingletonMeta(type):
    _instances: dict = {}
    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super().__call__(*args, **kwargs)
        return cls._instances[cls]

class AppConfig(metaclass=SingletonMeta):
    def __init__(self): self.db_url = ""

# ═══════════════════════════════════════════════
# 2. FACTORY — Registry dict
# ═══════════════════════════════════════════════
class DatabaseService(Protocol):
    async def search(self, index: str, filter: dict, limit: int) -> list: ...

_db_registry: dict[str, Callable[[], DatabaseService]] = {}

def register_db(name: str, factory: Callable[[], DatabaseService]):
    _db_registry[name] = factory

def create_database(provider: str) -> DatabaseService:
    if provider not in _db_registry:
        raise ValueError(f"Unknown provider: {provider}")
    return _db_registry[provider]()

# ═══════════════════════════════════════════════
# 3. BUILDER — Fluent dataclass construction
# ═══════════════════════════════════════════════
@dataclass
class FlowStep:
    id: str; type: str; config: dict = field(default_factory=dict)

@dataclass
class FlowEdge:
    from_id: str; to_id: str; condition: str | None = None

class FlowDefinitionBuilder:
    def __init__(self):
        self._name = ""; self._steps: list[FlowStep] = []; self._edges: list[FlowEdge] = []

    def with_name(self, name: str) -> FlowDefinitionBuilder:
        self._name = name; return self
    def add_step(self, id: str, type: str, config: dict | None = None) -> FlowDefinitionBuilder:
        self._steps.append(FlowStep(id, type, config or {})); return self
    def add_edge(self, from_id: str, to_id: str, condition: str | None = None) -> FlowDefinitionBuilder:
        self._edges.append(FlowEdge(from_id, to_id, condition)); return self

    def build(self) -> dict:
        assert self._name, "Flow name required"
        assert self._steps, "At least one step required"
        return {"name": self._name, "steps": self._steps, "edges": self._edges}

# ═══════════════════════════════════════════════
# 4. PROTOTYPE — deepcopy
# ═══════════════════════════════════════════════
@dataclass
class StepTemplate:
    type: str; default_config: dict
    def clone(self) -> StepTemplate:
        return StepTemplate(self.type, deepcopy(self.default_config))

# ═══════════════════════════════════════════════
# 5. ADAPTER
# ═══════════════════════════════════════════════
def adapt_plugin_to_figma(element: dict) -> dict:
    type_map = {"div": "FRAME", "text": "TEXT", "img": "RECTANGLE", "svg": "VECTOR"}
    return {
        "id": element["id"], "type": type_map.get(element.get("tag", ""), "FRAME"),
        "css": element.get("style", {}),
        "children": [adapt_plugin_to_figma(c) for c in element.get("children", [])]
    }

# ═══════════════════════════════════════════════
# 6. DECORATOR — Function wrapper
# ═══════════════════════════════════════════════
import functools, time, logging

def with_logging(func):
    @functools.wraps(func)
    async def wrapper(*args, **kwargs):
        start = time.time()
        result = await func(*args, **kwargs)
        logging.info(f"{func.__name__} completed in {(time.time()-start)*1000:.1f}ms")
        return result
    return wrapper

# ═══════════════════════════════════════════════
# 7. FACADE
# ═══════════════════════════════════════════════
class AiProvider(Protocol):
    async def complete(self, request: dict) -> dict: ...

class AiDispatcher:
    def __init__(self, providers: list[AiProvider]): self.providers = providers

    async def dispatch(self, request: dict, strategy: str = "all") -> Any:
        match strategy:
            case "all":
                return await asyncio.gather(*(p.complete(request) for p in self.providers))
            case "fallback":
                for p in self.providers:
                    try: return await p.complete(request)
                    except: continue
                raise RuntimeError("All providers failed")
            case "consensus":
                results = await asyncio.gather(
                    *(p.complete(request) for p in self.providers), return_exceptions=True)
                return [r for r in results if not isinstance(r, Exception)]

# ═══════════════════════════════════════════════
# 11. STRATEGY — Protocol-based
# ═══════════════════════════════════════════════
class DispatchStrategy(Protocol):
    async def execute(self, providers: list[AiProvider], request: dict) -> Any: ...

class AllParallelStrategy:
    async def execute(self, providers, request):
        return await asyncio.gather(*(p.complete(request) for p in providers))

class FallbackStrategy:
    async def execute(self, providers, request):
        for p in providers:
            try: return await p.complete(request)
            except: continue
        raise RuntimeError("All providers failed")

# ═══════════════════════════════════════════════
# 12. OBSERVER — Async event bus
# ═══════════════════════════════════════════════
class EventBus:
    def __init__(self): self._handlers: dict[str, list[Callable]] = {}

    def on(self, event: str, handler: Callable):
        self._handlers.setdefault(event, []).append(handler)
        return lambda: self._handlers[event].remove(handler)

    async def emit(self, event: str, data: Any = None):
        for handler in self._handlers.get(event, []):
            result = handler(data)
            if asyncio.iscoroutine(result): await result

# ═══════════════════════════════════════════════
# 13. CHAIN OF RESPONSIBILITY
# ═══════════════════════════════════════════════
Middleware = Callable  # (ctx, next) -> awaitable

def compose_middleware(middlewares: list[Middleware]) -> Callable:
    async def composed(ctx):
        async def dispatch(i):
            if i >= len(middlewares): return
            await middlewares[i](ctx, lambda: dispatch(i + 1))
        await dispatch(0)
    return composed

# ═══════════════════════════════════════════════
# 14. COMMAND
# ═══════════════════════════════════════════════
class Command(ABC):
    @abstractmethod
    async def execute(self) -> Any: ...
    async def undo(self) -> None: pass

class AiTransformCommand(Command):
    def __init__(self, dispatcher: AiDispatcher, input_data: dict):
        self.dispatcher = dispatcher; self.input = input_data; self.result = None
    async def execute(self):
        self.result = await self.dispatcher.dispatch(self.input)
        return self.result

# ═══════════════════════════════════════════════
# 15. STATE — Enum + transition table
# ═══════════════════════════════════════════════
class FlowStatus(Enum):
    CREATED = "created"; RUNNING = "running"; PAUSED = "paused"
    COMPLETED = "completed"; FAILED = "failed"; CANCELLED = "cancelled"

_transitions = {
    (FlowStatus.CREATED, "start"): FlowStatus.RUNNING,
    (FlowStatus.RUNNING, "pause"): FlowStatus.PAUSED,
    (FlowStatus.RUNNING, "complete"): FlowStatus.COMPLETED,
    (FlowStatus.RUNNING, "fail"): FlowStatus.FAILED,
    (FlowStatus.PAUSED, "resume"): FlowStatus.RUNNING,
    (FlowStatus.PAUSED, "cancel"): FlowStatus.CANCELLED,
}

def transition(current: FlowStatus, action: str) -> FlowStatus:
    key = (current, action)
    if key not in _transitions:
        raise ValueError(f"Invalid transition: {current.value} + {action}")
    return _transitions[key]

# ═══════════════════════════════════════════════
# 16. TEMPLATE METHOD
# ═══════════════════════════════════════════════
class StepExecutorBase(ABC):
    async def execute(self, input_data: dict) -> Any:
        context = await self.build_context(input_data)
        result = await self.process(context)
        await self.store_result(input_data.get("traceId", ""), result)
        return result

    @abstractmethod
    async def build_context(self, input_data: dict) -> Any: ...
    @abstractmethod
    async def process(self, context: Any) -> Any: ...
    async def store_result(self, trace_id: str, result: Any): pass  # DB insert

# ═══════════════════════════════════════════════
# 17. MEDIATOR
# ═══════════════════════════════════════════════
class FlowOrchestrator:
    def __init__(self): self._executors: dict[str, StepExecutorBase] = {}
    def register(self, type_name: str, executor: StepExecutorBase):
        self._executors[type_name] = executor
    async def orchestrate(self, flow: dict):
        for step in flow.get("steps", []):
            executor = self._executors.get(step["type"])
            if not executor: raise ValueError(f"No executor for: {step['type']}")
            await executor.execute(step.get("input", {}))

# ═══════════════════════════════════════════════
# 18. MEMENTO
# ═══════════════════════════════════════════════
@dataclass
class FlowCheckpoint:
    flow_id: str; trace_id: str; status: FlowStatus
    step_states: dict; saved_at: str = field(default_factory=lambda: "")

class CheckpointManager:
    def __init__(self): self._store: dict[str, FlowCheckpoint] = {}
    def save(self, state: dict) -> FlowCheckpoint:
        cp = FlowCheckpoint(**state)
        self._store[state["trace_id"]] = cp; return cp
    def restore(self, trace_id: str) -> FlowCheckpoint | None:
        return self._store.get(trace_id)

# ═══════════════════════════════════════════════
# 19. VISITOR
# ═══════════════════════════════════════════════
class NodeVisitor(ABC):
    @abstractmethod
    def visit_frame(self, node: dict) -> str: ...
    @abstractmethod
    def visit_text(self, node: dict) -> str: ...

class HtmlGeneratorVisitor(NodeVisitor):
    def visit(self, node: dict) -> str:
        visitors = {"FRAME": self.visit_frame, "TEXT": self.visit_text,
                     "RECTANGLE": self.visit_rect, "VECTOR": self.visit_vector}
        return visitors.get(node.get("type", "FRAME"), self.visit_frame)(node)

    def visit_frame(self, node):
        children = "".join(self.visit(c) for c in node.get("children", []))
        return f'<div style="{self._css(node)}">{children}</div>'
    def visit_text(self, node): return f'<span style="{self._css(node)}">text</span>'
    def visit_rect(self, node): return f'<div style="{self._css(node)}"></div>'
    def visit_vector(self, node): return "<svg></svg>"
    def _css(self, node): return ";".join(f"{k}:{v}" for k, v in node.get("css", {}).items())
