// XIIGen Skill 45 — Design Patterns (Node.js/TypeScript)
// All 19 patterns implemented with TypeScript idioms

// ═══════════════════════════════════════════════
// 1. SINGLETON — Use module-level instance
// ═══════════════════════════════════════════════
class AppConfig {
  private static instance: AppConfig;
  private constructor(public readonly dbUrl: string = process.env.DB_URL ?? '') {}
  static getInstance(): AppConfig {
    if (!AppConfig.instance) AppConfig.instance = new AppConfig();
    return AppConfig.instance;
  }
}

// ═══════════════════════════════════════════════
// 2. FACTORY — Registry-based creation
// ═══════════════════════════════════════════════
interface IDatabaseService {
  search(index: string, filter: any, limit: number): Promise<any[]>;
}

type DbFactory = () => IDatabaseService;
const dbRegistry = new Map<string, DbFactory>();
dbRegistry.set('elasticsearch', () => new ElasticsearchService());
dbRegistry.set('mongodb', () => new MongoService());

function createDatabase(provider: string): IDatabaseService {
  const factory = dbRegistry.get(provider);
  if (!factory) throw new Error(`Unknown provider: ${provider}`);
  return factory();
}

// ═══════════════════════════════════════════════
// 3. BUILDER — Fluent chain
// ═══════════════════════════════════════════════
class FlowDefinitionBuilder {
  private steps: Array<{ id: string; type: string; config?: any }> = [];
  private edges: Array<{ from: string; to: string; condition?: string }> = [];
  private name = '';

  withName(name: string) { this.name = name; return this; }
  addStep(id: string, type: string, config?: any) { this.steps.push({ id, type, config }); return this; }
  addEdge(from: string, to: string, condition?: string) { this.edges.push({ from, to, condition }); return this; }
  
  build() {
    if (!this.name) throw new Error('Flow name required');
    if (this.steps.length === 0) throw new Error('At least one step required');
    return { name: this.name, steps: [...this.steps], edges: [...this.edges] };
  }
}

// ═══════════════════════════════════════════════
// 4. PROTOTYPE — Structured clone
// ═══════════════════════════════════════════════
interface Cloneable<T> { clone(): T; }

class StepTemplate implements Cloneable<StepTemplate> {
  constructor(public type: string, public defaultConfig: Record<string, any>) {}
  clone(): StepTemplate { return new StepTemplate(this.type, structuredClone(this.defaultConfig)); }
}

// ═══════════════════════════════════════════════
// 5. ADAPTER — Convert Figma plugin format
// ═══════════════════════════════════════════════
interface PluginElement { id: string; tag: string; style: Record<string, string>; children?: PluginElement[]; }
interface FigmaNode { id: string; type: string; css: Record<string, string>; children: FigmaNode[]; }

function adaptPluginToFigma(element: PluginElement): FigmaNode {
  const typeMap: Record<string, string> = { div: 'FRAME', text: 'TEXT', img: 'RECTANGLE', svg: 'VECTOR' };
  return {
    id: element.id, type: typeMap[element.tag] ?? 'FRAME', css: element.style,
    children: (element.children ?? []).map(adaptPluginToFigma)
  };
}

// ═══════════════════════════════════════════════
// 6. DECORATOR — Wrap with logging
// ═══════════════════════════════════════════════
function withLogging<T extends IDatabaseService>(service: T, logger: any): IDatabaseService {
  return new Proxy(service, {
    get(target, prop) {
      const orig = (target as any)[prop];
      if (typeof orig !== 'function') return orig;
      return async (...args: any[]) => {
        const start = Date.now();
        const result = await orig.apply(target, args);
        logger.info(`${String(prop)} completed in ${Date.now() - start}ms`);
        return result;
      };
    }
  });
}

// ═══════════════════════════════════════════════
// 7. FACADE — AiDispatcher
// ═══════════════════════════════════════════════
interface IAiProvider { complete(request: any): Promise<any>; }

class AiDispatcher {
  constructor(private providers: IAiProvider[]) {}
  
  async dispatch(request: any, strategy: 'all' | 'fallback' | 'consensus' = 'all') {
    switch (strategy) {
      case 'all': return Promise.all(this.providers.map(p => p.complete(request)));
      case 'fallback':
        for (const p of this.providers) {
          try { return await p.complete(request); } catch { continue; }
        }
        throw new Error('All providers failed');
      case 'consensus':
        const results = await Promise.allSettled(this.providers.map(p => p.complete(request)));
        return results.filter(r => r.status === 'fulfilled').map(r => (r as any).value);
    }
  }
}

// ═══════════════════════════════════════════════
// 11. STRATEGY — Dispatch strategies
// ═══════════════════════════════════════════════
interface DispatchStrategy { execute(providers: IAiProvider[], request: any): Promise<any>; }

class AllParallelStrategy implements DispatchStrategy {
  async execute(providers: IAiProvider[], request: any) {
    return Promise.all(providers.map(p => p.complete(request)));
  }
}

class FallbackStrategy implements DispatchStrategy {
  async execute(providers: IAiProvider[], request: any) {
    for (const p of providers) {
      try { return await p.complete(request); } catch { continue; }
    }
    throw new Error('All providers failed');
  }
}

// ═══════════════════════════════════════════════
// 12. OBSERVER — Event bus with typed events
// ═══════════════════════════════════════════════
type EventHandler<T = any> = (data: T) => void | Promise<void>;

class EventBus {
  private handlers = new Map<string, Set<EventHandler>>();

  on<T>(event: string, handler: EventHandler<T>) {
    if (!this.handlers.has(event)) this.handlers.set(event, new Set());
    this.handlers.get(event)!.add(handler);
    return () => this.handlers.get(event)?.delete(handler); // unsubscribe
  }

  async emit<T>(event: string, data: T) {
    for (const handler of this.handlers.get(event) ?? [])
      await handler(data);
  }
}

// ═══════════════════════════════════════════════
// 13. CHAIN OF RESPONSIBILITY — Middleware
// ═══════════════════════════════════════════════
type Middleware = (ctx: any, next: () => Promise<void>) => Promise<void>;

function compose(middlewares: Middleware[]): (ctx: any) => Promise<void> {
  return async (ctx) => {
    let index = -1;
    async function dispatch(i: number): Promise<void> {
      if (i <= index) throw new Error('next() called multiple times');
      index = i;
      if (i >= middlewares.length) return;
      await middlewares[i](ctx, () => dispatch(i + 1));
    }
    await dispatch(0);
  };
}

// ═══════════════════════════════════════════════
// 14. COMMAND — Queue messages as commands
// ═══════════════════════════════════════════════
interface Command { execute(): Promise<any>; undo?(): Promise<void>; }

class AiTransformCommand implements Command {
  constructor(private dispatcher: AiDispatcher, private input: any) {}
  private result?: any;
  async execute() { this.result = await this.dispatcher.dispatch(this.input); return this.result; }
  async undo() { /* delete stored result */ }
}

// ═══════════════════════════════════════════════
// 15. STATE — Flow state machine
// ═══════════════════════════════════════════════
type FlowStatus = 'created' | 'running' | 'paused' | 'completed' | 'failed' | 'cancelled';

const transitions: Record<string, FlowStatus> = {
  'created:start': 'running', 'running:pause': 'paused',
  'running:complete': 'completed', 'running:fail': 'failed',
  'paused:resume': 'running', 'paused:cancel': 'cancelled'
};

function transition(current: FlowStatus, action: string): FlowStatus {
  const next = transitions[`${current}:${action}`];
  if (!next) throw new Error(`Invalid: ${current} + ${action}`);
  return next;
}

// ═══════════════════════════════════════════════
// 16. TEMPLATE METHOD — Step executor base
// ═══════════════════════════════════════════════
abstract class StepExecutorBase {
  async execute(input: any): Promise<any> {
    const context = await this.buildContext(input);   // override
    const result = await this.process(context);        // override
    await this.storeResult(input.traceId, result);     // shared
    return result;
  }
  protected abstract buildContext(input: any): Promise<any>;
  protected abstract process(context: any): Promise<any>;
  protected async storeResult(traceId: string, result: any) { /* db insert */ }
}

// ═══════════════════════════════════════════════
// 17. MEDIATOR — Flow orchestrator
// ═══════════════════════════════════════════════
class FlowOrchestrator {
  private executors = new Map<string, StepExecutorBase>();
  register(type: string, executor: StepExecutorBase) { this.executors.set(type, executor); }
  async orchestrate(flow: any) {
    for (const step of this.topologicalSort(flow)) {
      const executor = this.executors.get(step.type);
      if (!executor) throw new Error(`No executor for: ${step.type}`);
      await executor.execute(step.input);
    }
  }
  private topologicalSort(flow: any): any[] { /* Kahn's algorithm */ return flow.steps; }
}

// ═══════════════════════════════════════════════
// 18. MEMENTO — Flow checkpoints
// ═══════════════════════════════════════════════
interface FlowCheckpoint { flowId: string; traceId: string; status: FlowStatus; stepStates: Record<string, any>; savedAt: Date; }

class CheckpointManager {
  private store = new Map<string, FlowCheckpoint>();
  save(state: any): FlowCheckpoint {
    const cp: FlowCheckpoint = { ...state, savedAt: new Date() };
    this.store.set(state.traceId, cp);
    return cp;
  }
  restore(traceId: string): FlowCheckpoint | undefined { return this.store.get(traceId); }
}

// ═══════════════════════════════════════════════
// 19. VISITOR — Figma node tree traversal
// ═══════════════════════════════════════════════
interface NodeVisitor<T> {
  visitFrame(node: FigmaNode): T;
  visitText(node: FigmaNode): T;
  visitRectangle(node: FigmaNode): T;
  visitVector(node: FigmaNode): T;
}

class HtmlGeneratorVisitor implements NodeVisitor<string> {
  visitFrame(node: FigmaNode): string {
    const children = node.children.map(c => this.visit(c)).join('');
    return `<div style="${this.cssString(node.css)}">${children}</div>`;
  }
  visitText(node: FigmaNode) { return `<span style="${this.cssString(node.css)}">text</span>`; }
  visitRectangle(node: FigmaNode) { return `<div style="${this.cssString(node.css)}"></div>`; }
  visitVector(node: FigmaNode) { return `<svg></svg>`; }

  visit(node: FigmaNode): string {
    const visitors: Record<string, (n: FigmaNode) => string> = {
      FRAME: (n) => this.visitFrame(n), TEXT: (n) => this.visitText(n),
      RECTANGLE: (n) => this.visitRectangle(n), VECTOR: (n) => this.visitVector(n)
    };
    return (visitors[node.type] ?? this.visitFrame).call(this, node);
  }

  private cssString(css: Record<string, string>): string {
    return Object.entries(css).map(([k, v]) => `${k}:${v}`).join(';');
  }
}

export {
  AppConfig, FlowDefinitionBuilder, StepTemplate, AiDispatcher,
  EventBus, FlowOrchestrator, CheckpointManager, HtmlGeneratorVisitor,
  adaptPluginToFigma, withLogging, compose, transition, createDatabase
};
