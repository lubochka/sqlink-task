<?php
// XIIGen Skill 45 — Design Patterns (PHP 8.3 / Laravel)
// All 19 patterns implemented with modern PHP idioms

declare(strict_types=1);

// ═══════════════════════════════════════════════
// 1. SINGLETON — Private constructor + static
// ═══════════════════════════════════════════════
class AppConfig
{
    private static ?self $instance = null;

    private function __construct(
        public readonly string $dbUrl,
        public readonly int $cacheTtl = 300,
    ) {}

    public static function getInstance(): self
    {
        return self::$instance ??= new self(
            dbUrl: env('DB_URL', ''),
            cacheTtl: (int) env('CACHE_TTL', 300),
        );
    }
}

// ═══════════════════════════════════════════════
// 2. FACTORY — Registry-based creation
// ═══════════════════════════════════════════════
interface DatabaseService
{
    public function search(string $index, array $filter, int $limit): array;
}

class DatabaseFactory
{
    private static array $registry = [];

    public static function register(string $name, \Closure $factory): void
    {
        self::$registry[$name] = $factory;
    }

    public static function create(string $provider): DatabaseService
    {
        $factory = self::$registry[$provider] ?? throw new \InvalidArgumentException(
            "Unknown provider: {$provider}"
        );
        return $factory();
    }
}

// Usage: DatabaseFactory::register('elasticsearch', fn() => new ElasticsearchService());

// ═══════════════════════════════════════════════
// 3. BUILDER — Fluent chain with readonly DTO
// ═══════════════════════════════════════════════
readonly class FlowStep
{
    public function __construct(
        public string $id,
        public string $type,
        public array $config = [],
    ) {}
}

readonly class FlowEdge
{
    public function __construct(
        public string $from,
        public string $to,
        public ?string $condition = null,
    ) {}
}

readonly class FlowDefinition
{
    public function __construct(
        public string $name,
        public array $steps,
        public array $edges,
    ) {}
}

class FlowDefinitionBuilder
{
    private ?string $name = null;
    private array $steps = [];
    private array $edges = [];

    public function name(string $name): static { $this->name = $name; return $this; }

    public function step(string $id, string $type, array $config = []): static
    {
        $this->steps[] = new FlowStep($id, $type, $config);
        return $this;
    }

    public function edge(string $from, string $to, ?string $condition = null): static
    {
        $this->edges[] = new FlowEdge($from, $to, $condition);
        return $this;
    }

    public function build(): FlowDefinition
    {
        if (!$this->name) throw new \RuntimeException('Flow name required');
        if (empty($this->steps)) throw new \RuntimeException('At least one step required');
        return new FlowDefinition($this->name, $this->steps, $this->edges);
    }
}

// ═══════════════════════════════════════════════
// 4. PROTOTYPE — Clone with deep copy
// ═══════════════════════════════════════════════
class StepTemplate
{
    public function __construct(
        public string $type,
        public array $defaultConfig,
    ) {}

    public function createInstance(string $id): FlowStep
    {
        return new FlowStep($id, $this->type, $this->defaultConfig);
    }

    public function __clone(): void
    {
        // Deep copy nested arrays
        $this->defaultConfig = json_decode(json_encode($this->defaultConfig), true);
    }
}

// ═══════════════════════════════════════════════
// 5. ADAPTER — Wrap Figma API to our interface
// ═══════════════════════════════════════════════
class FigmaNodeRaw
{
    public function __construct(
        public string $nodeId,
        public string $nodeType,
        public array $properties = [],
    ) {}
}

class XiigenComponent
{
    public function __construct(
        public string $id,
        public string $componentType,
        public array $styles = [],
    ) {}
}

class FigmaAdapter
{
    private const TYPE_MAP = [
        'FRAME' => 'Container', 'TEXT' => 'Text',
        'RECTANGLE' => 'Box', 'INSTANCE' => 'Component',
    ];

    public static function adapt(FigmaNodeRaw $raw): XiigenComponent
    {
        return new XiigenComponent(
            id: $raw->nodeId,
            componentType: self::TYPE_MAP[$raw->nodeType] ?? 'Unknown',
            styles: $raw->properties,
        );
    }
}

// ═══════════════════════════════════════════════
// 6. DECORATOR — Wrapping with same interface
// ═══════════════════════════════════════════════
interface AiProvider
{
    public function generate(string $prompt): string;
}

class LoggingAiProvider implements AiProvider
{
    public function __construct(
        private AiProvider $inner,
        private string $serviceName,
    ) {}

    public function generate(string $prompt): string
    {
        $start = microtime(true);
        logger()->info("[{$this->serviceName}] AI request", ['prompt_len' => strlen($prompt)]);
        $result = $this->inner->generate($prompt);
        $elapsed = round((microtime(true) - $start) * 1000);
        logger()->info("[{$this->serviceName}] AI response in {$elapsed}ms");
        return $result;
    }
}

class RetryAiProvider implements AiProvider
{
    public function __construct(
        private AiProvider $inner,
        private int $maxRetries = 3,
    ) {}

    public function generate(string $prompt): string
    {
        $lastException = null;
        for ($i = 0; $i <= $this->maxRetries; $i++) {
            try {
                return $this->inner->generate($prompt);
            } catch (\Throwable $e) {
                $lastException = $e;
                if ($i < $this->maxRetries) usleep(100_000 * ($i + 1));
            }
        }
        throw $lastException;
    }
}

// ═══════════════════════════════════════════════
// 7. FACADE — Simple interface over complex AI dispatch
// ═══════════════════════════════════════════════
class AiDispatcherFacade
{
    /** @param AiProvider[] $providers */
    public function __construct(private array $providers) {}

    public function dispatchAll(string $prompt): array
    {
        return array_map(function (AiProvider $p) use ($prompt) {
            try { return ['success' => true, 'result' => $p->generate($prompt)]; }
            catch (\Throwable $e) { return ['success' => false, 'error' => $e->getMessage()]; }
        }, $this->providers);
    }

    public function dispatchFirstSuccess(string $prompt): string
    {
        foreach ($this->providers as $provider) {
            try { return $provider->generate($prompt); }
            catch (\Throwable) { continue; }
        }
        throw new \RuntimeException('All providers failed');
    }
}

// ═══════════════════════════════════════════════
// 8. PROXY — Caching + access control
// ═══════════════════════════════════════════════
class CachingDbProxy implements DatabaseService
{
    public function __construct(
        private DatabaseService $inner,
        private int $ttlSeconds = 60,
    ) {}

    public function search(string $index, array $filter, int $limit): array
    {
        $key = "db_proxy:" . md5("{$index}:" . json_encode($filter) . ":{$limit}");
        return cache()->remember($key, $this->ttlSeconds, fn() => $this->inner->search($index, $filter, $limit));
    }
}

// ═══════════════════════════════════════════════
// 9. BRIDGE — Separate abstraction from implementation
// ═══════════════════════════════════════════════
interface QueueBackend
{
    public function enqueue(string $queue, array $data): string;
    public function dequeue(string $queue): ?array;
}

class JobQueue
{
    public function __construct(
        private QueueBackend $backend,
        private string $queueName,
    ) {}

    public function submit(array $job): string { return $this->backend->enqueue($this->queueName, $job); }
    public function poll(): ?array { return $this->backend->dequeue($this->queueName); }
}

// ═══════════════════════════════════════════════
// 10. FLYWEIGHT — Shared design tokens
// ═══════════════════════════════════════════════
readonly class DesignToken
{
    public function __construct(
        public string $color,
        public string $font,
        public float $spacing,
    ) {}
}

class DesignTokenPool
{
    private array $tokens = [];

    public function getOrCreate(string $key, string $color, string $font, float $spacing): DesignToken
    {
        return $this->tokens[$key] ??= new DesignToken($color, $font, $spacing);
    }

    public function count(): int { return count($this->tokens); }
}

// ═══════════════════════════════════════════════
// 11. STRATEGY — AI dispatch modes
// ═══════════════════════════════════════════════
interface DispatchStrategy
{
    /** @param AiProvider[] $providers */
    public function execute(array $providers, string $prompt): array;
}

class AllStrategy implements DispatchStrategy
{
    public function execute(array $providers, string $prompt): array
    {
        return array_filter(array_map(function (AiProvider $p) use ($prompt) {
            try { return $p->generate($prompt); }
            catch (\Throwable) { return null; }
        }, $providers));
    }
}

class FallbackStrategy implements DispatchStrategy
{
    public function execute(array $providers, string $prompt): array
    {
        foreach ($providers as $p) {
            try { return [$p->generate($prompt)]; }
            catch (\Throwable) { continue; }
        }
        throw new \RuntimeException('All providers failed');
    }
}

class ConsensusStrategy implements DispatchStrategy
{
    public function execute(array $providers, string $prompt): array
    {
        $results = (new AllStrategy())->execute($providers, $prompt);
        // Return most common result
        $counts = array_count_values($results);
        arsort($counts);
        return [array_key_first($counts)];
    }
}

// ═══════════════════════════════════════════════
// 12. OBSERVER — Event dispatcher (Laravel Events)
// ═══════════════════════════════════════════════
readonly class FlowEvent
{
    public function __construct(
        public string $flowId,
        public string $stepId,
        public string $eventType,
        public array $data = [],
    ) {}
}

class FlowEventBus
{
    /** @var array<string, callable[]> */
    private array $listeners = [];

    public function on(string $eventType, callable $listener): void
    {
        $this->listeners[$eventType][] = $listener;
    }

    public function emit(FlowEvent $event): void
    {
        foreach ($this->listeners[$event->eventType] ?? [] as $listener) {
            $listener($event);
        }
        // Also emit wildcard
        foreach ($this->listeners['*'] ?? [] as $listener) {
            $listener($event);
        }
    }
}

// ═══════════════════════════════════════════════
// 13. CHAIN OF RESPONSIBILITY — Middleware pipeline
// ═══════════════════════════════════════════════
interface Middleware
{
    public function handle(array $request, \Closure $next): array;
}

class AuthMiddleware implements Middleware
{
    public function handle(array $request, \Closure $next): array
    {
        $token = $request['headers']['Authorization'] ?? null;
        if (!$token) return ['status' => 401, 'body' => 'Unauthorized'];
        return $next($request);
    }
}

class LogMiddleware implements Middleware
{
    public function handle(array $request, \Closure $next): array
    {
        $start = microtime(true);
        $response = $next($request);
        $elapsed = round((microtime(true) - $start) * 1000);
        logger()->info("{$request['method']} {$request['path']} → {$response['status']} in {$elapsed}ms");
        return $response;
    }
}

class MiddlewarePipeline
{
    /** @param Middleware[] $middlewares */
    public function __construct(private array $middlewares = []) {}

    public function pipe(Middleware $m): static { $this->middlewares[] = $m; return $this; }

    public function run(array $request, \Closure $handler): array
    {
        $pipeline = array_reduce(
            array_reverse($this->middlewares),
            fn(\Closure $next, Middleware $m) => fn(array $req) => $m->handle($req, $next),
            $handler
        );
        return $pipeline($request);
    }
}

// ═══════════════════════════════════════════════
// 14. COMMAND — Execute/undo with history
// ═══════════════════════════════════════════════
interface Command
{
    public function execute(): array;
    public function undo(): void;
    public function description(): string;
}

class CreateFlowCommand implements Command
{
    public function __construct(private FlowDefinition $flowDef) {}

    public function execute(): array
    {
        // Save flow to DB
        return ['flow_id' => 'new-flow-123', 'status' => 'created'];
    }

    public function undo(): void
    {
        // Delete the created flow
    }

    public function description(): string { return "Create flow: {$this->flowDef->name}"; }
}

class CommandHistory
{
    private array $executed = [];

    public function execute(Command $cmd): array
    {
        $result = $cmd->execute();
        $this->executed[] = $cmd;
        return $result;
    }

    public function undoLast(): void
    {
        $cmd = array_pop($this->executed);
        $cmd?->undo();
    }
}

// ═══════════════════════════════════════════════
// 15. STATE — Flow status transitions (enum)
// ═══════════════════════════════════════════════
enum FlowStatus: string
{
    case Created = 'created';
    case Running = 'running';
    case Paused = 'paused';
    case Completed = 'completed';
    case Failed = 'failed';
    case Cancelled = 'cancelled';

    public function canTransitionTo(self $target): bool
    {
        return match($this) {
            self::Created   => in_array($target, [self::Running]),
            self::Running   => in_array($target, [self::Paused, self::Completed, self::Failed, self::Cancelled]),
            self::Paused    => in_array($target, [self::Running, self::Cancelled]),
            self::Failed    => in_array($target, [self::Running]),
            default         => false,
        };
    }

    public function transition(self $target): self
    {
        if (!$this->canTransitionTo($target)) {
            throw new \LogicException("Cannot transition from {$this->value} to {$target->value}");
        }
        return $target;
    }
}

// ═══════════════════════════════════════════════
// 16. TEMPLATE METHOD — Abstract base with hooks
// ═══════════════════════════════════════════════
abstract class StepExecutor
{
    // Template method - calls hooks in order
    final public function run(array $input): array
    {
        $this->validate($input);
        $prepared = $this->prepare($input);
        $result = $this->execute($prepared);
        $this->postProcess($result);
        return $result;
    }

    abstract protected function validate(array $input): void;
    abstract protected function prepare(array $input): array;
    abstract protected function execute(array $input): array;
    protected function postProcess(array $result): void {} // Optional hook
}

class AiTransformExecutor extends StepExecutor
{
    protected function validate(array $input): void
    {
        if (empty($input['prompt'])) throw new \InvalidArgumentException('Prompt required');
    }

    protected function prepare(array $input): array
    {
        $input['timestamp'] = now()->toIso8601String();
        return $input;
    }

    protected function execute(array $input): array
    {
        // Call AI provider
        return ['generated_code' => '...', 'tokens_used' => 150];
    }
}

// ═══════════════════════════════════════════════
// 17. MEDIATOR — Orchestrator coordinates components
// ═══════════════════════════════════════════════
class FlowMediator
{
    /** @var array<string, StepExecutor> */
    private array $executors = [];

    public function __construct(private FlowEventBus $eventBus) {}

    public function register(string $stepType, StepExecutor $executor): void
    {
        $this->executors[$stepType] = $executor;
    }

    public function executeStep(string $flowId, FlowStep $step, array $input): array
    {
        $executor = $this->executors[$step->type]
            ?? throw new \RuntimeException("No executor for: {$step->type}");

        $this->eventBus->emit(new FlowEvent($flowId, $step->id, 'step_started'));
        $result = $executor->run($input);
        $this->eventBus->emit(new FlowEvent($flowId, $step->id, 'step_completed', $result));
        return $result;
    }
}

// ═══════════════════════════════════════════════
// 18. MEMENTO — Checkpoint save/restore
// ═══════════════════════════════════════════════
readonly class FlowCheckpoint
{
    public function __construct(
        public string $flowId,
        public FlowStatus $status,
        public array $completedSteps,
        public array $stepOutputs,
        public string $timestamp,
    ) {}

    public function toArray(): array
    {
        return [
            'flow_id' => $this->flowId,
            'status' => $this->status->value,
            'completed_steps' => $this->completedSteps,
            'step_outputs' => $this->stepOutputs,
            'timestamp' => $this->timestamp,
        ];
    }
}

class CheckpointManager
{
    private array $checkpoints = [];

    public function save(FlowCheckpoint $checkpoint): void
    {
        $this->checkpoints[] = $checkpoint;
    }

    public function restoreLatest(string $flowId): ?FlowCheckpoint
    {
        $matching = array_filter($this->checkpoints, fn($c) => $c->flowId === $flowId);
        return end($matching) ?: null;
    }
}

// ═══════════════════════════════════════════════
// 19. VISITOR — Figma node tree traversal
// ═══════════════════════════════════════════════
interface FigmaVisitor
{
    public function visitFrame(string $id, array $props, array $children): void;
    public function visitText(string $id, string $content, array $style): void;
    public function visitImage(string $id, string $url): void;
    public function visitComponent(string $id, string $name, array $children): void;
}

abstract class FigmaNode
{
    abstract public function accept(FigmaVisitor $visitor): void;
}

class FrameNode extends FigmaNode
{
    public function __construct(
        public string $id,
        public array $props,
        /** @var FigmaNode[] */
        public array $children = [],
    ) {}

    public function accept(FigmaVisitor $visitor): void
    {
        $visitor->visitFrame($this->id, $this->props, $this->children);
        foreach ($this->children as $child) $child->accept($visitor);
    }
}

class TextNode extends FigmaNode
{
    public function __construct(
        public string $id,
        public string $content,
        public array $style = [],
    ) {}

    public function accept(FigmaVisitor $visitor): void
    {
        $visitor->visitText($this->id, $this->content, $this->style);
    }
}

class CssExtractorVisitor implements FigmaVisitor
{
    public array $styles = [];

    public function visitFrame(string $id, array $props, array $children): void
    {
        $css = implode('; ', array_map(fn($k, $v) => "{$k}: {$v}", array_keys($props), $props));
        $this->styles[] = "#{$id} { {$css} }";
    }

    public function visitText(string $id, string $content, array $style): void
    {
        $css = implode('; ', array_map(fn($k, $v) => "{$k}: {$v}", array_keys($style), $style));
        $this->styles[] = "#{$id} { {$css} }";
    }

    public function visitImage(string $id, string $url): void {}
    public function visitComponent(string $id, string $name, array $children): void {}
}

// ═══════════════════════════════════════════════
// COMMON COMBINATIONS FOR XIIGen
// ═══════════════════════════════════════════════
// Database layer:  Bridge + Factory + Proxy + Decorator
// AI dispatch:     Strategy + Facade + Observer
// Flow execution:  Mediator + Command + State + Memento
// Figma parsing:   Visitor + Adapter + Builder
// Middleware:       Chain of Responsibility + Decorator + Template Method
