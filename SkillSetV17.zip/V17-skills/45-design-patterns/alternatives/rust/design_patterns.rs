// XIIGen Skill 45 — Design Patterns (Rust)
// All 19 patterns implemented with Rust idioms
// Uses: std, async-trait, tokio, serde

use std::collections::HashMap;
use std::sync::{Arc, Mutex, OnceLock};
use async_trait::async_trait;
use serde::{Serialize, Deserialize};

// ═══════════════════════════════════════════════
// 1. SINGLETON — OnceLock (thread-safe, lazy init)
// ═══════════════════════════════════════════════
#[derive(Debug)]
pub struct AppConfig {
    pub db_url: String,
    pub cache_ttl: u64,
}

static CONFIG: OnceLock<AppConfig> = OnceLock::new();

pub fn get_config() -> &'static AppConfig {
    CONFIG.get_or_init(|| AppConfig {
        db_url: std::env::var("DB_URL").unwrap_or_default(),
        cache_ttl: 300,
    })
}

// ═══════════════════════════════════════════════
// 2. FACTORY — Trait objects + registry
// ═══════════════════════════════════════════════
#[async_trait]
pub trait DatabaseService: Send + Sync {
    async fn search(&self, index: &str, filter: serde_json::Value, limit: usize)
        -> Result<Vec<serde_json::Value>, Box<dyn std::error::Error>>;
}

type DbFactory = Box<dyn Fn() -> Box<dyn DatabaseService> + Send + Sync>;

pub struct DatabaseRegistry {
    factories: HashMap<String, DbFactory>,
}

impl DatabaseRegistry {
    pub fn new() -> Self { Self { factories: HashMap::new() } }

    pub fn register(&mut self, name: &str, factory: DbFactory) {
        self.factories.insert(name.to_string(), factory);
    }

    pub fn create(&self, provider: &str) -> Result<Box<dyn DatabaseService>, String> {
        self.factories.get(provider)
            .map(|f| f())
            .ok_or_else(|| format!("Unknown provider: {provider}"))
    }
}

// ═══════════════════════════════════════════════
// 3. BUILDER — Consuming builder with validation
// ═══════════════════════════════════════════════
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FlowDefinition {
    pub name: String,
    pub steps: Vec<FlowStep>,
    pub edges: Vec<FlowEdge>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FlowStep { pub id: String, pub step_type: String, pub config: serde_json::Value }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FlowEdge { pub from: String, pub to: String, pub condition: Option<String> }

#[derive(Default)]
pub struct FlowDefinitionBuilder {
    name: Option<String>,
    steps: Vec<FlowStep>,
    edges: Vec<FlowEdge>,
}

impl FlowDefinitionBuilder {
    pub fn new() -> Self { Self::default() }

    pub fn name(mut self, name: impl Into<String>) -> Self {
        self.name = Some(name.into()); self
    }

    pub fn step(mut self, id: impl Into<String>, step_type: impl Into<String>, config: serde_json::Value) -> Self {
        self.steps.push(FlowStep { id: id.into(), step_type: step_type.into(), config });
        self
    }

    pub fn edge(mut self, from: impl Into<String>, to: impl Into<String>, condition: Option<String>) -> Self {
        self.edges.push(FlowEdge { from: from.into(), to: to.into(), condition });
        self
    }

    pub fn build(self) -> Result<FlowDefinition, String> {
        let name = self.name.ok_or("Flow name required")?;
        if self.steps.is_empty() { return Err("At least one step required".into()); }
        Ok(FlowDefinition { name, steps: self.steps, edges: self.edges })
    }
}

// ═══════════════════════════════════════════════
// 4. PROTOTYPE — Clone trait (native in Rust)
// ═══════════════════════════════════════════════
#[derive(Debug, Clone)]
pub struct StepTemplate {
    pub step_type: String,
    pub default_config: serde_json::Value,
}

impl StepTemplate {
    pub fn create_instance(&self, id: &str) -> FlowStep {
        FlowStep {
            id: id.to_string(),
            step_type: self.step_type.clone(),
            config: self.default_config.clone(),
        }
    }
}

// ═══════════════════════════════════════════════
// 5. ADAPTER — Wrap external API into our trait
// ═══════════════════════════════════════════════
pub struct FigmaNodeRaw {
    pub node_id: String,
    pub node_type: String,
    pub properties: HashMap<String, String>,
}

pub struct XiigenComponent {
    pub id: String,
    pub component_type: String,
    pub styles: HashMap<String, String>,
}

pub struct FigmaAdapter;

impl FigmaAdapter {
    pub fn adapt(raw: &FigmaNodeRaw) -> XiigenComponent {
        let component_type = match raw.node_type.as_str() {
            "FRAME" => "Container",
            "TEXT" => "Text",
            "RECTANGLE" => "Box",
            "INSTANCE" => "Component",
            _ => "Unknown",
        };
        XiigenComponent {
            id: raw.node_id.clone(),
            component_type: component_type.to_string(),
            styles: raw.properties.clone(),
        }
    }
}

// ═══════════════════════════════════════════════
// 6. DECORATOR — Wrapper structs implementing same trait
// ═══════════════════════════════════════════════
#[async_trait]
pub trait AiProvider: Send + Sync {
    async fn generate(&self, prompt: &str) -> Result<String, Box<dyn std::error::Error>>;
}

pub struct LoggingAiProvider<T: AiProvider> {
    inner: T,
    service_name: String,
}

impl<T: AiProvider> LoggingAiProvider<T> {
    pub fn new(inner: T, service_name: &str) -> Self {
        Self { inner, service_name: service_name.to_string() }
    }
}

#[async_trait]
impl<T: AiProvider> AiProvider for LoggingAiProvider<T> {
    async fn generate(&self, prompt: &str) -> Result<String, Box<dyn std::error::Error>> {
        let start = std::time::Instant::now();
        println!("[{}] AI request: {}...", self.service_name, &prompt[..prompt.len().min(50)]);
        let result = self.inner.generate(prompt).await;
        println!("[{}] AI response in {:?}", self.service_name, start.elapsed());
        result
    }
}

pub struct RetryAiProvider<T: AiProvider> {
    inner: T,
    max_retries: usize,
}

#[async_trait]
impl<T: AiProvider> AiProvider for RetryAiProvider<T> {
    async fn generate(&self, prompt: &str) -> Result<String, Box<dyn std::error::Error>> {
        let mut last_err = None;
        for attempt in 0..=self.max_retries {
            match self.inner.generate(prompt).await {
                Ok(result) => return Ok(result),
                Err(e) => {
                    last_err = Some(e);
                    if attempt < self.max_retries {
                        tokio::time::sleep(std::time::Duration::from_millis(100 * (attempt as u64 + 1))).await;
                    }
                }
            }
        }
        Err(last_err.unwrap())
    }
}

// ═══════════════════════════════════════════════
// 7. FACADE — Simplified interface to complex subsystem
// ═══════════════════════════════════════════════
pub struct AiDispatcherFacade {
    providers: Vec<Box<dyn AiProvider>>,
}

impl AiDispatcherFacade {
    pub fn new(providers: Vec<Box<dyn AiProvider>>) -> Self { Self { providers } }

    pub async fn dispatch_all(&self, prompt: &str) -> Vec<Result<String, String>> {
        let mut results = Vec::new();
        for provider in &self.providers {
            results.push(
                provider.generate(prompt).await.map_err(|e| e.to_string())
            );
        }
        results
    }

    pub async fn dispatch_first_success(&self, prompt: &str) -> Result<String, String> {
        for provider in &self.providers {
            if let Ok(result) = provider.generate(prompt).await {
                return Ok(result);
            }
        }
        Err("All providers failed".into())
    }
}

// ═══════════════════════════════════════════════
// 8. PROXY — Access control + caching wrapper
// ═══════════════════════════════════════════════
pub struct CachingDbProxy {
    inner: Box<dyn DatabaseService>,
    cache: Arc<Mutex<HashMap<String, (std::time::Instant, Vec<serde_json::Value>)>>>,
    ttl: std::time::Duration,
}

#[async_trait]
impl DatabaseService for CachingDbProxy {
    async fn search(&self, index: &str, filter: serde_json::Value, limit: usize)
        -> Result<Vec<serde_json::Value>, Box<dyn std::error::Error>>
    {
        let key = format!("{index}:{filter}:{limit}");
        if let Ok(cache) = self.cache.lock() {
            if let Some((ts, data)) = cache.get(&key) {
                if ts.elapsed() < self.ttl { return Ok(data.clone()); }
            }
        }
        let result = self.inner.search(index, filter, limit).await?;
        if let Ok(mut cache) = self.cache.lock() {
            cache.insert(key, (std::time::Instant::now(), result.clone()));
        }
        Ok(result)
    }
}

// ═══════════════════════════════════════════════
// 9. BRIDGE — Separate abstraction from implementation
// ═══════════════════════════════════════════════
#[async_trait]
pub trait QueueBackend: Send + Sync {
    async fn enqueue(&self, queue: &str, data: serde_json::Value) -> Result<String, Box<dyn std::error::Error>>;
    async fn dequeue(&self, queue: &str) -> Result<Option<serde_json::Value>, Box<dyn std::error::Error>>;
}

pub struct JobQueue {
    backend: Box<dyn QueueBackend>,
    queue_name: String,
}

impl JobQueue {
    pub fn new(backend: Box<dyn QueueBackend>, queue_name: &str) -> Self {
        Self { backend, queue_name: queue_name.to_string() }
    }
    pub async fn submit(&self, job: serde_json::Value) -> Result<String, Box<dyn std::error::Error>> {
        self.backend.enqueue(&self.queue_name, job).await
    }
    pub async fn poll(&self) -> Result<Option<serde_json::Value>, Box<dyn std::error::Error>> {
        self.backend.dequeue(&self.queue_name).await
    }
}

// ═══════════════════════════════════════════════
// 10. FLYWEIGHT — Shared immutable data
// ═══════════════════════════════════════════════
#[derive(Debug, Clone)]
pub struct DesignToken {
    pub color: String,
    pub font: String,
    pub spacing: f32,
}

pub struct DesignTokenPool {
    tokens: HashMap<String, Arc<DesignToken>>,
}

impl DesignTokenPool {
    pub fn new() -> Self { Self { tokens: HashMap::new() } }

    pub fn get_or_create(&mut self, key: &str, color: &str, font: &str, spacing: f32) -> Arc<DesignToken> {
        self.tokens.entry(key.to_string()).or_insert_with(|| {
            Arc::new(DesignToken { color: color.to_string(), font: font.to_string(), spacing })
        }).clone()
    }
}

// ═══════════════════════════════════════════════
// 11. STRATEGY — Dispatch mode selection
// ═══════════════════════════════════════════════
#[derive(Debug, Clone, Copy)]
pub enum DispatchMode { All, Fallback, Consensus }

#[async_trait]
pub trait DispatchStrategy: Send + Sync {
    async fn execute(&self, providers: &[Box<dyn AiProvider>], prompt: &str)
        -> Result<Vec<String>, Box<dyn std::error::Error>>;
}

pub struct AllStrategy;
pub struct FallbackStrategy;

#[async_trait]
impl DispatchStrategy for AllStrategy {
    async fn execute(&self, providers: &[Box<dyn AiProvider>], prompt: &str)
        -> Result<Vec<String>, Box<dyn std::error::Error>>
    {
        let mut results = Vec::new();
        for p in providers {
            if let Ok(r) = p.generate(prompt).await { results.push(r); }
        }
        Ok(results)
    }
}

#[async_trait]
impl DispatchStrategy for FallbackStrategy {
    async fn execute(&self, providers: &[Box<dyn AiProvider>], prompt: &str)
        -> Result<Vec<String>, Box<dyn std::error::Error>>
    {
        for p in providers {
            if let Ok(r) = p.generate(prompt).await { return Ok(vec![r]); }
        }
        Err("All providers failed".into())
    }
}

// ═══════════════════════════════════════════════
// 12. OBSERVER — Event channels (tokio broadcast)
// ═══════════════════════════════════════════════
use tokio::sync::broadcast;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FlowEvent {
    pub flow_id: String,
    pub step_id: String,
    pub event_type: String,  // "step_started", "step_completed", "step_failed"
    pub data: serde_json::Value,
}

pub struct FlowEventBus {
    sender: broadcast::Sender<FlowEvent>,
}

impl FlowEventBus {
    pub fn new(capacity: usize) -> Self {
        let (sender, _) = broadcast::channel(capacity);
        Self { sender }
    }

    pub fn publish(&self, event: FlowEvent) -> Result<usize, broadcast::error::SendError<FlowEvent>> {
        self.sender.send(event)
    }

    pub fn subscribe(&self) -> broadcast::Receiver<FlowEvent> {
        self.sender.subscribe()
    }
}

// ═══════════════════════════════════════════════
// 13. CHAIN OF RESPONSIBILITY — Middleware pipeline
// ═══════════════════════════════════════════════
pub struct HttpRequest {
    pub path: String,
    pub headers: HashMap<String, String>,
    pub body: String,
}

pub struct HttpResponse {
    pub status: u16,
    pub body: String,
}

#[async_trait]
pub trait Middleware: Send + Sync {
    async fn handle(&self, req: &HttpRequest, next: &dyn Middleware)
        -> Result<HttpResponse, Box<dyn std::error::Error>>;
}

pub struct AuthMiddleware { pub api_keys: Vec<String> }
pub struct LogMiddleware;
pub struct RateLimitMiddleware { pub max_per_sec: u32 }

// Pipeline runner
pub struct MiddlewarePipeline {
    middlewares: Vec<Box<dyn Middleware>>,
}

// ═══════════════════════════════════════════════
// 14. COMMAND — Queue messages with execute/undo
// ═══════════════════════════════════════════════
#[async_trait]
pub trait Command: Send + Sync {
    async fn execute(&self) -> Result<serde_json::Value, Box<dyn std::error::Error>>;
    async fn undo(&self) -> Result<(), Box<dyn std::error::Error>>;
    fn description(&self) -> &str;
}

pub struct CreateFlowCommand {
    pub flow_def: FlowDefinition,
}

#[async_trait]
impl Command for CreateFlowCommand {
    async fn execute(&self) -> Result<serde_json::Value, Box<dyn std::error::Error>> {
        // Save flow to DB, return flow ID
        Ok(serde_json::json!({ "flow_id": "new-flow-123", "status": "created" }))
    }
    async fn undo(&self) -> Result<(), Box<dyn std::error::Error>> {
        // Delete the created flow
        Ok(())
    }
    fn description(&self) -> &str { "Create flow definition" }
}

pub struct CommandHistory {
    executed: Vec<Box<dyn Command>>,
}

impl CommandHistory {
    pub fn new() -> Self { Self { executed: Vec::new() } }

    pub async fn execute(&mut self, cmd: Box<dyn Command>) -> Result<serde_json::Value, Box<dyn std::error::Error>> {
        let result = cmd.execute().await?;
        self.executed.push(cmd);
        Ok(result)
    }

    pub async fn undo_last(&mut self) -> Result<(), Box<dyn std::error::Error>> {
        if let Some(cmd) = self.executed.pop() {
            cmd.undo().await?;
        }
        Ok(())
    }
}

// ═══════════════════════════════════════════════
// 15. STATE — Flow status transitions (enum + match)
// ═══════════════════════════════════════════════
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum FlowStatus {
    Created, Running, Paused, Completed, Failed, Cancelled,
}

impl FlowStatus {
    pub fn can_transition_to(&self, target: FlowStatus) -> bool {
        matches!((self, target),
            (FlowStatus::Created, FlowStatus::Running) |
            (FlowStatus::Running, FlowStatus::Paused) |
            (FlowStatus::Running, FlowStatus::Completed) |
            (FlowStatus::Running, FlowStatus::Failed) |
            (FlowStatus::Running, FlowStatus::Cancelled) |
            (FlowStatus::Paused, FlowStatus::Running) |
            (FlowStatus::Paused, FlowStatus::Cancelled) |
            (FlowStatus::Failed, FlowStatus::Running)
        )
    }

    pub fn transition(self, target: FlowStatus) -> Result<FlowStatus, String> {
        if self.can_transition_to(target) {
            Ok(target)
        } else {
            Err(format!("Cannot transition from {:?} to {:?}", self, target))
        }
    }
}

// ═══════════════════════════════════════════════
// 16. TEMPLATE METHOD — Base executor with hooks
// ═══════════════════════════════════════════════
#[async_trait]
pub trait StepExecutor: Send + Sync {
    // Template method (final in other languages, convention in Rust)
    async fn run(&self, input: serde_json::Value) -> Result<serde_json::Value, Box<dyn std::error::Error>> {
        self.validate(&input)?;
        let prepared = self.prepare(input).await?;
        let result = self.execute(prepared).await?;
        self.post_process(&result).await?;
        Ok(result)
    }

    fn validate(&self, input: &serde_json::Value) -> Result<(), Box<dyn std::error::Error>>;
    async fn prepare(&self, input: serde_json::Value) -> Result<serde_json::Value, Box<dyn std::error::Error>>;
    async fn execute(&self, input: serde_json::Value) -> Result<serde_json::Value, Box<dyn std::error::Error>>;
    async fn post_process(&self, _result: &serde_json::Value) -> Result<(), Box<dyn std::error::Error>> { Ok(()) }
}

// ═══════════════════════════════════════════════
// 17. MEDIATOR — Flow orchestrator coordinates steps
// ═══════════════════════════════════════════════
pub struct FlowMediator {
    executors: HashMap<String, Box<dyn StepExecutor>>,
    event_bus: FlowEventBus,
}

impl FlowMediator {
    pub fn new(event_bus: FlowEventBus) -> Self {
        Self { executors: HashMap::new(), event_bus }
    }

    pub fn register(&mut self, step_type: &str, executor: Box<dyn StepExecutor>) {
        self.executors.insert(step_type.to_string(), executor);
    }

    pub async fn execute_step(&self, flow_id: &str, step: &FlowStep, input: serde_json::Value)
        -> Result<serde_json::Value, Box<dyn std::error::Error>>
    {
        let executor = self.executors.get(&step.step_type)
            .ok_or_else(|| format!("No executor for step type: {}", step.step_type))?;

        let _ = self.event_bus.publish(FlowEvent {
            flow_id: flow_id.to_string(),
            step_id: step.id.clone(),
            event_type: "step_started".into(),
            data: serde_json::json!({}),
        });

        let result = executor.run(input).await?;

        let _ = self.event_bus.publish(FlowEvent {
            flow_id: flow_id.to_string(),
            step_id: step.id.clone(),
            event_type: "step_completed".into(),
            data: result.clone(),
        });

        Ok(result)
    }
}

// ═══════════════════════════════════════════════
// 18. MEMENTO — Flow checkpoint/restore
// ═══════════════════════════════════════════════
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FlowCheckpoint {
    pub flow_id: String,
    pub status: FlowStatus,
    pub completed_steps: Vec<String>,
    pub step_outputs: HashMap<String, serde_json::Value>,
    pub timestamp: String,
}

pub struct CheckpointManager {
    checkpoints: Vec<FlowCheckpoint>,
}

impl CheckpointManager {
    pub fn new() -> Self { Self { checkpoints: Vec::new() } }

    pub fn save(&mut self, checkpoint: FlowCheckpoint) {
        self.checkpoints.push(checkpoint);
    }

    pub fn restore_latest(&self, flow_id: &str) -> Option<&FlowCheckpoint> {
        self.checkpoints.iter().rev().find(|c| c.flow_id == flow_id)
    }
}

// ═══════════════════════════════════════════════
// 19. VISITOR — Figma node tree traversal
// ═══════════════════════════════════════════════
pub enum FigmaNode {
    Frame { id: String, children: Vec<FigmaNode>, props: HashMap<String, String> },
    Text { id: String, content: String, style: HashMap<String, String> },
    Image { id: String, url: String },
    Component { id: String, name: String, children: Vec<FigmaNode> },
}

pub trait FigmaVisitor {
    fn visit_frame(&mut self, id: &str, props: &HashMap<String, String>, children: &[FigmaNode]);
    fn visit_text(&mut self, id: &str, content: &str, style: &HashMap<String, String>);
    fn visit_image(&mut self, id: &str, url: &str);
    fn visit_component(&mut self, id: &str, name: &str, children: &[FigmaNode]);
}

impl FigmaNode {
    pub fn accept(&self, visitor: &mut dyn FigmaVisitor) {
        match self {
            FigmaNode::Frame { id, children, props } => {
                visitor.visit_frame(id, props, children);
                for child in children { child.accept(visitor); }
            }
            FigmaNode::Text { id, content, style } => visitor.visit_text(id, content, style),
            FigmaNode::Image { id, url } => visitor.visit_image(id, url),
            FigmaNode::Component { id, name, children } => {
                visitor.visit_component(id, name, children);
                for child in children { child.accept(visitor); }
            }
        }
    }
}

// CSS extractor visitor
pub struct CssExtractor {
    pub styles: Vec<String>,
}

impl FigmaVisitor for CssExtractor {
    fn visit_frame(&mut self, id: &str, props: &HashMap<String, String>, _children: &[FigmaNode]) {
        let css: Vec<String> = props.iter().map(|(k, v)| format!("{k}: {v}")).collect();
        self.styles.push(format!("#{id} {{ {} }}", css.join("; ")));
    }
    fn visit_text(&mut self, id: &str, _content: &str, style: &HashMap<String, String>) {
        let css: Vec<String> = style.iter().map(|(k, v)| format!("{k}: {v}")).collect();
        self.styles.push(format!("#{id} {{ {} }}", css.join("; ")));
    }
    fn visit_image(&mut self, _id: &str, _url: &str) {}
    fn visit_component(&mut self, _id: &str, _name: &str, _children: &[FigmaNode]) {}
}

// ═══════════════════════════════════════════════
// COMMON COMBINATIONS FOR XIIGen
// ═══════════════════════════════════════════════
// Database layer:  Bridge + Factory + Proxy + Decorator
// AI dispatch:     Strategy + Facade + Observer
// Flow execution:  Mediator + Command + State + Memento
// Figma parsing:   Visitor + Adapter + Builder
// Middleware:       Chain of Responsibility + Decorator + Template Method

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_builder_validates() {
        let result = FlowDefinitionBuilder::new().build();
        assert!(result.is_err());

        let flow = FlowDefinitionBuilder::new()
            .name("test")
            .step("s1", "figma_parse", serde_json::json!({}))
            .build();
        assert!(flow.is_ok());
    }

    #[test]
    fn test_state_transitions() {
        assert!(FlowStatus::Created.can_transition_to(FlowStatus::Running));
        assert!(!FlowStatus::Completed.can_transition_to(FlowStatus::Running));
        assert!(FlowStatus::Failed.can_transition_to(FlowStatus::Running));
    }

    #[test]
    fn test_prototype_clone() {
        let template = StepTemplate {
            step_type: "ai_transform".into(),
            default_config: serde_json::json!({"model": "claude"}),
        };
        let instance = template.create_instance("step-1");
        assert_eq!(instance.step_type, "ai_transform");
        assert_eq!(instance.id, "step-1");
    }

    #[test]
    fn test_singleton_consistent() {
        let a = get_config();
        let b = get_config();
        assert!(std::ptr::eq(a, b));
    }
}
