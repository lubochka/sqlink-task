---
name: design-patterns
description: Complete reference for 19 design patterns — when to use, how to implement in 6 languages, combinations, anti-patterns, and XIIGen-specific usage.
triggers: design pattern, singleton, factory, builder, observer, strategy, decorator, adapter, command, pattern catalog
dependencies: []
layer: L10-Knowledge
genie-dna: Repository pattern uses ParseObjectAlternative + BuildSearchFilter. PatternCatalog queryable by AI Context Service (Skill 16).
---

# Skill 45: Design Patterns Library
## Complete reference for 19 design patterns — when to use, how to implement, combinations, and anti-patterns

**Dependencies:** None (standalone reference)
**Layer:** L10: Knowledge
**Phase:** 4 (Memory Library)

---

## Overview

This skill provides a comprehensive design patterns library that AI steps can reference during code generation. Each pattern includes: WHEN to use it, HOW to implement it in 6 languages (.NET, Node.js, Python, Java, Rust, PHP), common COMBINATIONS with other patterns, ANTI-PATTERNS to avoid, and XIIGen-SPECIFIC usage examples.

The AI Context Service (Skill 16) uses this library to inject relevant pattern hints into AI prompts based on the step type being executed.

## Pattern Catalog

### Creational Patterns
| # | Pattern | When to Use | XIIGen Usage |
|---|---------|-------------|--------------|
| 1 | **Singleton** | Single shared instance (config, logging) | ICacheService, Logger |
| 2 | **Factory** | Create objects without specifying concrete class | DatabaseFabric, AiProviderFactory |
| 3 | **Builder** | Complex object construction with many options | ContextPackage, FlowDefinition |
| 4 | **Prototype** | Clone existing objects to avoid costly creation | FlowStep templates, ContextSection |

### Structural Patterns
| # | Pattern | When to Use | XIIGen Usage |
|---|---------|-------------|--------------|
| 5 | **Adapter** | Convert one interface to another | FigmaPluginBridge (Skill 39) |
| 6 | **Decorator** | Add behavior without modifying class | Logging middleware, auth wrapping |
| 7 | **Facade** | Simple interface for complex subsystem | AiDispatcher wrapping providers |
| 8 | **Proxy** | Control access to an object | CacheProxy for database calls |
| 9 | **Bridge** | Separate abstraction from implementation | IDatabaseService + providers |
| 10 | **Flyweight** | Share data between many similar objects | Design token reuse |

### Behavioral Patterns
| # | Pattern | When to Use | XIIGen Usage |
|---|---------|-------------|--------------|
| 11 | **Strategy** | Swap algorithms at runtime | AI dispatch strategies |
| 12 | **Observer** | Notify dependents of state changes | Flow step completion events |
| 13 | **Chain of Responsibility** | Pass request through handler chain | Middleware pipeline |
| 14 | **Command** | Encapsulate requests as objects | Queue messages |
| 15 | **State** | Object behavior changes with state | FlowStatus transitions |
| 16 | **Template Method** | Define skeleton, let subclasses fill steps | IStepExecutor base |
| 17 | **Mediator** | Centralize communication between objects | FlowOrchestrator |
| 18 | **Memento** | Save/restore object state | Flow checkpoint/resume |
| 19 | **Visitor** | Add operations without modifying classes | Figma node tree traversal |

---

## Pattern Details

### 1. SINGLETON

**When:** You need exactly one instance shared across the application — config, logging, connection pools.

**Combinations:** Often used WITH Factory (create the singleton), WITH Observer (event bus singleton).

**Anti-patterns:**
- Global mutable state — makes testing hard
- Using for things that should be scoped (per-request data)
- Thread-unsafe lazy init

**XIIGen Usage:** `ICacheService` is registered as singleton in DI. `ILogger<T>` is singleton per category.

**.NET 9:**
```csharp
// Modern .NET: Use DI — it handles singleton lifecycle
services.AddSingleton<ICacheService, RedisCacheService>();
// Only use manual singleton for non-DI scenarios:
public sealed class AppConfig
{
    private static readonly Lazy<AppConfig> _instance = new(() => new AppConfig());
    public static AppConfig Instance => _instance.Value;
    private AppConfig() { /* load from env */ }
    public string DbUrl { get; init; }
}
```

### 2. FACTORY

**When:** You need to create objects based on runtime conditions without coupling to concrete classes.

**Combinations:** WITH Strategy (factory creates strategies), WITH Singleton (factory is singleton), WITH Prototype (factory clones prototypes).

**Anti-patterns:**
- Over-engineering simple creation (use `new` if only one type)
- Factory that knows about every subclass (use registry instead)

**XIIGen Usage:** `DatabaseFabric` (Skill 05) creates database providers by config. `AiProviderFactory` creates Claude/GPT/Gemini based on config.

**.NET 9:**
```csharp
public class DatabaseFabric
{
    private readonly IServiceProvider _sp;
    public DatabaseFabric(IServiceProvider sp) => _sp = sp;
    
    public IDatabaseService Create(string provider) => provider switch
    {
        "elasticsearch" => _sp.GetRequiredService<ElasticsearchDatabaseService>(),
        "mongodb" => _sp.GetRequiredService<MongoDatabaseService>(),
        "postgresql" => _sp.GetRequiredService<PostgresDatabaseService>(),
        _ => throw new ArgumentException($"Unknown provider: {provider}")
    };
}
```

### 3. BUILDER

**When:** Object has many optional parameters, or construction requires multiple steps.

**Combinations:** WITH Factory (factory delegates to builder), WITH Composite (build tree structures).

**Anti-patterns:**
- Builder for simple objects (records/tuples are enough)
- Mutable builder returned as final product

**XIIGen Usage:** Building `ContextPackage` with optional sections. Building `FlowDefinition` with steps and edges.

**.NET 9:**
```csharp
public class FlowDefinitionBuilder
{
    private readonly FlowDefinition _flow = new();
    private readonly List<FlowStep> _steps = new();
    private readonly List<FlowEdge> _edges = new();
    
    public FlowDefinitionBuilder WithName(string name) { _flow.Name = name; return this; }
    public FlowDefinitionBuilder AddStep(string id, string type, object? config = null)
    {
        _steps.Add(new FlowStep(id, type, config));
        return this;
    }
    public FlowDefinitionBuilder AddEdge(string from, string to, string? condition = null)
    {
        _edges.Add(new FlowEdge(from, to, condition));
        return this;
    }
    public FlowDefinition Build()
    {
        _flow.Steps = _steps; _flow.Edges = _edges;
        _flow.Validate(); // throws if invalid DAG
        return _flow;
    }
}
// Usage: var flow = new FlowDefinitionBuilder().WithName("figma-pipeline")
//     .AddStep("parse", "figma-parse").AddStep("transform", "ai-transform")
//     .AddEdge("parse", "transform").Build();
```

### 4. PROTOTYPE

**When:** Creating new objects is expensive, but cloning existing ones is cheap.

**Combinations:** WITH Registry (store prototypes by name), WITH Factory (factory clones instead of creating).

**.NET 9:**
```csharp
public record FlowStepTemplate(string Type, object DefaultConfig) : ICloneable
{
    public object Clone() => this with { }; // Record's with-expression = shallow clone
}
// Registry of pre-configured templates
public class StepTemplateRegistry
{
    private readonly Dictionary<string, FlowStepTemplate> _templates = new();
    public void Register(string name, FlowStepTemplate t) => _templates[name] = t;
    public FlowStepTemplate Create(string name) =>
        (FlowStepTemplate)_templates[name].Clone();
}
```

### 5. ADAPTER

**When:** You need to use a class with an incompatible interface.

**Combinations:** WITH Facade (adapter simplifies, facade unifies multiple), WITH Bridge (both decouple, adapter wraps existing).

**XIIGen Usage:** `FigmaPluginBridge` (Skill 39) adapts Figma plugin format → XIIGen FigmaNode format.

**.NET 9:**
```csharp
// Figma plugin sends PluginElement[], we need FigmaNode[]
public class FigmaPluginAdapter
{
    public FigmaNode Adapt(PluginElement element) => new FigmaNode
    {
        Id = element.Id,
        Type = element.Tag switch { "div" => "FRAME", "text" => "TEXT", "img" => "RECTANGLE", _ => "FRAME" },
        CssProperties = ConvertCss(element.Style),
        Children = element.Children?.Select(Adapt).ToList() ?? new()
    };
}
```

### 6. DECORATOR

**When:** Add responsibilities to objects dynamically without subclassing.

**Combinations:** WITH Chain of Responsibility (decorators chain), WITH Strategy (decorate strategies).

**Anti-patterns:**
- Too many decorators making debugging hard
- Decorators that depend on specific implementation details

**XIIGen Usage:** Logging decorator around database calls. Auth decorator around API endpoints.

**.NET 9:**
```csharp
public class LoggingDatabaseDecorator : IDatabaseService
{
    private readonly IDatabaseService _inner;
    private readonly ILogger _logger;
    
    public LoggingDatabaseDecorator(IDatabaseService inner, ILogger<LoggingDatabaseDecorator> logger)
    { _inner = inner; _logger = logger; }
    
    public async Task<DataProcessResult<T>> SearchAsync<T>(string index, object filter, int limit, CancellationToken ct)
    {
        var sw = System.Diagnostics.Stopwatch.StartNew();
        var result = await _inner.SearchAsync<T>(index, filter, limit, ct);
        _logger.LogInformation("DB.Search({Index}) → {Status} in {Ms}ms", index, result.Status, sw.ElapsedMilliseconds);
        return result;
    }
}
```

### 7. FACADE

**When:** Simplify access to a complex subsystem with a single entry point.

**Combinations:** WITH Singleton (facade often singleton), WITH Factory (facade uses factory internally).

**XIIGen Usage:** `AiDispatcher` (Skill 07) is a facade over multiple AI providers.

**.NET 9:**
```csharp
// AiDispatcher facades multiple providers behind a single interface
public class AiDispatcher
{
    private readonly IEnumerable<IAiProvider> _providers;
    
    // User calls one method — dispatcher handles complexity
    public async Task<AiResponse> DispatchAsync(AiRequest request, DispatchStrategy strategy)
    {
        return strategy switch
        {
            DispatchStrategy.All => await DispatchToAllAsync(request),
            DispatchStrategy.Fallback => await DispatchWithFallbackAsync(request),
            DispatchStrategy.Consensus => await DispatchForConsensusAsync(request),
            _ => throw new ArgumentException($"Unknown strategy: {strategy}")
        };
    }
}
```

### 8. PROXY

**When:** Control access to an object — caching, lazy loading, access control, logging.

**Combinations:** WITH Decorator (similar but proxy controls access, decorator adds behavior).

**.NET 9:**
```csharp
public class CachingDatabaseProxy : IDatabaseService
{
    private readonly IDatabaseService _real;
    private readonly ICacheService _cache;
    
    public async Task<DataProcessResult<T>> SearchAsync<T>(string index, object filter, int limit, CancellationToken ct)
    {
        var cacheKey = $"{index}:{System.Text.Json.JsonSerializer.Serialize(filter)}:{limit}";
        var cached = await _cache.GetAsync<DataProcessResult<T>>(cacheKey);
        if (cached != null) return cached;
        
        var result = await _real.SearchAsync<T>(index, filter, limit, ct);
        if (result.IsSuccess) await _cache.SetAsync(cacheKey, result, TimeSpan.FromMinutes(5));
        return result;
    }
}
```

### 9. BRIDGE

**When:** Separate abstraction from implementation so both can vary independently.

**XIIGen Usage:** `IDatabaseService` (abstraction) + `ElasticsearchDatabaseService`/`MongoDatabaseService` (implementations).

**.NET 9:**
```csharp
// Bridge: IDatabaseService is the abstraction, concrete providers are implementations
// The abstraction and implementation can evolve independently
public interface IDatabaseService  // Abstraction
{
    Task<DataProcessResult<T>> InsertAsync<T>(string index, T document, CancellationToken ct);
    Task<DataProcessResult<List<T>>> SearchAsync<T>(string index, object filter, int limit, CancellationToken ct);
}
// Implementation can be swapped via DI without changing any consumer code
```

### 10. FLYWEIGHT

**When:** Share common data between many similar objects to reduce memory.

**.NET 9:**
```csharp
// Design tokens shared across many components
public class DesignTokenCache
{
    private readonly Dictionary<string, DesignToken> _tokens = new();
    
    public DesignToken GetOrCreate(string key, Func<DesignToken> factory)
    {
        if (!_tokens.TryGetValue(key, out var token))
        {
            token = factory();
            _tokens[key] = token;
        }
        return token;
    }
}
```

### 11. STRATEGY

**When:** You need to swap algorithms at runtime without changing the client code.

**Combinations:** WITH Factory (create strategies), WITH Context (context holds current strategy).

**XIIGen Usage:** AI dispatch strategies (All, Fallback, Consensus). Database provider selection.

**.NET 9:**
```csharp
public interface IDispatchStrategy
{
    Task<AiResponse> ExecuteAsync(IEnumerable<IAiProvider> providers, AiRequest request);
}

public class AllParallelStrategy : IDispatchStrategy
{
    public async Task<AiResponse> ExecuteAsync(IEnumerable<IAiProvider> providers, AiRequest request)
    {
        var tasks = providers.Select(p => p.CompleteAsync(request));
        var results = await Task.WhenAll(tasks);
        return results.OrderByDescending(r => r.Score).First();
    }
}

public class FallbackStrategy : IDispatchStrategy
{
    public async Task<AiResponse> ExecuteAsync(IEnumerable<IAiProvider> providers, AiRequest request)
    {
        foreach (var provider in providers)
        {
            try { return await provider.CompleteAsync(request); }
            catch { continue; }
        }
        throw new InvalidOperationException("All providers failed");
    }
}
```

### 12. OBSERVER

**When:** One-to-many dependency where changes to one object notify all dependents.

**Combinations:** WITH Mediator (mediator centralizes observer), WITH Event (events are observer implementation).

**XIIGen Usage:** Flow step completion → triggers next steps. Feedback events → update context cache.

**.NET 9:**
```csharp
// Modern .NET uses IObservable<T> / IObserver<T> or event channels
public class FlowEventBus
{
    private readonly Channel<FlowEvent> _channel = Channel.CreateUnbounded<FlowEvent>();
    
    public async Task PublishAsync(FlowEvent evt) => await _channel.Writer.WriteAsync(evt);
    
    public async IAsyncEnumerable<FlowEvent> SubscribeAsync([EnumeratorCancellation] CancellationToken ct = default)
    {
        await foreach (var evt in _channel.Reader.ReadAllAsync(ct))
            yield return evt;
    }
}
```

### 13. CHAIN OF RESPONSIBILITY

**When:** Pass a request through a chain of handlers; each decides to process or pass along.

**Combinations:** WITH Command (commands passed through chain), WITH Decorator (similar chaining).

**XIIGen Usage:** Middleware pipeline (auth → logging → rate-limit → handler).

**.NET 9:**
```csharp
// ASP.NET middleware IS chain of responsibility
app.Use(async (context, next) =>
{
    // Auth check
    if (!context.User.Identity?.IsAuthenticated ?? true)
    { context.Response.StatusCode = 401; return; }
    await next(context);
});
app.Use(async (context, next) =>
{
    // Logging
    var sw = Stopwatch.StartNew();
    await next(context);
    logger.LogInformation("{Method} {Path} → {Status} in {Ms}ms",
        context.Request.Method, context.Request.Path, context.Response.StatusCode, sw.ElapsedMilliseconds);
});
```

### 14. COMMAND

**When:** Encapsulate a request as an object — enables queuing, undo, logging.

**Combinations:** WITH Memento (undo via memento), WITH Queue (queue commands).

**XIIGen Usage:** Queue messages are commands. Flow steps are commands with execute/rollback.

**.NET 9:**
```csharp
public interface IFlowCommand
{
    Task<DataProcessResult<object>> ExecuteAsync(FlowContext ctx, CancellationToken ct);
    Task RollbackAsync(FlowContext ctx, CancellationToken ct);
}

public class AiTransformCommand : IFlowCommand
{
    public async Task<DataProcessResult<object>> ExecuteAsync(FlowContext ctx, CancellationToken ct)
    {
        var result = await _aiDispatcher.DispatchAsync(ctx.Request, ct);
        ctx.SaveCheckpoint(result); // for rollback
        return DataProcessResult<object>.Success(result);
    }
    
    public async Task RollbackAsync(FlowContext ctx, CancellationToken ct)
    {
        await _db.DeleteAsync("xiigen-results", ctx.LastCheckpointId, ct);
    }
}
```

### 15. STATE

**When:** Object behavior changes based on its internal state.

**Combinations:** WITH Strategy (strategy is stateless state), WITH State Machine.

**XIIGen Usage:** FlowStatus (Created → Running → Paused → Completed/Failed/Cancelled).

**.NET 9:**
```csharp
public enum FlowStatus { Created, Running, Paused, Completed, Failed, Cancelled }

public class FlowStateMachine
{
    private static readonly Dictionary<(FlowStatus, string), FlowStatus> _transitions = new()
    {
        [(FlowStatus.Created, "start")] = FlowStatus.Running,
        [(FlowStatus.Running, "pause")] = FlowStatus.Paused,
        [(FlowStatus.Running, "complete")] = FlowStatus.Completed,
        [(FlowStatus.Running, "fail")] = FlowStatus.Failed,
        [(FlowStatus.Paused, "resume")] = FlowStatus.Running,
        [(FlowStatus.Paused, "cancel")] = FlowStatus.Cancelled,
    };
    
    public FlowStatus Transition(FlowStatus current, string action) =>
        _transitions.TryGetValue((current, action), out var next)
            ? next : throw new InvalidOperationException($"Invalid transition: {current} + {action}");
}
```

### 16. TEMPLATE METHOD

**When:** Define a skeleton algorithm where subclasses override specific steps.

**XIIGen Usage:** `IStepExecutor` defines Execute template; concrete steps (FigmaParser, AiTransform) override specifics.

**.NET 9:**
```csharp
public abstract class StepExecutorBase : IStepExecutor
{
    public async Task<StepResult> ExecuteAsync(StepInput input, CancellationToken ct)
    {
        var context = await BuildContextAsync(input, ct);     // Template: subclass overrides
        var result = await ProcessAsync(context, ct);          // Template: subclass overrides
        await StoreResultAsync(input.TraceId, result, ct);     // Shared: always stores
        return result;
    }
    
    protected abstract Task<object> BuildContextAsync(StepInput input, CancellationToken ct);
    protected abstract Task<StepResult> ProcessAsync(object context, CancellationToken ct);
    
    protected async Task StoreResultAsync(string traceId, StepResult result, CancellationToken ct)
    {
        await _db.InsertAsync("xiigen-results", new { traceId, result, createdAt = DateTime.UtcNow }, ct);
    }
}
```

### 17. MEDIATOR

**When:** Reduce chaotic dependencies between objects by centralizing communication.

**Combinations:** WITH Observer (mediator notifies), WITH Command (mediator dispatches commands).

**XIIGen Usage:** `FlowOrchestrator` (Skill 09) mediates between all step executors.

**.NET 9:**
```csharp
// MediatR-style: IMediator dispatches requests to handlers
public interface IMediator
{
    Task<TResponse> SendAsync<TResponse>(IRequest<TResponse> request, CancellationToken ct);
}
// FlowOrchestrator is a domain-specific mediator
public class FlowOrchestrator
{
    private readonly Dictionary<string, IStepExecutor> _executors;
    
    public async Task<FlowResult> OrchestrateAsync(FlowDefinition flow, CancellationToken ct)
    {
        foreach (var step in TopologicalSort(flow))
        {
            var executor = _executors[step.Type];
            await executor.ExecuteAsync(step.Input, ct);
        }
    }
}
```

### 18. MEMENTO

**When:** Save and restore an object's state without exposing internals.

**Combinations:** WITH Command (undo via memento), WITH State (save state transitions).

**XIIGen Usage:** Flow checkpoint/resume. Save flow state to Elasticsearch, restore from any point.

**.NET 9:**
```csharp
public record FlowCheckpoint(
    string FlowId, string TraceId, FlowStatus Status,
    Dictionary<string, StepState> StepStates,
    DateTime CreatedAt
);

public class FlowMementoManager
{
    private readonly IDatabaseService _db;
    
    public async Task SaveCheckpointAsync(FlowState state, CancellationToken ct)
    {
        var checkpoint = new FlowCheckpoint(state.FlowId, state.TraceId, state.Status,
            state.StepStates.ToDictionary(kv => kv.Key, kv => kv.Value), DateTime.UtcNow);
        await _db.InsertAsync("xiigen-checkpoints", checkpoint, ct);
    }
    
    public async Task<FlowState> RestoreAsync(string traceId, CancellationToken ct)
    {
        var result = await _db.SearchAsync<FlowCheckpoint>("xiigen-checkpoints",
            new { traceId }, 1, ct);
        var cp = result.Data!.First();
        return new FlowState { FlowId = cp.FlowId, TraceId = cp.TraceId,
            Status = cp.Status, StepStates = cp.StepStates };
    }
}
```

### 19. VISITOR

**When:** Add operations to objects without modifying their classes. Especially for tree traversals.

**Combinations:** WITH Composite (visit tree nodes), WITH Iterator (visit collection elements).

**XIIGen Usage:** Figma node tree traversal — parse, extract CSS, count components, generate HTML.

**.NET 9:**
```csharp
public interface IFigmaNodeVisitor<T>
{
    T VisitFrame(FigmaNode node);
    T VisitText(FigmaNode node);
    T VisitRectangle(FigmaNode node);
    T VisitVector(FigmaNode node);
}

public class HtmlGeneratorVisitor : IFigmaNodeVisitor<string>
{
    public string VisitFrame(FigmaNode node) =>
        $"<div style=\"{node.CssString}\">{string.Join("", node.Children.Select(c => c.Accept(this)))}</div>";
    public string VisitText(FigmaNode node) =>
        $"<span style=\"{node.CssString}\">{node.Characters}</span>";
    public string VisitRectangle(FigmaNode node) =>
        $"<div style=\"{node.CssString}\"></div>";
    public string VisitVector(FigmaNode node) =>
        $"<svg>{node.SvgPath}</svg>";
}

// Usage: var html = rootNode.Accept(new HtmlGeneratorVisitor());
```

---

## Common Pattern Combinations in XIIGen

| Scenario | Patterns Used |
|----------|--------------|
| Database layer | **Bridge** (interface) + **Factory** (create provider) + **Proxy** (caching) + **Decorator** (logging) |
| AI dispatch | **Strategy** (dispatch mode) + **Facade** (single entry) + **Observer** (completion events) |
| Flow execution | **Mediator** (orchestrator) + **Command** (steps) + **State** (flow status) + **Memento** (checkpoints) |
| Figma parsing | **Visitor** (tree traversal) + **Adapter** (format conversion) + **Builder** (assemble output) |
| Middleware | **Chain of Responsibility** (pipeline) + **Decorator** (wrapping) + **Template Method** (base behavior) |

---

## Alternatives

Each alternative file contains all 19 patterns implemented in that language.

| Language | File | Framework | Notes |
|----------|------|-----------|-------|
| .NET 9 | (Primary in SKILL.md above) | C# 12 | Records, pattern matching, DI |
| Node.js | `alternatives/nodejs/design-patterns.ts` | TypeScript | Classes, generics, async/await |
| Python | `alternatives/python/design_patterns.py` | Python 3.12 | Dataclasses, ABC, protocols |
| Java | `alternatives/java/DesignPatterns.java` | Java 21 | Records, sealed, pattern matching |
| Rust | `alternatives/rust/design_patterns.rs` | Rust | Traits, enums, ownership |
| PHP | `alternatives/php/DesignPatterns.php` | PHP 8.3 | Enums, readonly, interfaces |
