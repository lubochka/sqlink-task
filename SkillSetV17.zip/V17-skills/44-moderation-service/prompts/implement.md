# Moderation Service — Implementation Prompt | Skill 44
## Phase 1: Core Moderation
1. `Moderate(content, contentType)` returns ModerationResult with category scores
2. Auto-decision: approve < 0.3, reject > 0.85, else human review
3. AI-powered scoring via IAiProvider; fallback to auto-approve

## Phase 2: Category Scoring
1. Categories: toxicity, sexual, violence, hate, self-harm, PII, code-safety, spam
2. Configurable thresholds and enabled categories
3. Store results as dynamic docs; events for reject/review

## Phase 3: Human Review Queue
1. GetReviewQueue returns items needing human decision
2. ResolveReview updates action with reviewer info
3. Notification integration (Skill 24) for reviewers

## Phase 4: Integration & Testing
1. Middleware for auto-moderation on chat (Skill 42) messages
2. Content pipeline (Skill 40) pre-publish moderation
3. **Genie DNA Checklist:** ☐ DataProcessResult ☐ BuildSearchFilter ☐ Dynamic docs ☐ IAiProvider


---

## Genie DNA Compliance — MANDATORY for All Implementations

> Before writing ANY code, classify each component:
> **MACHINE** (static): Infrastructure that enables freedom. Build once, generic, interface-based.
> **FREEDOM** (dynamic): Anything users define. No fixed models, config-driven.

### DNA Checklist — Every Implementation MUST:
☐ **DNA-1 (Dynamic Documents):** Store data as `Dictionary<string, object>` / `Record<string, any>` — NOT typed model classes. User fields preserved without schema changes.
☐ **DNA-2 (BuildSearchFilter):** All queries use BuildSearchFilter/equivalent. Empty fields auto-skipped. No entity-specific query code.
☐ **DNA-3 (MicroserviceBase):** Inherit base class with DB, queue, cache, logger built in.
☐ **DNA-5 (DataProcessResult):** All public methods return `DataProcessResult<T>`. Errors return failure, not throw exceptions.
☐ **DNA-6 (Generic Interfaces):** External dependencies behind interfaces. Swap via config.
☐ **DNA-SCOPE:** Non-admin queries auto-inject userId filter. Cannot be bypassed.

### The Three Tests:
1. Can a business user change this without a developer? (YES = correct)
2. Does it work for entity types that do not exist yet? (YES = correct)
3. Can I swap the database/service/UI without changing this? (YES = correct)
