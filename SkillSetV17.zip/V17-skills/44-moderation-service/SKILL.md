---
skill_id: "44"
name: moderation-service
title: "Moderation Service"
layer: "L8: Specialty"
version: "17.0"
status: "active"
dependencies:
  - "01-core-interfaces"
  - "02-object-processor"
  - "03-elasticsearch-datastore"
  - "06-ai-providers"
  - "21-permissions-service"
dotnet_namespace: "XIIGen.Services.Moderation"
di_registration: "services.AddXIIGenModeration()"
es_index: "xiigen-moderation"
genie_dna:
  - "DNA-1: Moderation records, rules, and review results as dynamic documents"
  - "DNA-2: BuildSearchFilter for moderation queries (status, category, severity — skip empty)"
  - "DNA-3: Inherits MicroserviceBase"
  - "DNA-5: DataProcessResult for all operations"
  - "DNA-6: IAiProvider for content scoring (swap AI models for moderation)"
  - "DNA-FREEDOM: Moderation rules and thresholds are dynamic — admins configure without code"
  - "DNA-SCOPE: Moderators see items assigned to them; admins see all"
triggers: moderation, content review, AI moderation, toxicity, spam, content safety, human review, approval
---

# Skill 44: Moderation Service
## Human/AI Content Review — The Approval Gateway

From Architecture.docx: "Moderation — moderate entity data requests with human/AI agent."

**Classification: HYBRID — MACHINE moderation engine, FREEDOM moderation rules**

---

## Genie DNA Integration

### Moderation Rules as Dynamic Documents (DNA-1, DNA-FREEDOM)
Admins define moderation thresholds without code:
```json
{
  "ruleName": "default_content_policy",
  "categories": ["toxicity", "sexual", "violence", "hate", "spam", "PII"],
  "thresholds": {
    "auto_approve": 0.3,
    "auto_reject": 0.85,
    "human_review": "between"
  },
  "entityTypes": ["*"],
  "createdBy": "admin@company.com"
}
```
Change threshold from 0.85 to 0.90 = update a document. No deployment.

### AI Scoring with Generic Interface (DNA-6)
```csharp
// IAiProvider used for content scoring — swap models via config
var scoreResult = await AiProvider.CompleteAsync(
    $"Score this content for moderation categories: {content}");
var scores = ObjectProcessor.ParseDocument(scoreResult);
// Result: { "toxicity": 0.12, "spam": 0.05, "PII": 0.78 }
```

### Auto-Decision Logic
```
AI scores content → compare against rule thresholds:
  All scores ≤ 0.3 → auto_approve (no human needed)
  Any score ≥ 0.85 → auto_reject (flagged)
  Between → queued for human_review
```

### Scope Isolation for Review Queue (DNA-SCOPE)
Moderators see only items assigned to their categories. BuildSearchFilter injects moderator scope.

## Interface
```csharp
public interface IModerationService
{
    Task<DataProcessResult<string>> SubmitForReviewAsync(Dictionary<string, object> contentDoc);
    Task<DataProcessResult<Dictionary<string, object>>> ScoreContentAsync(
        Dictionary<string, object> contentDoc);
    Task<DataProcessResult<bool>> ReviewAsync(
        string moderationId, string decision, Dictionary<string, object> reviewNotes);
    Task<DataProcessResult<List<Dictionary<string, object>>>> GetReviewQueueAsync(
        Dictionary<string, object> filter, UserScope scope);
    Task<DataProcessResult<string>> CreateRuleAsync(Dictionary<string, object> ruleDoc);
}
```

## Alternatives
All alternatives MUST: store moderation records/rules as dynamic documents, use IAiProvider for scoring, enforce scope isolation on review queues, return DataProcessResult, support dynamic rule definitions.
