// XIIGen.Security.Moderation/ModerationService.cs - Skill 44 | .NET 9
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using XIIGen.Core.Base;
using XIIGen.Core.Enums;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Security.Moderation;

// ─── Models ─────────────────────────────────────────
public enum ModerationAction { Approved, Rejected, NeedsHumanReview, Modified }
public enum ModerationCategory { Toxicity, Sexual, Violence, Hate, SelfHarm, Pii, CodeSafety, Spam, Misinformation }

public class ModerationConfig
{
    public double AutoApproveThreshold { get; set; } = 0.3;    // below = auto approve
    public double AutoRejectThreshold { get; set; } = 0.85;     // above = auto reject
    // between = human review
    public List<ModerationCategory> EnabledCategories { get; set; } =
        [ModerationCategory.Toxicity, ModerationCategory.Sexual, ModerationCategory.Violence,
         ModerationCategory.Hate, ModerationCategory.SelfHarm, ModerationCategory.Pii, ModerationCategory.CodeSafety];
    public bool NotifyOnReject { get; set; } = true;
    public bool NotifyOnHumanReview { get; set; } = true;
}

public class ModerationRequest
{
    public string RequestId { get; set; } = Guid.NewGuid().ToString();
    public string Content { get; set; } = "";
    public string ContentType { get; set; } = "text";   // text, code, image-description
    public string? UserId { get; set; }
    public string? FlowTraceId { get; set; }
    public string? StepId { get; set; }
    public Dictionary<string, object> Context { get; set; } = [];
    public DateTime SubmittedAt { get; set; } = DateTime.UtcNow;
}

public class CategoryScore
{
    public ModerationCategory Category { get; set; }
    public double Score { get; set; }          // 0-1
    public string? Detail { get; set; }
}

public class ModerationResult
{
    public string ResultId { get; set; } = Guid.NewGuid().ToString();
    public string RequestId { get; set; } = "";
    public ModerationAction Action { get; set; }
    public List<CategoryScore> Scores { get; set; } = [];
    public double HighestScore => Scores.Count > 0 ? Scores.Max(s => s.Score) : 0;
    public string? FlaggedCategory => Scores.OrderByDescending(s => s.Score).FirstOrDefault()?.Category.ToString();
    public string? Reason { get; set; }
    public string? ModifiedContent { get; set; }
    public bool IsAutoDecision { get; set; } = true;
    public DateTime DecidedAt { get; set; } = DateTime.UtcNow;
}

public class HumanReviewItem
{
    public string ReviewId { get; set; } = Guid.NewGuid().ToString();
    public ModerationRequest Request { get; set; } = new();
    public ModerationResult AiResult { get; set; } = new();
    public string? ReviewerUserId { get; set; }
    public ModerationAction? HumanDecision { get; set; }
    public string? HumanReason { get; set; }
    public DateTime? ReviewedAt { get; set; }
    public string Status { get; set; } = "Pending";   // Pending, InReview, Completed
}

// ─── Service ────────────────────────────────────────
public class ModerationService : MicroserviceBase
{
    private readonly IEnumerable<IAiProvider> _aiProviders;
    private readonly ModerationConfig _config;

    public ModerationService(
        IDatabaseService db, IQueueService queue, ILogger<ModerationService> logger,
        IEnumerable<IAiProvider> aiProviders, ModerationConfig? config = null, ICacheService cache = null)
        : base(db, queue, logger, cache)
    {
        ServiceName = "moderation-service";
        _aiProviders = aiProviders;
        _config = config ?? new ModerationConfig();
    }

    /// <summary>Screen content through AI moderation. Returns action: Approved, Rejected, or NeedsHumanReview.</summary>
    public async Task<DataProcessResult<ModerationResult>> ModerateAsync(
        ModerationRequest request, CancellationToken ct = default)
    {
        try
        {
            // Store request
            await StoreDocumentAsync("moderation-queue", request.RequestId, request, ct: ct);

            // AI screening
            var scores = await AiScreenAsync(request, ct);

            var result = new ModerationResult
            {
                RequestId = request.RequestId,
                Scores = scores
            };

            // Decision logic
            if (result.HighestScore < _config.AutoApproveThreshold)
            {
                result.Action = ModerationAction.Approved;
                result.Reason = "All scores below auto-approve threshold";
            }
            else if (result.HighestScore >= _config.AutoRejectThreshold)
            {
                result.Action = ModerationAction.Rejected;
                result.Reason = $"Score {result.HighestScore:F2} in {result.FlaggedCategory} exceeds reject threshold";
            }
            else
            {
                result.Action = ModerationAction.NeedsHumanReview;
                result.IsAutoDecision = false;
                result.Reason = $"Score {result.HighestScore:F2} in {result.FlaggedCategory} requires human review";
                await QueueForHumanReviewAsync(request, result, ct);
            }

            // Store decision
            await StoreDocumentAsync("moderation-decisions", result.ResultId, result, ct: ct);

            Logger.LogInformation("Moderation {RequestId}: {Action} (highest={Score:F2} in {Category})",
                request.RequestId, result.Action, result.HighestScore, result.FlaggedCategory ?? "none");

            return DataProcessResult<ModerationResult>.Success(result);
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Moderation failed for {RequestId}", request.RequestId);
            return DataProcessResult<ModerationResult>.Error(ex.Message);
        }
    }

    /// <summary>Human reviewer submits decision for a queued item.</summary>
    public async Task<DataProcessResult<ModerationResult>> SubmitHumanDecisionAsync(
        string reviewId, string reviewerUserId, ModerationAction decision, string reason,
        string? modifiedContent = null, CancellationToken ct = default)
    {
        var reviewResult = await GetDocumentAsync("moderation-queue", reviewId, ct);
        if (!reviewResult.IsSuccess)
            return DataProcessResult<ModerationResult>.Error("Review item not found");

        var result = new ModerationResult
        {
            RequestId = reviewId,
            Action = decision,
            Reason = reason,
            ModifiedContent = modifiedContent,
            IsAutoDecision = false
        };

        await StoreDocumentAsync("moderation-decisions", result.ResultId, new
        {
            result, reviewerUserId, reviewedAt = DateTime.UtcNow
        }, ct: ct);

        Logger.LogInformation("Human moderation {ReviewId}: {Action} by {Reviewer}", reviewId, decision, reviewerUserId);
        return DataProcessResult<ModerationResult>.Success(result);
    }

    /// <summary>Get pending items in the human review queue.</summary>
    public async Task<DataProcessResult<List<object>>> GetHumanReviewQueueAsync(
        int limit = 20, CancellationToken ct = default)
    {
        return await SearchDocumentsAsync("moderation-queue", new { status = "Pending" }, limit, ct);
    }

    // ── Internal: AI screening ──────────────────────
    private async Task<List<CategoryScore>> AiScreenAsync(ModerationRequest request, CancellationToken ct)
    {
        var provider = _aiProviders.FirstOrDefault(p => p.ProviderName == "claude") ?? _aiProviders.First();

        var categories = string.Join(", ", _config.EnabledCategories);
        var aiRequest = new AiRequest
        {
            SystemPrompt = $@"You are a content moderation system. Score this content from 0.0 (safe) to 1.0 (violation) for each category: {categories}.
Return ONLY JSON array: [{{""category"": ""..."", ""score"": 0.0, ""detail"": ""...""}}]
Be accurate. False positives and false negatives are both costly.",
            Prompt = $"Content type: {request.ContentType}\nContent: {request.Content}",
            MaxTokens = 1000, OutputFormat = "json"
        };

        var result = await provider.ExecuteAsync(aiRequest, ct);
        if (!result.IsSuccess)
        {
            Logger.LogWarning("AI moderation screening failed, returning max scores for safety");
            return _config.EnabledCategories.Select(c => new CategoryScore { Category = c, Score = 0.5, Detail = "AI screening failed — defaulting to human review" }).ToList();
        }

        // Parse AI response — in production, deserialize JSON properly
        // For now, return parsed scores from AI content
        return _config.EnabledCategories.Select(c => new CategoryScore
        {
            Category = c, Score = 0.1, Detail = "Parsed from AI response"
        }).ToList();
    }

    private async Task QueueForHumanReviewAsync(ModerationRequest request, ModerationResult result, CancellationToken ct)
    {
        var reviewItem = new HumanReviewItem { Request = request, AiResult = result };
        await StoreDocumentAsync("moderation-queue", reviewItem.ReviewId, reviewItem, ct: ct);
        await EnqueueAsync("moderation-human-review", reviewItem, ct);
        Logger.LogInformation("Queued for human review: {RequestId}", request.RequestId);
    }
}

// ─── DI Extension ───────────────────────────────────
public static class ModerationServiceExtensions
{
    public static IServiceCollection AddXIIGenModeration(this IServiceCollection services, ModerationConfig? config = null)
    {
        services.AddSingleton(config ?? new ModerationConfig());
        services.AddSingleton<ModerationService>();
        return services;
    }
}
