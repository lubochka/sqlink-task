// XIIGen Moderation Service — Java | Skill 44
package com.xiigen.security.moderation;
import com.xiigen.core.*;
import java.util.*;

public class ModerationService extends MicroserviceBase {
    private final IAiProvider aiProvider;
    private final double autoApproveThreshold;
    private final double autoRejectThreshold;

    public ModerationService(IDatabaseService db, IQueueService queue, IAiProvider ai, double approveThresh, double rejectThresh) {
        super(db, queue, "moderation-service");
        this.aiProvider = ai; this.autoApproveThreshold = approveThresh; this.autoRejectThreshold = rejectThresh;
    }

    public DataProcessResult<Map<String, Object>> moderate(String content, String contentType, String userId) throws Exception {
        String requestId = UUID.randomUUID().toString();
        List<Map<String, Object>> scores;
        if (aiProvider != null) {
            String prompt = "Analyze for safety. Score 0-1 for toxicity, sexual, violence, hate, pii, spam. Content: \"" + content.substring(0, Math.min(2000, content.length())) + "\". Return JSON array.";
            String aiResult = aiProvider.complete(prompt);
            try { scores = new com.google.gson.Gson().fromJson(aiResult, List.class); } catch (Exception e) { scores = List.of(Map.of("category", "toxicity", "score", 0.0)); }
        } else { scores = List.of(Map.of("category", "toxicity", "score", 0.0)); }
        double highest = scores.stream().mapToDouble(s -> ((Number) s.getOrDefault("score", 0.0)).doubleValue()).max().orElse(0);
        String action = highest <= autoApproveThreshold ? "approved" : (highest >= autoRejectThreshold ? "rejected" : "needs-review");
        String rid = UUID.randomUUID().toString();
        var result = Map.of("resultId", rid, "requestId", requestId, "action", action, "scores", (Object) scores, "highestScore", highest);
        storeDocument("moderation-results", rid, result);
        if ("rejected".equals(action)) publishEvent("moderation.content.rejected", Map.of("requestId", requestId));
        return DataProcessResult.success(result);
    }
}
