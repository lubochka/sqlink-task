<?php
// XIIGen Moderation Service — PHP | Skill 44
namespace XIIGen\Security\Moderation;
use XIIGen\Core\{MicroserviceBase, DataProcessResult, IDatabaseService, IQueueService, IAiProvider};

class ModerationService extends MicroserviceBase {
    protected string $serviceName = 'moderation-service';
    private ?IAiProvider $ai;
    private float $autoApprove; private float $autoReject;

    public function __construct(IDatabaseService $db, IQueueService $queue, ?IAiProvider $ai = null, float $autoApprove = 0.3, float $autoReject = 0.85) {
        parent::__construct($db, $queue); $this->ai = $ai; $this->autoApprove = $autoApprove; $this->autoReject = $autoReject;
    }

    public function moderate(string $content, string $contentType = 'text', ?string $userId = null): DataProcessResult {
        $requestId = \Ramsey\Uuid\Uuid::uuid4()->toString();
        if ($this->ai) {
            $prompt = "Analyze for safety. Score 0-1 for toxicity,sexual,violence,hate,pii,spam. Content: \"" . substr($content, 0, 2000) . "\". Return JSON array.";
            $aiResult = $this->ai->complete($prompt);
            $scores = json_decode($aiResult, true) ?? [['category' => 'toxicity', 'score' => 0]];
        } else { $scores = [['category' => 'toxicity', 'score' => 0]]; }
        $highest = max(array_column($scores, 'score') ?: [0]);
        $action = $highest <= $this->autoApprove ? 'approved' : ($highest >= $this->autoReject ? 'rejected' : 'needs-review');
        $rid = \Ramsey\Uuid\Uuid::uuid4()->toString();
        $result = ['resultId' => $rid, 'requestId' => $requestId, 'action' => $action, 'scores' => $scores, 'highestScore' => $highest];
        $this->storeDocument('moderation-results', $rid, array_merge($result, ['content' => substr($content, 0, 500), 'userId' => $userId]));
        if ($action === 'rejected') $this->publishEvent('moderation.content.rejected', ['requestId' => $requestId]);
        return DataProcessResult::success($result);
    }

    public function getReviewQueue(int $limit = 20): DataProcessResult {
        $result = $this->searchDocuments('moderation-results', ['action' => 'needs-review'], $limit);
        return DataProcessResult::success($result->isSuccess ? ($result->data ?? []) : []);
    }
}
