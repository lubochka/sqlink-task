# XIIGen Moderation Service — Python | Skill 44
import json, uuid
from datetime import datetime, timezone
from core_interfaces import IDatabaseService, IQueueService, IAiProvider, DataProcessResult, MicroserviceBase

DEFAULT_CATEGORIES = ["toxicity", "sexual", "violence", "hate", "self-harm", "pii", "spam"]

class ModerationService(MicroserviceBase):
    service_name = "moderation-service"

    def __init__(self, db: IDatabaseService, queue: IQueueService, ai: IAiProvider = None, config: dict = None):
        super().__init__(db, queue)
        self._ai = ai
        cfg = config or {}
        self._auto_approve = cfg.get("autoApproveThreshold", 0.3)
        self._auto_reject = cfg.get("autoRejectThreshold", 0.85)
        self._categories = cfg.get("enabledCategories", DEFAULT_CATEGORIES)

    async def moderate(self, content: str, content_type: str = "text", user_id: str = None) -> DataProcessResult:
        request_id = str(uuid.uuid4())
        if self._ai:
            prompt = f'Analyze for safety ({", ".join(self._categories)}). Score 0-1. Content: "{content[:2000]}". Return JSON array of {{category, score, detail}}'
            ai_result = await self._ai.complete(prompt)
            try: scores = json.loads(ai_result)
            except: scores = [{"category": "toxicity", "score": 0, "detail": "Parse failed"}]
        else:
            scores = [{"category": c, "score": 0} for c in self._categories]
        highest = max((s.get("score", 0) for s in scores), default=0)
        action = "approved" if highest <= self._auto_approve else ("rejected" if highest >= self._auto_reject else "needs-review")
        result = {"resultId": str(uuid.uuid4()), "requestId": request_id, "action": action, "scores": scores, "highestScore": highest}
        await self.store_document("moderation-results", result["resultId"], {**result, "content": content[:500], "userId": user_id})
        if action == "rejected": await self.publish_event("moderation.content.rejected", {"requestId": request_id})
        return DataProcessResult.success(result)

    async def get_review_queue(self, limit: int = 20) -> DataProcessResult:
        result = await self.search_documents("moderation-results", {"action": "needs-review"}, limit)
        return DataProcessResult.success(result.data if result.is_success else [])
