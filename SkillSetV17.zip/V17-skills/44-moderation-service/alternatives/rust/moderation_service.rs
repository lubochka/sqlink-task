// XIIGen Moderation Service — Rust | Skill 44
use serde_json::{json, Value};
use uuid::Uuid;
use crate::core::{DataProcessResult, IAiProvider, IDatabaseService, IQueueService, MicroserviceBase};

pub struct ModerationService {
    base: MicroserviceBase,
    ai: Option<Box<dyn IAiProvider>>,
    auto_approve: f64,
    auto_reject: f64,
}

impl ModerationService {
    pub fn new(db: Box<dyn IDatabaseService>, queue: Box<dyn IQueueService>, ai: Option<Box<dyn IAiProvider>>) -> Self {
        Self { base: MicroserviceBase::new(db, queue, "moderation-service"), ai, auto_approve: 0.3, auto_reject: 0.85 }
    }

    pub async fn moderate(&self, content: &str, content_type: &str, user_id: Option<&str>) -> DataProcessResult<Value> {
        let request_id = Uuid::new_v4().to_string();
        let scores = if let Some(ai) = &self.ai {
            let prompt = format!("Analyze for safety. Score 0-1 for toxicity,sexual,violence,hate,pii,spam. Content: \"{}\"", &content[..content.len().min(2000)]);
            let result = ai.complete(&prompt).await;
            serde_json::from_str::<Vec<Value>>(&result).unwrap_or_else(|_| vec![json!({"category":"toxicity","score":0})])
        } else { vec![json!({"category":"toxicity","score":0})] };
        let highest = scores.iter().filter_map(|s| s["score"].as_f64()).fold(0.0_f64, f64::max);
        let action = if highest <= self.auto_approve { "approved" } else if highest >= self.auto_reject { "rejected" } else { "needs-review" };
        let rid = Uuid::new_v4().to_string();
        let result = json!({"resultId": rid, "requestId": request_id, "action": action, "scores": scores, "highestScore": highest});
        self.base.store_document("moderation-results", &rid, &result).await;
        if action == "rejected" { self.base.publish_event("moderation.content.rejected", &json!({"requestId": request_id})).await; }
        DataProcessResult::success(result)
    }
}
