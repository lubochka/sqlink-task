// XIIGen Moderation Service — Node.js/TypeScript | Skill 44
import { IDatabaseService, IQueueService, IAiProvider, DataProcessResult, MicroserviceBase } from '../../01-core-interfaces';
import { randomUUID } from 'crypto';

type ModerationAction = 'approved' | 'rejected' | 'needs-review' | 'modified';
type ModerationCategory = 'toxicity' | 'sexual' | 'violence' | 'hate' | 'self-harm' | 'pii' | 'code-safety' | 'spam';
interface CategoryScore { category: ModerationCategory; score: number; detail?: string; }
interface ModerationConfig { autoApproveThreshold: number; autoRejectThreshold: number; enabledCategories: ModerationCategory[]; }
interface ModerationResult { resultId: string; requestId: string; action: ModerationAction; scores: CategoryScore[]; highestScore: number; reason?: string; }

export class ModerationService extends MicroserviceBase {
  private aiProvider?: IAiProvider;
  private config: ModerationConfig;
  protected serviceName = 'moderation-service';

  constructor(db: IDatabaseService, queue: IQueueService, ai?: IAiProvider, config?: Partial<ModerationConfig>) {
    super(db, queue);
    this.aiProvider = ai;
    this.config = { autoApproveThreshold: 0.3, autoRejectThreshold: 0.85, enabledCategories: ['toxicity', 'sexual', 'violence', 'hate', 'self-harm', 'pii', 'spam'], ...config };
  }

  async moderate(content: string, contentType = 'text', userId?: string, traceId?: string): Promise<DataProcessResult<ModerationResult>> {
    const requestId = randomUUID();
    let scores: CategoryScore[];
    if (this.aiProvider) {
      const prompt = `Analyze this ${contentType} for safety. Score each category 0-1: ${this.config.enabledCategories.join(', ')}. Content: "${content.substring(0, 2000)}". Return JSON array of {category, score, detail}.`;
      const aiResult = await this.aiProvider.complete(prompt);
      try { scores = JSON.parse(aiResult); } catch { scores = [{ category: 'toxicity', score: 0, detail: 'Parse failed' }]; }
    } else {
      scores = this.config.enabledCategories.map(c => ({ category: c, score: 0, detail: 'No AI — auto-approve' }));
    }
    const highestScore = Math.max(...scores.map(s => s.score), 0);
    let action: ModerationAction;
    if (highestScore <= this.config.autoApproveThreshold) action = 'approved';
    else if (highestScore >= this.config.autoRejectThreshold) action = 'rejected';
    else action = 'needs-review';
    const result: ModerationResult = { resultId: randomUUID(), requestId, action, scores, highestScore, reason: scores.find(s => s.score === highestScore)?.detail };
    await this.storeDocument('moderation-results', result.resultId, { ...result, content: content.substring(0, 500), userId, traceId });
    if (action === 'rejected') await this.publishEvent('moderation.content.rejected', { requestId, userId, reason: result.reason });
    if (action === 'needs-review') await this.publishEvent('moderation.content.review', { requestId, userId });
    return DataProcessResult.success(result);
  }

  async getReviewQueue(limit = 20): Promise<DataProcessResult<any[]>> {
    const result = await this.searchDocuments('moderation-results', { action: 'needs-review' }, limit);
    return DataProcessResult.success(result.isSuccess ? result.data || [] : []);
  }

  async resolveReview(resultId: string, action: ModerationAction, reviewerId: string): Promise<DataProcessResult<boolean>> {
    const existing = await this.getDocument('moderation-results', resultId) as any;
    if (!existing) return DataProcessResult.failure('Result not found');
    existing.action = action; existing.reviewedBy = reviewerId; existing.reviewedAt = new Date();
    await this.storeDocument('moderation-results', resultId, existing);
    return DataProcessResult.success(true);
  }
}
