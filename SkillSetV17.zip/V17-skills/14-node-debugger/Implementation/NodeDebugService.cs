// XIIGen.Services.Debug/NodeDebugService.cs - Skill 14 | .NET 9
// Full debug data capture + query + timeline + token usage
using System.Text.Json.Nodes;
using Microsoft.Extensions.Logging;
using XIIGen.Core.Base;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Services.Debug;

// ─── Debug Data Model ───────────────────────────────
public class NodeDebugData
{
    public string DebugId { get; set; } = Guid.NewGuid().ToString();
    public string TraceId { get; set; }
    public string StepId { get; set; }
    public string NodeType { get; set; }
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
    public TimeSpan Duration { get; set; }
    public object Input { get; set; }          // Dynamic document (Genie DNA)
    public object Output { get; set; }         // Dynamic document
    public string Prompt { get; set; }          // AI prompt used
    public int PromptTokens { get; set; }
    public int CompletionTokens { get; set; }
    public object IntermediateData { get; set; } // Dynamic document
    public string Model { get; set; }           // AI model name
    public string Status { get; set; } = "success"; // success, failed, timeout
    public string Error { get; set; }
    public Dictionary<string, object> Metadata { get; set; } = [];
    public int RetryCount { get; set; }
}

public class DebugTimeline
{
    public string TraceId { get; set; }
    public TimeSpan TotalDuration { get; set; }
    public TokenUsage TotalTokens { get; set; } = new();
    public List<TimelineStep> Steps { get; set; } = [];
}

public class TimelineStep
{
    public string StepId { get; set; }
    public string NodeType { get; set; }
    public DateTime StartTime { get; set; }
    public TimeSpan Duration { get; set; }
    public string Status { get; set; }
    public string Model { get; set; }
    public TokenUsage Tokens { get; set; }
}

public class TokenUsage
{
    public int Prompt { get; set; }
    public int Completion { get; set; }
    public int Total => Prompt + Completion;
}

// ─── Service ────────────────────────────────────────
public class NodeDebugService(IDatabaseService db, IQueueService queue, ILogger<NodeDebugService> logger,
    IObjectProcessor processor = null) : MicroserviceBase(db, queue, logger, objectProcessor: processor)
{
    private const string Index = "debug-traces";

    protected override string ServiceName => "node-debugger";

    public async Task<DataProcessResult<NodeDebugData>> SaveDebugDataAsync(NodeDebugData data, CancellationToken ct = default)
    {
        data.DebugId ??= Guid.NewGuid().ToString();
        data.Timestamp = DateTime.UtcNow;
        await StoreDocumentAsync(Index, data.DebugId, data, ct: ct);
        return DataProcessResult<NodeDebugData>.Created(data);
    }

    public async Task<List<NodeDebugData>> GetTraceDebugAsync(string traceId, CancellationToken ct = default)
    {
        var result = await SearchDocumentsAsync(Index, new { traceId }, 100, ct);
        return result.IsSuccess
            ? result.Data?.Select(DeserializeDebug).Where(d => d != null).ToList() ?? []
            : [];
    }

    public async Task<NodeDebugData> GetStepDebugAsync(string traceId, string stepId, CancellationToken ct = default)
    {
        var result = await SearchDocumentsAsync(Index, new { traceId, stepId }, 1, ct);
        return result.IsSuccess ? result.Data?.Select(DeserializeDebug).FirstOrDefault() : null;
    }

    // ─── Timeline Reconstruction ────────────────────
    public async Task<DebugTimeline> GetTimelineAsync(string traceId, CancellationToken ct = default)
    {
        var debugEntries = await GetTraceDebugAsync(traceId, ct);
        var ordered = debugEntries.OrderBy(d => d.Timestamp).ToList();

        var timeline = new DebugTimeline
        {
            TraceId = traceId,
            TotalDuration = ordered.Count > 0
                ? ordered.Last().Timestamp.Add(ordered.Last().Duration) - ordered.First().Timestamp
                : TimeSpan.Zero,
            TotalTokens = new TokenUsage
            {
                Prompt = ordered.Sum(d => d.PromptTokens),
                Completion = ordered.Sum(d => d.CompletionTokens),
            },
            Steps = ordered.Select(d => new TimelineStep
            {
                StepId = d.StepId,
                NodeType = d.NodeType,
                StartTime = d.Timestamp,
                Duration = d.Duration,
                Status = d.Status,
                Model = d.Model,
                Tokens = d.PromptTokens > 0 || d.CompletionTokens > 0
                    ? new TokenUsage { Prompt = d.PromptTokens, Completion = d.CompletionTokens }
                    : null,
            }).ToList(),
        };

        return timeline;
    }

    // ─── Token Usage Summary ────────────────────────
    public async Task<TokenUsage> GetTokenUsageAsync(string traceId, CancellationToken ct = default)
    {
        var entries = await GetTraceDebugAsync(traceId, ct);
        return new TokenUsage
        {
            Prompt = entries.Sum(e => e.PromptTokens),
            Completion = entries.Sum(e => e.CompletionTokens),
        };
    }

    // ─── Dynamic Search (Genie DNA) ─────────────────
    public async Task<List<NodeDebugData>> SearchDebugAsync(object filter, int size = 50, CancellationToken ct = default)
    {
        // Genie DNA: BuildSearchFilter skips empty fields automatically
        var result = await SearchDocumentsAsync(Index, filter, size, ct);
        return result.IsSuccess
            ? result.Data?.Select(DeserializeDebug).Where(d => d != null).ToList() ?? []
            : [];
    }

    // ─── Cleanup ────────────────────────────────────
    public async Task<int> PurgeOldDebugAsync(DateTime before, CancellationToken ct = default)
    {
        var old = await SearchDebugAsync(new { timestampBefore = before }, 1000, ct);
        foreach (var entry in old)
        {
            await DeleteDocumentAsync(Index, entry.DebugId, ct);
        }
        return old.Count;
    }

    private NodeDebugData DeserializeDebug(object obj)
    {
        if (obj is NodeDebugData ndd) return ndd;
        if (obj is JsonObject jo && _objectProcessor != null)
            return _objectProcessor.Deserialize<NodeDebugData>(jo);
        return null;
    }
}
