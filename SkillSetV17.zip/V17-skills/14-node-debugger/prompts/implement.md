# Skill 14 — Node Debugger: Implementation Guide

## Prerequisites
- Skill 01 (Core Interfaces) — MicroserviceBase, IDatabaseService
- Skill 02 (ObjectProcessor) — BuildSearchFilter for dynamic queries
- Skill 03 or 05 — Elasticsearch or Database Fabric

## Step 1: Create NodeDebugData Model
Define with these fields:
- debugId, traceId, stepId, nodeType, timestamp, duration
- input, output (both dynamic — Genie DNA)
- prompt, promptTokens, completionTokens, model (for AI nodes)
- intermediateData (dynamic), status (success/failed/timeout), error
- metadata dict (dynamic extra fields), retryCount

## Step 2: Implement NodeDebugService
1. `SaveDebugDataAsync(data)` — set timestamp, store to ES index "debug-traces"
2. `GetTraceDebugAsync(traceId)` — search by traceId, return all entries
3. `GetStepDebugAsync(traceId, stepId)` — search by both, return single entry

## Step 3: Add Timeline Reconstruction
1. `GetTimelineAsync(traceId)` — get all entries, sort by timestamp
2. Build DebugTimeline with steps ordered by time, cumulative durations
3. Include token counts per step and total

## Step 4: Add Token Usage Summary
1. `GetTokenUsageAsync(traceId)` — sum promptTokens + completionTokens across all steps
2. Return {prompt, completion, total}

## Step 5: Add Dynamic Search (Genie DNA)
1. `SearchDebugAsync(filter, size)` — use ObjectProcessor.BuildSearchFilter
2. Empty fields are automatically skipped
3. Supports filtering by any combination: traceId, stepId, nodeType, status, model, time range

## Step 6: Add Cleanup
1. `PurgeOldDebugAsync(before)` — delete debug entries older than threshold

## Step 7: Integration with Orchestrator
In Skill 09 FlowOrchestrator.ExecuteNodeAsync, after each step:
```csharp
var debug = new NodeDebugData {
    TraceId = execution.TraceId, StepId = node.NodeId,
    NodeType = node.Type.ToString(), Input = context.Input,
    Output = result.Output, Duration = sw.Elapsed,
    IntermediateData = result.DebugData
};
await debugService.SaveDebugDataAsync(debug);
```

## Step 8: Verify
- Test: Save + retrieve debug data
- Test: Timeline returns ordered steps with cumulative timing
- Test: Token usage sums correctly
- Test: Search with partial filter (empty fields skipped)
