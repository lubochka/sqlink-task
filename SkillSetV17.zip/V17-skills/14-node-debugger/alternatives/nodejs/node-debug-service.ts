// XIIGen Node Debugger — Skill 14 | Node.js/TypeScript
// Debug data capture, query, timeline reconstruction, token usage

import { v4 as uuid } from 'uuid';

// ─── Debug Data Model ───────────────────────────────
export interface NodeDebugData {
  debugId: string;
  traceId: string;
  stepId: string;
  nodeType: string;
  timestamp: string;
  duration: number; // milliseconds
  input: any;
  output: any;
  prompt?: string;
  promptTokens: number;
  completionTokens: number;
  intermediateData?: any;
  model?: string;
  status: 'success' | 'failed' | 'timeout';
  error?: string;
  metadata: Record<string, any>;
  retryCount: number;
}

export interface DebugTimeline {
  traceId: string;
  totalDuration: number;
  totalTokens: { prompt: number; completion: number; total: number };
  steps: TimelineStep[];
}

export interface TimelineStep {
  stepId: string;
  nodeType: string;
  startTime: string;
  duration: number;
  status: string;
  model?: string;
  tokens?: { prompt: number; completion: number };
}

// ─── Service ────────────────────────────────────────
export class NodeDebugService {
  private readonly index = 'debug-traces';
  private readonly prefix = 'xiigen';

  constructor(private db: any, private processor?: any) {}

  async saveDebugData(data: Partial<NodeDebugData>): Promise<NodeDebugData> {
    const debug: NodeDebugData = {
      debugId: data.debugId || uuid(),
      traceId: data.traceId || '',
      stepId: data.stepId || '',
      nodeType: data.nodeType || '',
      timestamp: new Date().toISOString(),
      duration: data.duration || 0,
      input: data.input,
      output: data.output,
      prompt: data.prompt,
      promptTokens: data.promptTokens || 0,
      completionTokens: data.completionTokens || 0,
      intermediateData: data.intermediateData,
      model: data.model,
      status: data.status || 'success',
      error: data.error,
      metadata: data.metadata || {},
      retryCount: data.retryCount || 0,
    };
    await this.db.store(this.index, this.prefix, debug.debugId, debug);
    return debug;
  }

  async getTraceDebug(traceId: string): Promise<NodeDebugData[]> {
    const result = await this.db.search(this.index, this.prefix, { traceId }, 100);
    return result?.data ?? [];
  }

  async getStepDebug(traceId: string, stepId: string): Promise<NodeDebugData | null> {
    const result = await this.db.search(this.index, this.prefix, { traceId, stepId }, 1);
    return result?.data?.[0] ?? null;
  }

  async getTimeline(traceId: string): Promise<DebugTimeline> {
    const entries = await this.getTraceDebug(traceId);
    const ordered = entries.sort((a, b) => a.timestamp.localeCompare(b.timestamp));

    const totalPrompt = ordered.reduce((s, e) => s + e.promptTokens, 0);
    const totalCompletion = ordered.reduce((s, e) => s + e.completionTokens, 0);
    const totalDuration = ordered.reduce((s, e) => s + e.duration, 0);

    return {
      traceId,
      totalDuration,
      totalTokens: { prompt: totalPrompt, completion: totalCompletion, total: totalPrompt + totalCompletion },
      steps: ordered.map(d => ({
        stepId: d.stepId,
        nodeType: d.nodeType,
        startTime: d.timestamp,
        duration: d.duration,
        status: d.status,
        model: d.model,
        tokens: d.promptTokens || d.completionTokens
          ? { prompt: d.promptTokens, completion: d.completionTokens }
          : undefined,
      })),
    };
  }

  async getTokenUsage(traceId: string): Promise<{ prompt: number; completion: number; total: number }> {
    const entries = await this.getTraceDebug(traceId);
    const prompt = entries.reduce((s, e) => s + e.promptTokens, 0);
    const completion = entries.reduce((s, e) => s + e.completionTokens, 0);
    return { prompt, completion, total: prompt + completion };
  }

  async searchDebug(filter: Record<string, any>, size = 50): Promise<NodeDebugData[]> {
    // Genie DNA: empty fields auto-skipped by processor
    const clean = Object.fromEntries(Object.entries(filter).filter(([_, v]) => v !== '' && v != null));
    const result = await this.db.search(this.index, this.prefix, clean, size);
    return result?.data ?? [];
  }
}
