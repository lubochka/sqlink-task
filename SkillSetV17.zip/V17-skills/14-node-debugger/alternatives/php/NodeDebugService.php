<?php
// XIIGen Node Debugger — Skill 14 | PHP 8.3+
// Debug data capture, query, timeline reconstruction

declare(strict_types=1);
namespace XIIGen\Services\Debug;

use Ramsey\Uuid\Uuid;

class NodeDebugData {
    public function __construct(
        public string $debugId = '',
        public string $traceId = '',
        public string $stepId = '',
        public string $nodeType = '',
        public string $timestamp = '',
        public float $duration = 0.0,
        public mixed $input = null,
        public mixed $output = null,
        public ?string $prompt = null,
        public int $promptTokens = 0,
        public int $completionTokens = 0,
        public mixed $intermediateData = null,
        public ?string $model = null,
        public string $status = 'success',
        public ?string $error = null,
        public array $metadata = [],
        public int $retryCount = 0,
    ) {
        $this->debugId = $this->debugId ?: Uuid::uuid4()->toString();
        $this->timestamp = $this->timestamp ?: date('c');
    }
}

class NodeDebugService {
    private const INDEX = 'debug-traces';
    private const PREFIX = 'xiigen';

    public function __construct(private $db) {}

    public function save(NodeDebugData $data): NodeDebugData {
        $data->timestamp = date('c');
        $this->db->store(self::INDEX, self::PREFIX, $data->debugId, $data);
        return $data;
    }

    public function getTraceDebug(string $traceId): array {
        $result = $this->db->search(self::INDEX, self::PREFIX, ['traceId' => $traceId], 100);
        return $result['data'] ?? [];
    }

    public function getStepDebug(string $traceId, string $stepId): ?NodeDebugData {
        $result = $this->db->search(self::INDEX, self::PREFIX, ['traceId' => $traceId, 'stepId' => $stepId], 1);
        $data = $result['data'] ?? [];
        return $data[0] ?? null;
    }

    public function getTimeline(string $traceId): array {
        $entries = $this->getTraceDebug($traceId);
        usort($entries, fn($a, $b) => ($a['timestamp'] ?? '') <=> ($b['timestamp'] ?? ''));

        $totalPrompt = array_sum(array_column($entries, 'promptTokens'));
        $totalCompletion = array_sum(array_column($entries, 'completionTokens'));
        $totalDuration = array_sum(array_column($entries, 'duration'));

        return [
            'traceId' => $traceId,
            'totalDuration' => $totalDuration,
            'totalTokens' => ['prompt' => $totalPrompt, 'completion' => $totalCompletion, 'total' => $totalPrompt + $totalCompletion],
            'steps' => array_map(fn($d) => [
                'stepId' => $d['stepId'] ?? '', 'nodeType' => $d['nodeType'] ?? '',
                'startTime' => $d['timestamp'] ?? '', 'duration' => $d['duration'] ?? 0,
                'status' => $d['status'] ?? '', 'model' => $d['model'] ?? null,
            ], $entries),
        ];
    }

    public function getTokenUsage(string $traceId): array {
        $entries = $this->getTraceDebug($traceId);
        $p = array_sum(array_column($entries, 'promptTokens'));
        $c = array_sum(array_column($entries, 'completionTokens'));
        return ['prompt' => $p, 'completion' => $c, 'total' => $p + $c];
    }

    public function searchDebug(array $filter = [], int $size = 50): array {
        $clean = array_filter($filter, fn($v) => $v !== '' && $v !== null);
        $result = $this->db->search(self::INDEX, self::PREFIX, $clean, $size);
        return $result['data'] ?? [];
    }
}
