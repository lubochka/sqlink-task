// XIIGen Node Debugger — Skill 14 | Java 21+
// Debug data capture, query, timeline reconstruction

package com.xiigen.services.debug;

import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

public class NodeDebugService {
    private static final String INDEX = "debug-traces";
    private static final String PREFIX = "xiigen";
    private final Object db;

    public NodeDebugService(Object db) { this.db = db; }

    // ─── Data Model ─────────────────────────────────
    public record NodeDebugData(
        String debugId, String traceId, String stepId, String nodeType,
        Instant timestamp, Duration duration,
        Object input, Object output, String prompt,
        int promptTokens, int completionTokens,
        Object intermediateData, String model,
        String status, String error,
        Map<String, Object> metadata, int retryCount
    ) {
        public static NodeDebugData create(String traceId, String stepId, String nodeType, Object input, Object output) {
            return new NodeDebugData(
                UUID.randomUUID().toString(), traceId, stepId, nodeType,
                Instant.now(), Duration.ZERO, input, output, null,
                0, 0, null, null, "success", null, Map.of(), 0
            );
        }
    }

    public record DebugTimeline(String traceId, Duration totalDuration,
        int totalPromptTokens, int totalCompletionTokens, List<TimelineStep> steps) {}

    public record TimelineStep(String stepId, String nodeType, Instant startTime,
        Duration duration, String status, String model, int promptTokens, int completionTokens) {}

    // ─── Save ───────────────────────────────────────
    public NodeDebugData save(NodeDebugData data) {
        // Store via database service (dynamic document — Genie DNA)
        // db.store(INDEX, PREFIX, data.debugId(), data);
        return data;
    }

    // ─── Query ──────────────────────────────────────
    public List<NodeDebugData> getTraceDebug(String traceId) {
        // db.search(INDEX, PREFIX, Map.of("traceId", traceId), 100);
        return List.of();
    }

    public Optional<NodeDebugData> getStepDebug(String traceId, String stepId) {
        // db.search(INDEX, PREFIX, Map.of("traceId", traceId, "stepId", stepId), 1);
        return Optional.empty();
    }

    // ─── Timeline ───────────────────────────────────
    public DebugTimeline getTimeline(String traceId) {
        var entries = getTraceDebug(traceId);
        var ordered = entries.stream()
            .sorted(Comparator.comparing(NodeDebugData::timestamp))
            .toList();

        int totalPrompt = ordered.stream().mapToInt(NodeDebugData::promptTokens).sum();
        int totalCompletion = ordered.stream().mapToInt(NodeDebugData::completionTokens).sum();
        Duration totalDuration = ordered.stream()
            .map(NodeDebugData::duration)
            .reduce(Duration.ZERO, Duration::plus);

        var steps = ordered.stream()
            .map(d -> new TimelineStep(
                d.stepId(), d.nodeType(), d.timestamp(), d.duration(),
                d.status(), d.model(), d.promptTokens(), d.completionTokens()
            ))
            .toList();

        return new DebugTimeline(traceId, totalDuration, totalPrompt, totalCompletion, steps);
    }

    // ─── Token Usage ────────────────────────────────
    public Map<String, Integer> getTokenUsage(String traceId) {
        var entries = getTraceDebug(traceId);
        int p = entries.stream().mapToInt(NodeDebugData::promptTokens).sum();
        int c = entries.stream().mapToInt(NodeDebugData::completionTokens).sum();
        return Map.of("prompt", p, "completion", c, "total", p + c);
    }

    // ─── Search (Genie DNA — empty fields skipped) ──
    public List<NodeDebugData> searchDebug(Map<String, Object> filter, int size) {
        var clean = filter.entrySet().stream()
            .filter(e -> e.getValue() != null && !"".equals(e.getValue()))
            .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
        // db.search(INDEX, PREFIX, clean, size);
        return List.of();
    }
}
