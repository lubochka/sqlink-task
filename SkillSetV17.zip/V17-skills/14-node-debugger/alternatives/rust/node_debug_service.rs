// XIIGen Node Debugger — Skill 14 | Rust
// Debug data capture, query, timeline reconstruction

use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use chrono::{DateTime, Utc};
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct NodeDebugData {
    pub debug_id: String,
    pub trace_id: String,
    pub step_id: String,
    pub node_type: String,
    pub timestamp: DateTime<Utc>,
    pub duration_ms: u64,
    pub input: serde_json::Value,
    pub output: serde_json::Value,
    pub prompt: Option<String>,
    pub prompt_tokens: u32,
    pub completion_tokens: u32,
    pub intermediate_data: Option<serde_json::Value>,
    pub model: Option<String>,
    pub status: String, // success, failed, timeout
    pub error: Option<String>,
    pub metadata: HashMap<String, serde_json::Value>,
    pub retry_count: u32,
}

impl Default for NodeDebugData {
    fn default() -> Self {
        Self {
            debug_id: Uuid::new_v4().to_string(),
            trace_id: String::new(), step_id: String::new(), node_type: String::new(),
            timestamp: Utc::now(), duration_ms: 0,
            input: serde_json::Value::Null, output: serde_json::Value::Null,
            prompt: None, prompt_tokens: 0, completion_tokens: 0,
            intermediate_data: None, model: None,
            status: "success".to_string(), error: None,
            metadata: HashMap::new(), retry_count: 0,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DebugTimeline {
    pub trace_id: String,
    pub total_duration_ms: u64,
    pub total_tokens: TokenUsage,
    pub steps: Vec<TimelineStep>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TimelineStep {
    pub step_id: String,
    pub node_type: String,
    pub start_time: DateTime<Utc>,
    pub duration_ms: u64,
    pub status: String,
    pub model: Option<String>,
    pub tokens: Option<TokenUsage>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct TokenUsage {
    pub prompt: u32,
    pub completion: u32,
    pub total: u32,
}

// ─── Service ────────────────────────────────────────
pub struct NodeDebugService<D> {
    db: D,
}

impl<D> NodeDebugService<D> {
    pub fn new(db: D) -> Self { Self { db } }

    pub fn build_timeline(entries: &[NodeDebugData]) -> DebugTimeline {
        let mut sorted = entries.to_vec();
        sorted.sort_by_key(|e| e.timestamp);

        let total_prompt: u32 = sorted.iter().map(|e| e.prompt_tokens).sum();
        let total_completion: u32 = sorted.iter().map(|e| e.completion_tokens).sum();
        let total_duration: u64 = sorted.iter().map(|e| e.duration_ms).sum();

        DebugTimeline {
            trace_id: sorted.first().map(|e| e.trace_id.clone()).unwrap_or_default(),
            total_duration_ms: total_duration,
            total_tokens: TokenUsage {
                prompt: total_prompt, completion: total_completion,
                total: total_prompt + total_completion,
            },
            steps: sorted.iter().map(|d| TimelineStep {
                step_id: d.step_id.clone(), node_type: d.node_type.clone(),
                start_time: d.timestamp, duration_ms: d.duration_ms,
                status: d.status.clone(), model: d.model.clone(),
                tokens: if d.prompt_tokens > 0 || d.completion_tokens > 0 {
                    Some(TokenUsage { prompt: d.prompt_tokens, completion: d.completion_tokens, total: d.prompt_tokens + d.completion_tokens })
                } else { None },
            }).collect(),
        }
    }

    pub fn token_usage(entries: &[NodeDebugData]) -> TokenUsage {
        let p: u32 = entries.iter().map(|e| e.prompt_tokens).sum();
        let c: u32 = entries.iter().map(|e| e.completion_tokens).sum();
        TokenUsage { prompt: p, completion: c, total: p + c }
    }
}
