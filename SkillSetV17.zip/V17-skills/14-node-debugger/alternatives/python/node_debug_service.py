# XIIGen Node Debugger — Skill 14 | Python
# Debug data capture, query, timeline reconstruction, token usage

from __future__ import annotations
import uuid as uuid_mod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional


@dataclass
class NodeDebugData:
    debug_id: str = field(default_factory=lambda: str(uuid_mod.uuid4()))
    trace_id: str = ""
    step_id: str = ""
    node_type: str = ""
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    duration: float = 0.0  # seconds
    input: Any = None
    output: Any = None
    prompt: Optional[str] = None
    prompt_tokens: int = 0
    completion_tokens: int = 0
    intermediate_data: Any = None
    model: Optional[str] = None
    status: str = "success"  # success, failed, timeout
    error: Optional[str] = None
    metadata: dict[str, Any] = field(default_factory=dict)
    retry_count: int = 0


@dataclass
class DebugTimeline:
    trace_id: str = ""
    total_duration: float = 0.0
    total_tokens: dict = field(default_factory=lambda: {"prompt": 0, "completion": 0, "total": 0})
    steps: list[dict] = field(default_factory=list)


class NodeDebugService:
    INDEX = "debug-traces"
    PREFIX = "xiigen"

    def __init__(self, db, processor=None):
        self._db = db
        self._processor = processor

    async def save_debug_data(self, data: NodeDebugData) -> NodeDebugData:
        data.debug_id = data.debug_id or str(uuid_mod.uuid4())
        data.timestamp = datetime.now(timezone.utc).isoformat()
        await self._db.store(self.INDEX, self.PREFIX, data.debug_id, data.__dict__)
        return data

    async def get_trace_debug(self, trace_id: str) -> list[NodeDebugData]:
        result = await self._db.search(self.INDEX, self.PREFIX, {"traceId": trace_id}, 100)
        return result.get("data", [])

    async def get_step_debug(self, trace_id: str, step_id: str) -> NodeDebugData | None:
        result = await self._db.search(self.INDEX, self.PREFIX, {"traceId": trace_id, "stepId": step_id}, 1)
        data = result.get("data", [])
        return data[0] if data else None

    async def get_timeline(self, trace_id: str) -> DebugTimeline:
        entries = await self.get_trace_debug(trace_id)
        if not entries:
            return DebugTimeline(trace_id=trace_id)

        ordered = sorted(entries, key=lambda e: e.get("timestamp", "") if isinstance(e, dict) else getattr(e, "timestamp", ""))

        total_prompt = sum(_get(e, "prompt_tokens", 0) for e in ordered)
        total_completion = sum(_get(e, "completion_tokens", 0) for e in ordered)
        total_duration = sum(_get(e, "duration", 0) for e in ordered)

        return DebugTimeline(
            trace_id=trace_id,
            total_duration=total_duration,
            total_tokens={"prompt": total_prompt, "completion": total_completion, "total": total_prompt + total_completion},
            steps=[{
                "stepId": _get(e, "step_id"), "nodeType": _get(e, "node_type"),
                "startTime": _get(e, "timestamp"), "duration": _get(e, "duration", 0),
                "status": _get(e, "status"), "model": _get(e, "model"),
            } for e in ordered],
        )

    async def get_token_usage(self, trace_id: str) -> dict:
        entries = await self.get_trace_debug(trace_id)
        p = sum(_get(e, "prompt_tokens", 0) for e in entries)
        c = sum(_get(e, "completion_tokens", 0) for e in entries)
        return {"prompt": p, "completion": c, "total": p + c}

    async def search_debug(self, filt: dict | None = None, size: int = 50) -> list:
        clean = {k: v for k, v in (filt or {}).items() if v not in ("", None)}
        result = await self._db.search(self.INDEX, self.PREFIX, clean, size)
        return result.get("data", [])


def _get(obj, key, default=None):
    if isinstance(obj, dict):
        return obj.get(key, obj.get(_camel(key), default))
    return getattr(obj, key, default)


def _camel(snake: str) -> str:
    parts = snake.split("_")
    return parts[0] + "".join(p.capitalize() for p in parts[1:])
