---
name: node-debugger
description: Captures, stores, and queries debug data for every flow node execution — input, prompt, intermediate data, output, duration, token usage
triggers: debug, trace, node execution, inspect step, flow debugging, debug trace
dependencies: [01-core-interfaces, 02-object-processor, 03-elasticsearch-datastore, 05-database-fabric]
layer: L3-FlowEngine
genie-dna: Debug data stored as dynamic documents. Query uses BuildSearchFilter with empty-field skipping for flexible filtering by trace/step/time/type.
phase: 2
---

# Skill 14: Node Debugger
## Debug Data Capture + Query + Timeline Reconstruction

Records everything that happens at each node execution — what went in, what the AI prompt was, what intermediate processing occurred, what came out, how long it took, and how many tokens were used. Enables full flow debugging and inspection.

---

## Debug Data Model

```
NodeDebugData
├── debugId          — unique ID
├── traceId          — links to FlowExecution
├── stepId           — which node in the flow
├── nodeType         — trigger, aiTransform, aiReview, etc.
├── timestamp        — when execution started
├── duration         — TimeSpan / milliseconds
├── input            — what the node received (dynamic document)
├── output           — what the node produced (dynamic document)
├── prompt           — the AI prompt used (if AI node)
├── promptTokens     — input token count
├── completionTokens — output token count
├── intermediateData — any mid-processing data (dynamic document)
├── model            — which AI model was used
├── status           — success, failed, timeout
├── error            — error message if failed
├── metadata         — arbitrary extra fields (Genie DNA)
└── retryCount       — how many retries were attempted
```

## API

| Method | Description |
|---|---|
| `SaveDebugDataAsync(data)` | Store debug entry for a node execution |
| `GetTraceDebugAsync(traceId)` | Get all debug entries for a flow execution |
| `GetStepDebugAsync(traceId, stepId)` | Get specific step's debug data |
| `GetTimelineAsync(traceId)` | Get ordered timeline with durations |
| `SearchDebugAsync(filter, size)` | Dynamic search with Genie DNA empty-field skipping |
| `GetTokenUsageAsync(traceId)` | Sum tokens across all AI steps |
| `PurgeOldDebugAsync(before)` | Clean up old debug data |

## Timeline Reconstruction

```
GET /api/debug/{traceId}/timeline

Response:
{
  "traceId": "abc-123",
  "totalDuration": "00:05:23",
  "totalTokens": { "prompt": 15420, "completion": 8930 },
  "steps": [
    { "stepId": "parse", "nodeType": "FigmaParser", "start": "0:00", "duration": "0:02", "status": "success" },
    { "stepId": "transform", "nodeType": "AiTransform", "start": "0:02", "duration": "4:50", "status": "success",
      "model": "claude-sonnet-4-5-20250929", "tokens": { "prompt": 12000, "completion": 6500 } },
    { "stepId": "review", "nodeType": "AiReview", "start": "4:52", "duration": "0:31", "status": "success",
      "model": "claude-sonnet-4-5-20250929", "tokens": { "prompt": 3420, "completion": 2430 } }
  ]
}
```

## Search Examples (Genie DNA)

```
// Find all failed steps across all traces
filter: { status: "failed" }

// Find AI steps that used more than 10K tokens
filter: { nodeType: "AiTransform", promptTokens: { gte: 10000 } }

// Find all debug data for a specific trace and step
filter: { traceId: "abc-123", stepId: "transform" }

// Empty fields are automatically skipped — pass whatever you have
filter: { traceId: "abc-123", model: "", status: "" }
// → only filters by traceId
```

## Integration with Orchestrator (Skill 09)

The FlowOrchestrator automatically saves debug data after each step execution:
```csharp
var debug = new NodeDebugData {
    TraceId = execution.TraceId,
    StepId = node.NodeId,
    NodeType = node.Type.ToString(),
    Input = context.Input,
    Output = result.Output,
    Duration = sw.Elapsed,
    IntermediateData = result.DebugData
};
await debugService.SaveDebugDataAsync(debug);
```

## Test Scenarios

1. Save debug data → persists to ES, returns debugId
2. Get trace debug → returns all entries ordered by timestamp
3. Get step debug → returns specific entry
4. Get timeline → returns ordered steps with cumulative timing
5. Token usage → sums prompt + completion tokens
6. Search with partial filter → empty fields skipped
