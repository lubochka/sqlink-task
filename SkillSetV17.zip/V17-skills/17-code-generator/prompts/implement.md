# Implement Skill 17: Code Generator Service

## Context
You are implementing the Code Generator Service for XIIGen — a flow orchestration platform. This service transforms AI output into production-ready project structures with multi-stack support.

## Steps

1. **Read** `skills/17-code-generator/SKILL.md` completely
2. **Create Models** — `CodeUnit`, `ProjectTemplate`, `GenerationPlan`, `GenerationResult`, `TechStack` enum
3. **Create Interface** — `ICodeGeneratorService` with `CreatePlanAsync`, `GenerateProjectAsync`, `GenerateFromFlowResultAsync`, `ValidateSyntaxAsync`, `GetTemplate`
4. **Implement Service** — `CodeGeneratorService` extending `MicroserviceBase`
   - Initialize 6 tech stack templates with folder structures + boilerplate files
   - Variable substitution using `{{key}}` → value replacement
   - Code block extraction from markdown ``` fences
   - Basic syntax validation (bracket matching)
5. **Register DI** — `services.AddSingleton<ICodeGeneratorService, CodeGeneratorService>()`
6. **Add API Routes** — `POST /api/codegen/plan`, `POST /api/codegen/generate`, `POST /api/codegen/from-flow`
7. **Write Tests** — Plan includes boilerplate, generation substitutes variables, syntax validation works

## Verification Checklist
- [ ] 6 tech stacks configured (DotNet, NodeJs, Python, Java, Rust, PHP)
- [ ] Each template has folder structure + package/project file
- [ ] Variable substitution works in filenames AND content
- [ ] Code blocks extracted from markdown fences
- [ ] Results stored in Elasticsearch index `xiigen-generated-projects`
- [ ] Syntax validation catches mismatched brackets
- [ ] All 3 API endpoints functional

## Key Files
- SKILL.md: `skills/17-code-generator/SKILL.md`
- Existing .cs: `skills/17-code-generator/Implementation/CodeGeneratorService.cs`
- Alternatives: `skills/17-code-generator/alternatives/{nodejs,python,java,rust,php}/`


---

## Genie DNA Compliance — MANDATORY for All Implementations

> Before writing ANY code, classify each component:
> **MACHINE** (static): Infrastructure that enables freedom. Build once, generic, interface-based.
> **FREEDOM** (dynamic): Anything users define. No fixed models, config-driven.

### DNA Checklist — Every Implementation MUST:
☐ **DNA-1 (Dynamic Documents):** Store data as `Dictionary<string, object>` / `Record<string, any>` — NOT typed model classes. User fields preserved without schema changes.
☐ **DNA-2 (BuildSearchFilter):** All queries use BuildSearchFilter/equivalent. Empty fields auto-skipped. No entity-specific query code.
☐ **DNA-3 (MicroserviceBase):** Inherit base class with DB, queue, cache, logger built in.
☐ **DNA-5 (DataProcessResult):** All public methods return `DataProcessResult<T>`. Errors return failure, not throw exceptions.
☐ **DNA-6 (Generic Interfaces):** External dependencies behind interfaces. Swap via config.
☐ **DNA-SCOPE:** Non-admin queries auto-inject userId filter. Cannot be bypassed.

### The Three Tests:
1. Can a business user change this without a developer? (YES = correct)
2. Does it work for entity types that do not exist yet? (YES = correct)
3. Can I swap the database/service/UI without changing this? (YES = correct)
