---
name: code-generator
description: Transforms AI output into production-ready project structures with multi-stack support
triggers: generate code, scaffold project, create files, code output, project structure
dependencies: [01-core-interfaces, 02-object-processor, 03-elasticsearch-datastore, 06-ai-providers, 11-ai-transform-executor]
layer: L5-Application
genie-dna: "Generated code metadata stored as dynamic documents via ParseObjectAlternative. All DB queries use BuildSearchFilter. Template resolution uses DataProcessResult pattern."
---

# Skill 17: Code Generator Service
## Transform AI output into production-ready project structures with multi-stack support

**Status:** Ready to Generate  
**Priority:** P1 — Core output: turns AI responses into real files  
**Dependencies:** Skill 01 (Core Interfaces), Skill 03 (Database Fabric), Skill 06 (AI Providers)  
**Layer:** L5: Application  
**Phase:** 7  
**Estimated LOC:** ~450  

---

## Overview

The Code Generator is XIIGen's "printing press." When an AI step produces code, the Code Generator extracts code blocks, maps them to a project template, substitutes variables, injects boilerplate (package files, configs, entry points), and writes a complete, compilable project structure. It supports 6 technology stacks and handles the gap between "AI text output" and "runnable project."

## Key Concepts

- **CodeUnit** — A single extracted code block with filename, language, and content
- **ProjectTemplate** — Predefined folder structure + boilerplate per technology stack
- **GenerationPlan** — Ordered list of CodeUnits + template + variable bindings
- **Variable Substitution** — `{{ProjectName}}`, `{{Namespace}}` replaced in all files
- **PostProcessor** — Validates syntax, fixes imports, formats code after generation
- **TechStack** — Enum: DotNet, NodeJs, Python, Java, Rust, PHP

---

## Primary Implementation (.NET 9)

### Models

```csharp
// File: XIIGen.CodeGen/Models/CodeGenModels.cs
namespace XIIGen.CodeGen.Models;

public enum TechStack { DotNet, NodeJs, Python, Java, Rust, PHP }

public record CodeUnit(
    string FileName, string Content, string Language,
    string RelativePath, bool IsEntryPoint = false
);

public record ProjectTemplate(
    TechStack Stack, string Name,
    List<string> FolderStructure,
    Dictionary<string, string> BoilerplateFiles,
    Dictionary<string, string> ConfigFiles
);

public record GenerationPlan(
    string PlanId, string ProjectName, TechStack Stack,
    ProjectTemplate Template, List<CodeUnit> Units,
    Dictionary<string, string> Variables,
    DateTime CreatedAt = default
) { public DateTime CreatedAt { get; init; } = CreatedAt == default ? DateTime.UtcNow : CreatedAt; }

public record GenerationResult(
    string PlanId, string ProjectName, TechStack Stack,
    int FilesGenerated, int FoldersCreated,
    List<string> Warnings, Dictionary<string, string> GeneratedFiles,
    bool SyntaxValid, DateTime GeneratedAt = default
) { public DateTime GeneratedAt { get; init; } = GeneratedAt == default ? DateTime.UtcNow : GeneratedAt; }
```

### Service Interface

```csharp
// File: XIIGen.CodeGen/ICodeGeneratorService.cs
namespace XIIGen.CodeGen;

public interface ICodeGeneratorService
{
    Task<GenerationPlan> CreatePlanAsync(string projectName, TechStack stack,
        List<CodeUnit> units, Dictionary<string, string>? variables = null, CancellationToken ct = default);
    Task<GenerationResult> GenerateProjectAsync(GenerationPlan plan, CancellationToken ct = default);
    Task<GenerationResult> GenerateFromFlowResultAsync(string flowTraceId,
        TechStack stack, string projectName, CancellationToken ct = default);
    Task<bool> ValidateSyntaxAsync(string code, string language, CancellationToken ct = default);
    ProjectTemplate GetTemplate(TechStack stack);
}
```

### Service Implementation

```csharp
// File: XIIGen.CodeGen/CodeGeneratorService.cs
using Microsoft.Extensions.Logging;
using XIIGen.Core.Base;
using XIIGen.Core.Interfaces;

namespace XIIGen.CodeGen;

public class CodeGeneratorService : MicroserviceBase, ICodeGeneratorService
{
    private readonly Dictionary<TechStack, ProjectTemplate> _templates = new();

    public CodeGeneratorService(IDatabaseService db, IQueueService queue, ILogger<CodeGeneratorService> logger)
        : base(db, queue, logger) { ServiceName = "code-generator"; InitializeTemplates(); }

    private void InitializeTemplates()
    {
        _templates[TechStack.DotNet] = new(TechStack.DotNet, "dotnet9",
            ["src", "src/Models", "src/Services", "tests"],
            new() { ["{{ProjectName}}.csproj"] = "<Project Sdk=\"Microsoft.NET.Sdk.Web\"><PropertyGroup><TargetFramework>net9.0</TargetFramework></PropertyGroup></Project>" },
            new() { ["appsettings.json"] = "{ \"Logging\": { \"LogLevel\": { \"Default\": \"Information\" } } }" });

        _templates[TechStack.NodeJs] = new(TechStack.NodeJs, "nodejs",
            ["src", "src/models", "src/services", "src/routes", "tests"],
            new() { ["package.json"] = "{ \"name\": \"{{projectName}}\", \"version\": \"1.0.0\", \"type\": \"module\" }" },
            new() { ["tsconfig.json"] = "{ \"compilerOptions\": { \"target\": \"ES2022\", \"module\": \"ESNext\", \"strict\": true } }" });

        _templates[TechStack.Python] = new(TechStack.Python, "python",
            ["src", "src/models", "src/services", "tests"],
            new() { ["pyproject.toml"] = "[project]\nname = \"{{projectName}}\"\nversion = \"1.0.0\"" }, new());

        _templates[TechStack.Java] = new(TechStack.Java, "java",
            ["src/main/java", "src/main/java/models", "src/main/java/services", "src/test/java"],
            new() { ["pom.xml"] = "<project><modelVersion>4.0.0</modelVersion><artifactId>{{projectName}}</artifactId></project>" },
            new() { ["src/main/resources/application.yml"] = "spring:\n  application:\n    name: {{projectName}}" });

        _templates[TechStack.Rust] = new(TechStack.Rust, "rust",
            ["src", "src/models", "src/services", "tests"],
            new() { ["Cargo.toml"] = "[package]\nname = \"{{projectName}}\"\nversion = \"0.1.0\"\nedition = \"2021\"" }, new());

        _templates[TechStack.PHP] = new(TechStack.PHP, "php",
            ["src", "src/Models", "src/Services", "tests"],
            new() { ["composer.json"] = "{ \"name\": \"xiigen/{{projectName}}\", \"require\": { \"php\": \"^8.3\" } }" }, new());
    }

    public async Task<GenerationPlan> CreatePlanAsync(string projectName, TechStack stack,
        List<CodeUnit> units, Dictionary<string, string>? variables = null, CancellationToken ct = default)
    {
        var template = GetTemplate(stack);
        var vars = variables ?? new();
        vars.TryAdd("ProjectName", projectName);
        vars.TryAdd("projectName", projectName.ToLowerInvariant().Replace(" ", "-"));
        vars.TryAdd("Namespace", projectName.Replace(" ", ".").Replace("-", "."));
        var plan = new GenerationPlan(Guid.NewGuid().ToString(), projectName, stack, template, units, vars);
        await StoreDocumentAsync("xiigen-generation-plans", plan.PlanId, plan, ct: ct);
        return plan;
    }

    public async Task<GenerationResult> GenerateProjectAsync(GenerationPlan plan, CancellationToken ct = default)
    {
        var files = new Dictionary<string, string>();
        var warnings = new List<string>();

        foreach (var (path, content) in plan.Template.BoilerplateFiles)
            files[SubstituteVars(path, plan.Variables)] = SubstituteVars(content, plan.Variables);
        foreach (var (path, content) in plan.Template.ConfigFiles)
            files[SubstituteVars(path, plan.Variables)] = SubstituteVars(content, plan.Variables);

        foreach (var unit in plan.Units)
        {
            var fullPath = string.IsNullOrEmpty(unit.RelativePath) ? unit.FileName
                : $"{unit.RelativePath.TrimEnd('/')}/{unit.FileName}";
            files[fullPath] = SubstituteVars(unit.Content, plan.Variables);
        }

        var syntaxValid = true;
        foreach (var unit in plan.Units)
            if (!await ValidateSyntaxAsync(unit.Content, unit.Language, ct))
            { warnings.Add($"Syntax warning: {unit.FileName}"); syntaxValid = false; }

        var result = new GenerationResult(plan.PlanId, plan.ProjectName, plan.Stack,
            files.Count, plan.Template.FolderStructure.Count, warnings, files, syntaxValid);
        await StoreDocumentAsync("xiigen-generated-projects", plan.PlanId, result, ct: ct);
        return result;
    }

    public async Task<GenerationResult> GenerateFromFlowResultAsync(string flowTraceId,
        TechStack stack, string projectName, CancellationToken ct = default)
    {
        var flowResult = await GetDocumentAsync<object>("xiigen-flow-results", flowTraceId, ct);
        var codeBlocks = ExtractCodeBlocks(flowResult?.ToString() ?? "");
        var ext = GetExtension(stack);
        var units = codeBlocks.Select((code, i) => new CodeUnit($"Generated_{i}.{ext}", code, stack.ToString(), "src/")).ToList();
        var plan = await CreatePlanAsync(projectName, stack, units, ct: ct);
        return await GenerateProjectAsync(plan, ct);
    }

    public Task<bool> ValidateSyntaxAsync(string code, string language, CancellationToken ct = default)
    {
        var stack = new Stack<char>();
        var pairs = new Dictionary<char, char> { { ')', '(' }, { ']', '[' }, { '}', '{' } };
        foreach (var ch in code)
        {
            if (ch is '(' or '[' or '{') stack.Push(ch);
            if (pairs.ContainsKey(ch) && (stack.Count == 0 || stack.Pop() != pairs[ch]))
                return Task.FromResult(false);
        }
        return Task.FromResult(stack.Count == 0);
    }

    public ProjectTemplate GetTemplate(TechStack stack) =>
        _templates.TryGetValue(stack, out var t) ? t : _templates[TechStack.DotNet];

    private static string SubstituteVars(string text, Dictionary<string, string> vars)
    { foreach (var (k, v) in vars) text = text.Replace($"{{{{{k}}}}}", v); return text; }

    private static List<string> ExtractCodeBlocks(string text)
    {
        var blocks = new List<string>(); bool inBlock = false; var cur = new System.Text.StringBuilder();
        foreach (var line in text.Split('\n'))
        {
            if (line.TrimStart().StartsWith("```") && !inBlock) { inBlock = true; continue; }
            if (line.TrimStart().StartsWith("```") && inBlock) { blocks.Add(cur.ToString()); cur.Clear(); inBlock = false; continue; }
            if (inBlock) cur.AppendLine(line);
        }
        if (blocks.Count == 0 && text.Length > 0) blocks.Add(text);
        return blocks;
    }

    private static string GetExtension(TechStack s) => s switch
    { TechStack.DotNet => "cs", TechStack.NodeJs => "ts", TechStack.Python => "py",
      TechStack.Java => "java", TechStack.Rust => "rs", TechStack.PHP => "php", _ => "txt" };
}
```

### DI & API

```csharp
services.AddSingleton<ICodeGeneratorService, CodeGeneratorService>();

app.MapPost("/api/codegen/plan", async (ICodeGeneratorService svc, CreatePlanRequest req, CancellationToken ct) =>
    Results.Ok(await svc.CreatePlanAsync(req.ProjectName, req.Stack, req.Units, req.Variables, ct)));
app.MapPost("/api/codegen/generate", async (ICodeGeneratorService svc, GenerationPlan plan, CancellationToken ct) =>
    Results.Ok(await svc.GenerateProjectAsync(plan, ct)));
```

### Elasticsearch Index: `xiigen-generated-projects`, `xiigen-generation-plans`

---

## Tests

```csharp
[Fact] public async Task CreatePlan_IncludesBoilerplate()
{
    var plan = await _svc.CreatePlanAsync("MyApp", TechStack.NodeJs,
        [new("index.ts", "console.log('hi')", "typescript", "src/")]);
    Assert.Contains("package.json", plan.Template.BoilerplateFiles.Keys);
}

[Fact] public async Task GenerateProject_SubstitutesVariables()
{
    var plan = await _svc.CreatePlanAsync("MyApp", TechStack.DotNet,
        [new("Program.cs", "namespace {{Namespace}};", "csharp", "src/")]);
    var result = await _svc.GenerateProjectAsync(plan);
    Assert.Contains("namespace MyApp;", result.GeneratedFiles.Values);
}

[Fact] public async Task ValidateSyntax_DetectsMismatched()
{
    Assert.True(await _svc.ValidateSyntaxAsync("{ () }", "csharp"));
    Assert.False(await _svc.ValidateSyntaxAsync("{ ( }", "csharp"));
}
```

---

## Alternatives

| Stack | File | Key Libraries |
|-------|------|--------------|
| Node.js/TypeScript | `alternatives/nodejs/code-generator.ts` | Handlebars, fs-extra |
| Python 3.12 | `alternatives/python/code_generator.py` | Jinja2, pathlib, dataclasses |
| Java 21 | `alternatives/java/CodeGeneratorService.java` | FreeMarker, nio.file, records |
| Rust | `alternatives/rust/code_generator.rs` | Tera, std::fs, HashMap |
| PHP 8.3 | `alternatives/php/CodeGeneratorService.php` | Blade, Laravel Filesystem, enums |

## Implementation Prompt → `prompts/implement.md`
