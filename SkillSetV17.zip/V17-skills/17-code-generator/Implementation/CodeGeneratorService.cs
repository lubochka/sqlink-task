// XIIGen.Services.CodeGen/CodeGeneratorService.cs - Skill 17 | .NET 9
using Microsoft.Extensions.Logging;
using XIIGen.Core.Base;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Services.CodeGen;

public class CodeGeneratorService : MicroserviceBase, IStepExecutor
{
    public string NodeTypeName => "CodeGenerator";

    public CodeGeneratorService(IDatabaseService db, IQueueService queue, ILogger<CodeGeneratorService> logger)
        : base(db, queue, logger) { ServiceName = "code-generator"; }

    public async Task<StepExecutionResult> ExecuteAsync(StepExecutionContext context, CancellationToken ct = default)
    {
        try
        {
            var aiOutput = context.Input?.ToString() ?? "";
            var lang = context.Configuration.TryGetValue("language", out var l) ? l.ToString() : "csharp";
            var framework = context.Configuration.TryGetValue("framework", out var f) ? f.ToString() : "dotnet9";

            // Extract code blocks from AI output
            var codeBlocks = ExtractCodeBlocks(aiOutput);

            // Generate project structure
            var project = new GeneratedProject
            {
                ProjectName = context.Configuration.TryGetValue("projectName", out var pn) ? pn.ToString() : "Generated",
                Language = lang, Framework = framework,
                Files = codeBlocks.Select((code, i) => new GeneratedFile
                {
                    FileName = $"Generated_{i}.{GetExtension(lang)}",
                    Content = code, Language = lang
                }).ToList()
            };

            // Store generated code
            await StoreDocumentAsync("generated-code", context.TraceId, project, ct: ct);
            return StepExecutionResult.Ok(project, new() { ["fileCount"] = project.Files.Count, ["language"] = lang });
        }
        catch (Exception ex) { return StepExecutionResult.Fail(ex.Message); }
    }

    private static List<string> ExtractCodeBlocks(string text)
    {
        var blocks = new List<string>();
        var lines = text.Split('\n');
        var inBlock = false; var current = new System.Text.StringBuilder();

        foreach (var line in lines)
        {
            if (line.TrimStart().StartsWith("```") && !inBlock) { inBlock = true; continue; }
            if (line.TrimStart().StartsWith("```") && inBlock) { blocks.Add(current.ToString()); current.Clear(); inBlock = false; continue; }
            if (inBlock) current.AppendLine(line);
        }
        if (blocks.Count == 0 && text.Length > 0) blocks.Add(text);
        return blocks;
    }

    private static string GetExtension(string lang) => lang.ToLower() switch
    {
        "csharp" or "c#" => "cs", "typescript" or "ts" => "ts", "javascript" or "js" => "js",
        "python" => "py", "java" => "java", "go" => "go", "rust" => "rs", _ => "txt"
    };
}

public class GeneratedProject
{
    public string ProjectName { get; set; }
    public string Language { get; set; }
    public string Framework { get; set; }
    public List<GeneratedFile> Files { get; set; } = [];
}

public class GeneratedFile
{
    public string FileName { get; set; }
    public string Content { get; set; }
    public string Language { get; set; }
}
