// Skill 17: Code Generator — Rust | Tera templates + std::fs
use std::collections::HashMap;
use serde::{Deserialize, Serialize};
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum TechStack { DotNet, NodeJs, Python, Java, Rust, PHP }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CodeUnit { pub file_name: String, pub content: String, pub language: String, pub relative_path: String, pub is_entry_point: bool }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProjectTemplate { pub stack: TechStack, pub name: String, pub folders: Vec<String>, pub boilerplate: HashMap<String, String>, pub configs: HashMap<String, String> }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GenerationPlan { pub plan_id: String, pub project_name: String, pub stack: TechStack, pub template: ProjectTemplate, pub units: Vec<CodeUnit>, pub variables: HashMap<String, String> }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GenerationResult { pub plan_id: String, pub project_name: String, pub files_generated: usize, pub files: HashMap<String, String>, pub syntax_valid: bool, pub warnings: Vec<String> }

fn get_templates() -> HashMap<TechStack, ProjectTemplate> {
    let mut m = HashMap::new();
    m.insert(TechStack::DotNet, ProjectTemplate { stack: TechStack::DotNet, name: "dotnet9".into(),
        folders: vec!["src".into(), "tests".into()],
        boilerplate: HashMap::from([("{{ProjectName}}.csproj".into(), "<Project Sdk=\"Microsoft.NET.Sdk.Web\"><PropertyGroup><TargetFramework>net9.0</TargetFramework></PropertyGroup></Project>".into())]),
        configs: HashMap::new() });
    m.insert(TechStack::NodeJs, ProjectTemplate { stack: TechStack::NodeJs, name: "nodejs".into(),
        folders: vec!["src".into(), "tests".into()],
        boilerplate: HashMap::from([("package.json".into(), r#"{ "name": "{{projectName}}", "version": "1.0.0" }"#.into())]),
        configs: HashMap::from([("tsconfig.json".into(), r#"{ "compilerOptions": { "strict": true } }"#.into())]) });
    m.insert(TechStack::Rust, ProjectTemplate { stack: TechStack::Rust, name: "rust".into(),
        folders: vec!["src".into(), "tests".into()],
        boilerplate: HashMap::from([("Cargo.toml".into(), "[package]\nname = \"{{projectName}}\"".into())]),
        configs: HashMap::new() });
    m
}

fn sub_vars(text: &str, vars: &HashMap<String, String>) -> String {
    let mut result = text.to_string();
    for (k, v) in vars { result = result.replace(&format!("{{{{{}}}}}", k), v); }
    result
}

fn validate_syntax(code: &str) -> bool {
    let mut stack = Vec::new();
    for ch in code.chars() {
        match ch { '(' | '[' | '{' => stack.push(ch), ')' => { if stack.pop() != Some('(') { return false; } },
            ']' => { if stack.pop() != Some('[') { return false; } }, '}' => { if stack.pop() != Some('{') { return false; } }, _ => {} }
    }
    stack.is_empty()
}

pub fn create_plan(project_name: &str, stack: TechStack, units: Vec<CodeUnit>, variables: Option<HashMap<String, String>>) -> GenerationPlan {
    let templates = get_templates();
    let template = templates.get(&stack).cloned().unwrap_or_else(|| templates[&TechStack::Rust].clone());
    let mut vars = variables.unwrap_or_default();
    vars.entry("ProjectName".into()).or_insert_with(|| project_name.into());
    vars.entry("projectName".into()).or_insert_with(|| project_name.to_lowercase().replace(' ', "-"));
    GenerationPlan { plan_id: Uuid::new_v4().to_string(), project_name: project_name.into(), stack, template, units, variables: vars }
}

pub fn generate_project(plan: &GenerationPlan) -> GenerationResult {
    let mut files = HashMap::new();
    let mut warnings = Vec::new();
    for (p, c) in &plan.template.boilerplate { files.insert(sub_vars(p, &plan.variables), sub_vars(c, &plan.variables)); }
    for (p, c) in &plan.template.configs { files.insert(sub_vars(p, &plan.variables), sub_vars(c, &plan.variables)); }
    for u in &plan.units {
        let fp = if u.relative_path.is_empty() { u.file_name.clone() } else { format!("{}/{}", u.relative_path.trim_end_matches('/'), u.file_name) };
        files.insert(fp, sub_vars(&u.content, &plan.variables));
    }
    let mut syntax_valid = true;
    for u in &plan.units { if !validate_syntax(&u.content) { warnings.push(format!("Syntax: {}", u.file_name)); syntax_valid = false; } }
    GenerationResult { plan_id: plan.plan_id.clone(), project_name: plan.project_name.clone(), files_generated: files.len(), files, syntax_valid, warnings }
}

// Axum routes: axum::Router::new().route("/api/codegen/plan", post(plan_handler)).route("/api/codegen/generate", post(gen_handler))
