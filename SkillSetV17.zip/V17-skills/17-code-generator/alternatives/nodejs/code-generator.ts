// Skill 17: Code Generator — Node.js/TypeScript | Handlebars + fs-extra
import Handlebars from "handlebars";
import path from "path";

type TechStack = "dotnet" | "nodejs" | "python" | "java" | "rust" | "php";
interface CodeUnit { fileName: string; content: string; language: string; relativePath: string; isEntryPoint?: boolean; }
interface ProjectTemplate { stack: TechStack; folders: string[]; boilerplate: Record<string, string>; configs: Record<string, string>; }
interface GenerationPlan { planId: string; projectName: string; stack: TechStack; template: ProjectTemplate; units: CodeUnit[]; variables: Record<string, string>; }
interface GenerationResult { planId: string; projectName: string; filesGenerated: number; files: Record<string, string>; syntaxValid: boolean; warnings: string[]; }

const TEMPLATES: Record<TechStack, ProjectTemplate> = {
  dotnet: { stack: "dotnet", folders: ["src", "src/Models", "src/Services", "tests"],
    boilerplate: { "{{ProjectName}}.csproj": '<Project Sdk="Microsoft.NET.Sdk.Web"><PropertyGroup><TargetFramework>net9.0</TargetFramework></PropertyGroup></Project>' }, configs: {} },
  nodejs: { stack: "nodejs", folders: ["src", "src/models", "src/services", "tests"],
    boilerplate: { "package.json": '{ "name": "{{projectName}}", "version": "1.0.0" }' },
    configs: { "tsconfig.json": '{ "compilerOptions": { "target": "ES2022", "strict": true } }' } },
  python: { stack: "python", folders: ["src", "src/models", "src/services", "tests"],
    boilerplate: { "pyproject.toml": '[project]\nname = "{{projectName}}"\nversion = "1.0.0"' }, configs: {} },
  java: { stack: "java", folders: ["src/main/java", "src/main/java/models", "src/test/java"],
    boilerplate: { "pom.xml": "<project><artifactId>{{projectName}}</artifactId></project>" }, configs: {} },
  rust: { stack: "rust", folders: ["src", "src/models", "tests"],
    boilerplate: { "Cargo.toml": '[package]\nname = "{{projectName}}"\nversion = "0.1.0"' }, configs: {} },
  php: { stack: "php", folders: ["src", "src/Models", "src/Services", "tests"],
    boilerplate: { "composer.json": '{ "name": "xiigen/{{projectName}}", "require": { "php": "^8.3" } }' }, configs: {} },
};

function subVars(text: string, vars: Record<string, string>): string {
  return Object.entries(vars).reduce((t, [k, v]) => t.replaceAll(`{{${k}}}`, v), text);
}

function extractCodeBlocks(text: string): string[] {
  const blocks: string[] = []; let inBlock = false; let cur = "";
  for (const line of text.split("\n")) {
    if (line.trimStart().startsWith("```") && !inBlock) { inBlock = true; continue; }
    if (line.trimStart().startsWith("```") && inBlock) { blocks.push(cur); cur = ""; inBlock = false; continue; }
    if (inBlock) cur += line + "\n";
  }
  return blocks.length ? blocks : text.length ? [text] : [];
}

function validateSyntax(code: string): boolean {
  const stack: string[] = []; const pairs: Record<string, string> = { ")": "(", "]": "[", "}": "{" };
  for (const ch of code) {
    if ("([{".includes(ch)) stack.push(ch);
    if (ch in pairs) { if (!stack.length || stack.pop() !== pairs[ch]) return false; }
  }
  return stack.length === 0;
}

export async function createPlan(projectName: string, stack: TechStack, units: CodeUnit[], variables?: Record<string, string>): Promise<GenerationPlan> {
  const vars = { ProjectName: projectName, projectName: projectName.toLowerCase().replace(/ /g, "-"), ...variables };
  return { planId: crypto.randomUUID(), projectName, stack, template: TEMPLATES[stack] ?? TEMPLATES.nodejs, units, variables: vars };
}

export async function generateProject(plan: GenerationPlan): Promise<GenerationResult> {
  const files: Record<string, string> = {}; const warnings: string[] = [];
  for (const [p, c] of Object.entries(plan.template.boilerplate)) files[subVars(p, plan.variables)] = subVars(c, plan.variables);
  for (const [p, c] of Object.entries(plan.template.configs)) files[subVars(p, plan.variables)] = subVars(c, plan.variables);
  for (const u of plan.units) {
    const fp = u.relativePath ? `${u.relativePath.replace(/\/$/, "")}/${u.fileName}` : u.fileName;
    files[fp] = subVars(u.content, plan.variables);
  }
  let syntaxValid = true;
  for (const u of plan.units) { if (!validateSyntax(u.content)) { warnings.push(`Syntax: ${u.fileName}`); syntaxValid = false; } }
  return { planId: plan.planId, projectName: plan.projectName, filesGenerated: Object.keys(files).length, files, syntaxValid, warnings };
}

export function registerRoutes(app: any) {
  app.post("/api/codegen/plan", async (req: any) => createPlan(req.body.projectName, req.body.stack, req.body.units, req.body.variables));
  app.post("/api/codegen/generate", async (req: any) => generateProject(req.body));
}
