<?php
// Skill 17: Code Generator — PHP 8.3 | Laravel Filesystem + enums
declare(strict_types=1);
namespace App\Services\CodeGen;

enum TechStack: string { case DotNet = 'dotnet'; case NodeJs = 'nodejs'; case Python = 'python'; case Java = 'java'; case Rust = 'rust'; case PHP = 'php'; }

readonly class CodeUnit { public function __construct(public string $fileName, public string $content, public string $language, public string $relativePath, public bool $isEntryPoint = false) {} }
readonly class ProjectTemplate { public function __construct(public TechStack $stack, public string $name, public array $folders, public array $boilerplate, public array $configs) {} }
readonly class GenerationPlan { public function __construct(public string $planId, public string $projectName, public TechStack $stack, public ProjectTemplate $template, public array $units, public array $variables) {} }
readonly class GenerationResult { public function __construct(public string $planId, public string $projectName, public int $filesGenerated, public array $files, public bool $syntaxValid, public array $warnings) {} }

class CodeGeneratorService
{
    private array $templates;

    public function __construct() { $this->initTemplates(); }

    private function initTemplates(): void
    {
        $this->templates = [
            TechStack::DotNet->value => new ProjectTemplate(TechStack::DotNet, 'dotnet9', ['src', 'tests'],
                ['{{ProjectName}}.csproj' => '<Project Sdk="Microsoft.NET.Sdk.Web"><PropertyGroup><TargetFramework>net9.0</TargetFramework></PropertyGroup></Project>'], []),
            TechStack::NodeJs->value => new ProjectTemplate(TechStack::NodeJs, 'nodejs', ['src', 'tests'],
                ['package.json' => '{ "name": "{{projectName}}", "version": "1.0.0" }'], ['tsconfig.json' => '{ "compilerOptions": { "strict": true } }']),
            TechStack::Python->value => new ProjectTemplate(TechStack::Python, 'python', ['src', 'tests'],
                ['pyproject.toml' => '[project]\nname = "{{projectName}}"'], []),
            TechStack::PHP->value => new ProjectTemplate(TechStack::PHP, 'php', ['src', 'tests'],
                ['composer.json' => '{ "name": "xiigen/{{projectName}}" }'], []),
        ];
    }

    public function createPlan(string $projectName, TechStack $stack, array $units, array $variables = []): GenerationPlan
    {
        $vars = array_merge(['ProjectName' => $projectName, 'projectName' => strtolower(str_replace(' ', '-', $projectName))], $variables);
        $template = $this->templates[$stack->value] ?? $this->templates[TechStack::PHP->value];
        return new GenerationPlan(uniqid('plan-'), $projectName, $stack, $template, $units, $vars);
    }

    public function generateProject(GenerationPlan $plan): GenerationResult
    {
        $files = []; $warnings = [];
        foreach ($plan->template->boilerplate as $p => $c) { $files[$this->subVars($p, $plan->variables)] = $this->subVars($c, $plan->variables); }
        foreach ($plan->template->configs as $p => $c) { $files[$this->subVars($p, $plan->variables)] = $this->subVars($c, $plan->variables); }
        foreach ($plan->units as $u) {
            $fp = $u->relativePath ? rtrim($u->relativePath, '/') . '/' . $u->fileName : $u->fileName;
            $files[$fp] = $this->subVars($u->content, $plan->variables);
        }
        $valid = true;
        foreach ($plan->units as $u) { if (!$this->validateSyntax($u->content)) { $warnings[] = "Syntax: {$u->fileName}"; $valid = false; } }
        return new GenerationResult($plan->planId, $plan->projectName, count($files), $files, $valid, $warnings);
    }

    private function subVars(string $text, array $vars): string
    { foreach ($vars as $k => $v) { $text = str_replace("{{{$k}}}", $v, $text); } return $text; }

    private function validateSyntax(string $code): bool
    {
        $stack = []; $pairs = [')' => '(', ']' => '[', '}' => '{'];
        foreach (str_split($code) as $ch) {
            if (in_array($ch, ['(', '[', '{'])) $stack[] = $ch;
            if (isset($pairs[$ch])) { if (empty($stack) || array_pop($stack) !== $pairs[$ch]) return false; }
        }
        return empty($stack);
    }
}
// Laravel: Route::post('/api/codegen/plan', [CodeGenController::class, 'plan']);
