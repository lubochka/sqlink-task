# Skill 17: Code Generator — Python 3.12 | Jinja2 + pathlib
from dataclasses import dataclass, field
from enum import Enum
from uuid import uuid4
import re

class TechStack(Enum):
    DOTNET = "dotnet"; NODEJS = "nodejs"; PYTHON = "python"; JAVA = "java"; RUST = "rust"; PHP = "php"

@dataclass
class CodeUnit:
    file_name: str; content: str; language: str; relative_path: str; is_entry_point: bool = False

@dataclass
class ProjectTemplate:
    stack: TechStack; name: str; folders: list[str]; boilerplate: dict[str, str]; configs: dict[str, str]

@dataclass
class GenerationPlan:
    plan_id: str; project_name: str; stack: TechStack; template: ProjectTemplate
    units: list[CodeUnit]; variables: dict[str, str]

@dataclass
class GenerationResult:
    plan_id: str; project_name: str; files_generated: int
    files: dict[str, str]; syntax_valid: bool; warnings: list[str]

TEMPLATES = {
    TechStack.DOTNET: ProjectTemplate(TechStack.DOTNET, "dotnet9", ["src", "src/Models", "tests"],
        {"{{ProjectName}}.csproj": '<Project Sdk="Microsoft.NET.Sdk.Web"><PropertyGroup><TargetFramework>net9.0</TargetFramework></PropertyGroup></Project>'}, {}),
    TechStack.NODEJS: ProjectTemplate(TechStack.NODEJS, "nodejs", ["src", "src/models", "tests"],
        {"package.json": '{ "name": "{{projectName}}", "version": "1.0.0" }'}, {"tsconfig.json": '{ "compilerOptions": { "strict": true } }'}),
    TechStack.PYTHON: ProjectTemplate(TechStack.PYTHON, "python", ["src", "src/models", "tests"],
        {"pyproject.toml": '[project]\nname = "{{projectName}}"'}, {}),
    TechStack.JAVA: ProjectTemplate(TechStack.JAVA, "java", ["src/main/java", "src/test/java"],
        {"pom.xml": "<project><artifactId>{{projectName}}</artifactId></project>"}, {}),
    TechStack.RUST: ProjectTemplate(TechStack.RUST, "rust", ["src", "tests"],
        {"Cargo.toml": '[package]\nname = "{{projectName}}"'}, {}),
    TechStack.PHP: ProjectTemplate(TechStack.PHP, "php", ["src", "src/Models", "tests"],
        {"composer.json": '{ "name": "xiigen/{{projectName}}" }'}, {}),
}

def _sub_vars(text: str, variables: dict[str, str]) -> str:
    for k, v in variables.items(): text = text.replace(f"{{{{{k}}}}}", v)
    return text

def _extract_code_blocks(text: str) -> list[str]:
    blocks, in_block, current = [], False, []
    for line in text.split("\n"):
        if line.strip().startswith("```") and not in_block: in_block = True; continue
        if line.strip().startswith("```") and in_block: blocks.append("\n".join(current)); current = []; in_block = False; continue
        if in_block: current.append(line)
    return blocks if blocks else ([text] if text else [])

def _validate_syntax(code: str) -> bool:
    stack, pairs = [], {")": "(", "]": "[", "}": "{"}
    for ch in code:
        if ch in "([{": stack.append(ch)
        if ch in pairs:
            if not stack or stack.pop() != pairs[ch]: return False
    return len(stack) == 0

async def create_plan(project_name: str, stack: TechStack, units: list[CodeUnit], variables: dict[str, str] | None = None) -> GenerationPlan:
    v = {"ProjectName": project_name, "projectName": project_name.lower().replace(" ", "-"), **(variables or {})}
    return GenerationPlan(str(uuid4()), project_name, stack, TEMPLATES.get(stack, TEMPLATES[TechStack.PYTHON]), units, v)

async def generate_project(plan: GenerationPlan) -> GenerationResult:
    files, warnings = {}, []
    for p, c in plan.template.boilerplate.items(): files[_sub_vars(p, plan.variables)] = _sub_vars(c, plan.variables)
    for p, c in plan.template.configs.items(): files[_sub_vars(p, plan.variables)] = _sub_vars(c, plan.variables)
    for u in plan.units:
        fp = f"{u.relative_path.rstrip('/')}/{u.file_name}" if u.relative_path else u.file_name
        files[fp] = _sub_vars(u.content, plan.variables)
    syntax_valid = True
    for u in plan.units:
        if not _validate_syntax(u.content): warnings.append(f"Syntax: {u.file_name}"); syntax_valid = False
    return GenerationResult(plan.plan_id, plan.project_name, len(files), files, syntax_valid, warnings)

# FastAPI routes
def register_routes(app):
    from fastapi import APIRouter
    router = APIRouter(prefix="/api/codegen")
    @router.post("/plan")
    async def plan(req: dict): return await create_plan(req["projectName"], TechStack(req["stack"]), [CodeUnit(**u) for u in req["units"]])
    @router.post("/generate")
    async def gen(req: dict): return await generate_project(GenerationPlan(**req))
    app.include_router(router)
