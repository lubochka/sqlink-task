// Skill 17: Code Generator — Java 21 | FreeMarker + nio.file + records
package com.xiigen.codegen;

import java.util.*;
import java.util.stream.*;

public class CodeGeneratorService {

    public enum TechStack { DOTNET, NODEJS, PYTHON, JAVA, RUST, PHP }

    public record CodeUnit(String fileName, String content, String language, String relativePath, boolean isEntryPoint) {}
    public record ProjectTemplate(TechStack stack, String name, List<String> folders, Map<String, String> boilerplate, Map<String, String> configs) {}
    public record GenerationPlan(String planId, String projectName, TechStack stack, ProjectTemplate template, List<CodeUnit> units, Map<String, String> variables) {}
    public record GenerationResult(String planId, String projectName, int filesGenerated, Map<String, String> files, boolean syntaxValid, List<String> warnings) {}

    private static final Map<TechStack, ProjectTemplate> TEMPLATES = Map.of(
        TechStack.DOTNET, new ProjectTemplate(TechStack.DOTNET, "dotnet9", List.of("src", "src/Models", "tests"),
            Map.of("{{ProjectName}}.csproj", "<Project Sdk=\"Microsoft.NET.Sdk.Web\"><PropertyGroup><TargetFramework>net9.0</TargetFramework></PropertyGroup></Project>"), Map.of()),
        TechStack.NODEJS, new ProjectTemplate(TechStack.NODEJS, "nodejs", List.of("src", "src/models", "tests"),
            Map.of("package.json", "{ \"name\": \"{{projectName}}\", \"version\": \"1.0.0\" }"), Map.of("tsconfig.json", "{ \"compilerOptions\": { \"strict\": true } }")),
        TechStack.PYTHON, new ProjectTemplate(TechStack.PYTHON, "python", List.of("src", "tests"),
            Map.of("pyproject.toml", "[project]\nname = \"{{projectName}}\""), Map.of()),
        TechStack.JAVA, new ProjectTemplate(TechStack.JAVA, "java", List.of("src/main/java", "src/test/java"),
            Map.of("pom.xml", "<project><artifactId>{{projectName}}</artifactId></project>"), Map.of()),
        TechStack.RUST, new ProjectTemplate(TechStack.RUST, "rust", List.of("src", "tests"),
            Map.of("Cargo.toml", "[package]\nname = \"{{projectName}}\""), Map.of()),
        TechStack.PHP, new ProjectTemplate(TechStack.PHP, "php", List.of("src", "tests"),
            Map.of("composer.json", "{ \"name\": \"xiigen/{{projectName}}\" }"), Map.of())
    );

    private static String subVars(String text, Map<String, String> vars) {
        for (var e : vars.entrySet()) text = text.replace("{{" + e.getKey() + "}}", e.getValue());
        return text;
    }

    private static boolean validateSyntax(String code) {
        var stack = new ArrayDeque<Character>();
        var pairs = Map.of(')', '(', ']', '[', '}', '{');
        for (char ch : code.toCharArray()) {
            if ("([{".indexOf(ch) >= 0) stack.push(ch);
            if (pairs.containsKey(ch)) { if (stack.isEmpty() || !stack.pop().equals(pairs.get(ch))) return false; }
        }
        return stack.isEmpty();
    }

    public GenerationPlan createPlan(String projectName, TechStack stack, List<CodeUnit> units, Map<String, String> variables) {
        var vars = new HashMap<>(variables != null ? variables : Map.of());
        vars.putIfAbsent("ProjectName", projectName);
        vars.putIfAbsent("projectName", projectName.toLowerCase().replace(" ", "-"));
        return new GenerationPlan(UUID.randomUUID().toString(), projectName, stack, TEMPLATES.getOrDefault(stack, TEMPLATES.get(TechStack.JAVA)), units, vars);
    }

    public GenerationResult generateProject(GenerationPlan plan) {
        var files = new LinkedHashMap<String, String>();
        var warnings = new ArrayList<String>();
        plan.template().boilerplate().forEach((p, c) -> files.put(subVars(p, plan.variables()), subVars(c, plan.variables())));
        plan.template().configs().forEach((p, c) -> files.put(subVars(p, plan.variables()), subVars(c, plan.variables())));
        for (var u : plan.units()) {
            var fp = u.relativePath().isEmpty() ? u.fileName() : u.relativePath().replaceAll("/$", "") + "/" + u.fileName();
            files.put(fp, subVars(u.content(), plan.variables()));
        }
        boolean valid = true;
        for (var u : plan.units()) { if (!validateSyntax(u.content())) { warnings.add("Syntax: " + u.fileName()); valid = false; } }
        return new GenerationResult(plan.planId(), plan.projectName(), files.size(), files, valid, warnings);
    }

    // Spring Boot Controller
    // @RestController @RequestMapping("/api/codegen")
    // @PostMapping("/plan") public GenerationPlan plan(@RequestBody PlanRequest req) { ... }
    // @PostMapping("/generate") public GenerationResult generate(@RequestBody GenerationPlan plan) { ... }
}
