// XIIGen.Core/Interfaces/IRagService.cs | .NET 9
// Generic RAG interface - works with ANY vector/graph backend.
// Key: AI-driven context planning before each AI call,
// and AI-driven storage planning after each execution.

using XIIGen.Core.Models;

namespace XIIGen.Core.Interfaces;

/// <summary>
/// Generic RAG (Retrieval-Augmented Generation) interface.
/// Implementations: Azure AI Search, Pinecone, Neo4j, CosmosDB, Elasticsearch kNN, Gremlin.
/// </summary>
public interface IRagService
{
    string ProviderName { get; }
    RagCapabilities Capabilities { get; }

    // ─── Vector Operations ───────────────────────────────
    Task<DataProcessResult<string>> StoreEmbeddingAsync(
        string collection, string id, float[] embedding,
        Dictionary<string, object> metadata = null,
        CancellationToken ct = default);

    Task<DataProcessResult<List<RagSearchResult>>> VectorSearchAsync(
        string collection, float[] queryEmbedding,
        int topK = 10, float minScore = 0.0f,
        Dictionary<string, object> filters = null,
        CancellationToken ct = default);

    Task<DataProcessResult<List<RagSearchResult>>> HybridSearchAsync(
        string collection, string textQuery, float[] queryEmbedding = null,
        int topK = 10, Dictionary<string, object> filters = null,
        CancellationToken ct = default);

    // ─── Graph Operations (for graph-capable backends) ───
    Task<DataProcessResult<string>> StoreNodeAsync(
        string label, string id, Dictionary<string, object> properties,
        CancellationToken ct = default);

    Task<DataProcessResult<string>> StoreEdgeAsync(
        string fromId, string toId, string edgeType,
        Dictionary<string, object> properties = null,
        CancellationToken ct = default);

    Task<DataProcessResult<List<RagGraphResult>>> TraverseAsync(
        string startNodeId, string edgeType = null,
        int maxDepth = 3, TraversalDirection direction = TraversalDirection.Outgoing,
        CancellationToken ct = default);

    Task<DataProcessResult<List<RagGraphResult>>> GraphQueryAsync(
        string query, Dictionary<string, object> parameters = null,
        CancellationToken ct = default);

    // ─── Document Chunking + Storage ─────────────────────
    Task<DataProcessResult<List<string>>> StoreDocumentChunksAsync(
        string collection, string documentId, string content,
        ChunkingOptions options = null,
        CancellationToken ct = default);

    // ─── Maintenance ─────────────────────────────────────
    Task<DataProcessResult<bool>> DeleteAsync(string collection, string id, CancellationToken ct = default);
    Task<DataProcessResult<bool>> CollectionExistsAsync(string collection, CancellationToken ct = default);
    Task<DataProcessResult<bool>> CreateCollectionAsync(string collection, CollectionSchema schema, CancellationToken ct = default);
}

/// <summary>
/// AI-driven RAG Context Planner. Before each AI call, determines what context
/// to retrieve. After each execution, determines what to store.
/// </summary>
public interface IRagContextPlanner
{
    /// <summary>
    /// Before an AI call: uses a planning AI to determine which RAG queries
    /// to run to build the best context for the upcoming step.
    /// Returns a structured retrieval plan.
    /// </summary>
    Task<RagRetrievalPlan> PlanRetrievalAsync(
        RagPlanningInput input, CancellationToken ct = default);

    /// <summary>
    /// Executes a retrieval plan against one or more RAG backends.
    /// Returns aggregated context ready for prompt injection.
    /// </summary>
    Task<RagContext> ExecuteRetrievalPlanAsync(
        RagRetrievalPlan plan, CancellationToken ct = default);

    /// <summary>
    /// After an AI execution: uses a planning AI to determine what data
    /// to store in RAG (embeddings, graph nodes, metadata) and where.
    /// </summary>
    Task<RagStoragePlan> PlanStorageAsync(
        RagStoragePlanningInput input, CancellationToken ct = default);

    /// <summary>
    /// Executes a storage plan against one or more RAG backends.
    /// </summary>
    Task<DataProcessResult<bool>> ExecuteStoragePlanAsync(
        RagStoragePlan plan, CancellationToken ct = default);
}

/// <summary>
/// Embedding generation interface - bridges AI providers with RAG storage.
/// </summary>
public interface IEmbeddingService
{
    Task<float[]> GenerateEmbeddingAsync(string text, CancellationToken ct = default);
    Task<List<float[]>> GenerateBatchEmbeddingsAsync(List<string> texts, CancellationToken ct = default);
    int EmbeddingDimensions { get; }
}

// ─── Models ──────────────────────────────────────────────

public class RagCapabilities
{
    public bool SupportsVectorSearch { get; set; }
    public bool SupportsHybridSearch { get; set; }
    public bool SupportsGraphTraversal { get; set; }
    public bool SupportsGraphQuery { get; set; }
    public bool SupportsDocumentChunking { get; set; }
    public int MaxEmbeddingDimensions { get; set; }
}

public class RagSearchResult
{
    public string Id { get; set; }
    public float Score { get; set; }
    public Dictionary<string, object> Metadata { get; set; } = [];
    public string Content { get; set; }
    public string Collection { get; set; }
}

public class RagGraphResult
{
    public string NodeId { get; set; }
    public string Label { get; set; }
    public Dictionary<string, object> Properties { get; set; } = [];
    public List<RagGraphEdge> Edges { get; set; } = [];
    public int Depth { get; set; }
}

public class RagGraphEdge
{
    public string FromId { get; set; }
    public string ToId { get; set; }
    public string EdgeType { get; set; }
    public Dictionary<string, object> Properties { get; set; } = [];
}

public enum TraversalDirection { Outgoing, Incoming, Both }

public class ChunkingOptions
{
    public int ChunkSize { get; set; } = 512;
    public int ChunkOverlap { get; set; } = 50;
    public string Strategy { get; set; } = "sentence"; // sentence, paragraph, fixed, semantic
}

public class CollectionSchema
{
    public int EmbeddingDimensions { get; set; } = 1536;
    public string DistanceMetric { get; set; } = "cosine"; // cosine, dotProduct, euclidean
    public Dictionary<string, string> MetadataFields { get; set; } = [];
}

// ─── Planning Models ─────────────────────────────────────

public class RagPlanningInput
{
    public string TraceId { get; set; }
    public string StepId { get; set; }
    public string StepType { get; set; }
    public object StepInput { get; set; }
    public Dictionary<string, object> FlowContext { get; set; } = [];
    public List<string> AvailableCollections { get; set; } = [];
    public List<string> AvailableGraphLabels { get; set; } = [];
}

public class RagRetrievalPlan
{
    public string PlanId { get; set; } = Guid.NewGuid().ToString();
    public List<RagRetrievalStep> Steps { get; set; } = [];
    public string Reasoning { get; set; } // AI's explanation of why these retrievals
}

public class RagRetrievalStep
{
    public string StepId { get; set; } = Guid.NewGuid().ToString();
    public RagRetrievalType Type { get; set; }
    public string Collection { get; set; }
    public string Query { get; set; }          // Text query for hybrid search
    public string GraphQuery { get; set; }     // Cypher/Gremlin for graph traversal
    public string StartNodeId { get; set; }    // For graph traversal
    public string EdgeType { get; set; }       // For graph traversal
    public int TopK { get; set; } = 5;
    public float MinScore { get; set; } = 0.7f;
    public Dictionary<string, object> Filters { get; set; } = [];
    public int Priority { get; set; } = 1;     // Higher = more important
}

public enum RagRetrievalType { VectorSearch, HybridSearch, GraphTraversal, GraphQuery, KeywordSearch }

public class RagContext
{
    public string PlanId { get; set; }
    public List<RagContextItem> Items { get; set; } = [];
    public int TotalTokensEstimate { get; set; }
    public string FormattedForPrompt { get; set; } // Pre-formatted XML for prompt injection
}

public class RagContextItem
{
    public string Source { get; set; }       // Which retrieval step produced this
    public string Collection { get; set; }
    public float Relevance { get; set; }
    public string Content { get; set; }
    public Dictionary<string, object> Metadata { get; set; } = [];
}

public class RagStoragePlanningInput
{
    public string TraceId { get; set; }
    public string StepId { get; set; }
    public string StepType { get; set; }
    public object StepOutput { get; set; }
    public object StepInput { get; set; }
    public string FeedbackRating { get; set; }
    public string FeedbackText { get; set; }
    public RagContext RetrievedContext { get; set; } // What context was used
}

public class RagStoragePlan
{
    public string PlanId { get; set; } = Guid.NewGuid().ToString();
    public List<RagStorageStep> Steps { get; set; } = [];
    public string Reasoning { get; set; }
}

public class RagStorageStep
{
    public RagStorageType Type { get; set; }
    public string Collection { get; set; }
    public string DocumentId { get; set; }
    public string Content { get; set; }        // Text to embed
    public Dictionary<string, object> Metadata { get; set; } = [];
    public string NodeLabel { get; set; }      // For graph nodes
    public string FromNodeId { get; set; }     // For graph edges
    public string ToNodeId { get; set; }
    public string EdgeType { get; set; }
    public ChunkingOptions ChunkingOptions { get; set; }
}

public enum RagStorageType { Embedding, GraphNode, GraphEdge, DocumentChunks, Metadata }
