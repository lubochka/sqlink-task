// XIIGen.Core/Extensions/RagServiceCollectionExtensions.cs | .NET 9
// DI registration for all RAG backends + alternatives

using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using XIIGen.Core.Interfaces;

namespace XIIGen.Core.Extensions;

public static class RagServiceCollectionExtensions
{
    /// <summary>
    /// Registers RAG services based on configuration.
    /// Supports multiple backends simultaneously (e.g., Neo4j for graph + Pinecone for vectors).
    ///
    /// Config example:
    /// "Rag": {
    ///   "Backends": [
    ///     { "Type": "neo4j", "Uri": "bolt://localhost:7687", "User": "neo4j", "Password": "..." },
    ///     { "Type": "azure-ai-search", "Endpoint": "https://...", "ApiKey": "..." },
    ///     { "Type": "pinecone", "Host": "https://...", "ApiKey": "..." },
    ///     { "Type": "cosmosdb-graph", "Hostname": "...", "Database": "...", "Container": "...", "AuthKey": "..." },
    ///     { "Type": "elasticsearch-knn", "Uri": "http://localhost:9200" }
    ///   ],
    ///   "Embeddings": { "Provider": "openai", "Model": "text-embedding-3-small" },
    ///   "Planner": { "AiProvider": "claude" }
    /// }
    /// </summary>
    public static IServiceCollection AddXIIGenRag(this IServiceCollection services, IConfiguration config)
    {
        var ragConfig = config.GetSection("Rag");

        // Register RAG backends
        var backends = ragConfig.GetSection("Backends").GetChildren();
        foreach (var backend in backends)
        {
            var type = backend["Type"]?.ToLower();
            switch (type)
            {
                case "neo4j":
                    services.AddSingleton<IRagService>(sp =>
                        new XIIGen.Rag.Neo4j.Neo4jRagService(
                            backend["Uri"], backend["User"], backend["Password"]));
                    break;

                case "azure-ai-search":
                    services.AddSingleton<IRagService>(sp =>
                        new XIIGen.Rag.AzureAISearch.AzureAISearchRagService(
                            backend["Endpoint"], backend["ApiKey"]));
                    break;

                case "pinecone":
                    services.AddSingleton<IRagService>(sp =>
                        new XIIGen.Rag.Pinecone.PineconeRagService(
                            backend["Host"], backend["ApiKey"]));
                    break;

                case "cosmosdb-graph":
                    services.AddSingleton<IRagService>(sp =>
                        new XIIGen.Rag.CosmosGraph.CosmosDbGraphRagService(
                            backend["Hostname"], backend["Database"],
                            backend["Container"], backend["AuthKey"]));
                    break;

                case "elasticsearch-knn":
                    services.AddSingleton<IRagService>(sp =>
                        new XIIGen.Rag.ElasticsearchKnn.ElasticsearchKnnRagService(
                            backend["Uri"]));
                    break;
            }
        }

        // Register embedding service
        services.AddSingleton<IEmbeddingService, OpenAiEmbeddingService>(sp =>
        {
            var embConfig = ragConfig.GetSection("Embeddings");
            return new OpenAiEmbeddingService(
                embConfig["ApiKey"] ?? config["AiProviders:OpenAi:ApiKey"],
                embConfig["Model"] ?? "text-embedding-3-small");
        });

        // Register RAG context planner
        services.AddSingleton<IRagContextPlanner, XIIGen.Services.RagPlanner.RagContextPlanner>();

        return services;
    }

    /// <summary>
    /// Registers queue service based on configuration.
    /// Config: "Queue": { "Type": "redis|kafka|sqs|rabbitmq|azure-servicebus", ... }
    /// </summary>
    public static IServiceCollection AddXIIGenQueue(this IServiceCollection services, IConfiguration config)
    {
        var queueConfig = config.GetSection("Queue");
        var type = queueConfig["Type"]?.ToLower();

        switch (type)
        {
            case "kafka":
                services.AddSingleton<IQueueService>(sp =>
                    new XIIGen.Infrastructure.Kafka.KafkaQueueService(
                        queueConfig["BootstrapServers"], queueConfig["GroupId"] ?? "xiigen-workers"));
                break;
            case "sqs":
                services.AddSingleton<IQueueService>(sp =>
                    new XIIGen.Infrastructure.Sqs.SqsQueueService(
                        queueConfig["Region"] ?? "us-east-1", queueConfig["QueuePrefix"] ?? "xiigen-"));
                break;
            case "rabbitmq":
                services.AddSingleton<IQueueService>(sp =>
                    new XIIGen.Infrastructure.RabbitMq.RabbitMqQueueService(
                        queueConfig["ConnectionString"] ?? "amqp://guest:guest@localhost:5672"));
                break;
            case "azure-servicebus":
                services.AddSingleton<IQueueService>(sp =>
                    new XIIGen.Infrastructure.AzureServiceBus.AzureServiceBusQueueService(
                        queueConfig["ConnectionString"]));
                break;
            default: // redis (default)
                services.AddSingleton<IQueueService>(sp =>
                    new XIIGen.Infrastructure.Redis.RedisQueueService(
                        queueConfig["ConnectionString"] ?? "localhost:6379"));
                break;
        }
        return services;
    }

    /// <summary>
    /// Registers database service based on configuration.
    /// Config: "Database": { "Type": "elasticsearch|mongodb|prisma|redis|azure-ai-search|neo4j", ... }
    /// </summary>
    public static IServiceCollection AddXIIGenDatabase(this IServiceCollection services, IConfiguration config)
    {
        var dbConfig = config.GetSection("Database");
        var type = dbConfig["Type"]?.ToLower();

        switch (type)
        {
            case "mongodb":
                services.AddSingleton<IDatabaseService>(sp =>
                    new XIIGen.Infrastructure.MongoDb.MongoDatabaseService(
                        dbConfig["ConnectionString"], sp.GetService<IObjectProcessor>()));
                break;
            case "redis":
                services.AddSingleton<IDatabaseService>(sp =>
                    new XIIGen.Infrastructure.RedisDb.RedisDatabaseService(
                        dbConfig["ConnectionString"] ?? "localhost:6379"));
                break;
            case "azure-ai-search":
                services.AddSingleton<IDatabaseService>(sp =>
                    new XIIGen.Infrastructure.AzureAISearch.AzureAISearchDatabaseService(
                        dbConfig["Endpoint"], dbConfig["ApiKey"]));
                break;
            case "neo4j":
                services.AddSingleton<IDatabaseService>(sp =>
                    new XIIGen.Infrastructure.GraphAI.Neo4jDatabaseService(
                        dbConfig["Uri"], dbConfig["User"], dbConfig["Password"],
                        sp.GetService<IObjectProcessor>()));
                break;
            default: // elasticsearch (default)
                services.AddSingleton<IDatabaseService>(sp =>
                    new XIIGen.Infrastructure.Elasticsearch.ElasticsearchDatabaseService(
                        dbConfig["Uri"] ?? "http://localhost:9200",
                        sp.GetService<IObjectProcessor>()));
                break;
        }
        return services;
    }
}

/// <summary>
/// Embedding service using OpenAI's API (also works with Azure OpenAI).
/// </summary>
public class OpenAiEmbeddingService : IEmbeddingService
{
    private readonly HttpClient _http;
    private readonly string _model;
    public int EmbeddingDimensions { get; }

    public OpenAiEmbeddingService(string apiKey, string model = "text-embedding-3-small")
    {
        _model = model;
        EmbeddingDimensions = model.Contains("3-large") ? 3072 : 1536;
        _http = new HttpClient { BaseAddress = new Uri("https://api.openai.com/v1/") };
        _http.DefaultRequestHeaders.Add("Authorization", $"Bearer {apiKey}");
    }

    public async Task<float[]> GenerateEmbeddingAsync(string text, CancellationToken ct = default)
    {
        var body = new { input = text, model = _model };
        var resp = await _http.PostAsJsonAsync("embeddings", body, ct);
        resp.EnsureSuccessStatusCode();
        var json = await resp.Content.ReadFromJsonAsync<System.Text.Json.JsonElement>(ct);
        var embedding = json.GetProperty("data")[0].GetProperty("embedding");
        return embedding.EnumerateArray().Select(e => e.GetSingle()).ToArray();
    }

    public async Task<List<float[]>> GenerateBatchEmbeddingsAsync(List<string> texts, CancellationToken ct = default)
    {
        var body = new { input = texts, model = _model };
        var resp = await _http.PostAsJsonAsync("embeddings", body, ct);
        resp.EnsureSuccessStatusCode();
        var json = await resp.Content.ReadFromJsonAsync<System.Text.Json.JsonElement>(ct);
        return json.GetProperty("data").EnumerateArray()
            .OrderBy(d => d.GetProperty("index").GetInt32())
            .Select(d => d.GetProperty("embedding").EnumerateArray().Select(e => e.GetSingle()).ToArray())
            .ToList();
    }
}
