---
name: rag-interfaces
description: Generic RAG contracts for vector, graph, and hybrid backends. Swap Neo4j/Pinecone/Azure AI Search/CosmosDB/LightRAG/etc. via DI with zero code changes.
triggers: rag interface, vector search, graph rag, hybrid search, embedding store, knowledge graph, rag provider, swap rag backend
dependencies: [01-core-interfaces]
layer: L0-Foundation
genie-dna: All RAG operations accept dynamic documents via ObjectProcessor. StoreEmbeddingAsync uses ParseObjectAlternative for metadata. VectorSearchAsync uses BuildSearchFilter for filtering.
---

# Skill 00a: RAG Interfaces
## Generic RAG Contracts for Vector + Graph Backends

**Dependencies:** 01 (Core Interfaces)
**Layer:** L0: Foundation
**Phase:** 4 (Memory Library)

---

## Overview

RAG Interfaces defines the **universal contract** for all Retrieval-Augmented Generation backends in XIIGen. Whether you use Neo4j for graph traversal, Pinecone for vector similarity, Azure AI Search for hybrid queries, or a custom HybridRAG stack — every backend implements this single `IRagService` interface.

**Core principle (Genie DNA):** All RAG operations accept dynamic documents — no fixed embedding schemas. Metadata goes through `ObjectProcessor.ParseObjectAlternative()` before storage, and search filters use `BuildSearchFilter()` which automatically skips empty filter fields.

## When to Use

- Any time you store or retrieve AI context (embeddings, graph nodes, knowledge)
- When building a new RAG pipeline that needs to swap backends without code changes
- When the RAG Planner (00b) generates query plans — this is where they execute
- When the AI Context Service (16) fetches context for AI prompts

## Provider Comparison

| Provider | Vector | Graph | Hybrid | Managed | Best For |
|---|---|---|---|---|---|
| Neo4j | ✅ (v5+) | ✅ Best | ✅ | Cloud/Self | Knowledge graphs, relationships |
| Pinecone | ✅ Best | ❌ | ✅ Metadata | Cloud | Pure vector search, serverless |
| Azure AI Search | ✅ | ❌ | ✅ Best | Cloud | Enterprise, semantic ranking |
| CosmosDB Gremlin | ✅ (vCore) | ✅ | ✅ | Cloud | Azure-native, global dist |
| Elasticsearch kNN | ✅ | ❌ | ✅ | Both | Already in stack, log-scale |
| LightRAG | ✅ | ✅ | ✅ | Self | Budget, 80-90% fewer API calls |
| nano-graphrag | ✅ | ✅ | ✅ | Self | Full control, hackable |
| LlamaIndex | ✅ | ✅ | ✅ | Both | 160+ connectors |
| Graphlit | ✅ | ✅ | ✅ | SaaS | Zero-ops, auto-extraction |
| Memgraph | ❌ | ✅ | ❌ | Both | Real-time streaming, Kafka |

## Architecture

```
┌──────────────────────────────────────────────────────┐
│                   IRagService                         │
│  ┌─────────────────────────────────────────────────┐ │
│  │ Vector: Store / Search / HybridSearch           │ │
│  │ Graph:  StoreNode / StoreEdge / Traverse        │ │
│  │ Admin:  CreateCollection / CollectionExists      │ │
│  │ Lifecycle: DeleteAsync / HealthCheckAsync        │ │
│  └─────────────────────────────────────────────────┘ │
│         ▲           ▲            ▲           ▲       │
│    Neo4jRag    PineconeRag  AzureAIRag   ElasticRag  │
│    CosmosRag   LightRag    NanoGraphRag  ...         │
└──────────────────────────────────────────────────────┘
```

## Interface Contract

### IRagService
| Method | Purpose | Returns |
|--------|---------|---------|
| `StoreEmbeddingAsync` | Store vector embedding + dynamic metadata | `DataProcessResult<string>` (ID) |
| `VectorSearchAsync` | Similarity search by embedding vector | `DataProcessResult<List<RagSearchResult>>` |
| `HybridSearchAsync` | Combined text + vector + filter search | `DataProcessResult<List<RagSearchResult>>` |
| `StoreNodeAsync` | Store graph node with properties | `DataProcessResult<string>` |
| `StoreEdgeAsync` | Create relationship between nodes | `DataProcessResult<string>` |
| `TraverseAsync` | Graph traversal (BFS/DFS) from node | `DataProcessResult<List<GraphNode>>` |
| `DeleteAsync` | Remove embedding/node by ID | `DataProcessResult<bool>` |
| `CollectionExistsAsync` | Check if collection/index exists | `bool` |
| `CreateCollectionAsync` | Initialize with dimension/schema | `DataProcessResult<bool>` |
| `HealthCheckAsync` | Verify backend connectivity | `DataProcessResult<RagHealthStatus>` |

### Key Models
```csharp
public record RagCapabilities(bool SupportsVector, bool SupportsGraph, bool SupportsHybrid,
    bool SupportsFullText, bool SupportsMetadataFilter, int MaxDimensions, string[] DistanceMetrics);

public record RagSearchResult(string Id, double Score, Dictionary<string, object> Metadata,
    string? TextContent, float[]? Embedding);

public record GraphNode(string Id, string Label, Dictionary<string, object> Properties,
    List<GraphEdge> Edges);

public record GraphEdge(string Id, string FromId, string ToId, string RelationType,
    Dictionary<string, object> Properties);
```

## Genie DNA Integration

1. **ParseObjectAlternative** — Metadata dictionaries processed recursively before storage
2. **BuildSearchFilter** — Filter objects skip empty/null fields automatically
3. **DataProcessResult** — All operations return `DataProcessResult<T>` with success/failure/error
4. **CreateQueryContainerList** — Elasticsearch kNN provider uses this for compound queries

## Configuration

```json
{
  "Rag": {
    "Provider": "neo4j",
    "ConnectionString": "bolt://localhost:7687",
    "DefaultCollection": "xiigen-knowledge",
    "EmbeddingDimension": 1536,
    "DistanceMetric": "cosine",
    "MaxResults": 10,
    "MinScore": 0.7
  }
}
```

## Test Scenarios

1. Store embedding → vector search → verify score > 0.9 for same content
2. Store with metadata → hybrid search with text + filter → verify filter applied
3. Store 3 nodes + 2 edges → traverse from root → verify path
4. Run same test against 2 providers → same results (provider swap)
5. Disconnect backend → verify health check returns unhealthy
6. Pass filter with nulls → verify no error, all results returned
