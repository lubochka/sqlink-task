//! Skill 00a: RAG Interfaces — Rust
//! Generic contracts for vector, graph, and hybrid RAG backends.
//! Implements Genie DNA: dynamic documents, DataProcessResult pattern.

use async_trait::async_trait;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::sync::Arc;
use chrono::Utc;

// ─── Models ──────────────────────────────────────────────────────────

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RagCapabilities {
    pub supports_vector: bool,
    pub supports_graph: bool,
    pub supports_hybrid: bool,
    pub supports_full_text: bool,
    pub supports_metadata_filter: bool,
    pub max_dimensions: usize,
    pub distance_metrics: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RagSearchResult {
    pub id: String,
    pub score: f64,
    pub metadata: HashMap<String, serde_json::Value>,
    pub text_content: Option<String>,
    pub embedding: Option<Vec<f32>>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GraphNode {
    pub id: String,
    pub label: String,
    pub properties: HashMap<String, serde_json::Value>,
    pub edges: Vec<GraphEdge>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GraphEdge {
    pub id: String,
    pub from_id: String,
    pub to_id: String,
    pub relation_type: String,
    pub properties: HashMap<String, serde_json::Value>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RagHealthStatus {
    pub is_healthy: bool,
    pub provider: String,
    pub latency_ms: u64,
    pub details: HashMap<String, serde_json::Value>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DataProcessResult<T: Clone> {
    pub success: bool,
    pub data: Option<T>,
    pub error: Option<String>,
    pub timestamp: String,
}

impl<T: Clone> DataProcessResult<T> {
    pub fn ok(data: T) -> Self {
        Self { success: true, data: Some(data), error: None, timestamp: Utc::now().to_rfc3339() }
    }
    pub fn fail(error: &str) -> Self {
        Self { success: false, data: None, error: Some(error.to_string()), timestamp: Utc::now().to_rfc3339() }
    }
}

// ─── Request Models ──────────────────────────────────────────────────

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StoreEmbeddingRequest {
    pub collection: String,
    pub id: Option<String>,
    pub embedding: Vec<f32>,
    pub text_content: Option<String>,
    pub metadata: HashMap<String, serde_json::Value>, // Dynamic — Genie DNA
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StoreNodeRequest {
    pub collection: String,
    pub id: Option<String>,
    pub label: String,
    pub properties: HashMap<String, serde_json::Value>, // Dynamic — Genie DNA
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StoreEdgeRequest {
    pub collection: String,
    pub from_id: String,
    pub to_id: String,
    pub relation_type: String,
    pub properties: HashMap<String, serde_json::Value>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VectorSearchRequest {
    pub collection: String,
    pub embedding: Vec<f32>,
    pub top_k: usize,
    pub min_score: Option<f64>,
    pub filter: Option<HashMap<String, serde_json::Value>>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct HybridSearchRequest {
    pub collection: String,
    pub text_query: Option<String>,
    pub embedding: Option<Vec<f32>>,
    pub top_k: usize,
    pub min_score: Option<f64>,
    pub filter: Option<HashMap<String, serde_json::Value>>,
    pub vector_weight: Option<f64>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TraverseRequest {
    pub collection: String,
    pub start_node_id: String,
    pub max_depth: usize,
    pub edge_filter: Option<Vec<String>>,
    pub direction: Option<String>, // outgoing, incoming, both
}

// ─── IRagService Trait ──────────────────────────────────────────────

#[async_trait]
pub trait IRagService: Send + Sync {
    fn capabilities(&self) -> &RagCapabilities;
    fn provider_name(&self) -> &str;

    // Vector
    async fn store_embedding(&self, request: StoreEmbeddingRequest) -> DataProcessResult<String>;
    async fn vector_search(&self, request: VectorSearchRequest) -> DataProcessResult<Vec<RagSearchResult>>;
    async fn hybrid_search(&self, request: HybridSearchRequest) -> DataProcessResult<Vec<RagSearchResult>>;

    // Graph
    async fn store_node(&self, request: StoreNodeRequest) -> DataProcessResult<String>;
    async fn store_edge(&self, request: StoreEdgeRequest) -> DataProcessResult<String>;
    async fn traverse(&self, request: TraverseRequest) -> DataProcessResult<Vec<GraphNode>>;

    // Admin
    async fn delete_async(&self, collection: &str, id: &str) -> DataProcessResult<bool>;
    async fn collection_exists(&self, collection: &str) -> bool;
    async fn create_collection(&self, collection: &str, dimension: usize, metric: &str) -> DataProcessResult<bool>;
    async fn health_check(&self) -> DataProcessResult<RagHealthStatus>;
}

// ─── Genie DNA Utilities ────────────────────────────────────────────

/// BuildSearchFilter — strip null/empty values from filter. Genie DNA pattern.
pub fn build_search_filter(filter: &HashMap<String, serde_json::Value>) -> HashMap<String, serde_json::Value> {
    let mut clean = HashMap::new();
    for (key, value) in filter {
        if value.is_null() { continue; }
        if let Some(s) = value.as_str() { if s.is_empty() { continue; } }
        if let Some(arr) = value.as_array() { if arr.is_empty() { continue; } }
        if let Some(obj) = value.as_object() {
            let nested: HashMap<String, serde_json::Value> = obj.iter()
                .map(|(k, v)| (k.clone(), v.clone()))
                .collect();
            let filtered = build_search_filter(&nested);
            if !filtered.is_empty() {
                clean.insert(key.clone(), serde_json::to_value(filtered).unwrap());
            }
        } else {
            clean.insert(key.clone(), value.clone());
        }
    }
    clean
}

/// ParseObjectAlternative — recursive dynamic processing. Genie DNA.
pub fn parse_object_alternative(obj: &serde_json::Value, depth: usize, max_depth: usize) -> HashMap<String, serde_json::Value> {
    if depth > max_depth { return HashMap::new(); }
    match obj {
        serde_json::Value::Object(map) => {
            let mut result = HashMap::new();
            for (key, value) in map {
                if value.is_null() { continue; }
                if value.is_object() {
                    let nested = parse_object_alternative(value, depth + 1, max_depth);
                    result.insert(key.clone(), serde_json::to_value(nested).unwrap());
                } else {
                    result.insert(key.clone(), value.clone());
                }
            }
            result
        }
        _ => {
            let mut r = HashMap::new();
            r.insert("value".to_string(), obj.clone());
            r
        }
    }
}

// ─── Factory ────────────────────────────────────────────────────────

use std::sync::RwLock;
use once_cell::sync::Lazy;

type RagFactory = Box<dyn Fn() -> Arc<dyn IRagService> + Send + Sync>;
static RAG_PROVIDERS: Lazy<RwLock<HashMap<String, RagFactory>>> = Lazy::new(|| RwLock::new(HashMap::new()));

pub fn register_rag_provider<F>(name: &str, factory: F)
where F: Fn() -> Arc<dyn IRagService> + Send + Sync + 'static {
    RAG_PROVIDERS.write().unwrap().insert(name.to_lowercase(), Box::new(factory));
}

pub fn resolve_rag_service(name: &str) -> Arc<dyn IRagService> {
    let providers = RAG_PROVIDERS.read().unwrap();
    let factory = providers.get(&name.to_lowercase())
        .unwrap_or_else(|| panic!("RAG provider '{}' not registered", name));
    factory()
}
