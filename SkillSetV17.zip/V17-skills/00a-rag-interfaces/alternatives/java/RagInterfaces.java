/**
 * Skill 00a: RAG Interfaces — Java
 * Generic contracts for vector, graph, and hybrid RAG backends.
 * Implements Genie DNA: dynamic documents, DataProcessResult pattern.
 */
package com.xiigen.rag;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.CompletableFuture;

// ─── Models ──────────────────────────────────────────────────────────

public record RagCapabilities(
    boolean supportsVector, boolean supportsGraph, boolean supportsHybrid,
    boolean supportsFullText, boolean supportsMetadataFilter,
    int maxDimensions, List<String> distanceMetrics
) {}

public record RagSearchResult(
    String id, double score, Map<String, Object> metadata,
    String textContent, float[] embedding
) {}

public record GraphNode(
    String id, String label, Map<String, Object> properties, List<GraphEdge> edges
) {}

public record GraphEdge(
    String id, String fromId, String toId, String relationType, Map<String, Object> properties
) {}

public record RagHealthStatus(
    boolean isHealthy, String provider, long latencyMs, Map<String, Object> details
) {}

public record DataProcessResult<T>(boolean success, T data, String error, String timestamp) {
    public static <T> DataProcessResult<T> ok(T data) {
        return new DataProcessResult<>(true, data, null, Instant.now().toString());
    }
    public static <T> DataProcessResult<T> fail(String error) {
        return new DataProcessResult<>(false, null, error, Instant.now().toString());
    }
}

// ─── Request Models ──────────────────────────────────────────────────

public record StoreEmbeddingRequest(
    String collection, String id, float[] embedding, String textContent,
    Map<String, Object> metadata // Dynamic — Genie DNA
) {}

public record StoreNodeRequest(
    String collection, String id, String label,
    Map<String, Object> properties // Dynamic — Genie DNA
) {}

public record StoreEdgeRequest(
    String collection, String fromId, String toId, String relationType,
    Map<String, Object> properties
) {}

public record VectorSearchRequest(
    String collection, float[] embedding, int topK, double minScore,
    Map<String, Object> filter // BuildSearchFilter — empty fields skipped
) {}

public record HybridSearchRequest(
    String collection, String textQuery, float[] embedding, int topK,
    double minScore, Map<String, Object> filter, double vectorWeight
) {}

public record TraverseRequest(
    String collection, String startNodeId, int maxDepth,
    List<String> edgeFilter, String direction
) {}

// ─── IRagService Interface ──────────────────────────────────────────

public interface IRagService {
    RagCapabilities getCapabilities();
    String getProviderName();

    // Vector operations
    CompletableFuture<DataProcessResult<String>> storeEmbedding(StoreEmbeddingRequest request);
    CompletableFuture<DataProcessResult<List<RagSearchResult>>> vectorSearch(VectorSearchRequest request);
    CompletableFuture<DataProcessResult<List<RagSearchResult>>> hybridSearch(HybridSearchRequest request);

    // Graph operations
    CompletableFuture<DataProcessResult<String>> storeNode(StoreNodeRequest request);
    CompletableFuture<DataProcessResult<String>> storeEdge(StoreEdgeRequest request);
    CompletableFuture<DataProcessResult<List<GraphNode>>> traverse(TraverseRequest request);

    // Admin
    CompletableFuture<DataProcessResult<Boolean>> deleteAsync(String collection, String id);
    CompletableFuture<Boolean> collectionExists(String collection);
    CompletableFuture<DataProcessResult<Boolean>> createCollection(String collection, int dimension, String distanceMetric);
    CompletableFuture<DataProcessResult<RagHealthStatus>> healthCheck();
}

// ─── Genie DNA Utilities ────────────────────────────────────────────

public final class RagUtils {
    private RagUtils() {}

    /** BuildSearchFilter — strip empty/null values. Genie DNA pattern. */
    @SuppressWarnings("unchecked")
    public static Map<String, Object> buildSearchFilter(Map<String, Object> filter) {
        if (filter == null) return Map.of();
        var clean = new HashMap<String, Object>();
        for (var entry : filter.entrySet()) {
            var value = entry.getValue();
            if (value == null) continue;
            if (value instanceof String s && s.isEmpty()) continue;
            if (value instanceof Collection<?> c && c.isEmpty()) continue;
            if (value instanceof Map<?, ?> m) {
                var nested = buildSearchFilter((Map<String, Object>) m);
                if (!nested.isEmpty()) clean.put(entry.getKey(), nested);
            } else {
                clean.put(entry.getKey(), value);
            }
        }
        return clean;
    }

    /** ParseObjectAlternative — recursive dynamic object processing. Genie DNA. */
    @SuppressWarnings("unchecked")
    public static Map<String, Object> parseObjectAlternative(Object obj, int depth, int maxDepth) {
        if (depth > maxDepth || obj == null) return Map.of();
        if (!(obj instanceof Map)) return Map.of("value", obj);
        var source = (Map<String, Object>) obj;
        var result = new HashMap<String, Object>();
        for (var entry : source.entrySet()) {
            if (entry.getValue() == null) continue;
            if (entry.getValue() instanceof Map) {
                result.put(entry.getKey(), parseObjectAlternative(entry.getValue(), depth + 1, maxDepth));
            } else {
                result.put(entry.getKey(), entry.getValue());
            }
        }
        return result;
    }
}

// ─── Factory Registration ───────────────────────────────────────────

public final class RagServiceFactory {
    private static final Map<String, java.util.function.Supplier<IRagService>> providers = new HashMap<>();

    public static void register(String name, java.util.function.Supplier<IRagService> factory) {
        providers.put(name.toLowerCase(), factory);
    }

    public static IRagService resolve(String providerName) {
        var factory = providers.get(providerName.toLowerCase());
        if (factory == null) {
            throw new IllegalArgumentException("RAG provider '%s' not registered. Available: %s"
                .formatted(providerName, String.join(", ", providers.keySet())));
        }
        return factory.get();
    }

    public static Set<String> availableProviders() { return providers.keySet(); }
}
