/**
 * Skill 00a: RAG Interfaces — Node.js/TypeScript
 * Generic contracts for vector, graph, and hybrid RAG backends.
 * Implements Genie DNA: dynamic documents, DataProcessResult pattern.
 */

// ─── Models ──────────────────────────────────────────────────────────

export interface RagCapabilities {
  supportsVector: boolean;
  supportsGraph: boolean;
  supportsHybrid: boolean;
  supportsFullText: boolean;
  supportsMetadataFilter: boolean;
  maxDimensions: number;
  distanceMetrics: string[]; // cosine, euclidean, dot_product
}

export interface RagSearchResult {
  id: string;
  score: number;
  metadata: Record<string, unknown>;
  textContent?: string;
  embedding?: number[];
}

export interface GraphNode {
  id: string;
  label: string;
  properties: Record<string, unknown>;
  edges: GraphEdge[];
}

export interface GraphEdge {
  id: string;
  fromId: string;
  toId: string;
  relationType: string;
  properties: Record<string, unknown>;
}

export interface RagHealthStatus {
  isHealthy: boolean;
  provider: string;
  latencyMs: number;
  details: Record<string, unknown>;
}

export interface DataProcessResult<T> {
  success: boolean;
  data?: T;
  error?: string;
  timestamp: string;
}

// ─── Store Requests ─────────────────────────────────────────────────

export interface StoreEmbeddingRequest {
  collection: string;
  id?: string;
  embedding: number[];
  textContent?: string;
  metadata: Record<string, unknown>; // Dynamic — Genie DNA
}

export interface StoreNodeRequest {
  collection: string;
  id?: string;
  label: string;
  properties: Record<string, unknown>; // Dynamic — Genie DNA
}

export interface StoreEdgeRequest {
  collection: string;
  fromId: string;
  toId: string;
  relationType: string;
  properties?: Record<string, unknown>;
}

// ─── Search Requests ────────────────────────────────────────────────

export interface VectorSearchRequest {
  collection: string;
  embedding: number[];
  topK: number;
  minScore?: number;
  filter?: Record<string, unknown>; // BuildSearchFilter — empty fields skipped
}

export interface HybridSearchRequest {
  collection: string;
  textQuery?: string;
  embedding?: number[];
  topK: number;
  minScore?: number;
  filter?: Record<string, unknown>; // BuildSearchFilter — empty fields skipped
  vectorWeight?: number; // 0.0 = text only, 1.0 = vector only
}

export interface TraverseRequest {
  collection: string;
  startNodeId: string;
  maxDepth: number;
  edgeFilter?: string[]; // Relationship types to follow
  direction?: 'outgoing' | 'incoming' | 'both';
}

// ─── IRagService Interface ──────────────────────────────────────────

export interface IRagService {
  readonly capabilities: RagCapabilities;
  readonly providerName: string;

  // Vector operations
  storeEmbedding(request: StoreEmbeddingRequest): Promise<DataProcessResult<string>>;
  vectorSearch(request: VectorSearchRequest): Promise<DataProcessResult<RagSearchResult[]>>;
  hybridSearch(request: HybridSearchRequest): Promise<DataProcessResult<RagSearchResult[]>>;

  // Graph operations
  storeNode(request: StoreNodeRequest): Promise<DataProcessResult<string>>;
  storeEdge(request: StoreEdgeRequest): Promise<DataProcessResult<string>>;
  traverse(request: TraverseRequest): Promise<DataProcessResult<GraphNode[]>>;

  // Admin
  deleteAsync(collection: string, id: string): Promise<DataProcessResult<boolean>>;
  collectionExists(collection: string): Promise<boolean>;
  createCollection(collection: string, dimension: number, distanceMetric?: string): Promise<DataProcessResult<boolean>>;
  healthCheck(): Promise<DataProcessResult<RagHealthStatus>>;
}

// ─── Utility: BuildSearchFilter (Genie DNA) ─────────────────────────

/**
 * Builds a search filter by stripping empty/null/undefined values.
 * Genie DNA pattern — callers pass full filter, provider ignores blanks.
 */
export function buildSearchFilter(filter?: Record<string, unknown>): Record<string, unknown> {
  if (!filter) return {};
  const clean: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(filter)) {
    if (value === null || value === undefined || value === '') continue;
    if (Array.isArray(value) && value.length === 0) continue;
    if (typeof value === 'object' && !Array.isArray(value)) {
      const nested = buildSearchFilter(value as Record<string, unknown>);
      if (Object.keys(nested).length > 0) clean[key] = nested;
    } else {
      clean[key] = value;
    }
  }
  return clean;
}

// ─── Utility: ParseObjectAlternative (Genie DNA) ────────────────────

/**
 * Recursively processes a dynamic object for storage.
 * Genie DNA pattern — no fixed schemas, recursive traversal.
 */
export function parseObjectAlternative(obj: unknown, depth = 0, maxDepth = 10): Record<string, unknown> {
  if (depth > maxDepth || obj === null || obj === undefined) return {};
  if (typeof obj !== 'object') return { value: obj };

  const result: Record<string, unknown> = {};
  const source = obj as Record<string, unknown>;
  for (const [key, value] of Object.entries(source)) {
    if (value === null || value === undefined) continue;
    if (typeof value === 'object' && !Array.isArray(value) && !(value instanceof Date)) {
      result[key] = parseObjectAlternative(value, depth + 1, maxDepth);
    } else {
      result[key] = value;
    }
  }
  return result;
}

// ─── Factory Registration ───────────────────────────────────────────

const ragProviders = new Map<string, () => IRagService>();

export function registerRagProvider(name: string, factory: () => IRagService): void {
  ragProviders.set(name.toLowerCase(), factory);
}

export function resolveRagService(providerName: string): IRagService {
  const factory = ragProviders.get(providerName.toLowerCase());
  if (!factory) {
    throw new Error(`RAG provider '${providerName}' not registered. Available: ${Array.from(ragProviders.keys()).join(', ')}`);
  }
  return factory();
}

export function getAvailableRagProviders(): string[] {
  return Array.from(ragProviders.keys());
}
