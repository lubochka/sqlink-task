<?php
/**
 * Skill 00a: RAG Interfaces — PHP
 * Generic contracts for vector, graph, and hybrid RAG backends.
 * Implements Genie DNA: dynamic documents, DataProcessResult pattern.
 */

namespace XIIGen\Rag;

// ─── Models ──────────────────────────────────────────────────────────

class RagCapabilities {
    public function __construct(
        public readonly bool $supportsVector = false,
        public readonly bool $supportsGraph = false,
        public readonly bool $supportsHybrid = false,
        public readonly bool $supportsFullText = false,
        public readonly bool $supportsMetadataFilter = false,
        public readonly int $maxDimensions = 1536,
        public readonly array $distanceMetrics = ['cosine'],
    ) {}
}

class RagSearchResult {
    public function __construct(
        public readonly string $id,
        public readonly float $score,
        public readonly array $metadata,
        public readonly ?string $textContent = null,
        public readonly ?array $embedding = null,
    ) {}
}

class GraphNode {
    public function __construct(
        public readonly string $id,
        public readonly string $label,
        public readonly array $properties,
        public readonly array $edges = [],
    ) {}
}

class GraphEdge {
    public function __construct(
        public readonly string $id,
        public readonly string $fromId,
        public readonly string $toId,
        public readonly string $relationType,
        public readonly array $properties = [],
    ) {}
}

class RagHealthStatus {
    public function __construct(
        public readonly bool $isHealthy,
        public readonly string $provider,
        public readonly float $latencyMs,
        public readonly array $details = [],
    ) {}
}

/** @template T */
class DataProcessResult {
    public function __construct(
        public readonly bool $success,
        public readonly mixed $data = null,
        public readonly ?string $error = null,
        public readonly string $timestamp = '',
    ) {
        if ($this->timestamp === '') {
            $this->timestamp = (new \DateTimeImmutable('now', new \DateTimeZone('UTC')))->format('c');
        }
    }

    public static function ok(mixed $data): self {
        return new self(success: true, data: $data);
    }

    public static function fail(string $error): self {
        return new self(success: false, error: $error);
    }
}

// ─── Request Models ──────────────────────────────────────────────────

class StoreEmbeddingRequest {
    public function __construct(
        public readonly string $collection,
        public readonly array $embedding,
        public readonly array $metadata, // Dynamic — Genie DNA
        public readonly ?string $id = null,
        public readonly ?string $textContent = null,
    ) {}
}

class StoreNodeRequest {
    public function __construct(
        public readonly string $collection,
        public readonly string $label,
        public readonly array $properties, // Dynamic — Genie DNA
        public readonly ?string $id = null,
    ) {}
}

class StoreEdgeRequest {
    public function __construct(
        public readonly string $collection,
        public readonly string $fromId,
        public readonly string $toId,
        public readonly string $relationType,
        public readonly array $properties = [],
    ) {}
}

class VectorSearchRequest {
    public function __construct(
        public readonly string $collection,
        public readonly array $embedding,
        public readonly int $topK = 10,
        public readonly float $minScore = 0.0,
        public readonly ?array $filter = null, // BuildSearchFilter — empty skipped
    ) {}
}

class HybridSearchRequest {
    public function __construct(
        public readonly string $collection,
        public readonly int $topK = 10,
        public readonly ?string $textQuery = null,
        public readonly ?array $embedding = null,
        public readonly float $minScore = 0.0,
        public readonly ?array $filter = null,
        public readonly float $vectorWeight = 0.5,
    ) {}
}

class TraverseRequest {
    public function __construct(
        public readonly string $collection,
        public readonly string $startNodeId,
        public readonly int $maxDepth = 3,
        public readonly ?array $edgeFilter = null,
        public readonly string $direction = 'both',
    ) {}
}

// ─── IRagService Interface ──────────────────────────────────────────

interface IRagService {
    public function getCapabilities(): RagCapabilities;
    public function getProviderName(): string;

    // Vector
    public function storeEmbedding(StoreEmbeddingRequest $request): DataProcessResult;
    public function vectorSearch(VectorSearchRequest $request): DataProcessResult;
    public function hybridSearch(HybridSearchRequest $request): DataProcessResult;

    // Graph
    public function storeNode(StoreNodeRequest $request): DataProcessResult;
    public function storeEdge(StoreEdgeRequest $request): DataProcessResult;
    public function traverse(TraverseRequest $request): DataProcessResult;

    // Admin
    public function deleteAsync(string $collection, string $id): DataProcessResult;
    public function collectionExists(string $collection): bool;
    public function createCollection(string $collection, int $dimension, string $distanceMetric = 'cosine'): DataProcessResult;
    public function healthCheck(): DataProcessResult;
}

// ─── Genie DNA Utilities ────────────────────────────────────────────

class RagUtils {
    /** BuildSearchFilter — strip empty/null values. Genie DNA pattern. */
    public static function buildSearchFilter(?array $filter): array {
        if ($filter === null) return [];
        $clean = [];
        foreach ($filter as $key => $value) {
            if ($value === null || $value === '' || (is_array($value) && count($value) === 0)) continue;
            if (is_array($value) && !array_is_list($value)) {
                $nested = self::buildSearchFilter($value);
                if (!empty($nested)) $clean[$key] = $nested;
            } else {
                $clean[$key] = $value;
            }
        }
        return $clean;
    }

    /** ParseObjectAlternative — recursive dynamic processing. Genie DNA. */
    public static function parseObjectAlternative(mixed $obj, int $depth = 0, int $maxDepth = 10): array {
        if ($depth > $maxDepth || $obj === null) return [];
        if (!is_array($obj)) return ['value' => $obj];
        $result = [];
        foreach ($obj as $key => $value) {
            if ($value === null) continue;
            if (is_array($value) && !array_is_list($value)) {
                $result[$key] = self::parseObjectAlternative($value, $depth + 1, $maxDepth);
            } else {
                $result[$key] = $value;
            }
        }
        return $result;
    }
}

// ─── Factory Registration ───────────────────────────────────────────

class RagServiceFactory {
    private static array $providers = [];

    public static function register(string $name, callable $factory): void {
        self::$providers[strtolower($name)] = $factory;
    }

    public static function resolve(string $providerName): IRagService {
        $key = strtolower($providerName);
        if (!isset(self::$providers[$key])) {
            throw new \InvalidArgumentException(
                "RAG provider '$providerName' not registered. Available: " . implode(', ', array_keys(self::$providers))
            );
        }
        return (self::$providers[$key])();
    }

    public static function availableProviders(): array {
        return array_keys(self::$providers);
    }
}
