"""
Skill 00a: RAG Interfaces — Python
Generic contracts for vector, graph, and hybrid RAG backends.
Implements Genie DNA: dynamic documents, DataProcessResult pattern.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Optional
from datetime import datetime, timezone


# ─── Models ──────────────────────────────────────────────────────────

@dataclass
class RagCapabilities:
    supports_vector: bool = False
    supports_graph: bool = False
    supports_hybrid: bool = False
    supports_full_text: bool = False
    supports_metadata_filter: bool = False
    max_dimensions: int = 1536
    distance_metrics: list[str] = field(default_factory=lambda: ["cosine"])


@dataclass
class RagSearchResult:
    id: str
    score: float
    metadata: dict[str, Any]
    text_content: Optional[str] = None
    embedding: Optional[list[float]] = None


@dataclass
class GraphNode:
    id: str
    label: str
    properties: dict[str, Any]
    edges: list["GraphEdge"] = field(default_factory=list)


@dataclass
class GraphEdge:
    id: str
    from_id: str
    to_id: str
    relation_type: str
    properties: dict[str, Any] = field(default_factory=dict)


@dataclass
class RagHealthStatus:
    is_healthy: bool
    provider: str
    latency_ms: float
    details: dict[str, Any] = field(default_factory=dict)


@dataclass
class DataProcessResult[T]:
    success: bool
    data: Optional[T] = None
    error: Optional[str] = None
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    @staticmethod
    def ok(data: T) -> "DataProcessResult[T]":
        return DataProcessResult(success=True, data=data)

    @staticmethod
    def fail(error: str) -> "DataProcessResult[T]":
        return DataProcessResult(success=False, error=error)


# ─── Request Models ──────────────────────────────────────────────────

@dataclass
class StoreEmbeddingRequest:
    collection: str
    embedding: list[float]
    metadata: dict[str, Any]  # Dynamic — Genie DNA
    id: Optional[str] = None
    text_content: Optional[str] = None


@dataclass
class StoreNodeRequest:
    collection: str
    label: str
    properties: dict[str, Any]  # Dynamic — Genie DNA
    id: Optional[str] = None


@dataclass
class StoreEdgeRequest:
    collection: str
    from_id: str
    to_id: str
    relation_type: str
    properties: dict[str, Any] = field(default_factory=dict)


@dataclass
class VectorSearchRequest:
    collection: str
    embedding: list[float]
    top_k: int = 10
    min_score: float = 0.0
    filter: Optional[dict[str, Any]] = None  # BuildSearchFilter — empty fields skipped


@dataclass
class HybridSearchRequest:
    collection: str
    top_k: int = 10
    text_query: Optional[str] = None
    embedding: Optional[list[float]] = None
    min_score: float = 0.0
    filter: Optional[dict[str, Any]] = None
    vector_weight: float = 0.5


@dataclass
class TraverseRequest:
    collection: str
    start_node_id: str
    max_depth: int = 3
    edge_filter: Optional[list[str]] = None
    direction: str = "both"  # outgoing, incoming, both


# ─── IRagService Interface ───────────────────────────────────────────

class IRagService(ABC):
    """Universal RAG contract — all backends implement this."""

    @property
    @abstractmethod
    def capabilities(self) -> RagCapabilities: ...

    @property
    @abstractmethod
    def provider_name(self) -> str: ...

    # Vector operations
    @abstractmethod
    async def store_embedding(self, request: StoreEmbeddingRequest) -> DataProcessResult[str]: ...

    @abstractmethod
    async def vector_search(self, request: VectorSearchRequest) -> DataProcessResult[list[RagSearchResult]]: ...

    @abstractmethod
    async def hybrid_search(self, request: HybridSearchRequest) -> DataProcessResult[list[RagSearchResult]]: ...

    # Graph operations
    @abstractmethod
    async def store_node(self, request: StoreNodeRequest) -> DataProcessResult[str]: ...

    @abstractmethod
    async def store_edge(self, request: StoreEdgeRequest) -> DataProcessResult[str]: ...

    @abstractmethod
    async def traverse(self, request: TraverseRequest) -> DataProcessResult[list[GraphNode]]: ...

    # Admin
    @abstractmethod
    async def delete_async(self, collection: str, id: str) -> DataProcessResult[bool]: ...

    @abstractmethod
    async def collection_exists(self, collection: str) -> bool: ...

    @abstractmethod
    async def create_collection(self, collection: str, dimension: int, distance_metric: str = "cosine") -> DataProcessResult[bool]: ...

    @abstractmethod
    async def health_check(self) -> DataProcessResult[RagHealthStatus]: ...


# ─── Genie DNA Utilities ────────────────────────────────────────────

def build_search_filter(filter_dict: Optional[dict[str, Any]]) -> dict[str, Any]:
    """Strip empty/null values from filter. Genie DNA pattern."""
    if not filter_dict:
        return {}
    clean = {}
    for key, value in filter_dict.items():
        if value is None or value == "" or (isinstance(value, list) and len(value) == 0):
            continue
        if isinstance(value, dict):
            nested = build_search_filter(value)
            if nested:
                clean[key] = nested
        else:
            clean[key] = value
    return clean


def parse_object_alternative(obj: Any, depth: int = 0, max_depth: int = 10) -> dict[str, Any]:
    """Recursively process dynamic object for storage. Genie DNA pattern."""
    if depth > max_depth or obj is None:
        return {}
    if not isinstance(obj, dict):
        return {"value": obj}
    result = {}
    for key, value in obj.items():
        if value is None:
            continue
        if isinstance(value, dict):
            result[key] = parse_object_alternative(value, depth + 1, max_depth)
        else:
            result[key] = value
    return result


# ─── Factory Registration ───────────────────────────────────────────

_rag_providers: dict[str, type[IRagService]] = {}


def register_rag_provider(name: str, provider_class: type[IRagService]) -> None:
    _rag_providers[name.lower()] = provider_class


def resolve_rag_service(provider_name: str, **kwargs) -> IRagService:
    cls = _rag_providers.get(provider_name.lower())
    if not cls:
        available = ", ".join(_rag_providers.keys())
        raise ValueError(f"RAG provider '{provider_name}' not registered. Available: {available}")
    return cls(**kwargs)
