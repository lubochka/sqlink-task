# Skill 00a: RAG Interfaces — Implementation Guide

## Phase 1: Core Interface (30 min)
1. Create `IRagService` interface with all method signatures from SKILL.md
2. Create model records: `RagCapabilities`, `RagSearchResult`, `GraphNode`, `GraphEdge`, `RagHealthStatus`
3. Create request records: `StoreEmbeddingRequest`, `VectorSearchRequest`, `HybridSearchRequest`, `StoreNodeRequest`, `StoreEdgeRequest`, `TraverseRequest`
4. All methods return `DataProcessResult<T>` (Genie DNA)
5. Add `RagCapabilities` property so providers self-declare features

## Phase 2: Genie DNA Utilities (20 min)
1. Implement `BuildSearchFilter` — strip null/empty from filter dictionaries recursively
2. Implement `ParseObjectAlternative` — recursive dynamic object processing for metadata
3. Ensure all providers call these before storage/search operations
4. Write unit tests: null filter → empty, mixed filter → only non-empty fields

## Phase 3: DI Factory Registration (20 min)
1. Create `RagServiceFactory` or DI extension for registering providers by name
2. Support `resolve(providerName)` to get the configured backend
3. Read provider name from configuration (`appsettings.json` / env vars)
4. Validate: unknown provider → clear error listing available providers

## Phase 4: First Provider Implementation (45 min)
Pick one provider (recommend Elasticsearch kNN since it's already in stack):
1. Implement all `IRagService` methods against the chosen backend
2. Use `CreateQueryContainerList` pattern for compound queries (Genie DNA)
3. Test: store → search → verify results
4. Test: health check returns accurate status

## Phase 5: Provider Swap Validation (15 min)
1. Add a second provider (e.g., Pinecone or in-memory mock)
2. Run exact same test suite against both
3. Verify identical results (within score precision)
4. Swap via config only — zero code changes

## Validation Checklist
- [ ] `IRagService` has all 10 methods from SKILL.md
- [ ] `RagCapabilities` lets providers declare supported features
- [ ] `BuildSearchFilter` strips empty fields recursively
- [ ] `ParseObjectAlternative` processes dynamic metadata
- [ ] `DataProcessResult<T>` wraps all return values
- [ ] Factory resolves provider by config name
- [ ] At least one provider implementation passes all tests
- [ ] Provider swap works via config change only
