// XIIGen Calculator Metrics Service — Java | Skill 43
package com.xiigen.services.calculator;
import com.xiigen.core.*;
import java.util.*;
import java.util.stream.Collectors;

public class CalculatorService extends MicroserviceBase {
    public CalculatorService(IDatabaseService db, IQueueService queue) { super(db, queue, "calculator-service"); }

    public DataProcessResult<Map<String, Object>> createDefinition(String name, String entityType, List<Map<String, Object>> fields, Map<String, Double> weights) throws Exception {
        String id = UUID.randomUUID().toString();
        var def = Map.of("definitionId", id, "name", name, "entityType", entityType, "fields", fields, "weights", (Object)(weights != null ? weights : Map.of()), "normalizeOutput", true);
        storeDocument("calc-definitions", id, def);
        return DataProcessResult.success(def);
    }

    public DataProcessResult<Map<String, Object>> calculate(String definitionId, String entityId, Map<String, Double> data) throws Exception {
        var def = (Map<String, Object>) getDocument("calc-definitions", definitionId);
        if (def == null) return DataProcessResult.failure("Definition not found");
        Map<String, Double> fieldScores = new HashMap<>();
        double weightedSum = 0, totalWeight = 0;
        var weights = (Map<String, Double>) def.getOrDefault("weights", Map.of());
        for (var field : (List<Map<String, Object>>) def.get("fields")) {
            String src = (String) field.getOrDefault("sourceField", "");
            double raw = data.getOrDefault(src, 0.0);
            double w = weights.getOrDefault((String) field.get("name"), ((Number) field.getOrDefault("weight", 1.0)).doubleValue());
            fieldScores.put((String) field.get("name"), raw);
            weightedSum += raw * w; totalWeight += w;
        }
        double finalScore = totalWeight > 0 ? weightedSum / totalWeight : 0;
        if ((boolean) def.getOrDefault("normalizeOutput", true)) finalScore = Math.max(0, Math.min(100, finalScore));
        String rid = UUID.randomUUID().toString();
        var result = Map.of("resultId", rid, "definitionId", definitionId, "entityId", entityId, "finalScore", finalScore, "fieldScores", (Object) fieldScores);
        storeDocument("calc-results", rid, result);
        return DataProcessResult.success(result);
    }
}
