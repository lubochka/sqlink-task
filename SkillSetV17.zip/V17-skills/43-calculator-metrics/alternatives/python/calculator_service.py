# XIIGen Calculator Metrics Service — Python | Skill 43
import uuid
from core_interfaces import IDatabaseService, IQueueService, DataProcessResult, MicroserviceBase

class CalculatorService(MicroserviceBase):
    service_name = "calculator-service"
    def __init__(self, db: IDatabaseService, queue: IQueueService): super().__init__(db, queue)

    async def create_definition(self, name: str, entity_type: str, fields: list[dict], weights: dict = None, normalize: bool = True) -> DataProcessResult:
        defn = {"definitionId": str(uuid.uuid4()), "name": name, "entityType": entity_type, "fields": fields, "weights": weights or {}, "normalizeOutput": normalize}
        await self.store_document("calc-definitions", defn["definitionId"], defn)
        return DataProcessResult.success(defn)

    async def calculate(self, definition_id: str, entity_id: str, data: dict[str, float]) -> DataProcessResult:
        defn = await self.get_document("calc-definitions", definition_id)
        if not defn: return DataProcessResult.failure("Definition not found")
        field_scores = {}; weighted_sum = 0; total_weight = 0
        for field in defn.get("fields", []):
            raw = data.get(field.get("sourceField", ""), 0)
            value = max(field.get("min", raw), min(field.get("max", raw), raw))
            weight = defn.get("weights", {}).get(field["name"], field.get("weight", 1))
            field_scores[field["name"]] = value
            weighted_sum += value * weight; total_weight += weight
        final = (weighted_sum / total_weight) if total_weight > 0 else 0
        if defn.get("normalizeOutput"): final = max(0, min(100, final))
        result = {"resultId": str(uuid.uuid4()), "definitionId": definition_id, "entityId": entity_id, "finalScore": final, "fieldScores": field_scores}
        await self.store_document("calc-results", result["resultId"], result)
        return DataProcessResult.success(result)

    async def get_rankings(self, definition_id: str, limit: int = 10) -> DataProcessResult:
        results = await self.search_documents("calc-results", {"definitionId": definition_id}, limit)
        if not results.is_success: return DataProcessResult.success([])
        sorted_results = sorted(results.data or [], key=lambda r: r.get("finalScore", 0), reverse=True)
        for i, r in enumerate(sorted_results): r["rank"] = i + 1
        return DataProcessResult.success(sorted_results)
