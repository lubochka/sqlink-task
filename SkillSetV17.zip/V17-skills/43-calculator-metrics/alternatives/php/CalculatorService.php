<?php
// XIIGen Calculator Metrics Service — PHP | Skill 43
namespace XIIGen\Services\Calculator;
use XIIGen\Core\{MicroserviceBase, DataProcessResult, IDatabaseService, IQueueService};

class CalculatorService extends MicroserviceBase {
    protected string $serviceName = 'calculator-service';
    public function __construct(IDatabaseService $db, IQueueService $queue) { parent::__construct($db, $queue); }

    public function createDefinition(string $name, string $entityType, array $fields, array $weights = [], bool $normalize = true): DataProcessResult {
        $id = \Ramsey\Uuid\Uuid::uuid4()->toString();
        $def = ['definitionId' => $id, 'name' => $name, 'entityType' => $entityType, 'fields' => $fields, 'weights' => $weights, 'normalizeOutput' => $normalize];
        $this->storeDocument('calc-definitions', $id, $def);
        return DataProcessResult::success($def);
    }

    public function calculate(string $definitionId, string $entityId, array $data): DataProcessResult {
        $def = $this->getDocument('calc-definitions', $definitionId);
        if (!$def) return DataProcessResult::failure('Definition not found');
        $fieldScores = []; $weightedSum = 0; $totalWeight = 0;
        foreach ($def['fields'] ?? [] as $field) {
            $raw = $data[$field['sourceField'] ?? ''] ?? 0;
            $w = $def['weights'][$field['name']] ?? ($field['weight'] ?? 1);
            $fieldScores[$field['name']] = $raw;
            $weightedSum += $raw * $w; $totalWeight += $w;
        }
        $final = $totalWeight > 0 ? $weightedSum / $totalWeight : 0;
        if ($def['normalizeOutput'] ?? true) $final = max(0, min(100, $final));
        $rid = \Ramsey\Uuid\Uuid::uuid4()->toString();
        $result = ['resultId' => $rid, 'definitionId' => $definitionId, 'entityId' => $entityId, 'finalScore' => $final, 'fieldScores' => $fieldScores];
        $this->storeDocument('calc-results', $rid, $result);
        return DataProcessResult::success($result);
    }
}
