// XIIGen Calculator Metrics Service — Node.js/TypeScript | Skill 43
import { IDatabaseService, IQueueService, DataProcessResult, MicroserviceBase } from '../../01-core-interfaces';
import { randomUUID } from 'crypto';

interface MetricField { name: string; sourceField: string; aggregation: string; weight: number; min?: number; max?: number; customFormula?: string; }
interface CalculationDefinition { definitionId: string; name: string; entityType: string; fields: MetricField[]; weights: Record<string, number>; normalizeOutput: boolean; }
interface CalculationResult { resultId: string; definitionId: string; entityId: string; finalScore: number; fieldScores: Record<string, number>; rank?: number; }

export class CalculatorService extends MicroserviceBase {
  protected serviceName = 'calculator-service';
  constructor(db: IDatabaseService, queue: IQueueService) { super(db, queue); }

  async createDefinition(name: string, entityType: string, fields: MetricField[], weights: Record<string, number> = {}, normalize = true): Promise<DataProcessResult<CalculationDefinition>> {
    const def: CalculationDefinition = { definitionId: randomUUID(), name, entityType, fields, weights, normalizeOutput: normalize };
    await this.storeDocument('calc-definitions', def.definitionId, def);
    return DataProcessResult.success(def);
  }

  async calculate(definitionId: string, entityId: string, data: Record<string, number>): Promise<DataProcessResult<CalculationResult>> {
    const def = await this.getDocument('calc-definitions', definitionId) as any as CalculationDefinition;
    if (!def) return DataProcessResult.failure('Definition not found');
    const fieldScores: Record<string, number> = {};
    let weightedSum = 0, totalWeight = 0;
    for (const field of def.fields) {
      const raw = data[field.sourceField] ?? 0;
      let value = raw;
      if (field.min !== undefined) value = Math.max(value, field.min);
      if (field.max !== undefined) value = Math.min(value, field.max);
      const weight = def.weights[field.name] ?? field.weight ?? 1;
      fieldScores[field.name] = value;
      weightedSum += value * weight;
      totalWeight += weight;
    }
    let finalScore = totalWeight > 0 ? weightedSum / totalWeight : 0;
    if (def.normalizeOutput) finalScore = Math.max(0, Math.min(100, finalScore));
    const result: CalculationResult = { resultId: randomUUID(), definitionId, entityId, finalScore, fieldScores };
    await this.storeDocument('calc-results', result.resultId, result);
    return DataProcessResult.success(result);
  }

  async getRankings(definitionId: string, limit = 10): Promise<DataProcessResult<CalculationResult[]>> {
    const results = await this.searchDocuments('calc-results', { definitionId }, limit);
    if (!results.isSuccess) return DataProcessResult.success([]);
    const sorted = (results.data as any[]).sort((a, b) => (b.finalScore || 0) - (a.finalScore || 0));
    sorted.forEach((r, i) => r.rank = i + 1);
    return DataProcessResult.success(sorted);
  }
}
