// XIIGen Calculator Metrics Service — Rust | Skill 43
use serde_json::{json, Value};
use uuid::Uuid;
use std::collections::HashMap;
use crate::core::{DataProcessResult, IDatabaseService, IQueueService, MicroserviceBase};

pub struct CalculatorService { base: MicroserviceBase }

impl CalculatorService {
    pub fn new(db: Box<dyn IDatabaseService>, queue: Box<dyn IQueueService>) -> Self {
        Self { base: MicroserviceBase::new(db, queue, "calculator-service") }
    }

    pub async fn create_definition(&self, name: &str, entity_type: &str, fields: Vec<Value>, weights: HashMap<String, f64>) -> DataProcessResult<Value> {
        let id = Uuid::new_v4().to_string();
        let def = json!({"definitionId": id, "name": name, "entityType": entity_type, "fields": fields, "weights": weights, "normalizeOutput": true});
        self.base.store_document("calc-definitions", &id, &def).await;
        DataProcessResult::success(def)
    }

    pub async fn calculate(&self, definition_id: &str, entity_id: &str, data: &HashMap<String, f64>) -> DataProcessResult<Value> {
        let def = match self.base.get_document("calc-definitions", definition_id).await {
            Some(d) => d, None => return DataProcessResult::failure("Definition not found"),
        };
        let mut field_scores = HashMap::new();
        let mut weighted_sum = 0.0_f64; let mut total_weight = 0.0_f64;
        if let Some(fields) = def["fields"].as_array() {
            for field in fields {
                let src = field["sourceField"].as_str().unwrap_or("");
                let raw = data.get(src).copied().unwrap_or(0.0);
                let w = def["weights"].get(field["name"].as_str().unwrap_or("")).and_then(|v| v.as_f64()).unwrap_or(1.0);
                field_scores.insert(field["name"].as_str().unwrap_or("").to_string(), raw);
                weighted_sum += raw * w; total_weight += w;
            }
        }
        let final_score = if total_weight > 0.0 { (weighted_sum / total_weight).clamp(0.0, 100.0) } else { 0.0 };
        let rid = Uuid::new_v4().to_string();
        let result = json!({"resultId": rid, "definitionId": definition_id, "entityId": entity_id, "finalScore": final_score, "fieldScores": field_scores});
        self.base.store_document("calc-results", &rid, &result).await;
        DataProcessResult::success(result)
    }
}
