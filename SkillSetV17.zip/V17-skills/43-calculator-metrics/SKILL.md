---
skill_id: "43"
name: calculator-metrics
title: "Calculator Metrics Service"
layer: "L8: Specialty"
version: "17.0"
status: "active"
dependencies:
  - "01-core-interfaces"
  - "02-object-processor"
  - "03-elasticsearch-datastore"
dotnet_namespace: "XIIGen.Services.Calculator"
di_registration: "services.AddXIIGenCalculator()"
es_index: "xiigen-calculations"
genie_dna:
  - "DNA-1: Calculation definitions AND results as dynamic documents"
  - "DNA-2: BuildSearchFilter for calculation queries (entityType, metric, dateRange — skip empty)"
  - "DNA-3: Inherits MicroserviceBase"
  - "DNA-4: Calculation definitions created by admins from entity definitions — no code"
  - "DNA-5: DataProcessResult for all operations"
  - "DNA-FREEDOM: Business users define their own metrics and scoring formulas"
triggers: calculator, metrics, scoring, weighted average, ranking, aggregation, KPI, dashboard
---

# Skill 43: Calculator Metrics Service
## Dynamic Metric Definitions & Computed Scores

From Architecture.docx: "Calculator — metrics from entities + connections + weights."

**Classification: FREEDOM — users define their own metrics**

---

## Genie DNA Integration

### Calculation Definitions as Dynamic Documents (DNA-1, DNA-4, DNA-FREEDOM)
Business users create their own scoring formulas without developers:
```json
{
  "calcName": "vendor_reliability_score",
  "entityType": "vendors",
  "fields": [
    { "name": "on_time_delivery", "weight": 0.4, "aggregation": "average" },
    { "name": "quality_rating", "weight": 0.3, "aggregation": "average" },
    { "name": "response_time", "weight": 0.2, "aggregation": "min", "invertScore": true },
    { "name": "complaint_count", "weight": 0.1, "aggregation": "count", "invertScore": true }
  ],
  "normalize": { "min": 0, "max": 100 },
  "bounds": { "min": 0, "max": 100 },
  "createdBy": "finance_admin@company.com"
}
```
Adding a new metric = adding a document. Changing weights = updating a document. No code.

### Results as Dynamic Documents (DNA-1)
Calculation results stored with whatever metadata the calculation produces:
```json
{
  "calcName": "vendor_reliability_score",
  "entityId": "vendor_456",
  "score": 78.5,
  "fieldScores": { "on_time_delivery": 85, "quality_rating": 90, "response_time": 60, "complaint_count": 70 },
  "rank": 3,
  "calculatedAt": "2026-02-08T15:00:00Z"
}
```

## Interface
```csharp
public interface ICalculatorService
{
    Task<DataProcessResult<string>> CreateDefinitionAsync(Dictionary<string, object> calcDefDoc);
    Task<DataProcessResult<Dictionary<string, object>>> CalculateAsync(
        string calcName, string entityId);
    Task<DataProcessResult<List<Dictionary<string, object>>>> GetRankingsAsync(
        string calcName, Dictionary<string, object> filter);
}
```

## Aggregation Types
Sum, Average, WeightedAverage, Max, Min, Percentile, Count, Custom.
All defined in the calculation definition document — not in code.

## Alternatives
All alternatives MUST: store definitions/results as dynamic documents, support user-created metric formulas, use BuildSearchFilter for queries, return DataProcessResult.
