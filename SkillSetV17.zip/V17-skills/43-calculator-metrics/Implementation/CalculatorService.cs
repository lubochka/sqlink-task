// XIIGen.Services.Calculator/CalculatorService.cs - Skill 43 | .NET 9
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using XIIGen.Core.Base;
using XIIGen.Core.Enums;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Services.Calculator;

// ─── Models ─────────────────────────────────────────
public enum AggregationType { Sum, Average, WeightedAverage, Max, Min, Percentile, Count, Custom }

public class MetricField
{
    public string Name { get; set; } = "";
    public string SourceField { get; set; } = "";
    public AggregationType Aggregation { get; set; } = AggregationType.Sum;
    public double Weight { get; set; } = 1.0;
    public double? MinValue { get; set; }
    public double? MaxValue { get; set; }
    public string? CustomFormula { get; set; }   // e.g. "field1 * 0.3 + field2 * 0.7"
}

public class CalculationDefinition
{
    public string DefinitionId { get; set; } = Guid.NewGuid().ToString();
    public string Name { get; set; } = "";
    public string Description { get; set; } = "";
    public string EntityType { get; set; } = "";          // "user", "post", "product", etc.
    public List<MetricField> Fields { get; set; } = [];
    public string FinalAggregation { get; set; } = "weighted-sum"; // how fields combine into final score
    public Dictionary<string, double> Weights { get; set; } = [];  // field name → weight
    public bool NormalizeOutput { get; set; } = true;               // normalize to 0-100
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

public class CalculationResult
{
    public string ResultId { get; set; } = Guid.NewGuid().ToString();
    public string DefinitionId { get; set; } = "";
    public string EntityId { get; set; } = "";
    public string EntityType { get; set; } = "";
    public double FinalScore { get; set; }
    public Dictionary<string, double> FieldScores { get; set; } = [];
    public int? Rank { get; set; }
    public DateTime CalculatedAt { get; set; } = DateTime.UtcNow;
}

// ─── Service ────────────────────────────────────────
public class CalculatorService : MicroserviceBase
{
    private readonly IObjectProcessor _objectProcessor;

    public CalculatorService(IDatabaseService db, IQueueService queue, ILogger<CalculatorService> logger,
        IObjectProcessor objectProcessor, ICacheService cache = null)
        : base(db, queue, logger, cache)
    { ServiceName = "calculator-service"; _objectProcessor = objectProcessor; }

    // ── Definition CRUD ─────────────────────────────
    public async Task<DataProcessResult<CalculationDefinition>> CreateDefinitionAsync(
        CalculationDefinition def, CancellationToken ct = default)
    {
        await StoreDocumentAsync("calculator-definitions", def.DefinitionId, def, ct: ct);
        Logger.LogInformation("Calculation definition created: {Id} ({Name})", def.DefinitionId, def.Name);
        return DataProcessResult<CalculationDefinition>.Created(def);
    }

    public async Task<DataProcessResult<CalculationDefinition>> GetDefinitionAsync(
        string definitionId, CancellationToken ct = default)
    {
        var result = await GetDocumentAsync("calculator-definitions", definitionId, ct);
        return result.IsSuccess
            ? DataProcessResult<CalculationDefinition>.Success(result.Data as CalculationDefinition ?? new())
            : DataProcessResult<CalculationDefinition>.Error("Definition not found");
    }

    // ── Compute ─────────────────────────────────────
    /// <summary>Compute score for a single entity using a calculation definition.</summary>
    public async Task<DataProcessResult<CalculationResult>> ComputeAsync(
        string definitionId, string entityId, Dictionary<string, object> entityData,
        Dictionary<string, object>? connectionData = null, CancellationToken ct = default)
    {
        var defResult = await GetDefinitionAsync(definitionId, ct);
        if (!defResult.IsSuccess) return DataProcessResult<CalculationResult>.Error(defResult.Message);
        var def = defResult.Data!;

        var fieldScores = new Dictionary<string, double>();
        foreach (var field in def.Fields)
        {
            var rawValue = ExtractValue(entityData, connectionData, field.SourceField);
            var score = ApplyAggregation(rawValue, field);
            if (field.MinValue.HasValue) score = Math.Max(score, field.MinValue.Value);
            if (field.MaxValue.HasValue) score = Math.Min(score, field.MaxValue.Value);
            fieldScores[field.Name] = score;
        }

        var finalScore = ComputeFinalScore(fieldScores, def);
        if (def.NormalizeOutput) finalScore = NormalizeTo100(finalScore, def);

        var result = new CalculationResult
        {
            DefinitionId = definitionId,
            EntityId = entityId,
            EntityType = def.EntityType,
            FinalScore = Math.Round(finalScore, 2),
            FieldScores = fieldScores
        };

        await StoreDocumentAsync("calculator-results", result.ResultId, result, ct: ct);
        Logger.LogInformation("Computed {EntityType} {EntityId}: score={Score}", def.EntityType, entityId, result.FinalScore);
        return DataProcessResult<CalculationResult>.Success(result);
    }

    /// <summary>Compute scores for multiple entities and assign ranks.</summary>
    public async Task<DataProcessResult<List<CalculationResult>>> ComputeBatchAsync(
        string definitionId, List<(string entityId, Dictionary<string, object> data, Dictionary<string, object>? connections)> entities,
        CancellationToken ct = default)
    {
        var results = new List<CalculationResult>();
        foreach (var (entityId, data, connections) in entities)
        {
            var r = await ComputeAsync(definitionId, entityId, data, connections, ct);
            if (r.IsSuccess) results.Add(r.Data!);
        }

        // Assign ranks
        var ranked = results.OrderByDescending(r => r.FinalScore).ToList();
        for (int i = 0; i < ranked.Count; i++)
            ranked[i].Rank = i + 1;

        return DataProcessResult<List<CalculationResult>>.Success(ranked);
    }

    /// <summary>Get top-N entities by score (for feeds/rankings).</summary>
    public async Task<DataProcessResult<List<object>>> GetTopEntitiesAsync(
        string definitionId, int limit = 10, CancellationToken ct = default)
    {
        return await SearchDocumentsAsync("calculator-results", new { definitionId }, limit, ct);
    }

    // ── Internal Helpers ────────────────────────────
    private double ExtractValue(Dictionary<string, object> entityData, Dictionary<string, object>? connectionData, string sourceField)
    {
        if (entityData.TryGetValue(sourceField, out var val))
            return Convert.ToDouble(val);
        if (connectionData?.TryGetValue(sourceField, out var cVal) == true)
            return Convert.ToDouble(cVal);
        return 0;
    }

    private static double ApplyAggregation(double value, MetricField field) => field.Aggregation switch
    {
        AggregationType.Sum => value * field.Weight,
        AggregationType.Average => value * field.Weight,
        AggregationType.WeightedAverage => value * field.Weight,
        AggregationType.Max => value,
        AggregationType.Min => value,
        AggregationType.Count => value > 0 ? 1 * field.Weight : 0,
        _ => value * field.Weight
    };

    private static double ComputeFinalScore(Dictionary<string, double> fieldScores, CalculationDefinition def)
    {
        if (def.FinalAggregation == "weighted-sum")
        {
            double total = 0, totalWeight = 0;
            foreach (var (name, score) in fieldScores)
            {
                var w = def.Weights.GetValueOrDefault(name, 1.0);
                total += score * w;
                totalWeight += w;
            }
            return totalWeight > 0 ? total / totalWeight : 0;
        }
        return fieldScores.Values.Sum(); // simple sum fallback
    }

    private static double NormalizeTo100(double score, CalculationDefinition def)
    {
        // Simple normalization: assume max possible is sum of all max weights
        var maxPossible = def.Fields.Sum(f => (f.MaxValue ?? 100) * f.Weight);
        return maxPossible > 0 ? Math.Min(100, score / maxPossible * 100) : score;
    }
}

// ─── DI Extension ───────────────────────────────────
public static class CalculatorServiceExtensions
{
    public static IServiceCollection AddXIIGenCalculator(this IServiceCollection services)
    {
        services.AddSingleton<CalculatorService>();
        return services;
    }
}
