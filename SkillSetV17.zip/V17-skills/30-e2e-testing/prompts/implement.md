# Skill 30: E2E Testing — Implementation Prompt

## Phase 1: API Test Client
HTTP client with JWT auth. Store/search/get document roundtrip verification.

## Phase 2: Dynamic Document Roundtrip
Store document with arbitrary fields -> search by subset -> verify all fields preserved.
Store with NEW unknown fields -> verify stored and retrievable.

## Phase 3: Scope Isolation E2E
Login User A -> store doc -> logout. Login User B -> search -> verify A's doc NOT visible.
Login Admin -> search -> verify ALL docs visible.

## Phase 4: Event Propagation
Register user -> verify permission grant event -> verify notification sent.

---

## Genie DNA Compliance — MANDATORY
☐ DNA-1: Dynamic Documents — Dictionary<string, object>, NOT typed models
☐ DNA-2: BuildSearchFilter — skip empty fields, no entity-specific query code
☐ DNA-3: MicroserviceBase — inherit DB, queue, cache, logger
☐ DNA-5: DataProcessResult<T> — all methods return result wrapper
☐ DNA-6: Generic Interfaces — swap via config
☐ DNA-SCOPE: Non-admin queries auto-inject userId filter
