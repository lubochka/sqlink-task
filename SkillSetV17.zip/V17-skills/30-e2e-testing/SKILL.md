---
skill_id: "30"
name: e2e-testing
title: "E2E Test Generator Service"
layer: "L7: Quality"
version: "17.1"
status: "active"
dependencies: ["01-core-interfaces", "02-object-processor", "06-ai-providers", "08-flow-definition", "28-prompt-engineering"]
genie_dna:
  - "DNA-1: E2E scenarios stored as dynamic documents in ES"
  - "DNA-2: BuildSearchFilter for scenario search — skip empty, inject scope"
  - "DNA-3: ParseObjectAlternative for scenario storage"
  - "DNA-5: DataProcessResult wraps all operations"
  - "DNA-FREEDOM: Test scenarios, step definitions, assertions are user-definable"
  - "DNA-MACHINE: E2E engine orchestrates scenario execution"
  - "DNA-SCOPE: ownerId injected on all scenario queries"
triggers: e2e test, end to end, integration test, scenario test, playwright, cypress, flow testing
es_indices:
  - "xiigen-e2e-scenarios"
  - "xiigen-e2e-results"
---

# Skill 30: E2E Test Generator Service
## Flow-Aware End-to-End Test Generation

**Status:** Enhanced — DNA-Compliant  
**Priority:** P1 — Validates entire flow pipelines  
**Dependencies:** Skill 01, Skill 02, Skill 08, Skill 28  
**Layer:** L7: Quality  
**Estimated LOC:** ~400  

---

## Overview

The E2E Test Generator creates end-to-end test scenarios that validate complete flow pipelines — from user action through API calls, microservice orchestration, and final output. Scenarios are dynamic documents that describe steps, assertions, environments, and expected behaviors. Users and AI agents define scenarios at runtime; the MACHINE engine generates executable test code.

## Key Concepts

- **E2EScenario** — Dynamic document describing a complete test flow (steps, assertions, env). Schema-free.
- **StepDefinition** — Each step in a scenario: action, expected result, timeout, retry policy. Dynamic.
- **EnvironmentConfig** — Dynamic document: base URL, auth tokens, feature flags per environment.
- **ScenarioGenerator** — MACHINE component that converts scenario docs into executable test code.
- **FlowAwareAnalyzer** — MACHINE component that reads Skill 08 flow definitions to auto-generate scenarios.

---

## Component Classification (MACHINE vs FREEDOM)

### 🔧 MACHINE
| Component | What It Does |
|-----------|-------------|
| E2ETestGeneratorService | Orchestrates scenario → AI → test code pipeline |
| FlowAwareAnalyzer | Reads flow definitions (Skill 08) to derive test scenarios |
| ScenarioGenerator | Calls AI with scenario + env to produce executable tests |
| ResultCollector | Aggregates multi-step test results |

### 🔓 FREEDOM
| Component | What Users Control |
|-----------|-------------------|
| E2E scenarios | Step definitions, assertions, environments — dynamic docs |
| Environment configs | URLs, auth, feature flags — per environment |
| Custom assertions | User-defined validation rules |
| Retry policies | Per-step retry, timeout, backoff — config not code |

---

## Scope Isolation
- Scenario queries inject `ownerId` filter (non-admin)
- System scenarios: scope "system" — read-only for users
- Team scenarios shared via scope "team" + teamId
- Environment configs often team-scoped

## AI Agent Communication
1. **Discovery:** "What E2E scenarios exist for checkout?" → query xiigen-e2e-scenarios
2. **Auto-generation:** "Test the full order process" → agent reads flow definition (Skill 08), generates scenario doc
3. **Gap analysis:** Agent compares scenarios to flows, identifies untested paths
4. **Explanation:** Agent reads test results, explains failures in natural language

---

## Primary Interface (.NET 9)

```csharp
public interface IE2ETestGeneratorService
{
    Task<DataProcessResult<Dictionary<string, object>>> GenerateE2ETestsAsync(
        Dictionary<string, object> request, string userId, string traceId, CancellationToken ct = default);
    Task<DataProcessResult<Dictionary<string, object>>> GenerateFromFlowAsync(
        string flowId, string userId, string traceId, CancellationToken ct = default);
    Task<DataProcessResult<string>> StoreScenarioAsync(
        Dictionary<string, object> scenario, CancellationToken ct = default);
    Task<DataProcessResult<List<Dictionary<string, object>>>> SearchScenariosAsync(
        Dictionary<string, object> filter, string userId, bool isAdmin = false, CancellationToken ct = default);
    Task<DataProcessResult<string>> StoreEnvironmentAsync(
        Dictionary<string, object> envConfig, CancellationToken ct = default);
}
```

### DI: `services.AddSingleton<IE2ETestGeneratorService, E2ETestGeneratorService>();`

---

## Abstraction Extraction
E2E testing follows the same MACHINE/FREEDOM pattern as unit testing:
- MACHINE: scenario-to-test-code pipeline (same engine, different patterns)
- FREEDOM: scenario definitions (dynamic documents with steps + assertions)
- The flow-aware feature (reading Skill 08) is unique to E2E and enables auto-scenario generation.

## Dependencies
| Skill | Provides |
|-------|---------|
| 08 | Flow definitions for auto-scenario generation |
| 28 | Prompt templates for test generation |
| 29 | Shares test result infrastructure |
