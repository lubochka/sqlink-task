"""XIIGen Skill 30 — E2E Test Generator | Python
Generates end-to-end flow tests using httpx + pytest.
"""
from dataclasses import dataclass
from typing import Any
from core_interfaces import DataProcessResult

@dataclass
class E2ETestConfig:
    base_url: str = "http://localhost:8080"
    poll_interval: float = 1.0
    max_poll_attempts: int = 30
    timeout: float = 30.0

@dataclass
class E2ETestSuite:
    flow_id: str
    test_files: list[dict]
    total_scenarios: int

class E2ETestGenerator:
    async def generate_flow_tests(self, flow: dict, config: E2ETestConfig = None) -> DataProcessResult:
        config = config or E2ETestConfig()
        try:
            fid, fname = flow.get("id", "unknown"), flow.get("name", "Flow")
            steps = flow.get("steps", [])
            test_files = [
                {"path": f"test_{fid}_api.py", "content": self._gen_polling(fid, config), "scenarios": 3},
                {"path": f"test_{fid}_flow.py", "content": self._gen_flow(fid, steps), "scenarios": len(steps)},
                {"path": f"test_{fid}_recovery.py", "content": self._gen_recovery(fid), "scenarios": 2},
                {"path": f"test_{fid}_trace.py", "content": self._gen_trace(fid, len(steps)), "scenarios": 1},
            ]
            return DataProcessResult(success=True, data=E2ETestSuite(fid, test_files, sum(f["scenarios"] for f in test_files)))
        except Exception as e:
            return DataProcessResult(success=False, error=f"E2E generation failed: {e}")

    def _gen_polling(self, fid: str, cfg: E2ETestConfig) -> str:
        return f"""import httpx, pytest, asyncio
BASE = "{cfg.base_url}"

@pytest.mark.asyncio
async def test_submit_returns_trace_id():
    async with httpx.AsyncClient() as c:
        r = await c.post(f"{{BASE}}/api/v1/flows/{fid}/execute", json={{}})
        assert r.status_code == 202
        assert "traceId" in r.json()

@pytest.mark.asyncio
async def test_poll_until_complete():
    async with httpx.AsyncClient() as c:
        tid = (await c.post(f"{{BASE}}/api/v1/flows/{fid}/execute", json={{}})).json()["traceId"]
        for _ in range({cfg.max_poll_attempts}):
            await asyncio.sleep({cfg.poll_interval})
            r = await c.get(f"{{BASE}}/api/v1/traces/{{tid}}/status")
            if r.json()["status"] == "completed": break
        assert r.json()["status"] == "completed"

@pytest.mark.asyncio
async def test_invalid_flow_404():
    async with httpx.AsyncClient() as c:
        r = await c.post(f"{{BASE}}/api/v1/flows/invalid/execute", json={{}})
        assert r.status_code == 404
"""

    def _gen_flow(self, fid: str, steps: list) -> str:
        tests = "\n".join(f'@pytest.mark.asyncio\nasync def test_step_{i}_{s.get("type","step")}():\n    result = await get_step_result(trace_id, "{s.get("id","")}")\n    assert result["status"] == "completed"\n' for i, s in enumerate(steps))
        return f"import pytest\n{tests}"

    def _gen_recovery(self, fid: str) -> str:
        return "import pytest\n\n@pytest.mark.asyncio\nasync def test_retry(): pass\n\n@pytest.mark.asyncio\nasync def test_timeout(): pass"

    def _gen_trace(self, fid: str, n: int) -> str:
        return f"import pytest\n\n@pytest.mark.asyncio\nasync def test_trace_propagation():\n    # Verify all {n} steps share trace_id\n    pass"
