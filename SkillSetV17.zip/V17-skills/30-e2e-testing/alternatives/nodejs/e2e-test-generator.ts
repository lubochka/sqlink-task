// XIIGen Skill 30 — E2E Test Generator | Node.js/TypeScript
// Generates end-to-end flow tests using Supertest + Jest.
import { DataProcessResult } from '../../01-core-interfaces';

export interface E2ETestConfig {
  baseUrl: string;
  pollIntervalMs: number;
  maxPollAttempts: number;
  timeout: number;
}

export interface FlowDefinition {
  id: string;
  name: string;
  steps: { id: string; type: string; config: Record<string, unknown> }[];
}

export interface E2ETestSuite {
  flowId: string;
  testFiles: { path: string; content: string; scenarioCount: number }[];
  totalScenarios: number;
}

export class E2ETestGenerator {
  async generateFlowTests(flow: FlowDefinition, config: E2ETestConfig = {
    baseUrl: 'http://localhost:8080', pollIntervalMs: 1000, maxPollAttempts: 30, timeout: 30000
  }): Promise<DataProcessResult<E2ETestSuite>> {
    try {
      const testFiles = [
        { path: `${flow.id}.api.test.ts`, content: this.genPollingTest(flow, config), scenarioCount: 3 },
        { path: `${flow.id}.flow.test.ts`, content: this.genFlowTest(flow, config), scenarioCount: flow.steps.length },
        { path: `${flow.id}.recovery.test.ts`, content: this.genRecoveryTest(flow), scenarioCount: 2 },
        { path: `${flow.id}.trace.test.ts`, content: this.genTraceTest(flow), scenarioCount: 1 },
      ];
      return { success: true, data: { flowId: flow.id, testFiles, totalScenarios: testFiles.reduce((s, f) => s + f.scenarioCount, 0) } };
    } catch (err) {
      return { success: false, error: `E2E generation failed: ${(err as Error).message}` };
    }
  }

  private genPollingTest(flow: FlowDefinition, config: E2ETestConfig): string {
    return `import request from 'supertest';
describe('${flow.name} - API Polling', () => {
  const BASE = '${config.baseUrl}';
  it('submits job and receives trace ID', async () => {
    const res = await request(BASE).post('/api/v1/flows/${flow.id}/execute').send({}).expect(202);
    expect(res.body.traceId).toBeDefined();
  });
  it('polls until result is ready', async () => {
    const { traceId } = (await request(BASE).post('/api/v1/flows/${flow.id}/execute').send({})).body;
    let status = 'pending';
    for (let i = 0; i < ${config.maxPollAttempts} && status !== 'completed'; i++) {
      await new Promise(r => setTimeout(r, ${config.pollIntervalMs}));
      const poll = await request(BASE).get('/api/v1/traces/' + traceId + '/status');
      status = poll.body.status;
    }
    expect(status).toBe('completed');
  });
  it('returns 404 for invalid flow', async () => {
    await request(BASE).post('/api/v1/flows/invalid/execute').send({}).expect(404);
  });
});`;
  }

  private genFlowTest(flow: FlowDefinition, config: E2ETestConfig): string {
    const stepTests = flow.steps.map((s, i) =>
      `  it('step ${i+1}: ${s.type} completes', async () => {
    const result = await getStepResult(traceId, '${s.id}');
    expect(result.status).toBe('completed');
    expect(result.output).toBeDefined();
  });`).join('\n');
    return `describe('${flow.name} - Flow Sequence', () => {\n${stepTests}\n});`;
  }

  private genRecoveryTest(flow: FlowDefinition): string {
    return `describe('${flow.name} - Recovery', () => {
  it('retries failed step', async () => { /* mock failure, verify retry */ });
  it('handles timeout', async () => { /* short timeout, verify error */ });
});`;
  }

  private genTraceTest(flow: FlowDefinition): string {
    return `describe('${flow.name} - Trace', () => {
  it('propagates trace through all ${flow.steps.length} steps', async () => {
    const traceId = await submitAndWait('${flow.id}');
    const trace = await getFullTrace(traceId);
    expect(trace.steps).toHaveLength(${flow.steps.length});
    trace.steps.forEach(s => expect(s.traceId).toBe(traceId));
  });
});`;
  }
}
