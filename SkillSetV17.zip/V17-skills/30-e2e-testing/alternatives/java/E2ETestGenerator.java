// XIIGen Skill 30 — E2E Test Generator | Java / Spring Boot
package com.xiigen.skills.e2etesting;
import com.xiigen.core.interfaces.DataProcessResult;
import java.util.*;

public class E2ETestGenerator {
    public record E2ETestConfig(String baseUrl, int pollIntervalMs, int maxPollAttempts, int timeout) {
        public E2ETestConfig() { this("http://localhost:8080", 1000, 30, 30000); }
    }
    public record E2ETestSuite(String flowId, List<Map<String,Object>> testFiles, int totalScenarios) {}

    public DataProcessResult<E2ETestSuite> generateFlowTests(Map<String,Object> flow, E2ETestConfig config) {
        if (config == null) config = new E2ETestConfig();
        try {
            String flowId = (String) flow.get("id");
            var steps = (List<Map<String,Object>>) flow.getOrDefault("steps", List.of());
            var testFiles = List.of(
                Map.<String,Object>of("path", flowId + "ApiTest.java", "content", genPollingTest(flowId, config), "scenarios", 3),
                Map.<String,Object>of("path", flowId + "FlowTest.java", "content", genFlowTest(flowId, steps), "scenarios", steps.size()),
                Map.<String,Object>of("path", flowId + "RecoveryTest.java", "content", genRecoveryTest(flowId), "scenarios", 2),
                Map.<String,Object>of("path", flowId + "TraceTest.java", "content", genTraceTest(flowId, steps.size()), "scenarios", 1)
            );
            int total = testFiles.stream().mapToInt(f -> (int) f.get("scenarios")).sum();
            return DataProcessResult.success(new E2ETestSuite(flowId, testFiles, total));
        } catch (Exception e) {
            return DataProcessResult.failure("E2E generation failed: " + e.getMessage());
        }
    }

    private String genPollingTest(String flowId, E2ETestConfig cfg) {
        return "@Test void submitReturnsTraceId() {\n" +
            "  given().body(\"{}\").post(\"/api/v1/flows/" + flowId + "/execute\").then().statusCode(202);\n" +
            "}\n@Test void pollUntilComplete() { /* poll with " + cfg.pollIntervalMs() + "ms interval */ }\n" +
            "@Test void invalidFlowReturns404() { given().post(\"/api/v1/flows/invalid/execute\").then().statusCode(404); }";
    }
    private String genFlowTest(String fid, List<Map<String,Object>> steps) {
        var sb = new StringBuilder();
        for (int i = 0; i < steps.size(); i++)
            sb.append("@Test void step").append(i).append("_").append(steps.get(i).get("type")).append("() { /* verify */ }\n");
        return sb.toString();
    }
    private String genRecoveryTest(String fid) { return "@Test void retry() {}\n@Test void timeout() {}"; }
    private String genTraceTest(String fid, int n) { return "@Test void tracePropagation() { /* verify " + n + " steps */ }"; }
}
