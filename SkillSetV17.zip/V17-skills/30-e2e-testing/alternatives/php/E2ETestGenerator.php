<?php
// XIIGen Skill 30 — E2E Test Generator | PHP / Laravel
namespace XIIGen\Skills\E2ETesting;
use XIIGen\Core\Interfaces\DataProcessResult;

class E2ETestConfig {
    public function __construct(
        public string $baseUrl = 'http://localhost:8080',
        public int $pollIntervalMs = 1000,
        public int $maxPollAttempts = 30,
    ) {}
}

class E2ETestGenerator {
    public function generateFlowTests(array $flow, ?E2ETestConfig $config = null): DataProcessResult {
        $config ??= new E2ETestConfig();
        try {
            $fid = $flow['id'] ?? 'unknown';
            $steps = $flow['steps'] ?? [];
            $testFiles = [
                ['path' => "{$fid}ApiTest.php", 'content' => $this->genPollingTest($fid, $config), 'scenarios' => 3],
                ['path' => "{$fid}FlowTest.php", 'content' => $this->genFlowTest($fid, $steps), 'scenarios' => count($steps)],
                ['path' => "{$fid}RecoveryTest.php", 'content' => $this->genRecoveryTest($fid), 'scenarios' => 2],
                ['path' => "{$fid}TraceTest.php", 'content' => $this->genTraceTest($fid, count($steps)), 'scenarios' => 1],
            ];
            $total = array_sum(array_column($testFiles, 'scenarios'));
            return DataProcessResult::success(['flowId' => $fid, 'testFiles' => $testFiles, 'totalScenarios' => $total]);
        } catch (\Throwable $e) {
            return DataProcessResult::failure("E2E generation failed: " . $e->getMessage());
        }
    }

    private function genPollingTest(string $fid, E2ETestConfig $cfg): string {
        return "<?php\nclass ApiTest extends TestCase {\n    public function test_submit() { \$this->postJson('/api/v1/flows/$fid/execute', [])->assertStatus(202)->assertJsonStructure(['traceId']); }\n    public function test_poll() { /* poll loop */ }\n    public function test_invalid_404() { \$this->postJson('/api/v1/flows/invalid/execute', [])->assertStatus(404); }\n}";
    }
    private function genFlowTest(string $fid, array $steps): string {
        $tests = implode("\n", array_map(fn($s, $i) => "    public function test_step_{$i}() { /* verify */ }", $steps, array_keys($steps)));
        return "<?php\nclass FlowTest extends TestCase {\n$tests\n}";
    }
    private function genRecoveryTest(string $fid): string { return "<?php\nclass RecoveryTest extends TestCase { public function test_retry() {} public function test_timeout() {} }"; }
    private function genTraceTest(string $fid, int $n): string { return "<?php\nclass TraceTest extends TestCase { public function test_trace() { /* $n steps */ } }"; }
}
