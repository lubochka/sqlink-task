// XIIGen.Quality/E2ETesting/E2ETestGeneratorService.cs — Skill 30 | .NET 9
// MACHINE: Scenario → AI → test code pipeline + flow-aware analysis
// FREEDOM: Scenarios, environments, step definitions — dynamic documents
using System.Text.Json;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Quality.E2ETesting;

public interface IE2ETestGeneratorService
{
    Task<DataProcessResult<Dictionary<string, object>>> GenerateE2ETestsAsync(
        Dictionary<string, object> request, string userId, string traceId, CancellationToken ct = default);
    Task<DataProcessResult<Dictionary<string, object>>> GenerateFromFlowAsync(
        string flowId, string userId, string traceId, CancellationToken ct = default);
    Task<DataProcessResult<string>> StoreScenarioAsync(
        Dictionary<string, object> scenario, CancellationToken ct = default);
    Task<DataProcessResult<List<Dictionary<string, object>>>> SearchScenariosAsync(
        Dictionary<string, object> filter, string userId, bool isAdmin = false, CancellationToken ct = default);
    Task<DataProcessResult<string>> StoreEnvironmentAsync(
        Dictionary<string, object> envConfig, CancellationToken ct = default);
    Task<DataProcessResult<List<Dictionary<string, object>>>> SearchEnvironmentsAsync(
        Dictionary<string, object> filter, string userId, bool isAdmin = false, CancellationToken ct = default);
}

public sealed class E2ETestGeneratorService : IE2ETestGeneratorService
{
    private const string ScenarioIndex = "xiigen-e2e-scenarios";
    private const string ResultIndex = "xiigen-e2e-results";
    private const string EnvIndex = "xiigen-e2e-environments";

    private readonly IDataStore _db;
    private readonly IObjectProcessor _processor;
    private readonly IAiProvider _ai;
    private readonly IPromptTemplateService _prompts;
    private readonly IFlowDefinitionService _flows;
    private readonly ILogger<E2ETestGeneratorService> _logger;

    public E2ETestGeneratorService(
        IDataStore db, IObjectProcessor processor, IAiProvider ai,
        IPromptTemplateService prompts, IFlowDefinitionService flows,
        ILogger<E2ETestGeneratorService> logger)
    {
        _db = db; _processor = processor; _ai = ai;
        _prompts = prompts; _flows = flows; _logger = logger;
    }

    public async Task<DataProcessResult<Dictionary<string, object>>> GenerateE2ETestsAsync(
        Dictionary<string, object> request, string userId, string traceId, CancellationToken ct = default)
    {
        try
        {
            var scenarioId = GetStr(request, "scenarioId");
            var framework = GetStr(request, "testFramework", "playwright");
            var envId = GetStr(request, "environmentId", "default");

            // Load scenario (FREEDOM doc)
            var scenario = await _db.GetByIdAsync(ScenarioIndex, scenarioId, ct);
            if (!scenario.IsSuccess)
                return DataProcessResult<Dictionary<string, object>>.Fail("Scenario not found");

            // Load environment config (FREEDOM doc)
            var env = await _db.GetByIdAsync(EnvIndex, envId, ct);
            var envData = env.IsSuccess ? env.Data : new Dictionary<string, object>();

            // Build prompt
            var vars = new Dictionary<string, object>
            {
                ["scenario"] = JsonSerializer.Serialize(scenario.Data),
                ["testFramework"] = framework,
                ["environment"] = JsonSerializer.Serialize(envData),
                ["sourceCode"] = GetStr(request, "sourceCode", ""),
                ["language"] = GetStr(request, "language", "typescript")
            };

            var prompt = await _prompts.ResolveWithFeedbackAsync("sys-test-gen", vars, traceId, ct: ct);
            if (!prompt.IsSuccess)
                return DataProcessResult<Dictionary<string, object>>.Fail(prompt.Error);

            var aiResult = await _ai.GenerateAsync(prompt.Data, ct);
            if (!aiResult.IsSuccess)
                return DataProcessResult<Dictionary<string, object>>.Fail(aiResult.Error);

            var result = new Dictionary<string, object>
            {
                ["id"] = $"e2e-{traceId}",
                ["traceId"] = traceId,
                ["scenarioId"] = scenarioId,
                ["framework"] = framework,
                ["generatedCode"] = aiResult.Data,
                ["ownerId"] = userId,
                ["status"] = "generated",
                ["createdAt"] = DateTime.UtcNow
            };
            await _db.StoreAsync(ResultIndex, result["id"].ToString()!, result, ct: ct);
            return DataProcessResult<Dictionary<string, object>>.Ok(result);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[Skill30] GenerateE2ETestsAsync failed");
            return DataProcessResult<Dictionary<string, object>>.Fail(ex.Message);
        }
    }

    public async Task<DataProcessResult<Dictionary<string, object>>> GenerateFromFlowAsync(
        string flowId, string userId, string traceId, CancellationToken ct = default)
    {
        try
        {
            // Read flow definition (Skill 08) to derive scenarios
            var flow = await _flows.GetFlowAsync(flowId, ct);
            if (!flow.IsSuccess)
                return DataProcessResult<Dictionary<string, object>>.Fail("Flow not found");

            // Use AI to analyze flow and generate E2E scenario
            var vars = new Dictionary<string, object>
            {
                ["flowDefinition"] = JsonSerializer.Serialize(flow.Data),
                ["sourceCode"] = "",
                ["language"] = "typescript",
                ["testFramework"] = "playwright"
            };

            var prompt = await _prompts.ResolveWithFeedbackAsync("sys-test-gen", vars, traceId, ct: ct);
            if (!prompt.IsSuccess)
                return DataProcessResult<Dictionary<string, object>>.Fail(prompt.Error);

            var aiResult = await _ai.GenerateAsync(
                $"Analyze this flow definition and generate a comprehensive E2E test scenario:\n\n{prompt.Data}", ct);

            var scenario = new Dictionary<string, object>
            {
                ["id"] = $"auto-{flowId}-{traceId}",
                ["flowId"] = flowId,
                ["generatedScenario"] = aiResult.IsSuccess ? aiResult.Data : "",
                ["ownerId"] = userId,
                ["scope"] = "private",
                ["autoGenerated"] = true,
                ["createdAt"] = DateTime.UtcNow
            };

            await _db.StoreAsync(ScenarioIndex, scenario["id"].ToString()!, scenario, ct: ct);
            return DataProcessResult<Dictionary<string, object>>.Ok(scenario);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[Skill30] GenerateFromFlowAsync failed");
            return DataProcessResult<Dictionary<string, object>>.Fail(ex.Message);
        }
    }

    public async Task<DataProcessResult<string>> StoreScenarioAsync(
        Dictionary<string, object> scenario, CancellationToken ct = default)
    {
        var processed = _processor.ParseObjectAlternative(scenario);
        processed.TryAdd("id", Guid.NewGuid().ToString());
        processed.TryAdd("createdAt", DateTime.UtcNow);
        processed["updatedAt"] = DateTime.UtcNow;
        processed.TryAdd("scope", "private");
        processed.TryAdd("testType", "e2e");

        var id = processed["id"].ToString()!;
        var r = await _db.StoreAsync(ScenarioIndex, id, processed, ct: ct);
        return r.IsSuccess ? DataProcessResult<string>.Ok(id) : DataProcessResult<string>.Fail(r.Error);
    }

    public async Task<DataProcessResult<List<Dictionary<string, object>>>> SearchScenariosAsync(
        Dictionary<string, object> filter, string userId, bool isAdmin = false, CancellationToken ct = default)
    {
        var scoped = InjectScope(filter, userId, isAdmin);
        var sf = _processor.BuildSearchFilter(scoped);
        return await _db.SearchAsync(ScenarioIndex, sf, ct: ct);
    }

    public async Task<DataProcessResult<string>> StoreEnvironmentAsync(
        Dictionary<string, object> envConfig, CancellationToken ct = default)
    {
        var processed = _processor.ParseObjectAlternative(envConfig);
        processed.TryAdd("id", Guid.NewGuid().ToString());
        processed["updatedAt"] = DateTime.UtcNow;
        var id = processed["id"].ToString()!;
        var r = await _db.StoreAsync(EnvIndex, id, processed, ct: ct);
        return r.IsSuccess ? DataProcessResult<string>.Ok(id) : DataProcessResult<string>.Fail(r.Error);
    }

    public async Task<DataProcessResult<List<Dictionary<string, object>>>> SearchEnvironmentsAsync(
        Dictionary<string, object> filter, string userId, bool isAdmin = false, CancellationToken ct = default)
    {
        var scoped = InjectScope(filter, userId, isAdmin);
        var sf = _processor.BuildSearchFilter(scoped);
        return await _db.SearchAsync(EnvIndex, sf, ct: ct);
    }

    private static Dictionary<string, object> InjectScope(Dictionary<string, object> f, string userId, bool isAdmin)
    {
        var s = new Dictionary<string, object>(f);
        if (!isAdmin && !string.IsNullOrEmpty(userId)) s["_scope_userId"] = userId;
        return s;
    }

    private static string GetStr(Dictionary<string, object> d, string k, string fb = "") =>
        d.TryGetValue(k, out var v) ? (v switch { string s => s, JsonElement je => je.ToString(), _ => v?.ToString() ?? fb }) : fb;
}

public static class E2ETestingExtensions
{
    public static IServiceCollection AddE2ETesting(this IServiceCollection services)
    {
        services.AddSingleton<IE2ETestGeneratorService, E2ETestGeneratorService>();
        return services;
    }
}
