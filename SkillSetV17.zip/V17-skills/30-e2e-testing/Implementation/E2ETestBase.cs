// XIIGen.Testing.E2E/E2ETestBase.cs | .NET 9 | Skill 30
// End-to-end testing using Testcontainers for real infrastructure.
// Tests the full pipeline: API → Flow Orchestrator → AI → Review → Result
// NuGet: Testcontainers, Testcontainers.Elasticsearch, Testcontainers.Redis,
//        Microsoft.AspNetCore.Mvc.Testing, xUnit

using System.Net.Http.Json;
using System.Text.Json;
using DotNet.Testcontainers.Builders;
using DotNet.Testcontainers.Containers;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.DependencyInjection;
using Testcontainers.Elasticsearch;
using Testcontainers.Redis;
using Xunit;
using FluentAssertions;

namespace XIIGen.Testing.E2E;

// ═══════════════════════════════════════════════════════
// E2E TEST BASE - Spins up real ES + Redis via containers
// ═══════════════════════════════════════════════════════

public abstract class E2ETestBase : IAsyncLifetime
{
    protected ElasticsearchContainer EsContainer;
    protected RedisContainer RedisContainer;
    protected HttpClient Client;
    protected WebApplicationFactory<Program> Factory;

    public async Task InitializeAsync()
    {
        // Start infrastructure containers
        EsContainer = new ElasticsearchBuilder()
            .WithImage("docker.elastic.co/elasticsearch/elasticsearch:8.12.0")
            .WithEnvironment("discovery.type", "single-node")
            .WithEnvironment("xpack.security.enabled", "false")
            .WithPortBinding(9200, true)
            .Build();

        RedisContainer = new RedisBuilder()
            .WithImage("redis:7-alpine")
            .WithPortBinding(6379, true)
            .Build();

        await Task.WhenAll(EsContainer.StartAsync(), RedisContainer.StartAsync());

        // Create test API client with real containers
        Factory = new WebApplicationFactory<Program>()
            .WithWebHostBuilder(builder =>
            {
                builder.UseEnvironment("Testing");
                builder.ConfigureServices(services =>
                {
                    // Override DI with real container connections
                    services.AddSingleton<IDatabaseService>(sp =>
                        new ElasticsearchDatabaseService(
                            $"http://{EsContainer.Hostname}:{EsContainer.GetMappedPublicPort(9200)}"));

                    services.AddSingleton<IQueueService>(sp =>
                        new RedisQueueService(
                            $"{RedisContainer.Hostname}:{RedisContainer.GetMappedPublicPort(6379)}"));

                    // Use mock AI provider for deterministic tests
                    services.AddSingleton<IAiProvider>(sp => new MockAiProvider());
                });
            });

        Client = Factory.CreateClient();
    }

    public async Task DisposeAsync()
    {
        Client?.Dispose();
        Factory?.Dispose();
        if (EsContainer != null) await EsContainer.DisposeAsync();
        if (RedisContainer != null) await RedisContainer.DisposeAsync();
    }

    // ─── Helper Methods ──────────────────────────────────

    protected async Task<string> TriggerFlowAsync(string flowId, object body)
    {
        var response = await Client.PostAsJsonAsync("/api/flow/trigger", new
        {
            flowId, body, traceId = Guid.NewGuid().ToString()
        });
        response.EnsureSuccessStatusCode();
        var result = await response.Content.ReadFromJsonAsync<JsonElement>();
        return result.GetProperty("traceId").GetString();
    }

    protected async Task<FlowStatusResponse> PollUntilCompleteAsync(string traceId,
        TimeSpan? timeout = null, CancellationToken ct = default)
    {
        timeout ??= TimeSpan.FromSeconds(30);
        var deadline = DateTime.UtcNow + timeout.Value;
        var backoff = new[] { 500, 1000, 2000, 5000 };
        var attempt = 0;

        while (DateTime.UtcNow < deadline)
        {
            var response = await Client.GetAsync($"/api/flow/{traceId}/status", ct);
            response.EnsureSuccessStatusCode();
            var status = await response.Content.ReadFromJsonAsync<FlowStatusResponse>(ct);

            if (status.Status == "Completed" || status.Status == "Failed")
                return status;

            await Task.Delay(backoff[Math.Min(attempt++, backoff.Length - 1)], ct);
        }

        throw new TimeoutException($"Flow {traceId} did not complete within {timeout}");
    }

    protected async Task SubmitFeedbackAsync(string traceId, string stepId, string rating, string text = null)
    {
        var response = await Client.PostAsJsonAsync(
            $"/api/flow/{traceId}/steps/{stepId}/feedback",
            new { rating, text });
        response.EnsureSuccessStatusCode();
    }

    protected async Task WaitForElasticsearchAsync(int maxWaitMs = 10000)
    {
        var deadline = DateTime.UtcNow.AddMilliseconds(maxWaitMs);
        while (DateTime.UtcNow < deadline)
        {
            try
            {
                var resp = await Client.GetAsync("/health");
                if (resp.IsSuccessStatusCode) return;
            }
            catch { /* retry */ }
            await Task.Delay(500);
        }
    }
}

// ═══════════════════════════════════════════════════════
// E2E TEST SCENARIOS
// ═══════════════════════════════════════════════════════

public class FlowPipelineE2ETests : E2ETestBase
{
    [Fact]
    public async Task FullPipeline_FigmaToCode_CompletesSuccessfully()
    {
        // Arrange
        await WaitForElasticsearchAsync();

        // Act: Trigger figma-to-code flow
        var traceId = await TriggerFlowAsync("figma-to-react-v1", new
        {
            figmaNodes = new[] {
                new { id = "frame-1", type = "FRAME", name = "Header", width = 1200, height = 80 }
            }
        });

        // Poll until complete
        var result = await PollUntilCompleteAsync(traceId);

        // Assert
        result.Status.Should().Be("Completed");
        result.Steps.Should().NotBeEmpty();
        result.Steps.Should().AllSatisfy(s => s.Status.Should().Be("Completed"));
    }

    [Fact]
    public async Task FlowTrigger_InvalidFlowId_Returns404()
    {
        var response = await Client.PostAsJsonAsync("/api/flow/trigger", new
        {
            flowId = "nonexistent-flow", body = new { }, traceId = Guid.NewGuid().ToString()
        });
        response.StatusCode.Should().Be(System.Net.HttpStatusCode.NotFound);
    }

    [Fact]
    public async Task FeedbackLoop_SubmitFeedback_StoredAndRetrievable()
    {
        await WaitForElasticsearchAsync();
        var traceId = await TriggerFlowAsync("figma-to-react-v1", new { figmaNodes = new[] { new { id = "f1" } } });
        var result = await PollUntilCompleteAsync(traceId);

        // Submit feedback on first step
        var stepId = result.Steps.First().StepId;
        await SubmitFeedbackAsync(traceId, stepId, "Positive", "Great flexbox usage!");

        // Verify feedback stored
        var feedbackResp = await Client.GetAsync($"/api/flow/{traceId}/steps/{stepId}/feedback");
        feedbackResp.EnsureSuccessStatusCode();
    }

    [Fact]
    public async Task ConcurrentFlows_MultipleTraces_AllComplete()
    {
        await WaitForElasticsearchAsync();
        var tasks = Enumerable.Range(1, 5).Select(async i =>
        {
            var traceId = await TriggerFlowAsync("figma-to-react-v1",
                new { figmaNodes = new[] { new { id = $"f-{i}" } } });
            return await PollUntilCompleteAsync(traceId, TimeSpan.FromSeconds(60));
        });

        var results = await Task.WhenAll(tasks);
        results.Should().AllSatisfy(r => r.Status.Should().Be("Completed"));
    }

    [Fact]
    public async Task HealthCheck_AllServices_Healthy()
    {
        var response = await Client.GetAsync("/health");
        response.EnsureSuccessStatusCode();
        var health = await response.Content.ReadFromJsonAsync<JsonElement>();
        health.GetProperty("status").GetString().Should().Be("Healthy");
    }
}

// ═══════════════════════════════════════════════════════
// DATABASE SERVICE E2E TESTS (runs against real ES)
// ═══════════════════════════════════════════════════════

public class ElasticsearchE2ETests : E2ETestBase
{
    [Fact]
    public async Task StoreAndSearch_DynamicDocument_Works()
    {
        var esUri = $"http://{EsContainer.Hostname}:{EsContainer.GetMappedPublicPort(9200)}";
        var db = new ElasticsearchDatabaseService(esUri);

        await db.StoreDocumentAsync("e2e-test", "test", "doc-1",
            new { Name = "Widget", Category = "Tools", Price = 29.99 });
        await Task.Delay(1000); // ES refresh

        var results = await db.SearchDocumentsAsync<JsonElement>("e2e-test", "test",
            new SearchOptions { Conditions = [new SearchCondition { Property = "Category", Value = "Tools" }] });
        results.Data.Should().NotBeEmpty();
    }

    [Fact]
    public async Task BulkUpsert_1000Documents_CompletesUnder5Seconds()
    {
        var esUri = $"http://{EsContainer.Hostname}:{EsContainer.GetMappedPublicPort(9200)}";
        var db = new ElasticsearchDatabaseService(esUri);

        var docs = Enumerable.Range(1, 1000).Select(i =>
            ($"bulk-{i}", (object)new { Name = $"Item {i}", Value = i })).ToList();

        var sw = System.Diagnostics.Stopwatch.StartNew();
        await db.BulkUpsertAsync("e2e-bulk", "test", docs);
        sw.Stop();

        sw.Elapsed.Should().BeLessThan(TimeSpan.FromSeconds(5));
    }
}

// ═══════════════════════════════════════════════════════
// MOCK AI PROVIDER FOR DETERMINISTIC TESTS
// ═══════════════════════════════════════════════════════

public class MockAiProvider : IAiProvider
{
    public string ProviderName => "mock";
    public Task<AiResponse> ExecuteAsync(AiRequest request, CancellationToken ct = default)
    {
        var response = request.Prompt.Contains("review")
            ? "<review><scores><overall>8/10</overall></scores><verdict>approve</verdict></review>"
            : "<html><div class=\"component\">Generated Component</div></html>";

        return Task.FromResult(new AiResponse
        {
            Content = response, Model = "mock-model", TokensIn = 100, TokensOut = 200
        });
    }
}

// ─── Response Models ─────────────────────────────────────
public class FlowStatusResponse
{
    public string TraceId { get; set; }
    public string Status { get; set; }
    public double Progress { get; set; }
    public string CurrentStep { get; set; }
    public List<StepStatusResponse> Steps { get; set; } = [];
}
public class StepStatusResponse
{
    public string StepId { get; set; }
    public string Status { get; set; }
    public string NodeType { get; set; }
}

// Placeholder references
public class Program { }
public class ElasticsearchDatabaseService : IDatabaseService
{
    public ElasticsearchDatabaseService(string uri) { }
    // Interface implementation stubs
    public DatabaseType DatabaseType => DatabaseType.Elasticsearch;
    public Task<DataProcessResult<object>> StoreDocumentAsync(string i, string p, string id, object d, bool n = true, CancellationToken c = default) => Task.FromResult(DataProcessResult<object>.Success(d));
    public Task<DataProcessResult<T>> GetDocumentAsync<T>(string i, string p, string id, CancellationToken c = default) => Task.FromResult(DataProcessResult<T>.Success(default));
    public Task<DataProcessResult<List<T>>> SearchDocumentsAsync<T>(string i, string p, SearchOptions o, CancellationToken c = default) => Task.FromResult(DataProcessResult<List<T>>.Success([]));
    public Task<DataProcessResult<bool>> DeleteDocumentAsync(string i, string p, string id, CancellationToken c = default) => Task.FromResult(DataProcessResult<bool>.Success(true));
    public Task<DataProcessResult<BulkResult>> BulkUpsertAsync(string i, string p, List<(string, object)> d, CancellationToken c = default) => Task.FromResult(DataProcessResult<BulkResult>.Success(new BulkResult()));
    public Task<bool> IndexExistsAsync(string i, string p, CancellationToken c = default) => Task.FromResult(true);
    public Task<DataProcessResult<Dictionary<string, long>>> GetFiltersAsync(string i, string p, string f, CancellationToken c = default) => Task.FromResult(DataProcessResult<Dictionary<string, long>>.Success([]));
}
public class RedisQueueService : IQueueService
{
    public RedisQueueService(string conn) { }
    public QueueType QueueType => QueueType.Redis;
    public Task<DataProcessResult<string>> EnqueueAsync<T>(string q, T m, Dictionary<string, string> h = null, int p = 0, CancellationToken c = default) => Task.FromResult(DataProcessResult<string>.Success("id"));
    public IAsyncEnumerable<QueueMessage<T>> ConsumeAsync<T>(string q, string g, string cid = null, CancellationToken c = default) => AsyncEnumerable.Empty<QueueMessage<T>>();
    public Task<DataProcessResult<bool>> AcknowledgeAsync(string q, string g, string mid, CancellationToken c = default) => Task.FromResult(DataProcessResult<bool>.Success(true));
}
