"""
XIIGen Skill 38: Resource Management & Performance Optimization — Python Alternative
Profiling, caching strategy, connection pooling, AI-assisted optimization
DNA: DataProcessResult, dynamic documents, BuildSearchFilter, scope isolation
"""
import os
import time
import psutil
import json
from dataclasses import dataclass, field, asdict
from typing import Any, Optional
from datetime import datetime, timezone


@dataclass
class DataProcessResult:
    success: bool
    data: Any
    message: str


@dataclass
class CpuMetrics:
    usage_percent: float
    load_avg_1m: float
    load_avg_5m: float
    cores: int


@dataclass
class MemoryMetrics:
    used_mb: int
    total_mb: int
    heap_used_mb: int
    heap_total_mb: int
    rss_mb: int


@dataclass
class EndpointMetrics:
    path: str
    method: str
    p50_ms: float
    p95_ms: float
    p99_ms: float
    request_count: int
    error_rate: float


@dataclass
class QueryMetrics:
    index: str
    query: str
    avg_ms: float
    count: int
    slowest_ms: float


@dataclass
class ProfilingSnapshot:
    id: str
    scope_id: str
    service_id: str
    cpu: CpuMetrics
    memory: MemoryMetrics
    endpoints: list
    slow_queries: list
    captured_at: str
    duration_ms: int


@dataclass
class OptimizationRecommendation:
    id: str
    scope_id: str
    service_id: str
    category: str  # cpu, memory, query, cache, pool, network
    severity: str  # critical, high, medium, low
    description: str
    implementation: str
    estimated_impact: float
    status: str = "pending"
    created_at: str = ""


@dataclass
class CacheConfig:
    key: str
    layer: str  # L1-memory, L2-redis, L3-cdn
    ttl_seconds: int
    invalidation_event: str
    max_entries: int
    enabled: bool


@dataclass
class PoolInfo:
    name: str
    pool_type: str
    active: int
    idle: int
    max_size: int
    waiting_requests: int
    avg_acquire_ms: float


class OptimizationService:
    """
    Resource management and performance optimization service.
    DNA: All data as dynamic documents, DataProcessResult, BuildSearchFilter.
    """

    SNAPSHOTS_INDEX = "profiling-snapshots"
    RECOMMENDATIONS_INDEX = "optimization-recommendations"

    def __init__(self, db, logger=None, ai_provider=None):
        self._db = db
        self._logger = logger
        self._ai_provider = ai_provider

    async def profile_service(
        self, scope_id: str, service_id: str, duration_ms: int = 30000
    ) -> DataProcessResult:
        """Profile a service. DNA: DataProcessResult wrapping snapshot."""
        try:
            start = time.time()

            # CPU metrics via psutil
            cpu_percent = psutil.cpu_percent(interval=1)
            load_avg = os.getloadavg()
            cpu = CpuMetrics(
                usage_percent=cpu_percent,
                load_avg_1m=load_avg[0],
                load_avg_5m=load_avg[1],
                cores=psutil.cpu_count(),
            )

            # Memory metrics
            vm = psutil.virtual_memory()
            proc = psutil.Process()
            mem_info = proc.memory_info()
            memory = MemoryMetrics(
                used_mb=int(vm.used / 1048576),
                total_mb=int(vm.total / 1048576),
                heap_used_mb=int(mem_info.rss / 1048576),
                heap_total_mb=int(vm.total / 1048576),
                rss_mb=int(mem_info.rss / 1048576),
            )

            # Slow queries from ES log
            slow_queries = await self._get_slow_queries(scope_id, service_id)

            snapshot = ProfilingSnapshot(
                id=f"prof-{service_id}-{int(time.time() * 1000)}",
                scope_id=scope_id,
                service_id=service_id,
                cpu=cpu,
                memory=memory,
                endpoints=[],
                slow_queries=slow_queries,
                captured_at=datetime.now(timezone.utc).isoformat(),
                duration_ms=int((time.time() - start) * 1000),
            )

            # DNA: Store as dynamic document
            await self._db.upsert(self.SNAPSHOTS_INDEX, asdict(snapshot))
            if self._logger:
                self._logger.info(
                    f"Profiled {service_id}: CPU {cpu.usage_percent:.1f}%, "
                    f"Mem {memory.rss_mb}MB RSS"
                )

            return DataProcessResult(True, asdict(snapshot), f"Profiled {service_id}")
        except Exception as e:
            if self._logger:
                self._logger.error(f"Profiling failed: {e}")
            return DataProcessResult(False, {}, str(e))

    async def analyze(self, scope_id: str, service_id: str) -> DataProcessResult:
        """Analyze profiling data and generate recommendations. DNA: DataProcessResult."""
        try:
            snapshots = await self._db.query(
                self.SNAPSHOTS_INDEX,
                {"bool": {"must": [
                    {"term": {"scope_id": scope_id}},
                    {"term": {"service_id": service_id}},
                ]}},
                {"sort": [{"captured_at": "desc"}], "size": 1},
            )

            if not snapshots:
                return DataProcessResult(False, [], "No profiling data. Run profile_service first.")

            snapshot = snapshots[0]
            recommendations = []

            # CPU analysis
            cpu_usage = snapshot.get("cpu", {}).get("usage_percent", 0)
            if cpu_usage > 80:
                recommendations.append(self._create_rec(
                    scope_id, service_id, "cpu", "critical",
                    f"CPU usage at {cpu_usage:.1f}% — service is CPU-bound",
                    "Profile hot paths with py-spy, consider async I/O or multiprocessing", 0.4,
                ))
            elif cpu_usage > 60:
                recommendations.append(self._create_rec(
                    scope_id, service_id, "cpu", "medium",
                    f"CPU usage at {cpu_usage:.1f}% — approaching threshold",
                    "Cache computed results, review loop optimizations", 0.2,
                ))

            # Memory analysis
            heap_used = snapshot.get("memory", {}).get("heap_used_mb", 0)
            heap_total = snapshot.get("memory", {}).get("heap_total_mb", 1)
            heap_pct = (heap_used / heap_total) * 100 if heap_total else 0
            if heap_pct > 85:
                recommendations.append(self._create_rec(
                    scope_id, service_id, "memory", "critical",
                    f"Memory usage at {heap_pct:.1f}% — risk of OOM",
                    "Use tracemalloc to identify leaks, optimize data structures", 0.5,
                ))

            # Slow ES queries
            for sq in snapshot.get("slow_queries", []):
                avg_ms = sq.get("avg_ms", 0)
                if avg_ms > 500:
                    recommendations.append(self._create_rec(
                        scope_id, service_id, "query", "high",
                        f"Slow ES query on '{sq.get('index', '?')}': avg {avg_ms}ms",
                        "Add composite index, consider denormalization", 0.3,
                    ))

            # Store all recommendations
            for rec in recommendations:
                await self._db.upsert(self.RECOMMENDATIONS_INDEX, rec)

            return DataProcessResult(True, recommendations, f"{len(recommendations)} recommendations generated")
        except Exception as e:
            return DataProcessResult(False, [], str(e))

    async def get_ai_recommendations(
        self, scope_id: str, service_id: str
    ) -> DataProcessResult:
        """Use AI to generate optimization recommendations. DNA: DataProcessResult."""
        try:
            if not self._ai_provider:
                return DataProcessResult(False, [], "AI provider not configured")

            snapshots = await self._db.query(
                self.SNAPSHOTS_INDEX,
                {"bool": {"must": [
                    {"term": {"scope_id": scope_id}},
                    {"term": {"service_id": service_id}},
                ]}},
                {"sort": [{"captured_at": "desc"}], "size": 5},
            )

            prompt = (
                f"Analyze these profiling snapshots for microservice '{service_id}' "
                f"and return JSON array of optimization recommendations:\n"
                f"{json.dumps(snapshots, indent=2, default=str)}"
            )

            ai_result = await self._ai_provider.generate(prompt=prompt, format="json")
            parsed = json.loads(ai_result.get("content", "[]"))

            recommendations = [
                self._create_rec(
                    scope_id, service_id,
                    r.get("category", "cpu"), r.get("severity", "medium"),
                    r.get("description", "AI recommendation"),
                    r.get("implementation", "Review suggested change"),
                    r.get("impact", 0.2),
                )
                for r in parsed
            ]

            for rec in recommendations:
                await self._db.upsert(self.RECOMMENDATIONS_INDEX, rec)

            return DataProcessResult(True, recommendations, f"AI: {len(recommendations)} recommendations")
        except Exception as e:
            return DataProcessResult(False, [], str(e))

    async def configure_cache(
        self, scope_id: str, config: dict
    ) -> DataProcessResult:
        """Configure a cache entry. DNA: dynamic document."""
        try:
            doc = {**config, "scope_id": scope_id, "updated_at": datetime.now(timezone.utc).isoformat()}
            await self._db.upsert("cache-configs", doc)
            return DataProcessResult(True, config, f"Cache configured: {config.get('key')}")
        except Exception as e:
            return DataProcessResult(False, config, str(e))

    async def query_recommendations(self, **filters) -> DataProcessResult:
        """Query recommendations. DNA: BuildSearchFilter — skip empty values."""
        try:
            must = []
            for key in ("scope_id", "service_id", "category", "severity", "status"):
                val = filters.get(key)
                if val:
                    must.append({"term": {key: val}})

            date_from = filters.get("date_from")
            date_to = filters.get("date_to")
            if date_from or date_to:
                range_q = {}
                if date_from:
                    range_q["gte"] = date_from
                if date_to:
                    range_q["lte"] = date_to
                must.append({"range": {"created_at": range_q}})

            query = {"bool": {"must": must}} if must else {"match_all": {}}
            results = await self._db.query(self.RECOMMENDATIONS_INDEX, query)

            return DataProcessResult(True, results, f"Found {len(results)} recommendations")
        except Exception as e:
            return DataProcessResult(False, [], str(e))

    # --- Private ---

    async def _get_slow_queries(self, scope_id: str, service_id: str) -> list:
        try:
            return await self._db.query(
                "slow-query-log",
                {"bool": {"must": [
                    {"term": {"scope_id": scope_id}},
                    {"term": {"service_id": service_id}},
                ]}},
                {"sort": [{"avg_ms": "desc"}], "size": 10},
            )
        except Exception:
            return []

    def _create_rec(self, scope_id, service_id, category, severity, desc, impl, impact):
        return {
            "id": f"opt-{service_id}-{int(time.time() * 1000)}",
            "scope_id": scope_id,
            "service_id": service_id,
            "category": category,
            "severity": severity,
            "description": desc,
            "implementation": impl,
            "estimated_impact": impact,
            "status": "pending",
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
