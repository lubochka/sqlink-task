/**
 * XIIGen Skill 38: Resource Management & Performance Optimization — Node.js Alternative
 * Profiling, caching strategy, connection pooling, AI-assisted optimization
 * DNA: DataProcessResult, dynamic documents, BuildSearchFilter, scope isolation
 */
import { DataProcessResult, IDatabaseService } from '../../01-core-interfaces/alternatives/nodejs/core-interfaces';

// --- Models (DNA: dynamic documents, no fixed ORM) ---

interface ProfilingSnapshot {
  id: string; scopeId: string; serviceId: string;
  cpu: CpuMetrics; memory: MemoryMetrics;
  endpoints: EndpointMetrics[]; slowQueries: QueryMetrics[];
  capturedAt: string; durationMs: number;
}

interface CpuMetrics { usagePercent: number; loadAvg1m: number; loadAvg5m: number; cores: number; }
interface MemoryMetrics { usedMb: number; totalMb: number; heapUsedMb: number; heapTotalMb: number; rss: number; }
interface EndpointMetrics { path: string; method: string; p50Ms: number; p95Ms: number; p99Ms: number; requestCount: number; errorRate: number; }
interface QueryMetrics { index: string; query: string; avgMs: number; count: number; slowest: number; }

interface OptimizationRecommendation {
  id: string; scopeId: string; serviceId: string;
  category: 'cpu' | 'memory' | 'query' | 'cache' | 'pool' | 'network';
  severity: 'critical' | 'high' | 'medium' | 'low';
  description: string; implementation: string;
  estimatedImpact: number; status: 'pending' | 'applied' | 'dismissed';
  createdAt: string;
}

interface CacheConfig {
  key: string; layer: 'L1-memory' | 'L2-redis' | 'L3-cdn';
  ttlSeconds: number; invalidationEvent: string;
  maxEntries: number; enabled: boolean;
}

interface ConnectionPoolStatus {
  serviceId: string; pools: PoolInfo[];
  overallHealth: 'healthy' | 'degraded' | 'critical';
}

interface PoolInfo {
  name: string; type: 'elasticsearch' | 'redis' | 'http';
  active: number; idle: number; maxSize: number;
  waitingRequests: number; avgAcquireMs: number;
}

// --- Service ---

export class OptimizationService {
  private readonly SNAPSHOTS_INDEX = 'profiling-snapshots';
  private readonly RECOMMENDATIONS_INDEX = 'optimization-recommendations';

  constructor(
    private db: IDatabaseService,
    private logger: any,
    private aiProvider?: any
  ) {}

  /**
   * Profile a service for a given duration.
   * DNA: DataProcessResult wrapping profiling snapshot.
   */
  async profileService(scopeId: string, serviceId: string, durationMs: number = 30000): Promise<DataProcessResult<ProfilingSnapshot>> {
    try {
      const startTime = Date.now();

      // Collect CPU metrics
      const cpuUsage = process.cpuUsage();
      const loadAvg = require('os').loadavg();
      const cpu: CpuMetrics = {
        usagePercent: (cpuUsage.user + cpuUsage.system) / 1000000 * 100,
        loadAvg1m: loadAvg[0], loadAvg5m: loadAvg[1],
        cores: require('os').cpus().length
      };

      // Collect memory metrics
      const mem = process.memoryUsage();
      const osMem = require('os');
      const memory: MemoryMetrics = {
        usedMb: Math.round((osMem.totalmem() - osMem.freemem()) / 1048576),
        totalMb: Math.round(osMem.totalmem() / 1048576),
        heapUsedMb: Math.round(mem.heapUsed / 1048576),
        heapTotalMb: Math.round(mem.heapTotal / 1048576),
        rss: Math.round(mem.rss / 1048576)
      };

      // Query ES for slow queries on the service
      const slowQueries = await this.getSlowQueries(scopeId, serviceId);

      const snapshot: ProfilingSnapshot = {
        id: `prof-${serviceId}-${Date.now()}`, scopeId, serviceId,
        cpu, memory, endpoints: [], slowQueries,
        capturedAt: new Date().toISOString(),
        durationMs: Date.now() - startTime
      };

      // DNA: Store as dynamic document
      await this.db.upsert(this.SNAPSHOTS_INDEX, snapshot);
      this.logger?.info(`Profiled ${serviceId}: CPU ${cpu.usagePercent.toFixed(1)}%, Mem ${memory.heapUsedMb}MB heap`);

      return { success: true, data: snapshot, message: `Profiled ${serviceId} for ${durationMs}ms` };
    } catch (error: any) {
      this.logger?.error(`Profiling failed for ${serviceId}`, error);
      return { success: false, data: {} as ProfilingSnapshot, message: error.message };
    }
  }

  /**
   * Analyze a service and generate optimization recommendations.
   * DNA: DataProcessResult with list of recommendations.
   */
  async analyze(scopeId: string, serviceId: string): Promise<DataProcessResult<OptimizationRecommendation[]>> {
    try {
      // Get latest snapshot
      const snapshotResult = await this.db.query(this.SNAPSHOTS_INDEX, {
        bool: { must: [
          { term: { scopeId } }, { term: { serviceId } }
        ] }
      }, { sort: [{ capturedAt: 'desc' }], size: 1 });

      if (!snapshotResult?.length) {
        return { success: false, data: [], message: `No profiling data for ${serviceId}. Run profileService first.` };
      }

      const snapshot = snapshotResult[0] as ProfilingSnapshot;
      const recommendations: OptimizationRecommendation[] = [];

      // CPU analysis
      if (snapshot.cpu.usagePercent > 80) {
        recommendations.push(this.createRecommendation(scopeId, serviceId, 'cpu', 'critical',
          `CPU usage at ${snapshot.cpu.usagePercent.toFixed(1)}% — service is CPU-bound`,
          'Scale horizontally with HPA, profile hot code paths with clinic.js flame graph', 0.4));
      } else if (snapshot.cpu.usagePercent > 60) {
        recommendations.push(this.createRecommendation(scopeId, serviceId, 'cpu', 'medium',
          `CPU usage at ${snapshot.cpu.usagePercent.toFixed(1)}% — approaching threshold`,
          'Review compute-heavy operations, consider caching computed results', 0.2));
      }

      // Memory analysis
      const heapUsagePercent = (snapshot.memory.heapUsedMb / snapshot.memory.heapTotalMb) * 100;
      if (heapUsagePercent > 85) {
        recommendations.push(this.createRecommendation(scopeId, serviceId, 'memory', 'critical',
          `Heap usage at ${heapUsagePercent.toFixed(1)}% — risk of OOM`,
          'Increase --max-old-space-size, check for memory leaks with heapdump', 0.5));
      }

      // Slow query analysis
      for (const sq of snapshot.slowQueries) {
        if (sq.avgMs > 500) {
          recommendations.push(this.createRecommendation(scopeId, serviceId, 'query', 'high',
            `Slow ES query on index '${sq.index}': avg ${sq.avgMs}ms (${sq.count} calls)`,
            `Add composite index, consider denormalization, review query structure`, 0.3));
        }
      }

      // Store recommendations
      for (const rec of recommendations) {
        await this.db.upsert(this.RECOMMENDATIONS_INDEX, rec);
      }

      return { success: true, data: recommendations, message: `Generated ${recommendations.length} recommendations for ${serviceId}` };
    } catch (error: any) {
      return { success: false, data: [], message: error.message };
    }
  }

  /**
   * Get AI-powered recommendations by feeding profiling data to AI provider.
   * DNA: DataProcessResult with AI-generated suggestions.
   */
  async getAiRecommendations(scopeId: string, serviceId: string): Promise<DataProcessResult<OptimizationRecommendation[]>> {
    try {
      if (!this.aiProvider) {
        return { success: false, data: [], message: 'AI provider not configured' };
      }

      const snapshots = await this.db.query(this.SNAPSHOTS_INDEX, {
        bool: { must: [{ term: { scopeId } }, { term: { serviceId } }] }
      }, { sort: [{ capturedAt: 'desc' }], size: 5 });

      const prompt = `Analyze these ${snapshots.length} profiling snapshots for microservice "${serviceId}" and provide optimization recommendations as JSON array:\n${JSON.stringify(snapshots, null, 2)}`;

      const aiResult = await this.aiProvider.generate({ prompt, format: 'json' });
      const parsed = JSON.parse(aiResult.content || '[]');

      const recommendations: OptimizationRecommendation[] = parsed.map((r: any) =>
        this.createRecommendation(scopeId, serviceId, r.category || 'cpu', r.severity || 'medium',
          r.description || 'AI recommendation', r.implementation || 'Review suggested change', r.impact || 0.2));

      for (const rec of recommendations) {
        await this.db.upsert(this.RECOMMENDATIONS_INDEX, rec);
      }

      return { success: true, data: recommendations, message: `AI generated ${recommendations.length} recommendations` };
    } catch (error: any) {
      return { success: false, data: [], message: error.message };
    }
  }

  /**
   * Configure a cache entry.
   * DNA: DataProcessResult, dynamic document for cache config.
   */
  async configureCache(scopeId: string, config: CacheConfig): Promise<DataProcessResult<CacheConfig>> {
    try {
      const doc = { ...config, scopeId, updatedAt: new Date().toISOString() };
      await this.db.upsert('cache-configs', doc);
      return { success: true, data: config, message: `Cache configured: ${config.key} → ${config.layer} TTL=${config.ttlSeconds}s` };
    } catch (error: any) {
      return { success: false, data: config, message: error.message };
    }
  }

  /**
   * Query optimization recommendations.
   * DNA: BuildSearchFilter — skip empty filter values.
   */
  async queryRecommendations(filter: {
    scopeId?: string; serviceId?: string;
    category?: string; severity?: string;
    status?: string; dateFrom?: string; dateTo?: string;
  }): Promise<DataProcessResult<OptimizationRecommendation[]>> {
    try {
      // DNA: BuildSearchFilter — only include non-empty fields
      const must: any[] = [];
      if (filter.scopeId) must.push({ term: { scopeId: filter.scopeId } });
      if (filter.serviceId) must.push({ term: { serviceId: filter.serviceId } });
      if (filter.category) must.push({ term: { category: filter.category } });
      if (filter.severity) must.push({ term: { severity: filter.severity } });
      if (filter.status) must.push({ term: { status: filter.status } });
      if (filter.dateFrom || filter.dateTo) {
        const range: any = {};
        if (filter.dateFrom) range.gte = filter.dateFrom;
        if (filter.dateTo) range.lte = filter.dateTo;
        must.push({ range: { createdAt: range } });
      }

      const query = must.length > 0 ? { bool: { must } } : { match_all: {} };
      const results = await this.db.query(this.RECOMMENDATIONS_INDEX, query);

      return { success: true, data: results as OptimizationRecommendation[], message: `Found ${results.length} recommendations` };
    } catch (error: any) {
      return { success: false, data: [], message: error.message };
    }
  }

  // --- Private helpers ---

  private async getSlowQueries(scopeId: string, serviceId: string): Promise<QueryMetrics[]> {
    try {
      const result = await this.db.query('slow-query-log', {
        bool: { must: [{ term: { scopeId } }, { term: { serviceId } }] }
      }, { sort: [{ avgMs: 'desc' }], size: 10 });
      return result as QueryMetrics[];
    } catch { return []; }
  }

  private createRecommendation(
    scopeId: string, serviceId: string,
    category: OptimizationRecommendation['category'],
    severity: OptimizationRecommendation['severity'],
    description: string, implementation: string, estimatedImpact: number
  ): OptimizationRecommendation {
    return {
      id: `opt-${serviceId}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      scopeId, serviceId, category, severity, description, implementation,
      estimatedImpact, status: 'pending', createdAt: new Date().toISOString()
    };
  }
}
