<?php
/**
 * XIIGen Skill 38: Resource Management & Performance Optimization — PHP Alternative
 * Profiling, caching strategy, connection pooling, AI-assisted optimization
 * DNA: DataProcessResult, dynamic documents, BuildSearchFilter, scope isolation
 */

namespace XIIGen\Optimization;

class DataProcessResult {
    public function __construct(
        public readonly bool $success,
        public readonly mixed $data,
        public readonly string $message
    ) {}
}

class OptimizationService {
    private const SNAPSHOTS_INDEX = 'profiling-snapshots';
    private const RECOMMENDATIONS_INDEX = 'optimization-recommendations';

    public function __construct(
        private readonly object $db,
        private readonly ?object $logger = null,
        private readonly ?object $aiProvider = null
    ) {}

    /**
     * Profile a service by collecting CPU, memory, and query metrics.
     * DNA: DataProcessResult wrapping profiling snapshot.
     */
    public function profileService(string $scopeId, string $serviceId, int $durationMs = 30000): DataProcessResult
    {
        try {
            $startTime = microtime(true);

            // CPU metrics
            $loadAvg = sys_getloadavg();
            $cpuCount = (int) shell_exec('nproc') ?: 1;
            $cpu = [
                'usagePercent' => $loadAvg[0] / $cpuCount * 100,
                'loadAvg1m' => $loadAvg[0],
                'loadAvg5m' => $loadAvg[1],
                'cores' => $cpuCount,
            ];

            // Memory metrics
            $memUsage = memory_get_usage(true);
            $memPeak = memory_get_peak_usage(true);
            $memory = [
                'usedMb' => intdiv($memUsage, 1048576),
                'totalMb' => intdiv(self::getTotalMemory(), 1048576),
                'heapUsedMb' => intdiv($memUsage, 1048576),
                'heapTotalMb' => intdiv(ini_get('memory_limit') ? self::parseMemoryLimit(ini_get('memory_limit')) : $memPeak * 2, 1048576),
                'rssMb' => intdiv($memPeak, 1048576),
            ];

            // Slow queries from ES
            $slowQueries = $this->getSlowQueries($scopeId, $serviceId);

            $snapshot = [
                'id' => "prof-{$serviceId}-" . intval(microtime(true) * 1000),
                'scopeId' => $scopeId,
                'serviceId' => $serviceId,
                'cpu' => $cpu,
                'memory' => $memory,
                'endpoints' => [],
                'slowQueries' => $slowQueries,
                'capturedAt' => (new \DateTimeImmutable('now', new \DateTimeZone('UTC')))->format('c'),
                'durationMs' => intval((microtime(true) - $startTime) * 1000),
            ];

            // DNA: Store as dynamic document
            $this->db->upsert(self::SNAPSHOTS_INDEX, $snapshot);
            $this->logger?->info("Profiled {$serviceId}: CPU {$cpu['usagePercent']}%, Mem {$memory['heapUsedMb']}MB");

            return new DataProcessResult(true, $snapshot, "Profiled {$serviceId}");
        } catch (\Throwable $e) {
            $this->logger?->error("Profiling failed: {$e->getMessage()}");
            return new DataProcessResult(false, [], $e->getMessage());
        }
    }

    /**
     * Analyze profiling data and generate optimization recommendations.
     * DNA: DataProcessResult with recommendations array.
     */
    public function analyze(string $scopeId, string $serviceId): DataProcessResult
    {
        try {
            $snapshots = $this->db->query(self::SNAPSHOTS_INDEX, [
                'bool' => ['must' => [
                    ['term' => ['scopeId' => $scopeId]],
                    ['term' => ['serviceId' => $serviceId]],
                ]],
            ], ['sort' => [['capturedAt' => 'desc']], 'size' => 1]);

            if (empty($snapshots)) {
                return new DataProcessResult(false, [], 'No profiling data. Run profileService first.');
            }

            $snapshot = $snapshots[0];
            $recs = [];

            // CPU analysis
            $cpuUsage = $snapshot['cpu']['usagePercent'] ?? 0;
            if ($cpuUsage > 80) {
                $recs[] = $this->createRec($scopeId, $serviceId, 'cpu', 'critical',
                    sprintf('CPU at %.1f%% — CPU-bound', $cpuUsage),
                    'Profile with Blackfire/Xdebug, check for blocking I/O', 0.4);
            } elseif ($cpuUsage > 60) {
                $recs[] = $this->createRec($scopeId, $serviceId, 'cpu', 'medium',
                    sprintf('CPU at %.1f%% — approaching threshold', $cpuUsage),
                    'Use opcache tuning, review compute-heavy operations', 0.2);
            }

            // Memory analysis
            $heapUsed = $snapshot['memory']['heapUsedMb'] ?? 0;
            $heapTotal = $snapshot['memory']['heapTotalMb'] ?? 1;
            $heapPct = ($heapUsed / $heapTotal) * 100;
            if ($heapPct > 85) {
                $recs[] = $this->createRec($scopeId, $serviceId, 'memory', 'critical',
                    sprintf('Memory at %.1f%% — OOM risk', $heapPct),
                    'Increase memory_limit, check for circular references and large arrays', 0.5);
            }

            // Slow ES queries
            foreach ($snapshot['slowQueries'] ?? [] as $sq) {
                $avgMs = $sq['avgMs'] ?? 0;
                if ($avgMs > 500) {
                    $recs[] = $this->createRec($scopeId, $serviceId, 'query', 'high',
                        sprintf("Slow query on '%s': avg %.0fms", $sq['index'] ?? '?', $avgMs),
                        'Add composite index, consider denormalization', 0.3);
                }
            }

            // Store recommendations
            foreach ($recs as $rec) {
                $this->db->upsert(self::RECOMMENDATIONS_INDEX, $rec);
            }

            return new DataProcessResult(true, $recs, count($recs) . ' recommendations generated');
        } catch (\Throwable $e) {
            return new DataProcessResult(false, [], $e->getMessage());
        }
    }

    /**
     * Get AI-powered optimization recommendations.
     * DNA: DataProcessResult with AI-generated suggestions.
     */
    public function getAiRecommendations(string $scopeId, string $serviceId): DataProcessResult
    {
        try {
            if (!$this->aiProvider) {
                return new DataProcessResult(false, [], 'AI provider not configured');
            }

            $snapshots = $this->db->query(self::SNAPSHOTS_INDEX, [
                'bool' => ['must' => [
                    ['term' => ['scopeId' => $scopeId]],
                    ['term' => ['serviceId' => $serviceId]],
                ]],
            ], ['sort' => [['capturedAt' => 'desc']], 'size' => 5]);

            $prompt = "Analyze these profiling snapshots for '{$serviceId}' and return JSON array of recommendations:\n"
                . json_encode($snapshots, JSON_PRETTY_PRINT);

            $aiResult = $this->aiProvider->generate($prompt, 'json');
            $parsed = json_decode($aiResult['content'] ?? '[]', true) ?: [];

            $recs = array_map(fn($r) => $this->createRec(
                $scopeId, $serviceId,
                $r['category'] ?? 'cpu', $r['severity'] ?? 'medium',
                $r['description'] ?? 'AI recommendation',
                $r['implementation'] ?? 'Review suggested change',
                $r['impact'] ?? 0.2
            ), $parsed);

            foreach ($recs as $rec) {
                $this->db->upsert(self::RECOMMENDATIONS_INDEX, $rec);
            }

            return new DataProcessResult(true, $recs, 'AI: ' . count($recs) . ' recommendations');
        } catch (\Throwable $e) {
            return new DataProcessResult(false, [], $e->getMessage());
        }
    }

    /**
     * Configure a cache entry.
     * DNA: dynamic document.
     */
    public function configureCache(string $scopeId, array $config): DataProcessResult
    {
        try {
            $doc = array_merge($config, [
                'scopeId' => $scopeId,
                'updatedAt' => (new \DateTimeImmutable('now', new \DateTimeZone('UTC')))->format('c'),
            ]);
            $this->db->upsert('cache-configs', $doc);
            return new DataProcessResult(true, $config, 'Cache configured: ' . ($config['key'] ?? ''));
        } catch (\Throwable $e) {
            return new DataProcessResult(false, $config, $e->getMessage());
        }
    }

    /**
     * Query recommendations with dynamic filter.
     * DNA: BuildSearchFilter — skip empty/null values.
     */
    public function queryRecommendations(array $filter): DataProcessResult
    {
        try {
            $must = [];

            // DNA: BuildSearchFilter — only include non-empty fields
            foreach (['scopeId', 'serviceId', 'category', 'severity', 'status'] as $key) {
                if (!empty($filter[$key])) {
                    $must[] = ['term' => [$key => $filter[$key]]];
                }
            }

            if (!empty($filter['dateFrom']) || !empty($filter['dateTo'])) {
                $range = [];
                if (!empty($filter['dateFrom'])) $range['gte'] = $filter['dateFrom'];
                if (!empty($filter['dateTo'])) $range['lte'] = $filter['dateTo'];
                $must[] = ['range' => ['createdAt' => $range]];
            }

            $query = empty($must) ? ['match_all' => new \stdClass()] : ['bool' => ['must' => $must]];
            $results = $this->db->query(self::RECOMMENDATIONS_INDEX, $query, []);

            return new DataProcessResult(true, $results, 'Found ' . count($results) . ' recommendations');
        } catch (\Throwable $e) {
            return new DataProcessResult(false, [], $e->getMessage());
        }
    }

    // --- Private helpers ---

    private function getSlowQueries(string $scopeId, string $serviceId): array
    {
        try {
            return $this->db->query('slow-query-log', [
                'bool' => ['must' => [
                    ['term' => ['scopeId' => $scopeId]],
                    ['term' => ['serviceId' => $serviceId]],
                ]],
            ], ['sort' => [['avgMs' => 'desc']], 'size' => 10]);
        } catch (\Throwable) {
            return [];
        }
    }

    private function createRec(string $scopeId, string $serviceId, string $category, string $severity, string $desc, string $impl, float $impact): array
    {
        return [
            'id' => "opt-{$serviceId}-" . intval(microtime(true) * 1000),
            'scopeId' => $scopeId,
            'serviceId' => $serviceId,
            'category' => $category,
            'severity' => $severity,
            'description' => $desc,
            'implementation' => $impl,
            'estimatedImpact' => $impact,
            'status' => 'pending',
            'createdAt' => (new \DateTimeImmutable('now', new \DateTimeZone('UTC')))->format('c'),
        ];
    }

    private static function getTotalMemory(): int
    {
        if (PHP_OS_FAMILY === 'Linux' && file_exists('/proc/meminfo')) {
            preg_match('/MemTotal:\s+(\d+)/', file_get_contents('/proc/meminfo'), $m);
            return ($m[1] ?? 0) * 1024;
        }
        return 1073741824; // default 1GB
    }

    private static function parseMemoryLimit(string $limit): int
    {
        $val = (int) $limit;
        return match (strtolower(substr($limit, -1))) {
            'g' => $val * 1073741824,
            'm' => $val * 1048576,
            'k' => $val * 1024,
            default => $val,
        };
    }
}
