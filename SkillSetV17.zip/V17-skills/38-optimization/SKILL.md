---
skill_id: "38"
name: optimization
title: "Resource Management & Performance Optimization"
layer: "L8: Quality Assurance"
version: "17.1"
status: "active"
priority: "P1"
dependencies: ["01-core-interfaces", "03-elasticsearch-datastore", "23-monitoring-service", "36-logging"]
alternatives_server: [dotnet-diagnostics, clinic-js, py-spy, tokio-console, blackfire]
genie_dna:
  - "DNA-OPT: Measure before optimizing — never premature optimization"
  - "DNA-6: Optimization patterns work across all server alternatives"
  - "DNA-RESULT: Optimization analysis returns DataProcessResult with recommendations"
triggers: optimization, performance, resource management, memory, CPU, latency, throughput, profiling, caching, connection pooling
estimated_loc: 600
---

# Skill 38: Resource Management & Performance Optimization
## Profiling, Caching Strategy, Connection Pooling, and AI-Assisted Optimization

**Classification:** HUMAN — Optimization requires analysis and judgment  
**Priority:** P1 — Required for production performance  
**Dependencies:** Skill 01 (Core), Skill 03 (ES), Skill 23 (Monitoring), Skill 36 (Logging)  
**Layer:** L8: Quality Assurance  
**Estimated LOC:** ~600  

---

## Overview

Resource Optimization provides profiling, analysis, and automated tuning for XIIGen microservices. It profiles CPU, memory, network, and Elasticsearch query performance; manages caching strategies (Redis, in-memory, CDN); configures connection pooling for databases and HTTP clients; and uses AI-assisted analysis to recommend optimizations based on monitoring data (Skill 23) and log patterns (Skill 36). Results are stored as dynamic documents for trend analysis.

## Key Concepts

- **Profile-First Optimization** — Never optimize without profiling data. The service collects metrics first, identifies bottlenecks, then recommends targeted fixes.
- **Multi-Layer Caching** — L1 (in-memory), L2 (Redis), L3 (CDN) with configurable TTL, invalidation, and cache-aside patterns.
- **Connection Pool Management** — Elastic, HTTP, and DB connection pools with health monitoring and auto-scaling based on load.
- **ES Query Optimization** — Analyzes Elasticsearch query patterns, suggests index optimizations, identifies slow queries, recommends denormalization.
- **AI Optimization Advisor** — Feeds profiling data to AI (Skill 06) for natural language recommendations: "Your Elasticsearch queries on 'flows' index are 3x slower than average. Consider adding a composite index on [status, createdAt]."

---

## DNA Integration

### Required Patterns
- **DataProcessResult** — Optimization analysis returns recommendations with severity, estimated impact, and implementation steps.
- **Dynamic Document** — Profiling snapshots, optimization recommendations, and cache metrics stored as dynamic documents.
- **BuildSearchFilter** — Query profiling data by service, metric type, date range, severity.
- **ObjectProcessor** — Recursively analyze configuration objects to find optimization opportunities.

### Anti-Patterns to AVOID
- ❌ Premature optimization without profiling data
- ❌ Caching everything — cache only hot paths identified by profiling
- ❌ Unbounded connection pools — always set max limits with health checks
- ❌ Ignoring Elasticsearch query cost — monitor slow query log
- ❌ Manual cache invalidation — use event-driven invalidation patterns

---

## Primary Implementation (.NET 9)

### Models

```csharp
namespace XIIGen.Optimization.Models;

public record ProfilingSnapshot(
    string ServiceId, string SnapshotId,
    CpuMetrics Cpu, MemoryMetrics Memory,
    List<EndpointMetrics> Endpoints,
    List<QueryMetrics> SlowQueries,
    DateTime CapturedAt
);

public record OptimizationRecommendation(
    string Id, string ServiceId, string Category,
    string Severity, string Description,
    string Implementation, double EstimatedImpact,
    string Status, DateTime CreatedAt
);

public record CacheConfig(
    string Key, string Layer, TimeSpan Ttl,
    string InvalidationEvent, bool Enabled
);
```

### Service Interface

```csharp
public interface IOptimizationService
{
    Task<DataProcessResult<ProfilingSnapshot>> ProfileServiceAsync(string serviceId, TimeSpan duration, CancellationToken ct = default);
    Task<DataProcessResult<List<OptimizationRecommendation>>> AnalyzeAsync(string serviceId, CancellationToken ct = default);
    Task<DataProcessResult<List<OptimizationRecommendation>>> GetAiRecommendationsAsync(string serviceId, CancellationToken ct = default);
    Task<DataProcessResult<CacheConfig>> ConfigureCacheAsync(string serviceId, CacheConfig config, CancellationToken ct = default);
    Task<DataProcessResult<ConnectionPoolStatus>> GetPoolStatusAsync(string serviceId, CancellationToken ct = default);
}
```

### DI Registration

```csharp
services.AddScoped<IOptimizationService, OptimizationService>();
services.AddSingleton<ICacheManager, MultiLayerCacheManager>();
services.AddSingleton<IConnectionPoolMonitor, ConnectionPoolMonitor>();
```

---

## Test Scenarios

1. Profile service for 30s → verify CPU/memory/endpoint metrics captured
2. Analyze service with slow ES queries → verify recommendation to add index
3. Configure L1+L2 cache → verify cache-aside pattern with TTL and invalidation
4. Check connection pool → verify current/max/idle counts reported
5. Get AI recommendations → verify natural language suggestions based on profiling
6. Query recommendations by severity=critical → verify BuildSearchFilter
7. Apply cache config then re-profile → verify latency improvement in snapshot

## Component Classification
- **Category:** Performance Engineering
- **Inputs:** Service IDs, profiling config, cache config, monitoring data
- **Outputs:** Profiling snapshots, optimization recommendations, cache configs
- **Side Effects:** Modifies cache settings, connection pool configs
- **ES Indexes:** `profiling-snapshots`, `optimization-recommendations`
