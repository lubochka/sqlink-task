// XIIGen.Skills.Optimization/OptimizationService.cs | .NET 9 | Skill 38
// Resource management, connection pooling, memory optimization,
// caching strategies, batch processing, and performance monitoring.

using System.Collections.Concurrent;
using System.Diagnostics;
using System.Diagnostics.Metrics;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Skills.Optimization;

// ═══════════════════════════════════════════════════════
// CONNECTION POOL MANAGER
// ═══════════════════════════════════════════════════════

public class ConnectionPoolManager<T> : IDisposable where T : class
{
    private readonly ConcurrentBag<T> _pool = [];
    private readonly Func<T> _factory;
    private readonly Action<T> _cleanup;
    private readonly int _maxSize;
    private int _currentCount;
    private readonly SemaphoreSlim _semaphore;

    public ConnectionPoolManager(Func<T> factory, Action<T> cleanup = null, int maxSize = 20)
    {
        _factory = factory; _cleanup = cleanup; _maxSize = maxSize;
        _semaphore = new SemaphoreSlim(maxSize, maxSize);
    }

    public async Task<PooledConnection<T>> AcquireAsync(CancellationToken ct = default)
    {
        await _semaphore.WaitAsync(ct);
        if (!_pool.TryTake(out var connection))
        {
            connection = _factory();
            Interlocked.Increment(ref _currentCount);
        }
        return new PooledConnection<T>(connection, this);
    }

    internal void Release(T connection)
    {
        if (_pool.Count < _maxSize)
            _pool.Add(connection);
        else
        {
            _cleanup?.Invoke(connection);
            Interlocked.Decrement(ref _currentCount);
        }
        _semaphore.Release();
    }

    public int Available => _pool.Count;
    public int InUse => _maxSize - _semaphore.CurrentCount;

    public void Dispose()
    {
        while (_pool.TryTake(out var conn))
            _cleanup?.Invoke(conn);
        _semaphore.Dispose();
    }
}

public class PooledConnection<T> : IDisposable where T : class
{
    public T Value { get; }
    private readonly ConnectionPoolManager<T> _pool;
    private bool _disposed;

    internal PooledConnection(T value, ConnectionPoolManager<T> pool) { Value = value; _pool = pool; }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _pool.Release(Value);
    }
}

// ═══════════════════════════════════════════════════════
// MULTI-LEVEL CACHE
// ═══════════════════════════════════════════════════════

public class MultiLevelCache
{
    private readonly IMemoryCache _l1;  // In-memory (fast, small)
    private readonly ICacheService _l2; // Redis/distributed (slower, large)
    private readonly ILogger _logger;
    private readonly Meter _meter;
    private readonly Counter<long> _hits;
    private readonly Counter<long> _misses;

    public MultiLevelCache(IMemoryCache l1, ICacheService l2, ILogger<MultiLevelCache> logger)
    {
        _l1 = l1; _l2 = l2; _logger = logger;
        _meter = new Meter("XIIGen.Cache");
        _hits = _meter.CreateCounter<long>("cache.hits");
        _misses = _meter.CreateCounter<long>("cache.misses");
    }

    public async Task<T> GetOrSetAsync<T>(string key, Func<Task<T>> factory,
        TimeSpan? l1Ttl = null, TimeSpan? l2Ttl = null, CancellationToken ct = default)
    {
        l1Ttl ??= TimeSpan.FromSeconds(30);
        l2Ttl ??= TimeSpan.FromMinutes(5);

        // L1: In-memory
        if (_l1.TryGetValue(key, out T l1Value))
        {
            _hits.Add(1, new KeyValuePair<string, object>("level", "L1"));
            return l1Value;
        }

        // L2: Redis/distributed
        if (_l2 != null)
        {
            var l2Value = await _l2.GetAsync<T>(key, ct);
            if (l2Value != null)
            {
                _hits.Add(1, new KeyValuePair<string, object>("level", "L2"));
                _l1.Set(key, l2Value, l1Ttl.Value);
                return l2Value;
            }
        }

        // Cache miss → compute
        _misses.Add(1);
        var value = await factory();

        _l1.Set(key, value, l1Ttl.Value);
        if (_l2 != null) await _l2.SetAsync(key, value, l2Ttl.Value, ct);

        return value;
    }

    public async Task InvalidateAsync(string key, CancellationToken ct = default)
    {
        _l1.Remove(key);
        if (_l2 != null) await _l2.DeleteAsync(key, ct);
    }

    public async Task InvalidateByPrefixAsync(string prefix, CancellationToken ct = default)
    {
        // L2 prefix invalidation
        if (_l2 != null) await _l2.DeleteByPrefixAsync(prefix, ct);
    }
}

// ═══════════════════════════════════════════════════════
// BATCH PROCESSOR - Coalesces operations for throughput
// ═══════════════════════════════════════════════════════

public class BatchProcessor<T> : IDisposable
{
    private readonly Func<List<T>, Task> _processBatch;
    private readonly ConcurrentQueue<T> _queue = new();
    private readonly Timer _timer;
    private readonly int _maxBatchSize;
    private readonly SemaphoreSlim _lock = new(1, 1);

    public BatchProcessor(Func<List<T>, Task> processBatch, int maxBatchSize = 100, int flushIntervalMs = 1000)
    {
        _processBatch = processBatch;
        _maxBatchSize = maxBatchSize;
        _timer = new Timer(_ => _ = FlushAsync(), null, flushIntervalMs, flushIntervalMs);
    }

    public void Add(T item)
    {
        _queue.Enqueue(item);
        if (_queue.Count >= _maxBatchSize)
            _ = FlushAsync();
    }

    public async Task FlushAsync()
    {
        if (_queue.IsEmpty) return;
        if (!await _lock.WaitAsync(0)) return; // Don't block

        try
        {
            var batch = new List<T>();
            while (batch.Count < _maxBatchSize && _queue.TryDequeue(out var item))
                batch.Add(item);

            if (batch.Count > 0)
                await _processBatch(batch);
        }
        finally { _lock.Release(); }
    }

    public void Dispose() { _timer?.Dispose(); _ = FlushAsync(); }
}

// ═══════════════════════════════════════════════════════
// AI REQUEST OPTIMIZER - Reduces token usage + costs
// ═══════════════════════════════════════════════════════

public class AiRequestOptimizer
{
    private readonly MultiLevelCache _cache;
    private readonly ILogger _logger;

    public AiRequestOptimizer(MultiLevelCache cache, ILogger<AiRequestOptimizer> logger)
    {
        _cache = cache; _logger = logger;
    }

    /// <summary>
    /// Deduplicates identical AI requests within a time window.
    /// If the same prompt was sent in the last N minutes, return cached result.
    /// </summary>
    public async Task<AiResponse> ExecuteWithDeduplicationAsync(
        IAiProvider provider, AiRequest request, TimeSpan? cacheWindow = null, CancellationToken ct = default)
    {
        cacheWindow ??= TimeSpan.FromMinutes(10);
        var cacheKey = $"ai-dedup:{ComputeHash(request.Prompt + request.SystemPrompt)}";

        return await _cache.GetOrSetAsync(cacheKey,
            () => provider.ExecuteAsync(request, ct),
            l1Ttl: TimeSpan.FromMinutes(2),
            l2Ttl: cacheWindow,
            ct: ct);
    }

    /// <summary>
    /// Trims prompt context to stay within token budget while keeping most relevant items.
    /// </summary>
    public string TrimContextToTokenBudget(string context, int maxTokens = 4000)
    {
        var estimatedTokens = context.Length / 4;
        if (estimatedTokens <= maxTokens) return context;

        // Keep first and last portions (most important context tends to be at boundaries)
        var charBudget = maxTokens * 4;
        var halfBudget = charBudget / 2;
        return context[..halfBudget] + "\n...[trimmed for token budget]...\n" + context[^halfBudget..];
    }

    /// <summary>
    /// Selects the cheapest model that meets quality threshold for a given task.
    /// </summary>
    public string SelectOptimalModel(string taskType, float qualityThreshold = 0.8f) => taskType switch
    {
        "simple-transform" => "claude-haiku-4-5",        // Fast, cheap
        "complex-transform" => "claude-sonnet-4-5",      // Balanced
        "review" => "claude-haiku-4-5",                  // Review doesn't need top model
        "architecture" => "claude-sonnet-4-5",            // Complex reasoning
        "code-generation" => "claude-sonnet-4-5",         // Needs good code quality
        _ => "claude-sonnet-4-5"
    };

    private static string ComputeHash(string input)
    {
        var bytes = System.Security.Cryptography.SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(input));
        return Convert.ToHexString(bytes)[..16];
    }
}

// ═══════════════════════════════════════════════════════
// PERFORMANCE MONITOR - Tracks and reports metrics
// ═══════════════════════════════════════════════════════

public class PerformanceMonitor
{
    private readonly Meter _meter;
    private readonly Histogram<double> _requestDuration;
    private readonly Histogram<double> _aiLatency;
    private readonly Counter<long> _aiTokensUsed;
    private readonly Counter<long> _dbOperations;
    private readonly ObservableGauge<long> _memoryUsage;
    private readonly ObservableGauge<int> _activeConnections;
    private int _connectionCount;

    public PerformanceMonitor()
    {
        _meter = new Meter("XIIGen.Performance", "1.0");
        _requestDuration = _meter.CreateHistogram<double>("http.request.duration", "ms");
        _aiLatency = _meter.CreateHistogram<double>("ai.request.duration", "ms");
        _aiTokensUsed = _meter.CreateCounter<long>("ai.tokens.total");
        _dbOperations = _meter.CreateCounter<long>("db.operations.total");
        _memoryUsage = _meter.CreateObservableGauge("process.memory.bytes",
            () => GC.GetTotalMemory(false));
        _activeConnections = _meter.CreateObservableGauge("connections.active",
            () => _connectionCount);
    }

    public IDisposable TrackRequest(string method, string path)
    {
        var sw = Stopwatch.StartNew();
        Interlocked.Increment(ref _connectionCount);
        return new RequestTracker(() =>
        {
            sw.Stop();
            _requestDuration.Record(sw.ElapsedMilliseconds,
                new KeyValuePair<string, object>("method", method),
                new KeyValuePair<string, object>("path", path));
            Interlocked.Decrement(ref _connectionCount);
        });
    }

    public void TrackAiCall(string model, double durationMs, int tokensIn, int tokensOut)
    {
        _aiLatency.Record(durationMs, new KeyValuePair<string, object>("model", model));
        _aiTokensUsed.Add(tokensIn + tokensOut, new KeyValuePair<string, object>("model", model));
    }

    public void TrackDbOperation(string operation, string index)
    {
        _dbOperations.Add(1,
            new KeyValuePair<string, object>("operation", operation),
            new KeyValuePair<string, object>("index", index));
    }

    private class RequestTracker(Action onDispose) : IDisposable { public void Dispose() => onDispose(); }
}

// ═══════════════════════════════════════════════════════
// RESOURCE DISPOSAL MANAGER
// ═══════════════════════════════════════════════════════

public class ResourceManager : IAsyncDisposable
{
    private readonly ConcurrentBag<IDisposable> _disposables = [];
    private readonly ConcurrentBag<IAsyncDisposable> _asyncDisposables = [];

    public T Track<T>(T resource) where T : IDisposable { _disposables.Add(resource); return resource; }
    public T TrackAsync<T>(T resource) where T : IAsyncDisposable { _asyncDisposables.Add(resource); return resource; }

    public async ValueTask DisposeAsync()
    {
        foreach (var d in _asyncDisposables)
            await d.DisposeAsync();
        foreach (var d in _disposables)
            d.Dispose();
    }
}

// ═══════════════════════════════════════════════════════
// DI REGISTRATION
// ═══════════════════════════════════════════════════════

public static class OptimizationExtensions
{
    public static IServiceCollection AddXIIGenOptimization(this IServiceCollection services)
    {
        services.AddMemoryCache();
        services.AddSingleton<MultiLevelCache>();
        services.AddSingleton<PerformanceMonitor>();
        services.AddSingleton<AiRequestOptimizer>();
        services.AddSingleton<ResourceManager>();

        // Batch processor for log writes
        services.AddSingleton(sp =>
        {
            var db = sp.GetRequiredService<IDatabaseService>();
            return new BatchProcessor<object>(async batch =>
            {
                var docs = batch.Select((d, i) => ($"batch-{DateTime.UtcNow:HHmmssfff}-{i}", d)).ToList();
                await db.BulkUpsertAsync("service-logs", "xiigen", docs);
            }, maxBatchSize: 50, flushIntervalMs: 2000);
        });

        return services;
    }
}
