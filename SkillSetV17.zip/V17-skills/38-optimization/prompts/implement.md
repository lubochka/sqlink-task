# Skill 38: Performance Optimization — Implementation Prompt

## Phase 1: Query Optimization
Analyze BuildSearchFilter query patterns. Create compound ES indexes for hot paths.

## Phase 2: Cache Layer
MicroserviceBase cache integration. Cache key strategy. TTL configuration.

## Phase 3: Database Fabric Tuning
Per-provider optimization: ES bulk indexing, Mongo covered queries, Redis pipelining.

## Phase 4: Document Splitting
Large documents split: base doc (searchable) + detail doc (on-demand).

---

## Genie DNA Compliance — MANDATORY
☐ DNA-1: Dynamic Documents — Dictionary<string, object>, NOT typed models
☐ DNA-2: BuildSearchFilter — skip empty fields, no entity-specific query code
☐ DNA-3: MicroserviceBase — inherit DB, queue, cache, logger
☐ DNA-5: DataProcessResult<T> — all methods return result wrapper
☐ DNA-6: Generic Interfaces — swap via config
☐ DNA-SCOPE: Non-admin queries auto-inject userId filter
