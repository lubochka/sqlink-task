// XIIGen.Rag.Neo4j/Neo4jRagService.cs | .NET 9
// NuGet: Neo4j.Driver 5.*
// Supports: graph traversal, Cypher queries, vector search (Neo4j 5.11+ with vector index)

using System.Text.Json;
using Neo4j.Driver;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Rag.Neo4j;

public class Neo4jRagService : IRagService, IDisposable
{
    private readonly IDriver _driver;
    public string ProviderName => "neo4j";

    public RagCapabilities Capabilities => new()
    {
        SupportsVectorSearch = true, SupportsHybridSearch = true,
        SupportsGraphTraversal = true, SupportsGraphQuery = true,
        SupportsDocumentChunking = true, MaxEmbeddingDimensions = 4096
    };

    public Neo4jRagService(string uri, string user, string password)
    {
        _driver = GraphDatabase.Driver(uri, AuthTokens.Basic(user, password));
    }

    // ─── Vector Operations ───────────────────────────────

    public async Task<DataProcessResult<string>> StoreEmbeddingAsync(
        string collection, string id, float[] embedding,
        Dictionary<string, object> metadata = null, CancellationToken ct = default)
    {
        await using var session = _driver.AsyncSession();
        var props = new Dictionary<string, object> { ["id"] = id, ["embedding"] = embedding.ToList() };
        if (metadata != null) foreach (var kv in metadata) props[kv.Key] = kv.Value;

        await session.ExecuteWriteAsync(async tx =>
        {
            await tx.RunAsync(
                $"MERGE (n:{Sanitize(collection)} {{id: $id}}) SET n += $props",
                new { id, props });
        });
        return DataProcessResult<string>.Success(id);
    }

    public async Task<DataProcessResult<List<RagSearchResult>>> VectorSearchAsync(
        string collection, float[] queryEmbedding, int topK = 10, float minScore = 0.0f,
        Dictionary<string, object> filters = null, CancellationToken ct = default)
    {
        await using var session = _driver.AsyncSession();
        // Neo4j 5.11+ vector index query
        var results = new List<RagSearchResult>();
        var records = await session.ExecuteReadAsync(async tx =>
        {
            var result = await tx.RunAsync(
                $"""
                CALL db.index.vector.queryNodes('{Sanitize(collection)}_vector', $topK, $embedding)
                YIELD node, score
                WHERE score >= $minScore
                RETURN node, score
                ORDER BY score DESC
                """,
                new { topK, embedding = queryEmbedding.ToList(), minScore });
            return await result.ToListAsync();
        });

        foreach (var record in records)
        {
            var node = record["node"].As<INode>();
            results.Add(new RagSearchResult
            {
                Id = node.Properties.GetValueOrDefault("id")?.ToString() ?? node.ElementId,
                Score = record["score"].As<float>(),
                Content = node.Properties.GetValueOrDefault("content")?.ToString(),
                Metadata = node.Properties.Where(p => p.Key != "id" && p.Key != "embedding" && p.Key != "content")
                    .ToDictionary(p => p.Key, p => p.Value),
                Collection = collection
            });
        }
        return DataProcessResult<List<RagSearchResult>>.Success(results);
    }

    public async Task<DataProcessResult<List<RagSearchResult>>> HybridSearchAsync(
        string collection, string textQuery, float[] queryEmbedding = null,
        int topK = 10, Dictionary<string, object> filters = null, CancellationToken ct = default)
    {
        await using var session = _driver.AsyncSession();
        var results = new List<RagSearchResult>();

        // Full-text + optional vector search
        var cypher = queryEmbedding != null
            ? $"""
               CALL db.index.fulltext.queryNodes('{Sanitize(collection)}_fulltext', $query) YIELD node AS textNode, score AS textScore
               WITH textNode, textScore
               CALL db.index.vector.queryNodes('{Sanitize(collection)}_vector', $topK, $embedding) YIELD node AS vecNode, score AS vecScore
               WITH COLLECT({{node: textNode, score: textScore}}) + COLLECT({{node: vecNode, score: vecScore}}) AS combined
               UNWIND combined AS item
               WITH item.node AS node, MAX(item.score) AS score
               RETURN DISTINCT node, score ORDER BY score DESC LIMIT $topK
               """
            : $"""
               CALL db.index.fulltext.queryNodes('{Sanitize(collection)}_fulltext', $query) YIELD node, score
               RETURN node, score ORDER BY score DESC LIMIT $topK
               """;

        var records = await session.ExecuteReadAsync(async tx =>
        {
            var result = await tx.RunAsync(cypher, new { query = textQuery, topK, embedding = queryEmbedding?.ToList() });
            return await result.ToListAsync();
        });

        foreach (var record in records)
        {
            var node = record["node"].As<INode>();
            results.Add(new RagSearchResult
            {
                Id = node.Properties.GetValueOrDefault("id")?.ToString(),
                Score = record["score"].As<float>(),
                Content = node.Properties.GetValueOrDefault("content")?.ToString(),
                Collection = collection,
                Metadata = node.Properties.Where(p => p.Key != "id" && p.Key != "embedding" && p.Key != "content")
                    .ToDictionary(p => p.Key, p => p.Value)
            });
        }
        return DataProcessResult<List<RagSearchResult>>.Success(results);
    }

    // ─── Graph Operations ────────────────────────────────

    public async Task<DataProcessResult<string>> StoreNodeAsync(
        string label, string id, Dictionary<string, object> properties, CancellationToken ct = default)
    {
        await using var session = _driver.AsyncSession();
        var props = new Dictionary<string, object>(properties) { ["id"] = id };
        await session.ExecuteWriteAsync(async tx =>
        {
            await tx.RunAsync(
                $"MERGE (n:{Sanitize(label)} {{id: $id}}) SET n += $props",
                new { id, props });
        });
        return DataProcessResult<string>.Success(id);
    }

    public async Task<DataProcessResult<string>> StoreEdgeAsync(
        string fromId, string toId, string edgeType,
        Dictionary<string, object> properties = null, CancellationToken ct = default)
    {
        await using var session = _driver.AsyncSession();
        var props = properties ?? new Dictionary<string, object>();
        props["createdAt"] = DateTime.UtcNow.ToString("O");

        await session.ExecuteWriteAsync(async tx =>
        {
            await tx.RunAsync(
                $"""
                MATCH (a {{id: $fromId}}), (b {{id: $toId}})
                MERGE (a)-[r:{Sanitize(edgeType)}]->(b)
                SET r += $props
                """,
                new { fromId, toId, props });
        });
        return DataProcessResult<string>.Success($"{fromId}-[{edgeType}]->{toId}");
    }

    public async Task<DataProcessResult<List<RagGraphResult>>> TraverseAsync(
        string startNodeId, string edgeType = null, int maxDepth = 3,
        TraversalDirection direction = TraversalDirection.Outgoing, CancellationToken ct = default)
    {
        await using var session = _driver.AsyncSession();
        var dirArrow = direction switch
        {
            TraversalDirection.Outgoing => "->",
            TraversalDirection.Incoming => "<-",
            _ => "-"
        };
        var edgeFilter = edgeType != null ? $":{Sanitize(edgeType)}" : "";

        var cypher = $"""
            MATCH path = (start {{id: $startId}})-[r{edgeFilter}*1..{maxDepth}]{dirArrow}(end)
            UNWIND nodes(path) AS node
            WITH DISTINCT node, length(shortestPath((start)-[*]-(node))) AS depth
            WHERE start.id = $startId
            RETURN node, depth
            ORDER BY depth
            """;

        var records = await session.ExecuteReadAsync(async tx =>
        {
            var result = await tx.RunAsync(cypher, new { startId = startNodeId });
            return await result.ToListAsync();
        });

        var results = records.Select(r =>
        {
            var node = r["node"].As<INode>();
            return new RagGraphResult
            {
                NodeId = node.Properties.GetValueOrDefault("id")?.ToString(),
                Label = string.Join(":", node.Labels),
                Properties = node.Properties.ToDictionary(p => p.Key, p => p.Value),
                Depth = r["depth"].As<int>()
            };
        }).ToList();

        return DataProcessResult<List<RagGraphResult>>.Success(results);
    }

    public async Task<DataProcessResult<List<RagGraphResult>>> GraphQueryAsync(
        string query, Dictionary<string, object> parameters = null, CancellationToken ct = default)
    {
        await using var session = _driver.AsyncSession();
        var records = await session.ExecuteReadAsync(async tx =>
        {
            var result = await tx.RunAsync(query, parameters ?? new Dictionary<string, object>());
            return await result.ToListAsync();
        });

        var results = new List<RagGraphResult>();
        foreach (var record in records)
        {
            foreach (var value in record.Values.Values)
            {
                if (value is INode node)
                {
                    results.Add(new RagGraphResult
                    {
                        NodeId = node.Properties.GetValueOrDefault("id")?.ToString(),
                        Label = string.Join(":", node.Labels),
                        Properties = node.Properties.ToDictionary(p => p.Key, p => p.Value)
                    });
                }
            }
        }
        return DataProcessResult<List<RagGraphResult>>.Success(results);
    }

    public async Task<DataProcessResult<List<string>>> StoreDocumentChunksAsync(
        string collection, string documentId, string content,
        ChunkingOptions options = null, CancellationToken ct = default)
    {
        options ??= new ChunkingOptions();
        var chunks = ChunkBySentence(content, options.ChunkSize, options.ChunkOverlap);
        var ids = new List<string>();

        await using var session = _driver.AsyncSession();
        await session.ExecuteWriteAsync(async tx =>
        {
            // Create document node
            await tx.RunAsync(
                $"MERGE (d:Document {{id: $docId}}) SET d.collection = $collection",
                new { docId = documentId, collection });

            string prevChunkId = null;
            for (int i = 0; i < chunks.Count; i++)
            {
                var chunkId = $"{documentId}_chunk_{i}";
                ids.Add(chunkId);

                await tx.RunAsync(
                    $"""
                    MERGE (c:{Sanitize(collection)}Chunk {{id: $chunkId}})
                    SET c.content = $content, c.chunkIndex = $index, c.documentId = $docId
                    WITH c
                    MATCH (d:Document {{id: $docId}})
                    MERGE (d)-[:HAS_CHUNK]->(c)
                    """,
                    new { chunkId, content = chunks[i], index = i, docId = documentId });

                // Link sequential chunks
                if (prevChunkId != null)
                {
                    await tx.RunAsync(
                        $"MATCH (a:{Sanitize(collection)}Chunk {{id: $prev}}), (b:{Sanitize(collection)}Chunk {{id: $curr}}) MERGE (a)-[:NEXT]->(b)",
                        new { prev = prevChunkId, curr = chunkId });
                }
                prevChunkId = chunkId;
            }
        });

        return DataProcessResult<List<string>>.Success(ids);
    }

    public async Task<DataProcessResult<bool>> DeleteAsync(string collection, string id, CancellationToken ct)
    {
        await using var session = _driver.AsyncSession();
        await session.ExecuteWriteAsync(async tx =>
        {
            await tx.RunAsync("MATCH (n {id: $id}) DETACH DELETE n", new { id });
        });
        return DataProcessResult<bool>.Success(true);
    }

    public async Task<DataProcessResult<bool>> CollectionExistsAsync(string collection, CancellationToken ct)
    {
        await using var session = _driver.AsyncSession();
        var count = await session.ExecuteReadAsync(async tx =>
        {
            var result = await tx.RunAsync($"MATCH (n:{Sanitize(collection)}) RETURN count(n) AS cnt LIMIT 1");
            var record = await result.SingleAsync();
            return record["cnt"].As<long>();
        });
        return DataProcessResult<bool>.Success(count >= 0); // Label always "exists" in Neo4j
    }

    public async Task<DataProcessResult<bool>> CreateCollectionAsync(string collection, CollectionSchema schema, CancellationToken ct)
    {
        await using var session = _driver.AsyncSession();
        await session.ExecuteWriteAsync(async tx =>
        {
            // Create vector index
            await tx.RunAsync(
                $"""
                CREATE VECTOR INDEX {Sanitize(collection)}_vector IF NOT EXISTS
                FOR (n:{Sanitize(collection)}) ON (n.embedding)
                OPTIONS {{indexConfig: {{
                    `vector.dimensions`: {schema.EmbeddingDimensions},
                    `vector.similarity_function`: '{(schema.DistanceMetric == "cosine" ? "cosine" : "euclidean")}'
                }}}}
                """);

            // Create full-text index
            await tx.RunAsync(
                $"CREATE FULLTEXT INDEX {Sanitize(collection)}_fulltext IF NOT EXISTS FOR (n:{Sanitize(collection)}) ON EACH [n.content]");

            // Create ID uniqueness constraint
            await tx.RunAsync(
                $"CREATE CONSTRAINT {Sanitize(collection)}_id IF NOT EXISTS FOR (n:{Sanitize(collection)}) REQUIRE n.id IS UNIQUE");
        });
        return DataProcessResult<bool>.Success(true);
    }

    private static string Sanitize(string label) => label.Replace("-", "_").Replace(".", "_");

    private static List<string> ChunkBySentence(string text, int chunkSize, int overlap)
    {
        var sentences = text.Split(new[] { ". ", "! ", "? ", "\n\n" }, StringSplitOptions.RemoveEmptyEntries);
        var chunks = new List<string>();
        var current = "";
        foreach (var s in sentences)
        {
            if (current.Length + s.Length > chunkSize && current.Length > 0)
            {
                chunks.Add(current.Trim());
                current = overlap > 0 && current.Length > overlap ? current[^overlap..] : "";
            }
            current += s + ". ";
        }
        if (!string.IsNullOrWhiteSpace(current)) chunks.Add(current.Trim());
        return chunks;
    }

    public void Dispose() => _driver?.Dispose();
}
