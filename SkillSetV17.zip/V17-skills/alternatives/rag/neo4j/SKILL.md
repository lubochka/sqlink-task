# RAG Backend: neo4j
Implements IRagService for neo4j.
See implementation file for details.
