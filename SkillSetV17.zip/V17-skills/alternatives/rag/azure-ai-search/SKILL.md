# RAG Backend: azure-ai-search
Implements IRagService for azure-ai-search.
See implementation file for details.
