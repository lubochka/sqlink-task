// XIIGen.Rag.AzureAISearch/AzureAISearchRagService.cs | .NET 9
// NuGet: Azure.Search.Documents 11.*
// Supports: vector search, hybrid search (RRF), semantic ranking

using System.Text.Json;
using Azure;
using Azure.Search.Documents;
using Azure.Search.Documents.Indexes;
using Azure.Search.Documents.Indexes.Models;
using Azure.Search.Documents.Models;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Rag.AzureAISearch;

public class AzureAISearchRagService : IRagService
{
    private readonly SearchIndexClient _indexClient;
    private readonly string _endpoint;
    private readonly AzureKeyCredential _credential;
    public string ProviderName => "azure-ai-search";

    public RagCapabilities Capabilities => new()
    {
        SupportsVectorSearch = true, SupportsHybridSearch = true,
        SupportsGraphTraversal = false, SupportsGraphQuery = false,
        SupportsDocumentChunking = true, MaxEmbeddingDimensions = 3072
    };

    public AzureAISearchRagService(string endpoint, string apiKey)
    {
        _endpoint = endpoint;
        _credential = new AzureKeyCredential(apiKey);
        _indexClient = new SearchIndexClient(new Uri(endpoint), _credential);
    }

    private SearchClient GetClient(string collection) =>
        new(new Uri(_endpoint), collection, _credential);

    public async Task<DataProcessResult<string>> StoreEmbeddingAsync(
        string collection, string id, float[] embedding,
        Dictionary<string, object> metadata = null, CancellationToken ct = default)
    {
        var client = GetClient(collection);
        var doc = new Dictionary<string, object> { ["id"] = id, ["contentVector"] = embedding };
        if (metadata != null)
            foreach (var kv in metadata) doc[kv.Key] = kv.Value;

        var batch = IndexDocumentsBatch.Upload(new[] { new SearchDocument(doc) });
        await client.IndexDocumentsAsync(batch, cancellationToken: ct);
        return DataProcessResult<string>.Success(id);
    }

    public async Task<DataProcessResult<List<RagSearchResult>>> VectorSearchAsync(
        string collection, float[] queryEmbedding, int topK = 10, float minScore = 0.0f,
        Dictionary<string, object> filters = null, CancellationToken ct = default)
    {
        var client = GetClient(collection);
        var vectorQuery = new VectorizedQuery(queryEmbedding)
        {
            KNearestNeighborsCount = topK, Fields = { "contentVector" }
        };
        var options = new SearchOptions { VectorSearch = new() { Queries = { vectorQuery } }, Size = topK };
        if (filters?.Any() == true) options.Filter = BuildODataFilter(filters);

        var results = new List<RagSearchResult>();
        await foreach (var result in client.SearchAsync<SearchDocument>(null, options, ct).Value.GetResultsAsync())
        {
            if (result.Score >= minScore)
                results.Add(new RagSearchResult
                {
                    Id = result.Document["id"]?.ToString(),
                    Score = (float)(result.Score ?? 0),
                    Content = result.Document.GetValueOrDefault("content")?.ToString(),
                    Metadata = result.Document.Where(k => k.Key != "id" && k.Key != "contentVector" && k.Key != "content")
                        .ToDictionary(k => k.Key, v => v.Value),
                    Collection = collection
                });
        }
        return DataProcessResult<List<RagSearchResult>>.Success(results);
    }

    public async Task<DataProcessResult<List<RagSearchResult>>> HybridSearchAsync(
        string collection, string textQuery, float[] queryEmbedding = null,
        int topK = 10, Dictionary<string, object> filters = null, CancellationToken ct = default)
    {
        var client = GetClient(collection);
        var options = new SearchOptions
        {
            Size = topK,
            QueryType = SearchQueryType.Semantic,
            SemanticSearch = new() { SemanticConfigurationName = "default" }
        };
        if (queryEmbedding != null)
        {
            var vectorQuery = new VectorizedQuery(queryEmbedding)
            {
                KNearestNeighborsCount = topK, Fields = { "contentVector" }
            };
            options.VectorSearch = new() { Queries = { vectorQuery } };
        }
        if (filters?.Any() == true) options.Filter = BuildODataFilter(filters);

        var results = new List<RagSearchResult>();
        await foreach (var result in client.SearchAsync<SearchDocument>(textQuery, options, ct).Value.GetResultsAsync())
        {
            results.Add(new RagSearchResult
            {
                Id = result.Document["id"]?.ToString(),
                Score = (float)(result.Score ?? 0),
                Content = result.Document.GetValueOrDefault("content")?.ToString(),
                Metadata = result.Document.Where(k => k.Key != "id" && k.Key != "contentVector" && k.Key != "content")
                    .ToDictionary(k => k.Key, v => v.Value),
                Collection = collection
            });
        }
        return DataProcessResult<List<RagSearchResult>>.Success(results);
    }

    // Graph operations not supported by Azure AI Search
    public Task<DataProcessResult<string>> StoreNodeAsync(string label, string id, Dictionary<string, object> properties, CancellationToken ct) =>
        Task.FromResult(DataProcessResult<string>.Error("Graph not supported by Azure AI Search"));
    public Task<DataProcessResult<string>> StoreEdgeAsync(string fromId, string toId, string edgeType, Dictionary<string, object> properties, CancellationToken ct) =>
        Task.FromResult(DataProcessResult<string>.Error("Graph not supported"));
    public Task<DataProcessResult<List<RagGraphResult>>> TraverseAsync(string startNodeId, string edgeType, int maxDepth, TraversalDirection direction, CancellationToken ct) =>
        Task.FromResult(DataProcessResult<List<RagGraphResult>>.Error("Graph not supported"));
    public Task<DataProcessResult<List<RagGraphResult>>> GraphQueryAsync(string query, Dictionary<string, object> parameters, CancellationToken ct) =>
        Task.FromResult(DataProcessResult<List<RagGraphResult>>.Error("Graph not supported"));

    public async Task<DataProcessResult<List<string>>> StoreDocumentChunksAsync(
        string collection, string documentId, string content,
        ChunkingOptions options = null, CancellationToken ct = default)
    {
        options ??= new ChunkingOptions();
        var chunks = ChunkText(content, options);
        var ids = new List<string>();

        for (int i = 0; i < chunks.Count; i++)
        {
            var chunkId = $"{documentId}_chunk_{i}";
            ids.Add(chunkId);
            // Note: caller should generate embeddings and call StoreEmbeddingAsync
            var client = GetClient(collection);
            var doc = new SearchDocument(new Dictionary<string, object>
            {
                ["id"] = chunkId, ["content"] = chunks[i],
                ["documentId"] = documentId, ["chunkIndex"] = i,
                ["totalChunks"] = chunks.Count
            });
            await client.IndexDocumentsAsync(IndexDocumentsBatch.Upload(new[] { doc }), cancellationToken: ct);
        }
        return DataProcessResult<List<string>>.Success(ids);
    }

    public async Task<DataProcessResult<bool>> DeleteAsync(string collection, string id, CancellationToken ct)
    {
        var client = GetClient(collection);
        await client.DeleteDocumentsAsync("id", new[] { id }, cancellationToken: ct);
        return DataProcessResult<bool>.Success(true);
    }

    public async Task<DataProcessResult<bool>> CollectionExistsAsync(string collection, CancellationToken ct)
    {
        try { await _indexClient.GetIndexAsync(collection, ct); return DataProcessResult<bool>.Success(true); }
        catch { return DataProcessResult<bool>.Success(false); }
    }

    public async Task<DataProcessResult<bool>> CreateCollectionAsync(string collection, CollectionSchema schema, CancellationToken ct)
    {
        var index = new SearchIndex(collection)
        {
            Fields = {
                new SimpleField("id", SearchFieldDataType.String) { IsKey = true },
                new SearchableField("content") { AnalyzerName = LexicalAnalyzerName.Values.EnMicrosoft },
                new SearchField("contentVector", SearchFieldDataType.Collection(SearchFieldDataType.Single))
                {
                    IsSearchable = true,
                    VectorSearchDimensions = schema.EmbeddingDimensions,
                    VectorSearchProfileName = "default-profile"
                },
                new SimpleField("documentId", SearchFieldDataType.String) { IsFilterable = true },
            },
            VectorSearch = new()
            {
                Profiles = { new VectorSearchProfile("default-profile", "default-algo") },
                Algorithms = { new HnswAlgorithmConfiguration("default-algo") }
            },
            SemanticSearch = new()
            {
                Configurations = { new SemanticConfiguration("default", new()
                {
                    ContentFields = { new SemanticField("content") }
                })}
            }
        };
        await _indexClient.CreateOrUpdateIndexAsync(index, cancellationToken: ct);
        return DataProcessResult<bool>.Success(true);
    }

    private static string BuildODataFilter(Dictionary<string, object> filters) =>
        string.Join(" and ", filters.Select(kv => $"{kv.Key} eq '{kv.Value}'"));

    private static List<string> ChunkText(string text, ChunkingOptions options)
    {
        if (options.Strategy == "sentence")
        {
            var sentences = text.Split(new[] { ". ", "! ", "? ", "\n" }, StringSplitOptions.RemoveEmptyEntries);
            var chunks = new List<string>();
            var current = "";
            foreach (var s in sentences)
            {
                if (current.Length + s.Length > options.ChunkSize && current.Length > 0)
                { chunks.Add(current.Trim()); current = current.Length > options.ChunkOverlap ? current[^options.ChunkOverlap..] : ""; }
                current += s + ". ";
            }
            if (current.Trim().Length > 0) chunks.Add(current.Trim());
            return chunks;
        }
        // Fixed-size chunking fallback
        var fixedChunks = new List<string>();
        for (int i = 0; i < text.Length; i += options.ChunkSize - options.ChunkOverlap)
            fixedChunks.Add(text.Substring(i, Math.Min(options.ChunkSize, text.Length - i)));
        return fixedChunks;
    }
}
