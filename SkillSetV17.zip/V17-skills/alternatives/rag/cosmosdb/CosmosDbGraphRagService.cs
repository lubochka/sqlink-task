// XIIGen.Rag.CosmosGraph/CosmosDbGraphRagService.cs | .NET 9
// NuGet: Gremlin.Net 3.*, Azure.Identity
// Supports: graph traversal (Gremlin), graph query, vector search (with DiskANN)

using System.Text.Json;
using Gremlin.Net.Driver;
using Gremlin.Net.Structure.IO.GraphSON;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Rag.CosmosGraph;

public class CosmosDbGraphRagService : IRagService, IDisposable
{
    private readonly GremlinClient _client;
    private readonly string _database;
    private readonly string _container;
    public string ProviderName => "cosmosdb-graph";

    public RagCapabilities Capabilities => new()
    {
        SupportsVectorSearch = true, SupportsHybridSearch = false,
        SupportsGraphTraversal = true, SupportsGraphQuery = true,
        SupportsDocumentChunking = true, MaxEmbeddingDimensions = 4096
    };

    public CosmosDbGraphRagService(string hostname, string database, string container, string authKey, int port = 443)
    {
        _database = database;
        _container = container;
        var server = new GremlinServer(hostname, port, enableSsl: true,
            username: $"/dbs/{database}/colls/{container}", password: authKey);
        _client = new GremlinClient(server, new GraphSON2MessageSerializer());
    }

    private async Task<List<Dictionary<string, object>>> ExecuteGremlinAsync(string query, CancellationToken ct = default)
    {
        var results = new List<Dictionary<string, object>>();
        var resultSet = await _client.SubmitAsync<dynamic>(query);
        foreach (var result in resultSet)
        {
            if (result is Dictionary<string, object> dict) results.Add(dict);
            else results.Add(new Dictionary<string, object> { ["value"] = result?.ToString() });
        }
        return results;
    }

    public async Task<DataProcessResult<string>> StoreEmbeddingAsync(
        string collection, string id, float[] embedding,
        Dictionary<string, object> metadata = null, CancellationToken ct = default)
    {
        var props = new Dictionary<string, object>(metadata ?? [])
        {
            ["embedding"] = JsonSerializer.Serialize(embedding),
            ["collection"] = collection
        };
        var propsStr = string.Join("", props.Select(kv =>
            $".property('{Escape(kv.Key)}', '{Escape(kv.Value?.ToString())}')"));

        await ExecuteGremlinAsync(
            $"g.V('{Escape(id)}').fold().coalesce(unfold(), g.addV('{Escape(collection)}').property('id', '{Escape(id)}')){propsStr}", ct);
        return DataProcessResult<string>.Success(id);
    }

    public async Task<DataProcessResult<List<RagSearchResult>>> VectorSearchAsync(
        string collection, float[] queryEmbedding, int topK = 10, float minScore = 0.0f,
        Dictionary<string, object> filters = null, CancellationToken ct = default)
    {
        // CosmosDB with DiskANN vector index via SQL API
        // For Gremlin API, retrieve all and compute similarity locally (for small datasets)
        // For production, use CosmosDB SQL API's VectorDistance function
        var gremlin = $"g.V().hasLabel('{Escape(collection)}').has('embedding').limit({topK * 3}).valueMap(true)";
        var raw = await ExecuteGremlinAsync(gremlin, ct);

        var results = raw.Select(dict =>
        {
            var embStr = GetProp(dict, "embedding");
            if (embStr == null) return null;
            var emb = JsonSerializer.Deserialize<float[]>(embStr);
            var score = CosineSimilarity(queryEmbedding, emb);
            if (score < minScore) return null;

            return new RagSearchResult
            {
                Id = GetProp(dict, "id"),
                Score = score,
                Content = GetProp(dict, "content"),
                Collection = collection,
                Metadata = dict.Where(k => k.Key != "id" && k.Key != "embedding" && k.Key != "content")
                    .ToDictionary(k => k.Key, v => v.Value)
            };
        })
        .Where(r => r != null)
        .OrderByDescending(r => r.Score)
        .Take(topK)
        .ToList();

        return DataProcessResult<List<RagSearchResult>>.Success(results);
    }

    public Task<DataProcessResult<List<RagSearchResult>>> HybridSearchAsync(
        string collection, string textQuery, float[] queryEmbedding = null,
        int topK = 10, Dictionary<string, object> filters = null, CancellationToken ct = default)
    {
        if (queryEmbedding != null)
            return VectorSearchAsync(collection, queryEmbedding, topK, 0.0f, filters, ct);
        return Task.FromResult(DataProcessResult<List<RagSearchResult>>.Error("Hybrid search requires embedding for CosmosDB Graph"));
    }

    public async Task<DataProcessResult<string>> StoreNodeAsync(
        string label, string id, Dictionary<string, object> properties, CancellationToken ct = default)
    {
        var propsStr = string.Join("", properties.Select(kv =>
            $".property('{Escape(kv.Key)}', '{Escape(kv.Value?.ToString())}')"));
        await ExecuteGremlinAsync(
            $"g.addV('{Escape(label)}').property('id', '{Escape(id)}').property('pk', '{Escape(label)}'){propsStr}", ct);
        return DataProcessResult<string>.Success(id);
    }

    public async Task<DataProcessResult<string>> StoreEdgeAsync(
        string fromId, string toId, string edgeType,
        Dictionary<string, object> properties = null, CancellationToken ct = default)
    {
        var propsStr = properties != null
            ? string.Join("", properties.Select(kv => $".property('{Escape(kv.Key)}', '{Escape(kv.Value?.ToString())}')"))
            : "";
        await ExecuteGremlinAsync(
            $"g.V('{Escape(fromId)}').addE('{Escape(edgeType)}').to(g.V('{Escape(toId)}')){propsStr}", ct);
        return DataProcessResult<string>.Success($"{fromId}-[{edgeType}]->{toId}");
    }

    public async Task<DataProcessResult<List<RagGraphResult>>> TraverseAsync(
        string startNodeId, string edgeType = null, int maxDepth = 3,
        TraversalDirection direction = TraversalDirection.Outgoing, CancellationToken ct = default)
    {
        var dirStep = direction switch
        {
            TraversalDirection.Outgoing => "out",
            TraversalDirection.Incoming => "in",
            _ => "both"
        };
        var edgeFilter = edgeType != null ? $"('{Escape(edgeType)}')" : "()";
        var gremlin = $"g.V('{Escape(startNodeId)}').repeat({dirStep}{edgeFilter}).times({maxDepth}).emit().path().by(valueMap(true))";
        var raw = await ExecuteGremlinAsync(gremlin, ct);

        var results = raw.Select(dict => new RagGraphResult
        {
            NodeId = GetProp(dict, "id"),
            Label = GetProp(dict, "label") ?? "unknown",
            Properties = dict.Where(k => k.Key != "id" && k.Key != "label")
                .ToDictionary(k => k.Key, v => v.Value)
        }).ToList();

        return DataProcessResult<List<RagGraphResult>>.Success(results);
    }

    public async Task<DataProcessResult<List<RagGraphResult>>> GraphQueryAsync(
        string query, Dictionary<string, object> parameters = null, CancellationToken ct = default)
    {
        var raw = await ExecuteGremlinAsync(query, ct);
        var results = raw.Select(dict => new RagGraphResult
        {
            NodeId = GetProp(dict, "id"),
            Label = GetProp(dict, "label") ?? "unknown",
            Properties = dict
        }).ToList();
        return DataProcessResult<List<RagGraphResult>>.Success(results);
    }

    public async Task<DataProcessResult<List<string>>> StoreDocumentChunksAsync(
        string collection, string documentId, string content,
        ChunkingOptions options = null, CancellationToken ct = default)
    {
        options ??= new ChunkingOptions();
        var chunks = content.Split(new[] { "\n\n", ". " }, StringSplitOptions.RemoveEmptyEntries);
        var ids = new List<string>();

        // Create document node
        await StoreNodeAsync("Document", documentId, new Dictionary<string, object>
        {
            ["collection"] = collection, ["totalChunks"] = chunks.Length
        }, ct);

        for (int i = 0; i < chunks.Length; i++)
        {
            var chunkId = $"{documentId}_chunk_{i}";
            ids.Add(chunkId);
            await StoreNodeAsync($"{collection}Chunk", chunkId, new Dictionary<string, object>
            {
                ["content"] = chunks[i], ["chunkIndex"] = i, ["documentId"] = documentId
            }, ct);
            await StoreEdgeAsync(documentId, chunkId, "HAS_CHUNK", null, ct);
            if (i > 0) await StoreEdgeAsync(ids[i - 1], chunkId, "NEXT", null, ct);
        }
        return DataProcessResult<List<string>>.Success(ids);
    }

    public async Task<DataProcessResult<bool>> DeleteAsync(string collection, string id, CancellationToken ct)
    {
        await ExecuteGremlinAsync($"g.V('{Escape(id)}').drop()", ct);
        return DataProcessResult<bool>.Success(true);
    }

    public Task<DataProcessResult<bool>> CollectionExistsAsync(string collection, CancellationToken ct)
        => Task.FromResult(DataProcessResult<bool>.Success(true)); // Labels auto-exist

    public Task<DataProcessResult<bool>> CreateCollectionAsync(string collection, CollectionSchema schema, CancellationToken ct)
        => Task.FromResult(DataProcessResult<bool>.Success(true)); // Container must be pre-created

    private static string Escape(string s) => s?.Replace("'", "\\'").Replace("\\", "\\\\") ?? "";

    private static string GetProp(Dictionary<string, object> dict, string key)
    {
        if (dict.TryGetValue(key, out var val))
        {
            if (val is List<object> list && list.Count > 0) return list[0]?.ToString();
            return val?.ToString();
        }
        return null;
    }

    private static float CosineSimilarity(float[] a, float[] b)
    {
        if (a == null || b == null || a.Length != b.Length) return 0;
        float dot = 0, normA = 0, normB = 0;
        for (int i = 0; i < a.Length; i++) { dot += a[i] * b[i]; normA += a[i] * a[i]; normB += b[i] * b[i]; }
        return normA > 0 && normB > 0 ? dot / (MathF.Sqrt(normA) * MathF.Sqrt(normB)) : 0;
    }

    public void Dispose() => _client?.Dispose();
}
