# RAG Backend: cosmosdb
Implements IRagService for cosmosdb.
See implementation file for details.
