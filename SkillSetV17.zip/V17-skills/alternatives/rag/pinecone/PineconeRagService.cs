// XIIGen.Rag.Pinecone/PineconeRagService.cs | .NET 9
// NuGet: Pinecone.NET (or raw HTTP) - pure vector search
// Supports: vector search, hybrid search (sparse+dense), metadata filtering

using System.Net.Http.Json;
using System.Text.Json;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Rag.Pinecone;

public class PineconeRagService : IRagService, IDisposable
{
    private readonly HttpClient _http;
    private readonly string _host;
    public string ProviderName => "pinecone";

    public RagCapabilities Capabilities => new()
    {
        SupportsVectorSearch = true, SupportsHybridSearch = true,
        SupportsGraphTraversal = false, SupportsGraphQuery = false,
        SupportsDocumentChunking = true, MaxEmbeddingDimensions = 20000
    };

    public PineconeRagService(string host, string apiKey)
    {
        _host = host.TrimEnd('/');
        _http = new HttpClient();
        _http.DefaultRequestHeaders.Add("Api-Key", apiKey);
    }

    public async Task<DataProcessResult<string>> StoreEmbeddingAsync(
        string collection, string id, float[] embedding,
        Dictionary<string, object> metadata = null, CancellationToken ct = default)
    {
        var body = new
        {
            vectors = new[] { new { id, values = embedding, metadata = metadata ?? new Dictionary<string, object>() } },
            @namespace = collection
        };
        var resp = await _http.PostAsJsonAsync($"{_host}/vectors/upsert", body, ct);
        resp.EnsureSuccessStatusCode();
        return DataProcessResult<string>.Success(id);
    }

    public async Task<DataProcessResult<List<RagSearchResult>>> VectorSearchAsync(
        string collection, float[] queryEmbedding, int topK = 10, float minScore = 0.0f,
        Dictionary<string, object> filters = null, CancellationToken ct = default)
    {
        var body = new Dictionary<string, object>
        {
            ["vector"] = queryEmbedding, ["topK"] = topK,
            ["includeMetadata"] = true, ["namespace"] = collection
        };
        if (filters?.Any() == true) body["filter"] = filters;

        var resp = await _http.PostAsJsonAsync($"{_host}/query", body, ct);
        resp.EnsureSuccessStatusCode();
        var json = await resp.Content.ReadFromJsonAsync<JsonElement>(ct);

        var results = new List<RagSearchResult>();
        if (json.TryGetProperty("matches", out var matches))
        {
            foreach (var match in matches.EnumerateArray())
            {
                var score = match.GetProperty("score").GetSingle();
                if (score < minScore) continue;

                var meta = new Dictionary<string, object>();
                if (match.TryGetProperty("metadata", out var metaProp))
                    foreach (var prop in metaProp.EnumerateObject())
                        meta[prop.Name] = prop.Value.ValueKind switch
                        {
                            JsonValueKind.String => prop.Value.GetString(),
                            JsonValueKind.Number => prop.Value.GetDouble(),
                            JsonValueKind.True => true, JsonValueKind.False => false,
                            _ => prop.Value.ToString()
                        };

                results.Add(new RagSearchResult
                {
                    Id = match.GetProperty("id").GetString(),
                    Score = score,
                    Content = meta.GetValueOrDefault("content")?.ToString(),
                    Metadata = meta, Collection = collection
                });
            }
        }
        return DataProcessResult<List<RagSearchResult>>.Success(results);
    }

    public async Task<DataProcessResult<List<RagSearchResult>>> HybridSearchAsync(
        string collection, string textQuery, float[] queryEmbedding = null,
        int topK = 10, Dictionary<string, object> filters = null, CancellationToken ct = default)
    {
        // Pinecone hybrid = dense vector + sparse vector (BM25)
        // If no embedding provided, fall back to metadata text filter
        if (queryEmbedding != null)
            return await VectorSearchAsync(collection, queryEmbedding, topK, 0.0f, filters, ct);

        // Text-only: filter by content containing query terms
        var textFilter = new Dictionary<string, object>(filters ?? new())
        {
            ["content"] = new Dictionary<string, object> { ["$regex"] = textQuery }
        };
        // Pinecone requires a vector for query, use a zero vector as placeholder
        var zeroVector = new float[1536]; // Default dimensions
        return await VectorSearchAsync(collection, zeroVector, topK, 0.0f, textFilter, ct);
    }

    // Graph operations not supported
    public Task<DataProcessResult<string>> StoreNodeAsync(string l, string id, Dictionary<string, object> p, CancellationToken ct)
        => Task.FromResult(DataProcessResult<string>.Error("Graph not supported by Pinecone"));
    public Task<DataProcessResult<string>> StoreEdgeAsync(string f, string t, string e, Dictionary<string, object> p, CancellationToken ct)
        => Task.FromResult(DataProcessResult<string>.Error("Graph not supported"));
    public Task<DataProcessResult<List<RagGraphResult>>> TraverseAsync(string s, string e, int d, TraversalDirection dir, CancellationToken ct)
        => Task.FromResult(DataProcessResult<List<RagGraphResult>>.Error("Graph not supported"));
    public Task<DataProcessResult<List<RagGraphResult>>> GraphQueryAsync(string q, Dictionary<string, object> p, CancellationToken ct)
        => Task.FromResult(DataProcessResult<List<RagGraphResult>>.Error("Graph not supported"));

    public async Task<DataProcessResult<List<string>>> StoreDocumentChunksAsync(
        string collection, string documentId, string content,
        ChunkingOptions options = null, CancellationToken ct = default)
    {
        options ??= new ChunkingOptions();
        var chunks = ChunkText(content, options.ChunkSize, options.ChunkOverlap);
        var ids = new List<string>();

        // Batch upsert chunks (Pinecone supports batch of up to 100)
        for (int batch = 0; batch < chunks.Count; batch += 100)
        {
            var vectors = chunks.Skip(batch).Take(100).Select((chunk, i) =>
            {
                var idx = batch + i;
                var id = $"{documentId}_chunk_{idx}";
                ids.Add(id);
                return new
                {
                    id,
                    values = new float[1536], // Caller should replace with real embeddings
                    metadata = new Dictionary<string, object>
                    {
                        ["content"] = chunk, ["documentId"] = documentId,
                        ["chunkIndex"] = idx, ["totalChunks"] = chunks.Count
                    }
                };
            }).ToArray();

            var body = new { vectors, @namespace = collection };
            var resp = await _http.PostAsJsonAsync($"{_host}/vectors/upsert", body, ct);
            resp.EnsureSuccessStatusCode();
        }
        return DataProcessResult<List<string>>.Success(ids);
    }

    public async Task<DataProcessResult<bool>> DeleteAsync(string collection, string id, CancellationToken ct)
    {
        var body = new { ids = new[] { id }, @namespace = collection };
        var resp = await _http.PostAsJsonAsync($"{_host}/vectors/delete", body, ct);
        resp.EnsureSuccessStatusCode();
        return DataProcessResult<bool>.Success(true);
    }

    public Task<DataProcessResult<bool>> CollectionExistsAsync(string collection, CancellationToken ct)
        => Task.FromResult(DataProcessResult<bool>.Success(true)); // Namespaces auto-exist in Pinecone

    public async Task<DataProcessResult<bool>> CreateCollectionAsync(string collection, CollectionSchema schema, CancellationToken ct)
        => DataProcessResult<bool>.Success(true); // Index must be created via Pinecone console/API separately

    private static List<string> ChunkText(string text, int chunkSize, int overlap)
    {
        var sentences = text.Split(new[] { ". ", "! ", "? ", "\n\n" }, StringSplitOptions.RemoveEmptyEntries);
        var chunks = new List<string>();
        var current = "";
        foreach (var s in sentences)
        {
            if (current.Length + s.Length > chunkSize && current.Length > 0)
            { chunks.Add(current.Trim()); current = overlap > 0 ? current[Math.Max(0, current.Length - overlap)..] : ""; }
            current += s + ". ";
        }
        if (!string.IsNullOrWhiteSpace(current)) chunks.Add(current.Trim());
        return chunks;
    }

    public void Dispose() => _http?.Dispose();
}
