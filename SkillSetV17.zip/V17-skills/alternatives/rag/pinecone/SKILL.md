# RAG Backend: pinecone
Implements IRagService for pinecone.
See implementation file for details.
