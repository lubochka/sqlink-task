# RAG Backend: elasticsearch-knn
Implements IRagService for elasticsearch-knn.
See implementation file for details.
