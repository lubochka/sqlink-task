// XIIGen.Rag.ElasticsearchKnn/ElasticsearchKnnRagService.cs | .NET 9
// NuGet: Elastic.Clients.Elasticsearch 8.*
// Supports: vector search (kNN), hybrid search (RRF), text search

using System.Text.Json;
using Elastic.Clients.Elasticsearch;
using Elastic.Clients.Elasticsearch.QueryDsl;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Rag.ElasticsearchKnn;

public class ElasticsearchKnnRagService : IRagService
{
    private readonly ElasticsearchClient _client;
    public string ProviderName => "elasticsearch-knn";

    public RagCapabilities Capabilities => new()
    {
        SupportsVectorSearch = true, SupportsHybridSearch = true,
        SupportsGraphTraversal = false, SupportsGraphQuery = false,
        SupportsDocumentChunking = true, MaxEmbeddingDimensions = 4096
    };

    public ElasticsearchKnnRagService(string uri) =>
        _client = new ElasticsearchClient(new ElasticsearchClientSettings(new Uri(uri)));

    public async Task<DataProcessResult<string>> StoreEmbeddingAsync(
        string collection, string id, float[] embedding,
        Dictionary<string, object> metadata = null, CancellationToken ct = default)
    {
        var doc = new Dictionary<string, object>(metadata ?? [])
        {
            ["id"] = id, ["contentVector"] = embedding
        };
        await _client.IndexAsync(doc, idx => idx.Index(collection).Id(id), ct);
        return DataProcessResult<string>.Success(id);
    }

    public async Task<DataProcessResult<List<RagSearchResult>>> VectorSearchAsync(
        string collection, float[] queryEmbedding, int topK = 10, float minScore = 0.0f,
        Dictionary<string, object> filters = null, CancellationToken ct = default)
    {
        var response = await _client.SearchAsync<Dictionary<string, object>>(s => s
            .Index(collection)
            .Size(topK)
            .Knn(knn => knn
                .Field("contentVector")
                .QueryVector(queryEmbedding)
                .k(topK)
                .NumCandidates(topK * 2)
            ), ct);

        var results = response.Hits.Select(h => new RagSearchResult
        {
            Id = h.Id,
            Score = (float)(h.Score ?? 0),
            Content = h.Source?.GetValueOrDefault("content")?.ToString(),
            Metadata = h.Source?.Where(k => k.Key != "id" && k.Key != "contentVector" && k.Key != "content")
                .ToDictionary(k => k.Key, v => v.Value) ?? [],
            Collection = collection
        }).Where(r => r.Score >= minScore).ToList();

        return DataProcessResult<List<RagSearchResult>>.Success(results);
    }

    public async Task<DataProcessResult<List<RagSearchResult>>> HybridSearchAsync(
        string collection, string textQuery, float[] queryEmbedding = null,
        int topK = 10, Dictionary<string, object> filters = null, CancellationToken ct = default)
    {
        // Elasticsearch RRF (Reciprocal Rank Fusion) for hybrid search
        var searchDesc = new SearchRequestDescriptor<Dictionary<string, object>>()
            .Index(collection)
            .Size(topK)
            .Query(q => q.Match(m => m.Field("content").Query(textQuery)));

        if (queryEmbedding != null)
        {
            searchDesc.Knn(knn => knn
                .Field("contentVector")
                .QueryVector(queryEmbedding)
                .k(topK)
                .NumCandidates(topK * 2));
        }

        var response = await _client.SearchAsync(searchDesc, ct);
        var results = response.Hits.Select(h => new RagSearchResult
        {
            Id = h.Id, Score = (float)(h.Score ?? 0),
            Content = h.Source?.GetValueOrDefault("content")?.ToString(),
            Metadata = h.Source?.Where(k => k.Key != "id" && k.Key != "contentVector" && k.Key != "content")
                .ToDictionary(k => k.Key, v => v.Value) ?? [],
            Collection = collection
        }).ToList();

        return DataProcessResult<List<RagSearchResult>>.Success(results);
    }

    // Graph not supported
    public Task<DataProcessResult<string>> StoreNodeAsync(string l, string id, Dictionary<string, object> p, CancellationToken ct) =>
        Task.FromResult(DataProcessResult<string>.Error("Graph not supported by ES kNN"));
    public Task<DataProcessResult<string>> StoreEdgeAsync(string f, string t, string e, Dictionary<string, object> p, CancellationToken ct) =>
        Task.FromResult(DataProcessResult<string>.Error("Graph not supported"));
    public Task<DataProcessResult<List<RagGraphResult>>> TraverseAsync(string s, string e, int d, TraversalDirection dir, CancellationToken ct) =>
        Task.FromResult(DataProcessResult<List<RagGraphResult>>.Error("Graph not supported"));
    public Task<DataProcessResult<List<RagGraphResult>>> GraphQueryAsync(string q, Dictionary<string, object> p, CancellationToken ct) =>
        Task.FromResult(DataProcessResult<List<RagGraphResult>>.Error("Graph not supported"));

    public async Task<DataProcessResult<List<string>>> StoreDocumentChunksAsync(
        string collection, string documentId, string content,
        ChunkingOptions options = null, CancellationToken ct = default)
    {
        options ??= new ChunkingOptions();
        var chunks = content.Split(new[] { "\n\n", ". " }, StringSplitOptions.RemoveEmptyEntries);
        var ids = new List<string>();

        foreach (var (chunk, i) in chunks.Select((c, i) => (c, i)))
        {
            var chunkId = $"{documentId}_chunk_{i}";
            ids.Add(chunkId);
            var doc = new Dictionary<string, object>
            {
                ["id"] = chunkId, ["content"] = chunk,
                ["documentId"] = documentId, ["chunkIndex"] = i, ["totalChunks"] = chunks.Length
            };
            await _client.IndexAsync(doc, idx => idx.Index(collection).Id(chunkId), ct);
        }
        return DataProcessResult<List<string>>.Success(ids);
    }

    public async Task<DataProcessResult<bool>> DeleteAsync(string collection, string id, CancellationToken ct)
    {
        await _client.DeleteAsync(collection, id, ct);
        return DataProcessResult<bool>.Success(true);
    }

    public async Task<DataProcessResult<bool>> CollectionExistsAsync(string collection, CancellationToken ct)
    {
        var exists = await _client.Indices.ExistsAsync(collection, ct);
        return DataProcessResult<bool>.Success(exists.Exists);
    }

    public async Task<DataProcessResult<bool>> CreateCollectionAsync(string collection, CollectionSchema schema, CancellationToken ct)
    {
        await _client.Indices.CreateAsync(collection, c => c
            .Mappings(m => m
                .Properties(p => p
                    .Keyword(k => k, f => f.Name("id"))
                    .Text(t => t, f => f.Name("content"))
                    .DenseVector(dv => dv, f => f.Name("contentVector")
                        .Dims(schema.EmbeddingDimensions)
                        .Similarity(schema.DistanceMetric == "cosine" ? "cosine" : "l2_norm"))
                    .Keyword(k => k, f => f.Name("documentId"))
                    .Integer(i => i, f => f.Name("chunkIndex"))
                )
            ), ct);
        return DataProcessResult<bool>.Success(true);
    }
}
