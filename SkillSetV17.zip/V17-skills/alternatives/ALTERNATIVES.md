# XIIGen Alternatives Catalog — v14

## GraphRAG Alternatives (10 options)
Selection: `config["Rag:Provider"]`

| # | Provider | Category | Vector | Graph | Pricing | Best For |
|---|----------|----------|--------|-------|---------|----------|
| 1 | **Neo4j GraphRAG** | Enterprise | ✅ | ✅ Cypher | Free / $65+/mo | Industry standard, Claude SDK + MCP |
| 2 | **LightRAG** | Lightweight | ✅ | ✅ Dual-level | Open source (MIT) | Budget-conscious, 80-90% fewer API calls |
| 3 | **nano-graphrag** | Lightweight | ✅ | ✅ Local/Global | Open source | Full control, hackable codebase |
| 4 | **LangChain KG** | Framework | ✅ | ✅ GraphCypherQA | Open source | Already in LangChain ecosystem |
| 5 | **LlamaIndex GraphRAG** | Framework | ✅ | ✅ KG Index | Open source | 160+ connectors, Bedrock tutorial |
| 6 | **Graphlit** | Managed SaaS | ✅ | ✅ Auto-extract | Free 1GB / $49+/mo | Zero-ops, auto KG from docs/audio/video |
| 7 | **Memgraph** | Real-time | ❌ | ✅ Cypher | Open source | Real-time streaming, Kafka/Pulsar |
| 8 | **Neptune + Bedrock** | AWS Native | ✅ | ✅ openCypher | No free tier | AWS-first enterprises |
| 9 | **Contextual AI** | Agentic | ✅ | ✅ Agent-driven | Enterprise | Graph reasoning without graph maintenance |
| 10 | **HybridRAG (DIY)** | Architecture | ✅ | ✅ Composable | Component costs | Maximum flexibility |

Quick Pick: Prototype → LightRAG | Production → Neo4j GraphRAG | Enterprise → Neptune+Bedrock | Zero-ops → Graphlit

## DevOps Hosting (13 options)
Selection: `config["Hosting:Platform"]`

| # | Platform | Category | Price | Best For |
|---|----------|----------|-------|----------|
| 1 | **Railway** | PaaS | $5/mo+ | Fast GitHub deploy, visual UI |
| 2 | **Render** | PaaS | $7/mo, free tier | Heroku replacement, built-in DBs |
| 3 | **Fly.io** | PaaS | $2/mo per VM | Global edge, low latency |
| 4 | **Vercel** | PaaS | free / $20 Pro | Frontend only |
| 5 | **GKE** | Managed K8s | free CP | Best K8s, Autopilot |
| 6 | **EKS** | Managed K8s | $0.10/hr | IAM, CloudWatch, Fargate |
| 7 | **AKS** | Managed K8s | free CP | Azure AD, Key Vault |
| 8 | **DigitalOcean** | Managed K8s | free CP | Simpler & cheaper |
| 9 | **Nomad** | Lightweight | open source | Single binary, containers + VMs |
| 10 | **Docker Swarm** | Lightweight | built-in | Zero extra tooling |
| 11 | **K3s** | Lightweight | open source | Edge, IoT, dev |
| 12 | **OpenShift** | Enterprise | per CPU core | GitOps, security, compliance |
| 13 | **Rancher** | Enterprise | open source | Multi-cluster, hybrid cloud |

Quick Pick: Prototype → Railway | Production → Render/AKS | Global → Fly.io | Enterprise → OpenShift

## Other Alternatives (from v11)
- **Queues (5):** Redis Streams, Kafka, SQS, RabbitMQ, Azure Service Bus
- **Databases (6):** Elasticsearch, MongoDB, Prisma, Redis, Azure AI Search, Neo4j
- **RAG Standard (5):** Azure AI Search, Neo4j, Pinecone, CosmosDB Graph, ES kNN
- **Servers (6):** .NET 9, Node.js, Rust, Java, Python, PHP
- **Clients (5):** React Native, Angular, Vue, Native iOS, Native Android

## Total: 50 alternatives across 7 categories
