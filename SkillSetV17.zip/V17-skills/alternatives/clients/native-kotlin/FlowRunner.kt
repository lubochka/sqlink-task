// XIIGen Android Client | Jetpack Compose + Kotlin Coroutines
// minSdk: 26, targetSdk: 35, Kotlin 2.0+
// Dependencies: compose-bom, retrofit2, okhttp3, kotlinx-coroutines

package com.xiigen.client

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*

// ─── API Models ──────────────────────────────────────────
data class FlowStatus(
    val traceId: String, val flowId: String, val status: String,
    val currentStep: String, val progress: Double,
    val result: Any? = null, val steps: List<StepStatus> = emptyList(),
    val startedAt: String, val completedAt: String? = null
)
data class StepStatus(
    val stepId: String, val nodeType: String, val status: String,
    val error: String? = null, val outputSummary: String? = null, val hasFeedback: Boolean = false
)
data class TriggerRequest(val flowId: String, val body: Any, val traceId: String)
data class TriggerResponse(val traceId: String)
data class FeedbackRequest(val rating: String, val text: String? = null)

// ─── Retrofit API ────────────────────────────────────────
interface XIIGenApi {
    @POST("flow/trigger")
    suspend fun triggerFlow(@Body request: TriggerRequest): TriggerResponse

    @GET("flow/{traceId}/status")
    suspend fun getFlowStatus(@Path("traceId") traceId: String): FlowStatus

    @POST("flow/{traceId}/steps/{stepId}/feedback")
    suspend fun submitFeedback(
        @Path("traceId") traceId: String,
        @Path("stepId") stepId: String,
        @Body feedback: FeedbackRequest
    )
}

// ─── ViewModel ───────────────────────────────────────────
class FlowViewModel : ViewModel() {
    private val api: XIIGenApi = Retrofit.Builder()
        .baseUrl("http://10.0.2.2:5000/api/") // Android emulator → host machine
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(XIIGenApi::class.java)

    private val _status = MutableStateFlow<FlowStatus?>(null)
    val status = _status.asStateFlow()

    private val _isPolling = MutableStateFlow(false)
    val isPolling = _isPolling.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error = _error.asStateFlow()

    private val backoffMs = listOf(1000L, 2000L, 5000L, 10000L)

    fun triggerFlow(flowId: String, body: Map<String, Any> = emptyMap()) {
        viewModelScope.launch {
            try {
                val traceId = java.util.UUID.randomUUID().toString()
                api.triggerFlow(TriggerRequest(flowId, body, traceId))
                startPolling(traceId)
            } catch (e: Exception) {
                _error.value = e.message
            }
        }
    }

    private fun startPolling(traceId: String) {
        _isPolling.value = true
        viewModelScope.launch {
            var attempt = 0
            while (_isPolling.value) {
                try {
                    val s = api.getFlowStatus(traceId)
                    _status.value = s
                    if (s.status == "Completed" || s.status == "Failed") {
                        _isPolling.value = false
                        return@launch
                    }
                    attempt = 0
                } catch (e: Exception) {
                    attempt = minOf(attempt + 1, backoffMs.size - 1)
                }
                delay(backoffMs[minOf(attempt, backoffMs.size - 1)])
            }
        }
    }

    fun submitFeedback(stepId: String, rating: String, text: String? = null) {
        val traceId = _status.value?.traceId ?: return
        viewModelScope.launch {
            try { api.submitFeedback(traceId, stepId, FeedbackRequest(rating, text)) }
            catch (_: Exception) { /* Silent fail for feedback */ }
        }
    }
}

// ─── Composable UI ───────────────────────────────────────
@Composable
fun FlowRunnerScreen(viewModel: FlowViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {
    val status by viewModel.status.collectAsState()
    val isPolling by viewModel.isPolling.collectAsState()
    val error by viewModel.error.collectAsState()
    var flowId by remember { mutableStateOf("figma-to-react-v1") }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("XIIGen Flow Runner", style = MaterialTheme.typography.headlineMedium)

        if (status == null) {
            OutlinedTextField(value = flowId, onValueChange = { flowId = it },
                label = { Text("Flow ID") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = { viewModel.triggerFlow(flowId) }, modifier = Modifier.fillMaxWidth()) {
                Text("Run Flow")
            }
        }

        status?.let { s ->
            FlowProgressCard(s)
            StepsList(s.steps) { stepId, rating, text ->
                viewModel.submitFeedback(stepId, rating, text)
            }
        }

        if (isPolling) {
            CircularProgressIndicator(modifier = Modifier.align(Alignment.CenterHorizontally))
        }

        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    }
}

@Composable
fun FlowProgressCard(status: FlowStatus) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text(status.status, style = MaterialTheme.typography.titleMedium,
                    color = when (status.status) {
                        "Completed" -> Color(0xFF2E7D32)
                        "Failed" -> MaterialTheme.colorScheme.error
                        "Running" -> MaterialTheme.colorScheme.primary
                        else -> MaterialTheme.colorScheme.onSurface
                    })
                Text("${(status.progress * 100).toInt()}%", style = MaterialTheme.typography.bodySmall)
            }
            LinearProgressIndicator(progress = { status.progress.toFloat() },
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
            Text("Current: ${status.currentStep}", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun StepsList(steps: List<StepStatus>, onFeedback: (String, String, String?) -> Unit) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(steps) { step ->
            StepCard(step, onFeedback)
        }
    }
}

@Composable
fun StepCard(step: StepStatus, onFeedback: (String, String, String?) -> Unit) {
    var showFeedback by remember { mutableStateOf(false) }
    var feedbackText by remember { mutableStateOf("") }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text(step.nodeType, style = MaterialTheme.typography.titleSmall)
                Text(step.status, color = when (step.status) {
                    "Completed" -> Color(0xFF2E7D32); "Failed" -> MaterialTheme.colorScheme.error
                    "Running" -> MaterialTheme.colorScheme.primary; else -> MaterialTheme.colorScheme.onSurface
                })
            }
            step.outputSummary?.let { Text(it, style = MaterialTheme.typography.bodySmall) }

            if (step.status == "Completed" && !step.hasFeedback) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                    listOf("Positive" to "Good", "Neutral" to "OK", "Negative" to "Bad").forEach { (rating, label) ->
                        OutlinedButton(onClick = { onFeedback(step.stepId, rating, feedbackText.ifEmpty { null }) },
                            modifier = Modifier.weight(1f)) { Text(label) }
                    }
                }
            }
        }
    }
}
