// XIIGen Advanced RAG Alternatives | Part 1 of 4
// Neo4j GraphRAG, LightRAG, nano-graphrag
// All implement IRagService from v12 interfaces

using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Skills.Rag.Advanced;

// ═══════════════════════════════════════════════════════
// 1. NEO4J GRAPHRAG — Industry standard, Claude SDK + MCP
// NuGet: Neo4j.Driver 5.*, Neo4j.GraphRAG (if available)
// ═══════════════════════════════════════════════════════

public class Neo4jGraphRagService : IRagService
{
    public string ProviderName => "neo4j-graphrag";
    public RagCapabilities Capabilities => new()
    {
        SupportsVectorSearch = true, SupportsHybridSearch = true,
        SupportsGraphTraversal = true, SupportsGraphQuery = true,
        MaxDimensions = 4096
    };

    private readonly Neo4j.Driver.IDriver _driver;
    private readonly IEmbeddingService _embeddings;
    private readonly ILogger _logger;

    // GraphRAG-specific: entity extraction + community detection
    private readonly IAiProvider _aiProvider;

    public Neo4jGraphRagService(string uri, string user, string password,
        IEmbeddingService embeddings, IAiProvider aiProvider, ILogger<Neo4jGraphRagService> logger)
    {
        _driver = Neo4j.Driver.GraphDatabase.Driver(uri, Neo4j.Driver.AuthTokens.Basic(user, password));
        _embeddings = embeddings; _aiProvider = aiProvider; _logger = logger;
    }

    /// <summary>
    /// GraphRAG entity extraction: uses AI to extract entities and relationships from text,
    /// then stores them as graph nodes + edges with embeddings.
    /// </summary>
    public async Task<DataProcessResult<GraphRagResult>> IngestWithGraphRagAsync(
        string text, string sourceId, string collection = "default", CancellationToken ct = default)
    {
        // Step 1: AI extracts entities and relationships
        var extraction = await _aiProvider.ExecuteAsync(new AiRequest
        {
            SystemPrompt = ENTITY_EXTRACTION_PROMPT,
            Prompt = $"Extract entities and relationships from:\n\n{text}",
            MaxTokens = 4000, Temperature = 0.1f
        }, ct);

        var entities = ParseEntities(extraction.Content);

        // Step 2: Generate embeddings for each entity
        var texts = entities.Nodes.Select(n => n.Description).ToList();
        var embeddingsList = await _embeddings.GenerateBatchEmbeddingsAsync(texts, ct);

        // Step 3: Store in Neo4j as graph with vector index
        await using var session = _driver.AsyncSession();
        await session.ExecuteWriteAsync(async tx =>
        {
            for (int i = 0; i < entities.Nodes.Count; i++)
            {
                var node = entities.Nodes[i];
                await tx.RunAsync(@"
                    MERGE (n:Entity {id: $id})
                    SET n.name = $name, n.type = $type, n.description = $desc,
                        n.embedding = $embedding, n.source = $source, n.collection = $collection,
                        n.updatedAt = datetime()
                    ", new
                {
                    id = $"{collection}:{node.Name.ToLowerInvariant().Replace(" ", "-")}",
                    name = node.Name, type = node.Type, desc = node.Description,
                    embedding = embeddingsList[i], source = sourceId, collection
                });
            }

            foreach (var edge in entities.Edges)
            {
                await tx.RunAsync($@"
                    MATCH (a:Entity {{name: $from, collection: $collection}})
                    MATCH (b:Entity {{name: $to, collection: $collection}})
                    MERGE (a)-[r:{SanitizeCypherLabel(edge.RelationType)}]->(b)
                    SET r.description = $desc, r.weight = $weight, r.source = $source
                    ", new
                {
                    from = edge.From, to = edge.To,
                    desc = edge.Description, weight = edge.Weight,
                    source = sourceId, collection
                });
            }
        });

        // Step 4: Community detection (Louvain algorithm via GDS)
        try
        {
            await session.ExecuteWriteAsync(async tx =>
            {
                await tx.RunAsync(@"
                    CALL gds.louvain.write({
                        nodeProjection: 'Entity',
                        relationshipProjection: { REL: { type: '*', orientation: 'UNDIRECTED' } },
                        writeProperty: 'community'
                    })");
            });
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "GDS community detection not available; skipping");
        }

        return DataProcessResult<GraphRagResult>.Success(new GraphRagResult
        {
            NodesCreated = entities.Nodes.Count,
            EdgesCreated = entities.Edges.Count,
            SourceId = sourceId
        });
    }

    /// <summary>
    /// GraphRAG query: combines vector similarity with graph traversal.
    /// 1. Vector search for seed entities
    /// 2. Graph expansion from seeds
    /// 3. Community-level summarization
    /// </summary>
    public async Task<DataProcessResult<List<RagSearchResult>>> GraphRagQueryAsync(
        string query, string collection, int topK = 5, int graphDepth = 2, CancellationToken ct = default)
    {
        var queryEmbedding = await _embeddings.GenerateEmbeddingAsync(query, ct);

        await using var session = _driver.AsyncSession();
        var results = await session.ExecuteReadAsync(async tx =>
        {
            // Vector search for seed nodes
            var cursor = await tx.RunAsync(@"
                CALL db.index.vector.queryNodes('entity-embeddings', $topK, $embedding)
                YIELD node, score
                WHERE node.collection = $collection
                WITH node, score
                // Expand graph from seeds
                CALL {
                    WITH node
                    MATCH path = (node)-[*1..$depth]-(related:Entity)
                    WHERE related.collection = $collection
                    RETURN related, length(path) as distance
                    ORDER BY distance
                    LIMIT 20
                }
                RETURN node.name AS seedName, node.description AS seedDesc, score,
                       collect(DISTINCT {name: related.name, desc: related.description,
                               type: related.type, community: related.community,
                               distance: distance}) AS neighbors
                ORDER BY score DESC
                ", new { topK, embedding = queryEmbedding, collection, depth = graphDepth });

            var items = new List<RagSearchResult>();
            await foreach (var record in cursor)
            {
                var neighbors = record["neighbors"].As<List<Dictionary<string, object>>>();
                var context = $"Entity: {record["seedName"].As<string>()}\n{record["seedDesc"].As<string>()}\n\nRelated:\n";
                context += string.Join("\n", neighbors.Select(n => $"  - {n["name"]} ({n["type"]}): {n["desc"]}"));

                items.Add(new RagSearchResult
                {
                    Id = record["seedName"].As<string>(),
                    Content = context,
                    Score = record["score"].As<float>(),
                    Metadata = new Dictionary<string, object>
                    {
                        ["neighborCount"] = neighbors.Count,
                        ["community"] = neighbors.FirstOrDefault()?["community"]
                    }
                });
            }
            return items;
        });

        return DataProcessResult<List<RagSearchResult>>.Success(results);
    }

    // Standard IRagService implementations delegate to existing Neo4j service
    public Task<DataProcessResult<string>> StoreEmbeddingAsync(string collection, string id, float[] embedding,
        Dictionary<string, object> metadata = null, string content = null, CancellationToken ct = default)
        => StoreEmbeddingCoreAsync(collection, id, embedding, metadata, content, ct);

    public Task<DataProcessResult<List<RagSearchResult>>> VectorSearchAsync(string collection, float[] queryEmbedding,
        int topK = 5, Dictionary<string, object> filter = null, CancellationToken ct = default)
        => VectorSearchCoreAsync(collection, queryEmbedding, topK, filter, ct);

    public Task<DataProcessResult<List<RagSearchResult>>> HybridSearchAsync(string collection, string textQuery,
        float[] queryEmbedding, int topK = 5, Dictionary<string, object> filter = null, CancellationToken ct = default)
        => HybridSearchCoreAsync(collection, textQuery, queryEmbedding, topK, filter, ct);

    public Task<DataProcessResult<string>> StoreNodeAsync(string label, string id,
        Dictionary<string, object> properties, float[] embedding = null, CancellationToken ct = default)
        => StoreNodeCoreAsync(label, id, properties, embedding, ct);

    public Task<DataProcessResult<string>> StoreEdgeAsync(string fromId, string toId, string edgeType,
        Dictionary<string, object> properties = null, CancellationToken ct = default)
        => StoreEdgeCoreAsync(fromId, toId, edgeType, properties, ct);

    public Task<DataProcessResult<List<RagGraphResult>>> TraverseAsync(string startNodeId, string edgeType,
        int maxDepth = 3, Dictionary<string, object> filter = null, CancellationToken ct = default)
        => TraverseCoreAsync(startNodeId, edgeType, maxDepth, filter, ct);

    public Task<DataProcessResult<List<RagGraphResult>>> GraphQueryAsync(string query,
        Dictionary<string, object> parameters = null, CancellationToken ct = default)
        => GraphQueryCoreAsync(query, parameters, ct);

    public Task<DataProcessResult<List<string>>> StoreDocumentChunksAsync(string collection, string documentId,
        string content, ChunkingOptions options = null, CancellationToken ct = default)
        => StoreDocumentChunksCoreAsync(collection, documentId, content, options, ct);

    // Core implementations (abbreviated — follow same patterns as v12 Neo4jRagService)
    private async Task<DataProcessResult<string>> StoreEmbeddingCoreAsync(string collection, string id, float[] embedding, Dictionary<string, object> metadata, string content, CancellationToken ct)
    {
        await using var session = _driver.AsyncSession();
        await session.ExecuteWriteAsync(async tx =>
        {
            await tx.RunAsync("MERGE (n:Vector {id: $id, collection: $collection}) SET n.embedding = $embedding, n.content = $content, n.metadata = $metadata",
                new { id, collection, embedding, content, metadata = JsonSerializer.Serialize(metadata) });
        });
        return DataProcessResult<string>.Success(id);
    }

    private async Task<DataProcessResult<List<RagSearchResult>>> VectorSearchCoreAsync(string collection, float[] queryEmbedding, int topK, Dictionary<string, object> filter, CancellationToken ct)
    {
        await using var session = _driver.AsyncSession();
        var results = await session.ExecuteReadAsync(async tx =>
        {
            var cursor = await tx.RunAsync("CALL db.index.vector.queryNodes('entity-embeddings', $topK, $embedding) YIELD node, score WHERE node.collection = $collection RETURN node, score",
                new { topK, embedding = queryEmbedding, collection });
            var items = new List<RagSearchResult>();
            await foreach (var r in cursor)
                items.Add(new RagSearchResult { Id = r["node"].As<Neo4j.Driver.INode>()["id"].As<string>(), Score = r["score"].As<float>(), Content = r["node"].As<Neo4j.Driver.INode>()["content"]?.As<string>() });
            return items;
        });
        return DataProcessResult<List<RagSearchResult>>.Success(results);
    }

    private Task<DataProcessResult<List<RagSearchResult>>> HybridSearchCoreAsync(string c, string t, float[] e, int k, Dictionary<string, object> f, CancellationToken ct) => VectorSearchCoreAsync(c, e, k, f, ct);
    private async Task<DataProcessResult<string>> StoreNodeCoreAsync(string label, string id, Dictionary<string, object> props, float[] embedding, CancellationToken ct) { await using var s = _driver.AsyncSession(); await s.ExecuteWriteAsync(async tx => { await tx.RunAsync($"MERGE (n:{SanitizeCypherLabel(label)} {{id: $id}}) SET n += $props", new { id, props }); }); return DataProcessResult<string>.Success(id); }
    private async Task<DataProcessResult<string>> StoreEdgeCoreAsync(string from, string to, string type, Dictionary<string, object> props, CancellationToken ct) { await using var s = _driver.AsyncSession(); await s.ExecuteWriteAsync(async tx => { await tx.RunAsync($"MATCH (a {{id: $from}}), (b {{id: $to}}) MERGE (a)-[r:{SanitizeCypherLabel(type)}]->(b) SET r += $props", new { from, to, props = props ?? new() }); }); return DataProcessResult<string>.Success($"{from}->{to}"); }
    private async Task<DataProcessResult<List<RagGraphResult>>> TraverseCoreAsync(string start, string edge, int depth, Dictionary<string, object> filter, CancellationToken ct) { await using var s = _driver.AsyncSession(); var r = await s.ExecuteReadAsync(async tx => { var c = await tx.RunAsync($"MATCH path=(n {{id: $start}})-[*1..{depth}]-(m) RETURN m, length(path) as depth ORDER BY depth LIMIT 50", new { start }); var items = new List<RagGraphResult>(); await foreach (var rec in c) items.Add(new RagGraphResult { NodeId = rec["m"].As<Neo4j.Driver.INode>()["id"]?.As<string>(), Depth = rec["depth"].As<int>() }); return items; }); return DataProcessResult<List<RagGraphResult>>.Success(r); }
    private async Task<DataProcessResult<List<RagGraphResult>>> GraphQueryCoreAsync(string query, Dictionary<string, object> parameters, CancellationToken ct) { await using var s = _driver.AsyncSession(); var r = await s.ExecuteReadAsync(async tx => { var c = await tx.RunAsync(query, parameters); var items = new List<RagGraphResult>(); await foreach (var rec in c) items.Add(new RagGraphResult { Data = rec.Values.ToDictionary(kv => kv.Key, kv => kv.Value as object) }); return items; }); return DataProcessResult<List<RagGraphResult>>.Success(r); }
    private async Task<DataProcessResult<List<string>>> StoreDocumentChunksCoreAsync(string collection, string docId, string content, ChunkingOptions options, CancellationToken ct) { var chunks = ChunkText(content, options ?? new()); var ids = new List<string>(); for (int i = 0; i < chunks.Count; i++) { var id = $"{docId}-chunk-{i}"; var emb = await _embeddings.GenerateEmbeddingAsync(chunks[i], ct); await StoreEmbeddingCoreAsync(collection, id, emb, new() { ["documentId"] = docId, ["chunkIndex"] = i }, chunks[i], ct); ids.Add(id); } return DataProcessResult<List<string>>.Success(ids); }

    private static List<string> ChunkText(string text, ChunkingOptions opts) { var size = opts.ChunkSize > 0 ? opts.ChunkSize : 500; var chunks = new List<string>(); for (int i = 0; i < text.Length; i += size) chunks.Add(text.Substring(i, Math.Min(size, text.Length - i))); return chunks; }
    private static string SanitizeCypherLabel(string s) => System.Text.RegularExpressions.Regex.Replace(s, @"[^a-zA-Z0-9_]", "_");
    private EntityExtractionResult ParseEntities(string content) { try { return JsonSerializer.Deserialize<EntityExtractionResult>(content); } catch { return new(); } }

    private const string ENTITY_EXTRACTION_PROMPT = """
        Extract entities and relationships from text. Return ONLY JSON:
        {"nodes":[{"name":"...","type":"Person|Organization|Concept|Technology|Event","description":"..."}],
         "edges":[{"from":"...","to":"...","relationType":"USES|DEPENDS_ON|CREATED_BY|PART_OF|RELATED_TO","description":"...","weight":1.0}]}
        """;
}

// ═══════════════════════════════════════════════════════
// 2. LIGHTRAG — Dual-level retrieval, 80-90% fewer API calls
// pip: lightrag (Python via subprocess or HTTP bridge)
// ═══════════════════════════════════════════════════════

public class LightRagService : IRagService
{
    public string ProviderName => "lightrag";
    public RagCapabilities Capabilities => new()
    {
        SupportsVectorSearch = true, SupportsHybridSearch = true,
        SupportsGraphTraversal = true, SupportsGraphQuery = false,
        MaxDimensions = 3072
    };

    private readonly HttpClient _http;
    private readonly string _baseUrl;
    private readonly ILogger _logger;

    // LightRAG uses a Python server; we communicate via HTTP
    // Start: lightrag serve --host 0.0.0.0 --port 8020
    public LightRagService(string baseUrl, ILogger<LightRagService> logger)
    {
        _baseUrl = baseUrl.TrimEnd('/');
        _http = new HttpClient { BaseAddress = new Uri(_baseUrl) };
        _logger = logger;
    }

    /// <summary>
    /// LightRAG's dual-level retrieval: entities (specific) + themes (high-level).
    /// Mode: naive | local | global | hybrid
    /// - naive: standard vector similarity
    /// - local: entity-level graph search (specific facts)
    /// - global: theme/community-level search (broad patterns)
    /// - hybrid: combines local + global (recommended)
    /// </summary>
    public async Task<DataProcessResult<List<RagSearchResult>>> QueryAsync(
        string query, string mode = "hybrid", int topK = 5, CancellationToken ct = default)
    {
        var response = await _http.PostAsJsonAsync("/query", new
        {
            query, mode, top_k = topK
        }, ct);

        if (!response.IsSuccessStatusCode)
            return DataProcessResult<List<RagSearchResult>>.Error($"LightRAG query failed: {response.StatusCode}");

        var result = await response.Content.ReadFromJsonAsync<LightRagQueryResult>(ct);
        var items = result.Results.Select(r => new RagSearchResult
        {
            Id = r.Id, Content = r.Content, Score = r.Score,
            Metadata = new Dictionary<string, object>
            {
                ["level"] = r.Level, // "entity" or "theme"
                ["source"] = r.Source, ["mode"] = mode
            }
        }).ToList();

        return DataProcessResult<List<RagSearchResult>>.Success(items);
    }

    /// <summary>Insert document into LightRAG (auto entity extraction + graph building).</summary>
    public async Task<DataProcessResult<string>> IngestAsync(string text, string sourceId = null, CancellationToken ct = default)
    {
        var response = await _http.PostAsJsonAsync("/insert", new { text, source_id = sourceId }, ct);
        if (!response.IsSuccessStatusCode)
            return DataProcessResult<string>.Error($"LightRAG insert failed: {response.StatusCode}");
        return DataProcessResult<string>.Success(sourceId ?? "ingested");
    }

    // IRagService standard implementations
    public async Task<DataProcessResult<string>> StoreEmbeddingAsync(string collection, string id, float[] embedding, Dictionary<string, object> metadata = null, string content = null, CancellationToken ct = default)
    {
        if (content != null) return await IngestAsync(content, id, ct);
        return DataProcessResult<string>.Success(id);
    }

    public async Task<DataProcessResult<List<RagSearchResult>>> VectorSearchAsync(string collection, float[] queryEmbedding, int topK = 5, Dictionary<string, object> filter = null, CancellationToken ct = default)
    {
        // LightRAG's naive mode = pure vector search
        return await QueryAsync(filter?["query"]?.ToString() ?? "", "naive", topK, ct);
    }

    public async Task<DataProcessResult<List<RagSearchResult>>> HybridSearchAsync(string collection, string textQuery, float[] queryEmbedding, int topK = 5, Dictionary<string, object> filter = null, CancellationToken ct = default)
        => await QueryAsync(textQuery, "hybrid", topK, ct);

    public async Task<DataProcessResult<List<RagGraphResult>>> TraverseAsync(string startNodeId, string edgeType, int maxDepth = 3, Dictionary<string, object> filter = null, CancellationToken ct = default)
    {
        var result = await QueryAsync($"What is related to {startNodeId}?", "local", maxDepth * 3, ct);
        return DataProcessResult<List<RagGraphResult>>.Success(
            result.Data?.Select(r => new RagGraphResult { NodeId = r.Id, Data = r.Metadata }).ToList() ?? []);
    }

    // Not supported
    public Task<DataProcessResult<string>> StoreNodeAsync(string l, string i, Dictionary<string, object> p, float[] e = null, CancellationToken c = default) => Task.FromResult(DataProcessResult<string>.Error("Use IngestAsync for LightRAG"));
    public Task<DataProcessResult<string>> StoreEdgeAsync(string f, string t, string e, Dictionary<string, object> p = null, CancellationToken c = default) => Task.FromResult(DataProcessResult<string>.Error("LightRAG auto-extracts edges"));
    public Task<DataProcessResult<List<RagGraphResult>>> GraphQueryAsync(string q, Dictionary<string, object> p = null, CancellationToken c = default) => Task.FromResult(DataProcessResult<List<RagGraphResult>>.Error("Use QueryAsync with mode"));

    public async Task<DataProcessResult<List<string>>> StoreDocumentChunksAsync(string collection, string documentId, string content, ChunkingOptions options = null, CancellationToken ct = default)
    {
        // LightRAG handles its own chunking internally
        await IngestAsync(content, documentId, ct);
        return DataProcessResult<List<string>>.Success([documentId]);
    }
}

// ═══════════════════════════════════════════════════════
// 3. NANO-GRAPHRAG — Minimal, hackable Microsoft GraphRAG reimplementation
// pip: nano-graphrag (Python via HTTP bridge)
// ═══════════════════════════════════════════════════════

public class NanoGraphRagService : IRagService
{
    public string ProviderName => "nano-graphrag";
    public RagCapabilities Capabilities => new()
    {
        SupportsVectorSearch = true, SupportsHybridSearch = true,
        SupportsGraphTraversal = true, SupportsGraphQuery = false,
        MaxDimensions = 3072
    };

    private readonly HttpClient _http;
    private readonly ILogger _logger;

    // nano-graphrag runs as Python process; bridge via HTTP wrapper
    // See: https://github.com/gusye1234/nano-graphrag
    public NanoGraphRagService(string baseUrl, ILogger<NanoGraphRagService> logger)
    {
        _http = new HttpClient { BaseAddress = new Uri(baseUrl) };
        _logger = logger;
    }

    /// <summary>
    /// Query modes: local (entity-centric), global (community summaries), naive (vector only)
    /// nano-graphrag follows Microsoft GraphRAG's local/global search pattern.
    /// </summary>
    public async Task<DataProcessResult<List<RagSearchResult>>> QueryAsync(
        string query, string mode = "local", int topK = 5, CancellationToken ct = default)
    {
        var response = await _http.PostAsJsonAsync("/query", new { query, mode, top_k = topK }, ct);
        if (!response.IsSuccessStatusCode)
            return DataProcessResult<List<RagSearchResult>>.Error($"nano-graphrag failed: {response.StatusCode}");

        var result = await response.Content.ReadFromJsonAsync<NanoGraphRagResult>(ct);
        return DataProcessResult<List<RagSearchResult>>.Success(
            result.Chunks.Select((c, i) => new RagSearchResult
            {
                Id = $"chunk-{i}", Content = c.Content, Score = c.Score,
                Metadata = new() { ["mode"] = mode, ["community"] = c.CommunityId }
            }).ToList());
    }

    public async Task<DataProcessResult<string>> IngestAsync(string text, string sourceId, CancellationToken ct = default)
    {
        await _http.PostAsJsonAsync("/insert", new { content = text, doc_id = sourceId }, ct);
        return DataProcessResult<string>.Success(sourceId);
    }

    // Standard IRagService delegations
    public async Task<DataProcessResult<string>> StoreEmbeddingAsync(string c, string id, float[] e, Dictionary<string, object> m = null, string content = null, CancellationToken ct = default) { if (content != null) await IngestAsync(content, id, ct); return DataProcessResult<string>.Success(id); }
    public async Task<DataProcessResult<List<RagSearchResult>>> VectorSearchAsync(string c, float[] e, int k = 5, Dictionary<string, object> f = null, CancellationToken ct = default) => await QueryAsync(f?["query"]?.ToString() ?? "", "naive", k, ct);
    public async Task<DataProcessResult<List<RagSearchResult>>> HybridSearchAsync(string c, string t, float[] e, int k = 5, Dictionary<string, object> f = null, CancellationToken ct = default) => await QueryAsync(t, "local", k, ct);
    public async Task<DataProcessResult<List<RagGraphResult>>> TraverseAsync(string s, string e, int d = 3, Dictionary<string, object> f = null, CancellationToken ct = default) { var r = await QueryAsync($"entities related to {s}", "local", d * 3, ct); return DataProcessResult<List<RagGraphResult>>.Success(r.Data?.Select(x => new RagGraphResult { NodeId = x.Id, Data = x.Metadata }).ToList() ?? []); }
    public Task<DataProcessResult<string>> StoreNodeAsync(string l, string i, Dictionary<string, object> p, float[] e = null, CancellationToken c = default) => Task.FromResult(DataProcessResult<string>.Error("Use IngestAsync"));
    public Task<DataProcessResult<string>> StoreEdgeAsync(string f, string t, string e, Dictionary<string, object> p = null, CancellationToken c = default) => Task.FromResult(DataProcessResult<string>.Error("Auto-extracted"));
    public Task<DataProcessResult<List<RagGraphResult>>> GraphQueryAsync(string q, Dictionary<string, object> p = null, CancellationToken c = default) => Task.FromResult(DataProcessResult<List<RagGraphResult>>.Error("Use QueryAsync"));
    public async Task<DataProcessResult<List<string>>> StoreDocumentChunksAsync(string c, string d, string content, ChunkingOptions o = null, CancellationToken ct = default) { await IngestAsync(content, d, ct); return DataProcessResult<List<string>>.Success([d]); }
}

// ─── Shared Models ───────────────────────────────────────
public class GraphRagResult { public int NodesCreated { get; set; } public int EdgesCreated { get; set; } public string SourceId { get; set; } }
public class EntityExtractionResult { public List<ExtractedNode> Nodes { get; set; } = []; public List<ExtractedEdge> Edges { get; set; } = []; }
public class ExtractedNode { public string Name { get; set; } public string Type { get; set; } public string Description { get; set; } }
public class ExtractedEdge { public string From { get; set; } public string To { get; set; } public string RelationType { get; set; } public string Description { get; set; } public float Weight { get; set; } = 1.0f; }
public class LightRagQueryResult { public List<LightRagItem> Results { get; set; } = []; }
public class LightRagItem { public string Id { get; set; } public string Content { get; set; } public float Score { get; set; } public string Level { get; set; } public string Source { get; set; } }
public class NanoGraphRagResult { public List<NanoChunk> Chunks { get; set; } = []; }
public class NanoChunk { public string Content { get; set; } public float Score { get; set; } public string CommunityId { get; set; } }
