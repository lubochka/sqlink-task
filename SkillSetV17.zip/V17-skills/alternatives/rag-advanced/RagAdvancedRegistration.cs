// XIIGen.Skills.Rag.Advanced/RagAdvancedRegistration.cs | .NET 9
// DI registration for all 10 GraphRAG alternatives. Select via config:
// "Rag:Provider": "neo4j-graphrag|lightrag|nano-graphrag|langchain-kg|
//                  llamaindex-graphrag|graphlit|memgraph|neptune-bedrock|
//                  contextual-ai|hybrid-rag"

using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using XIIGen.Core.Interfaces;

namespace XIIGen.Skills.Rag.Advanced;

public static class RagAdvancedRegistration
{
    /// <summary>
    /// Registers the selected GraphRAG provider.
    /// All providers implement IRagService for uniform access.
    /// </summary>
    public static IServiceCollection AddXIIGenAdvancedRag(
        this IServiceCollection services, IConfiguration config)
    {
        var provider = config["Rag:Provider"] ?? "neo4j-graphrag";

        services.AddSingleton<IRagService>(sp =>
        {
            var logger = sp.GetRequiredService<ILoggerFactory>();
            var embeddings = sp.GetRequiredService<IEmbeddingService>();
            var ai = sp.GetRequiredService<IAiProvider>();

            return provider switch
            {
                // ── Enterprise Graph ─────────────────────────
                "neo4j-graphrag" => new Neo4jGraphRagService(
                    config["Rag:Neo4j:Uri"] ?? "bolt://localhost:7687",
                    config["Rag:Neo4j:User"] ?? "neo4j",
                    config["Rag:Neo4j:Password"] ?? "password",
                    embeddings, ai,
                    logger.CreateLogger<Neo4jGraphRagService>()),

                // ── Lightweight / Open Source ────────────────
                "lightrag" => new LightRagService(
                    config["Rag:LightRag:BaseUrl"] ?? "http://localhost:8020",
                    logger.CreateLogger<LightRagService>()),

                "nano-graphrag" => new NanoGraphRagService(
                    config["Rag:NanoGraphRag:BaseUrl"] ?? "http://localhost:8025",
                    logger.CreateLogger<NanoGraphRagService>()),

                // ── Framework-based ─────────────────────────
                "langchain-kg" => new LangChainKgRagService(
                    config["Rag:LangChain:BaseUrl"] ?? "http://localhost:8030",
                    logger.CreateLogger<LangChainKgRagService>()),

                "llamaindex-graphrag" => new LlamaIndexGraphRagService(
                    config["Rag:LlamaIndex:BaseUrl"] ?? "http://localhost:8040",
                    logger.CreateLogger<LlamaIndexGraphRagService>()),

                // ── Managed SaaS ────────────────────────────
                "graphlit" => new GraphlitRagService(
                    config["Rag:Graphlit:ApiKey"] ?? throw new InvalidOperationException("Rag:Graphlit:ApiKey required"),
                    config["Rag:Graphlit:ProjectId"] ?? throw new InvalidOperationException("Rag:Graphlit:ProjectId required"),
                    logger.CreateLogger<GraphlitRagService>()),

                // ── Real-time / Streaming ───────────────────
                "memgraph" => new MemgraphRagService(
                    config["Rag:Memgraph:Uri"] ?? "bolt://localhost:7687",
                    logger.CreateLogger<MemgraphRagService>()),

                // ── AWS Native ──────────────────────────────
                "neptune-bedrock" => new NeptuneBedrockRagService(
                    config["Rag:Neptune:Endpoint"] ?? throw new InvalidOperationException("Rag:Neptune:Endpoint required"),
                    config["Rag:Neptune:GraphId"] ?? throw new InvalidOperationException("Rag:Neptune:GraphId required"),
                    config["Rag:Neptune:Region"] ?? "us-east-1",
                    logger.CreateLogger<NeptuneBedrockRagService>()),

                // ── Agentic ─────────────────────────────────
                "contextual-ai" => new ContextualAiRagService(
                    config["Rag:ContextualAi:ApiKey"] ?? throw new InvalidOperationException("Rag:ContextualAi:ApiKey required"),
                    logger.CreateLogger<ContextualAiRagService>()),

                // ── DIY Hybrid ──────────────────────────────
                "hybrid-rag" => BuildHybridRag(sp, config, logger),

                _ => throw new InvalidOperationException(
                    $"Unknown RAG provider: '{provider}'. Options: neo4j-graphrag, lightrag, nano-graphrag, " +
                    "langchain-kg, llamaindex-graphrag, graphlit, memgraph, neptune-bedrock, contextual-ai, hybrid-rag")
            };
        });

        return services;
    }

    private static HybridRagService BuildHybridRag(
        IServiceProvider sp, IConfiguration config, ILoggerFactory loggerFactory)
    {
        var vectorProvider = config["Rag:Hybrid:VectorBackend"] ?? "elasticsearch-knn";
        var graphProvider = config["Rag:Hybrid:GraphBackend"] ?? "neo4j-graphrag";

        // Build vector backend
        IRagService vectorBackend = vectorProvider switch
        {
            "elasticsearch-knn" => sp.GetServices<IRagService>()
                .FirstOrDefault(s => s.ProviderName == "elasticsearch-knn")
                ?? throw new InvalidOperationException("Register elasticsearch-knn RAG first"),
            "pinecone" => sp.GetServices<IRagService>()
                .FirstOrDefault(s => s.ProviderName == "pinecone")
                ?? throw new InvalidOperationException("Register pinecone RAG first"),
            _ => throw new InvalidOperationException($"Unknown vector backend: {vectorProvider}")
        };

        // Build graph backend
        IRagService graphBackend = graphProvider switch
        {
            "neo4j-graphrag" => new Neo4jGraphRagService(
                config["Rag:Neo4j:Uri"] ?? "bolt://localhost:7687",
                config["Rag:Neo4j:User"] ?? "neo4j",
                config["Rag:Neo4j:Password"] ?? "password",
                sp.GetRequiredService<IEmbeddingService>(),
                sp.GetRequiredService<IAiProvider>(),
                loggerFactory.CreateLogger<Neo4jGraphRagService>()),
            "memgraph" => new MemgraphRagService(
                config["Rag:Memgraph:Uri"] ?? "bolt://localhost:7687",
                loggerFactory.CreateLogger<MemgraphRagService>()),
            _ => throw new InvalidOperationException($"Unknown graph backend: {graphProvider}")
        };

        return new HybridRagService(vectorBackend, graphBackend,
            sp.GetRequiredService<IAiProvider>(),
            loggerFactory.CreateLogger<HybridRagService>());
    }
}

// ═══════════════════════════════════════════════════════
// COMPARISON MATRIX (for documentation / MCP tool)
// ═══════════════════════════════════════════════════════

public static class RagComparisonMatrix
{
    public static List<RagProviderInfo> GetAllProviders() =>
    [
        new("neo4j-graphrag", "Neo4j GraphRAG", "Enterprise", true, true, true, true,
            "Cypher + Claude SDK + MCP", "Free tier / $65+/mo",
            "Industry standard. Best ecosystem and Claude integration."),
        new("lightrag", "LightRAG", "Lightweight", true, true, true, false,
            "Dual-level (entity+theme), 80-90% fewer API calls", "Open source (MIT)",
            "Budget-conscious. HKU research project."),
        new("nano-graphrag", "nano-graphrag", "Lightweight", true, true, true, false,
            "Microsoft GraphRAG reimplementation, hackable", "Open source",
            "Full control. Clean minimal codebase."),
        new("langchain-kg", "LangChain KG", "Framework", true, true, true, true,
            "GraphCypherQAChain, 95K+ GitHub stars", "Open source",
            "Already in LangChain ecosystem."),
        new("llamaindex-graphrag", "LlamaIndex GraphRAG", "Framework", true, true, true, true,
            "160+ connectors, AWS Bedrock tutorial", "Open source",
            "Data-heavy pipelines, rapid prototyping."),
        new("graphlit", "Graphlit", "Managed SaaS", true, true, true, false,
            "Auto KG from docs/audio/video, zero-ops", "Free 1GB / $49+/mo",
            "Zero infrastructure management."),
        new("memgraph", "Memgraph", "Real-time", false, false, true, true,
            "In-memory, Kafka/Pulsar streaming", "Open source / Enterprise",
            "Real-time analytics, fraud detection."),
        new("neptune-bedrock", "Neptune + Bedrock", "AWS Native", true, false, true, true,
            "Fully managed, official Claude via Bedrock", "No free tier",
            "Enterprise AWS-first shops."),
        new("contextual-ai", "Contextual AI", "Agentic", true, true, true, false,
            "No static graph, agent-driven traversal", "Enterprise pricing",
            "Graph-like reasoning without graph maintenance."),
        new("hybrid-rag", "HybridRAG (DIY)", "Architecture", true, true, true, true,
            "Any vector DB + graph DB + re-ranker", "Component costs",
            "Maximum flexibility and customization."),
    ];
}

public record RagProviderInfo(
    string Id, string Name, string Category,
    bool VectorSearch, bool HybridSearch, bool GraphTraversal, bool GraphQuery,
    string KeyFeature, string Pricing, string BestFor);
