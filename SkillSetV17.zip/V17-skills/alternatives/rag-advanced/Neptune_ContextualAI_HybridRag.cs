// XIIGen Advanced RAG Alternatives | Part 3 of 4
// Neptune+Bedrock, Contextual AI, HybridRAG (DIY)

using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Skills.Rag.Advanced;

// ═══════════════════════════════════════════════════════
// 8. NEPTUNE + BEDROCK — AWS-native managed stack
// NuGet: AWSSDK.NeptuneGraph, AWSSDK.BedrockRuntime
// ═══════════════════════════════════════════════════════

public class NeptuneBedrockRagService : IRagService
{
    public string ProviderName => "neptune-bedrock";
    public RagCapabilities Capabilities => new()
    {
        SupportsVectorSearch = true, SupportsHybridSearch = false,
        SupportsGraphTraversal = true, SupportsGraphQuery = true,
        MaxDimensions = 3072
    };

    private readonly HttpClient _neptuneHttp;
    private readonly HttpClient _bedrockHttp;
    private readonly string _graphId;
    private readonly string _region;
    private readonly ILogger _logger;

    public NeptuneBedrockRagService(string neptuneEndpoint, string graphId,
        string region, ILogger<NeptuneBedrockRagService> logger)
    {
        _neptuneHttp = new HttpClient { BaseAddress = new Uri(neptuneEndpoint) };
        _graphId = graphId; _region = region; _logger = logger;
        // In production: use AWS SDK with IAM auth via SigV4
        _bedrockHttp = new HttpClient { BaseAddress = new Uri($"https://bedrock-runtime.{region}.amazonaws.com") };
    }

    /// <summary>
    /// Neptune Analytics vector search using DiskANN index.
    /// Official AWS tutorial pattern: embed with Bedrock → search in Neptune.
    /// </summary>
    public async Task<DataProcessResult<List<RagSearchResult>>> VectorSearchAsync(
        string collection, float[] queryEmbedding, int topK = 5,
        Dictionary<string, object> filter = null, CancellationToken ct = default)
    {
        // Neptune Analytics openCypher with vector search
        var query = @"
            CALL neptune.algo.vectors.topKByEmbedding($embedding, {topK: $topK})
            YIELD node, score
            WHERE node.collection = $collection
            RETURN node.id AS id, node.content AS content, score
            ORDER BY score DESC";

        var response = await NeptuneCypherAsync(query, new
        {
            embedding = queryEmbedding, topK, collection
        }, ct);

        return DataProcessResult<List<RagSearchResult>>.Success(
            response.Select(r => new RagSearchResult
            {
                Id = r["id"]?.ToString(),
                Content = r["content"]?.ToString(),
                Score = Convert.ToSingle(r["score"])
            }).ToList());
    }

    /// <summary>
    /// Generate embedding using Amazon Bedrock (Titan or Cohere).
    /// Then query Neptune graph with the embedding.
    /// </summary>
    public async Task<float[]> EmbedWithBedrockAsync(string text, CancellationToken ct = default)
    {
        var response = await _bedrockHttp.PostAsJsonAsync(
            "/model/amazon.titan-embed-text-v2:0/invoke",
            new { inputText = text }, ct);
        var result = await response.Content.ReadFromJsonAsync<JsonElement>(ct);
        return result.GetProperty("embedding").EnumerateArray()
            .Select(e => (float)e.GetDouble()).ToArray();
    }

    /// <summary>
    /// Full GraphRAG pattern: Claude (Bedrock) extracts entities → Neptune stores graph.
    /// </summary>
    public async Task<DataProcessResult<string>> IngestWithBedrockAsync(
        string text, string sourceId, CancellationToken ct = default)
    {
        // Step 1: Claude on Bedrock extracts entities
        var extractResponse = await _bedrockHttp.PostAsJsonAsync(
            "/model/anthropic.claude-sonnet-4-5-v2:0/invoke",
            new
            {
                anthropic_version = "bedrock-2023-05-31",
                max_tokens = 4000,
                messages = new[] { new { role = "user", content = $"Extract entities and relationships as JSON: {text}" } }
            }, ct);

        var extractResult = await extractResponse.Content.ReadFromJsonAsync<JsonElement>(ct);
        var entities = extractResult.GetProperty("content")[0].GetProperty("text").GetString();

        // Step 2: Store in Neptune
        var embedding = await EmbedWithBedrockAsync(text, ct);
        await NeptuneCypherAsync(
            "CREATE (n:Document {id: $id, content: $content, embedding: $embedding, source: $source})",
            new { id = sourceId, content = text, embedding, source = sourceId }, ct);

        return DataProcessResult<string>.Success(sourceId);
    }

    private async Task<List<Dictionary<string, object>>> NeptuneCypherAsync(
        string query, object parameters, CancellationToken ct)
    {
        var response = await _neptuneHttp.PostAsJsonAsync("/opencypher", new
        {
            query, parameters
        }, ct);
        return await response.Content.ReadFromJsonAsync<List<Dictionary<string, object>>>(ct) ?? [];
    }

    // Standard IRagService
    public async Task<DataProcessResult<string>> StoreEmbeddingAsync(string c, string id, float[] e, Dictionary<string, object> m = null, string content = null, CancellationToken ct = default)
    { await NeptuneCypherAsync("MERGE (n:Vector {id: $id, collection: $c}) SET n.embedding = $e, n.content = $content", new { id, c, e, content }, ct); return DataProcessResult<string>.Success(id); }

    public Task<DataProcessResult<List<RagSearchResult>>> HybridSearchAsync(string c, string t, float[] e, int k = 5, Dictionary<string, object> f = null, CancellationToken ct = default) => VectorSearchAsync(c, e, k, f, ct);

    public async Task<DataProcessResult<string>> StoreNodeAsync(string l, string id, Dictionary<string, object> p, float[] e = null, CancellationToken ct = default)
    { await NeptuneCypherAsync($"MERGE (n:`{l}` {{id: $id}}) SET n += $p", new { id, p }, ct); return DataProcessResult<string>.Success(id); }

    public async Task<DataProcessResult<string>> StoreEdgeAsync(string f, string t, string edgeType, Dictionary<string, object> p = null, CancellationToken ct = default)
    { await NeptuneCypherAsync($"MATCH (a {{id: $f}}), (b {{id: $t}}) MERGE (a)-[r:`{edgeType}`]->(b) SET r += $p", new { f, t, p = p ?? new() }, ct); return DataProcessResult<string>.Success($"{f}->{t}"); }

    public async Task<DataProcessResult<List<RagGraphResult>>> TraverseAsync(string s, string e, int d = 3, Dictionary<string, object> f = null, CancellationToken ct = default)
    {
        var results = await NeptuneCypherAsync($"MATCH path=(n {{id: $s}})-[*1..{d}]-(m) RETURN m.id AS id, length(path) AS depth LIMIT 50", new { s }, ct);
        return DataProcessResult<List<RagGraphResult>>.Success(results.Select(r => new RagGraphResult { NodeId = r["id"]?.ToString(), Depth = Convert.ToInt32(r["depth"]) }).ToList());
    }

    public async Task<DataProcessResult<List<RagGraphResult>>> GraphQueryAsync(string q, Dictionary<string, object> p = null, CancellationToken ct = default)
    { var r = await NeptuneCypherAsync(q, p, ct); return DataProcessResult<List<RagGraphResult>>.Success(r.Select(x => new RagGraphResult { Data = x }).ToList()); }

    public async Task<DataProcessResult<List<string>>> StoreDocumentChunksAsync(string c, string d, string content, ChunkingOptions o = null, CancellationToken ct = default)
    { await IngestWithBedrockAsync(content, d, ct); return DataProcessResult<List<string>>.Success([d]); }
}

// ═══════════════════════════════════════════════════════
// 9. CONTEXTUAL AI — Agentic approach, no static graph
// API: https://api.contextual.ai/v1
// ═══════════════════════════════════════════════════════

public class ContextualAiRagService : IRagService
{
    public string ProviderName => "contextual-ai";
    public RagCapabilities Capabilities => new()
    {
        SupportsVectorSearch = true, SupportsHybridSearch = true,
        SupportsGraphTraversal = true, // Agent-driven, not static graph
        SupportsGraphQuery = false,
        MaxDimensions = 3072
    };

    private readonly HttpClient _http;
    private readonly ILogger _logger;

    public ContextualAiRagService(string apiKey, ILogger<ContextualAiRagService> logger)
    {
        _http = new HttpClient { BaseAddress = new Uri("https://api.contextual.ai/v1/") };
        _http.DefaultRequestHeaders.Add("Authorization", $"Bearer {apiKey}");
        _logger = logger;
    }

    /// <summary>
    /// Agentic retrieval: agent decides what to search, when to traverse, when to stop.
    /// No pre-built graph — agent builds traversal paths on-the-fly.
    /// </summary>
    public async Task<DataProcessResult<List<RagSearchResult>>> AgenticQueryAsync(
        string query, string datastore = "default", int maxSteps = 5, CancellationToken ct = default)
    {
        var response = await _http.PostAsJsonAsync("query", new
        {
            query, datastore, max_agent_steps = maxSteps,
            model = "contextual-grounded",
            include_reasoning = true
        }, ct);

        var result = await response.Content.ReadFromJsonAsync<ContextualResult>(ct);
        var items = result.Attributions.Select((a, i) => new RagSearchResult
        {
            Id = $"ctx-{i}",
            Content = a.Content,
            Score = a.Relevance,
            Metadata = new()
            {
                ["source"] = a.Source, ["reasoning"] = a.Reasoning,
                ["agentSteps"] = result.AgentSteps
            }
        }).ToList();

        return DataProcessResult<List<RagSearchResult>>.Success(items);
    }

    /// <summary>Ingest documents into Contextual AI datastore.</summary>
    public async Task<DataProcessResult<string>> IngestAsync(string content, string name, string datastore = "default", CancellationToken ct = default)
    {
        var response = await _http.PostAsJsonAsync("ingest", new { content, name, datastore }, ct);
        var result = await response.Content.ReadFromJsonAsync<JsonElement>(ct);
        return DataProcessResult<string>.Success(result.GetProperty("id").GetString());
    }

    // IRagService implementations
    public async Task<DataProcessResult<string>> StoreEmbeddingAsync(string c, string id, float[] e, Dictionary<string, object> m = null, string content = null, CancellationToken ct = default)
        => content != null ? await IngestAsync(content, id, c, ct) : DataProcessResult<string>.Success(id);

    public async Task<DataProcessResult<List<RagSearchResult>>> VectorSearchAsync(string c, float[] e, int k = 5, Dictionary<string, object> f = null, CancellationToken ct = default)
        => await AgenticQueryAsync(f?["query"]?.ToString() ?? "", c, 3, ct);

    public async Task<DataProcessResult<List<RagSearchResult>>> HybridSearchAsync(string c, string t, float[] e, int k = 5, Dictionary<string, object> f = null, CancellationToken ct = default)
        => await AgenticQueryAsync(t, c, 5, ct);

    public async Task<DataProcessResult<List<RagGraphResult>>> TraverseAsync(string s, string e, int d = 3, Dictionary<string, object> f = null, CancellationToken ct = default)
    {
        var r = await AgenticQueryAsync($"What entities and relationships are connected to {s}?", "default", d, ct);
        return DataProcessResult<List<RagGraphResult>>.Success(r.Data?.Select(x => new RagGraphResult { NodeId = x.Id, Data = x.Metadata }).ToList() ?? []);
    }

    public Task<DataProcessResult<string>> StoreNodeAsync(string l, string i, Dictionary<string, object> p, float[] e = null, CancellationToken c = default) => Task.FromResult(DataProcessResult<string>.Error("Contextual AI: agentic, no static graph"));
    public Task<DataProcessResult<string>> StoreEdgeAsync(string f, string t, string e, Dictionary<string, object> p = null, CancellationToken c = default) => Task.FromResult(DataProcessResult<string>.Error("Agentic"));
    public Task<DataProcessResult<List<RagGraphResult>>> GraphQueryAsync(string q, Dictionary<string, object> p = null, CancellationToken c = default) => Task.FromResult(DataProcessResult<List<RagGraphResult>>.Error("Use AgenticQueryAsync"));
    public async Task<DataProcessResult<List<string>>> StoreDocumentChunksAsync(string c, string d, string content, ChunkingOptions o = null, CancellationToken ct = default) { await IngestAsync(content, d, c, ct); return DataProcessResult<List<string>>.Success([d]); }
}

// ═══════════════════════════════════════════════════════
// 10. HYBRID RAG (DIY) — Vector DB + Graph DB + Re-ranker
// Combines any two backends for maximum flexibility
// ═══════════════════════════════════════════════════════

public class HybridRagService : IRagService
{
    public string ProviderName => "hybrid-rag";
    public RagCapabilities Capabilities => new()
    {
        SupportsVectorSearch = true, SupportsHybridSearch = true,
        SupportsGraphTraversal = true, SupportsGraphQuery = true,
        MaxDimensions = 4096
    };

    private readonly IRagService _vectorBackend;   // e.g., Pinecone, ES kNN, Azure AI Search
    private readonly IRagService _graphBackend;     // e.g., Neo4j, Memgraph, CosmosDB
    private readonly IAiProvider _reranker;          // AI re-ranker (Claude/Cohere)
    private readonly ILogger _logger;

    /// <summary>
    /// Combine any vector DB + graph DB + AI re-ranker.
    /// The vector backend handles embeddings/similarity; the graph backend handles traversal.
    /// Results are merged, deduplicated, and re-ranked by AI.
    /// </summary>
    public HybridRagService(IRagService vectorBackend, IRagService graphBackend,
        IAiProvider reranker, ILogger<HybridRagService> logger)
    {
        _vectorBackend = vectorBackend ?? throw new ArgumentNullException(nameof(vectorBackend));
        _graphBackend = graphBackend ?? throw new ArgumentNullException(nameof(graphBackend));
        _reranker = reranker; _logger = logger;
    }

    /// <summary>
    /// Hybrid query pipeline:
    /// 1. Vector similarity search (fast, broad recall)
    /// 2. Graph traversal from top vector hits (deep, structural)
    /// 3. Merge + deduplicate
    /// 4. AI re-ranking for final order
    /// </summary>
    public async Task<DataProcessResult<List<RagSearchResult>>> HybridQueryAsync(
        string query, float[] queryEmbedding, string collection,
        int vectorTopK = 10, int graphDepth = 2, int finalTopK = 5,
        CancellationToken ct = default)
    {
        // Step 1: Vector search (parallel with step 2 if we have seeds)
        var vectorTask = _vectorBackend.VectorSearchAsync(collection, queryEmbedding, vectorTopK, null, ct);

        // Step 2: Graph traversal from query entities (extract key terms)
        var graphTask = _graphBackend.GraphQueryAsync?Invoke(
            $"MATCH (n)-[r*1..{graphDepth}]-(m) WHERE n.name CONTAINS $query RETURN m.id AS id, m.content AS content LIMIT 20",
            new() { ["query"] = query }, ct);

        await Task.WhenAll(vectorTask, graphTask ?? Task.CompletedTask);
        var vectorResults = vectorTask.Result.Data ?? [];
        var graphResults = graphTask?.Result?.Data ?? [];

        // Step 3: Merge + deduplicate
        var merged = new Dictionary<string, RagSearchResult>();
        foreach (var vr in vectorResults)
        {
            merged[vr.Id ?? vr.Content.GetHashCode().ToString()] = vr;
            vr.Metadata ??= [];
            vr.Metadata["source"] = "vector";
        }
        foreach (var gr in graphResults)
        {
            var key = gr.NodeId ?? gr.Data?.GetHashCode().ToString();
            if (key != null && !merged.ContainsKey(key))
            {
                merged[key] = new RagSearchResult
                {
                    Id = gr.NodeId, Content = gr.Data?["content"]?.ToString(),
                    Score = 0.5f, Metadata = new() { ["source"] = "graph", ["depth"] = gr.Depth }
                };
            }
            else if (key != null && merged.ContainsKey(key))
            {
                // Boost score for items found in both
                merged[key].Score = Math.Min(merged[key].Score * 1.5f, 1.0f);
                merged[key].Metadata["source"] = "vector+graph";
            }
        }

        var candidates = merged.Values.ToList();

        // Step 4: AI re-ranking
        if (_reranker != null && candidates.Count > finalTopK)
        {
            var reranked = await RerankWithAiAsync(query, candidates, finalTopK, ct);
            return DataProcessResult<List<RagSearchResult>>.Success(reranked);
        }

        return DataProcessResult<List<RagSearchResult>>.Success(
            candidates.OrderByDescending(c => c.Score).Take(finalTopK).ToList());
    }

    private async Task<List<RagSearchResult>> RerankWithAiAsync(
        string query, List<RagSearchResult> candidates, int topK, CancellationToken ct)
    {
        var candidateText = string.Join("\n", candidates.Select((c, i) =>
            $"[{i}] (score={c.Score:F2}, source={c.Metadata?["source"]}): {c.Content?[..Math.Min(c.Content.Length, 200)]}"));

        var response = await _reranker.ExecuteAsync(new AiRequest
        {
            SystemPrompt = "Re-rank these search results by relevance to the query. Return ONLY a JSON array of indices in order of relevance, e.g. [3,1,0,4,2]",
            Prompt = $"Query: {query}\n\nCandidates:\n{candidateText}\n\nReturn top {topK} indices as JSON array:",
            MaxTokens = 200, Temperature = 0.0f
        }, ct);

        try
        {
            var indices = JsonSerializer.Deserialize<List<int>>(response.Content.Trim());
            return indices.Where(i => i >= 0 && i < candidates.Count)
                .Take(topK).Select(i => candidates[i]).ToList();
        }
        catch
        {
            return candidates.OrderByDescending(c => c.Score).Take(topK).ToList();
        }
    }

    // IRagService: delegate to appropriate backend
    public Task<DataProcessResult<string>> StoreEmbeddingAsync(string c, string id, float[] e, Dictionary<string, object> m = null, string content = null, CancellationToken ct = default)
        => _vectorBackend.StoreEmbeddingAsync(c, id, e, m, content, ct);

    public Task<DataProcessResult<List<RagSearchResult>>> VectorSearchAsync(string c, float[] e, int k = 5, Dictionary<string, object> f = null, CancellationToken ct = default)
        => _vectorBackend.VectorSearchAsync(c, e, k, f, ct);

    public async Task<DataProcessResult<List<RagSearchResult>>> HybridSearchAsync(string c, string t, float[] e, int k = 5, Dictionary<string, object> f = null, CancellationToken ct = default)
        => await HybridQueryAsync(t, e, c, k * 2, 2, k, ct);

    public Task<DataProcessResult<string>> StoreNodeAsync(string l, string id, Dictionary<string, object> p, float[] e = null, CancellationToken ct = default)
        => _graphBackend.StoreNodeAsync(l, id, p, e, ct);

    public Task<DataProcessResult<string>> StoreEdgeAsync(string f, string t, string e, Dictionary<string, object> p = null, CancellationToken ct = default)
        => _graphBackend.StoreEdgeAsync(f, t, e, p, ct);

    public Task<DataProcessResult<List<RagGraphResult>>> TraverseAsync(string s, string e, int d = 3, Dictionary<string, object> f = null, CancellationToken ct = default)
        => _graphBackend.TraverseAsync(s, e, d, f, ct);

    public Task<DataProcessResult<List<RagGraphResult>>> GraphQueryAsync(string q, Dictionary<string, object> p = null, CancellationToken ct = default)
        => _graphBackend.GraphQueryAsync(q, p, ct);

    public async Task<DataProcessResult<List<string>>> StoreDocumentChunksAsync(string c, string d, string content, ChunkingOptions o = null, CancellationToken ct = default)
    {
        // Store chunks in vector backend; store entity graph in graph backend
        var vectorResult = await _vectorBackend.StoreDocumentChunksAsync(c, d, content, o, ct);
        // Optionally also ingest into graph backend if it supports it
        try { await _graphBackend.StoreDocumentChunksAsync(c, d, content, o, ct); } catch { }
        return vectorResult;
    }
}

// ─── Contextual AI Models ────────────────────────────────
public class ContextualResult { public List<ContextualAttribution> Attributions { get; set; } = []; public int AgentSteps { get; set; } }
public class ContextualAttribution { public string Content { get; set; } public float Relevance { get; set; } public string Source { get; set; } public string Reasoning { get; set; } }
