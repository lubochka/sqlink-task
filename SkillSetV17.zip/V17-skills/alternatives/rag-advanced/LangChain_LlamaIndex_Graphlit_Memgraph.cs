// XIIGen Advanced RAG Alternatives | Part 2 of 4
// LangChain KG RAG, LlamaIndex GraphRAG, Graphlit, Memgraph
// All implement IRagService

using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Skills.Rag.Advanced;

// ═══════════════════════════════════════════════════════
// 4. LANGCHAIN KG RAG — GraphCypherQAChain + Claude
// Python bridge via HTTP. pip: langchain, langchain-anthropic, neo4j
// ═══════════════════════════════════════════════════════

public class LangChainKgRagService : IRagService
{
    public string ProviderName => "langchain-kg";
    public RagCapabilities Capabilities => new()
    {
        SupportsVectorSearch = true, SupportsHybridSearch = true,
        SupportsGraphTraversal = true, SupportsGraphQuery = true,
        MaxDimensions = 3072
    };

    private readonly HttpClient _http;
    private readonly ILogger _logger;

    // LangChain runs as Python FastAPI server:
    // uvicorn langchain_kg_server:app --port 8030
    public LangChainKgRagService(string baseUrl, ILogger<LangChainKgRagService> logger)
    {
        _http = new HttpClient { BaseAddress = new Uri(baseUrl) };
        _logger = logger;
    }

    /// <summary>
    /// Uses LangChain's GraphCypherQAChain: natural language → Cypher → result.
    /// Claude generates Cypher queries from user intent.
    /// </summary>
    public async Task<DataProcessResult<List<RagSearchResult>>> NaturalLanguageGraphQueryAsync(
        string question, CancellationToken ct = default)
    {
        // LangChain server endpoint that uses GraphCypherQAChain
        var response = await _http.PostAsJsonAsync("/graph-qa", new
        {
            question,
            chain_type = "GraphCypherQAChain",
            llm = "claude-sonnet-4-5",       // Claude generates Cypher
            return_intermediate_steps = true  // Show generated Cypher
        }, ct);

        var result = await response.Content.ReadFromJsonAsync<LangChainResult>(ct);
        return DataProcessResult<List<RagSearchResult>>.Success(
        [
            new RagSearchResult
            {
                Id = "langchain-result",
                Content = result.Answer,
                Score = 1.0f,
                Metadata = new()
                {
                    ["cypher_query"] = result.IntermediateSteps?.FirstOrDefault()?.CypherQuery,
                    ["source_documents"] = result.SourceDocuments?.Count ?? 0
                }
            }
        ]);
    }

    /// <summary>
    /// Retrieval chain: vector search + graph context + Claude synthesis.
    /// Uses LangChain's RetrievalQAWithSourcesChain with graph enhancer.
    /// </summary>
    public async Task<DataProcessResult<List<RagSearchResult>>> RetrievalChainAsync(
        string query, string collection = "default", int topK = 5, CancellationToken ct = default)
    {
        var response = await _http.PostAsJsonAsync("/retrieval-chain", new
        {
            query, collection, top_k = topK,
            retriever_type = "hybrid",  // vector + graph
            llm = "claude-sonnet-4-5"
        }, ct);

        var result = await response.Content.ReadFromJsonAsync<LangChainRetrievalResult>(ct);
        return DataProcessResult<List<RagSearchResult>>.Success(
            result.Documents.Select(d => new RagSearchResult
            {
                Id = d.Id, Content = d.PageContent, Score = d.Score,
                Metadata = d.Metadata
            }).ToList());
    }

    // IRagService standard implementations
    public async Task<DataProcessResult<string>> StoreEmbeddingAsync(string c, string id, float[] e, Dictionary<string, object> m = null, string content = null, CancellationToken ct = default)
    {
        await _http.PostAsJsonAsync("/store", new { collection = c, id, embedding = e, metadata = m, content }, ct);
        return DataProcessResult<string>.Success(id);
    }

    public async Task<DataProcessResult<List<RagSearchResult>>> VectorSearchAsync(string c, float[] e, int k = 5, Dictionary<string, object> f = null, CancellationToken ct = default)
    {
        var resp = await _http.PostAsJsonAsync("/vector-search", new { collection = c, embedding = e, top_k = k, filter = f }, ct);
        var result = await resp.Content.ReadFromJsonAsync<LangChainRetrievalResult>(ct);
        return DataProcessResult<List<RagSearchResult>>.Success(result.Documents.Select(d => new RagSearchResult { Id = d.Id, Content = d.PageContent, Score = d.Score, Metadata = d.Metadata }).ToList());
    }

    public async Task<DataProcessResult<List<RagSearchResult>>> HybridSearchAsync(string c, string t, float[] e, int k = 5, Dictionary<string, object> f = null, CancellationToken ct = default)
        => await RetrievalChainAsync(t, c, k, ct);

    public async Task<DataProcessResult<string>> StoreNodeAsync(string l, string id, Dictionary<string, object> p, float[] e = null, CancellationToken ct = default)
    { await _http.PostAsJsonAsync("/graph/node", new { label = l, id, properties = p }, ct); return DataProcessResult<string>.Success(id); }

    public async Task<DataProcessResult<string>> StoreEdgeAsync(string f, string t, string e, Dictionary<string, object> p = null, CancellationToken ct = default)
    { await _http.PostAsJsonAsync("/graph/edge", new { from_id = f, to_id = t, edge_type = e, properties = p }, ct); return DataProcessResult<string>.Success($"{f}->{t}"); }

    public async Task<DataProcessResult<List<RagGraphResult>>> TraverseAsync(string s, string e, int d = 3, Dictionary<string, object> f = null, CancellationToken ct = default)
    {
        var resp = await _http.PostAsJsonAsync("/graph/traverse", new { start = s, edge_type = e, max_depth = d }, ct);
        var result = await resp.Content.ReadFromJsonAsync<List<RagGraphResult>>(ct);
        return DataProcessResult<List<RagGraphResult>>.Success(result ?? []);
    }

    public async Task<DataProcessResult<List<RagGraphResult>>> GraphQueryAsync(string q, Dictionary<string, object> p = null, CancellationToken ct = default)
        => (await NaturalLanguageGraphQueryAsync(q, ct)).IsSuccess
            ? DataProcessResult<List<RagGraphResult>>.Success([new RagGraphResult { Data = new() { ["answer"] = (await NaturalLanguageGraphQueryAsync(q, ct)).Data.First().Content } }])
            : DataProcessResult<List<RagGraphResult>>.Error("Query failed");

    public async Task<DataProcessResult<List<string>>> StoreDocumentChunksAsync(string c, string d, string content, ChunkingOptions o = null, CancellationToken ct = default)
    { await _http.PostAsJsonAsync("/ingest", new { collection = c, doc_id = d, content, chunk_size = o?.ChunkSize ?? 500 }, ct); return DataProcessResult<List<string>>.Success([d]); }
}

// ═══════════════════════════════════════════════════════
// 5. LLAMAINDEX GRAPHRAG — 160+ connectors, AWS Bedrock
// Python bridge. pip: llama-index, llama-index-graph-stores-neo4j
// ═══════════════════════════════════════════════════════

public class LlamaIndexGraphRagService : IRagService
{
    public string ProviderName => "llamaindex-graphrag";
    public RagCapabilities Capabilities => new()
    {
        SupportsVectorSearch = true, SupportsHybridSearch = true,
        SupportsGraphTraversal = true, SupportsGraphQuery = true,
        MaxDimensions = 3072
    };

    private readonly HttpClient _http;
    private readonly ILogger _logger;

    // LlamaIndex server: python -m llama_index.server --port 8040
    public LlamaIndexGraphRagService(string baseUrl, ILogger<LlamaIndexGraphRagService> logger)
    {
        _http = new HttpClient { BaseAddress = new Uri(baseUrl) };
        _logger = logger;
    }

    /// <summary>
    /// KnowledgeGraphIndex: auto-extracts triplets from documents.
    /// Supports: neo4j, neptune, kuzu, nebula as graph stores.
    /// </summary>
    public async Task<DataProcessResult<string>> BuildKnowledgeGraphAsync(
        string text, string graphStore = "neo4j", CancellationToken ct = default)
    {
        var response = await _http.PostAsJsonAsync("/build-kg", new
        {
            documents = new[] { new { text, doc_id = Guid.NewGuid().ToString() } },
            graph_store = graphStore,
            include_embeddings = true,
            llm = "bedrock/anthropic.claude-sonnet-4-5-v2" // AWS Bedrock Claude
        }, ct);

        var result = await response.Content.ReadFromJsonAsync<JsonElement>(ct);
        return DataProcessResult<string>.Success(result.GetProperty("index_id").GetString());
    }

    /// <summary>
    /// KnowledgeGraphQueryEngine: combines graph traversal with vector retrieval.
    /// </summary>
    public async Task<DataProcessResult<List<RagSearchResult>>> KgQueryAsync(
        string query, bool includeText = true, bool includeGraph = true, int topK = 5, CancellationToken ct = default)
    {
        var response = await _http.PostAsJsonAsync("/kg-query", new
        {
            query, include_text = includeText, include_graph = includeGraph,
            similarity_top_k = topK, graph_store_query_depth = 2
        }, ct);

        var result = await response.Content.ReadFromJsonAsync<LlamaIndexResult>(ct);
        return DataProcessResult<List<RagSearchResult>>.Success(
            result.SourceNodes.Select(n => new RagSearchResult
            {
                Id = n.NodeId, Content = n.Text, Score = n.Score,
                Metadata = new() { ["nodeType"] = n.NodeType, ["relationships"] = n.Relationships?.Count ?? 0 }
            }).ToList());
    }

    // IRagService implementations (all delegate to LlamaIndex HTTP API)
    public async Task<DataProcessResult<string>> StoreEmbeddingAsync(string c, string id, float[] e, Dictionary<string, object> m = null, string content = null, CancellationToken ct = default) { await _http.PostAsJsonAsync("/store-embedding", new { collection = c, id, embedding = e, metadata = m, content }, ct); return DataProcessResult<string>.Success(id); }
    public async Task<DataProcessResult<List<RagSearchResult>>> VectorSearchAsync(string c, float[] e, int k = 5, Dictionary<string, object> f = null, CancellationToken ct = default) { var r = await _http.PostAsJsonAsync("/vector-query", new { collection = c, embedding = e, top_k = k }, ct); var res = await r.Content.ReadFromJsonAsync<LlamaIndexResult>(ct); return DataProcessResult<List<RagSearchResult>>.Success(res.SourceNodes.Select(n => new RagSearchResult { Id = n.NodeId, Content = n.Text, Score = n.Score }).ToList()); }
    public async Task<DataProcessResult<List<RagSearchResult>>> HybridSearchAsync(string c, string t, float[] e, int k = 5, Dictionary<string, object> f = null, CancellationToken ct = default) => await KgQueryAsync(t, true, true, k, ct);
    public async Task<DataProcessResult<string>> StoreNodeAsync(string l, string id, Dictionary<string, object> p, float[] e = null, CancellationToken ct = default) { await _http.PostAsJsonAsync("/graph/node", new { label = l, id, properties = p }, ct); return DataProcessResult<string>.Success(id); }
    public async Task<DataProcessResult<string>> StoreEdgeAsync(string f, string t, string e, Dictionary<string, object> p = null, CancellationToken ct = default) { await _http.PostAsJsonAsync("/graph/edge", new { from_id = f, to_id = t, rel_type = e, properties = p }, ct); return DataProcessResult<string>.Success($"{f}->{t}"); }
    public async Task<DataProcessResult<List<RagGraphResult>>> TraverseAsync(string s, string e, int d = 3, Dictionary<string, object> f = null, CancellationToken ct = default) { var r = await _http.PostAsJsonAsync("/graph/traverse", new { start = s, edge_type = e, depth = d }, ct); return DataProcessResult<List<RagGraphResult>>.Success(await r.Content.ReadFromJsonAsync<List<RagGraphResult>>(ct) ?? []); }
    public async Task<DataProcessResult<List<RagGraphResult>>> GraphQueryAsync(string q, Dictionary<string, object> p = null, CancellationToken ct = default) { var r = await KgQueryAsync(q, false, true, 10, ct); return DataProcessResult<List<RagGraphResult>>.Success(r.Data?.Select(x => new RagGraphResult { NodeId = x.Id, Data = x.Metadata }).ToList() ?? []); }
    public async Task<DataProcessResult<List<string>>> StoreDocumentChunksAsync(string c, string d, string content, ChunkingOptions o = null, CancellationToken ct = default) { await BuildKnowledgeGraphAsync(content, "neo4j", ct); return DataProcessResult<List<string>>.Success([d]); }
}

// ═══════════════════════════════════════════════════════
// 6. GRAPHLIT — Fully managed SaaS, auto KG extraction
// API: GraphQL at https://api.graphlit.io
// ═══════════════════════════════════════════════════════

public class GraphlitRagService : IRagService
{
    public string ProviderName => "graphlit";
    public RagCapabilities Capabilities => new()
    {
        SupportsVectorSearch = true, SupportsHybridSearch = true,
        SupportsGraphTraversal = true, SupportsGraphQuery = false,
        MaxDimensions = 3072
    };

    private readonly HttpClient _http;
    private readonly string _projectId;
    private readonly ILogger _logger;

    public GraphlitRagService(string apiKey, string projectId, ILogger<GraphlitRagService> logger)
    {
        _http = new HttpClient { BaseAddress = new Uri("https://api.graphlit.io/graphql") };
        _http.DefaultRequestHeaders.Add("Authorization", $"Bearer {apiKey}");
        _projectId = projectId; _logger = logger;
    }

    /// <summary>Ingest content — Graphlit auto-extracts entities, summaries, embeddings.</summary>
    public async Task<DataProcessResult<string>> IngestContentAsync(
        string text, string name, string contentType = "TEXT", CancellationToken ct = default)
    {
        var mutation = """
            mutation IngestText($input: IngestTextInput!) {
                ingestText(input: $input) { id state }
            }
            """;
        var response = await GraphqlAsync(mutation, new
        {
            input = new { name, text, contentType, project = new { id = _projectId } }
        }, ct);
        var id = response.GetProperty("data").GetProperty("ingestText").GetProperty("id").GetString();
        return DataProcessResult<string>.Success(id);
    }

    /// <summary>Query with auto graph + vector search.</summary>
    public async Task<DataProcessResult<List<RagSearchResult>>> QueryContentAsync(
        string query, int topK = 5, CancellationToken ct = default)
    {
        var graphql = """
            query QueryContents($query: String!, $limit: Int) {
                queryContents(query: $query, limit: $limit) {
                    results { id name relevance summary
                        entities { name type }
                        observations { type observable { name } }
                    }
                }
            }
            """;
        var response = await GraphqlAsync(graphql, new { query, limit = topK }, ct);
        var results = response.GetProperty("data").GetProperty("queryContents").GetProperty("results");
        var items = new List<RagSearchResult>();
        foreach (var r in results.EnumerateArray())
        {
            items.Add(new RagSearchResult
            {
                Id = r.GetProperty("id").GetString(),
                Content = r.GetProperty("summary").GetString(),
                Score = (float)r.GetProperty("relevance").GetDouble(),
                Metadata = new()
                {
                    ["name"] = r.GetProperty("name").GetString(),
                    ["entityCount"] = r.GetProperty("entities").GetArrayLength()
                }
            });
        }
        return DataProcessResult<List<RagSearchResult>>.Success(items);
    }

    private async Task<JsonElement> GraphqlAsync(string query, object variables, CancellationToken ct)
    {
        var response = await _http.PostAsJsonAsync("", new { query, variables }, ct);
        return await response.Content.ReadFromJsonAsync<JsonElement>(ct);
    }

    // IRagService standard implementations
    public async Task<DataProcessResult<string>> StoreEmbeddingAsync(string c, string id, float[] e, Dictionary<string, object> m = null, string content = null, CancellationToken ct = default) => content != null ? await IngestContentAsync(content, id, ct: ct) : DataProcessResult<string>.Success(id);
    public async Task<DataProcessResult<List<RagSearchResult>>> VectorSearchAsync(string c, float[] e, int k = 5, Dictionary<string, object> f = null, CancellationToken ct = default) => await QueryContentAsync(f?["query"]?.ToString() ?? "", k, ct);
    public async Task<DataProcessResult<List<RagSearchResult>>> HybridSearchAsync(string c, string t, float[] e, int k = 5, Dictionary<string, object> f = null, CancellationToken ct = default) => await QueryContentAsync(t, k, ct);
    public Task<DataProcessResult<string>> StoreNodeAsync(string l, string id, Dictionary<string, object> p, float[] e = null, CancellationToken ct = default) => Task.FromResult(DataProcessResult<string>.Error("Graphlit auto-extracts graph"));
    public Task<DataProcessResult<string>> StoreEdgeAsync(string f, string t, string e, Dictionary<string, object> p = null, CancellationToken ct = default) => Task.FromResult(DataProcessResult<string>.Error("Auto-managed"));
    public async Task<DataProcessResult<List<RagGraphResult>>> TraverseAsync(string s, string e, int d = 3, Dictionary<string, object> f = null, CancellationToken ct = default) { var r = await QueryContentAsync($"related to {s}", d * 2, ct); return DataProcessResult<List<RagGraphResult>>.Success(r.Data?.Select(x => new RagGraphResult { NodeId = x.Id, Data = x.Metadata }).ToList() ?? []); }
    public Task<DataProcessResult<List<RagGraphResult>>> GraphQueryAsync(string q, Dictionary<string, object> p = null, CancellationToken ct = default) => Task.FromResult(DataProcessResult<List<RagGraphResult>>.Error("Use QueryContentAsync"));
    public async Task<DataProcessResult<List<string>>> StoreDocumentChunksAsync(string c, string d, string content, ChunkingOptions o = null, CancellationToken ct = default) { var r = await IngestContentAsync(content, d, ct: ct); return DataProcessResult<List<string>>.Success([r.Data]); }
}

// ═══════════════════════════════════════════════════════
// 7. MEMGRAPH — In-memory graph, real-time streaming
// NuGet: Neo4j.Driver (Memgraph is Bolt-compatible)
// ═══════════════════════════════════════════════════════

public class MemgraphRagService : IRagService
{
    public string ProviderName => "memgraph";
    public RagCapabilities Capabilities => new()
    {
        SupportsVectorSearch = false,  // No native vector index (use with LightRAG)
        SupportsHybridSearch = false,
        SupportsGraphTraversal = true,
        SupportsGraphQuery = true,     // Full Cypher (openCypher)
        MaxDimensions = 0
    };

    private readonly Neo4j.Driver.IDriver _driver; // Bolt-compatible
    private readonly ILogger _logger;

    public MemgraphRagService(string uri, ILogger<MemgraphRagService> logger)
    {
        _driver = Neo4j.Driver.GraphDatabase.Driver(uri);
        _logger = logger;
    }

    /// <summary>
    /// Real-time graph streaming: auto-ingest from Kafka/Pulsar topics.
    /// Creates triggers that fire on new events.
    /// </summary>
    public async Task<DataProcessResult<bool>> CreateStreamTriggerAsync(
        string triggerName, string topic, string transformQuery, CancellationToken ct = default)
    {
        await using var session = _driver.AsyncSession();
        await session.ExecuteWriteAsync(async tx =>
        {
            // Memgraph streaming with Kafka
            await tx.RunAsync($@"
                CREATE TRIGGER {triggerName}
                ON CREATE AFTER COMMIT EXECUTE
                CALL kafka_transform.consume('{topic}')
                YIELD *
                {transformQuery}
            ");
        });
        return DataProcessResult<bool>.Success(true);
    }

    /// <summary>PageRank for entity importance ranking.</summary>
    public async Task<DataProcessResult<List<RagGraphResult>>> PageRankAsync(int topN = 20, CancellationToken ct = default)
    {
        await using var session = _driver.AsyncSession();
        var results = await session.ExecuteReadAsync(async tx =>
        {
            var cursor = await tx.RunAsync(@"
                CALL pagerank.get() YIELD node, rank
                RETURN node.id AS id, node.name AS name, rank
                ORDER BY rank DESC LIMIT $topN", new { topN });
            var items = new List<RagGraphResult>();
            await foreach (var r in cursor)
                items.Add(new RagGraphResult { NodeId = r["id"]?.As<string>(), Data = new() { ["name"] = r["name"]?.As<string>(), ["pagerank"] = r["rank"].As<double>() } });
            return items;
        });
        return DataProcessResult<List<RagGraphResult>>.Success(results);
    }

    // IRagService graph implementations
    public async Task<DataProcessResult<string>> StoreNodeAsync(string label, string id, Dictionary<string, object> properties, float[] embedding = null, CancellationToken ct = default)
    {
        await using var session = _driver.AsyncSession();
        await session.ExecuteWriteAsync(async tx =>
        {
            var safeLabel = System.Text.RegularExpressions.Regex.Replace(label, @"[^a-zA-Z0-9_]", "_");
            await tx.RunAsync($"MERGE (n:{safeLabel} {{id: $id}}) SET n += $props", new { id, props = properties });
        });
        return DataProcessResult<string>.Success(id);
    }

    public async Task<DataProcessResult<string>> StoreEdgeAsync(string fromId, string toId, string edgeType, Dictionary<string, object> properties = null, CancellationToken ct = default)
    {
        await using var session = _driver.AsyncSession();
        var safeType = System.Text.RegularExpressions.Regex.Replace(edgeType, @"[^a-zA-Z0-9_]", "_");
        await session.ExecuteWriteAsync(async tx =>
        {
            await tx.RunAsync($"MATCH (a {{id: $from}}), (b {{id: $to}}) MERGE (a)-[r:{safeType}]->(b) SET r += $props",
                new { from = fromId, to = toId, props = properties ?? new Dictionary<string, object>() });
        });
        return DataProcessResult<string>.Success($"{fromId}->{toId}");
    }

    public async Task<DataProcessResult<List<RagGraphResult>>> TraverseAsync(string startNodeId, string edgeType, int maxDepth = 3, Dictionary<string, object> filter = null, CancellationToken ct = default)
    {
        await using var session = _driver.AsyncSession();
        var results = await session.ExecuteReadAsync(async tx =>
        {
            var cursor = await tx.RunAsync($"MATCH path=(n {{id: $start}})-[*1..{maxDepth}]-(m) RETURN DISTINCT m.id AS id, m.name AS name, length(path) AS depth ORDER BY depth LIMIT 50", new { start = startNodeId });
            var items = new List<RagGraphResult>();
            await foreach (var r in cursor)
                items.Add(new RagGraphResult { NodeId = r["id"]?.As<string>(), Depth = r["depth"].As<int>(), Data = new() { ["name"] = r["name"]?.As<string>() } });
            return items;
        });
        return DataProcessResult<List<RagGraphResult>>.Success(results);
    }

    public async Task<DataProcessResult<List<RagGraphResult>>> GraphQueryAsync(string query, Dictionary<string, object> parameters = null, CancellationToken ct = default)
    {
        await using var session = _driver.AsyncSession();
        var results = await session.ExecuteReadAsync(async tx =>
        {
            var cursor = await tx.RunAsync(query, parameters);
            var items = new List<RagGraphResult>();
            await foreach (var r in cursor)
                items.Add(new RagGraphResult { Data = r.Values.ToDictionary(kv => kv.Key, kv => kv.Value as object) });
            return items;
        });
        return DataProcessResult<List<RagGraphResult>>.Success(results);
    }

    // Vector operations not supported (Memgraph = pure graph; pair with vector DB)
    public Task<DataProcessResult<string>> StoreEmbeddingAsync(string c, string id, float[] e, Dictionary<string, object> m = null, string content = null, CancellationToken ct = default) => Task.FromResult(DataProcessResult<string>.Error("Memgraph: use alongside vector DB"));
    public Task<DataProcessResult<List<RagSearchResult>>> VectorSearchAsync(string c, float[] e, int k = 5, Dictionary<string, object> f = null, CancellationToken ct = default) => Task.FromResult(DataProcessResult<List<RagSearchResult>>.Error("No vector support"));
    public Task<DataProcessResult<List<RagSearchResult>>> HybridSearchAsync(string c, string t, float[] e, int k = 5, Dictionary<string, object> f = null, CancellationToken ct = default) => Task.FromResult(DataProcessResult<List<RagSearchResult>>.Error("No vector support"));
    public Task<DataProcessResult<List<string>>> StoreDocumentChunksAsync(string c, string d, string content, ChunkingOptions o = null, CancellationToken ct = default) => Task.FromResult(DataProcessResult<List<string>>.Error("Use entity extraction + StoreNode"));
}

// ─── LangChain/LlamaIndex Response Models ─────────────
public class LangChainResult { public string Answer { get; set; } public List<LangChainStep> IntermediateSteps { get; set; } public List<LangChainDoc> SourceDocuments { get; set; } }
public class LangChainStep { public string CypherQuery { get; set; } public string Result { get; set; } }
public class LangChainDoc { public string Id { get; set; } public string PageContent { get; set; } public float Score { get; set; } public Dictionary<string, object> Metadata { get; set; } }
public class LangChainRetrievalResult { public List<LangChainDoc> Documents { get; set; } = []; }
public class LlamaIndexResult { public List<LlamaIndexNode> SourceNodes { get; set; } = []; }
public class LlamaIndexNode { public string NodeId { get; set; } public string Text { get; set; } public float Score { get; set; } public string NodeType { get; set; } public List<object> Relationships { get; set; } }
