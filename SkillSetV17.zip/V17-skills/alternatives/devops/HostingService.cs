// XIIGen.Skills.DevOps/HostingService.cs | .NET 9
// Hosting platform selector + deploy script generator + comparison matrix
// Supports: 4 PaaS, 4 Managed K8s, 3 Lightweight, 2 Enterprise = 13 platforms

using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace XIIGen.Skills.DevOps;

// ═══════════════════════════════════════════════════════
// HOSTING PLATFORM SELECTOR
// ═══════════════════════════════════════════════════════

public class HostingService
{
    private readonly IConfiguration _config;
    private readonly ILogger _logger;

    public HostingService(IConfiguration config, ILogger<HostingService> logger)
    {
        _config = config; _logger = logger;
    }

    /// <summary>
    /// Recommends hosting platform based on project requirements.
    /// </summary>
    public HostingRecommendation Recommend(HostingRequirements req)
    {
        var scored = GetAllPlatforms()
            .Select(p => new { Platform = p, Score = ScorePlatform(p, req) })
            .OrderByDescending(x => x.Score)
            .ToList();

        return new HostingRecommendation
        {
            Primary = scored[0].Platform,
            PrimaryScore = scored[0].Score,
            Alternatives = scored.Skip(1).Take(2).Select(s => s.Platform).ToList(),
            Reasoning = GenerateReasoning(scored[0].Platform, req)
        };
    }

    private int ScorePlatform(HostingPlatform p, HostingRequirements req)
    {
        int score = 0;

        // Budget fit
        if (req.MonthlyBudget > 0)
        {
            if (p.StartingPrice <= req.MonthlyBudget) score += 20;
            if (p.StartingPrice <= req.MonthlyBudget / 2) score += 10;
        }

        // Scale requirements
        if (req.ExpectedRps > 1000 && p.MaxScale == "Unlimited") score += 25;
        if (req.ExpectedRps <= 100 && p.Category == "PaaS") score += 15;
        if (req.NeedsAutoScaling && p.AutoScaling) score += 15;

        // Region requirements
        if (req.NeedsMultiRegion && p.MultiRegion) score += 20;
        if (req.PrimaryCloud == p.Cloud) score += 15;

        // Complexity preference
        if (req.TeamK8sExperience == "none" && p.Complexity <= 2) score += 20;
        if (req.TeamK8sExperience == "expert" && p.Complexity >= 4) score += 10;

        // Compliance
        if (req.NeedsCompliance && p.EnterpriseCompliance) score += 25;

        // Real-time / streaming
        if (req.NeedsRealTimeStreaming && p.StreamingSupport) score += 15;

        // Edge / IoT
        if (req.NeedsEdgeDeployment && p.EdgeSupport) score += 20;

        return score;
    }

    private string GenerateReasoning(HostingPlatform p, HostingRequirements req) => p.Id switch
    {
        "railway" => "Railway offers the fastest path to deployment with visual UI and GitHub integration. Good for prototyping and small teams.",
        "render" => "Render is a solid Heroku replacement with built-in managed databases, monitoring, and auto-scaling. Great value for production workloads.",
        "flyio" => "Fly.io's global edge network provides the lowest latency for distributed users. Ideal for globally-accessed APIs.",
        "vercel" => "Vercel is optimized for frontend deployments. Use for the XIIGen web editor only; backend needs a separate platform.",
        "gke" => "GKE offers the best Kubernetes experience with Autopilot mode, Workload Identity, and deep GCP integration.",
        "eks" => "EKS integrates tightly with AWS IAM, CloudWatch, and Fargate serverless pods. Best if you're already AWS-native.",
        "aks" => "AKS provides free control plane, Azure AD integration, and Key Vault for secrets. Good with existing Azure infrastructure.",
        "digitalocean" => "DigitalOcean K8s is simpler and cheaper than the big three. Great for teams wanting managed K8s without cloud complexity.",
        "nomad" => "Nomad is a single-binary orchestrator that handles containers AND VMs. Simpler than K8s with Vault/Consul integration.",
        "docker-swarm" => "Docker Swarm is built into Docker—zero additional tooling. Best for small teams already using Docker Compose.",
        "k3s" => "K3s is a lightweight K8s distribution perfect for edge, IoT, and development environments. Runs in 512MB RAM.",
        "openshift" => "OpenShift provides enterprise-grade GitOps, security scanning, and compliance out of the box. Best for regulated industries.",
        "rancher" => "Rancher manages multiple K8s clusters across clouds from a single dashboard. Best for hybrid/multi-cloud enterprise setups.",
        _ => "Selected based on requirement scoring."
    };

    /// <summary>
    /// Generates a deployment script for the selected platform.
    /// </summary>
    public string GenerateDeployScript(string platformId, DeployConfig config) => platformId switch
    {
        "railway" => GenerateRailwayScript(config),
        "render" => GenerateRenderScript(config),
        "flyio" => GenerateFlyScript(config),
        "gke" => GenerateGkeScript(config),
        "eks" => GenerateEksScript(config),
        "aks" => GenerateAksScript(config),
        "digitalocean" => GenerateDoScript(config),
        "nomad" => GenerateNomadScript(config),
        "docker-swarm" => GenerateSwarmScript(config),
        "k3s" => GenerateK3sScript(config),
        "openshift" => GenerateOpenshiftScript(config),
        "rancher" => GenerateRancherScript(config),
        _ => throw new ArgumentException($"Unknown platform: {platformId}")
    };

    // ─── Deploy Script Generators ────────────────────────

    private string GenerateRailwayScript(DeployConfig c) => $"""
        #!/bin/bash
        set -e
        echo "=== XIIGen → Railway ==="
        npm i -g @railway/cli
        railway login --token "$RAILWAY_TOKEN"
        railway link
        railway add --plugin elasticsearch 2>/dev/null || true
        railway add --plugin redis 2>/dev/null || true
        railway variables set AI_PROVIDER_KEY="$AI_PROVIDER_KEY" JWT_SECRET="$JWT_SECRET" ENVIRONMENT="{c.Environment}"
        railway up --detach
        sleep 30 && curl -f "https://$(railway domain)/health"
        echo "=== Deployed ==="
        """;

    private string GenerateRenderScript(DeployConfig c) => $"""
        #!/bin/bash
        set -e
        echo "=== XIIGen → Render ==="
        # Render deploys via render.yaml on push to main
        # Manual trigger:
        curl -X POST "https://api.render.com/v1/services/$RENDER_SERVICE_ID/deploys" \
          -H "Authorization: Bearer $RENDER_API_KEY" \
          -H "Content-Type: application/json" -d '{{"clearCache":"do_not_clear"}}'
        echo "Deploy triggered → https://dashboard.render.com"
        """;

    private string GenerateFlyScript(DeployConfig c) => $"""
        #!/bin/bash
        set -e
        echo "=== XIIGen → Fly.io ==="
        fly auth token "$FLY_API_TOKEN"
        fly apps create xiigen-api-{c.Environment} 2>/dev/null || true
        fly secrets set ELASTICSEARCH_URL="$ELASTICSEARCH_URL" REDIS_URL="$REDIS_URL" \
          AI_PROVIDER_KEY="$AI_PROVIDER_KEY" JWT_SECRET="$JWT_SECRET" \
          --app xiigen-api-{c.Environment}
        fly deploy --app xiigen-api-{c.Environment} --strategy rolling
        {(c.MultiRegion ? $"fly scale count 2 --region iad\nfly scale count 1 --region ams\nfly scale count 1 --region nrt" : "")}
        fly status --app xiigen-api-{c.Environment}
        """;

    private string GenerateGkeScript(DeployConfig c) => $"""
        #!/bin/bash
        set -e
        echo "=== XIIGen → GKE ==="
        gcloud container clusters get-credentials xiigen-{c.Environment} --region {c.Region} --project $GCP_PROJECT_ID
        helm upgrade --install xiigen ./deploy/k8s/helm \
          --namespace xiigen --create-namespace \
          --set image.tag={c.ImageTag} \
          --set replicas.api={c.ApiReplicas} --set replicas.orchestrator={c.OrchestratorReplicas} \
          --set autoscaling.enabled={c.AutoScale.ToString().ToLower()} \
          --wait --timeout=5m
        kubectl -n xiigen rollout status deployment/xiigen-api
        """;

    private string GenerateEksScript(DeployConfig c) => $"""
        #!/bin/bash
        set -e
        echo "=== XIIGen → EKS ==="
        aws eks update-kubeconfig --name xiigen-{c.Environment} --region {c.Region}
        helm upgrade --install xiigen ./deploy/k8s/helm \
          --namespace xiigen --create-namespace \
          --set image.tag={c.ImageTag} \
          --set replicas.api={c.ApiReplicas} --set replicas.orchestrator={c.OrchestratorReplicas} \
          --set serviceAccount.annotations."eks\.amazonaws\.com/role-arn"="$EKS_ROLE_ARN" \
          --wait --timeout=5m
        kubectl -n xiigen rollout status deployment/xiigen-api
        """;

    private string GenerateAksScript(DeployConfig c) => $"""
        #!/bin/bash
        set -e
        echo "=== XIIGen → AKS ==="
        az aks get-credentials --resource-group rg-xiigen-{c.Environment} --name aks-xiigen-{c.Environment}
        helm upgrade --install xiigen ./deploy/k8s/helm \
          --namespace xiigen --create-namespace \
          --set image.tag={c.ImageTag} \
          --set replicas.api={c.ApiReplicas} --set replicas.orchestrator={c.OrchestratorReplicas} \
          --set keyvault.uri="$KEY_VAULT_URI" \
          --wait --timeout=5m
        kubectl -n xiigen rollout status deployment/xiigen-api
        """;

    private string GenerateDoScript(DeployConfig c) => $"""
        #!/bin/bash
        set -e
        echo "=== XIIGen → DigitalOcean K8s ==="
        doctl kubernetes cluster kubeconfig save xiigen-{c.Environment}
        helm upgrade --install xiigen ./deploy/k8s/helm \
          --namespace xiigen --create-namespace \
          --set image.tag={c.ImageTag} \
          --set replicas.api={c.ApiReplicas} --set replicas.orchestrator={c.OrchestratorReplicas} \
          --wait --timeout=5m
        """;

    private string GenerateNomadScript(DeployConfig c) => $"""
        #!/bin/bash
        set -e
        echo "=== XIIGen → Nomad ==="
        vault kv put secret/xiigen/ai key="$AI_PROVIDER_KEY"
        vault kv put secret/xiigen/jwt secret="$JWT_SECRET"
        consul kv put xiigen/elasticsearch_url "$ELASTICSEARCH_URL"
        consul kv put xiigen/redis_url "$REDIS_URL"
        nomad job run -var="VERSION={c.ImageTag}" deploy/nomad/xiigen.nomad.hcl
        nomad job status xiigen-api
        """;

    private string GenerateSwarmScript(DeployConfig c) => $"""
        #!/bin/bash
        set -e
        echo "=== XIIGen → Docker Swarm ==="
        docker swarm init 2>/dev/null || true
        echo "$AI_PROVIDER_KEY" | docker secret create ai_provider_key - 2>/dev/null || true
        echo "$JWT_SECRET" | docker secret create jwt_secret - 2>/dev/null || true
        TAG={c.ImageTag} docker stack deploy -c deploy/swarm/docker-stack.yml xiigen
        docker stack services xiigen
        """;

    private string GenerateK3sScript(DeployConfig c) => $"""
        #!/bin/bash
        set -e
        echo "=== XIIGen → K3s ==="
        curl -sfL https://get.k3s.io | sh -s - --write-kubeconfig-mode 644
        kubectl wait --for=condition=Ready nodes --all --timeout=120s
        helm upgrade --install xiigen ./deploy/k8s/helm \
          --namespace xiigen --create-namespace \
          --set image.tag={c.ImageTag} \
          --values deploy/k3s/values-k3s.yaml --wait
        """;

    private string GenerateOpenshiftScript(DeployConfig c) => $"""
        #!/bin/bash
        set -e
        echo "=== XIIGen → OpenShift ==="
        oc login "$OPENSHIFT_API" --token="$OPENSHIFT_TOKEN"
        oc project xiigen 2>/dev/null || oc new-project xiigen
        oc apply -f deploy/openshift/
        oc rollout latest dc/xiigen-api
        oc rollout status dc/xiigen-api --timeout=5m
        """;

    private string GenerateRancherScript(DeployConfig c) => $"""
        #!/bin/bash
        set -e
        echo "=== XIIGen → Rancher Fleet ==="
        # Rancher Fleet auto-deploys via GitOps
        git tag -a "deploy-{c.Environment}-{c.ImageTag}" -m "Deploy {c.ImageTag} to {c.Environment}"
        git push origin "deploy-{c.Environment}-{c.ImageTag}"
        echo "Fleet will auto-deploy to matching clusters"
        kubectl --context rancher get fleet -A
        """;

    // ─── Platform Catalog ────────────────────────────────

    public static List<HostingPlatform> GetAllPlatforms() =>
    [
        // PaaS
        new("railway",   "Railway",    "PaaS",        5,    1, true,  false, false, false, false, "any",   "Fast GitHub deploy, visual UI"),
        new("render",    "Render",     "PaaS",        7,    2, true,  false, false, false, false, "any",   "Heroku replacement, built-in DBs & monitoring"),
        new("flyio",     "Fly.io",     "PaaS",        2,    2, true,  true,  false, false, false, "any",   "Global edge network, low latency"),
        new("vercel",    "Vercel",     "PaaS",        0,    1, true,  true,  false, false, false, "any",   "Frontend & Next.js only"),

        // Managed Kubernetes
        new("gke",       "GKE",        "Managed K8s", 0,    3, true,  true,  false, false, false, "gcp",   "Best K8s integration, Autopilot mode"),
        new("eks",       "EKS",        "Managed K8s", 73,   4, true,  true,  false, false, false, "aws",   "IAM, CloudWatch, Fargate serverless pods"),
        new("aks",       "AKS",        "Managed K8s", 0,    3, true,  true,  true,  false, false, "azure", "Azure AD, Key Vault, Windows containers"),
        new("digitalocean","DigitalOcean","Managed K8s",0,   2, true,  false, false, false, false, "any",   "Simpler & cheaper than big three"),

        // Lightweight Orchestrators
        new("nomad",     "Nomad",      "Lightweight",  0,   3, true,  false, false, false, true,  "any",   "Single binary, containers + VMs, Vault/Consul"),
        new("docker-swarm","Docker Swarm","Lightweight",0,   1, false, false, false, false, false, "any",   "Built into Docker, zero extra tooling"),
        new("k3s",       "K3s",        "Lightweight",  0,   2, false, false, false, true,  false, "any",   "512MB RAM, edge/IoT/dev environments"),

        // Enterprise
        new("openshift", "OpenShift",  "Enterprise",   0,   5, true,  true,  true,  false, false, "any",   "GitOps, security scanning, compliance"),
        new("rancher",   "Rancher",    "Enterprise",   0,   4, true,  true,  false, false, false, "any",   "Multi-cluster, hybrid cloud dashboard"),
    ];
}

// ─── Models ──────────────────────────────────────────────

public record HostingPlatform(
    string Id, string Name, string Category,
    decimal StartingPrice, int Complexity,        // 1-5
    bool AutoScaling, bool MultiRegion,
    bool EnterpriseCompliance, bool EdgeSupport,
    bool StreamingSupport, string Cloud,           // aws|azure|gcp|any
    string BestFor)
{
    public string MaxScale => Category switch
    {
        "Enterprise" or "Managed K8s" => "Unlimited",
        "PaaS" => "High",
        _ => "Medium"
    };
}

public class HostingRequirements
{
    public decimal MonthlyBudget { get; set; }
    public int ExpectedRps { get; set; }
    public bool NeedsAutoScaling { get; set; }
    public bool NeedsMultiRegion { get; set; }
    public string PrimaryCloud { get; set; } = "any";   // aws|azure|gcp|any
    public string TeamK8sExperience { get; set; } = "some"; // none|some|expert
    public bool NeedsCompliance { get; set; }
    public bool NeedsRealTimeStreaming { get; set; }
    public bool NeedsEdgeDeployment { get; set; }
}

public class HostingRecommendation
{
    public HostingPlatform Primary { get; set; }
    public int PrimaryScore { get; set; }
    public List<HostingPlatform> Alternatives { get; set; }
    public string Reasoning { get; set; }
}

public class DeployConfig
{
    public string Environment { get; set; } = "staging";
    public string Region { get; set; } = "us-east-1";
    public string ImageTag { get; set; } = "latest";
    public int ApiReplicas { get; set; } = 3;
    public int OrchestratorReplicas { get; set; } = 2;
    public bool AutoScale { get; set; } = true;
    public bool MultiRegion { get; set; } = false;
}
