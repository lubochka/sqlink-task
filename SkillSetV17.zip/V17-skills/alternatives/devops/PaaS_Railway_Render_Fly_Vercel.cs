// XIIGen DevOps Hosting | PaaS Alternatives
// Railway, Render, Fly.io, Vercel
// Each has: config file, deploy script, health check, CI integration

// ═══════════════════════════════════════════════════════
// 1. RAILWAY — Fast GitHub deploy, visual UI ($5/mo+)
// ═══════════════════════════════════════════════════════

// FILE: railway.toml
/*
[build]
builder = "dockerfile"
dockerfilePath = "Dockerfile"

[deploy]
numReplicas = 2
startCommand = "dotnet XIIGen.Api.dll"
healthcheckPath = "/health"
healthcheckTimeout = 30
restartPolicyType = "ON_FAILURE"
restartPolicyMaxRetries = 3

[[services]]
name = "xiigen-api"
internalPort = 8080

[[services]]
name = "xiigen-orchestrator"
internalPort = 8081

[services.xiigen-api.env]
ASPNETCORE_URLS = "http://+:8080"
ELASTICSEARCH_URL = "${{Elasticsearch.ELASTICSEARCH_URL}}"
REDIS_URL = "${{Redis.REDIS_URL}}"

[services.xiigen-orchestrator.env]
ASPNETCORE_URLS = "http://+:8081"
ELASTICSEARCH_URL = "${{Elasticsearch.ELASTICSEARCH_URL}}"
REDIS_URL = "${{Redis.REDIS_URL}}"
*/

// FILE: deploy/railway/deploy.sh
/*
#!/bin/bash
# Railway deployment script
set -e

echo "=== XIIGen Railway Deployment ==="

# Install Railway CLI
npm i -g @railway/cli

# Login (requires RAILWAY_TOKEN env var)
railway login --token "$RAILWAY_TOKEN"

# Create project if not exists
railway project create xiigen-$ENVIRONMENT 2>/dev/null || true

# Link to project
railway link

# Add Elasticsearch plugin
railway add --plugin elasticsearch || true

# Add Redis plugin
railway add --plugin redis || true

# Set environment variables from Key Vault
railway variables set \
  AI_PROVIDER_KEY="$AI_PROVIDER_KEY" \
  JWT_SECRET="$JWT_SECRET" \
  ENVIRONMENT="$ENVIRONMENT"

# Deploy
railway up --detach

# Health check
sleep 30
DOMAIN=$(railway domain)
curl -f "https://$DOMAIN/health" || { echo "Health check failed!"; exit 1; }

echo "=== Deployed to https://$DOMAIN ==="
*/

// ═══════════════════════════════════════════════════════
// 2. RENDER — Heroku replacement, built-in DBs ($7/mo+)
// ═══════════════════════════════════════════════════════

// FILE: render.yaml (Infrastructure-as-Code)
/*
services:
  - type: web
    name: xiigen-api
    runtime: docker
    dockerfilePath: ./Dockerfile
    plan: standard
    region: oregon
    scaling:
      minInstances: 1
      maxInstances: 5
      targetMemoryPercent: 75
      targetCPUPercent: 70
    healthCheckPath: /health
    envVars:
      - key: ASPNETCORE_URLS
        value: http://+:10000
      - key: ASPNETCORE_ENVIRONMENT
        value: Production
      - key: ELASTICSEARCH_URL
        fromService:
          type: pserv
          name: xiigen-elasticsearch
          envVarKey: ELASTICSEARCH_URL
      - key: REDIS_URL
        fromService:
          type: redis
          name: xiigen-redis
          property: connectionString
      - key: AI_PROVIDER_KEY
        sync: false  # Set manually in dashboard
      - key: JWT_SECRET
        generateValue: true

  - type: worker
    name: xiigen-orchestrator
    runtime: docker
    dockerfilePath: ./Dockerfile.orchestrator
    plan: standard
    envVars:
      - key: ELASTICSEARCH_URL
        fromService:
          type: pserv
          name: xiigen-elasticsearch
          envVarKey: ELASTICSEARCH_URL
      - key: REDIS_URL
        fromService:
          type: redis
          name: xiigen-redis
          property: connectionString

  - type: pserv
    name: xiigen-elasticsearch
    runtime: docker
    dockerfilePath: ./deploy/render/Dockerfile.elasticsearch
    plan: standard plus
    disk:
      name: es-data
      mountPath: /usr/share/elasticsearch/data
      sizeGB: 20
    envVars:
      - key: discovery.type
        value: single-node
      - key: xpack.security.enabled
        value: "false"
      - key: ELASTICSEARCH_URL
        value: http://xiigen-elasticsearch:9200

  - type: redis
    name: xiigen-redis
    plan: standard
    maxmemoryPolicy: allkeys-lru
    ipAllowList: []
*/

// FILE: deploy/render/deploy.sh
/*
#!/bin/bash
set -e
echo "=== XIIGen Render Deployment ==="

# Render auto-deploys from GitHub on push to main
# For manual deploy:
curl -X POST "https://api.render.com/v1/services/$RENDER_SERVICE_ID/deploys" \
  -H "Authorization: Bearer $RENDER_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"clearCache": "do_not_clear"}'

echo "Deploy triggered. Monitor at https://dashboard.render.com"
*/

// ═══════════════════════════════════════════════════════
// 3. FLY.IO — Global edge network, low latency ($2/mo+)
// ═══════════════════════════════════════════════════════

// FILE: fly.toml
/*
app = "xiigen-api"
primary_region = "iad"  # US East

[build]
  dockerfile = "Dockerfile"

[env]
  ASPNETCORE_URLS = "http://+:8080"
  ASPNETCORE_ENVIRONMENT = "Production"

[http_service]
  internal_port = 8080
  force_https = true
  auto_stop_machines = true
  auto_start_machines = true
  min_machines_running = 1
  processes = ["app"]

  [http_service.concurrency]
    type = "requests"
    hard_limit = 250
    soft_limit = 200

  [[http_service.checks]]
    interval = "15s"
    timeout = "5s"
    grace_period = "30s"
    method = "GET"
    path = "/health"

[[vm]]
  cpu_kind = "shared"
  cpus = 2
  memory_mb = 1024

# Multi-region for global low latency
[[vm]]
  cpu_kind = "shared"
  cpus = 2
  memory_mb = 1024
  [vm.regions]
    ams = 1  # Amsterdam
    syd = 1  # Sydney
    nrt = 1  # Tokyo

[metrics]
  port = 9091
  path = "/metrics"
*/

// FILE: deploy/fly/deploy.sh
/*
#!/bin/bash
set -e
echo "=== XIIGen Fly.io Deployment ==="

# Install flyctl
curl -L https://fly.io/install.sh | sh

# Login
fly auth token "$FLY_API_TOKEN"

# Create app if needed
fly apps create xiigen-api-$ENVIRONMENT 2>/dev/null || true

# Set secrets
fly secrets set \
  ELASTICSEARCH_URL="$ELASTICSEARCH_URL" \
  REDIS_URL="$REDIS_URL" \
  AI_PROVIDER_KEY="$AI_PROVIDER_KEY" \
  JWT_SECRET="$JWT_SECRET" \
  --app xiigen-api-$ENVIRONMENT

# Create Fly Postgres (managed DB alternative)
fly postgres create --name xiigen-pg-$ENVIRONMENT --region iad 2>/dev/null || true

# Deploy
fly deploy --app xiigen-api-$ENVIRONMENT --strategy rolling

# Scale to multi-region
fly scale count 2 --region iad --app xiigen-api-$ENVIRONMENT
fly scale count 1 --region ams --app xiigen-api-$ENVIRONMENT

# Health check
fly status --app xiigen-api-$ENVIRONMENT
echo "=== Deployed to https://xiigen-api-$ENVIRONMENT.fly.dev ==="
*/

// ═══════════════════════════════════════════════════════
// 4. VERCEL — Frontend only (React editor + runner)
// ═══════════════════════════════════════════════════════

// FILE: vercel.json (for XIIGen web editor frontend only)
/*
{
  "$schema": "https://openapi.vercel.sh/vercel.json",
  "framework": "nextjs",
  "buildCommand": "cd client/xiigen-web-editor && npm run build",
  "outputDirectory": "client/xiigen-web-editor/.next",
  "installCommand": "cd client/xiigen-web-editor && npm ci",
  "regions": ["iad1", "sfo1", "lhr1", "hnd1"],
  "env": {
    "NEXT_PUBLIC_API_URL": "@xiigen-api-url",
    "NEXT_PUBLIC_WS_URL": "@xiigen-ws-url"
  },
  "headers": [
    {
      "source": "/(.*)",
      "headers": [
        { "key": "X-Content-Type-Options", "value": "nosniff" },
        { "key": "X-Frame-Options", "value": "DENY" },
        { "key": "Strict-Transport-Security", "value": "max-age=31536000" }
      ]
    }
  ],
  "rewrites": [
    { "source": "/api/:path*", "destination": "https://api.xiigen.io/api/:path*" }
  ]
}
*/
