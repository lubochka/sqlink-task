// React Native Client - Skill 25 | Expo + TypeScript
// Main App with Flow Visualization

import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, ScrollView, TouchableOpacity, TextInput, StyleSheet, ActivityIndicator } from 'react-native';

const API_BASE = 'http://localhost:5000/api';

// ─── Types ──────────────────────────────────────────
interface FlowStatus {
  traceId: string; flowId: string; status: string; currentStep: string;
  progress: number; result: any; steps: StepStatus[]; startedAt: string; completedAt?: string;
}
interface StepStatus {
  stepId: string; nodeType: string; status: string; startedAt?: string; completedAt?: string; error?: string;
}

// ─── API Client ─────────────────────────────────────
const api = {
  triggerFlow: async (flowId: string, body: any) => {
    const res = await fetch(`${API_BASE}/flow/trigger`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ flowId, body, traceId: `trace-${Date.now()}` })
    });
    return res.json();
  },
  pollStatus: async (traceId: string): Promise<FlowStatus> => {
    const res = await fetch(`${API_BASE}/flow/${traceId}/status`);
    return res.json();
  },
  submitFeedback: async (traceId: string, stepId: string, rating: string, text: string) => {
    const res = await fetch(`${API_BASE}/flow/${traceId}/feedback`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ stepId, rating, text })
    });
    return res.json();
  },
  getDebug: async (traceId: string) => {
    const res = await fetch(`${API_BASE}/debug/${traceId}`);
    return res.json();
  }
};

// ─── Flow Node Component (n8n-style) ────────────────
const FlowNode = ({ step, isActive }: { step: StepStatus; isActive: boolean }) => {
  const statusColor = { Completed: '#27ae60', Running: '#f39c12', Failed: '#e74c3c', Draft: '#95a5a6' };
  return (
    <View style={[styles.node, { borderColor: statusColor[step.status] || '#95a5a6', borderWidth: isActive ? 3 : 1 }]}>
      <Text style={styles.nodeType}>{step.nodeType}</Text>
      <Text style={styles.nodeId}>{step.stepId}</Text>
      <View style={[styles.statusBadge, { backgroundColor: statusColor[step.status] || '#95a5a6' }]}>
        <Text style={styles.statusText}>{step.status}</Text>
      </View>
    </View>
  );
};

// ─── Main App ───────────────────────────────────────
export default function App() {
  const [traceId, setTraceId] = useState<string>('');
  const [flowStatus, setFlowStatus] = useState<FlowStatus | null>(null);
  const [input, setInput] = useState('');
  const [polling, setPolling] = useState(false);
  const [feedbackText, setFeedbackText] = useState('');

  // Polling effect
  useEffect(() => {
    if (!polling || !traceId) return;
    const interval = setInterval(async () => {
      const status = await api.pollStatus(traceId);
      setFlowStatus(status);
      if (status.status === 'Completed' || status.status === 'Failed') setPolling(false);
    }, 3000);
    return () => clearInterval(interval);
  }, [polling, traceId]);

  const handleTrigger = async () => {
    try {
      const body = JSON.parse(input || '{}');
      const result = await api.triggerFlow('figma-to-code', body);
      setTraceId(result.traceId);
      setPolling(true);
    } catch (e) { console.error('Invalid JSON input'); }
  };

  const handleFeedback = async (rating: string) => {
    if (!traceId || !flowStatus?.currentStep) return;
    await api.submitFeedback(traceId, flowStatus.currentStep, rating, feedbackText);
    setFeedbackText('');
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>XIIGen Flow Runner</Text>

      {/* Input Section */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Figma Input (JSON)</Text>
        <TextInput style={styles.input} multiline value={input} onChangeText={setInput} placeholder='{"nodes": [...]}' />
        <TouchableOpacity style={styles.button} onPress={handleTrigger}>
          <Text style={styles.buttonText}>Trigger Flow</Text>
        </TouchableOpacity>
      </View>

      {/* Flow Visualization */}
      {flowStatus && (
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Flow: {flowStatus.status} ({Math.round(flowStatus.progress * 100)}%)</Text>
          <View style={styles.flowContainer}>
            {flowStatus.steps?.map((step, i) => (
              <React.Fragment key={step.stepId}>
                <FlowNode step={step} isActive={step.stepId === flowStatus.currentStep} />
                {i < flowStatus.steps.length - 1 && <Text style={styles.arrow}>→</Text>}
              </React.Fragment>
            ))}
          </View>
          {polling && <ActivityIndicator size="large" color="#2E86C1" />}

          {/* Result */}
          {flowStatus.result && (
            <View style={styles.resultBox}>
              <Text style={styles.sectionTitle}>Result</Text>
              <Text style={styles.code}>{JSON.stringify(flowStatus.result, null, 2)}</Text>
            </View>
          )}

          {/* Feedback */}
          {flowStatus.status === 'Completed' && (
            <View style={styles.feedbackSection}>
              <Text style={styles.sectionTitle}>Feedback</Text>
              <TextInput style={styles.input} value={feedbackText} onChangeText={setFeedbackText} placeholder="Additional feedback..." />
              <View style={styles.feedbackButtons}>
                {['Positive', 'Neutral', 'Negative'].map(r => (
                  <TouchableOpacity key={r} style={[styles.fbBtn, { backgroundColor: r === 'Positive' ? '#27ae60' : r === 'Negative' ? '#e74c3c' : '#95a5a6' }]} onPress={() => handleFeedback(r)}>
                    <Text style={styles.buttonText}>{r === 'Positive' ? '👍' : r === 'Negative' ? '👎' : '😐'} {r}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          )}
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#f5f6fa' },
  title: { fontSize: 28, fontWeight: 'bold', color: '#1B4F72', marginBottom: 20 },
  section: { backgroundColor: '#fff', borderRadius: 12, padding: 16, marginBottom: 16, shadowColor: '#000', shadowOpacity: 0.1, shadowRadius: 4 },
  sectionTitle: { fontSize: 18, fontWeight: '600', color: '#2C3E50', marginBottom: 12 },
  input: { borderWidth: 1, borderColor: '#ddd', borderRadius: 8, padding: 12, minHeight: 80, fontFamily: 'monospace', marginBottom: 12 },
  button: { backgroundColor: '#2E86C1', borderRadius: 8, padding: 14, alignItems: 'center' },
  buttonText: { color: '#fff', fontWeight: '600', fontSize: 16 },
  flowContainer: { flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', gap: 8 },
  node: { backgroundColor: '#fff', borderRadius: 8, padding: 12, minWidth: 120, alignItems: 'center', shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 2 },
  nodeType: { fontSize: 12, color: '#7f8c8d', marginBottom: 4 },
  nodeId: { fontSize: 14, fontWeight: '600', color: '#2C3E50' },
  statusBadge: { borderRadius: 4, paddingHorizontal: 8, paddingVertical: 2, marginTop: 6 },
  statusText: { color: '#fff', fontSize: 11, fontWeight: '600' },
  arrow: { fontSize: 20, color: '#bdc3c7', marginHorizontal: 4 },
  resultBox: { marginTop: 12, backgroundColor: '#f8f9fa', borderRadius: 8, padding: 12 },
  code: { fontFamily: 'monospace', fontSize: 12, color: '#2C3E50' },
  feedbackSection: { marginTop: 16 },
  feedbackButtons: { flexDirection: 'row', gap: 8, marginTop: 8 },
  fbBtn: { flex: 1, borderRadius: 8, padding: 12, alignItems: 'center' },
});
