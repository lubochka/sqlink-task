<?php
// XIIGen CLI Client — PHP | Skill 25
namespace XIIGen\Client;

class CliClient {
    private string $baseUrl;
    private string $token = '';

    public function __construct(string $baseUrl) { $this->baseUrl = $baseUrl; }

    private function request(string $method, string $path, ?array $body = null): array {
        $ch = curl_init($this->baseUrl . $path);
        $headers = ['Content-Type: application/json'];
        if ($this->token) $headers[] = "Authorization: Bearer {$this->token}";
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_HTTPHEADER => $headers, CURLOPT_CUSTOMREQUEST => $method]);
        if ($body) curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
        $response = curl_exec($ch); curl_close($ch);
        return json_decode($response, true) ?? [];
    }

    public function login(string $email, string $password): array {
        $data = $this->request('POST', '/auth/login', ['email' => $email, 'password' => $password]);
        $this->token = $data['token'] ?? '';
        return $data;
    }

    public function triggerFlow(string $flowId, array $input): string {
        $data = $this->request('POST', "/flows/{$flowId}/trigger", $input);
        return $data['traceId'] ?? '';
    }

    public function pollTrace(string $traceId, int $intervalSec = 2): array {
        while (true) {
            $data = $this->request('GET', "/traces/{$traceId}");
            if (in_array($data['status'] ?? '', ['completed', 'failed'])) return $data;
            sleep($intervalSec);
        }
    }
}
