// XIIGen Desktop Client — JavaFX | Skill 25
package com.xiigen.client;

import java.net.URI;
import java.net.http.*;
import java.net.http.HttpResponse.BodyHandlers;
import java.util.*;
import com.google.gson.*;

public class DesktopClient {
    private final String baseUrl;
    private String token = "";
    private final HttpClient http = HttpClient.newHttpClient();
    private final Gson gson = new Gson();

    public DesktopClient(String baseUrl) { this.baseUrl = baseUrl; }

    private HttpRequest.Builder req(String path) {
        var b = HttpRequest.newBuilder().uri(URI.create(baseUrl + path)).header("Content-Type", "application/json");
        if (!token.isEmpty()) b.header("Authorization", "Bearer " + token);
        return b;
    }

    public Map<String, String> login(String email, String password) throws Exception {
        var body = gson.toJson(Map.of("email", email, "password", password));
        var res = http.send(req("/auth/login").POST(HttpRequest.BodyPublishers.ofString(body)).build(), BodyHandlers.ofString());
        Map<String, String> data = gson.fromJson(res.body(), Map.class);
        this.token = data.get("token");
        return data;
    }

    public String triggerFlow(String flowId, Map<String, Object> input) throws Exception {
        var body = gson.toJson(input);
        var res = http.send(req("/flows/" + flowId + "/trigger").POST(HttpRequest.BodyPublishers.ofString(body)).build(), BodyHandlers.ofString());
        return gson.fromJson(res.body(), Map.class).get("traceId").toString();
    }

    public record TraceResult(String traceId, String status, JsonObject result, double progress) {}

    public TraceResult pollTrace(String traceId) throws Exception {
        while (true) {
            var res = http.send(req("/traces/" + traceId).GET().build(), BodyHandlers.ofString());
            var data = gson.fromJson(res.body(), JsonObject.class);
            var status = data.get("status").getAsString();
            if ("completed".equals(status) || "failed".equals(status))
                return new TraceResult(traceId, status, data.has("result") ? data.getAsJsonObject("result") : null, data.has("progress") ? data.get("progress").getAsDouble() : 0);
            Thread.sleep(2000);
        }
    }
}
