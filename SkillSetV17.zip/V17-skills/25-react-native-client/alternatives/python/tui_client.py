"""XIIGen TUI Client — Python Textual | Skill 25"""
import asyncio, httpx, json
from dataclasses import dataclass, field
from typing import Optional

@dataclass
class TraceResult:
    trace_id: str; status: str; result: Optional[dict] = None; progress: float = 0.0

class XIIGenClient:
    def __init__(self, base_url: str, token: str = ""):
        self.base_url = base_url
        self.headers = {"Content-Type": "application/json"}
        if token: self.headers["Authorization"] = f"Bearer {token}"

    async def login(self, email: str, password: str) -> dict:
        async with httpx.AsyncClient() as c:
            r = await c.post(f"{self.base_url}/auth/login", json={"email": email, "password": password}, headers=self.headers)
            r.raise_for_status(); data = r.json()
            self.headers["Authorization"] = f"Bearer {data['token']}"
            return data

    async def trigger_flow(self, flow_id: str, input_data: dict) -> str:
        async with httpx.AsyncClient() as c:
            r = await c.post(f"{self.base_url}/flows/{flow_id}/trigger", json=input_data, headers=self.headers)
            r.raise_for_status(); return r.json()["traceId"]

    async def poll_trace(self, trace_id: str, interval: float = 2.0) -> TraceResult:
        async with httpx.AsyncClient() as c:
            while True:
                r = await c.get(f"{self.base_url}/traces/{trace_id}", headers=self.headers)
                r.raise_for_status(); data = r.json()
                result = TraceResult(trace_id=trace_id, status=data["status"], result=data.get("result"), progress=data.get("progress", 0))
                if result.status in ("completed", "failed"): return result
                await asyncio.sleep(interval)

    async def get_flows(self) -> list:
        async with httpx.AsyncClient() as c:
            r = await c.get(f"{self.base_url}/flows", headers=self.headers)
            r.raise_for_status(); return r.json().get("items", [])
