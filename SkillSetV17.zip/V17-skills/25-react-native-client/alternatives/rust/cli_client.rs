// XIIGen CLI Client — Rust | Skill 25
use reqwest::{Client, header};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use tokio::time::{sleep, Duration};

#[derive(Debug, Deserialize)]
pub struct TraceResult {
    pub trace_id: String, pub status: String,
    pub result: Option<serde_json::Value>, pub progress: Option<f64>,
}

pub struct XIIGenCli {
    client: Client, base_url: String, token: String,
}

impl XIIGenCli {
    pub fn new(base_url: &str) -> Self {
        Self { client: Client::new(), base_url: base_url.to_string(), token: String::new() }
    }

    pub async fn login(&mut self, email: &str, password: &str) -> Result<(), Box<dyn std::error::Error>> {
        let body = serde_json::json!({"email": email, "password": password});
        let res: serde_json::Value = self.client.post(format!("{}/auth/login", self.base_url))
            .json(&body).send().await?.json().await?;
        self.token = res["token"].as_str().unwrap_or("").to_string();
        Ok(())
    }

    pub async fn trigger_flow(&self, flow_id: &str, input: serde_json::Value) -> Result<String, Box<dyn std::error::Error>> {
        let res: serde_json::Value = self.client.post(format!("{}/flows/{}/trigger", self.base_url, flow_id))
            .bearer_auth(&self.token).json(&input).send().await?.json().await?;
        Ok(res["traceId"].as_str().unwrap_or("").to_string())
    }

    pub async fn poll_trace(&self, trace_id: &str) -> Result<TraceResult, Box<dyn std::error::Error>> {
        loop {
            let res: TraceResult = self.client.get(format!("{}/traces/{}", self.base_url, trace_id))
                .bearer_auth(&self.token).send().await?.json().await?;
            if res.status == "completed" || res.status == "failed" { return Ok(res); }
            sleep(Duration::from_secs(2)).await;
        }
    }
}
