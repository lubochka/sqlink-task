// XIIGen Web Client — React + Vite | Skill 25
import React, { useState, useEffect, useCallback } from 'react';

interface FlowNode { id: string; type: string; position: { x: number; y: number }; data: Record<string, any>; }
interface FlowEdge { id: string; source: string; target: string; }
interface TraceResult { traceId: string; status: 'pending' | 'running' | 'completed' | 'failed'; result?: any; progress?: number; }

class XIIGenApiClient {
  constructor(private baseUrl: string, private token?: string) {}

  private async request<T>(path: string, opts?: RequestInit): Promise<T> {
    const res = await fetch(`${this.baseUrl}${path}`, {
      ...opts,
      headers: { 'Content-Type': 'application/json', ...(this.token ? { Authorization: `Bearer ${this.token}` } : {}), ...opts?.headers }
    });
    if (!res.ok) throw new Error(`API ${res.status}: ${res.statusText}`);
    return res.json();
  }

  login(email: string, password: string) { return this.request<{ token: string; refreshToken: string }>('/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) }); }
  triggerFlow(flowId: string, input: Record<string, any>) { return this.request<{ traceId: string }>(`/flows/${flowId}/trigger`, { method: 'POST', body: JSON.stringify(input) }); }
  pollTrace(traceId: string) { return this.request<TraceResult>(`/traces/${traceId}`); }
  getFlows() { return this.request<{ items: any[] }>('/flows'); }
  saveFlow(flow: { id?: string; name: string; nodes: FlowNode[]; edges: FlowEdge[] }) { return this.request<any>('/flows', { method: 'POST', body: JSON.stringify(flow) }); }
}

// Polling hook
function useTracePoll(client: XIIGenApiClient, traceId: string | null, intervalMs = 2000) {
  const [result, setResult] = useState<TraceResult | null>(null);
  useEffect(() => {
    if (!traceId) return;
    const poll = setInterval(async () => {
      const r = await client.pollTrace(traceId);
      setResult(r);
      if (r.status === 'completed' || r.status === 'failed') clearInterval(poll);
    }, intervalMs);
    return () => clearInterval(poll);
  }, [traceId]);
  return result;
}

export { XIIGenApiClient, useTracePoll, FlowNode, FlowEdge, TraceResult };
