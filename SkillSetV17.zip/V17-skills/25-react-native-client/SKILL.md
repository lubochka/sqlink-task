---
skill_id: "25"
name: react-native-client
title: "React Native Mobile Client"
layer: "L9: Showroom"
version: "17.1"
status: "active"
priority: "P0"
dependencies: ["15-api-gateway", "20-auth-service", "13-feedback-service"]
alternatives_client: [flutter, swiftui, kotlin-compose, ionic]
genie_dna:
  - "DNA-UI: Client uses dynamic rendering — screens built from server-driven configs"
  - "DNA-6: Client alternatives share the same API contract"
  - "DNA-RESULT: API responses always DataProcessResult — client has unified error handling"
triggers: mobile app, react native, client, UI, screens, navigation, feedback UI, flow results, expo
estimated_loc: 2000
---

# Skill 25: React Native Mobile Client
## Mobile Application for Flow Management, Results Viewing, and Feedback

**Classification:** HUMAN — UI requires design judgment  
**Priority:** P0 — Primary user interface  
**Dependencies:** Skill 15 (API Gateway), Skill 20 (Auth), Skill 13 (Feedback)  
**Layer:** L9: Showroom  
**Estimated LOC:** ~2000  

---

## Overview

The React Native Client is the primary mobile interface for XIIGen users. It provides: authentication (login/register with SSO), flow management (view, trigger, monitor), real-time results with polling, node-level debugging, feedback submission (good/neutral/negative + text), chat interface, and notification handling. The app uses Expo for cross-platform deployment and follows a server-driven UI pattern where screen layouts can be updated from the backend without app updates.

## Key Concepts

- **Server-Driven UI** — Screen layouts defined as dynamic documents on the server. The client renders them dynamically. Add new screens without app store updates.
- **Polling Engine** — Configurable polling for flow execution status. Polls every X seconds until result ready, with exponential backoff.
- **Feedback Widget** — Reusable component for good/neutral/negative rating + text input. Used on every AI-generated result screen.
- **Offline Queue** — Actions taken offline (feedback, text input) queued locally and synced when connection restores.
- **Theme System** — Design system tokens (Skill 19) applied as React Native themes for consistent styling.

---

## DNA Integration

### Required Patterns
- **DataProcessResult** — All API responses parsed as DataProcessResult. Unified error handling component shows errors consistently.
- **Dynamic Document** — Screen configs, form definitions, and flow visualizations all received as dynamic documents and rendered dynamically.
- **EventDriven** — Push notifications trigger UI updates. WebSocket/SSE for real-time flow progress.

### Anti-Patterns to AVOID
- ❌ Hardcoding screen layouts — use server-driven UI
- ❌ Blocking UI thread during API calls — always async with loading states
- ❌ Storing auth tokens in AsyncStorage without encryption
- ❌ Polling without backoff — use exponential backoff to reduce server load

---

## Screen Map

1. **Auth** — Login, Register, SSO, Password Reset
2. **Dashboard** — Active flows, recent results, notifications
3. **Flow List** — Browse/search flows, trigger new flow
4. **Flow Detail** — Real-time progress, node-by-node status
5. **Node Debug** — Input/output/prompt for each node
6. **Results** — AI-generated output with feedback widget
7. **Feedback** — Rating + text input, history of past feedback
8. **Chat** — AI chat interface for system interaction
9. **Settings** — Profile, notifications, theme, language
10. **Content** — Content pipeline results preview

## Primary Implementation (React Native + Expo)

### Core Architecture

```typescript
// App structure
src/
├── screens/           // Screen components
├── components/        // Reusable UI components
│   ├── FeedbackWidget.tsx
│   ├── FlowNodeCard.tsx
│   ├── PollingContainer.tsx
│   └── DynamicRenderer.tsx
├── services/          // API layer
│   ├── apiClient.ts   // Axios + DataProcessResult parsing
│   ├── authService.ts
│   └── flowService.ts
├── hooks/             // Custom hooks
│   ├── usePolling.ts
│   ├── useAuth.ts
│   └── useDynamicScreen.ts
├── store/             // Redux/Zustand state
├── theme/             // Design system tokens
└── navigation/        // React Navigation config
```

### Key Components

```tsx
// Polling Hook — used for flow status
const usePolling = (traceId: string, intervalMs: number = 3000) => {
  const [status, setStatus] = useState<DataProcessResult>(null);
  useEffect(() => {
    const poll = async () => {
      const result = await flowService.getStatus(traceId);
      setStatus(result);
      if (result.success && result.data.status === 'completed') clearInterval(timer);
    };
    const timer = setInterval(poll, intervalMs);
    return () => clearInterval(timer);
  }, [traceId]);
  return status;
};

// Feedback Widget — reusable across all result screens
const FeedbackWidget = ({ traceId, nodeId }: Props) => {
  const [rating, setRating] = useState<'good'|'neutral'|'negative'>(null);
  const [text, setText] = useState('');
  const submit = () => feedbackService.submit({ traceId, nodeId, rating, text });
  return (
    <View>
      <RatingButtons value={rating} onChange={setRating} />
      <TextInput value={text} onChangeText={setText} placeholder="Additional feedback..." />
      <Button title="Submit" onPress={submit} />
    </View>
  );
};
```

### DI / Service Registration

```typescript
// apiClient.ts — unified DataProcessResult handling
const apiClient = axios.create({ baseURL: config.API_URL });
apiClient.interceptors.response.use(
  (res) => res.data as DataProcessResult,
  (err) => ({ success: false, data: null, message: err.message })
);
```

---

## Test Scenarios

1. Login with valid credentials → verify token stored securely, dashboard loads
2. Trigger flow → verify traceId returned, polling starts
3. Poll until completion → verify results screen shows output
4. Submit feedback (good + text) → verify API call succeeds
5. View node debug → verify input/prompt/output displayed for each node
6. Offline feedback → verify queued locally, synced on reconnect
7. Server-driven screen update → verify new layout renders without app update

## Component Classification
- **Category:** Mobile Application
- **Inputs:** User interactions, server-driven configs, API responses
- **Outputs:** API calls, local state, push notification handling
- **Side Effects:** Network requests, local storage, push notification registration
