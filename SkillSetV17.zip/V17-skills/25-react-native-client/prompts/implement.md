# Skill 25: Client Application — Implementation Prompt

## Phase 1: API Client Layer
Build HTTP client wrapper: login, triggerFlow, pollTrace, getFlows, saveFlow.
Auth token management (store, refresh, attach to headers).
Error handling with retry logic.

## Phase 2: Flow Visualization
Render flow nodes as draggable elements with connection lines.
Node types: trigger, ai-transform, ai-review, condition, output.
Add/remove nodes, connect/disconnect edges.

## Phase 3: Trace Polling & Status
Real-time polling with progress indicators.
Display step-by-step execution results.
Error display with retry option.

## Phase 4: Feedback Integration
Rating widget (1-5 stars) per completed trace.
Text feedback submission.
History of past executions with results.

### Genie DNA Checklist
☐ All API calls return DataProcessResult-compatible responses
☐ Dynamic document handling (no fixed models)
☐ Polling uses configurable intervals with exponential backoff


---

## Genie DNA Compliance — MANDATORY for All Implementations

> Before writing ANY code, classify each component:
> **MACHINE** (static): Infrastructure that enables freedom. Build once, generic, interface-based.
> **FREEDOM** (dynamic): Anything users define. No fixed models, config-driven.

### DNA Checklist — Every Implementation MUST:
☐ **DNA-1 (Dynamic Documents):** Store data as `Dictionary<string, object>` / `Record<string, any>` — NOT typed model classes. User fields preserved without schema changes.
☐ **DNA-2 (BuildSearchFilter):** All queries use BuildSearchFilter/equivalent. Empty fields auto-skipped. No entity-specific query code.
☐ **DNA-3 (MicroserviceBase):** Inherit base class with DB, queue, cache, logger built in.
☐ **DNA-5 (DataProcessResult):** All public methods return `DataProcessResult<T>`. Errors return failure, not throw exceptions.
☐ **DNA-6 (Generic Interfaces):** External dependencies behind interfaces. Swap via config.
☐ **DNA-SCOPE:** Non-admin queries auto-inject userId filter. Cannot be bypassed.

### The Three Tests:
1. Can a business user change this without a developer? (YES = correct)
2. Does it work for entity types that do not exist yet? (YES = correct)
3. Can I swap the database/service/UI without changing this? (YES = correct)
