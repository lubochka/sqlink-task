// XIIGen.AI/Dispatch/AiDispatcher.cs - Skill 07 | .NET 9
using System.Collections.Concurrent;
using System.Diagnostics;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;
using XIIGen.AI.Providers;

namespace XIIGen.AI.Dispatch;

public class AiDispatcher(AiProviderFactory providerFactory)
{
    public async Task<AiDispatchResult> DispatchAsync(
        AiRequest request, IEnumerable<string> modelNames = null, TimeSpan? timeout = null, CancellationToken ct = default)
    {
        var models = (modelNames ?? providerFactory.RegisteredProviders).ToList();
        var results = new ConcurrentBag<AiScoredResult>();
        var sw = Stopwatch.StartNew();
        var cts = CancellationTokenSource.CreateLinkedTokenSource(ct);
        if (timeout.HasValue) cts.CancelAfter(timeout.Value);

        var tasks = models.Select(async model =>
        {
            try
            {
                var provider = providerFactory.Resolve(model);
                var response = await provider.ExecuteAsync(request with { Model = model }, cts.Token);
                if (response.Success)
                {
                    var score = ScoreResponse(response, request);
                    results.Add(new AiScoredResult { ModelName = model, Response = response, Score = score });
                }
            }
            catch (OperationCanceledException) { }
            catch (Exception ex) { results.Add(new AiScoredResult { ModelName = model, Response = new AiResponse { Success = false, Error = ex.Message }, Score = 0 }); }
        });

        await Task.WhenAll(tasks);
        sw.Stop();

        var sorted = results.Where(r => r.Response.Success).OrderByDescending(r => r.Score).ToList();
        var best = sorted.FirstOrDefault();

        return new AiDispatchResult
        {
            TraceId = request.TraceId,
            StepId = request.StepId,
            BestResult = best,
            AllResults = sorted,
            TotalDuration = sw.Elapsed,
            ModelsQueried = models.Count,
            ModelsSucceeded = sorted.Count
        };
    }

    private double ScoreResponse(AiResponse response, AiRequest request)
    {
        double score = 0;
        if (response.Content?.Length > 100) score += 30; // non-trivial response
        if (response.Content?.Length > 500) score += 20; // substantial response
        if (response.Content?.Contains("```") == true) score += 15; // contains code blocks
        if (response.Duration.TotalSeconds < 10) score += 15; // fast response
        if (response.Duration.TotalSeconds < 5) score += 10; // very fast
        score += Math.Max(0, 10 - (response.Usage?.OutputTokens ?? 0) / 1000.0); // token efficiency
        return Math.Min(100, score);
    }
}

public class AiDispatchResult
{
    public string TraceId { get; set; }
    public string StepId { get; set; }
    public AiScoredResult BestResult { get; set; }
    public List<AiScoredResult> AllResults { get; set; } = [];
    public TimeSpan TotalDuration { get; set; }
    public int ModelsQueried { get; set; }
    public int ModelsSucceeded { get; set; }
}

public class AiScoredResult
{
    public string ModelName { get; set; }
    public AiResponse Response { get; set; }
    public double Score { get; set; }
}

// ─── Prompt Context Builder ─────────────────────────
public class PromptContextBuilder
{
    private readonly List<string> _sections = [];

    public PromptContextBuilder AddPreviousStepOutput(string stepId, string output)
    { _sections.Add($"### Previous Step ({stepId}):\n{Truncate(output, 2000)}"); return this; }

    public PromptContextBuilder AddFeedback(IEnumerable<FeedbackEntry> feedback)
    {
        var positive = feedback.Where(f => f.Rating == Core.Enums.FeedbackRating.Positive).Take(3);
        var negative = feedback.Where(f => f.Rating == Core.Enums.FeedbackRating.Negative).Take(3);
        if (positive.Any()) _sections.Add($"### What worked well:\n{string.Join("\n", positive.Select(f => $"- {f.Text}"))}");
        if (negative.Any()) _sections.Add($"### What to avoid:\n{string.Join("\n", negative.Select(f => $"- {f.Text}"))}");
        return this;
    }

    public PromptContextBuilder AddSection(string title, string content)
    { _sections.Add($"### {title}:\n{content}"); return this; }

    public string Build() => _sections.Count > 0 ? $"## Context\n\n{string.Join("\n\n", _sections)}\n\n---\n\n" : "";

    private static string Truncate(string s, int max) => s?.Length > max ? s[..max] + "..." : s ?? "";
}
