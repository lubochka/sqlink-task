// Skill 07: AI Dispatcher — Rust / tokio
// Fan-out to N AI models, score, select best
use crate::ai_providers::*;
use std::sync::Arc;
use std::time::{Duration, Instant};
use tokio::sync::Mutex;

#[derive(Clone, Debug)]
pub struct AiScoredResult {
    pub model_name: String,
    pub response: AiResponse,
    pub score: f64,
}

#[derive(Clone, Debug)]
pub struct AiDispatchResult {
    pub trace_id: String,
    pub best_result: Option<AiScoredResult>,
    pub all_results: Vec<AiScoredResult>,
    pub total_duration_ms: u64,
    pub models_queried: usize,
    pub models_succeeded: usize,
}

pub struct AiDispatcher {
    factory: Arc<AiProviderFactory>,
}

impl AiDispatcher {
    pub fn new(factory: Arc<AiProviderFactory>) -> Self { Self { factory } }

    pub async fn dispatch(
        &self, request: &AiRequest, model_names: Option<Vec<String>>, timeout: Duration,
    ) -> AiDispatchResult {
        let models = model_names.unwrap_or_else(|| {
            self.factory.all().iter().map(|p| p.provider_name().to_string()).collect()
        });
        let results = Arc::new(Mutex::new(Vec::new()));
        let start = Instant::now();

        let mut handles = vec![];
        for model in &models {
            let factory = self.factory.clone();
            let results = results.clone();
            let request = request.clone();
            let model = model.clone();
            let timeout = timeout;

            handles.push(tokio::spawn(async move {
                match tokio::time::timeout(timeout, async {
                    if let Ok(provider) = factory.resolve(Some(&model)) {
                        let response = provider.execute(&request).await;
                        if response.success {
                            let score = Self::default_score(&response);
                            results.lock().await.push(AiScoredResult { model_name: model, response, score });
                        }
                    }
                }).await {
                    Ok(_) => {}
                    Err(_) => {} // timeout — skip
                }
            }));
        }

        for h in handles { let _ = h.await; }
        let elapsed = start.elapsed().as_millis() as u64;

        let mut sorted = results.lock().await.clone();
        sorted.retain(|r| r.response.success);
        sorted.sort_by(|a, b| b.score.partial_cmp(&a.score).unwrap_or(std::cmp::Ordering::Equal));

        AiDispatchResult {
            trace_id: request.trace_id.clone(),
            best_result: sorted.first().cloned(),
            models_succeeded: sorted.len(),
            all_results: sorted,
            total_duration_ms: elapsed,
            models_queried: models.len(),
        }
    }

    fn default_score(response: &AiResponse) -> f64 {
        let mut score = 0.0;
        let len = response.content.len();
        if len > 100 { score += 30.0; }
        if len > 500 { score += 20.0; }
        if response.content.contains("```") { score += 15.0; }
        if response.duration_ms < 10000 { score += 15.0; }
        if response.duration_ms < 5000 { score += 10.0; }
        score.min(100.0)
    }
}

// ─── Prompt Context Builder ────────────────────────────
pub struct PromptContextBuilder {
    sections: Vec<String>,
}

impl PromptContextBuilder {
    pub fn new() -> Self { Self { sections: vec![] } }

    pub fn add_previous_step(&mut self, step_id: &str, output: &str) -> &mut Self {
        let truncated = if output.len() > 2000 { &output[..2000] } else { output };
        self.sections.push(format!("### Previous Step ({}):\n{}", step_id, truncated));
        self
    }

    pub fn add_feedback(&mut self, feedback: &[(String, String)]) -> &mut Self {
        let positive: Vec<_> = feedback.iter().filter(|(r, _)| r == "positive").take(3).collect();
        let negative: Vec<_> = feedback.iter().filter(|(r, _)| r == "negative").take(3).collect();
        if !positive.is_empty() {
            self.sections.push(format!("### What worked well:\n{}", positive.iter().map(|(_, t)| format!("- {}", t)).collect::<Vec<_>>().join("\n")));
        }
        if !negative.is_empty() {
            self.sections.push(format!("### What to avoid:\n{}", negative.iter().map(|(_, t)| format!("- {}", t)).collect::<Vec<_>>().join("\n")));
        }
        self
    }

    pub fn add_section(&mut self, title: &str, content: &str) -> &mut Self {
        self.sections.push(format!("### {}:\n{}", title, content));
        self
    }

    pub fn build(&self) -> String {
        if self.sections.is_empty() { String::new() }
        else { format!("## Context\n\n{}\n\n---\n\n", self.sections.join("\n\n")) }
    }
}
