# Skill 07: AI Dispatcher — Python 3.12+ / asyncio
# Fan-out to N AI models, score, select best
from dataclasses import dataclass, field
from typing import Optional, Callable
import asyncio, time
from ai_providers import AiProviderFactory, AiRequest, AiResponse

@dataclass
class AiScoredResult:
    model_name: str
    response: AiResponse
    score: float

@dataclass
class AiDispatchResult:
    trace_id: str = ""
    step_id: str = ""
    best_result: Optional[AiScoredResult] = None
    all_results: list[AiScoredResult] = field(default_factory=list)
    total_duration_ms: float = 0
    models_queried: int = 0
    models_succeeded: int = 0

class AiDispatcher:
    def __init__(self, factory: AiProviderFactory, scorer: Optional[Callable] = None):
        self.factory = factory
        self.scorer = scorer

    async def dispatch(self, request: AiRequest, model_names: list[str] | None = None,
                       timeout: float = 60.0) -> AiDispatchResult:
        models = model_names or self.factory.registered_names
        results: list[AiScoredResult] = []
        start = time.monotonic()

        async def call_model(model: str):
            try:
                provider = self.factory.resolve(model)
                response = await asyncio.wait_for(provider.execute(request), timeout=timeout)
                if response.success:
                    score = self.scorer(response, request) if self.scorer else self._default_score(response)
                    results.append(AiScoredResult(model_name=model, response=response, score=score))
            except (asyncio.TimeoutError, Exception):
                pass  # skip failed model

        await asyncio.gather(*[call_model(m) for m in models])
        elapsed = (time.monotonic() - start) * 1000

        sorted_results = sorted([r for r in results if r.response.success], key=lambda r: r.score, reverse=True)
        return AiDispatchResult(
            trace_id=request.trace_id, step_id=request.step_id,
            best_result=sorted_results[0] if sorted_results else None,
            all_results=sorted_results, total_duration_ms=elapsed,
            models_queried=len(models), models_succeeded=len(sorted_results),
        )

    @staticmethod
    def _default_score(response: AiResponse) -> float:
        score = 0.0
        length = len(response.content) if response.content else 0
        if length > 100: score += 30
        if length > 500: score += 20
        if "```" in (response.content or ""): score += 15
        if response.duration_ms < 10000: score += 15
        if response.duration_ms < 5000: score += 10
        return min(100, score)

# ─── Prompt Context Builder (Genie DNA: feedback loop) ──
class PromptContextBuilder:
    def __init__(self):
        self._sections: list[str] = []

    def add_previous_step(self, step_id: str, output: str) -> "PromptContextBuilder":
        self._sections.append(f"### Previous Step ({step_id}):\n{output[:2000]}")
        return self

    def add_feedback(self, feedback: list[dict]) -> "PromptContextBuilder":
        positive = [f for f in feedback if f.get("rating") == "positive"][:3]
        negative = [f for f in feedback if f.get("rating") == "negative"][:3]
        if positive: self._sections.append("### What worked well:\n" + "\n".join(f"- {f['text']}" for f in positive))
        if negative: self._sections.append("### What to avoid:\n" + "\n".join(f"- {f['text']}" for f in negative))
        return self

    def add_section(self, title: str, content: str) -> "PromptContextBuilder":
        self._sections.append(f"### {title}:\n{content}")
        return self

    def build(self) -> str:
        return f"## Context\n\n{'\\n\\n'.join(self._sections)}\n\n---\n\n" if self._sections else ""
