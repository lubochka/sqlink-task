// Skill 07: AI Dispatcher — Java 21+ / CompletableFuture
// Fan-out to N AI models, score, select best
package com.xiigen.ai.dispatch;

import com.xiigen.ai.providers.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Collectors;

public record AiScoredResult(String modelName, AiResponse response, double score) {}

public record AiDispatchResult(
    String traceId, String stepId, AiScoredResult bestResult, List<AiScoredResult> allResults,
    long totalDurationMs, int modelsQueried, int modelsSucceeded
) {}

public class AiDispatcher {
    private final AiProviderFactory factory;
    private final ResponseScorer scorer;

    public AiDispatcher(AiProviderFactory factory) { this(factory, null); }
    public AiDispatcher(AiProviderFactory factory, ResponseScorer scorer) { this.factory = factory; this.scorer = scorer; }

    public AiDispatchResult dispatch(AiRequest request, List<String> modelNames, long timeoutMs) {
        var models = modelNames != null ? modelNames : new ArrayList<>(factory.getRegisteredNames());
        var results = new CopyOnWriteArrayList<AiScoredResult>();
        long start = System.currentTimeMillis();

        var executor = Executors.newVirtualThreadPerTaskExecutor();
        var futures = models.stream().map(model -> CompletableFuture.runAsync(() -> {
            try {
                var provider = factory.resolve(model);
                var response = provider.execute(request);
                if (response.success()) {
                    double score = scorer != null ? scorer.score(response, request) : defaultScore(response);
                    results.add(new AiScoredResult(model, response, score));
                }
            } catch (Exception ignored) {}
        }, executor)).toList();

        try { CompletableFuture.allOf(futures.toArray(CompletableFuture[]::new)).get(timeoutMs, TimeUnit.MILLISECONDS); }
        catch (Exception ignored) {}

        var sorted = results.stream().filter(r -> r.response().success())
            .sorted(Comparator.comparingDouble(AiScoredResult::score).reversed()).toList();
        long elapsed = System.currentTimeMillis() - start;

        return new AiDispatchResult(request.traceId(), null, sorted.isEmpty() ? null : sorted.getFirst(),
            sorted, elapsed, models.size(), sorted.size());
    }

    public AiDispatchResult dispatch(AiRequest request) { return dispatch(request, null, 60000); }

    private double defaultScore(AiResponse response) {
        double score = 0;
        int len = response.content() != null ? response.content().length() : 0;
        if (len > 100) score += 30;
        if (len > 500) score += 20;
        if (response.content() != null && response.content().contains("```")) score += 15;
        if (response.durationMs() < 10000) score += 15;
        if (response.durationMs() < 5000) score += 10;
        return Math.min(100, score);
    }

    @FunctionalInterface
    public interface ResponseScorer { double score(AiResponse response, AiRequest request); }
}

// ─── Prompt Context Builder (Genie DNA: feedback loop) ──
public class PromptContextBuilder {
    private final List<String> sections = new ArrayList<>();

    public PromptContextBuilder addPreviousStep(String stepId, String output) {
        sections.add("### Previous Step (%s):\n%s".formatted(stepId, output.length() > 2000 ? output.substring(0, 2000) : output));
        return this;
    }

    public PromptContextBuilder addFeedback(List<Map<String, String>> feedback) {
        var positive = feedback.stream().filter(f -> "positive".equals(f.get("rating"))).limit(3).toList();
        var negative = feedback.stream().filter(f -> "negative".equals(f.get("rating"))).limit(3).toList();
        if (!positive.isEmpty()) sections.add("### What worked well:\n" + positive.stream().map(f -> "- " + f.get("text")).collect(Collectors.joining("\n")));
        if (!negative.isEmpty()) sections.add("### What to avoid:\n" + negative.stream().map(f -> "- " + f.get("text")).collect(Collectors.joining("\n")));
        return this;
    }

    public PromptContextBuilder addSection(String title, String content) { sections.add("### %s:\n%s".formatted(title, content)); return this; }

    public String build() { return sections.isEmpty() ? "" : "## Context\n\n" + String.join("\n\n", sections) + "\n\n---\n\n"; }
}
