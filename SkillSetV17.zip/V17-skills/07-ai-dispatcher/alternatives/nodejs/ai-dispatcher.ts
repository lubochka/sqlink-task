// Skill 07: AI Dispatcher — Node.js/TypeScript
// Fan-out to N AI models, score, select best
// Same interface as .NET AiDispatcher — see SKILL.md
import { IAiProvider, AiProviderFactory, AiRequest, AiResponse } from "./ai-providers";

export interface AiScoredResult { modelName: string; response: AiResponse; score: number; }

export interface AiDispatchResult {
  traceId?: string; stepId?: string;
  bestResult?: AiScoredResult; allResults: AiScoredResult[];
  totalDurationMs: number; modelsQueried: number; modelsSucceeded: number;
}

export type DispatchStrategy = "BestOf" | "FirstSuccess" | "Fallback";

export class AiDispatcher {
  constructor(private factory: AiProviderFactory, private scorer?: IResponseScorer) {}

  async dispatch(
    request: AiRequest,
    modelNames?: string[],
    timeout = 60000,
    strategy: DispatchStrategy = "BestOf"
  ): Promise<AiDispatchResult> {
    const models = modelNames ?? this.factory.registeredNames;
    const results: AiScoredResult[] = [];
    const start = Date.now();

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);

    const tasks = models.map(async (model) => {
      try {
        const provider = this.factory.resolve(model);
        const response = await provider.execute({ ...request, model });
        if (response.success) {
          const score = this.scorer?.score(response, request) ?? this.defaultScore(response);
          results.push({ modelName: model, response, score });
          if (strategy === "FirstSuccess") controller.abort(); // short-circuit
        }
      } catch { /* timeout or error — skip model */ }
    });

    try { await Promise.allSettled(tasks); } finally { clearTimeout(timer); }

    const sorted = results.filter(r => r.response.success).sort((a, b) => b.score - a.score);
    return {
      traceId: request.traceId, stepId: request.stepId,
      bestResult: sorted[0], allResults: sorted,
      totalDurationMs: Date.now() - start, modelsQueried: models.length, modelsSucceeded: sorted.length,
    };
  }

  private defaultScore(response: AiResponse): number {
    let score = 0;
    const len = response.content?.length ?? 0;
    if (len > 100) score += 30;
    if (len > 500) score += 20;
    if (response.content?.includes("```")) score += 15;
    if ((response.duration ?? 999999) < 10000) score += 15;
    if ((response.duration ?? 999999) < 5000) score += 10;
    return Math.min(100, score);
  }
}

// ─── Scoring Interface ─────────────────────────────────
export interface IResponseScorer {
  score(response: AiResponse, request: AiRequest): number;
}

// ─── Prompt Context Builder (Genie DNA: feedback loop) ──
export class PromptContextBuilder {
  private sections: string[] = [];

  addPreviousStepOutput(stepId: string, output: string): this {
    this.sections.push(`### Previous Step (${stepId}):\n${output.slice(0, 2000)}`);
    return this;
  }

  addFeedback(feedback: { rating: string; text: string }[]): this {
    const positive = feedback.filter(f => f.rating === "positive").slice(0, 3);
    const negative = feedback.filter(f => f.rating === "negative").slice(0, 3);
    if (positive.length) this.sections.push(`### What worked well:\n${positive.map(f => `- ${f.text}`).join("\n")}`);
    if (negative.length) this.sections.push(`### What to avoid:\n${negative.map(f => `- ${f.text}`).join("\n")}`);
    return this;
  }

  addSection(title: string, content: string): this {
    this.sections.push(`### ${title}:\n${content}`);
    return this;
  }

  build(): string {
    return this.sections.length > 0 ? `## Context\n\n${this.sections.join("\n\n")}\n\n---\n\n` : "";
  }
}
