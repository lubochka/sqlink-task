<?php
// Skill 07: AI Dispatcher — PHP 8.3 / Fiber (parallel via amp/parallel or Guzzle promises)
// Fan-out to N AI models, score, select best
declare(strict_types=1);
namespace XIIGen\AI\Dispatch;

use XIIGen\AI\Providers\{AiProviderFactory, AiRequest, AiResponse, IAiProvider};

final class AiScoredResult {
    public function __construct(
        public readonly string $modelName,
        public readonly AiResponse $response,
        public readonly float $score,
    ) {}
}

final class AiDispatchResult {
    public function __construct(
        public readonly string $traceId = '',
        public readonly ?AiScoredResult $bestResult = null,
        /** @var AiScoredResult[] */
        public readonly array $allResults = [],
        public readonly float $totalDurationMs = 0,
        public readonly int $modelsQueried = 0,
        public readonly int $modelsSucceeded = 0,
    ) {}
}

final class AiDispatcher
{
    public function __construct(
        private readonly AiProviderFactory $factory,
        private readonly ?\Closure $scorer = null,
    ) {}

    /**
     * @param string[]|null $modelNames
     */
    public function dispatch(AiRequest $request, ?array $modelNames = null, float $timeoutSec = 60.0): AiDispatchResult
    {
        $models = $modelNames ?? $this->factory->getRegisteredNames();
        $results = [];
        $start = microtime(true);

        // PHP dispatch: sequential (use amp/parallel or Guzzle promises for true parallelism)
        foreach ($models as $model) {
            try {
                $provider = $this->factory->resolve($model);
                $response = $provider->execute($request);
                if ($response->success) {
                    $score = $this->scorer ? ($this->scorer)($response, $request) : $this->defaultScore($response);
                    $results[] = new AiScoredResult($model, $response, $score);
                }
            } catch (\Throwable) { /* skip failed model */ }
        }

        usort($results, fn(AiScoredResult $a, AiScoredResult $b) => $b->score <=> $a->score);
        $successful = array_filter($results, fn(AiScoredResult $r) => $r->response->success);
        $elapsed = (microtime(true) - $start) * 1000;

        return new AiDispatchResult(
            traceId: $request->requestId,
            bestResult: $results[0] ?? null,
            allResults: array_values($successful),
            totalDurationMs: $elapsed,
            modelsQueried: count($models),
            modelsSucceeded: count($successful),
        );
    }

    private function defaultScore(AiResponse $response): float
    {
        $score = 0.0;
        $len = strlen($response->content);
        if ($len > 100) $score += 30;
        if ($len > 500) $score += 20;
        if (str_contains($response->content, '```')) $score += 15;
        if ($response->durationMs < 10000) $score += 15;
        if ($response->durationMs < 5000) $score += 10;
        return min(100.0, $score);
    }
}

// ─── Prompt Context Builder (Genie DNA: feedback loop) ──
final class PromptContextBuilder
{
    /** @var string[] */
    private array $sections = [];

    public function addPreviousStep(string $stepId, string $output): self
    {
        $this->sections[] = "### Previous Step ($stepId):\n" . mb_substr($output, 0, 2000);
        return $this;
    }

    public function addFeedback(array $feedback): self
    {
        $positive = array_filter($feedback, fn($f) => ($f['rating'] ?? '') === 'positive');
        $negative = array_filter($feedback, fn($f) => ($f['rating'] ?? '') === 'negative');
        if ($positive) $this->sections[] = "### What worked well:\n" . implode("\n", array_map(fn($f) => "- {$f['text']}", array_slice($positive, 0, 3)));
        if ($negative) $this->sections[] = "### What to avoid:\n" . implode("\n", array_map(fn($f) => "- {$f['text']}", array_slice($negative, 0, 3)));
        return $this;
    }

    public function addSection(string $title, string $content): self
    {
        $this->sections[] = "### $title:\n$content";
        return $this;
    }

    public function build(): string
    {
        return empty($this->sections) ? '' : "## Context\n\n" . implode("\n\n", $this->sections) . "\n\n---\n\n";
    }
}
