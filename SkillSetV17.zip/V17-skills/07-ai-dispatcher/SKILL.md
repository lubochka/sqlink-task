---
name: ai-dispatcher
description: Fan-out prompts to N AI models in parallel, score responses, select best or generate consensus. Supports timeout, fallback, and weighted voting.
triggers: dispatch ai, multi-model, parallel ai, consensus, fan-out, best-of-n, ai voting
dependencies: [01-core-interfaces, 04-redis-queue-service, 06-ai-providers]
layer: L3-AI
genie-dna: Returns DataProcessResult via AiDispatchResult. Uses PromptContextBuilder for feedback injection (Genie DNA feedback loop).
---

# Skill 07: AI Dispatcher
## Fan-out to N Models, Score, Select Best

**Dependencies:** 01-core-interfaces, 04-redis-queue, 06-ai-providers
**Layer:** L3: AI
**Existing .NET:** AiDispatcher.cs (4.6KB — includes scoring + PromptContextBuilder)

---

## Overview

AI Dispatcher is the **multi-model orchestrator** within a single flow step. When a pipeline node needs AI generation, it doesn't call one model — it dispatches the same prompt to N models in parallel, scores each response, and selects the best one (or generates a consensus hybrid).

This is critical for XIIGen's quality assurance: by running Claude, GPT, and Gemini on the same task and scoring the results, the system consistently gets better output than any single model alone.

## When to Use

- In any flow step that generates code, content, or analysis via AI
- When quality matters more than speed (multi-model consensus)
- When you need fallback resilience (if one model fails, others still succeed)
- For A/B testing different models on the same prompt

## Dispatch Strategies

| Strategy | Description | Speed | Quality |
|---|---|---|---|
| **BestOf** | Send to all, pick highest score | Slowest | Highest |
| **FirstSuccess** | Send to all, return first successful | Fastest | Medium |
| **Consensus** | Send to all, merge common patterns | Medium | Highest |
| **Fallback** | Send to primary, if fail try secondary | Fast | Medium |
| **Weighted** | Score with model-specific weights | Slowest | Custom |

## Architecture

```
AiRequest ──→ AiDispatcher
                 ├──→ Claude   ──→ score: 85
                 ├──→ GPT-4o   ──→ score: 72    → Select best (85)
                 └──→ Gemini   ──→ score: 68    → Return winner
```

## API Reference

### AiDispatcher

```csharp
var dispatcher = new AiDispatcher(providerFactory);

// Dispatch to all registered providers
var result = await dispatcher.DispatchAsync(request, timeout: TimeSpan.FromSeconds(60));
// result.BestResult — highest scoring response
// result.AllResults — all responses sorted by score
// result.ModelsQueried / ModelsSucceeded — stats

// Dispatch to specific models only
var result = await dispatcher.DispatchAsync(request, modelNames: ["claude", "openai"]);
```

### Scoring Rubric

Default scoring (0-100):
- Content length > 100 chars: +30
- Content length > 500 chars: +20
- Contains code blocks (triple backtick): +15
- Response time < 10s: +15
- Response time < 5s: +10
- Token efficiency bonus: +10

Custom scoring can be provided via `IResponseScorer` interface.

### PromptContextBuilder

Builds context section injected before the user prompt:
```csharp
var context = new PromptContextBuilder()
    .AddPreviousStepOutput("parse", parsedFigma)
    .AddFeedback(feedbackEntries)     // Genie DNA: feedback → AI loop
    .AddSection("Design System", themeJson)
    .Build();

var request = new AiRequest {
    SystemPrompt = systemPrompt,
    UserPrompt = context + userPrompt  // Context prepended
};
```

## Configuration

```json
{
  "AiDispatcher": {
    "DefaultTimeout": 60,
    "DefaultStrategy": "BestOf",
    "ScoreWeights": { "Claude": 1.1, "OpenAI": 1.0, "Gemini": 0.9 }
  }
}
```

## DI Registration

```csharp
services.AddXIIGenAiDispatcher(config); // Requires AiProviderFactory already registered
```

## Test Scenarios

1. Dispatch to 3 models, verify best is selected correctly
2. One model times out, verify others still return
3. All models fail, verify graceful error result
4. Custom scorer overrides default scoring
5. PromptContextBuilder correctly injects feedback sections
6. Verify concurrent dispatch doesn't cause race conditions
