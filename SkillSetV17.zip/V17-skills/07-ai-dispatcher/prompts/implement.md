# Skill 07: AI Dispatcher — Implementation Prompts

## Step 1: Create AiDispatcher Class
```
Create AiDispatcher that takes AiProviderFactory in constructor.
Method: DispatchAsync(AiRequest, modelNames?, timeout?, strategy?)
Fan out request to all specified models in parallel using Task.WhenAll.
Collect results in ConcurrentBag<AiScoredResult>.
Support CancellationToken with linked timeout.
```

## Step 2: Implement Scoring
```
Create default scoring (0-100): content length, code blocks, response time, token efficiency.
Allow custom IResponseScorer interface injection.
Sort results by score descending, return AiDispatchResult with BestResult + AllResults.
```

## Step 3: Implement Dispatch Strategies
```
BestOf: Run all models, return highest score (default).
FirstSuccess: Run all, return first successful (cancel others).
Fallback: Try primary model first, if fail try secondary list.
Weighted: Apply model-specific multipliers to scores (e.g., Claude x1.1).
```

## Step 4: Create PromptContextBuilder
```
Builder pattern that assembles context sections:
- AddPreviousStepOutput(stepId, output) — truncated to 2000 chars
- AddFeedback(entries) — positive/negative sections with max 3 items each
- AddSection(title, content) — arbitrary context section
- Build() — returns "## Context\n\n{sections}\n\n---\n\n"
Prepend this to the user prompt before dispatching.
```

## Step 5: DI Registration
```
services.AddXIIGenAiDispatcher(config) — registers AiDispatcher as singleton.
Requires AiProviderFactory already registered (from skill 06).
Reads config: AiDispatcher:DefaultTimeout, AiDispatcher:DefaultStrategy.
```


---

## Genie DNA Compliance — MANDATORY for All Implementations

> Before writing ANY code, classify each component:
> **MACHINE** (static): Infrastructure that enables freedom. Build once, generic, interface-based.
> **FREEDOM** (dynamic): Anything users define. No fixed models, config-driven.

### DNA Checklist — Every Implementation MUST:
☐ **DNA-1 (Dynamic Documents):** Store data as `Dictionary<string, object>` / `Record<string, any>` — NOT typed model classes. User fields preserved without schema changes.
☐ **DNA-2 (BuildSearchFilter):** All queries use BuildSearchFilter/equivalent. Empty fields auto-skipped. No entity-specific query code.
☐ **DNA-3 (MicroserviceBase):** Inherit base class with DB, queue, cache, logger built in.
☐ **DNA-5 (DataProcessResult):** All public methods return `DataProcessResult<T>`. Errors return failure, not throw exceptions.
☐ **DNA-6 (Generic Interfaces):** External dependencies behind interfaces. Swap via config.
☐ **DNA-SCOPE:** Non-admin queries auto-inject userId filter. Cannot be bypassed.

### The Three Tests:
1. Can a business user change this without a developer? (YES = correct)
2. Does it work for entity types that do not exist yet? (YES = correct)
3. Can I swap the database/service/UI without changing this? (YES = correct)
