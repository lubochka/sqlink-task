// XIIGen Chat Service — Java | Skill 42
package com.xiigen.chat;
import com.xiigen.core.*;
import java.time.Instant;
import java.util.*;

public class ChatService extends MicroserviceBase {
    public ChatService(IDatabaseService db, IQueueService queue) { super(db, queue, "chat-service"); }

    public DataProcessResult<Map<String, Object>> createSession(List<String> participants, String title) throws Exception {
        String sid = UUID.randomUUID().toString();
        Map<String, Integer> unread = new HashMap<>(); participants.forEach(p -> unread.put(p, 0));
        var session = new HashMap<>(Map.of("sessionId", sid, "participants", participants, "title", title != null ? title : "", "unreadCounts", unread, "isClosed", false));
        storeDocument("chat-sessions", sid, session);
        return DataProcessResult.success(session);
    }

    public DataProcessResult<Map<String, Object>> sendMessage(String sessionId, String fromUserId, String content, String contentType) throws Exception {
        String mid = UUID.randomUUID().toString();
        var msg = Map.of("messageId", mid, "sessionId", sessionId, "fromUserId", fromUserId, "content", content, "contentType", contentType != null ? contentType : "text", "status", "sent", "sentAt", Instant.now().toString());
        storeDocument("chat-messages", mid, msg);
        publishEvent("chat.message.sent", Map.of("sessionId", sessionId, "messageId", mid));
        return DataProcessResult.success(msg);
    }

    public DataProcessResult<List<Object>> getMessages(String sessionId, int limit) throws Exception {
        var result = searchDocuments("chat-messages", Map.of("sessionId", sessionId), limit);
        return DataProcessResult.success(result.isSuccess() ? result.getData() : List.of());
    }
}
