// XIIGen Chat Service — Node.js/TypeScript | Skill 42
import { IDatabaseService, IQueueService, DataProcessResult, MicroserviceBase } from '../../01-core-interfaces';
import { randomUUID } from 'crypto';

interface ChatSession { sessionId: string; participants: string[]; title?: string; lastMessagePreview?: string; lastMessageAt?: Date; unreadCounts: Record<string, number>; isClosed: boolean; }
interface ChatMessage { messageId: string; sessionId: string; fromUserId: string; toUserId?: string; content: string; contentType: string; status: string; sentAt: Date; }

export class ChatService extends MicroserviceBase {
  protected serviceName = 'chat-service';
  constructor(db: IDatabaseService, queue: IQueueService) { super(db, queue); }

  async createSession(participants: string[], title?: string): Promise<DataProcessResult<ChatSession>> {
    const session: ChatSession = { sessionId: randomUUID(), participants, title, unreadCounts: {}, isClosed: false };
    participants.forEach(p => session.unreadCounts[p] = 0);
    await this.storeDocument('chat-sessions', session.sessionId, session);
    return DataProcessResult.success(session);
  }

  async sendMessage(sessionId: string, fromUserId: string, content: string, contentType = 'text'): Promise<DataProcessResult<ChatMessage>> {
    const msg: ChatMessage = { messageId: randomUUID(), sessionId, fromUserId, content, contentType, status: 'sent', sentAt: new Date() };
    await this.storeDocument('chat-messages', msg.messageId, msg);
    // Update session preview
    const session = await this.getDocument('chat-sessions', sessionId) as any;
    if (session) {
      session.lastMessagePreview = content.substring(0, 100);
      session.lastMessageAt = new Date();
      session.participants.filter((p: string) => p !== fromUserId).forEach((p: string) => session.unreadCounts[p] = (session.unreadCounts[p] || 0) + 1);
      await this.storeDocument('chat-sessions', sessionId, session);
    }
    await this.publishEvent('chat.message.sent', { sessionId, messageId: msg.messageId, fromUserId });
    return DataProcessResult.success(msg);
  }

  async getMessages(sessionId: string, limit = 50): Promise<DataProcessResult<ChatMessage[]>> {
    const result = await this.searchDocuments('chat-messages', { sessionId }, limit);
    return DataProcessResult.success(result.isSuccess ? (result.data as ChatMessage[]) || [] : []);
  }

  async markRead(sessionId: string, userId: string): Promise<DataProcessResult<boolean>> {
    const session = await this.getDocument('chat-sessions', sessionId) as any;
    if (session) { session.unreadCounts[userId] = 0; await this.storeDocument('chat-sessions', sessionId, session); }
    return DataProcessResult.success(true);
  }

  async getUserSessions(userId: string): Promise<DataProcessResult<any[]>> {
    const result = await this.searchDocuments('chat-sessions', { participants: userId }, 50);
    return DataProcessResult.success(result.isSuccess ? result.data || [] : []);
  }
}
