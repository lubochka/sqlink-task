# XIIGen Chat Service — Python | Skill 42
import uuid
from datetime import datetime, timezone
from core_interfaces import IDatabaseService, IQueueService, DataProcessResult, MicroserviceBase

class ChatService(MicroserviceBase):
    service_name = "chat-service"
    def __init__(self, db: IDatabaseService, queue: IQueueService): super().__init__(db, queue)

    async def create_session(self, participants: list[str], title: str = None) -> DataProcessResult:
        session = {"sessionId": str(uuid.uuid4()), "participants": participants, "title": title, "unreadCounts": {p: 0 for p in participants}, "isClosed": False, "createdAt": datetime.now(timezone.utc).isoformat()}
        await self.store_document("chat-sessions", session["sessionId"], session)
        return DataProcessResult.success(session)

    async def send_message(self, session_id: str, from_user: str, content: str, content_type: str = "text") -> DataProcessResult:
        msg = {"messageId": str(uuid.uuid4()), "sessionId": session_id, "fromUserId": from_user, "content": content, "contentType": content_type, "status": "sent", "sentAt": datetime.now(timezone.utc).isoformat()}
        await self.store_document("chat-messages", msg["messageId"], msg)
        session = await self.get_document("chat-sessions", session_id)
        if session:
            session["lastMessagePreview"] = content[:100]
            for p in session.get("participants", []):
                if p != from_user: session["unreadCounts"][p] = session["unreadCounts"].get(p, 0) + 1
            await self.store_document("chat-sessions", session_id, session)
        await self.publish_event("chat.message.sent", {"sessionId": session_id, "messageId": msg["messageId"]})
        return DataProcessResult.success(msg)

    async def get_messages(self, session_id: str, limit: int = 50) -> DataProcessResult:
        result = await self.search_documents("chat-messages", {"sessionId": session_id}, limit)
        return DataProcessResult.success(result.data if result.is_success else [])

    async def mark_read(self, session_id: str, user_id: str) -> DataProcessResult:
        session = await self.get_document("chat-sessions", session_id)
        if session: session["unreadCounts"][user_id] = 0; await self.store_document("chat-sessions", session_id, session)
        return DataProcessResult.success(True)
