<?php
// XIIGen Chat Service — PHP | Skill 42
namespace XIIGen\Chat;
use XIIGen\Core\{MicroserviceBase, DataProcessResult, IDatabaseService, IQueueService};

class ChatService extends MicroserviceBase {
    protected string $serviceName = 'chat-service';
    public function __construct(IDatabaseService $db, IQueueService $queue) { parent::__construct($db, $queue); }

    public function createSession(array $participants, ?string $title = null): DataProcessResult {
        $sid = \Ramsey\Uuid\Uuid::uuid4()->toString();
        $unread = array_fill_keys($participants, 0);
        $session = ['sessionId' => $sid, 'participants' => $participants, 'title' => $title, 'unreadCounts' => $unread, 'isClosed' => false];
        $this->storeDocument('chat-sessions', $sid, $session);
        return DataProcessResult::success($session);
    }

    public function sendMessage(string $sessionId, string $fromUserId, string $content, string $contentType = 'text'): DataProcessResult {
        $mid = \Ramsey\Uuid\Uuid::uuid4()->toString();
        $msg = ['messageId' => $mid, 'sessionId' => $sessionId, 'fromUserId' => $fromUserId, 'content' => $content, 'contentType' => $contentType, 'status' => 'sent', 'sentAt' => date('c')];
        $this->storeDocument('chat-messages', $mid, $msg);
        $this->publishEvent('chat.message.sent', ['sessionId' => $sessionId, 'messageId' => $mid]);
        return DataProcessResult::success($msg);
    }

    public function getMessages(string $sessionId, int $limit = 50): DataProcessResult {
        $result = $this->searchDocuments('chat-messages', ['sessionId' => $sessionId], $limit);
        return DataProcessResult::success($result->isSuccess ? ($result->data ?? []) : []);
    }
}
