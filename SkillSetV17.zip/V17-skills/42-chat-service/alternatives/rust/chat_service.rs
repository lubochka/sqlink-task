// XIIGen Chat Service — Rust | Skill 42
use serde_json::{json, Value};
use uuid::Uuid;
use chrono::Utc;
use crate::core::{DataProcessResult, IDatabaseService, IQueueService, MicroserviceBase};

pub struct ChatService { base: MicroserviceBase }

impl ChatService {
    pub fn new(db: Box<dyn IDatabaseService>, queue: Box<dyn IQueueService>) -> Self {
        Self { base: MicroserviceBase::new(db, queue, "chat-service") }
    }

    pub async fn create_session(&self, participants: &[String], title: Option<&str>) -> DataProcessResult<Value> {
        let sid = Uuid::new_v4().to_string();
        let session = json!({"sessionId": sid, "participants": participants, "title": title, "isClosed": false, "createdAt": Utc::now().to_rfc3339()});
        self.base.store_document("chat-sessions", &sid, &session).await;
        DataProcessResult::success(session)
    }

    pub async fn send_message(&self, session_id: &str, from_user: &str, content: &str, content_type: Option<&str>) -> DataProcessResult<Value> {
        let mid = Uuid::new_v4().to_string();
        let msg = json!({"messageId": mid, "sessionId": session_id, "fromUserId": from_user, "content": content, "contentType": content_type.unwrap_or("text"), "status": "sent", "sentAt": Utc::now().to_rfc3339()});
        self.base.store_document("chat-messages", &mid, &msg).await;
        self.base.publish_event("chat.message.sent", &json!({"sessionId": session_id, "messageId": mid})).await;
        DataProcessResult::success(msg)
    }

    pub async fn get_messages(&self, session_id: &str, limit: usize) -> DataProcessResult<Vec<Value>> {
        let result = self.base.search_documents("chat-messages", &json!({"sessionId": session_id}), limit).await;
        DataProcessResult::success(if result.is_success { result.data } else { vec![] })
    }
}
