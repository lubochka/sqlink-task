---
skill_id: "42"
name: chat-service
title: "Chat Service"
layer: "L8: Specialty"
version: "17.0"
status: "active"
dependencies:
  - "01-core-interfaces"
  - "02-object-processor"
  - "03-elasticsearch-datastore"
  - "04-redis-queue-service"
  - "20-auth-service"
  - "21-permissions-service"
  - "24-notification-service"
dotnet_namespace: "XIIGen.Services.Chat"
di_registration: "services.AddXIIGenChatService()"
es_index: "xiigen-chat"
genie_dna:
  - "DNA-1: Messages and sessions as dynamic documents (support any attachment types)"
  - "DNA-2: BuildSearchFilter for message search (sessionId, sender, content — skip empty)"
  - "DNA-3: Inherits MicroserviceBase"
  - "DNA-5: DataProcessResult for all operations"
  - "DNA-7: Message events → real-time delivery via SignalR/WebSocket (Observer pattern)"
  - "DNA-SCOPE: Users only see sessions they're participants in"
  - "DNA-MEDIATOR: Chat hub mediates between participants (Mediator pattern from V6)"
triggers: chat, messaging, real-time, WebSocket, SignalR, session, conversation, direct message
---

# Skill 42: Chat Service
## Entity-to-Entity Messaging — The Mediator Pattern

**Classification: HYBRID — MACHINE message delivery, FREEDOM message content**

From Architecture.docx: "Chat — entity-to-entity messaging with sessions."

---

## Genie DNA Integration

### Messages as Dynamic Documents (DNA-1)
Messages support ANY content type without schema changes:
```json
{
  "sessionId": "session_abc",
  "senderId": "user_123",
  "content": "Here's the invoice",
  "attachments": [
    { "type": "file", "url": "/files/invoice.pdf", "size": 245000 },
    { "type": "image", "url": "/files/receipt.jpg", "thumbnail": "/files/receipt_thumb.jpg" }
  ],
  "metadata": { "replyTo": "msg_456", "mentions": ["user_789"] },
  "timestamp": "2026-02-08T14:30:00Z"
}
```
New attachment types, reaction types, metadata fields — all added without code changes.

### Scope Isolation (DNA-SCOPE)
Users can ONLY access sessions where they are a participant:
```csharp
// BuildSearchFilter injects: participants CONTAINS userId
// User cannot query sessions they're not part of
```

### Real-Time via Events (DNA-7, Observer Pattern)
```
Message sent → stored in ES → event published to queue
→ NotificationService pushes to WebSocket (SignalR)
→ All session participants receive real-time update
```

## Interface
```csharp
public interface IChatService
{
    Task<DataProcessResult<string>> CreateSessionAsync(Dictionary<string, object> sessionDoc);
    Task<DataProcessResult<string>> SendMessageAsync(
        string sessionId, Dictionary<string, object> messageDoc);
    Task<DataProcessResult<List<Dictionary<string, object>>>> GetMessagesAsync(
        string sessionId, Dictionary<string, object> filter);
    Task<DataProcessResult<int>> GetUnreadCountAsync(string userId, string sessionId);
    Task<DataProcessResult<bool>> MarkReadAsync(string userId, string sessionId);
}
```

## Alternatives
All alternatives MUST: store messages/sessions as dynamic documents, enforce scope isolation, deliver messages via events, return DataProcessResult.
