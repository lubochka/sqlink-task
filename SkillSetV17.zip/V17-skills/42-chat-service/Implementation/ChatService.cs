// XIIGen.Chat/ChatService.cs - Skill 42 | .NET 9
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using XIIGen.Core.Base;
using XIIGen.Core.Enums;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Chat;

// ─── Models ─────────────────────────────────────────
public enum MessageStatus { Sent, Delivered, Read }

public class ChatSession
{
    public string SessionId { get; set; } = Guid.NewGuid().ToString();
    public List<string> Participants { get; set; } = [];        // [from entity, to entity]
    public string? Title { get; set; }
    public string? LastMessagePreview { get; set; }
    public DateTime? LastMessageAt { get; set; }
    public Dictionary<string, int> UnreadCounts { get; set; } = [];   // userId → count
    public Dictionary<string, object> Metadata { get; set; } = [];
    public bool IsClosed { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
}

public class ChatMessage
{
    public string MessageId { get; set; } = Guid.NewGuid().ToString();
    public string SessionId { get; set; } = "";
    public string FromUserId { get; set; } = "";
    public string? ToUserId { get; set; }           // null = broadcast to all participants
    public string Content { get; set; } = "";
    public string ContentType { get; set; } = "text";  // text, image, file, system
    public List<ChatAttachment> Attachments { get; set; } = [];
    public MessageStatus Status { get; set; } = MessageStatus.Sent;
    public DateTime SentAt { get; set; } = DateTime.UtcNow;
    public DateTime? DeliveredAt { get; set; }
    public DateTime? ReadAt { get; set; }
    public Dictionary<string, object> Metadata { get; set; } = [];
}

public class ChatAttachment
{
    public string AttachmentId { get; set; } = Guid.NewGuid().ToString();
    public string FileName { get; set; } = "";
    public string ContentType { get; set; } = "application/octet-stream";
    public long SizeBytes { get; set; }
    public string? Url { get; set; }
    public string? Base64Data { get; set; }
}

// ─── Service ────────────────────────────────────────
public class ChatService : MicroserviceBase
{
    public ChatService(IDatabaseService db, IQueueService queue, ILogger<ChatService> logger, ICacheService cache = null)
        : base(db, queue, logger, cache) { ServiceName = "chat-service"; }

    // ── Sessions ────────────────────────────────────
    public async Task<DataProcessResult<ChatSession>> CreateSessionAsync(
        List<string> participants, string? title = null, CancellationToken ct = default)
    {
        var session = new ChatSession
        {
            Participants = participants,
            Title = title ?? string.Join(", ", participants.Take(3)),
            UnreadCounts = participants.ToDictionary(p => p, _ => 0)
        };
        await StoreDocumentAsync("chat-sessions", session.SessionId, session, ct: ct);
        Logger.LogInformation("Chat session created: {SessionId} with {Count} participants", session.SessionId, participants.Count);
        return DataProcessResult<ChatSession>.Created(session);
    }

    public async Task<DataProcessResult<ChatSession>> GetSessionAsync(string sessionId, CancellationToken ct = default)
    {
        var result = await GetDocumentAsync("chat-sessions", sessionId, ct);
        return result.IsSuccess
            ? DataProcessResult<ChatSession>.Success(result.Data as ChatSession ?? new())
            : DataProcessResult<ChatSession>.Error("Session not found");
    }

    public async Task<DataProcessResult<List<object>>> ListSessionsAsync(string userId, int limit = 20, CancellationToken ct = default)
    {
        return await SearchDocumentsAsync("chat-sessions", new { participants = userId }, limit, ct);
    }

    public async Task<DataProcessResult<bool>> CloseSessionAsync(string sessionId, CancellationToken ct = default)
    {
        var session = await GetSessionAsync(sessionId, ct);
        if (!session.IsSuccess) return DataProcessResult<bool>.Error("Session not found");
        var s = session.Data!;
        s.IsClosed = true;
        s.UpdatedAt = DateTime.UtcNow;
        await StoreDocumentAsync("chat-sessions", s.SessionId, s, ct: ct);
        return DataProcessResult<bool>.Success(true);
    }

    // ── Messages ────────────────────────────────────
    public async Task<DataProcessResult<ChatMessage>> SendMessageAsync(
        string sessionId, string fromUserId, string content,
        string contentType = "text", List<ChatAttachment>? attachments = null,
        CancellationToken ct = default)
    {
        var session = await GetSessionAsync(sessionId, ct);
        if (!session.IsSuccess) return DataProcessResult<ChatMessage>.Error("Session not found");
        if (session.Data!.IsClosed) return DataProcessResult<ChatMessage>.Error("Session is closed");

        var msg = new ChatMessage
        {
            SessionId = sessionId,
            FromUserId = fromUserId,
            Content = content,
            ContentType = contentType,
            Attachments = attachments ?? []
        };

        // Store message
        await StoreDocumentAsync("chat-messages", msg.MessageId, msg, ct: ct);

        // Update session
        var s = session.Data!;
        s.LastMessagePreview = content.Length > 100 ? content[..100] + "…" : content;
        s.LastMessageAt = msg.SentAt;
        s.UpdatedAt = DateTime.UtcNow;
        foreach (var p in s.Participants.Where(p => p != fromUserId))
            s.UnreadCounts[p] = s.UnreadCounts.GetValueOrDefault(p) + 1;
        await StoreDocumentAsync("chat-sessions", s.SessionId, s, ct: ct);

        // Publish to queue for real-time delivery (SignalR/WebSocket consumer)
        await EnqueueAsync("chat-messages", msg, ct);

        Logger.LogInformation("Message sent: {MsgId} in session {SessionId}", msg.MessageId, sessionId);
        return DataProcessResult<ChatMessage>.Created(msg);
    }

    public async Task<DataProcessResult<List<object>>> GetMessagesAsync(
        string sessionId, int limit = 50, int from = 0, CancellationToken ct = default)
    {
        return await SearchDocumentsAsync("chat-messages", new { sessionId }, limit, ct);
    }

    public async Task<DataProcessResult<bool>> MarkAsReadAsync(
        string sessionId, string userId, string? upToMessageId = null, CancellationToken ct = default)
    {
        // Reset unread count
        var session = await GetSessionAsync(sessionId, ct);
        if (!session.IsSuccess) return DataProcessResult<bool>.Error("Session not found");
        session.Data!.UnreadCounts[userId] = 0;
        session.Data!.UpdatedAt = DateTime.UtcNow;
        await StoreDocumentAsync("chat-sessions", session.Data!.SessionId, session.Data!, ct: ct);
        return DataProcessResult<bool>.Success(true);
    }

    public async Task<DataProcessResult<bool>> UpdateMessageStatusAsync(
        string messageId, MessageStatus status, CancellationToken ct = default)
    {
        var result = await GetDocumentAsync("chat-messages", messageId, ct);
        if (!result.IsSuccess) return DataProcessResult<bool>.Error("Message not found");

        // Update status + timestamp
        var msg = result.Data as ChatMessage ?? new();
        msg.Status = status;
        if (status == MessageStatus.Delivered) msg.DeliveredAt = DateTime.UtcNow;
        if (status == MessageStatus.Read) msg.ReadAt = DateTime.UtcNow;
        await StoreDocumentAsync("chat-messages", msg.MessageId, msg, ct: ct);
        return DataProcessResult<bool>.Success(true);
    }

    // ── Search ──────────────────────────────────────
    public async Task<DataProcessResult<List<object>>> SearchMessagesAsync(
        string sessionId, string query, int limit = 20, CancellationToken ct = default)
    {
        return await SearchDocumentsAsync("chat-messages", new { sessionId, content = query }, limit, ct);
    }

    // ── Typing Indicators (via Redis pub/sub) ───────
    public async Task PublishTypingAsync(string sessionId, string userId, CancellationToken ct = default)
    {
        await EnqueueAsync($"chat-typing:{sessionId}", new { userId, timestamp = DateTime.UtcNow }, ct);
    }
}

// ─── DI Extension ───────────────────────────────────
public static class ChatServiceExtensions
{
    public static IServiceCollection AddXIIGenChat(this IServiceCollection services)
    {
        services.AddSingleton<ChatService>();
        return services;
    }
}
