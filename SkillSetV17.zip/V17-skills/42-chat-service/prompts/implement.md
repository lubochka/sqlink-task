# Chat Service — Implementation Prompt | Skill 42
## Phase 1: Sessions
1. CreateSession with participants, title; store as dynamic doc
2. GetUserSessions via BuildSearchFilter on participants array

## Phase 2: Messaging
1. SendMessage: store msg doc + update session preview + increment unread
2. GetMessages by sessionId; MarkRead resets unread counter
3. Events: `chat.message.sent`, `chat.message.read`

## Phase 3: Real-time (WebSocket)
1. SignalR/WebSocket hub for live message delivery
2. Typing indicators, online status
3. Integration with Skill 44 Moderation for content filtering

## Phase 4: Attachments & Testing
1. File/image attachments with base64 or URL storage
2. Message search across sessions
3. **Genie DNA Checklist:** ☐ DataProcessResult ☐ BuildSearchFilter ☐ Dynamic docs ☐ Events


---

## Genie DNA Compliance — MANDATORY for All Implementations

> Before writing ANY code, classify each component:
> **MACHINE** (static): Infrastructure that enables freedom. Build once, generic, interface-based.
> **FREEDOM** (dynamic): Anything users define. No fixed models, config-driven.

### DNA Checklist — Every Implementation MUST:
☐ **DNA-1 (Dynamic Documents):** Store data as `Dictionary<string, object>` / `Record<string, any>` — NOT typed model classes. User fields preserved without schema changes.
☐ **DNA-2 (BuildSearchFilter):** All queries use BuildSearchFilter/equivalent. Empty fields auto-skipped. No entity-specific query code.
☐ **DNA-3 (MicroserviceBase):** Inherit base class with DB, queue, cache, logger built in.
☐ **DNA-5 (DataProcessResult):** All public methods return `DataProcessResult<T>`. Errors return failure, not throw exceptions.
☐ **DNA-6 (Generic Interfaces):** External dependencies behind interfaces. Swap via config.
☐ **DNA-SCOPE:** Non-admin queries auto-inject userId filter. Cannot be bypassed.

### The Three Tests:
1. Can a business user change this without a developer? (YES = correct)
2. Does it work for entity types that do not exist yet? (YES = correct)
3. Can I swap the database/service/UI without changing this? (YES = correct)
