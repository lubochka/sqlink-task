# Skill 32: DevOps CI/CD — Implementation Prompt

## Phase 1: Pipeline Structure
GitHub Actions workflow. Build -> Lint -> Test -> Docker -> Deploy stages.

## Phase 2: DNA Compliance Gate
Automated check: all services return DataProcessResult.
No typed model classes where dynamic docs should be used.
BuildSearchFilter used for all queries.

## Phase 3: Docker & Helm
Multi-stage Docker builds. Helm chart with configurable values per environment.

## Phase 4: Deployment
K8s deploy with rollback. Smoke tests post-deploy. Health check verification.

---

## Genie DNA Compliance — MANDATORY
☐ DNA-1: Dynamic Documents — Dictionary<string, object>, NOT typed models
☐ DNA-2: BuildSearchFilter — skip empty fields, no entity-specific query code
☐ DNA-3: MicroserviceBase — inherit DB, queue, cache, logger
☐ DNA-5: DataProcessResult<T> — all methods return result wrapper
☐ DNA-6: Generic Interfaces — swap via config
☐ DNA-SCOPE: Non-admin queries auto-inject userId filter
