/**
 * XIIGen Skill 32: DevOps CI/CD — Java Alternative
 * DNA: DataProcessResult, dynamic documents, BuildSearchFilter
 */
package com.xiigen.devops;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

public class CiCdService {
    private final IDatabaseService db;
    private final IQueueService queue;
    private final ILogger logger;

    public CiCdService(IDatabaseService db, IQueueService queue, ILogger logger) {
        this.db = db; this.queue = queue; this.logger = logger;
    }

    public DataProcessResult<String> generatePipeline(PipelineConfig config) {
        try {
            Map<String, Object> template = resolveTemplate(config.getProvider());
            String rendered = renderTemplate(template, config);

            Map<String, Object> doc = new HashMap<>();
            doc.put("id", config.getServiceId() + "-" + config.getProvider());
            doc.put("serviceId", config.getServiceId());
            doc.put("provider", config.getProvider());
            doc.put("stages", config.getStages());
            doc.put("rendered", rendered);
            doc.put("createdAt", Instant.now().toString());
            db.upsert("pipeline-configs", doc);

            return DataProcessResult.ok(rendered, "Pipeline generated");
        } catch (Exception e) {
            logger.error("Pipeline generation failed", e);
            return DataProcessResult.fail(e.getMessage());
        }
    }

    public DataProcessResult<Map<String, Object>> triggerPipeline(String pipelineId, String triggerType) {
        try {
            Map<String, Object> execution = new HashMap<>();
            execution.put("id", "exec-" + System.currentTimeMillis());
            execution.put("pipelineId", pipelineId);
            execution.put("triggerType", triggerType);
            execution.put("status", "running");
            execution.put("startedAt", Instant.now().toString());
            db.upsert("pipeline-executions", execution);
            queue.publish("pipeline-jobs", execution);
            return DataProcessResult.ok(execution, "Pipeline triggered");
        } catch (Exception e) {
            return DataProcessResult.fail(e.getMessage());
        }
    }

    // DNA: BuildSearchFilter pattern
    public DataProcessResult<List<Map<String, Object>>> queryHistory(Map<String, Object> filters) {
        Map<String, Object> searchFilter = filters.entrySet().stream()
            .filter(e -> e.getValue() != null && !e.getValue().toString().isEmpty())
            .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
        return db.query("pipeline-executions", searchFilter);
    }

    private Map<String, Object> resolveTemplate(String provider) {
        Map<String, Object> template = new HashMap<>();
        switch (provider) {
            case "github-actions": template.put("runner", "ubuntu-latest"); break;
            case "gitlab-ci": template.put("image", "mcr.microsoft.com/dotnet/sdk:9.0"); break;
            default: template.put("runner", "ubuntu-latest");
        }
        return template;
    }

    private String renderTemplate(Map<String, Object> template, PipelineConfig config) {
        return "# Generated pipeline for " + config.getServiceId();
    }
}
