---
skill_id: "32"
name: devops-cicd
title: "DevOps CI/CD Pipeline"
layer: "L8: Quality Assurance"
version: "17.1"
status: "active"
priority: "P1"
dependencies: ["27-k8s-deployment", "29-unit-testing", "30-e2e-testing", "22-logger-service"]
alternatives_server: [github-actions, gitlab-ci, azure-devops, jenkins, circleci]
genie_dna:
  - "DNA-3: CI/CD builds and deploys each microservice independently"
  - "DNA-6: Pipeline works across cloud providers via generic interfaces"
  - "DNA-MACHINE: CI/CD infrastructure is static"
  - "DNA-RESULT: Pipeline step results use DataProcessResult for audit trail"
triggers: CI/CD, GitHub Actions, GitLab CI, pipeline, build, deploy, automated, rollback, canary
estimated_loc: 800
---

# Skill 32: DevOps CI/CD Pipeline
## Automated Build, Test, Deploy for XIIGen Microservice Architecture

**Classification:** MACHINE — CI/CD infrastructure is static config  
**Priority:** P1 — Required for automated deployment  
**Dependencies:** Skill 27 (K8s), Skill 29 (Unit Tests), Skill 30 (E2E), Skill 22 (Logger)  
**Layer:** L8: Quality Assurance  
**Estimated LOC:** ~800  

---

## Overview

DevOps CI/CD orchestrates the build-test-deploy pipeline for every XIIGen microservice. It generates pipeline configurations for multiple providers (GitHub Actions, GitLab CI, Azure DevOps, Jenkins, CircleCI) from a universal template model. Each pipeline enforces DNA compliance gates, runs multi-level tests, builds Docker images, and deploys to Kubernetes with rollback automation. Execution history is stored as dynamic documents in Elasticsearch for audit and AI-assisted optimization.

## Key Concepts

- **Pipeline Template Engine** — Universal model that generates provider-specific configs. Change CI provider without rewriting logic.
- **Multi-Stage Deployment** — dev → staging → production with configurable approval gates and environment-specific secrets.
- **DNA Compliance Gate** — Automated checks verifying DataProcessResult, dynamic docs, BuildSearchFilter, scope isolation.
- **Rollback Automation** — Health check monitoring post-deploy; auto-rollback via `kubectl rollout undo` on failure.
- **Pipeline History** — Every execution stored as dynamic document for querying and trend analysis.

---

## DNA Integration

### Required Patterns
- **DataProcessResult** — Every pipeline step returns `DataProcessResult<StageResult>` with success/failure, duration, logs.
- **Dynamic Document** — Pipeline configs and execution history stored as dynamic documents. No fixed schema.
- **Scope Isolation (DNA-3)** — Each microservice has its own pipeline. Deploying one service never affects another.
- **BuildSearchFilter** — Query history by status, date, service, environment — empty fields skipped automatically.
- **EventDriven** — Emits: `PipelinePassed`, `PipelineFailed`, `DeploymentCompleted`, `RollbackTriggered`.

### Anti-Patterns to AVOID
- ❌ Hardcoding secrets in pipeline files — use Key Vault (Skill 37)
- ❌ Sharing Docker layers across unrelated services — violates scope isolation
- ❌ Running tests without coverage thresholds — enforce minimum 80%
- ❌ Deploying without health check verification
- ❌ Manual rollback processes — automate with health check detection

---

## Pipeline Stages

1. **Lint** — Code quality checks
2. **DNA Compliance** — Verify patterns
3. **Unit Tests** — Coverage gate (Skill 29)
4. **Build** — Docker multi-stage, tag with SHA
5. **Integration Tests** — Dynamic doc roundtrip
6. **E2E Tests** — Full flow (Skill 30)
7. **Security Scan** — Vulnerability check (Skill 37)
8. **Deploy** — Helm upgrade (Skill 27)
9. **Smoke Test** — Health + API check
10. **Notify** — Status notification (Skill 24)

---

## Primary Implementation (.NET 9)

### Models

```csharp
namespace XIIGen.DevOps.Models;

public record PipelineConfig(
    string ServiceId,
    string Provider,       // github-actions | gitlab-ci | azure-devops | jenkins | circleci
    string[] Stages,
    Dictionary<string, EnvironmentConfig> Environments,
    DeploymentStrategy Strategy,
    int CoverageThreshold = 80,
    DateTime CreatedAt = default
);

public record EnvironmentConfig(
    string Name, string Namespace, string ClusterUrl,
    bool RequiresApproval,
    Dictionary<string, string> Variables
);

public record PipelineExecution(
    string Id, string PipelineId, string ServiceId,
    string TriggerType, string CommitSha, string Branch,
    List<StageResult> Stages, string Status,
    TimeSpan Duration, DateTime StartedAt, DateTime? CompletedAt
);

public record StageResult(
    string Name, string Status, TimeSpan Duration,
    string[] Logs, Dictionary<string, object> Artifacts
);

public enum DeploymentStrategy { RollingUpdate, BlueGreen, Canary }
```

### Service Interface

```csharp
namespace XIIGen.DevOps.Interfaces;

public interface ICiCdService
{
    Task<DataProcessResult<string>> GeneratePipelineAsync(PipelineConfig config, CancellationToken ct = default);
    Task<DataProcessResult<PipelineExecution>> TriggerPipelineAsync(string pipelineId, string triggerType, CancellationToken ct = default);
    Task<DataProcessResult<PipelineExecution>> GetExecutionStatusAsync(string executionId, CancellationToken ct = default);
    Task<DataProcessResult<List<PipelineExecution>>> QueryHistoryAsync(Dictionary<string, object> filters, CancellationToken ct = default);
    Task<DataProcessResult<bool>> RollbackAsync(string executionId, CancellationToken ct = default);
    Task<DataProcessResult<DnaComplianceReport>> RunDnaComplianceAsync(string serviceId, CancellationToken ct = default);
}
```

### Core Implementation Pattern

```csharp
public class CiCdService : ICiCdService
{
    private readonly IDatabaseService _db;
    private readonly IQueueService _queue;
    private readonly ILogger<CiCdService> _logger;

    public async Task<DataProcessResult<string>> GeneratePipelineAsync(PipelineConfig config, CancellationToken ct = default)
    {
        try
        {
            var template = ResolveTemplate(config.Provider);
            var rendered = RenderTemplate(template, config);
            
            // DNA: Store as dynamic document
            await _db.UpsertAsync("pipeline-configs", new Dictionary<string, object>
            {
                ["id"] = $"{config.ServiceId}-{config.Provider}",
                ["serviceId"] = config.ServiceId,
                ["provider"] = config.Provider,
                ["stages"] = config.Stages,
                ["strategy"] = config.Strategy.ToString(),
                ["rendered"] = rendered,
                ["createdAt"] = DateTime.UtcNow
            }, ct);

            return DataProcessResult<string>.Ok(rendered, "Pipeline generated");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Pipeline generation failed for {ServiceId}", config.ServiceId);
            return DataProcessResult<string>.Fail(ex.Message);
        }
    }

    // DNA: BuildSearchFilter pattern
    public async Task<DataProcessResult<List<PipelineExecution>>> QueryHistoryAsync(
        Dictionary<string, object> filters, CancellationToken ct = default)
    {
        var searchFilter = ObjectProcessor.BuildSearchFilter(filters); // skips empty values
        return await _db.QueryAsync<List<PipelineExecution>>("pipeline-executions", searchFilter, ct);
    }
}
```

### DI Registration

```csharp
services.AddScoped<ICiCdService, CiCdService>();
services.AddScoped<IPipelineTemplateEngine, PipelineTemplateEngine>();
services.AddScoped<IDnaComplianceChecker, DnaComplianceChecker>();
```

---

## Test Scenarios

1. Generate GitHub Actions pipeline for .NET 9 service → verify valid YAML with all 10 stages
2. Generate GitLab CI for same service → verify equivalent stages in GitLab syntax
3. Trigger staging deploy → verify approval gate enforced for production
4. Health check fails → verify auto-rollback and `RollbackTriggered` event emitted
5. Query history for last 7 days → verify BuildSearchFilter skips empty fields
6. DNA compliance on service with hardcoded secrets → verify failure report
7. Canary deployment → verify traffic split (10% → 50% → 100%)

## Component Classification
- **Category:** DevOps Automation
- **Inputs:** Service metadata, tech stack, environment configs, Git triggers
- **Outputs:** Pipeline YAML, deployment status, rollback records, compliance reports
- **Side Effects:** Triggers pipelines, deploys to K8s, emits events
- **ES Indexes:** `pipeline-configs`, `pipeline-executions`
