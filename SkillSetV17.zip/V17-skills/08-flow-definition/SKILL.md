---
name: flow-definition
description: DAG-based flow model with validation, CRUD, and pre-built templates for all XIIGen scenarios
triggers: flow definition, DAG, workflow, pipeline, flow template, flow editor, create flow
dependencies: [01-core-interfaces, 02-object-processor, 03-elasticsearch-datastore, 05-database-fabric]
layer: L3-FlowEngine
genie-dna: Flow definitions stored as dynamic documents via ObjectProcessor. Search uses BuildSearchFilter with empty-field skipping.
phase: 2
---

# Skill 08: Flow Definition
## DAG Model + CRUD + Validation + Templates

The **data model** for XIIGen workflows. A FlowDefinition is a directed acyclic graph (DAG) of FlowNodes connected by FlowEdges. Each node has a type (trigger, AI transform, review, etc.) and configuration. Edges can have conditions (success/failure/expression).

---

## Architecture

```
FlowDefinition
├── FlowId, Name, Description, Version, Status
├── Nodes[] ─── FlowNode { NodeId, Name, Type, Config, Position, Timeout, Retries }
├── Edges[] ─── FlowEdge { SourceNodeId, TargetNodeId, Condition, Priority }
└── Metadata {} ─── dynamic fields (Genie DNA)

FlowExecution (runtime state — created by Skill 09)
├── ExecutionId, TraceId, FlowId, Status
├── StepStatuses {} ─── per-node state
├── StepOutputs {} ─── per-node output
├── Input, FinalResult
└── StartedAt, CompletedAt, Error
```

## Node Types

| Type | Purpose | Used By Skill |
|---|---|---|
| Trigger | Entry point — receives input | 15 (API Gateway) |
| FigmaParser | Parse Figma node tree | 10 |
| AiTransform | Send to AI model(s) for generation | 11 |
| AiReview | AI-powered code/output review | 12 |
| Feedback | Collect user feedback | 13 |
| Debug | Capture debug snapshot | 14 |
| CodeGenerator | Generate source code | 17 |
| DocumentationGen | Generate documentation | 18 |
| DesignSystem | Apply design system theme | 19 |
| Condition | Branch based on expression | 09 (built-in) |
| Merge | Fan-in — wait for all inputs | 09 (built-in) |
| Split | Fan-out — parallel execution | 09 (built-in) |
| Notification | Send notification | 24 |
| ContentPipeline | Content generation step | 40 |
| WhatsAppDiet | Diet coaching interaction | 41 |
| Custom | User-defined step executor | Any |

## Validation Rules

1. Must have at least one Trigger node
2. Must be a valid DAG (no cycles) — verified via DFS
3. All edge source/target node IDs must exist
4. Condition expressions must be parseable
5. No orphan nodes (every non-trigger node must be reachable)
6. Timeout and retry values must be positive

## Pre-Built Flow Templates

### 1. Figma → Code (Basic)
`Trigger → FigmaParser → AiTransform(4 models) → AiReview → Output`

### 2. Full System Generation
`Trigger → FigmaParser → AiAnalysis → Architecture → TechDesign → CodeGen → Review`

### 3. Integrate Design into Existing System
`Trigger → DocGen(existing) → FigmaParser → DesignSystem → AiTransform → AiReview → CodeGen`

### 4. System from Scratch (No Figma)
`Trigger → AiAnalysis(user desc) → Architecture → TechDesign → CodeGen → Review → Deploy`

### 5. WhatsApp Diet Coaching
`Trigger → AiDietPlan → DailyInput → AiCalorieCalc → AiReview → Notification`

### 6. Content Generation Pipeline
`Trigger → AudioToText → AiTextImprove → AiImagePlan → ImageGen → VideoGen → Schedule`

## Configuration Examples

```json
{
  "flowId": "figma-to-code-v1",
  "name": "Figma to Code",
  "nodes": [
    { "nodeId": "trigger", "name": "Input", "type": "Trigger" },
    { "nodeId": "parse", "name": "Parse Figma", "type": "FigmaParser" },
    { "nodeId": "transform", "name": "AI Transform", "type": "AiTransform",
      "configuration": { "models": ["claude","openai","gemini","deepseek"], "strategy": "parallel" } },
    { "nodeId": "review", "name": "AI Review", "type": "AiReview" }
  ],
  "edges": [
    { "sourceNodeId": "trigger", "targetNodeId": "parse" },
    { "sourceNodeId": "parse", "targetNodeId": "transform" },
    { "sourceNodeId": "transform", "targetNodeId": "review" }
  ]
}
```

## API (FlowDefinitionService)

| Method | Description |
|---|---|
| `CreateAsync(flow)` | Validate + store new flow definition |
| `GetAsync(flowId)` | Retrieve flow by ID |
| `UpdateAsync(flow)` | Validate + update existing flow |
| `DeleteAsync(flowId)` | Remove flow definition |
| `ListAsync(filter)` | Search flows with dynamic filter (Genie DNA) |
| `CloneAsync(flowId, newName)` | Deep-copy a flow definition |
| `GetTemplateAsync(name)` | Get pre-built template |

## Genie DNA Application

- Flow definitions stored as **dynamic documents** — ObjectProcessor.ParseObjectAlternative
- List/search uses **BuildSearchFilter** with empty-field skipping
- Metadata dict supports arbitrary fields without schema changes
- Node configuration dict is fully dynamic per node type

## DI Registration (.NET)

```csharp
builder.Services.AddSingleton<FlowDefinitionService>();
// Requires: IDatabaseService (Skill 05), IObjectProcessor (Skill 02)
```

## Test Scenarios

1. Create valid flow → returns Created with FlowId
2. Create flow with cycle → returns Error
3. Create flow without trigger → returns Error
4. Update flow → validates + returns Updated
5. List flows with partial filter → returns matching
6. Clone flow → new FlowId, same structure
7. Get template → returns pre-built flow
