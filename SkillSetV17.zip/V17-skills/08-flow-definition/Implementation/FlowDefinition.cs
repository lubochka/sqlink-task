// XIIGen.FlowEngine/Models/FlowDefinition.cs - Skill 08 | .NET 9
using XIIGen.Core.Base;
using XIIGen.Core.Enums;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;
using Microsoft.Extensions.Logging;

namespace XIIGen.FlowEngine.Models;

public class FlowDefinition
{
    public string FlowId { get; set; } = Guid.NewGuid().ToString();
    public string Name { get; set; }
    public string Description { get; set; }
    public string Version { get; set; } = "1.0.0";
    public FlowStatus Status { get; set; } = FlowStatus.Draft;
    public List<FlowNode> Nodes { get; set; } = [];
    public List<FlowEdge> Edges { get; set; } = [];
    public Dictionary<string, object> Metadata { get; set; } = [];
    public string CreatedBy { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
}

public class FlowNode
{
    public string NodeId { get; set; } = Guid.NewGuid().ToString();
    public string Name { get; set; }
    public NodeType Type { get; set; }
    public Dictionary<string, object> Configuration { get; set; } = [];
    public int PositionX { get; set; }
    public int PositionY { get; set; }
    public int TimeoutSeconds { get; set; } = 300;
    public int MaxRetries { get; set; } = 3;
}

public class FlowEdge
{
    public string EdgeId { get; set; } = Guid.NewGuid().ToString();
    public string SourceNodeId { get; set; }
    public string TargetNodeId { get; set; }
    public string Condition { get; set; } // null = always, "success", "failure", or expression
    public int Priority { get; set; }
}

public class FlowExecution
{
    public string ExecutionId { get; set; } = Guid.NewGuid().ToString();
    public string TraceId { get; set; }
    public string FlowId { get; set; }
    public FlowStatus Status { get; set; } = FlowStatus.Running;
    public string CurrentStepId { get; set; }
    public Dictionary<string, StepStatus> StepStatuses { get; set; } = [];
    public Dictionary<string, object> StepOutputs { get; set; } = [];
    public object Input { get; set; }
    public object FinalResult { get; set; }
    public DateTime StartedAt { get; set; } = DateTime.UtcNow;
    public DateTime? CompletedAt { get; set; }
    public string Error { get; set; }
}

// ─── Flow Validator ─────────────────────────────────
public static class FlowValidator
{
    public static (bool Valid, List<string> Errors) Validate(FlowDefinition flow)
    {
        var errors = new List<string>();
        if (flow.Nodes.Count == 0) errors.Add("Flow must have at least one node");

        var nodeIds = flow.Nodes.Select(n => n.NodeId).ToHashSet();
        foreach (var edge in flow.Edges)
        {
            if (!nodeIds.Contains(edge.SourceNodeId)) errors.Add($"Edge source '{edge.SourceNodeId}' not found");
            if (!nodeIds.Contains(edge.TargetNodeId)) errors.Add($"Edge target '{edge.TargetNodeId}' not found");
        }

        // Check for cycles (DAG validation)
        if (HasCycle(flow)) errors.Add("Flow contains a cycle - must be a DAG");

        // Check for trigger node
        var triggerNodes = flow.Nodes.Where(n => n.Type == NodeType.Trigger).ToList();
        if (triggerNodes.Count == 0) errors.Add("Flow must have a Trigger node");

        return (errors.Count == 0, errors);
    }

    private static bool HasCycle(FlowDefinition flow)
    {
        var adj = new Dictionary<string, List<string>>();
        foreach (var n in flow.Nodes) adj[n.NodeId] = [];
        foreach (var e in flow.Edges) adj[e.SourceNodeId].Add(e.TargetNodeId);

        var visited = new HashSet<string>();
        var stack = new HashSet<string>();

        bool Dfs(string node)
        {
            visited.Add(node); stack.Add(node);
            foreach (var next in adj.GetValueOrDefault(node, []))
            {
                if (!visited.Contains(next)) { if (Dfs(next)) return true; }
                else if (stack.Contains(next)) return true;
            }
            stack.Remove(node);
            return false;
        }

        return flow.Nodes.Any(n => !visited.Contains(n.NodeId) && Dfs(n.NodeId));
    }
}

// ─── Flow Definition Service (CRUD) ─────────────────
public class FlowDefinitionService(IDatabaseService database, IObjectProcessor processor)
{
    private const string Index = "flow-definitions";
    private const string Prefix = "xiigen";

    public async Task<DataProcessResult<FlowDefinition>> CreateAsync(FlowDefinition flow, CancellationToken ct = default)
    {
        var (valid, errors) = FlowValidator.Validate(flow);
        if (!valid) return DataProcessResult<FlowDefinition>.Error(string.Join("; ", errors));
        await database.StoreDocumentAsync(Index, Prefix, flow.FlowId, flow, ct: ct);
        return DataProcessResult<FlowDefinition>.Created(flow);
    }

    public async Task<DataProcessResult<FlowDefinition>> GetAsync(string flowId, CancellationToken ct = default)
    {
        var result = await database.GetDocumentAsync(Index, Prefix, flowId, ct);
        return result.IsSuccess ? DataProcessResult<FlowDefinition>.Success((FlowDefinition)result.Data) : DataProcessResult<FlowDefinition>.NotFound();
    }

    public async Task<DataProcessResult<FlowDefinition>> UpdateAsync(FlowDefinition flow, CancellationToken ct = default)
    {
        flow.UpdatedAt = DateTime.UtcNow;
        var (valid, errors) = FlowValidator.Validate(flow);
        if (!valid) return DataProcessResult<FlowDefinition>.Error(string.Join("; ", errors));
        await database.StoreDocumentAsync(Index, Prefix, flow.FlowId, flow, ct: ct);
        return DataProcessResult<FlowDefinition>.Updated(flow);
    }

    public Task<DataProcessResult<bool>> DeleteAsync(string flowId, CancellationToken ct = default)
        => database.DeleteDocumentAsync(Index, Prefix, flowId, ct);

    public async Task<DataProcessResult<List<FlowDefinition>>> ListAsync(object filter = null, int size = 50, CancellationToken ct = default)
    {
        // Genie DNA: BuildSearchFilter skips empty fields automatically
        var result = await database.SearchDocumentsAsync(Index, Prefix, filter ?? new { }, size, ct: ct);
        if (!result.IsSuccess) return DataProcessResult<List<FlowDefinition>>.Error(result.Message);
        var flows = result.Data?.Select(j => processor.Deserialize<FlowDefinition>(j)).ToList() ?? [];
        return DataProcessResult<List<FlowDefinition>>.Success(flows);
    }

    public async Task<DataProcessResult<FlowDefinition>> CloneAsync(string flowId, string newName, CancellationToken ct = default)
    {
        var original = await GetAsync(flowId, ct);
        if (!original.IsSuccess) return DataProcessResult<FlowDefinition>.NotFound();

        var clone = processor.DeepClone(original.Data);
        clone.FlowId = Guid.NewGuid().ToString();
        clone.Name = newName;
        clone.Version = "1.0.0";
        clone.Status = FlowStatus.Draft;
        clone.CreatedAt = DateTime.UtcNow;
        clone.UpdatedAt = DateTime.UtcNow;
        // Regenerate node/edge IDs to avoid conflicts
        var idMap = new Dictionary<string, string>();
        foreach (var node in clone.Nodes)
        {
            var oldId = node.NodeId;
            node.NodeId = Guid.NewGuid().ToString();
            idMap[oldId] = node.NodeId;
        }
        foreach (var edge in clone.Edges)
        {
            edge.EdgeId = Guid.NewGuid().ToString();
            if (idMap.TryGetValue(edge.SourceNodeId, out var newSrc)) edge.SourceNodeId = newSrc;
            if (idMap.TryGetValue(edge.TargetNodeId, out var newTgt)) edge.TargetNodeId = newTgt;
        }
        return await CreateAsync(clone, ct);
    }

    public FlowDefinition GetTemplate(string templateName) => templateName?.ToLower() switch
    {
        "figma-to-code" => FlowTemplates.FigmaToCode(),
        "system-generation" => FlowTemplates.SystemGeneration(),
        "integrate-design" => FlowTemplates.IntegrateDesign(),
        "system-from-scratch" => FlowTemplates.SystemFromScratch(),
        "whatsapp-diet" => FlowTemplates.WhatsAppDiet(),
        "content-pipeline" => FlowTemplates.ContentPipeline(),
        _ => null
    };
}

// ─── Pre-built Flow Templates ───────────────────────
public static class FlowTemplates
{
    public static FlowDefinition FigmaToCode() => new()
    {
        Name = "Figma to Code",
        Description = "Parse Figma nodes, fan-out to AI models, review, return best result",
        Nodes =
        [
            new() { NodeId = "trigger", Name = "Input", Type = NodeType.Trigger },
            new() { NodeId = "parse", Name = "Parse Figma", Type = NodeType.FigmaParser },
            new() { NodeId = "transform", Name = "AI Transform (4 models)", Type = NodeType.AiTransform, Configuration = new() { ["models"] = "claude,openai,gemini,deepseek" } },
            new() { NodeId = "review", Name = "AI Review", Type = NodeType.AiReview },
        ],
        Edges =
        [
            new() { SourceNodeId = "trigger", TargetNodeId = "parse" },
            new() { SourceNodeId = "parse", TargetNodeId = "transform" },
            new() { SourceNodeId = "transform", TargetNodeId = "review" },
        ]
    };

    public static FlowDefinition SystemGeneration() => new()
    {
        Name = "Full System Generation",
        Description = "From Figma + tech stack, generate complete system",
        Nodes =
        [
            new() { NodeId = "trigger", Name = "Input", Type = NodeType.Trigger },
            new() { NodeId = "parse", Name = "Parse All Screens", Type = NodeType.FigmaParser },
            new() { NodeId = "analyze", Name = "AI System Analysis", Type = NodeType.AiTransform, Configuration = new() { ["prompt_type"] = "system_analysis" } },
            new() { NodeId = "arch", Name = "Architecture Generation", Type = NodeType.AiTransform, Configuration = new() { ["prompt_type"] = "architecture" } },
            new() { NodeId = "techdesign", Name = "Tech Design Per Screen", Type = NodeType.AiTransform, Configuration = new() { ["prompt_type"] = "tech_design" } },
            new() { NodeId = "codegen", Name = "Code Generation", Type = NodeType.CodeGenerator },
            new() { NodeId = "review", Name = "Final Review", Type = NodeType.AiReview },
        ],
        Edges =
        [
            new() { SourceNodeId = "trigger", TargetNodeId = "parse" },
            new() { SourceNodeId = "parse", TargetNodeId = "analyze" },
            new() { SourceNodeId = "analyze", TargetNodeId = "arch" },
            new() { SourceNodeId = "arch", TargetNodeId = "techdesign" },
            new() { SourceNodeId = "techdesign", TargetNodeId = "codegen" },
            new() { SourceNodeId = "codegen", TargetNodeId = "review" },
        ]
    };

    public static FlowDefinition IntegrateDesign() => new()
    {
        Name = "Integrate Design into Existing System",
        Description = "Document existing system, parse Figma, apply design system, generate integration code",
        Nodes =
        [
            new() { NodeId = "trigger", Name = "Input", Type = NodeType.Trigger },
            new() { NodeId = "docgen", Name = "Document Existing System", Type = NodeType.DocumentationGen },
            new() { NodeId = "parse", Name = "Parse Figma Design", Type = NodeType.FigmaParser },
            new() { NodeId = "design", Name = "Apply Design System", Type = NodeType.DesignSystem },
            new() { NodeId = "transform", Name = "AI Integration Code", Type = NodeType.AiTransform, Configuration = new() { ["prompt_type"] = "integration" } },
            new() { NodeId = "review", Name = "AI Review", Type = NodeType.AiReview },
            new() { NodeId = "codegen", Name = "Generate Final Code", Type = NodeType.CodeGenerator },
        ],
        Edges =
        [
            new() { SourceNodeId = "trigger", TargetNodeId = "docgen" },
            new() { SourceNodeId = "trigger", TargetNodeId = "parse" },
            new() { SourceNodeId = "docgen", TargetNodeId = "transform" },
            new() { SourceNodeId = "parse", TargetNodeId = "design" },
            new() { SourceNodeId = "design", TargetNodeId = "transform" },
            new() { SourceNodeId = "transform", TargetNodeId = "review" },
            new() { SourceNodeId = "review", TargetNodeId = "codegen" },
        ]
    };

    public static FlowDefinition SystemFromScratch() => new()
    {
        Name = "System from Scratch (No Figma)",
        Description = "Generate full system from user description without Figma designs",
        Nodes =
        [
            new() { NodeId = "trigger", Name = "User Description", Type = NodeType.Trigger },
            new() { NodeId = "analyze", Name = "AI Requirement Analysis", Type = NodeType.AiTransform, Configuration = new() { ["prompt_type"] = "requirement_analysis" } },
            new() { NodeId = "arch", Name = "Architecture Generation", Type = NodeType.AiTransform, Configuration = new() { ["prompt_type"] = "architecture" } },
            new() { NodeId = "techdesign", Name = "Technical Design", Type = NodeType.AiTransform, Configuration = new() { ["prompt_type"] = "tech_design" } },
            new() { NodeId = "codegen", Name = "Code Generation", Type = NodeType.CodeGenerator },
            new() { NodeId = "review", Name = "AI Review", Type = NodeType.AiReview },
        ],
        Edges =
        [
            new() { SourceNodeId = "trigger", TargetNodeId = "analyze" },
            new() { SourceNodeId = "analyze", TargetNodeId = "arch" },
            new() { SourceNodeId = "arch", TargetNodeId = "techdesign" },
            new() { SourceNodeId = "techdesign", TargetNodeId = "codegen" },
            new() { SourceNodeId = "codegen", TargetNodeId = "review" },
        ]
    };

    public static FlowDefinition WhatsAppDiet() => new()
    {
        Name = "WhatsApp Diet Coaching",
        Description = "AI diet plan generation with daily WhatsApp interaction and calorie tracking",
        Nodes =
        [
            new() { NodeId = "trigger", Name = "Client Registration", Type = NodeType.Trigger },
            new() { NodeId = "dietplan", Name = "AI Diet Plan", Type = NodeType.AiTransform, Configuration = new() { ["prompt_type"] = "diet_plan", ["models"] = "claude,openai,gemini" } },
            new() { NodeId = "review", Name = "Nutritionist Review", Type = NodeType.AiReview },
            new() { NodeId = "notify", Name = "Send Plan", Type = NodeType.Notification, Configuration = new() { ["channels"] = "whatsapp,push" } },
        ],
        Edges =
        [
            new() { SourceNodeId = "trigger", TargetNodeId = "dietplan" },
            new() { SourceNodeId = "dietplan", TargetNodeId = "review" },
            new() { SourceNodeId = "review", TargetNodeId = "notify" },
        ]
    };

    public static FlowDefinition ContentPipeline() => new()
    {
        Name = "Content Generation Pipeline",
        Description = "Audio/text → AI improve → images → video → music → schedule across platforms",
        Nodes =
        [
            new() { NodeId = "trigger", Name = "Content Input", Type = NodeType.Trigger },
            new() { NodeId = "transcribe", Name = "Audio to Text", Type = NodeType.AiTransform, Configuration = new() { ["prompt_type"] = "transcription" } },
            new() { NodeId = "improve", Name = "AI Text Improvement", Type = NodeType.AiTransform, Configuration = new() { ["prompt_type"] = "text_improve" } },
            new() { NodeId = "imageplan", Name = "Image Plan", Type = NodeType.AiTransform, Configuration = new() { ["prompt_type"] = "image_prompts" } },
            new() { NodeId = "imagegen", Name = "Image Generation", Type = NodeType.AiTransform, Configuration = new() { ["prompt_type"] = "image_gen" } },
            new() { NodeId = "videogen", Name = "Video Generation", Type = NodeType.ContentPipeline, Configuration = new() { ["step"] = "video" } },
            new() { NodeId = "schedule", Name = "Schedule Posts", Type = NodeType.ContentPipeline, Configuration = new() { ["step"] = "schedule" } },
        ],
        Edges =
        [
            new() { SourceNodeId = "trigger", TargetNodeId = "transcribe" },
            new() { SourceNodeId = "transcribe", TargetNodeId = "improve" },
            new() { SourceNodeId = "improve", TargetNodeId = "imageplan" },
            new() { SourceNodeId = "imageplan", TargetNodeId = "imagegen" },
            new() { SourceNodeId = "imagegen", TargetNodeId = "videogen" },
            new() { SourceNodeId = "videogen", TargetNodeId = "schedule" },
        ]
    };
}
