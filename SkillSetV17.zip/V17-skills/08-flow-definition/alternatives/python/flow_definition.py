# XIIGen Flow Definition — Skill 08 | Python
# DAG model, validation, CRUD, templates

from __future__ import annotations
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional


class FlowStatus(str, Enum):
    DRAFT = "draft"
    ACTIVE = "active"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class NodeType(str, Enum):
    TRIGGER = "trigger"
    FIGMA_PARSER = "figmaParser"
    AI_TRANSFORM = "aiTransform"
    AI_REVIEW = "aiReview"
    CODE_GENERATOR = "codeGenerator"
    FEEDBACK = "feedback"
    DEBUG = "debug"
    CONDITION = "condition"
    MERGE = "merge"
    SPLIT = "split"
    CUSTOM = "custom"
    DOCUMENTATION_GEN = "documentationGen"
    DESIGN_SYSTEM = "designSystem"
    NOTIFICATION = "notification"
    CONTENT_PIPELINE = "contentPipeline"
    WHATSAPP_DIET = "whatsappDiet"


@dataclass
class FlowNode:
    node_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    type: NodeType = NodeType.CUSTOM
    configuration: dict[str, Any] = field(default_factory=dict)
    position_x: int = 0
    position_y: int = 0
    timeout_seconds: int = 300
    max_retries: int = 3


@dataclass
class FlowEdge:
    edge_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    source_node_id: str = ""
    target_node_id: str = ""
    condition: Optional[str] = None
    priority: int = 0


@dataclass
class FlowDefinition:
    flow_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    description: str = ""
    version: str = "1.0.0"
    status: FlowStatus = FlowStatus.DRAFT
    nodes: list[FlowNode] = field(default_factory=list)
    edges: list[FlowEdge] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    created_by: Optional[str] = None
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


@dataclass
class FlowExecution:
    execution_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    trace_id: str = ""
    flow_id: str = ""
    status: FlowStatus = FlowStatus.RUNNING
    current_step_id: Optional[str] = None
    step_statuses: dict[str, dict] = field(default_factory=dict)
    step_outputs: dict[str, Any] = field(default_factory=dict)
    input: Any = None
    final_result: Any = None
    started_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    completed_at: Optional[str] = None
    error: Optional[str] = None


# ─── Flow Validator ──────────────────────────────────
def validate_flow(flow: FlowDefinition) -> tuple[bool, list[str]]:
    errors: list[str] = []
    if not flow.nodes:
        errors.append("Flow must have at least one node")

    node_ids = {n.node_id for n in flow.nodes}
    for edge in flow.edges:
        if edge.source_node_id not in node_ids:
            errors.append(f"Edge source '{edge.source_node_id}' not found")
        if edge.target_node_id not in node_ids:
            errors.append(f"Edge target '{edge.target_node_id}' not found")

    if _has_cycle(flow):
        errors.append("Flow contains a cycle — must be a DAG")

    triggers = [n for n in flow.nodes if n.type == NodeType.TRIGGER]
    if not triggers:
        errors.append("Flow must have a Trigger node")

    return len(errors) == 0, errors


def _has_cycle(flow: FlowDefinition) -> bool:
    adj: dict[str, list[str]] = {n.node_id: [] for n in flow.nodes}
    for e in flow.edges:
        adj.setdefault(e.source_node_id, []).append(e.target_node_id)

    visited: set[str] = set()
    stack: set[str] = set()

    def dfs(node: str) -> bool:
        visited.add(node)
        stack.add(node)
        for nxt in adj.get(node, []):
            if nxt not in visited:
                if dfs(nxt):
                    return True
            elif nxt in stack:
                return True
        stack.discard(node)
        return False

    return any(n.node_id not in visited and dfs(n.node_id) for n in flow.nodes)


# ─── Flow Definition Service ────────────────────────
class FlowDefinitionService:
    INDEX = "flow-definitions"
    PREFIX = "xiigen"

    def __init__(self, db, processor=None):
        self._db = db
        self._processor = processor

    async def create(self, flow: FlowDefinition) -> dict:
        valid, errors = validate_flow(flow)
        if not valid:
            return {"success": False, "error": "; ".join(errors)}
        await self._db.store(self.INDEX, self.PREFIX, flow.flow_id, flow.__dict__)
        return {"success": True, "data": flow}

    async def get(self, flow_id: str) -> FlowDefinition | None:
        result = await self._db.get(self.INDEX, self.PREFIX, flow_id)
        return result.get("data") if result else None

    async def update(self, flow: FlowDefinition) -> dict:
        flow.updated_at = datetime.now(timezone.utc).isoformat()
        valid, errors = validate_flow(flow)
        if not valid:
            return {"success": False, "error": "; ".join(errors)}
        await self._db.store(self.INDEX, self.PREFIX, flow.flow_id, flow.__dict__)
        return {"success": True}

    async def delete(self, flow_id: str) -> bool:
        return await self._db.delete(self.INDEX, self.PREFIX, flow_id)

    async def list_flows(self, filt: dict | None = None, size: int = 50) -> list:
        # Genie DNA: empty fields auto-skipped
        clean = {k: v for k, v in (filt or {}).items() if v}
        result = await self._db.search(self.INDEX, self.PREFIX, clean, size)
        return result.get("data", [])

    async def clone(self, flow_id: str, new_name: str) -> FlowDefinition | None:
        import copy
        original = await self.get(flow_id)
        if not original:
            return None
        cloned = copy.deepcopy(original)
        id_map: dict[str, str] = {}
        cloned.flow_id = str(uuid.uuid4())
        cloned.name = new_name
        cloned.version = "1.0.0"
        cloned.status = FlowStatus.DRAFT
        for node in cloned.nodes:
            old_id = node.node_id
            node.node_id = str(uuid.uuid4())
            id_map[old_id] = node.node_id
        for edge in cloned.edges:
            edge.edge_id = str(uuid.uuid4())
            edge.source_node_id = id_map.get(edge.source_node_id, edge.source_node_id)
            edge.target_node_id = id_map.get(edge.target_node_id, edge.target_node_id)
        result = await self.create(cloned)
        return result.get("data")

    @staticmethod
    def get_template(name: str) -> FlowDefinition | None:
        return FLOW_TEMPLATES.get(name, lambda: None)()


# ─── Flow Templates ──────────────────────────────────
def _figma_to_code() -> FlowDefinition:
    return FlowDefinition(
        name="Figma to Code",
        description="Parse Figma, fan-out AI, review",
        status=FlowStatus.ACTIVE,
        nodes=[
            FlowNode(node_id="trigger", name="Input", type=NodeType.TRIGGER),
            FlowNode(node_id="parse", name="Parse Figma", type=NodeType.FIGMA_PARSER),
            FlowNode(node_id="transform", name="AI Transform", type=NodeType.AI_TRANSFORM,
                     configuration={"models": ["claude", "openai", "gemini", "deepseek"]}),
            FlowNode(node_id="review", name="AI Review", type=NodeType.AI_REVIEW),
        ],
        edges=[
            FlowEdge(source_node_id="trigger", target_node_id="parse"),
            FlowEdge(source_node_id="parse", target_node_id="transform"),
            FlowEdge(source_node_id="transform", target_node_id="review"),
        ],
    )


def _system_generation() -> FlowDefinition:
    return FlowDefinition(
        name="Full System Generation",
        description="From Figma to complete system",
        status=FlowStatus.ACTIVE,
        nodes=[
            FlowNode(node_id="trigger", name="Input", type=NodeType.TRIGGER),
            FlowNode(node_id="parse", name="Parse Screens", type=NodeType.FIGMA_PARSER),
            FlowNode(node_id="analyze", name="System Analysis", type=NodeType.AI_TRANSFORM,
                     configuration={"prompt_type": "system_analysis"}),
            FlowNode(node_id="arch", name="Architecture", type=NodeType.AI_TRANSFORM,
                     configuration={"prompt_type": "architecture"}),
            FlowNode(node_id="codegen", name="Code Gen", type=NodeType.CODE_GENERATOR),
            FlowNode(node_id="review", name="Review", type=NodeType.AI_REVIEW),
        ],
        edges=[
            FlowEdge(source_node_id="trigger", target_node_id="parse"),
            FlowEdge(source_node_id="parse", target_node_id="analyze"),
            FlowEdge(source_node_id="analyze", target_node_id="arch"),
            FlowEdge(source_node_id="arch", target_node_id="codegen"),
            FlowEdge(source_node_id="codegen", target_node_id="review"),
        ],
    )


FLOW_TEMPLATES = {
    "figma-to-code": _figma_to_code,
    "system-generation": _system_generation,
}
