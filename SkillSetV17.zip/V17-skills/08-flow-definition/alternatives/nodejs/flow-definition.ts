// XIIGen Flow Definition — Skill 08 | Node.js/TypeScript
// DAG model, validation, CRUD, templates

import { v4 as uuid } from 'uuid';

// ─── Enums ──────────────────────────────────────────
export type FlowStatus = 'draft' | 'active' | 'running' | 'paused' | 'completed' | 'failed' | 'cancelled';
export type NodeType = 'trigger' | 'figmaParser' | 'aiTransform' | 'aiReview' | 'codeGenerator'
  | 'feedback' | 'debug' | 'condition' | 'merge' | 'split' | 'custom'
  | 'documentationGen' | 'designSystem' | 'notification' | 'contentPipeline' | 'whatsappDiet';

// ─── Models ─────────────────────────────────────────
export interface FlowNode {
  nodeId: string;
  name: string;
  type: NodeType;
  configuration: Record<string, any>;
  positionX: number;
  positionY: number;
  timeoutSeconds: number;
  maxRetries: number;
}

export interface FlowEdge {
  edgeId: string;
  sourceNodeId: string;
  targetNodeId: string;
  condition?: string;
  priority: number;
}

export interface FlowDefinition {
  flowId: string;
  name: string;
  description: string;
  version: string;
  status: FlowStatus;
  nodes: FlowNode[];
  edges: FlowEdge[];
  metadata: Record<string, any>;
  createdBy?: string;
  createdAt: string;
  updatedAt: string;
}

export interface FlowExecution {
  executionId: string;
  traceId: string;
  flowId: string;
  status: FlowStatus;
  currentStepId?: string;
  stepStatuses: Record<string, StepStatus>;
  stepOutputs: Record<string, any>;
  input: any;
  finalResult?: any;
  startedAt: string;
  completedAt?: string;
  error?: string;
}

export interface StepStatus {
  stepId: string;
  nodeType: string;
  status: FlowStatus;
  startedAt?: string;
  completedAt?: string;
  output?: any;
  error?: string;
}

// ─── Flow Validator ─────────────────────────────────
export function validateFlow(flow: FlowDefinition): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (!flow.nodes.length) errors.push('Flow must have at least one node');

  const nodeIds = new Set(flow.nodes.map(n => n.nodeId));
  for (const edge of flow.edges) {
    if (!nodeIds.has(edge.sourceNodeId)) errors.push(`Edge source '${edge.sourceNodeId}' not found`);
    if (!nodeIds.has(edge.targetNodeId)) errors.push(`Edge target '${edge.targetNodeId}' not found`);
  }

  if (hasCycle(flow)) errors.push('Flow contains a cycle — must be a DAG');

  const triggers = flow.nodes.filter(n => n.type === 'trigger');
  if (!triggers.length) errors.push('Flow must have a Trigger node');

  return { valid: errors.length === 0, errors };
}

function hasCycle(flow: FlowDefinition): boolean {
  const adj = new Map<string, string[]>();
  flow.nodes.forEach(n => adj.set(n.nodeId, []));
  flow.edges.forEach(e => adj.get(e.sourceNodeId)?.push(e.targetNodeId));

  const visited = new Set<string>();
  const stack = new Set<string>();

  function dfs(node: string): boolean {
    visited.add(node); stack.add(node);
    for (const next of adj.get(node) || []) {
      if (!visited.has(next)) { if (dfs(next)) return true; }
      else if (stack.has(next)) return true;
    }
    stack.delete(node);
    return false;
  }

  return flow.nodes.some(n => !visited.has(n.nodeId) && dfs(n.nodeId));
}

// ─── Flow Definition Service ────────────────────────
export class FlowDefinitionService {
  private readonly index = 'flow-definitions';
  private readonly prefix = 'xiigen';

  constructor(private db: any, private processor: any) {}

  async create(flow: FlowDefinition): Promise<{ success: boolean; data?: FlowDefinition; error?: string }> {
    const { valid, errors } = validateFlow(flow);
    if (!valid) return { success: false, error: errors.join('; ') };
    flow.flowId ||= uuid();
    flow.createdAt = new Date().toISOString();
    flow.updatedAt = flow.createdAt;
    await this.db.store(this.index, this.prefix, flow.flowId, flow);
    return { success: true, data: flow };
  }

  async get(flowId: string): Promise<FlowDefinition | null> {
    const result = await this.db.get(this.index, this.prefix, flowId);
    return result?.data ?? null;
  }

  async update(flow: FlowDefinition): Promise<{ success: boolean; error?: string }> {
    flow.updatedAt = new Date().toISOString();
    const { valid, errors } = validateFlow(flow);
    if (!valid) return { success: false, error: errors.join('; ') };
    await this.db.store(this.index, this.prefix, flow.flowId, flow);
    return { success: true };
  }

  async delete(flowId: string): Promise<boolean> {
    return this.db.delete(this.index, this.prefix, flowId);
  }

  async list(filter: Record<string, any> = {}, size = 50): Promise<FlowDefinition[]> {
    // Genie DNA: empty fields auto-skipped by processor
    const cleanFilter = this.processor?.buildSearchFilter?.(filter) ?? filter;
    const result = await this.db.search(this.index, this.prefix, cleanFilter, size);
    return result?.data ?? [];
  }

  async clone(flowId: string, newName: string): Promise<FlowDefinition | null> {
    const original = await this.get(flowId);
    if (!original) return null;
    const cloned: FlowDefinition = JSON.parse(JSON.stringify(original));
    const idMap = new Map<string, string>();
    cloned.flowId = uuid();
    cloned.name = newName;
    cloned.version = '1.0.0';
    cloned.status = 'draft';
    cloned.nodes.forEach(n => { const old = n.nodeId; n.nodeId = uuid(); idMap.set(old, n.nodeId); });
    cloned.edges.forEach(e => {
      e.edgeId = uuid();
      e.sourceNodeId = idMap.get(e.sourceNodeId) || e.sourceNodeId;
      e.targetNodeId = idMap.get(e.targetNodeId) || e.targetNodeId;
    });
    const result = await this.create(cloned);
    return result.data ?? null;
  }

  getTemplate(name: string): FlowDefinition | null {
    return FlowTemplates[name as keyof typeof FlowTemplates]?.() ?? null;
  }
}

// ─── Flow Templates ─────────────────────────────────
export const FlowTemplates = {
  'figma-to-code': (): FlowDefinition => ({
    flowId: uuid(), name: 'Figma to Code', description: 'Parse Figma, fan-out AI, review',
    version: '1.0.0', status: 'active' as FlowStatus, metadata: {}, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(),
    nodes: [
      { nodeId: 'trigger', name: 'Input', type: 'trigger', configuration: {}, positionX: 0, positionY: 0, timeoutSeconds: 60, maxRetries: 0 },
      { nodeId: 'parse', name: 'Parse Figma', type: 'figmaParser', configuration: {}, positionX: 200, positionY: 0, timeoutSeconds: 120, maxRetries: 2 },
      { nodeId: 'transform', name: 'AI Transform', type: 'aiTransform', configuration: { models: ['claude','openai','gemini','deepseek'] }, positionX: 400, positionY: 0, timeoutSeconds: 300, maxRetries: 3 },
      { nodeId: 'review', name: 'AI Review', type: 'aiReview', configuration: {}, positionX: 600, positionY: 0, timeoutSeconds: 300, maxRetries: 2 },
    ],
    edges: [
      { edgeId: uuid(), sourceNodeId: 'trigger', targetNodeId: 'parse', priority: 0 },
      { edgeId: uuid(), sourceNodeId: 'parse', targetNodeId: 'transform', priority: 0 },
      { edgeId: uuid(), sourceNodeId: 'transform', targetNodeId: 'review', priority: 0 },
    ],
  }),
  'system-generation': (): FlowDefinition => ({
    flowId: uuid(), name: 'Full System Generation', description: 'From Figma to complete system',
    version: '1.0.0', status: 'active' as FlowStatus, metadata: {}, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(),
    nodes: [
      { nodeId: 'trigger', name: 'Input', type: 'trigger', configuration: {}, positionX: 0, positionY: 0, timeoutSeconds: 60, maxRetries: 0 },
      { nodeId: 'parse', name: 'Parse Screens', type: 'figmaParser', configuration: {}, positionX: 200, positionY: 0, timeoutSeconds: 120, maxRetries: 2 },
      { nodeId: 'analyze', name: 'System Analysis', type: 'aiTransform', configuration: { prompt_type: 'system_analysis' }, positionX: 400, positionY: 0, timeoutSeconds: 300, maxRetries: 3 },
      { nodeId: 'arch', name: 'Architecture', type: 'aiTransform', configuration: { prompt_type: 'architecture' }, positionX: 600, positionY: 0, timeoutSeconds: 300, maxRetries: 3 },
      { nodeId: 'codegen', name: 'Code Gen', type: 'codeGenerator', configuration: {}, positionX: 800, positionY: 0, timeoutSeconds: 600, maxRetries: 2 },
      { nodeId: 'review', name: 'Review', type: 'aiReview', configuration: {}, positionX: 1000, positionY: 0, timeoutSeconds: 300, maxRetries: 2 },
    ],
    edges: [
      { edgeId: uuid(), sourceNodeId: 'trigger', targetNodeId: 'parse', priority: 0 },
      { edgeId: uuid(), sourceNodeId: 'parse', targetNodeId: 'analyze', priority: 0 },
      { edgeId: uuid(), sourceNodeId: 'analyze', targetNodeId: 'arch', priority: 0 },
      { edgeId: uuid(), sourceNodeId: 'arch', targetNodeId: 'codegen', priority: 0 },
      { edgeId: uuid(), sourceNodeId: 'codegen', targetNodeId: 'review', priority: 0 },
    ],
  }),
};
