<?php
// XIIGen Flow Definition — Skill 08 | PHP 8.3+
// DAG model, validation, CRUD, templates

declare(strict_types=1);
namespace XIIGen\FlowEngine;

use Ramsey\Uuid\Uuid;

// ─── Enums ──────────────────────────────────────────
enum FlowStatus: string {
    case Draft = 'draft';
    case Active = 'active';
    case Running = 'running';
    case Paused = 'paused';
    case Completed = 'completed';
    case Failed = 'failed';
    case Cancelled = 'cancelled';
}

enum NodeType: string {
    case Trigger = 'trigger';
    case FigmaParser = 'figmaParser';
    case AiTransform = 'aiTransform';
    case AiReview = 'aiReview';
    case CodeGenerator = 'codeGenerator';
    case Feedback = 'feedback';
    case Debug = 'debug';
    case Condition = 'condition';
    case Merge = 'merge';
    case Split = 'split';
    case Custom = 'custom';
    case DocumentationGen = 'documentationGen';
    case DesignSystem = 'designSystem';
    case Notification = 'notification';
    case ContentPipeline = 'contentPipeline';
    case WhatsAppDiet = 'whatsappDiet';
}

// ─── Models ─────────────────────────────────────────
class FlowNode {
    public function __construct(
        public string $nodeId = '',
        public string $name = '',
        public NodeType $type = NodeType::Custom,
        public array $configuration = [],
        public int $positionX = 0,
        public int $positionY = 0,
        public int $timeoutSeconds = 300,
        public int $maxRetries = 3,
    ) {
        $this->nodeId = $this->nodeId ?: Uuid::uuid4()->toString();
    }
}

class FlowEdge {
    public function __construct(
        public string $edgeId = '',
        public string $sourceNodeId = '',
        public string $targetNodeId = '',
        public ?string $condition = null,
        public int $priority = 0,
    ) {
        $this->edgeId = $this->edgeId ?: Uuid::uuid4()->toString();
    }
}

class FlowDefinition {
    public function __construct(
        public string $flowId = '',
        public string $name = '',
        public string $description = '',
        public string $version = '1.0.0',
        public FlowStatus $status = FlowStatus::Draft,
        public array $nodes = [],
        public array $edges = [],
        public array $metadata = [],
        public ?string $createdBy = null,
        public string $createdAt = '',
        public string $updatedAt = '',
    ) {
        $this->flowId = $this->flowId ?: Uuid::uuid4()->toString();
        $this->createdAt = $this->createdAt ?: date('c');
        $this->updatedAt = $this->updatedAt ?: date('c');
    }
}

// ─── Validator ──────────────────────────────────────
class FlowValidator {
    public static function validate(FlowDefinition $flow): array {
        $errors = [];

        if (empty($flow->nodes)) {
            $errors[] = 'Flow must have at least one node';
        }

        $nodeIds = array_map(fn(FlowNode $n) => $n->nodeId, $flow->nodes);
        $nodeIdSet = array_flip($nodeIds);

        foreach ($flow->edges as $edge) {
            if (!isset($nodeIdSet[$edge->sourceNodeId])) {
                $errors[] = "Edge source '{$edge->sourceNodeId}' not found";
            }
            if (!isset($nodeIdSet[$edge->targetNodeId])) {
                $errors[] = "Edge target '{$edge->targetNodeId}' not found";
            }
        }

        if (self::hasCycle($flow)) {
            $errors[] = 'Flow contains a cycle — must be a DAG';
        }

        $triggers = array_filter($flow->nodes, fn(FlowNode $n) => $n->type === NodeType::Trigger);
        if (empty($triggers)) {
            $errors[] = 'Flow must have a Trigger node';
        }

        return ['valid' => empty($errors), 'errors' => $errors];
    }

    private static function hasCycle(FlowDefinition $flow): bool {
        $adj = [];
        foreach ($flow->nodes as $n) { $adj[$n->nodeId] = []; }
        foreach ($flow->edges as $e) { $adj[$e->sourceNodeId][] = $e->targetNodeId; }

        $visited = [];
        $stack = [];

        $dfs = function(string $node) use (&$adj, &$visited, &$stack, &$dfs): bool {
            $visited[$node] = true;
            $stack[$node] = true;
            foreach ($adj[$node] ?? [] as $next) {
                if (!isset($visited[$next])) { if ($dfs($next)) return true; }
                elseif (isset($stack[$next])) return true;
            }
            unset($stack[$node]);
            return false;
        };

        foreach ($flow->nodes as $n) {
            if (!isset($visited[$n->nodeId]) && $dfs($n->nodeId)) return true;
        }
        return false;
    }
}

// ─── Service ────────────────────────────────────────
class FlowDefinitionService {
    private const INDEX = 'flow-definitions';
    private const PREFIX = 'xiigen';

    public function __construct(private $db, private $processor = null) {}

    public function create(FlowDefinition $flow): array {
        $validation = FlowValidator::validate($flow);
        if (!$validation['valid']) {
            return ['success' => false, 'error' => implode('; ', $validation['errors'])];
        }
        $this->db->store(self::INDEX, self::PREFIX, $flow->flowId, $flow);
        return ['success' => true, 'data' => $flow];
    }

    public function get(string $flowId): ?FlowDefinition {
        $result = $this->db->get(self::INDEX, self::PREFIX, $flowId);
        return $result['data'] ?? null;
    }

    public function update(FlowDefinition $flow): array {
        $flow->updatedAt = date('c');
        $validation = FlowValidator::validate($flow);
        if (!$validation['valid']) {
            return ['success' => false, 'error' => implode('; ', $validation['errors'])];
        }
        $this->db->store(self::INDEX, self::PREFIX, $flow->flowId, $flow);
        return ['success' => true];
    }

    public function delete(string $flowId): bool {
        return $this->db->delete(self::INDEX, self::PREFIX, $flowId);
    }

    public function listFlows(array $filter = [], int $size = 50): array {
        $clean = array_filter($filter, fn($v) => $v !== '' && $v !== null);
        $result = $this->db->search(self::INDEX, self::PREFIX, $clean, $size);
        return $result['data'] ?? [];
    }
}

// ─── Templates ──────────────────────────────────────
class FlowTemplates {
    public static function figmaToCode(): FlowDefinition {
        return new FlowDefinition(
            name: 'Figma to Code',
            description: 'Parse Figma, fan-out AI, review',
            status: FlowStatus::Active,
            nodes: [
                new FlowNode(nodeId: 'trigger', name: 'Input', type: NodeType::Trigger),
                new FlowNode(nodeId: 'parse', name: 'Parse Figma', type: NodeType::FigmaParser),
                new FlowNode(nodeId: 'transform', name: 'AI Transform', type: NodeType::AiTransform,
                    configuration: ['models' => ['claude','openai','gemini','deepseek']]),
                new FlowNode(nodeId: 'review', name: 'AI Review', type: NodeType::AiReview),
            ],
            edges: [
                new FlowEdge(sourceNodeId: 'trigger', targetNodeId: 'parse'),
                new FlowEdge(sourceNodeId: 'parse', targetNodeId: 'transform'),
                new FlowEdge(sourceNodeId: 'transform', targetNodeId: 'review'),
            ]
        );
    }

    public static function systemGeneration(): FlowDefinition {
        return new FlowDefinition(
            name: 'Full System Generation',
            description: 'From Figma to complete system',
            status: FlowStatus::Active,
            nodes: [
                new FlowNode(nodeId: 'trigger', name: 'Input', type: NodeType::Trigger),
                new FlowNode(nodeId: 'parse', name: 'Parse Screens', type: NodeType::FigmaParser),
                new FlowNode(nodeId: 'analyze', name: 'System Analysis', type: NodeType::AiTransform,
                    configuration: ['prompt_type' => 'system_analysis']),
                new FlowNode(nodeId: 'arch', name: 'Architecture', type: NodeType::AiTransform,
                    configuration: ['prompt_type' => 'architecture']),
                new FlowNode(nodeId: 'codegen', name: 'Code Gen', type: NodeType::CodeGenerator),
                new FlowNode(nodeId: 'review', name: 'Review', type: NodeType::AiReview),
            ],
            edges: [
                new FlowEdge(sourceNodeId: 'trigger', targetNodeId: 'parse'),
                new FlowEdge(sourceNodeId: 'parse', targetNodeId: 'analyze'),
                new FlowEdge(sourceNodeId: 'analyze', targetNodeId: 'arch'),
                new FlowEdge(sourceNodeId: 'arch', targetNodeId: 'codegen'),
                new FlowEdge(sourceNodeId: 'codegen', targetNodeId: 'review'),
            ]
        );
    }
}
