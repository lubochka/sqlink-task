// XIIGen Flow Definition — Skill 08 | Rust
// DAG model, validation, CRUD, templates

use serde::{Deserialize, Serialize};
use std::collections::{HashMap, HashSet};
use uuid::Uuid;
use chrono::{DateTime, Utc};

// ─── Enums ──────────────────────────────────────────
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "camelCase")]
pub enum FlowStatus { Draft, Active, Running, Paused, Completed, Failed, Cancelled }

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "camelCase")]
pub enum NodeType {
    Trigger, FigmaParser, AiTransform, AiReview, CodeGenerator,
    Feedback, Debug, Condition, Merge, Split, Custom,
    DocumentationGen, DesignSystem, Notification, ContentPipeline, WhatsAppDiet,
}

// ─── Models ─────────────────────────────────────────
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct FlowNode {
    pub node_id: String,
    pub name: String,
    #[serde(rename = "type")]
    pub node_type: NodeType,
    pub configuration: HashMap<String, serde_json::Value>,
    pub position_x: i32,
    pub position_y: i32,
    pub timeout_seconds: u32,
    pub max_retries: u32,
}

impl FlowNode {
    pub fn new(id: &str, name: &str, node_type: NodeType) -> Self {
        Self {
            node_id: id.to_string(), name: name.to_string(), node_type,
            configuration: HashMap::new(), position_x: 0, position_y: 0,
            timeout_seconds: 300, max_retries: 3,
        }
    }
    pub fn with_config(mut self, key: &str, value: serde_json::Value) -> Self {
        self.configuration.insert(key.to_string(), value);
        self
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct FlowEdge {
    pub edge_id: String,
    pub source_node_id: String,
    pub target_node_id: String,
    pub condition: Option<String>,
    pub priority: i32,
}

impl FlowEdge {
    pub fn new(source: &str, target: &str) -> Self {
        Self {
            edge_id: Uuid::new_v4().to_string(),
            source_node_id: source.to_string(),
            target_node_id: target.to_string(),
            condition: None, priority: 0,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct FlowDefinition {
    pub flow_id: String,
    pub name: String,
    pub description: String,
    pub version: String,
    pub status: FlowStatus,
    pub nodes: Vec<FlowNode>,
    pub edges: Vec<FlowEdge>,
    pub metadata: HashMap<String, serde_json::Value>,
    pub created_by: Option<String>,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}

impl Default for FlowDefinition {
    fn default() -> Self {
        Self {
            flow_id: Uuid::new_v4().to_string(),
            name: String::new(), description: String::new(),
            version: "1.0.0".to_string(), status: FlowStatus::Draft,
            nodes: Vec::new(), edges: Vec::new(),
            metadata: HashMap::new(), created_by: None,
            created_at: Utc::now(), updated_at: Utc::now(),
        }
    }
}

// ─── Validation ─────────────────────────────────────
pub struct ValidationResult {
    pub valid: bool,
    pub errors: Vec<String>,
}

pub fn validate_flow(flow: &FlowDefinition) -> ValidationResult {
    let mut errors = Vec::new();

    if flow.nodes.is_empty() {
        errors.push("Flow must have at least one node".to_string());
    }

    let node_ids: HashSet<&str> = flow.nodes.iter().map(|n| n.node_id.as_str()).collect();
    for edge in &flow.edges {
        if !node_ids.contains(edge.source_node_id.as_str()) {
            errors.push(format!("Edge source '{}' not found", edge.source_node_id));
        }
        if !node_ids.contains(edge.target_node_id.as_str()) {
            errors.push(format!("Edge target '{}' not found", edge.target_node_id));
        }
    }

    if has_cycle(flow) {
        errors.push("Flow contains a cycle — must be a DAG".to_string());
    }

    if !flow.nodes.iter().any(|n| n.node_type == NodeType::Trigger) {
        errors.push("Flow must have a Trigger node".to_string());
    }

    ValidationResult { valid: errors.is_empty(), errors }
}

fn has_cycle(flow: &FlowDefinition) -> bool {
    let mut adj: HashMap<&str, Vec<&str>> = HashMap::new();
    for n in &flow.nodes { adj.insert(&n.node_id, Vec::new()); }
    for e in &flow.edges {
        adj.entry(&e.source_node_id).or_default().push(&e.target_node_id);
    }

    let mut visited = HashSet::new();
    let mut stack = HashSet::new();

    fn dfs<'a>(node: &'a str, adj: &HashMap<&'a str, Vec<&'a str>>,
               visited: &mut HashSet<&'a str>, stack: &mut HashSet<&'a str>) -> bool {
        visited.insert(node); stack.insert(node);
        if let Some(neighbors) = adj.get(node) {
            for &next in neighbors {
                if !visited.contains(next) { if dfs(next, adj, visited, stack) { return true; } }
                else if stack.contains(next) { return true; }
            }
        }
        stack.remove(node);
        false
    }

    flow.nodes.iter().any(|n| !visited.contains(n.node_id.as_str()) && dfs(&n.node_id, &adj, &mut visited, &mut stack))
}

// ─── Templates ──────────────────────────────────────
pub fn figma_to_code_template() -> FlowDefinition {
    FlowDefinition {
        name: "Figma to Code".to_string(),
        description: "Parse Figma, fan-out AI, review".to_string(),
        status: FlowStatus::Active,
        nodes: vec![
            FlowNode::new("trigger", "Input", NodeType::Trigger),
            FlowNode::new("parse", "Parse Figma", NodeType::FigmaParser),
            FlowNode::new("transform", "AI Transform", NodeType::AiTransform)
                .with_config("models", serde_json::json!(["claude","openai","gemini","deepseek"])),
            FlowNode::new("review", "AI Review", NodeType::AiReview),
        ],
        edges: vec![
            FlowEdge::new("trigger", "parse"),
            FlowEdge::new("parse", "transform"),
            FlowEdge::new("transform", "review"),
        ],
        ..Default::default()
    }
}

pub fn system_generation_template() -> FlowDefinition {
    FlowDefinition {
        name: "Full System Generation".to_string(),
        description: "From Figma to complete system".to_string(),
        status: FlowStatus::Active,
        nodes: vec![
            FlowNode::new("trigger", "Input", NodeType::Trigger),
            FlowNode::new("parse", "Parse Screens", NodeType::FigmaParser),
            FlowNode::new("analyze", "System Analysis", NodeType::AiTransform)
                .with_config("prompt_type", serde_json::json!("system_analysis")),
            FlowNode::new("arch", "Architecture", NodeType::AiTransform)
                .with_config("prompt_type", serde_json::json!("architecture")),
            FlowNode::new("codegen", "Code Gen", NodeType::CodeGenerator),
            FlowNode::new("review", "Review", NodeType::AiReview),
        ],
        edges: vec![
            FlowEdge::new("trigger", "parse"),
            FlowEdge::new("parse", "analyze"),
            FlowEdge::new("analyze", "arch"),
            FlowEdge::new("arch", "codegen"),
            FlowEdge::new("codegen", "review"),
        ],
        ..Default::default()
    }
}
