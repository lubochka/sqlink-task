// XIIGen Flow Definition — Skill 08 | Java 21+
// DAG model, validation, CRUD, templates

package com.xiigen.flowengine;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

public class FlowDefinition {

    // ─── Enums ──────────────────────────────────────
    public enum FlowStatus { DRAFT, ACTIVE, RUNNING, PAUSED, COMPLETED, FAILED, CANCELLED }
    public enum NodeType {
        TRIGGER, FIGMA_PARSER, AI_TRANSFORM, AI_REVIEW, CODE_GENERATOR,
        FEEDBACK, DEBUG, CONDITION, MERGE, SPLIT, CUSTOM,
        DOCUMENTATION_GEN, DESIGN_SYSTEM, NOTIFICATION, CONTENT_PIPELINE, WHATSAPP_DIET
    }

    // ─── Flow Node ──────────────────────────────────
    public record FlowNode(
        String nodeId, String name, NodeType type,
        Map<String, Object> configuration,
        int positionX, int positionY,
        int timeoutSeconds, int maxRetries
    ) {
        public FlowNode(String nodeId, String name, NodeType type) {
            this(nodeId, name, type, Map.of(), 0, 0, 300, 3);
        }
        public FlowNode(String nodeId, String name, NodeType type, Map<String, Object> config) {
            this(nodeId, name, type, config, 0, 0, 300, 3);
        }
    }

    // ─── Flow Edge ──────────────────────────────────
    public record FlowEdge(String edgeId, String sourceNodeId, String targetNodeId, String condition, int priority) {
        public FlowEdge(String sourceNodeId, String targetNodeId) {
            this(UUID.randomUUID().toString(), sourceNodeId, targetNodeId, null, 0);
        }
    }

    // ─── Flow Definition Model ──────────────────────
    private String flowId = UUID.randomUUID().toString();
    private String name;
    private String description;
    private String version = "1.0.0";
    private FlowStatus status = FlowStatus.DRAFT;
    private List<FlowNode> nodes = new ArrayList<>();
    private List<FlowEdge> edges = new ArrayList<>();
    private Map<String, Object> metadata = new HashMap<>();
    private String createdBy;
    private Instant createdAt = Instant.now();
    private Instant updatedAt = Instant.now();

    // Getters/setters omitted for brevity — use Lombok @Data in production
    public String getFlowId() { return flowId; }
    public void setFlowId(String id) { this.flowId = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getDescription() { return description; }
    public void setDescription(String desc) { this.description = desc; }
    public String getVersion() { return version; }
    public void setVersion(String v) { this.version = v; }
    public FlowStatus getStatus() { return status; }
    public void setStatus(FlowStatus s) { this.status = s; }
    public List<FlowNode> getNodes() { return nodes; }
    public void setNodes(List<FlowNode> n) { this.nodes = n; }
    public List<FlowEdge> getEdges() { return edges; }
    public void setEdges(List<FlowEdge> e) { this.edges = e; }
    public Map<String, Object> getMetadata() { return metadata; }
    public Instant getCreatedAt() { return createdAt; }
    public Instant getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(Instant t) { this.updatedAt = t; }

    // ─── Validator ──────────────────────────────────
    public static record ValidationResult(boolean valid, List<String> errors) {}

    public static ValidationResult validate(FlowDefinition flow) {
        var errors = new ArrayList<String>();
        if (flow.nodes.isEmpty()) errors.add("Flow must have at least one node");

        var nodeIds = flow.nodes.stream().map(FlowNode::nodeId).collect(Collectors.toSet());
        for (var edge : flow.edges) {
            if (!nodeIds.contains(edge.sourceNodeId())) errors.add("Edge source '" + edge.sourceNodeId() + "' not found");
            if (!nodeIds.contains(edge.targetNodeId())) errors.add("Edge target '" + edge.targetNodeId() + "' not found");
        }

        if (hasCycle(flow)) errors.add("Flow contains a cycle — must be a DAG");

        boolean hasTrigger = flow.nodes.stream().anyMatch(n -> n.type() == NodeType.TRIGGER);
        if (!hasTrigger) errors.add("Flow must have a Trigger node");

        return new ValidationResult(errors.isEmpty(), errors);
    }

    private static boolean hasCycle(FlowDefinition flow) {
        var adj = new HashMap<String, List<String>>();
        flow.nodes.forEach(n -> adj.put(n.nodeId(), new ArrayList<>()));
        flow.edges.forEach(e -> adj.computeIfAbsent(e.sourceNodeId(), k -> new ArrayList<>()).add(e.targetNodeId()));

        var visited = new HashSet<String>();
        var stack = new HashSet<String>();

        for (var node : flow.nodes) {
            if (!visited.contains(node.nodeId()) && dfs(node.nodeId(), adj, visited, stack)) return true;
        }
        return false;
    }

    private static boolean dfs(String node, Map<String, List<String>> adj, Set<String> visited, Set<String> stack) {
        visited.add(node); stack.add(node);
        for (var next : adj.getOrDefault(node, List.of())) {
            if (!visited.contains(next)) { if (dfs(next, adj, visited, stack)) return true; }
            else if (stack.contains(next)) return true;
        }
        stack.remove(node);
        return false;
    }

    // ─── Templates ──────────────────────────────────
    public static FlowDefinition figmaToCodeTemplate() {
        var flow = new FlowDefinition();
        flow.setName("Figma to Code");
        flow.setDescription("Parse Figma, fan-out AI models, review");
        flow.setStatus(FlowStatus.ACTIVE);
        flow.setNodes(List.of(
            new FlowNode("trigger", "Input", NodeType.TRIGGER),
            new FlowNode("parse", "Parse Figma", NodeType.FIGMA_PARSER),
            new FlowNode("transform", "AI Transform", NodeType.AI_TRANSFORM, Map.of("models", List.of("claude","openai","gemini","deepseek"))),
            new FlowNode("review", "AI Review", NodeType.AI_REVIEW)
        ));
        flow.setEdges(List.of(
            new FlowEdge("trigger", "parse"),
            new FlowEdge("parse", "transform"),
            new FlowEdge("transform", "review")
        ));
        return flow;
    }

    public static FlowDefinition systemGenerationTemplate() {
        var flow = new FlowDefinition();
        flow.setName("Full System Generation");
        flow.setDescription("From Figma to complete system");
        flow.setStatus(FlowStatus.ACTIVE);
        flow.setNodes(List.of(
            new FlowNode("trigger", "Input", NodeType.TRIGGER),
            new FlowNode("parse", "Parse Screens", NodeType.FIGMA_PARSER),
            new FlowNode("analyze", "System Analysis", NodeType.AI_TRANSFORM, Map.of("prompt_type", "system_analysis")),
            new FlowNode("arch", "Architecture", NodeType.AI_TRANSFORM, Map.of("prompt_type", "architecture")),
            new FlowNode("codegen", "Code Gen", NodeType.CODE_GENERATOR),
            new FlowNode("review", "Review", NodeType.AI_REVIEW)
        ));
        flow.setEdges(List.of(
            new FlowEdge("trigger", "parse"),
            new FlowEdge("parse", "analyze"),
            new FlowEdge("analyze", "arch"),
            new FlowEdge("arch", "codegen"),
            new FlowEdge("codegen", "review")
        ));
        return flow;
    }
}
