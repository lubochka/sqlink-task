# Skill 08 — Flow Definition: Implementation Guide

## Prerequisites
- Skill 01 (Core Interfaces) — IDatabaseService, IObjectProcessor
- Skill 02 (ObjectProcessor) — ParseObjectAlternative, BuildSearchFilter
- Skill 03 or 05 — Elasticsearch or Database Fabric provider configured

## Step 1: Create Models
1. Define `FlowStatus` enum (Draft, Active, Running, Paused, Completed, Failed, Cancelled)
2. Define `NodeType` enum (16 types — see SKILL.md)
3. Create `FlowNode` model (nodeId, name, type, configuration dict, position, timeout, retries)
4. Create `FlowEdge` model (edgeId, sourceNodeId, targetNodeId, condition, priority)
5. Create `FlowDefinition` model (flowId, name, description, version, status, nodes[], edges[], metadata{})
6. Create `FlowExecution` model (executionId, traceId, flowId, status, stepStatuses{}, stepOutputs{}, input, finalResult)

## Step 2: Implement FlowValidator
1. Check at least one node exists
2. Verify all edge source/target IDs reference existing nodes
3. Implement cycle detection via DFS (adjacency list → visited + recursion stack)
4. Check for at least one Trigger node
5. Return (valid, errors[]) tuple

## Step 3: Implement FlowDefinitionService (CRUD)
1. `CreateAsync` — validate → store via IDatabaseService → return Created
2. `GetAsync` — retrieve by flowId
3. `UpdateAsync` — set UpdatedAt → validate → store → return Updated
4. `DeleteAsync` — delete by flowId
5. `ListAsync` — use ObjectProcessor.BuildSearchFilter (Genie DNA: empty fields skipped) → search
6. `CloneAsync` — deep copy → regenerate all IDs (flowId, nodeIds, edgeIds) → remap edge references → create

## Step 4: Create Flow Templates
Create static methods for all 6 scenario templates:
1. `FigmaToCode()` — Trigger → FigmaParser → AiTransform(4 models) → AiReview
2. `SystemGeneration()` — Trigger → Parse → Analyze → Architecture → TechDesign → CodeGen → Review
3. `IntegrateDesign()` — Trigger → (DocGen ∥ Parse) → DesignSystem → AiTransform → Review → CodeGen
4. `SystemFromScratch()` — Trigger → ReqAnalysis → Architecture → TechDesign → CodeGen → Review
5. `WhatsAppDiet()` — Trigger → AiDietPlan → Review → Notification(WhatsApp+Push)
6. `ContentPipeline()` — Trigger → Transcribe → Improve → ImagePlan → ImageGen → VideoGen → Schedule

## Step 5: Register in DI
```csharp
builder.Services.AddSingleton<FlowDefinitionService>();
```

## Step 6: Verify
- Unit test: Create valid flow → success
- Unit test: Create flow with cycle → error
- Unit test: Create flow without trigger → error
- Unit test: Clone flow → new IDs, same structure
- Integration test: CRUD round-trip with Elasticsearch


---

## Genie DNA Compliance — MANDATORY for All Implementations

> Before writing ANY code, classify each component:
> **MACHINE** (static): Infrastructure that enables freedom. Build once, generic, interface-based.
> **FREEDOM** (dynamic): Anything users define. No fixed models, config-driven.

### DNA Checklist — Every Implementation MUST:
☐ **DNA-1 (Dynamic Documents):** Store data as `Dictionary<string, object>` / `Record<string, any>` — NOT typed model classes. User fields preserved without schema changes.
☐ **DNA-2 (BuildSearchFilter):** All queries use BuildSearchFilter/equivalent. Empty fields auto-skipped. No entity-specific query code.
☐ **DNA-3 (MicroserviceBase):** Inherit base class with DB, queue, cache, logger built in.
☐ **DNA-5 (DataProcessResult):** All public methods return `DataProcessResult<T>`. Errors return failure, not throw exceptions.
☐ **DNA-6 (Generic Interfaces):** External dependencies behind interfaces. Swap via config.
☐ **DNA-SCOPE:** Non-admin queries auto-inject userId filter. Cannot be bypassed.

### The Three Tests:
1. Can a business user change this without a developer? (YES = correct)
2. Does it work for entity types that do not exist yet? (YES = correct)
3. Can I swap the database/service/UI without changing this? (YES = correct)
