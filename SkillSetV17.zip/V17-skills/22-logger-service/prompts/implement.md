# Logger Service — Implementation Prompt | Skill 22
## Phase 1: Core Structured Logging
1. `LogStructuredAsync(LogEntry)` stores to ES with auto logId/timestamp
2. Convenience: `Info()`, `Warn()`, `Error()` with traceId propagation
3. **Genie DNA:** Log entries as dynamic docs, BuildSearchFilter for queries

## Phase 2: Search & Query
1. `SearchLogsAsync(traceId?, service?, level?, limit)` via BuildSearchFilter
2. Index naming: `logs-{yyyy-MM}` for rotation

## Phase 3: Exception Middleware
1. ASP.NET ExceptionMiddleware auto-capturing unhandled exceptions
2. Correlates with traceId from headers; publishes `xiigen.events.log.error`

## Phase 4: Retention & Testing
1. Index rotation policy; batch ingestion from queue
2. **Genie DNA Checklist:** ☐ DataProcessResult ☐ BuildSearchFilter ☐ Dynamic docs ☐ MicroserviceBase
