---
skill_id: "22"
name: logger-service
title: "Logger Service"
layer: "L6: Platform Services"
version: "17.0"
status: "active"
dependencies:
  - "01-core-interfaces"
  - "02-object-processor"
  - "03-elasticsearch-datastore"
  - "04-redis-queue-service"
dotnet_namespace: "XIIGen.Services.Logger"
di_registration: "services.AddXIIGenLoggerService()"
es_index: "xiigen-logs-{yyyy-MM}"
genie_dna:
  - "DNA-1: Log entries as dynamic documents (structured JSON, extensible fields)"
  - "DNA-2: BuildSearchFilter for log search (traceId, level, service, time — skip empty)"
  - "DNA-3: Inherits MicroserviceBase (component #11 from Architecture.docx)"
  - "DNA-5: DataProcessResult for search/query operations"
  - "DNA-7: Subscribes to events from ALL services — event-driven log aggregation"
triggers: logging, log, trace, structured logging, correlation ID, traceId, audit log, log search, log retention
---

# Skill 22: Logger Service
## Structured Logging with Dynamic Documents — Component #11

**Classification: MACHINE (Static infrastructure)**
From Architecture.docx Base Core component #11: "Logger — logging and data." Every service inherits logging through MicroserviceBase. The Logger service aggregates, stores, and enables search across all logs.

---

## Genie DNA Integration

### Log Entries as Dynamic Documents (DNA-1)
Log entries are NOT typed log models — they're dynamic documents that can contain ANY fields from ANY service:

```csharp
// ✅ Dynamic log document — each service can add custom fields
var logEntry = ObjectProcessor.ParseDocument(new {
    traceId = context.TraceId,
    level = "Info",
    service = "AITransform",
    message = "Transform completed",
    duration = 1250,
    aiProvider = "claude",          // AI-specific field
    tokensUsed = 3500,              // AI-specific field
    figmaNodeCount = 42,            // Figma-specific field
    timestamp = DateTime.UtcNow
});
await Database.UpsertAsync($"xiigen-logs-{DateTime.UtcNow:yyyy-MM}", logId, logEntry);
```

Any service can add any fields. No schema change. The log search (DNA-2) handles any combination.

### Log Search with BuildSearchFilter (DNA-2)
```csharp
// Search logs by any combination — empty fields auto-skipped
var filter = new { traceId = "trace_abc", level = "Error", service = "", aiProvider = "claude" };
var conditions = ObjectProcessor.BuildSearchFilter(filter);
// Result: traceId AND level AND aiProvider (service skipped because empty)
```

---

## Interface

```csharp
public interface ILoggerService
{
    Task LogAsync(Dictionary<string, object> logEntry);
    Task<DataProcessResult<List<Dictionary<string, object>>>> SearchAsync(
        Dictionary<string, object> filter, int pageSize = 50, int page = 1);
    Task<DataProcessResult<Dictionary<string, long>>> GetLevelCountsAsync(
        string service, DateTime from, DateTime to);
}
```

## Log Levels
Trace, Debug, Info, Warn, Error, Critical — stored as string field in the dynamic document.

## Index Rotation
Logs stored in monthly indices: `xiigen-logs-2026-01`, `xiigen-logs-2026-02`, etc. Old indices can be archived/deleted by retention policy.

## Event Subscriptions
Logger subscribes to events from ALL services — it's the universal event listener for audit trails.

## Alternatives
All alternatives MUST: store log entries as dynamic documents, use BuildSearchFilter for log queries, support monthly index rotation, return DataProcessResult.
