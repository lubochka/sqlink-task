<?php
// XIIGen Logger Service — PHP | Skill 22
namespace XIIGen\Platform\Logger;
use XIIGen\Core\{MicroserviceBase, IDatabaseService, IQueueService};

class LoggerService extends MicroserviceBase {
    protected string $serviceName = 'logger-service';
    public function __construct(IDatabaseService $db, IQueueService $queue) { parent::__construct($db, $queue); }

    public function log(array $entry): void {
        $entry['logId'] ??= \Ramsey\Uuid\Uuid::uuid4()->toString();
        $entry['timestamp'] ??= date('c');
        $this->storeDocument('logs', $entry['logId'], $entry);
    }

    public function info(string $traceId, string $service, string $msg, $data = null): void { $this->log(['traceId' => $traceId, 'service' => $service, 'level' => 'Info', 'message' => $msg, 'data' => $data]); }
    public function warn(string $traceId, string $service, string $msg, $data = null): void { $this->log(['traceId' => $traceId, 'service' => $service, 'level' => 'Warn', 'message' => $msg, 'data' => $data]); }
    public function error(string $traceId, string $service, string $msg, ?string $ex = null): void { $this->log(['traceId' => $traceId, 'service' => $service, 'level' => 'Error', 'message' => $msg, 'exception' => $ex]); }

    public function searchLogs(?string $traceId = null, ?string $service = null, ?string $level = null, int $limit = 50): array {
        $filter = array_filter(['traceId' => $traceId, 'service' => $service, 'level' => $level]);
        $result = $this->searchDocuments('logs', $filter, $limit);
        return $result->isSuccess ? ($result->data ?? []) : [];
    }
}
