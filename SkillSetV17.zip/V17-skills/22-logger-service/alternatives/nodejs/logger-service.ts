// XIIGen Logger Service — Node.js/TypeScript | Skill 22
import { IDatabaseService, IQueueService, MicroserviceBase } from '../../01-core-interfaces';
import { randomUUID } from 'crypto';

interface LogEntry { logId?: string; traceId?: string; service?: string; level: string; message: string; data?: any; exception?: string; timestamp?: Date; }

export class LoggerService extends MicroserviceBase {
  protected serviceName = 'logger-service';
  constructor(db: IDatabaseService, queue: IQueueService) { super(db, queue); }

  async log(entry: LogEntry): Promise<void> {
    entry.logId ??= randomUUID(); entry.timestamp ??= new Date();
    await this.storeDocument('logs', entry.logId, entry);
  }
  info(traceId: string, service: string, msg: string, data?: any) { return this.log({ traceId, service, level: 'Info', message: msg, data }); }
  warn(traceId: string, service: string, msg: string, data?: any) { return this.log({ traceId, service, level: 'Warn', message: msg, data }); }
  error(traceId: string, service: string, msg: string, ex?: string) { return this.log({ traceId, service, level: 'Error', message: msg, exception: ex }); }

  async searchLogs(traceId?: string, service?: string, level?: string, limit = 50): Promise<LogEntry[]> {
    const filter: any = {}; if (traceId) filter.traceId = traceId; if (service) filter.service = service; if (level) filter.level = level;
    const result = await this.searchDocuments('logs', filter, limit);
    return result.isSuccess ? (result.data as LogEntry[]) || [] : [];
  }
}
