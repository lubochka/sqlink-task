# XIIGen Logger Service — Python | Skill 22
import uuid
from datetime import datetime, timezone
from typing import Optional, Any
from core_interfaces import IDatabaseService, IQueueService, MicroserviceBase

class LoggerService(MicroserviceBase):
    service_name = "logger-service"
    def __init__(self, db: IDatabaseService, queue: IQueueService): super().__init__(db, queue)

    async def log(self, level: str, message: str, trace_id: str = None, service: str = None, data: Any = None, exception: str = None):
        log_id = str(uuid.uuid4())
        entry = {"logId": log_id, "traceId": trace_id, "service": service, "level": level, "message": message, "data": data, "exception": exception, "timestamp": datetime.now(timezone.utc).isoformat()}
        await self.store_document("logs", log_id, {k: v for k, v in entry.items() if v is not None})

    async def info(self, trace_id: str, service: str, msg: str, data=None): await self.log("Info", msg, trace_id, service, data)
    async def warn(self, trace_id: str, service: str, msg: str, data=None): await self.log("Warn", msg, trace_id, service, data)
    async def error(self, trace_id: str, service: str, msg: str, ex: str = None): await self.log("Error", msg, trace_id, service, exception=ex)

    async def search_logs(self, trace_id: str = None, service: str = None, level: str = None, limit: int = 50) -> list:
        filt = {k: v for k, v in {"traceId": trace_id, "service": service, "level": level}.items() if v}
        result = await self.search_documents("logs", filt, limit)
        return result.data if result.is_success else []
