// XIIGen Logger Service — Rust | Skill 22
use serde_json::{json, Value};
use uuid::Uuid;
use chrono::Utc;
use crate::core::{IDatabaseService, IQueueService, MicroserviceBase};

pub struct LoggerService { base: MicroserviceBase }

impl LoggerService {
    pub fn new(db: Box<dyn IDatabaseService>, queue: Box<dyn IQueueService>) -> Self {
        Self { base: MicroserviceBase::new(db, queue, "logger-service") }
    }

    pub async fn log(&self, level: &str, message: &str, trace_id: Option<&str>, service: Option<&str>, data: Option<Value>) {
        let log_id = Uuid::new_v4().to_string();
        let mut entry = json!({"logId": log_id, "level": level, "message": message, "timestamp": Utc::now().to_rfc3339()});
        if let Some(t) = trace_id { entry["traceId"] = json!(t); }
        if let Some(s) = service { entry["service"] = json!(s); }
        if let Some(d) = data { entry["data"] = d; }
        self.base.store_document("logs", &log_id, &entry).await;
    }

    pub async fn info(&self, trace_id: &str, service: &str, msg: &str) { self.log("Info", msg, Some(trace_id), Some(service), None).await; }
    pub async fn warn(&self, trace_id: &str, service: &str, msg: &str) { self.log("Warn", msg, Some(trace_id), Some(service), None).await; }
    pub async fn error(&self, trace_id: &str, service: &str, msg: &str) { self.log("Error", msg, Some(trace_id), Some(service), None).await; }

    pub async fn search_logs(&self, trace_id: Option<&str>, service: Option<&str>, level: Option<&str>, limit: usize) -> Vec<Value> {
        let mut filter = json!({});
        if let Some(t) = trace_id { filter["traceId"] = json!(t); }
        if let Some(s) = service { filter["service"] = json!(s); }
        if let Some(l) = level { filter["level"] = json!(l); }
        let result = self.base.search_documents("logs", &filter, limit).await;
        if result.is_success { result.data } else { vec![] }
    }
}
