// XIIGen Logger Service — Java | Skill 22
package com.xiigen.platform.logger;
import com.xiigen.core.*;
import java.time.Instant;
import java.util.*;

public class LoggerService extends MicroserviceBase {
    public LoggerService(IDatabaseService db, IQueueService queue) { super(db, queue, "logger-service"); }

    public void log(Map<String, Object> entry) throws Exception {
        entry.putIfAbsent("logId", UUID.randomUUID().toString());
        entry.putIfAbsent("timestamp", Instant.now().toString());
        storeDocument("logs", entry.get("logId").toString(), entry);
    }

    public void info(String traceId, String service, String message) throws Exception { log(new HashMap<>(Map.of("traceId", traceId, "service", service, "level", "Info", "message", message))); }
    public void warn(String traceId, String service, String message) throws Exception { log(new HashMap<>(Map.of("traceId", traceId, "service", service, "level", "Warn", "message", message))); }
    public void error(String traceId, String service, String message, String ex) throws Exception { log(new HashMap<>(Map.of("traceId", traceId, "service", service, "level", "Error", "message", message, "exception", ex != null ? ex : ""))); }

    public List<Map<String, Object>> searchLogs(String traceId, String service, String level, int limit) throws Exception {
        Map<String, Object> filter = new HashMap<>();
        if (traceId != null) filter.put("traceId", traceId); if (service != null) filter.put("service", service); if (level != null) filter.put("level", level);
        var result = searchDocuments("logs", filter, limit);
        return result.isSuccess() ? (List<Map<String, Object>>) (Object) result.getData() : List.of();
    }
}
