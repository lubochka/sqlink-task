// XIIGen.Platform.Logger/LoggerService.cs - Skill 22 | .NET 9
using Microsoft.Extensions.Logging;
using XIIGen.Core.Base;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Platform.Logger;

public class LoggerServiceImpl : MicroserviceBase
{
    public LoggerServiceImpl(IDatabaseService db, IQueueService queue, ILogger<LoggerServiceImpl> logger)
        : base(db, queue, logger) { ServiceName = "logger-service"; }

    public async Task LogStructuredAsync(LogEntry entry, CancellationToken ct = default)
    {
        entry.Timestamp ??= DateTime.UtcNow;
        entry.LogId ??= Guid.NewGuid().ToString();
        await StoreDocumentAsync("logs", entry.LogId, entry, ct: ct);
    }

    public async Task<List<LogEntry>> SearchLogsAsync(string traceId = null, string service = null, string level = null, int limit = 50, CancellationToken ct = default)
    {
        var filter = new { traceId, service, level };
        var result = await SearchDocumentsAsync("logs", filter, limit, ct);
        return result.IsSuccess ? result.Data?.Cast<LogEntry>().ToList() ?? [] : [];
    }

    protected override async Task OnStartedAsync(CancellationToken ct)
    {
        await RegisterEventHandlerAsync("xiigen.events.log.*");
        // Consume log events from all services
    }
}

public class LogEntry
{
    public string LogId { get; set; }
    public string TraceId { get; set; }
    public string Service { get; set; }
    public string Level { get; set; } // Info, Warn, Error
    public string Message { get; set; }
    public object Data { get; set; }
    public string Exception { get; set; }
    public DateTime? Timestamp { get; set; }
}
