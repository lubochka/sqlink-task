---
skill_id: "33"
name: documentation
title: "Documentation Generator"
layer: "L8: Quality Assurance"
version: "17.1"
status: "active"
priority: "P1"
dependencies: ["01-core-interfaces", "03-elasticsearch-datastore", "17-code-generator"]
alternatives_server: [docfx, typedoc, sphinx, rustdoc, phpdoc]
genie_dna:
  - "DNA-DOC: Auto-generate docs from code + dynamic document schemas"
  - "DNA-6: Documentation covers all language alternatives"
  - "DNA-RESULT: Doc generation returns DataProcessResult with coverage metrics"
triggers: documentation, docs, generate docs, API docs, code documentation, markdown, autodoc
estimated_loc: 600
---

# Skill 33: Documentation Generator
## Auto-Generate Documentation from Code, Schemas, and Flow Definitions

**Classification:** MACHINE — Doc templates are static, content is generated  
**Priority:** P1 — Required for maintainability and AI context  
**Dependencies:** Skill 01 (Core), Skill 03 (Elasticsearch), Skill 17 (Code Gen)  
**Layer:** L8: Quality Assurance  
**Estimated LOC:** ~600  

---

## Overview

The Documentation Generator auto-creates comprehensive documentation from XIIGen source code, dynamic document schemas, flow definitions, and API endpoints. It produces Markdown, HTML, and PDF output covering architecture overviews, API references, data models, flow diagrams, and deployment guides. Generated docs are stored as dynamic documents in Elasticsearch, enabling full-text search across all project documentation and RAG retrieval for AI context.

## Key Concepts

- **Schema Introspection** — Reads dynamic document schemas from Elasticsearch index mappings and code interfaces to auto-generate data model documentation.
- **Flow Documentation** — Parses flow definitions (Skill 08) and generates visual step-by-step docs with input/output specs per node.
- **Multi-Format Output** — Generates Markdown (for GitHub), HTML (for hosted docs), and PDF (for offline) from a single source model.
- **Coverage Tracking** — Measures what percentage of services, endpoints, and models have documentation. Enforces minimum coverage thresholds.
- **RAG Integration** — All generated docs are chunked and indexed for RAG retrieval (Skill 00a), enabling AI to reference documentation during code generation.

---

## DNA Integration

### Required Patterns
- **DataProcessResult** — `GenerateDocsAsync` returns coverage metrics, generated file list, and any warnings/gaps.
- **Dynamic Document** — Documentation entries stored as dynamic documents. Each doc chunk has metadata: service, section, version, language.
- **BuildSearchFilter** — Search documentation by service name, section type, version, language — empty filters skipped.
- **ObjectProcessor** — Parse code files and extract documentation comments, interface signatures, model definitions using recursive traversal.

### Anti-Patterns to AVOID
- ❌ Hand-writing documentation that duplicates code comments — auto-generate instead
- ❌ Storing docs only as files — also index in Elasticsearch for RAG
- ❌ Single-language documentation — generate for all alternative languages
- ❌ Documenting implementation details instead of interfaces — focus on contracts

---

## Primary Implementation (.NET 9)

### Models

```csharp
namespace XIIGen.Documentation.Models;

public record DocGenerationRequest(
    string ServiceId,
    string[] OutputFormats,   // markdown | html | pdf
    string[] Sections,        // architecture | api | models | flows | deployment
    string Language,          // csharp | nodejs | python | java | rust | php
    bool IncludeExamples = true,
    DateTime CreatedAt = default
);

public record DocGenerationResult(
    string ServiceId,
    List<GeneratedDoc> Documents,
    DocCoverage Coverage,
    string[] Warnings
);

public record GeneratedDoc(
    string Path,
    string Format,
    string Section,
    string Content,
    int WordCount
);

public record DocCoverage(
    int TotalEndpoints, int DocumentedEndpoints,
    int TotalModels, int DocumentedModels,
    int TotalFlows, int DocumentedFlows,
    double CoveragePercent
);
```

### Service Interface

```csharp
namespace XIIGen.Documentation.Interfaces;

public interface IDocumentationService
{
    Task<DataProcessResult<DocGenerationResult>> GenerateDocsAsync(DocGenerationRequest request, CancellationToken ct = default);
    Task<DataProcessResult<DocCoverage>> GetCoverageAsync(string serviceId, CancellationToken ct = default);
    Task<DataProcessResult<List<Dictionary<string, object>>>> SearchDocsAsync(Dictionary<string, object> filters, CancellationToken ct = default);
    Task<DataProcessResult<string>> GenerateFlowDocAsync(string flowId, string format, CancellationToken ct = default);
    Task<DataProcessResult<bool>> IndexForRagAsync(string serviceId, CancellationToken ct = default);
}
```

### Core Implementation Pattern

```csharp
public class DocumentationService : IDocumentationService
{
    private readonly IDatabaseService _db;
    private readonly ILogger<DocumentationService> _logger;

    public async Task<DataProcessResult<DocGenerationResult>> GenerateDocsAsync(
        DocGenerationRequest request, CancellationToken ct = default)
    {
        try
        {
            var sourceFiles = await IntrospectServiceAsync(request.ServiceId, ct);
            var docs = new List<GeneratedDoc>();

            foreach (var section in request.Sections)
            {
                var content = section switch
                {
                    "api" => GenerateApiDocs(sourceFiles, request.Language),
                    "models" => GenerateModelDocs(sourceFiles, request.Language),
                    "flows" => await GenerateFlowDocs(request.ServiceId, ct),
                    "architecture" => GenerateArchitectureDocs(sourceFiles),
                    "deployment" => GenerateDeploymentDocs(request.ServiceId),
                    _ => throw new ArgumentException($"Unknown section: {section}")
                };

                foreach (var format in request.OutputFormats)
                {
                    docs.Add(new GeneratedDoc(
                        $"docs/{request.ServiceId}/{section}.{format}",
                        format, section,
                        ConvertFormat(content, format),
                        content.Split(' ').Length
                    ));
                }
            }

            var coverage = CalculateCoverage(sourceFiles, docs);
            
            // DNA: Store as dynamic document for RAG
            await _db.UpsertAsync("documentation", new Dictionary<string, object>
            {
                ["id"] = $"docs-{request.ServiceId}-{DateTime.UtcNow:yyyyMMdd}",
                ["serviceId"] = request.ServiceId,
                ["documents"] = docs,
                ["coverage"] = coverage,
                ["generatedAt"] = DateTime.UtcNow
            }, ct);

            return DataProcessResult<DocGenerationResult>.Ok(
                new DocGenerationResult(request.ServiceId, docs, coverage, Array.Empty<string>()));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Doc generation failed for {ServiceId}", request.ServiceId);
            return DataProcessResult<DocGenerationResult>.Fail(ex.Message);
        }
    }
}
```

### DI Registration

```csharp
services.AddScoped<IDocumentationService, DocumentationService>();
services.AddScoped<ICodeIntrospector, CSharpIntrospector>();
services.AddScoped<IDocFormatter, MarkdownFormatter>();
```

---

## Test Scenarios

1. Generate API docs for a service with 5 endpoints → verify all 5 documented with params, returns, examples
2. Generate model docs → verify dynamic document schemas extracted correctly
3. Generate flow docs for Registration flow → verify node-by-node documentation with inputs/outputs
4. Check coverage for service missing 2 endpoint docs → verify coverage < 100% and warnings list gaps
5. Search docs by service + section → verify BuildSearchFilter pattern used
6. Index docs for RAG → verify chunks created with proper metadata for retrieval
7. Generate docs in 3 formats (md, html, pdf) → verify format conversion correct

## Component Classification
- **Category:** Documentation Automation
- **Inputs:** Service source code, flow definitions, ES index mappings
- **Outputs:** Markdown/HTML/PDF docs, coverage reports, RAG-indexed chunks
- **Side Effects:** Writes doc files, indexes in Elasticsearch
- **ES Indexes:** `documentation`, `doc-chunks` (for RAG)
