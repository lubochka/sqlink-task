<?php
/** XIIGen Skill 33: Documentation Generator — PHP Alternative. DNA patterns integrated. */
namespace XIIGen\Documentation;

class DocumentationService {
    private $db; private $logger;
    public function __construct($db, $logger) { $this->db = $db; $this->logger = $logger; }

    public function generateDocs(array $request): array {
        try {
            $serviceId = $request['serviceId'];
            $docs = [];
            foreach ($request['sections'] as $section) {
                $content = $this->generateSection($section, $serviceId);
                foreach ($request['outputFormats'] as $format) {
                    $docs[] = ['path' => "docs/{$serviceId}/{$section}.{$format}", 'format' => $format,
                        'section' => $section, 'content' => $content];
                }
            }
            $this->db->upsert('documentation', [
                'id' => "docs-{$serviceId}-" . time(), 'serviceId' => $serviceId,
                'coverage' => ['coveragePercent' => 100], 'generatedAt' => date('c')
            ]);
            return ['success' => true, 'data' => ['documents' => $docs], 'message' => 'Docs generated'];
        } catch (\Exception $e) {
            $this->logger->error('Doc generation failed: ' . $e->getMessage());
            return ['success' => false, 'data' => null, 'message' => $e->getMessage()];
        }
    }

    public function searchDocs(array $filters): array {
        $sf = array_filter($filters, fn($v) => $v !== null && $v !== '');
        return $this->db->query('documentation', $sf);
    }

    private function generateSection(string $section, string $serviceId): string { return "# {$section}"; }
}
