// XIIGen.Skills.Documentation/AutoDocService.cs | .NET 9 | Skill 33+34
// Auto-generates: API docs (Swagger), service docs, architecture diagrams, runbooks

using System.Reflection;
using System.Text;
using System.Text.Json;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using XIIGen.Core.Base;
using XIIGen.Core.Interfaces;

namespace XIIGen.Skills.Documentation;

// ═══════════════════════════════════════════════════════
// SKILL 33: AUTO DOCUMENTATION SERVICE
// ═══════════════════════════════════════════════════════

public class AutoDocService : MicroserviceBase
{
    private readonly IAiProvider _aiProvider;

    public AutoDocService(IDatabaseService db, IQueueService queue, ILogger<AutoDocService> logger,
        IAiProvider aiProvider, ICacheService cache = null)
        : base(db, queue, logger, cache)
    {
        ServiceName = "auto-doc-service";
        _aiProvider = aiProvider;
    }

    /// <summary>
    /// Generates full documentation for a service by analyzing its source code.
    /// Produces: README, API reference, architecture diagram, runbook.
    /// </summary>
    public async Task<ServiceDocumentation> GenerateServiceDocAsync(
        string serviceName, string sourceCode, string existingDocs = null, CancellationToken ct = default)
    {
        var response = await _aiProvider.ExecuteAsync(new AiRequest
        {
            SystemPrompt = DOC_SYSTEM_PROMPT,
            Prompt = $"""
                Generate comprehensive documentation for this service:
                <service_name>{serviceName}</service_name>
                <source_code>{sourceCode}</source_code>
                <existing_docs>{existingDocs ?? "none"}</existing_docs>
                """,
            MaxTokens = 8000,
            Temperature = 0.3f
        }, ct);

        var doc = ParseDocumentation(serviceName, response.Content);

        // Store in Elasticsearch for search/retrieval
        await StoreDocumentAsync("service-docs", doc.ServiceName, doc, ct: ct);
        return doc;
    }

    /// <summary>
    /// Generates architecture diagram in Mermaid syntax from flow definitions.
    /// </summary>
    public async Task<string> GenerateArchitectureDiagramAsync(
        List<FlowDefinitionSummary> flows, CancellationToken ct = default)
    {
        var sb = new StringBuilder("```mermaid\ngraph TD\n");
        foreach (var flow in flows)
        {
            sb.AppendLine($"  subgraph {flow.FlowId}[\"{flow.Name}\"]");
            foreach (var node in flow.Nodes)
                sb.AppendLine($"    {node.NodeId}[\"{node.Name}<br/>{node.NodeType}\"]");
            foreach (var edge in flow.Edges)
                sb.AppendLine($"    {edge.From} --> {edge.To}");
            sb.AppendLine("  end");
        }
        sb.AppendLine("```");
        return sb.ToString();
    }

    /// <summary>
    /// Generates runbook for incident response and operations.
    /// </summary>
    public async Task<string> GenerateRunbookAsync(string serviceName, CancellationToken ct = default)
    {
        var response = await _aiProvider.ExecuteAsync(new AiRequest
        {
            SystemPrompt = "You are a DevOps engineer writing operational runbooks.",
            Prompt = $"""
                Generate an operational runbook for the {serviceName} service covering:
                1. Service overview and dependencies
                2. Health check endpoints and expected responses
                3. Common failure modes and troubleshooting steps
                4. Scaling procedures (manual and auto)
                5. Deployment and rollback procedures
                6. Log analysis queries (Elasticsearch)
                7. Alert thresholds and escalation paths
                8. Disaster recovery steps
                Format as Markdown with clear sections and code examples.
                """,
            MaxTokens = 4000,
            Temperature = 0.3f
        }, ct);
        return response.Content;
    }

    /// <summary>
    /// Generates inline code documentation (XML comments for C#, JSDoc for TS).
    /// </summary>
    public async Task<string> GenerateInlineDocsAsync(string sourceCode, string language, CancellationToken ct = default)
    {
        var response = await _aiProvider.ExecuteAsync(new AiRequest
        {
            SystemPrompt = $"Add comprehensive {(language == "csharp" ? "XML" : "JSDoc")} documentation comments to this code. Document all public types, methods, parameters, return values, and exceptions.",
            Prompt = sourceCode,
            MaxTokens = 8000,
            Temperature = 0.2f
        }, ct);
        return response.Content;
    }

    private ServiceDocumentation ParseDocumentation(string name, string content) => new()
    {
        ServiceName = name,
        Content = content,
        GeneratedAt = DateTime.UtcNow,
        Sections = ExtractSections(content)
    };

    private List<DocSection> ExtractSections(string content)
    {
        var sections = new List<DocSection>();
        var lines = content.Split('\n');
        DocSection current = null;

        foreach (var line in lines)
        {
            if (line.StartsWith("## "))
            {
                if (current != null) sections.Add(current);
                current = new DocSection { Title = line[3..].Trim(), Content = "" };
            }
            else if (current != null)
                current.Content += line + "\n";
        }
        if (current != null) sections.Add(current);
        return sections;
    }

    private const string DOC_SYSTEM_PROMPT = """
        You are a senior technical writer. Generate comprehensive service documentation.
        Include: overview, architecture, API reference with examples, configuration,
        data models, error handling, monitoring, and troubleshooting.
        Use Mermaid diagrams for architecture. Format as Markdown.
        """;
}

public class ServiceDocumentation
{
    public string ServiceName { get; set; }
    public string Content { get; set; }
    public DateTime GeneratedAt { get; set; }
    public List<DocSection> Sections { get; set; } = [];
}
public class DocSection { public string Title { get; set; } public string Content { get; set; } }
public class FlowDefinitionSummary
{
    public string FlowId { get; set; }
    public string Name { get; set; }
    public List<NodeSummary> Nodes { get; set; } = [];
    public List<EdgeSummary> Edges { get; set; } = [];
}
public class NodeSummary { public string NodeId { get; set; } public string Name { get; set; } public string NodeType { get; set; } }
public class EdgeSummary { public string From { get; set; } public string To { get; set; } }

// ═══════════════════════════════════════════════════════
// SKILL 34: SWAGGER / OPENAPI SERVICE
// ═══════════════════════════════════════════════════════

public static class SwaggerConfiguration
{
    /// <summary>
    /// Configures Swagger/OpenAPI with full XIIGen API documentation.
    /// Call in Program.cs: builder.Services.AddXIIGenSwagger();
    /// </summary>
    public static IServiceCollection AddXIIGenSwagger(this IServiceCollection services)
    {
        services.AddEndpointsApiExplorer();
        services.AddSwaggerGen(options =>
        {
            options.SwaggerDoc("v1", new OpenApiInfo
            {
                Title = "XIIGen API",
                Version = "v1",
                Description = """
                    XIIGen Flow Orchestration API.
                    Transforms Figma designs and text descriptions into production systems
                    via multi-model AI pipelines with feedback loops and RAG context.
                    """,
                Contact = new OpenApiContact { Name = "XIIGen Team", Email = "api@xiigen.io" },
                License = new OpenApiLicense { Name = "Proprietary" }
            });

            // JWT Authentication
            options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
            {
                Description = "JWT Authorization header. Example: 'Bearer {token}'",
                Name = "Authorization",
                In = ParameterLocation.Header,
                Type = SecuritySchemeType.Http,
                Scheme = "bearer",
                BearerFormat = "JWT"
            });

            options.AddSecurityRequirement(new OpenApiSecurityRequirement
            {
                {
                    new OpenApiSecurityScheme
                    {
                        Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "Bearer" }
                    },
                    Array.Empty<string>()
                }
            });

            // Include XML comments from all assemblies
            var xmlFiles = Directory.GetFiles(AppContext.BaseDirectory, "XIIGen.*.xml");
            foreach (var xml in xmlFiles)
                options.IncludeXmlComments(xml);

            // Custom operation filters
            options.OperationFilter<TraceIdHeaderFilter>();

            // Tag grouping
            options.TagActionsBy(api => [api.GroupName ?? api.ActionDescriptor.RouteValues["controller"] ?? "General"]);
        });

        return services;
    }

    /// <summary>
    /// Maps Swagger UI and API docs endpoints.
    /// Call in Program.cs: app.UseXIIGenSwagger();
    /// </summary>
    public static WebApplication UseXIIGenSwagger(this WebApplication app)
    {
        app.UseSwagger(c => c.RouteTemplate = "api-docs/{documentName}/swagger.json");
        app.UseSwaggerUI(c =>
        {
            c.SwaggerEndpoint("/api-docs/v1/swagger.json", "XIIGen API v1");
            c.RoutePrefix = "api-docs";
            c.DocumentTitle = "XIIGen API Documentation";
            c.DefaultModelsExpandDepth(2);
            c.EnableTryItOutByDefault();
            c.DisplayRequestDuration();
        });

        // Expose OpenAPI spec as downloadable JSON
        app.MapGet("/api-docs/openapi.json", () => Results.File(
            System.Text.Encoding.UTF8.GetBytes(GenerateOpenApiSpec()),
            "application/json", "xiigen-openapi.json"));

        return app;
    }

    private static string GenerateOpenApiSpec() => JsonSerializer.Serialize(new
    {
        openapi = "3.1.0",
        info = new { title = "XIIGen API", version = "1.0.0" },
        paths = new Dictionary<string, object>
        {
            ["/api/flow/trigger"] = new
            {
                post = new
                {
                    tags = new[] { "Flow" },
                    summary = "Trigger a flow execution",
                    requestBody = new { content = new { } },
                    responses = new Dictionary<string, object>
                    {
                        ["200"] = new { description = "Flow triggered successfully" },
                        ["404"] = new { description = "Flow definition not found" }
                    }
                }
            },
            ["/api/flow/{traceId}/status"] = new
            {
                get = new
                {
                    tags = new[] { "Flow" },
                    summary = "Get flow execution status",
                    parameters = new[] { new { name = "traceId", @in = "path", required = true } }
                }
            }
        }
    }, new JsonSerializerOptions { WriteIndented = true });
}

/// <summary>
/// Swagger filter that adds X-Trace-Id header to all operations.
/// </summary>
public class TraceIdHeaderFilter : Swashbuckle.AspNetCore.SwaggerGen.IOperationFilter
{
    public void Apply(OpenApiOperation operation, Swashbuckle.AspNetCore.SwaggerGen.OperationFilterContext context)
    {
        operation.Parameters ??= new List<OpenApiParameter>();
        operation.Parameters.Add(new OpenApiParameter
        {
            Name = "X-Trace-Id",
            In = ParameterLocation.Header,
            Description = "ULID trace ID for distributed tracing",
            Required = false,
            Schema = new OpenApiSchema { Type = "string" }
        });
    }
}
