# Skill 33: Auto-Documentation — Implementation Prompt

## Phase 1: Entity Definition Scanner
Read entity definitions from ES. Extract fields, types, validation rules.

## Phase 2: Doc Generation
Auto-generate API docs from entity definitions. Field reference with types and validation.
Search guide showing which fields are searchable.

## Phase 3: Searchable Storage
Store generated docs as dynamic documents in ES. Full-text search via BuildSearchFilter.

## Phase 4: Auto-Update
When entity definition changes -> docs auto-regenerate.

---

## Genie DNA Compliance — MANDATORY
☐ DNA-1: Dynamic Documents — Dictionary<string, object>, NOT typed models
☐ DNA-2: BuildSearchFilter — skip empty fields, no entity-specific query code
☐ DNA-3: MicroserviceBase — inherit DB, queue, cache, logger
☐ DNA-5: DataProcessResult<T> — all methods return result wrapper
☐ DNA-6: Generic Interfaces — swap via config
☐ DNA-SCOPE: Non-admin queries auto-inject userId filter
