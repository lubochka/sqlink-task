---
skill_id: "20"
name: auth-service
title: "Authentication Service"
layer: "L6: Platform Services"
version: "17.0"
status: "active"
dependencies:
  - "01-core-interfaces"
  - "02-object-processor"
  - "03-elasticsearch-datastore"
  - "05-database-fabric"
dotnet_namespace: "XIIGen.Services.Auth"
di_registration: "services.AddXIIGenAuthService()"
es_index: "xiigen-users"
genie_dna:
  - "DNA-1: User profiles stored as dynamic documents (no User model class)"
  - "DNA-2: BuildSearchFilter for user lookup (email, role, status — skip empty)"
  - "DNA-3: Inherits MicroserviceBase (DB, queue, cache, logger)"
  - "DNA-5: DataProcessResult for all auth operations"
  - "DNA-MACHINE: Auth is STATIC infrastructure — trust boundary, never user-configurable"
triggers: auth, login, register, JWT, token, refresh token, password, PBKDF2, authentication
---

# Skill 20: Authentication Service
## JWT Authentication — The Trust Boundary

**Classification: MACHINE (Static)**
Auth is one of the few truly static services. Users do NOT configure auth logic — it's a trust boundary. However, user PROFILES stored by auth are dynamic documents (DNA-1).

---

## Genie DNA Integration

### Why Auth is MACHINE, Not FREEDOM
From the Freedom Machine Guide: "Only the machine that enables freedom is static." The auth SERVICE is static. But the data it stores (user profiles) follows dynamic document patterns.

### Dynamic Document Storage (DNA-1)
User records stored as `Dictionary<string, object>`, NOT as a fixed `User` model:
```csharp
// ✅ Dynamic user document — business users add custom fields without code changes
var userDoc = ObjectProcessor.ParseDocument(new {
    email, passwordHash, salt, roles = new[] { "user" }, createdAt = DateTime.UtcNow
});
await Database.UpsertAsync("xiigen-users", userId, userDoc);
```

### Scope Creation
Auth CREATES the UserScope that ALL other services consume for automatic scope isolation:
```csharp
public record UserScope(string UserId, bool IsAdmin, List<string> Roles);
// Extracted from JWT → passed to BuildSearchFilter → auto-injected into queries
```

---

## Interface

```csharp
public interface IAuthService
{
    Task<DataProcessResult<AuthTokens>> LoginAsync(string email, string password);
    Task<DataProcessResult<string>> RegisterAsync(Dictionary<string, object> userDocument);
    Task<DataProcessResult<AuthTokens>> RefreshTokenAsync(string refreshToken);
    Task<DataProcessResult<bool>> LogoutAsync(string userId, string refreshToken);
    Task<DataProcessResult<UserScope>> ExtractScopeAsync(string token);
}
```

Note: `RegisterAsync` accepts `Dictionary<string, object>` — dynamic document, not typed model.

## Security Design

| Aspect | Implementation |
|---|---|
| Password hashing | PBKDF2-SHA512, 100k iterations, 32-byte salt |
| Access token | JWT HS256, 15min expiry, userId + roles in claims |
| Refresh token | Opaque UUID, 7-day expiry, single-use rotation |
| Rate limiting | Max 5 failed logins per email per 15min |

## Events Published

| Event | Subscribers |
|---|---|
| `UserRegistered` | Permissions (grant defaults), Notifications (welcome), Logger |
| `UserLoggedIn` | Logger (audit), Monitoring (metrics) |
| `LoginFailed` | Security (threat detection), Logger (audit) |

## Alternatives
All alternatives MUST: store user profiles as dynamic documents, return DataProcessResult, use BuildSearchFilter for user queries, publish auth events.

| Language | Key Libraries |
|---|---|
| .NET 9 | System.IdentityModel.Tokens.Jwt, PBKDF2 |
| Node.js | jsonwebtoken, crypto.pbkdf2Sync |
| Python | PyJWT, hashlib.pbkdf2_hmac |
| Java | io.jsonwebtoken, PBKDF2WithHmacSHA512 |
| Rust | jsonwebtoken, pbkdf2 crate |
| PHP | Firebase\JWT, hash_pbkdf2 |
