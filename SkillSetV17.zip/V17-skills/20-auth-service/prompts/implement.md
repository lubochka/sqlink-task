# Auth Service — Implementation Prompt | Skill 20

## Phase 1: Core Interface + JWT
1. Create `IAuthService` with `GenerateTokenAsync`, `ValidateTokenAsync`
2. JWT signing (HS256) with configurable secret/expiry
3. Extend `MicroserviceBase`; `DataProcessResult<T>` for all returns

## Phase 2: Registration & Login
1. Register: PBKDF2-SHA512 + random salt, store user as dynamic doc
2. Login: verify password, generate JWT + refresh token
3. `BuildSearchFilter` for email lookup; publish auth events

## Phase 3: Token Refresh & Logout
1. Refresh token rotation: delete old, issue new pair
2. Logout: delete refresh token
3. Expiry validation with clock skew tolerance

## Phase 4: Middleware & Testing
1. ASP.NET `AuthMiddleware` extracting JWT from Authorization header
2. Rate limiting: 5 login attempts / 15min
3. Test: valid/invalid tokens, registration, login, refresh flow
4. **Genie DNA Checklist:** ☐ DataProcessResult ☐ BuildSearchFilter ☐ ParseObjectAlternative ☐ MicroserviceBase
