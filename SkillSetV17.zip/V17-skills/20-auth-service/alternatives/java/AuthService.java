// XIIGen Auth Service — Java | Skill 20
package com.xiigen.platform.auth;
import com.xiigen.core.*;
import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import java.security.SecureRandom;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.*;
import javax.crypto.SecretKey;

public class AuthService extends MicroserviceBase {
    private final SecretKey jwtKey;
    private final long tokenExpirySec;

    public AuthService(IDatabaseService db, IQueueService queue, String jwtSecret, long tokenExpirySec) {
        super(db, queue, "auth-service");
        this.jwtKey = Keys.hmacShaKeyFor(jwtSecret.getBytes());
        this.tokenExpirySec = tokenExpirySec > 0 ? tokenExpirySec : 86400;
    }

    public DataProcessResult<String> generateToken(String userId, List<String> roles) {
        String token = Jwts.builder().subject(userId).claim("roles", roles)
            .issuedAt(Date.from(Instant.now())).expiration(Date.from(Instant.now().plus(tokenExpirySec, ChronoUnit.SECONDS)))
            .signWith(jwtKey).compact();
        return DataProcessResult.success(token);
    }

    public DataProcessResult<Map<String, Object>> validateToken(String token) {
        try {
            var claims = Jwts.parser().verifyWith(jwtKey).build().parseSignedClaims(token).getPayload();
            return DataProcessResult.success(Map.of("isValid", true, "userId", claims.getSubject(), "roles", claims.get("roles", List.class)));
        } catch (JwtException e) { return DataProcessResult.success(Map.of("isValid", false)); }
    }

    public DataProcessResult<String> register(String email, String password, List<String> roles) throws Exception {
        var existing = searchDocuments("users", Map.of("email", email), 1);
        if (existing.isSuccess() && !existing.getData().isEmpty()) return DataProcessResult.failure("User exists");
        byte[] salt = new byte[16]; new SecureRandom().nextBytes(salt);
        String hash = hashPassword(password, salt);
        String userId = UUID.randomUUID().toString();
        storeDocument("users", userId, Map.of("userId", userId, "email", email,
            "passwordHash", Base64.getEncoder().encodeToString(salt) + ":" + hash, "roles", roles != null ? roles : List.of("user")));
        publishEvent("auth.user.registered", Map.of("userId", userId, "email", email));
        return DataProcessResult.success(userId);
    }

    public DataProcessResult<Map<String, String>> login(String email, String password) throws Exception {
        var result = searchDocuments("users", Map.of("email", email), 1);
        if (!result.isSuccess() || result.getData().isEmpty()) return DataProcessResult.failure("Invalid credentials");
        var user = (Map<String, Object>) result.getData().get(0);
        String[] parts = ((String) user.get("passwordHash")).split(":");
        if (!hashPassword(password, Base64.getDecoder().decode(parts[0])).equals(parts[1])) return DataProcessResult.failure("Invalid credentials");
        String token = generateToken((String) user.get("userId"), (List<String>) user.get("roles")).getData();
        String refresh = UUID.randomUUID().toString();
        storeDocument("refresh-tokens", refresh, Map.of("userId", user.get("userId"), "expiresAt", Instant.now().plus(7, ChronoUnit.DAYS).toString()));
        return DataProcessResult.success(Map.of("token", token, "refreshToken", refresh));
    }

    private String hashPassword(String password, byte[] salt) throws Exception {
        var spec = new javax.crypto.spec.PBEKeySpec(password.toCharArray(), salt, 100000, 512);
        return Base64.getEncoder().encodeToString(javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512").generateSecret(spec).getEncoded());
    }
}
