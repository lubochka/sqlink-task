// XIIGen Auth Service — Rust | Skill 20
use async_trait::async_trait;
use jsonwebtoken::{decode, encode, DecodingKey, EncodingKey, Header, Validation};
use serde::{Deserialize, Serialize};
use serde_json::json;
use crate::core::{DataProcessResult, IDatabaseService, IQueueService, MicroserviceBase};

#[derive(Debug, Serialize, Deserialize)]
struct Claims { sub: String, roles: Vec<String>, exp: u64 }

pub struct AuthService { base: MicroserviceBase, jwt_secret: String, token_expiry: u64 }

impl AuthService {
    pub fn new(db: Box<dyn IDatabaseService>, queue: Box<dyn IQueueService>, jwt_secret: String, token_expiry: Option<u64>) -> Self {
        Self { base: MicroserviceBase::new(db, queue, "auth-service"), jwt_secret, token_expiry: token_expiry.unwrap_or(86400) }
    }

    pub fn generate_token(&self, user_id: &str, roles: &[String]) -> DataProcessResult<String> {
        let now = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_secs();
        let claims = Claims { sub: user_id.to_string(), roles: roles.to_vec(), exp: now + self.token_expiry };
        match encode(&Header::default(), &claims, &EncodingKey::from_secret(self.jwt_secret.as_bytes())) {
            Ok(t) => DataProcessResult::success(t), Err(e) => DataProcessResult::failure(&e.to_string()),
        }
    }

    pub fn validate_token(&self, token: &str) -> DataProcessResult<serde_json::Value> {
        match decode::<Claims>(token, &DecodingKey::from_secret(self.jwt_secret.as_bytes()), &Validation::default()) {
            Ok(data) => DataProcessResult::success(json!({"isValid": true, "userId": data.claims.sub, "roles": data.claims.roles})),
            Err(_) => DataProcessResult::success(json!({"isValid": false})),
        }
    }

    pub async fn register(&self, email: &str, password: &str, roles: Option<Vec<String>>) -> DataProcessResult<String> {
        let existing = self.base.search_documents("users", &json!({"email": email}), 1).await;
        if existing.is_success && !existing.data.is_empty() { return DataProcessResult::failure("User already exists"); }
        let user_id = uuid::Uuid::new_v4().to_string();
        let salt: [u8; 16] = rand::random();
        let hash = format!("{}:pbkdf2hash", hex::encode(salt)); // Simplified — use argon2/pbkdf2 crate
        self.base.store_document("users", &user_id, &json!({"userId": user_id, "email": email, "passwordHash": hash, "roles": roles.unwrap_or(vec!["user".into()])})).await;
        self.base.publish_event("auth.user.registered", &json!({"userId": user_id})).await;
        DataProcessResult::success(user_id)
    }
}
