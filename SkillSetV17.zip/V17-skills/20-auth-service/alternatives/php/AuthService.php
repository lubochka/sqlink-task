<?php
// XIIGen Auth Service — PHP | Skill 20
namespace XIIGen\Platform\Auth;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use XIIGen\Core\{MicroserviceBase, DataProcessResult, IDatabaseService, IQueueService};

class AuthService extends MicroserviceBase {
    protected string $serviceName = 'auth-service';
    private string $jwtSecret;
    private int $tokenExpiry;

    public function __construct(IDatabaseService $db, IQueueService $queue, string $jwtSecret, int $tokenExpiry = 86400) {
        parent::__construct($db, $queue);
        $this->jwtSecret = $jwtSecret;
        $this->tokenExpiry = $tokenExpiry;
    }

    public function generateToken(string $userId, array $roles): DataProcessResult {
        $payload = ['sub' => $userId, 'roles' => $roles, 'iat' => time(), 'exp' => time() + $this->tokenExpiry];
        return DataProcessResult::success(JWT::encode($payload, $this->jwtSecret, 'HS256'));
    }

    public function validateToken(string $token): DataProcessResult {
        try {
            $decoded = JWT::decode($token, new Key($this->jwtSecret, 'HS256'));
            return DataProcessResult::success(['isValid' => true, 'userId' => $decoded->sub, 'roles' => $decoded->roles ?? []]);
        } catch (\Exception $e) { return DataProcessResult::success(['isValid' => false]); }
    }

    public function register(string $email, string $password, array $roles = ['user']): DataProcessResult {
        $existing = $this->searchDocuments('users', ['email' => $email], 1);
        if ($existing->isSuccess && !empty($existing->data)) return DataProcessResult::failure('User already exists');
        $salt = bin2hex(random_bytes(16));
        $hash = hash_pbkdf2('sha512', $password, $salt, 100000, 128);
        $userId = \Ramsey\Uuid\Uuid::uuid4()->toString();
        $this->storeDocument('users', $userId, ['userId' => $userId, 'email' => $email, 'passwordHash' => "$salt:$hash", 'roles' => $roles]);
        $this->publishEvent('auth.user.registered', ['userId' => $userId, 'email' => $email]);
        return DataProcessResult::success($userId);
    }

    public function login(string $email, string $password): DataProcessResult {
        $result = $this->searchDocuments('users', ['email' => $email], 1);
        if (!$result->isSuccess || empty($result->data)) return DataProcessResult::failure('Invalid credentials');
        $user = $result->data[0];
        [$salt, $storedHash] = explode(':', $user['passwordHash']);
        if (hash_pbkdf2('sha512', $password, $salt, 100000, 128) !== $storedHash) return DataProcessResult::failure('Invalid credentials');
        $token = $this->generateToken($user['userId'], $user['roles'] ?? ['user'])->data;
        $refresh = bin2hex(random_bytes(48));
        $this->storeDocument('refresh-tokens', $refresh, ['userId' => $user['userId'], 'expiresAt' => date('c', time() + 604800)]);
        return DataProcessResult::success(['token' => $token, 'refreshToken' => $refresh]);
    }
}
