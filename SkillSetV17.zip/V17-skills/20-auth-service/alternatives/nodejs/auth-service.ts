// XIIGen Auth Service — Node.js/TypeScript | Skill 20
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import { IDatabaseService, IQueueService, DataProcessResult, MicroserviceBase } from '../../01-core-interfaces';

export class AuthService extends MicroserviceBase {
  private jwtSecret: string;
  private tokenExpiry: number;
  protected serviceName = 'auth-service';

  constructor(db: IDatabaseService, queue: IQueueService, config: { jwtSecret: string; tokenExpiry?: number }) {
    super(db, queue);
    this.jwtSecret = config.jwtSecret;
    this.tokenExpiry = config.tokenExpiry || 86400;
  }

  async generateToken(userId: string, roles: string[]): Promise<DataProcessResult<string>> {
    const token = jwt.sign({ sub: userId, roles }, this.jwtSecret, { expiresIn: this.tokenExpiry });
    return DataProcessResult.success(token);
  }

  async validateToken(token: string): Promise<DataProcessResult<{ isValid: boolean; userId?: string; roles?: string[] }>> {
    try {
      const decoded = jwt.verify(token, this.jwtSecret) as any;
      return DataProcessResult.success({ isValid: true, userId: decoded.sub, roles: decoded.roles || [] });
    } catch { return DataProcessResult.success({ isValid: false }); }
  }

  async register(email: string, password: string, roles = ['user']): Promise<DataProcessResult<string>> {
    const existing = await this.searchDocuments('users', { email }, 1);
    if (existing.isSuccess && existing.data?.length) return DataProcessResult.failure('User already exists');
    const salt = crypto.randomBytes(16).toString('hex');
    const hash = crypto.pbkdf2Sync(password, salt, 100000, 64, 'sha512').toString('hex');
    const userId = crypto.randomUUID();
    await this.storeDocument('users', userId, { userId, email, passwordHash: `${salt}:${hash}`, roles, createdAt: new Date() });
    await this.publishEvent('auth.user.registered', { userId, email });
    return DataProcessResult.success(userId);
  }

  async login(email: string, password: string): Promise<DataProcessResult<{ token: string; refreshToken: string }>> {
    const result = await this.searchDocuments('users', { email }, 1);
    if (!result.isSuccess || !result.data?.length) return DataProcessResult.failure('Invalid credentials');
    const user = result.data[0] as any;
    const [salt, storedHash] = user.passwordHash.split(':');
    const verify = crypto.pbkdf2Sync(password, salt, 100000, 64, 'sha512').toString('hex');
    if (verify !== storedHash) return DataProcessResult.failure('Invalid credentials');
    const token = jwt.sign({ sub: user.userId, roles: user.roles }, this.jwtSecret, { expiresIn: this.tokenExpiry });
    const refreshToken = crypto.randomBytes(48).toString('hex');
    await this.storeDocument('refresh-tokens', refreshToken, { userId: user.userId, expiresAt: new Date(Date.now() + 7 * 86400000) });
    return DataProcessResult.success({ token, refreshToken });
  }

  async refreshToken(token: string): Promise<DataProcessResult<{ token: string; refreshToken: string }>> {
    const stored = await this.getDocument('refresh-tokens', token) as any;
    if (!stored || new Date(stored.expiresAt) < new Date()) return DataProcessResult.failure('Invalid refresh token');
    await this.deleteDocument('refresh-tokens', token);
    const user = await this.getDocument('users', stored.userId) as any;
    const newToken = jwt.sign({ sub: user.userId, roles: user.roles }, this.jwtSecret, { expiresIn: this.tokenExpiry });
    const newRefresh = crypto.randomBytes(48).toString('hex');
    await this.storeDocument('refresh-tokens', newRefresh, { userId: user.userId, expiresAt: new Date(Date.now() + 7 * 86400000) });
    return DataProcessResult.success({ token: newToken, refreshToken: newRefresh });
  }

  async logout(refreshToken: string): Promise<DataProcessResult<boolean>> {
    await this.deleteDocument('refresh-tokens', refreshToken);
    return DataProcessResult.success(true);
  }
}
