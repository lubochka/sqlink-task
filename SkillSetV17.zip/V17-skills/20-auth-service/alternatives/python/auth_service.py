# XIIGen Auth Service — Python | Skill 20
import jwt, hashlib, secrets, uuid
from datetime import datetime, timedelta, timezone
from typing import Optional
from core_interfaces import IDatabaseService, IQueueService, DataProcessResult, MicroserviceBase

class AuthService(MicroserviceBase):
    service_name = "auth-service"

    def __init__(self, db: IDatabaseService, queue: IQueueService, jwt_secret: str, token_expiry: int = 86400):
        super().__init__(db, queue)
        self._jwt_secret = jwt_secret
        self._token_expiry = token_expiry

    async def generate_token(self, user_id: str, roles: list[str]) -> DataProcessResult:
        payload = {"sub": user_id, "roles": roles, "exp": datetime.now(timezone.utc) + timedelta(seconds=self._token_expiry)}
        return DataProcessResult.success(jwt.encode(payload, self._jwt_secret, algorithm="HS256"))

    async def validate_token(self, token: str) -> DataProcessResult:
        try:
            decoded = jwt.decode(token, self._jwt_secret, algorithms=["HS256"])
            return DataProcessResult.success({"isValid": True, "userId": decoded["sub"], "roles": decoded.get("roles", [])})
        except jwt.InvalidTokenError:
            return DataProcessResult.success({"isValid": False})

    async def register(self, email: str, password: str, roles: list[str] = None) -> DataProcessResult:
        existing = await self.search_documents("users", {"email": email}, limit=1)
        if existing.is_success and existing.data: return DataProcessResult.failure("User already exists")
        salt = secrets.token_hex(16)
        pw_hash = hashlib.pbkdf2_hmac("sha512", password.encode(), salt.encode(), 100000).hex()
        user_id = str(uuid.uuid4())
        await self.store_document("users", user_id, {"userId": user_id, "email": email, "passwordHash": f"{salt}:{pw_hash}", "roles": roles or ["user"]})
        await self.publish_event("auth.user.registered", {"userId": user_id, "email": email})
        return DataProcessResult.success(user_id)

    async def login(self, email: str, password: str) -> DataProcessResult:
        result = await self.search_documents("users", {"email": email}, limit=1)
        if not result.is_success or not result.data: return DataProcessResult.failure("Invalid credentials")
        user = result.data[0]
        salt, stored_hash = user["passwordHash"].split(":")
        verify = hashlib.pbkdf2_hmac("sha512", password.encode(), salt.encode(), 100000).hex()
        if verify != stored_hash: return DataProcessResult.failure("Invalid credentials")
        token_result = await self.generate_token(user["userId"], user.get("roles", []))
        refresh = secrets.token_hex(48)
        await self.store_document("refresh-tokens", refresh, {"userId": user["userId"], "expiresAt": (datetime.now(timezone.utc) + timedelta(days=7)).isoformat()})
        return DataProcessResult.success({"token": token_result.data, "refreshToken": refresh})
