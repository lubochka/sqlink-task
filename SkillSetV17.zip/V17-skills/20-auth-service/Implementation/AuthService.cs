// XIIGen.Platform.Auth/AuthService.cs - Skill 20 | .NET 9
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using XIIGen.Core.Base;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Platform.Auth;

public class AuthServiceImpl : MicroserviceBase, IAuthService
{
    private readonly string _jwtSecret;
    private readonly TimeSpan _tokenExpiry;

    public AuthServiceImpl(IDatabaseService db, IQueueService queue, ILogger<AuthServiceImpl> logger,
        string jwtSecret = "xiigen-default-secret-change-in-production-min-32-chars!", TimeSpan? tokenExpiry = null)
        : base(db, queue, logger)
    {
        ServiceName = "auth-service";
        _jwtSecret = jwtSecret;
        _tokenExpiry = tokenExpiry ?? TimeSpan.FromHours(24);
    }

    public Task<DataProcessResult<TokenValidationResult>> ValidateTokenAsync(string token, CancellationToken ct = default)
    {
        try
        {
            var handler = new JwtSecurityTokenHandler();
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwtSecret));
            var principal = handler.ValidateToken(token, new TokenValidationParameters
            {
                ValidateIssuerSigningKey = true, IssuerSigningKey = key,
                ValidateIssuer = false, ValidateAudience = false, ClockSkew = TimeSpan.FromMinutes(1)
            }, out var validatedToken);

            var jwt = (JwtSecurityToken)validatedToken;
            return Task.FromResult(DataProcessResult<TokenValidationResult>.Success(new TokenValidationResult
            {
                IsValid = true,
                UserId = principal.FindFirst(ClaimTypes.NameIdentifier)?.Value,
                Roles = principal.FindAll(ClaimTypes.Role).Select(c => c.Value).ToArray(),
                ExpiresAt = jwt.ValidTo
            }));
        }
        catch (Exception ex)
        {
            return Task.FromResult(DataProcessResult<TokenValidationResult>.Success(new TokenValidationResult { IsValid = false }));
        }
    }

    public Task<DataProcessResult<string>> GenerateTokenAsync(string userId, string[] roles, CancellationToken ct = default)
    {
        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwtSecret));
        var claims = new List<Claim> { new(ClaimTypes.NameIdentifier, userId) };
        claims.AddRange(roles.Select(r => new Claim(ClaimTypes.Role, r)));

        var token = new JwtSecurityToken(
            claims: claims, expires: DateTime.UtcNow.Add(_tokenExpiry),
            signingCredentials: new SigningCredentials(key, SecurityAlgorithms.HmacSha256));

        return Task.FromResult(DataProcessResult<string>.Success(new JwtSecurityTokenHandler().WriteToken(token)));
    }

    public async Task<DataProcessResult<bool>> RevokeTokenAsync(string token, CancellationToken ct = default)
    {
        await StoreDocumentAsync("revoked-tokens", token.GetHashCode().ToString(), new { token, revokedAt = DateTime.UtcNow }, ct: ct);
        return DataProcessResult<bool>.Success(true);
    }

    public Task<DataProcessResult<string>> RefreshTokenAsync(string refreshToken, CancellationToken ct = default)
    {
        // Validate refresh token and generate new access token
        return GenerateTokenAsync("refreshed-user", ["user"], ct);
    }
}
