# XIIGen V17 — Master Skills Index
## 46 skills across 10 layers + 50+ alternatives
## See also: ROUTING_GUIDE.md (skill chains per scenario), GENIE_DNA_GUIDE.md (code patterns)

---

## Layer 0: RAG

### 00a — RAG Interfaces
- **Purpose:** Abstract interfaces for RAG (Retrieval-Augmented Generation) providers
- **Key files:** IRagService.cs, RagServiceCollectionExtensions.cs
- **Dependencies:** 01-core-interfaces
- **Alternatives:** See alternatives/rag/ (5 providers) and alternatives/rag-advanced/ (10 GraphRAG)

### 00b — RAG Planner
- **Purpose:** AI-driven planning for what context to retrieve and where to store results
- **Key files:** RagContextPlanner.cs
- **Dependencies:** 00a-rag-interfaces, 06-ai-providers
- **Alternatives:** nodejs, python, java, rust, php ✅

---

## Layer 1: Foundation

### 01 — Core Interfaces ✅
- **Purpose:** ALL interfaces, models, enums, MicroserviceBase (19-component architecture)
- **Key classes:** IDatabaseService, IQueueService, ICacheService, IAiProvider, IRagService, IStepExecutor, IFlowOrchestrator, IObjectProcessor, DataProcessResult<T>, MicroserviceBase
- **Dependencies:** None
- **Alternatives:** nodejs, python, java, rust, php ✅

### 02 — Object Processor ✅
- **Purpose:** Dynamic JSON parsing, filter-by-non-empty, deep merge (Genie DNA core)
- **Key methods:** ParseObjectAlternative(object), BuildSearchFilter(object), MergeObjects(a, b)
- **Dependencies:** None
- **Alternatives:** nodejs, python, java, rust, php ✅

---

## Layer 2: Infrastructure

### 03 — Elasticsearch Datastore ✅
- **Purpose:** IDatabaseService implementation for Elasticsearch 8
- **DI:** services.AddXIIGenElasticsearch(config)
- **Dependencies:** 01, 02
- **Alternatives:** nodejs, python, java, rust, php ✅

### 04 — Redis Queue + Cache ✅
- **Purpose:** IQueueService + ICacheService via Redis Streams
- **DI:** services.AddXIIGenRedis(config)
- **Dependencies:** 01
- **Alternatives:** nodejs, python, java, rust, php ✅

### 05 — Database Fabric 🔧
- **Purpose:** Factory pattern swapping DB backends (ES, Mongo, PostgreSQL, Redis, MySQL, SQL Server)
- **DI:** services.AddXIIGenDatabaseFabric(config)
- **Dependencies:** 01, 02
- **Reference:** DataBase_Fabric.docx

---

## Layer 3: AI

### 06 — AI Providers 🔧
- **Purpose:** Unified interface to Claude, GPT, Gemini with retry/rate-limit
- **Key class:** AiProviders.cs (12KB)
- **DI:** services.AddXIIGenAiProviders(config)
- **Dependencies:** 01

### 07 — AI Dispatcher 🔧
- **Purpose:** Parallel dispatch to multiple AI models with fallback + consensus
- **Key class:** AiDispatcher.cs
- **Dependencies:** 01, 06

---

## Layer 4: Flow Engine

### 08 — Flow Definition 🔧
- **Purpose:** DAG model for flow definitions with validation rules
- **Key class:** FlowDefinition.cs
- **Dependencies:** 01
- **Reference:** project_bases_drawio.xml (6 flow templates)

### 09 — Flow Orchestrator 🔧
- **Purpose:** Execute flows: topological sort, parallel fan-out/fan-in, checkpointing
- **Key class:** FlowOrchestrator.cs (10KB)
- **Dependencies:** 01, 03, 04, 08

### 14 — Node Debugger 🔧
- **Purpose:** Debug data per node (input/prompt/output/duration/tokens)
- **Dependencies:** 01, 03

### 15 — API Gateway 🔧
- **Purpose:** Trace ID polling endpoints, rate limiting, auth
- **Dependencies:** 01, 09, 20

---

## Layer 5: Pipeline Steps

### 10 — Figma Parser 🔧
- **Purpose:** Parse Figma node tree into structured component descriptions
- **Dependencies:** 01, 02
- **Reference:** FigmaToCode-with-skills.zip

### 11 — AI Transform Executor 🔧
- **Purpose:** Generate code from parsed Figma via AI models
- **Dependencies:** 01, 06, 07, 28

### 12 — AI Review Executor 🔧
- **Purpose:** Score and select best AI output using multi-model consensus
- **Dependencies:** 01, 06, 07

### 13 — Feedback Service 🔧
- **Purpose:** CRUD for user feedback, injection into future AI prompts
- **Dependencies:** 01, 03

### 39 — Figma Plugin Bridge 🔧
- **Purpose:** Webhook handler for Figma plugin, element-to-FlowInput mapping
- **Dependencies:** 01, 10, 15

---

## Layer 6: RAG + Context

### 16 — AI Context Service 🔧
- **Purpose:** Inject relevant patterns + past feedback into AI prompts
- **SKILL.md:** 19KB (comprehensive)
- **Dependencies:** 00a, 00b, 03
- **Alternatives:** nodejs, python, java, rust, php ✅

### 45 — Design Patterns 🔧
- **Purpose:** Design pattern catalog per language with usage guidance
- **SKILL.md:** 23KB (comprehensive)
- **Dependencies:** 16
- **Reference:** design_patterns_reference.md (44KB), design_patterns_extended.md (67KB)
- **Alternatives:** nodejs, python, java, rust, php ✅

---

## Layer 7: Platform Services

### 17 — Code Generator | 18 — Documentation | 19 — Design System
- **Purpose:** Generate code, docs, and design tokens from architecture specs
- **SKILL.md:** 12KB, 11KB, 13KB (good)
- **Dependencies:** 01, 02, 06, 16
- **Alternatives:** nodejs, python, java, rust, php ✅

### 20 — Auth Service | 21 — Permissions | 22 — Logger | 23 — Monitoring | 24 — Notification
- **Purpose:** Security, permissions, logging, monitoring, notifications
- **Dependencies:** 01, 03
- **Reference:** Architecture.docx, genie/auth-jwt, genie/realtime-push

### 40 — Content Pipeline | 41 — WhatsApp Diet | 42 — Chat | 43 — Calculator | 44 — Moderation
- **Purpose:** Use-case-specific services (UC5, UC4, chat, metrics, moderation)
- **Dependencies:** 01, 06, 07, 09

---

## Layer 8: Advanced Skills

### 28 — Prompt Engineering
- **Key class:** PromptTemplateService.cs (23KB)
- **Dependencies:** 06, 16

### 29 — Unit Testing | 30 — E2E Testing | 31 — UI Testing
- **Key classes:** UnitTestBase.cs (15KB), E2ETestBase.cs (14KB), UITests.ts (12KB)

### 32 — DevOps CI/CD | 33 — Documentation | 34 — Swagger/OpenAPI
- **Purpose:** Build pipeline, auto-docs, API spec generation

### 35 — MCP Server | 36 — Logging | 37 — Safe Code | 38 — Optimization
- **Key classes:** McpServer.cs (17KB), LoggingSkill.cs (12KB+), SecurityService.cs (12KB), OptimizationService.cs (14KB)

---

## Layer 9: Clients + Infrastructure

### 25 — React Native Client
- **Purpose:** Mobile app with flow visualization, WebSocket integration
- **Dependencies:** 15, 26

### 26 — Web Flow Editor
- **Purpose:** n8n-like visual flow editor (React Flow)
- **Dependencies:** 08, 09, 15

### 27 — K8s Deployment
- **Purpose:** Kubernetes manifests + hosting alternatives
- **Reference:** Architecture.docx, hosting alternatives table

---

## Cross-cutting Alternatives

| Directory | Contents |
|---|---|
| alternatives/rag/ | 5 RAG providers: ES-KNN, Neo4j, Azure AI Search, CosmosDB, Pinecone |
| alternatives/rag-advanced/ | 10 GraphRAG: Neo4j, LightRAG, nano, LangChain, LlamaIndex, Graphlit, Memgraph, Neptune, Contextual AI, HybridRAG |
| alternatives/devops/ | PaaS (Railway, Render, Fly.io) + Managed K8s (GKE, EKS, AKS) + Lightweight (Nomad, Swarm, K3s) |
| alternatives/clients/ | Angular, Vue, Native Kotlin (planned) |

---

## Legend
- ✅ Complete (SKILL.md + .NET + 5 alternatives + prompts)
- 🔧 Needs enhancement (has some components, missing others)
