<?php
// XIIGen Skill 29 — Unit Test Generator | PHP
// Generates PHPUnit test suites from source code analysis.
namespace XIIGen\Skills\UnitTesting;

use XIIGen\Core\Interfaces\DataProcessResult;
use XIIGen\Core\Processor\ObjectProcessor;

class TestConfig {
    public function __construct(
        public string $framework = 'phpunit',
        public int $coverageTarget = 80,
        public bool $generateMocks = true,
        public bool $generateEdgeCases = true,
    ) {}
}

class TestFile {
    public function __construct(
        public string $path, public string $content,
        public int $testCount, public string $category,
    ) {}
}

class TestSuite {
    public function __construct(
        public string $sourceFile, public array $testFiles,
        public int $totalTests, public float $estimatedCoverage,
    ) {}
}

class UnitTestGenerator {
    public function generateTests(string $sourceCode, string $language = 'php', ?TestConfig $config = null): DataProcessResult {
        $config ??= new TestConfig();
        try {
            $methods = $this->analyzeMethods($sourceCode);
            $testFiles = [];
            $testFiles[] = $this->generateHappyPath($methods);
            $testFiles[] = $this->generateErrorTests($methods);
            if ($config->generateEdgeCases) $testFiles[] = $this->generateEdgeCases($methods);
            if ($config->generateMocks) {
                $deps = array_unique(array_merge(...array_map(fn($m) => $m['dependencies'], $methods)));
                if (!empty($deps)) $testFiles[] = $this->generateMockSetup($deps);
            }
            $total = array_sum(array_map(fn($f) => $f->testCount, $testFiles));
            return DataProcessResult::success(new TestSuite('source.php', $testFiles, $total, min($config->coverageTarget, 85)));
        } catch (\Throwable $e) {
            return DataProcessResult::failure("Generation failed: " . $e->getMessage());
        }
    }

    private function analyzeMethods(string $code): array {
        preg_match_all('/(?:public|protected)\s+function\s+(\w+)\s*\(([^)]*)\)\s*(?::\s*(\w+))?/', $code, $matches, PREG_SET_ORDER);
        return array_map(function($m) {
            $params = array_filter(array_map(function($p) {
                $p = trim($p);
                if (empty($p)) return null;
                preg_match('/(?:(\w+)\s+)?(\$\w+)/', $p, $parts);
                return ['type' => $parts[1] ?? 'mixed', 'name' => $parts[2] ?? '$arg'];
            }, explode(',', $m[2])));
            return ['name' => $m[1], 'params' => array_values($params), 'returnType' => $m[3] ?? 'mixed', 'dependencies' => []];
        }, $matches);
    }

    private function generateHappyPath(array $methods): TestFile {
        $lines = ["<?php\nclass HappyPathTest extends TestCase {"];
        foreach ($methods as $m) {
            $args = implode(', ', array_map(fn($p) => $this->getTestValue($p['type']), $m['params']));
            $lines[] = "    public function test_{$m['name']}_success() {";
            $lines[] = "        \$result = \$this->service->{$m['name']}($args);";
            $lines[] = "        \$this->assertTrue(\$result->success);";
            $lines[] = "    }";
        }
        $lines[] = "}";
        return new TestFile('HappyPathTest.php', implode("\n", $lines), count($methods), 'happy-path');
    }

    private function generateErrorTests(array $methods): TestFile {
        $lines = ["<?php\nclass ErrorTest extends TestCase {"]; $count = 0;
        foreach ($methods as $m) {
            if (!empty($m['params'])) {
                $lines[] = "    public function test_{$m['name']}_null_input() {";
                $lines[] = "        \$result = \$this->service->{$m['name']}(null);";
                $lines[] = "        \$this->assertFalse(\$result->success);";
                $lines[] = "    }";
                $count++;
            }
        }
        $lines[] = "}";
        return new TestFile('ErrorTest.php', implode("\n", $lines), $count, 'error');
    }

    private function generateEdgeCases(array $methods): TestFile {
        $lines = ["<?php\nclass EdgeCaseTest extends TestCase {"]; $count = 0;
        foreach ($methods as $m) {
            foreach ($m['params'] as $p) {
                if (in_array($p['type'], ['string', 'mixed'])) {
                    $lines[] = "    public function test_{$m['name']}_empty_{$p['name']}() {";
                    $lines[] = "        \$result = \$this->service->{$m['name']}('');";
                    $lines[] = "        \$this->assertNotNull(\$result);";
                    $lines[] = "    }";
                    $count++;
                }
            }
        }
        $lines[] = "}";
        return new TestFile('EdgeCaseTest.php', implode("\n", $lines), $count, 'edge-case');
    }

    private function generateMockSetup(array $deps): TestFile {
        $lines = ["<?php\n// Mock setup"];
        foreach ($deps as $dep) {
            $lines[] = "\$mock$dep = \$this->createMock({$dep}::class);";
            $lines[] = "\$mock$dep->method('query')->willReturn(DataProcessResult::success([]));";
        }
        return new TestFile('MockSetup.php', implode("\n", $lines), 0, 'mock');
    }

    private function getTestValue(string $type): string {
        return match($type) { 'string' => "'test'", 'int','float' => '42', 'bool' => 'true', default => "'test'" };
    }
}
