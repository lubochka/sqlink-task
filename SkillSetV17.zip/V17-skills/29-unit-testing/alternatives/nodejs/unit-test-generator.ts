// XIIGen Skill 29 — Unit Test Generator | Node.js/TypeScript
// Generates Jest test suites from source code analysis.

import { DataProcessResult } from '../../01-core-interfaces';
import { ObjectProcessor } from '../../02-object-processor';

export interface TestConfig {
  framework: 'jest' | 'mocha' | 'vitest';
  coverageTarget: number;
  generateMocks: boolean;
  generateEdgeCases: boolean;
}

export interface TestSuite {
  sourceFile: string;
  testFiles: TestFile[];
  totalTests: number;
  estimatedCoverage: number;
}

export interface TestFile {
  path: string;
  content: string;
  testCount: number;
  category: 'happy-path' | 'error' | 'edge-case' | 'mock';
}

interface MethodAnalysis {
  name: string;
  params: { name: string; type: string }[];
  returnType: string;
  isAsync: boolean;
  dependencies: string[];
}

export class UnitTestGenerator {
  async generateTests(
    sourceCode: string, language: string, config: TestConfig = { framework: 'jest', coverageTarget: 80, generateMocks: true, generateEdgeCases: true }
  ): Promise<DataProcessResult<TestSuite>> {
    try {
      const methods = this.analyzeMethods(sourceCode);
      const testFiles: TestFile[] = [];

      // Happy path tests
      testFiles.push(this.generateHappyPathTests(methods, config));

      // Error handling tests
      testFiles.push(this.generateErrorTests(methods, config));

      // Edge case tests
      if (config.generateEdgeCases) {
        testFiles.push(this.generateEdgeCaseTests(methods, config));
      }

      // Mock setup
      if (config.generateMocks) {
        const deps = [...new Set(methods.flatMap(m => m.dependencies))];
        if (deps.length > 0) testFiles.push(this.generateMockSetup(deps));
      }

      const suite: TestSuite = {
        sourceFile: 'source',
        testFiles,
        totalTests: testFiles.reduce((sum, f) => sum + f.testCount, 0),
        estimatedCoverage: Math.min(config.coverageTarget, methods.length > 0 ? 85 : 0),
      };
      return { success: true, data: suite };
    } catch (err) {
      return { success: false, error: `Generation failed: ${(err as Error).message}` };
    }
  }

  private analyzeMethods(code: string): MethodAnalysis[] {
    const methods: MethodAnalysis[] = [];
    const regex = /(?:async\s+)?(?:function\s+|(?:public|private|protected)\s+)?(\w+)\s*\(([^)]*)\)\s*(?::\s*(\w+[<>\[\]]*))?\s*\{/g;
    let match: RegExpExecArray | null;
    while ((match = regex.exec(code)) !== null) {
      const [, name, paramsStr, returnType] = match;
      if (['if', 'for', 'while', 'switch', 'catch'].includes(name)) continue;
      const params = paramsStr.split(',').filter(Boolean).map(p => {
        const parts = p.trim().split(/[:\s]+/);
        return { name: parts[0], type: parts[1] || 'unknown' };
      });
      methods.push({
        name, params, returnType: returnType || 'void',
        isAsync: code.substring(Math.max(0, match.index - 10), match.index).includes('async'),
        dependencies: this.extractDependencies(code, name),
      });
    }
    return methods;
  }

  private extractDependencies(code: string, methodName: string): string[] {
    const deps: string[] = [];
    const depPatterns = [/this\.(\w+Service)/g, /this\.(\w+Repository)/g, /this\.(\w+Provider)/g];
    for (const pattern of depPatterns) {
      let m: RegExpExecArray | null;
      while ((m = pattern.exec(code)) !== null) deps.push(m[1]);
    }
    return [...new Set(deps)];
  }

  private generateHappyPathTests(methods: MethodAnalysis[], config: TestConfig): TestFile {
    const lines: string[] = ["describe('Happy Path Tests', () => {"];
    for (const m of methods) {
      lines.push(`  it('${m.name} returns expected result', ${m.isAsync ? 'async ' : ''}() => {`);
      lines.push(`    const result = ${m.isAsync ? 'await ' : ''}service.${m.name}(${m.params.map(p => this.getTestValue(p.type)).join(', ')});`);
      lines.push(`    expect(result).toBeDefined();`);
      lines.push(`    expect(result.success).toBe(true);`);
      lines.push(`  });`);
    }
    lines.push('});');
    return { path: 'happy-path.test.ts', content: lines.join('\n'), testCount: methods.length, category: 'happy-path' };
  }

  private generateErrorTests(methods: MethodAnalysis[], config: TestConfig): TestFile {
    const lines: string[] = ["describe('Error Handling Tests', () => {"];
    for (const m of methods) {
      if (m.params.length > 0) {
        lines.push(`  it('${m.name} handles null input', ${m.isAsync ? 'async ' : ''}() => {`);
        lines.push(`    const result = ${m.isAsync ? 'await ' : ''}service.${m.name}(${m.params.map(() => 'null').join(', ')});`);
        lines.push(`    expect(result.success).toBe(false);`);
        lines.push(`  });`);
      }
      for (const dep of m.dependencies) {
        lines.push(`  it('${m.name} handles ${dep} failure', ${m.isAsync ? 'async ' : ''}() => {`);
        lines.push(`    mock${dep}.mockRejectedValueOnce(new Error('Service unavailable'));`);
        lines.push(`    const result = ${m.isAsync ? 'await ' : ''}service.${m.name}(${m.params.map(p => this.getTestValue(p.type)).join(', ')});`);
        lines.push(`    expect(result.success).toBe(false);`);
        lines.push(`  });`);
      }
    }
    lines.push('});');
    return { path: 'error.test.ts', content: lines.join('\n'), testCount: methods.length * 2, category: 'error' };
  }

  private generateEdgeCaseTests(methods: MethodAnalysis[], config: TestConfig): TestFile {
    const lines: string[] = ["describe('Edge Case Tests', () => {"];
    for (const m of methods) {
      for (const p of m.params) {
        if (p.type === 'string') {
          lines.push(`  it('${m.name} handles empty string for ${p.name}', async () => {`);
          lines.push(`    const result = await service.${m.name}('');`);
          lines.push(`    expect(result).toBeDefined();`);
          lines.push(`  });`);
        }
        if (p.type === 'number') {
          lines.push(`  it('${m.name} handles zero for ${p.name}', async () => {`);
          lines.push(`    const result = await service.${m.name}(0);`);
          lines.push(`    expect(result).toBeDefined();`);
          lines.push(`  });`);
        }
      }
    }
    lines.push('});');
    return { path: 'edge-cases.test.ts', content: lines.join('\n'), testCount: methods.length * 2, category: 'edge-case' };
  }

  private generateMockSetup(deps: string[]): TestFile {
    const lines: string[] = ['// Auto-generated mock setup'];
    for (const dep of deps) {
      lines.push(`const mock${dep} = {`);
      lines.push(`  query: jest.fn().mockResolvedValue({ success: true, data: [] }),`);
      lines.push(`  upsert: jest.fn().mockResolvedValue({ success: true }),`);
      lines.push(`  delete: jest.fn().mockResolvedValue({ success: true }),`);
      lines.push(`};`);
    }
    lines.push(`export { ${deps.map(d => `mock${d}`).join(', ')} };`);
    return { path: '__mocks__/setup.ts', content: lines.join('\n'), testCount: 0, category: 'mock' };
  }

  private getTestValue(type: string): string {
    switch (type) {
      case 'string': return "'test-value'";
      case 'number': return '42';
      case 'boolean': return 'true';
      default: return '{}';
    }
  }
}
