// XIIGen Skill 29 — Unit Test Generator | Rust
// Generates cargo test suites from source code analysis.
use std::collections::HashMap;
use serde::{Deserialize, Serialize};
use regex::Regex;
use crate::core_interfaces::DataProcessResult;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TestConfig {
    pub framework: String,
    pub coverage_target: u32,
    pub generate_mocks: bool,
    pub generate_edge_cases: bool,
}
impl Default for TestConfig {
    fn default() -> Self { Self { framework: "cargo-test".into(), coverage_target: 80, generate_mocks: true, generate_edge_cases: true } }
}

#[derive(Debug, Clone, Serialize)]
pub struct TestFile { pub path: String, pub content: String, pub test_count: usize, pub category: String }
#[derive(Debug, Clone, Serialize)]
pub struct TestSuite { pub source_file: String, pub test_files: Vec<TestFile>, pub total_tests: usize, pub estimated_coverage: f64 }

struct MethodInfo { name: String, params: Vec<(String, String)>, return_type: String, is_async: bool }

pub struct UnitTestGenerator;

impl UnitTestGenerator {
    pub async fn generate_tests(&self, source_code: &str, _lang: &str, config: Option<TestConfig>) -> DataProcessResult<TestSuite> {
        let config = config.unwrap_or_default();
        let methods = Self::analyze_methods(source_code);
        let mut test_files = vec![
            Self::generate_happy_path(&methods),
            Self::generate_error_tests(&methods),
        ];
        if config.generate_edge_cases { test_files.push(Self::generate_edge_cases(&methods)); }
        let total: usize = test_files.iter().map(|f| f.test_count).sum();
        DataProcessResult::success(TestSuite {
            source_file: "source.rs".into(), test_files, total_tests: total,
            estimated_coverage: config.coverage_target.min(85) as f64,
        })
    }

    fn analyze_methods(code: &str) -> Vec<MethodInfo> {
        let re = Regex::new(r"(?:pub\s+)?(?:async\s+)?fn\s+(\w+)\s*\(([^)]*)\)\s*(?:->\s*(\S+))?").unwrap();
        re.captures_iter(code).filter_map(|cap| {
            let name = cap[1].to_string();
            if name == "new" || name.starts_with("test_") { return None; }
            let params: Vec<(String, String)> = cap.get(2).map(|m| m.as_str()).unwrap_or("")
                .split(',').filter(|s| !s.is_empty() && !s.contains("self"))
                .map(|p| { let parts: Vec<&str> = p.trim().splitn(2, ':').collect();
                    (parts.get(0).unwrap_or(&"arg").trim().to_string(), parts.get(1).unwrap_or(&"_").trim().to_string())
                }).collect();
            Some(MethodInfo { name, params, return_type: cap.get(3).map(|m| m.as_str().to_string()).unwrap_or_default(),
                is_async: code[..cap.get(0).unwrap().start()].ends_with("async ") })
        }).collect()
    }

    fn generate_happy_path(methods: &[MethodInfo]) -> TestFile {
        let mut content = String::from("#[cfg(test)]\nmod happy_path_tests {\n    use super::*;\n\n");
        for m in methods {
            let prefix = if m.is_async { "#[tokio::test]\n    async " } else { "#[test]\n    " };
            let args = m.params.iter().map(|(_, t)| Self::get_test_value(t)).collect::<Vec<_>>().join(", ");
            content.push_str(&format!("    {}fn test_{}_success() {{\n", prefix, m.name));
            content.push_str(&format!("        let result = service.{}({}){};\n", m.name, args, if m.is_async { ".await" } else { "" }));
            content.push_str("        assert!(result.is_ok());\n    }\n\n");
        }
        content.push_str("}\n");
        TestFile { path: "tests/happy_path.rs".into(), content, test_count: methods.len(), category: "happy-path".into() }
    }

    fn generate_error_tests(methods: &[MethodInfo]) -> TestFile {
        let mut content = String::from("#[cfg(test)]\nmod error_tests {\n    use super::*;\n\n");
        let mut count = 0;
        for m in methods {
            if !m.params.is_empty() {
                content.push_str(&format!("    #[test]\n    fn test_{}_invalid_input() {{\n", m.name));
                content.push_str(&format!("        let result = service.{}(\"\");\n", m.name));
                content.push_str("        assert!(result.is_err());\n    }\n\n");
                count += 1;
            }
        }
        content.push_str("}\n");
        TestFile { path: "tests/error_tests.rs".into(), content, test_count: count, category: "error".into() }
    }

    fn generate_edge_cases(methods: &[MethodInfo]) -> TestFile {
        let mut content = String::from("#[cfg(test)]\nmod edge_cases {\n    use super::*;\n\n");
        let mut count = 0;
        for m in methods {
            for (name, typ) in &m.params {
                if typ.contains("String") || typ.contains("str") {
                    content.push_str(&format!("    #[test]\n    fn test_{}_empty_{}() {{\n", m.name, name));
                    content.push_str(&format!("        let result = service.{}(\"\".to_string());\n", m.name));
                    content.push_str("        assert!(result.is_ok() || result.is_err());\n    }\n\n");
                    count += 1;
                }
            }
        }
        content.push_str("}\n");
        TestFile { path: "tests/edge_cases.rs".into(), content, test_count: count, category: "edge-case".into() }
    }

    fn get_test_value(type_name: &str) -> String {
        if type_name.contains("String") || type_name.contains("str") { "\"test\".to_string()".into() }
        else if type_name.contains("i32") || type_name.contains("u32") || type_name.contains("usize") { "42".into() }
        else if type_name.contains("bool") { "true".into() }
        else { "Default::default()".into() }
    }
}
