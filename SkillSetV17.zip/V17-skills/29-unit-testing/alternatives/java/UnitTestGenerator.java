// XIIGen Skill 29 — Unit Test Generator | Java / Spring Boot
// Generates JUnit 5 + Mockito test suites from source code analysis.
package com.xiigen.skills.unittesting;

import com.xiigen.core.interfaces.DataProcessResult;
import com.xiigen.core.processor.ObjectProcessor;
import java.util.*;
import java.util.regex.*;
import java.util.stream.*;

public class UnitTestGenerator {
    public record TestConfig(String framework, int coverageTarget, boolean generateMocks, boolean generateEdgeCases) {
        public TestConfig() { this("junit5", 80, true, true); }
    }
    public record TestFile(String path, String content, int testCount, String category) {}
    public record TestSuite(String sourceFile, List<TestFile> testFiles, int totalTests, double estimatedCoverage) {}
    private record MethodInfo(String name, List<Map<String,String>> params, String returnType, boolean isAsync, List<String> dependencies) {}

    public DataProcessResult<TestSuite> generateTests(String sourceCode, String language, TestConfig config) {
        if (config == null) config = new TestConfig();
        try {
            var methods = analyzeMethods(sourceCode);
            var testFiles = new ArrayList<TestFile>();
            testFiles.add(generateHappyPath(methods));
            testFiles.add(generateErrorTests(methods));
            if (config.generateEdgeCases()) testFiles.add(generateEdgeCases(methods));
            if (config.generateMocks()) {
                var deps = methods.stream().flatMap(m -> m.dependencies().stream()).distinct().toList();
                if (!deps.isEmpty()) testFiles.add(generateMockSetup(deps));
            }
            int total = testFiles.stream().mapToInt(TestFile::testCount).sum();
            return DataProcessResult.success(new TestSuite("source.java", testFiles, total, Math.min(config.coverageTarget(), 85)));
        } catch (Exception e) {
            return DataProcessResult.failure("Generation failed: " + e.getMessage());
        }
    }

    private List<MethodInfo> analyzeMethods(String code) {
        var methods = new ArrayList<MethodInfo>();
        var pattern = Pattern.compile("(?:public|protected)\\s+(?:async\\s+)?(?:static\\s+)?(\\w+(?:<[^>]+>)?)\\s+(\\w+)\\s*\\(([^)]*)\\)");
        var matcher = pattern.matcher(code);
        while (matcher.find()) {
            String returnType = matcher.group(1), name = matcher.group(2), paramsStr = matcher.group(3);
            var params = Arrays.stream(paramsStr.split(",")).filter(s -> !s.isBlank())
                .map(p -> { var parts = p.trim().split("\\s+"); return Map.of("type", parts[0], "name", parts.length > 1 ? parts[1] : "arg"); })
                .collect(Collectors.toList());
            methods.add(new MethodInfo(name, params, returnType, returnType.contains("Mono") || returnType.contains("Flux"), List.of()));
        }
        return methods;
    }

    private TestFile generateHappyPath(List<MethodInfo> methods) {
        var sb = new StringBuilder();
        sb.append("@ExtendWith(MockitoExtension.class)\nclass HappyPathTest {\n");
        for (var m : methods) {
            sb.append("  @Test\n  void ").append(m.name()).append("_success() {\n");
            sb.append("    var result = service.").append(m.name()).append("(");
            sb.append(m.params().stream().map(p -> getTestValue(p.get("type"))).collect(Collectors.joining(", ")));
            sb.append(");\n    assertNotNull(result);\n    assertTrue(result.isSuccess());\n  }\n");
        }
        sb.append("}");
        return new TestFile("HappyPathTest.java", sb.toString(), methods.size(), "happy-path");
    }

    private TestFile generateErrorTests(List<MethodInfo> methods) {
        var sb = new StringBuilder();
        sb.append("class ErrorTest {\n");
        int count = 0;
        for (var m : methods) {
            if (!m.params().isEmpty()) {
                sb.append("  @Test\n  void ").append(m.name()).append("_nullInput() {\n");
                sb.append("    var result = service.").append(m.name()).append("(null);\n");
                sb.append("    assertFalse(result.isSuccess());\n  }\n");
                count++;
            }
        }
        sb.append("}");
        return new TestFile("ErrorTest.java", sb.toString(), count, "error");
    }

    private TestFile generateEdgeCases(List<MethodInfo> methods) {
        var sb = new StringBuilder();
        sb.append("class EdgeCaseTest {\n");
        int count = 0;
        for (var m : methods) {
            for (var p : m.params()) {
                if ("String".equals(p.get("type"))) {
                    sb.append("  @Test\n  void ").append(m.name()).append("_empty").append(p.get("name")).append("() {\n");
                    sb.append("    var result = service.").append(m.name()).append("(\"\");\n    assertNotNull(result);\n  }\n");
                    count++;
                }
            }
        }
        sb.append("}");
        return new TestFile("EdgeCaseTest.java", sb.toString(), count, "edge-case");
    }

    private TestFile generateMockSetup(List<String> deps) {
        var sb = new StringBuilder();
        for (var dep : deps) {
            sb.append("@Mock\nprivate ").append(dep).append(" mock").append(dep).append(";\n");
        }
        return new TestFile("MockSetup.java", sb.toString(), 0, "mock");
    }

    private String getTestValue(String type) {
        return switch (type) { case "String" -> "\"test\""; case "int","Integer","long","Long" -> "42"; case "boolean","Boolean" -> "true"; default -> "null"; };
    }
}
