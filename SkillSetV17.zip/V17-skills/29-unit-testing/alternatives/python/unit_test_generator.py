"""XIIGen Skill 29 — Unit Test Generator | Python
Generates pytest test suites from source code analysis.
"""
import re
import ast
from dataclasses import dataclass, field
from typing import Any
from core_interfaces import DataProcessResult
from object_processor import ObjectProcessor

@dataclass
class TestConfig:
    framework: str = "pytest"
    coverage_target: int = 80
    generate_mocks: bool = True
    generate_edge_cases: bool = True

@dataclass
class TestFile:
    path: str
    content: str
    test_count: int
    category: str  # happy-path, error, edge-case, mock

@dataclass
class TestSuite:
    source_file: str
    test_files: list[TestFile]
    total_tests: int
    estimated_coverage: float

@dataclass
class MethodInfo:
    name: str
    params: list[dict[str, str]]
    return_type: str
    is_async: bool
    dependencies: list[str]

class UnitTestGenerator:
    """Generates comprehensive pytest test suites for Python source code."""

    async def generate_tests(self, source_code: str, language: str = "python",
                              config: TestConfig = None) -> DataProcessResult[TestSuite]:
        config = config or TestConfig()
        try:
            methods = self._analyze_methods(source_code)
            test_files = []

            test_files.append(self._generate_happy_path(methods))
            test_files.append(self._generate_error_tests(methods))
            if config.generate_edge_cases:
                test_files.append(self._generate_edge_cases(methods))
            if config.generate_mocks:
                deps = list({d for m in methods for d in m.dependencies})
                if deps:
                    test_files.append(self._generate_conftest(deps))

            suite = TestSuite(
                source_file="source.py", test_files=test_files,
                total_tests=sum(f.test_count for f in test_files),
                estimated_coverage=min(config.coverage_target, 85 if methods else 0))
            return DataProcessResult(success=True, data=suite)
        except Exception as e:
            return DataProcessResult(success=False, error=f"Generation failed: {e}")

    def _analyze_methods(self, code: str) -> list[MethodInfo]:
        methods = []
        try:
            tree = ast.parse(code)
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    if node.name.startswith('_') and not node.name.startswith('__'):
                        continue
                    params = [{"name": a.arg, "type": getattr(a.annotation, 'id', 'Any')}
                              for a in node.args.args if a.arg != 'self']
                    deps = [n.attr for n in ast.walk(node)
                            if isinstance(n, ast.Attribute) and isinstance(n.value, ast.Name)
                            and n.value.id == 'self' and 'service' in n.attr.lower()]
                    methods.append(MethodInfo(
                        name=node.name, params=params,
                        return_type="coroutine" if isinstance(node, ast.AsyncFunctionDef) else "Any",
                        is_async=isinstance(node, ast.AsyncFunctionDef),
                        dependencies=list(set(deps))))
        except SyntaxError:
            pattern = r'(?:async\s+)?def\s+(\w+)\s*\(([^)]*)\)'
            for match in re.finditer(pattern, code):
                name, params_str = match.groups()
                params = [{"name": p.strip().split(':')[0].strip(), "type": "Any"}
                          for p in params_str.split(',') if p.strip() and p.strip() != 'self']
                methods.append(MethodInfo(name=name, params=params, return_type="Any",
                    is_async='async' in code[max(0,match.start()-10):match.start()], dependencies=[]))
        return methods

    def _generate_happy_path(self, methods: list[MethodInfo]) -> TestFile:
        lines = ['"""Happy path tests."""', 'import pytest', '']
        for m in methods:
            prefix = 'async ' if m.is_async else ''
            await_kw = 'await ' if m.is_async else ''
            decorator = '@pytest.mark.asyncio\n' if m.is_async else ''
            test_args = ', '.join(self._get_test_value(p["type"]) for p in m.params)
            lines.append(f'{decorator}{prefix}def test_{m.name}_success(service):')
            lines.append(f'    result = {await_kw}service.{m.name}({test_args})')
            lines.append(f'    assert result is not None')
            lines.append(f'    assert result.success is True')
            lines.append('')
        return TestFile("test_happy_path.py", '\n'.join(lines), len(methods), "happy-path")

    def _generate_error_tests(self, methods: list[MethodInfo]) -> TestFile:
        lines = ['"""Error handling tests."""', 'import pytest', '']
        count = 0
        for m in methods:
            if m.params:
                lines.append(f'{"@pytest.mark.asyncio" if m.is_async else ""}')
                lines.append(f'{"async " if m.is_async else ""}def test_{m.name}_null_input(service):')
                lines.append(f'    result = {"await " if m.is_async else ""}service.{m.name}(None)')
                lines.append(f'    assert result.success is False')
                lines.append('')
                count += 1
        return TestFile("test_errors.py", '\n'.join(lines), count, "error")

    def _generate_edge_cases(self, methods: list[MethodInfo]) -> TestFile:
        lines = ['"""Edge case tests."""', 'import pytest', '']
        count = 0
        for m in methods:
            for p in m.params:
                if p["type"] in ("str", "string", "Any"):
                    lines.append(f'def test_{m.name}_empty_{p["name"]}(service):')
                    lines.append(f'    result = service.{m.name}("")')
                    lines.append(f'    assert result is not None')
                    lines.append('')
                    count += 1
        return TestFile("test_edge_cases.py", '\n'.join(lines), count, "edge-case")

    def _generate_conftest(self, deps: list[str]) -> TestFile:
        lines = ['"""Shared fixtures."""', 'import pytest', 'from unittest.mock import AsyncMock, MagicMock', '']
        for dep in deps:
            lines.append(f'@pytest.fixture')
            lines.append(f'def mock_{dep}():')
            lines.append(f'    mock = AsyncMock()')
            lines.append(f'    mock.query.return_value = DataProcessResult(success=True, data=[])')
            lines.append(f'    return mock')
            lines.append('')
        return TestFile("conftest.py", '\n'.join(lines), 0, "mock")

    @staticmethod
    def _get_test_value(type_name: str) -> str:
        return {"str": "'test'", "int": "42", "float": "3.14", "bool": "True"}.get(type_name, "'test'")
