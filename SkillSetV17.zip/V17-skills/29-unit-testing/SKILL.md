---
skill_id: "29"
name: unit-testing
title: "Unit Test Generator Service"
layer: "L7: Quality"
version: "17.1"
status: "active"
dependencies: ["01-core-interfaces", "02-object-processor", "03-elasticsearch-datastore", "06-ai-providers", "28-prompt-engineering"]
genie_dna:
  - "DNA-1: Test patterns stored as dynamic documents (Dict<string,object>) in ES"
  - "DNA-2: BuildSearchFilter for pattern search — skip empty, inject scope"
  - "DNA-3: ParseObjectAlternative for test data storage — no fixed schema"
  - "DNA-5: DataProcessResult wraps all operations"
  - "DNA-FREEDOM: Test patterns, fixtures, thresholds are user-definable"
  - "DNA-MACHINE: TestGenerator engine is static infrastructure"
  - "DNA-SCOPE: ownerId injected on all test pattern queries"
triggers: unit test, test generation, test coverage, test patterns, test fixtures, xunit, jest, pytest
es_indices:
  - "xiigen-test-patterns"
  - "xiigen-test-results"
---

# Skill 29: Unit Test Generator Service
## AI-Powered Test Generation with User-Definable Patterns

**Status:** Enhanced — DNA-Compliant  
**Priority:** P1 — Every implementation needs tests  
**Dependencies:** Skill 01, Skill 02, Skill 06, Skill 28  
**Layer:** L7: Quality  
**Estimated LOC:** ~400  

---

## Overview

The Unit Test Generator analyzes source code and produces comprehensive unit tests using AI models. Test patterns, fixtures, coverage thresholds, and framework preferences are stored as dynamic documents — users (and AI agents) create custom test strategies at runtime without code changes.

## Key Concepts

- **TestPattern** — Dynamic document defining a test strategy (what to test, how, expected coverage). Schema-free.
- **TestFixture** — Dynamic document with test data (inputs, expected outputs). Any shape.
- **CodeAnalyzer** — MACHINE component that extracts methods, dependencies, and testable units from source code.
- **TestGenerator** — MACHINE component that uses AI + patterns + fixtures to produce test code.
- **CoverageTracker** — MACHINE component that tracks generated test coverage per module.

---

## Component Classification (MACHINE vs FREEDOM)

### 🔧 MACHINE (static infrastructure — build once)
| Component | What It Does |
|-----------|-------------|
| UnitTestGeneratorService | Orchestrates analysis → AI → test output pipeline |
| CodeAnalyzer | Extracts methods, params, return types from source |
| TestGenerator | Calls AI with patterns + source to produce tests |
| CoverageTracker | Measures test coverage, tracks history |
| FrameworkAdapter | Maps test output to xUnit/Jest/pytest/etc format |

### 🔓 FREEDOM (user-definable — dynamic documents)
| Component | What Users Control |
|-----------|-------------------|
| Test patterns | "Always include accessibility checks" — stored as dynamic doc |
| Test fixtures | Input/output pairs, mock data — any shape |
| Coverage thresholds | Per-project, per-module — user-configurable |
| Framework selection | xUnit, Jest, pytest, JUnit — config, not code |
| Test categories | User creates: "security", "performance", "regression" |

### The Test
> Can a user add "Performance regression (P0)" as a test category without a developer?
> With FREEDOM: YES → add to pattern document. With current: NO → code change.

---

## Scope Isolation

- Test pattern queries inject `ownerId` filter (non-admin)
- System patterns (`scope: "system"`) readable by all
- Test results scoped to user/project that created them
- AI agents operate under requesting user's scope
- Team patterns shared via `scope: "team"` + `teamId`

---

## AI Agent Communication

1. **Discovery:** "What test patterns are available?" → agent queries xiigen-test-patterns
2. **Creation:** "Write tests for my checkout flow" → agent creates test pattern doc + generates tests
3. **Customization:** "I want all tests to include null checks" → agent updates user's default pattern
4. **Analysis:** "Why did my tests fail?" → agent reads test results and explains
5. **Composition:** Agent chains: Skill 28 (prompt) → Skill 29 (test gen) → Skill 30 (E2E) for full coverage

---

## Primary Implementation (.NET 9)

### Interface

```csharp
namespace XIIGen.Quality.Interfaces;

public interface IUnitTestGeneratorService
{
    // Generate tests from source code + pattern
    Task<DataProcessResult<Dictionary<string, object>>> GenerateTestsAsync(
        Dictionary<string, object> request, string userId, string traceId,
        CancellationToken ct = default);
    
    // CRUD for test patterns (FREEDOM — dynamic documents)
    Task<DataProcessResult<string>> StorePatternAsync(
        Dictionary<string, object> pattern, CancellationToken ct = default);
    Task<DataProcessResult<List<Dictionary<string, object>>>> SearchPatternsAsync(
        Dictionary<string, object> filter, string userId, bool isAdmin = false,
        CancellationToken ct = default);
    
    // CRUD for test fixtures (FREEDOM — dynamic documents)
    Task<DataProcessResult<string>> StoreFixtureAsync(
        Dictionary<string, object> fixture, CancellationToken ct = default);
    Task<DataProcessResult<List<Dictionary<string, object>>>> SearchFixturesAsync(
        Dictionary<string, object> filter, string userId, bool isAdmin = false,
        CancellationToken ct = default);
    
    // Coverage tracking
    Task<DataProcessResult<Dictionary<string, object>>> GetCoverageAsync(
        string projectId, string moduleId, CancellationToken ct = default);
    Task<DataProcessResult<string>> UpdateCoverageAsync(
        Dictionary<string, object> coverageData, CancellationToken ct = default);
}
```

### DI Registration
```csharp
services.AddSingleton<IUnitTestGeneratorService, UnitTestGeneratorService>();
```

---

## Abstraction Extraction

When you see test generation in any domain (unit, E2E, UI, API):
1. **MACHINE:** The test generator engine (analyze source → call AI → produce test code)
2. **FREEDOM:** Test patterns, fixtures, thresholds (dynamic documents)
3. **BRIDGE:** Pattern category ("unit", "e2e", "ui", "api") — same service, different patterns

## Dependencies

| Skill | What It Provides |
|-------|-----------------|
| 01 | DataProcessResult, IDataStore interfaces |
| 02 | ParseObjectAlternative for dynamic docs |
| 06 | AI provider for test generation |
| 28 | Prompt templates for test generation prompts |

## Related Skills
- **30** — E2E Testing (same MACHINE pattern, different FREEDOM patterns)
- **31** — UI Testing (visual regression patterns)
- **17** — Code Generator outputs what gets tested
