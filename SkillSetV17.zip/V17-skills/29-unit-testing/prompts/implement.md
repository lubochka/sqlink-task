# Skill 29: Unit Testing — Implementation Prompt

## Phase 1: Core Setup
xUnit/Jest/pytest setup. Test project structure. Mock factories for IDatabaseService, IQueueService.

## Phase 2: DNA Pattern Tests
Verify ParseDocument preserves unknown fields. Verify BuildSearchFilter skips empty fields.
Verify all services return DataProcessResult. Verify scope injection for non-admin queries.

## Phase 3: Test Data Generation
Dynamic document test factories — generate test data as Dictionary<string, object>.
Same factory works for ANY entity type (no typed test fixtures).

## Phase 4: Coverage & Reporting
Test coverage reporting. Minimum thresholds per skill. DNA compliance report.

---

## Genie DNA Compliance — MANDATORY
☐ DNA-1: Dynamic Documents — Dictionary<string, object>, NOT typed models
☐ DNA-2: BuildSearchFilter — skip empty fields, no entity-specific query code
☐ DNA-3: MicroserviceBase — inherit DB, queue, cache, logger
☐ DNA-5: DataProcessResult<T> — all methods return result wrapper
☐ DNA-6: Generic Interfaces — swap via config
☐ DNA-SCOPE: Non-admin queries auto-inject userId filter
