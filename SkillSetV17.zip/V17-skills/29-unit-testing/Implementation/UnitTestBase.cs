// XIIGen.Testing.Unit/UnitTestBase.cs | .NET 9 | Skill 29
// Base class + helpers + generators for high-coverage unit testing.
// xUnit + Moq + FluentAssertions + AutoFixture

using System.Text.Json;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;
using FluentAssertions;
using AutoFixture;
using AutoFixture.AutoMoq;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Testing.Unit;

// ═══════════════════════════════════════════════════════
// BASE TEST CLASS - All unit tests inherit from this
// ═══════════════════════════════════════════════════════

public abstract class UnitTestBase<TService> where TService : class
{
    protected readonly IFixture Fixture;
    protected readonly Mock<IDatabaseService> MockDb;
    protected readonly Mock<IQueueService> MockQueue;
    protected readonly Mock<ICacheService> MockCache;
    protected readonly Mock<IAiProvider> MockAiProvider;
    protected readonly Mock<IRagService> MockRag;
    protected readonly Mock<ILogger<TService>> MockLogger;
    protected TService Service { get; set; }

    protected UnitTestBase()
    {
        Fixture = new Fixture().Customize(new AutoMoqCustomization { ConfigureMembers = true });
        MockDb = new Mock<IDatabaseService>();
        MockQueue = new Mock<IQueueService>();
        MockCache = new Mock<ICacheService>();
        MockAiProvider = new Mock<IAiProvider>();
        MockRag = new Mock<IRagService>();
        MockLogger = new Mock<ILogger<TService>>();

        // Default mock behaviors
        SetupDefaultMocks();
    }

    private void SetupDefaultMocks()
    {
        // DB: return success by default
        MockDb.Setup(x => x.StoreDocumentAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(),
                It.IsAny<object>(), It.IsAny<bool>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(DataProcessResult<object>.Success(new { }));

        MockDb.Setup(x => x.GetDocumentAsync<object>(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(DataProcessResult<object>.Success(new { }));

        // Queue: return success
        MockQueue.Setup(x => x.EnqueueAsync(
                It.IsAny<string>(), It.IsAny<object>(), It.IsAny<Dictionary<string, string>>(),
                It.IsAny<int>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(DataProcessResult<string>.Success("msg-id"));

        // Cache: return null (cache miss) by default
        MockCache.Setup(x => x.GetAsync<object>(It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync((object)null);

        // AI: return generic response
        MockAiProvider.Setup(x => x.ExecuteAsync(It.IsAny<AiRequest>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new AiResponse { Content = "AI response", Model = "test-model", TokensIn = 100, TokensOut = 50 });
    }

    // ─── Helper Methods ──────────────────────────────────

    protected void SetupDbSearch<T>(string index, List<T> results)
    {
        MockDb.Setup(x => x.SearchDocumentsAsync<T>(
                index, It.IsAny<string>(), It.IsAny<SearchOptions>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(DataProcessResult<List<T>>.Success(results));
    }

    protected void SetupDbNotFound(string index, string id)
    {
        MockDb.Setup(x => x.GetDocumentAsync<object>(
                index, It.IsAny<string>(), id, It.IsAny<CancellationToken>()))
            .ReturnsAsync(DataProcessResult<object>.NotFound());
    }

    protected void SetupDbError(string errorMessage = "Database error")
    {
        MockDb.Setup(x => x.StoreDocumentAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(),
                It.IsAny<object>(), It.IsAny<bool>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(DataProcessResult<object>.Error(errorMessage));
    }

    protected void SetupAiResponse(string content, int tokensIn = 100, int tokensOut = 50)
    {
        MockAiProvider.Setup(x => x.ExecuteAsync(It.IsAny<AiRequest>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new AiResponse { Content = content, Model = "test-model", TokensIn = tokensIn, TokensOut = tokensOut });
    }

    protected void SetupCacheHit<T>(string key, T value)
    {
        MockCache.Setup(x => x.GetAsync<T>(key, It.IsAny<CancellationToken>()))
            .ReturnsAsync(value);
    }

    protected void VerifyDbStored(string index, Times times)
    {
        MockDb.Verify(x => x.StoreDocumentAsync(
            index, It.IsAny<string>(), It.IsAny<string>(),
            It.IsAny<object>(), It.IsAny<bool>(), It.IsAny<CancellationToken>()), times);
    }

    protected void VerifyEnqueued(string queue, Times times)
    {
        MockQueue.Verify(x => x.EnqueueAsync(
            queue, It.IsAny<object>(), It.IsAny<Dictionary<string, string>>(),
            It.IsAny<int>(), It.IsAny<CancellationToken>()), times);
    }

    protected void VerifyLogged(LogLevel level, string messageContains = null)
    {
        MockLogger.Verify(x => x.Log(level,
            It.IsAny<EventId>(),
            It.Is<It.IsAnyType>((v, t) => messageContains == null || v.ToString().Contains(messageContains)),
            It.IsAny<Exception>(),
            It.IsAny<Func<It.IsAnyType, Exception, string>>()), Times.AtLeastOnce());
    }
}

// ═══════════════════════════════════════════════════════
// EXAMPLE: FlowOrchestrator Unit Tests
// ═══════════════════════════════════════════════════════

public class FlowOrchestratorTests : UnitTestBase<FlowOrchestrator>
{
    public FlowOrchestratorTests()
    {
        // Service = new FlowOrchestrator(MockDb.Object, MockQueue.Object, MockLogger.Object, MockCache.Object);
    }

    [Fact]
    public async Task ExecuteFlow_ValidFlow_CreatesExecutionRecord()
    {
        // Arrange
        var flowId = "test-flow-1";
        var traceId = "trace-123";
        SetupDbSearch<FlowDefinition>("flow-definitions", [new FlowDefinition
        {
            FlowId = flowId, Nodes = [new FlowNode { NodeId = "n1", NodeType = "ai-transform" }],
            Edges = []
        }]);

        // Act
        // var result = await Service.ExecuteFlowAsync(flowId, traceId, new { }, CancellationToken.None);

        // Assert
        // result.IsSuccess.Should().BeTrue();
        VerifyDbStored("flow-executions", Times.Once());
    }

    [Fact]
    public async Task ExecuteFlow_FlowNotFound_ReturnsNotFound()
    {
        SetupDbSearch<FlowDefinition>("flow-definitions", []);
        // var result = await Service.ExecuteFlowAsync("nonexistent", "trace-1", new { }, CancellationToken.None);
        // result.Status.Should().Be(ResultStatus.NotFound);
    }

    [Theory]
    [InlineData(null)]
    [InlineData("")]
    [InlineData(" ")]
    public async Task ExecuteFlow_InvalidTraceId_ThrowsArgument(string traceId)
    {
        // await Assert.ThrowsAsync<ArgumentException>(() =>
        //     Service.ExecuteFlowAsync("flow-1", traceId, new { }, CancellationToken.None));
    }

    [Fact]
    public async Task ExecuteFlow_DbError_ReturnsError()
    {
        SetupDbError("Connection refused");
        // var result = await Service.ExecuteFlowAsync("flow-1", "trace-1", new { }, CancellationToken.None);
        // result.IsSuccess.Should().BeFalse();
        // result.Message.Should().Contain("Connection refused");
    }
}

// ═══════════════════════════════════════════════════════
// EXAMPLE: AiDispatcher Unit Tests
// ═══════════════════════════════════════════════════════

public class AiDispatcherTests : UnitTestBase<AiDispatcher>
{
    private readonly Mock<IAiProvider> _mockClaude = new();
    private readonly Mock<IAiProvider> _mockGpt = new();

    public AiDispatcherTests()
    {
        _mockClaude.Setup(x => x.ProviderName).Returns("claude");
        _mockGpt.Setup(x => x.ProviderName).Returns("gpt");
        _mockClaude.Setup(x => x.ExecuteAsync(It.IsAny<AiRequest>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new AiResponse { Content = "Claude response", Model = "claude-sonnet", TokensIn = 100, TokensOut = 200 });
        _mockGpt.Setup(x => x.ExecuteAsync(It.IsAny<AiRequest>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new AiResponse { Content = "GPT response", Model = "gpt-4", TokensIn = 100, TokensOut = 180 });
    }

    [Fact]
    public async Task FanOut_MultipleProviders_ReturnsAllResults()
    {
        // Arrange: dispatcher with 2 providers
        // Act: fan out to all
        // Assert: should have 2 results
        _mockClaude.Verify(x => x.ExecuteAsync(It.IsAny<AiRequest>(), It.IsAny<CancellationToken>()), Times.Never());
    }

    [Fact]
    public async Task FanOut_OneProviderFails_ReturnsPartialResults()
    {
        _mockGpt.Setup(x => x.ExecuteAsync(It.IsAny<AiRequest>(), It.IsAny<CancellationToken>()))
            .ThrowsAsync(new HttpRequestException("Timeout"));
        // Should still return Claude's result
    }

    [Fact]
    public async Task FanOut_AllProvidersFail_ReturnsError()
    {
        _mockClaude.Setup(x => x.ExecuteAsync(It.IsAny<AiRequest>(), It.IsAny<CancellationToken>()))
            .ThrowsAsync(new HttpRequestException("Timeout"));
        _mockGpt.Setup(x => x.ExecuteAsync(It.IsAny<AiRequest>(), It.IsAny<CancellationToken>()))
            .ThrowsAsync(new HttpRequestException("Rate limited"));
        // Should return error with all failure messages
    }
}

// ═══════════════════════════════════════════════════════
// EXAMPLE: Database Service Tests (tests any IDatabaseService)
// ═══════════════════════════════════════════════════════

public abstract class DatabaseServiceTestBase
{
    protected abstract IDatabaseService CreateService();

    [Fact]
    public async Task StoreAndRetrieve_SimpleDocument_RoundTrips()
    {
        var db = CreateService();
        var doc = new { Name = "test", Value = 42 };
        var storeResult = await db.StoreDocumentAsync("test-index", "test", "doc-1", doc);
        storeResult.IsSuccess.Should().BeTrue();

        var getResult = await db.GetDocumentAsync<object>("test-index", "test", "doc-1");
        getResult.IsSuccess.Should().BeTrue();
    }

    [Fact]
    public async Task Search_ByNonEmptyFields_ReturnsMatching()
    {
        var db = CreateService();
        await db.StoreDocumentAsync("test-index", "test", "doc-1", new { Name = "Alpha", Status = "Active" });
        await db.StoreDocumentAsync("test-index", "test", "doc-2", new { Name = "Beta", Status = "Inactive" });

        var results = await db.SearchDocumentsAsync<object>("test-index", "test",
            new SearchOptions { Conditions = [new SearchCondition { Property = "Status", Value = "Active", QueryType = QueryType.Equal }] });
        results.Data.Should().HaveCount(1);
    }

    [Fact]
    public async Task Delete_ExistingDocument_Succeeds()
    {
        var db = CreateService();
        await db.StoreDocumentAsync("test-index", "test", "doc-del", new { Name = "deleteme" });
        var result = await db.DeleteDocumentAsync("test-index", "test", "doc-del");
        result.IsSuccess.Should().BeTrue();
    }

    [Fact]
    public async Task Get_NonExistent_ReturnsNotFound()
    {
        var db = CreateService();
        var result = await db.GetDocumentAsync<object>("test-index", "test", "nonexistent-xyz");
        result.Status.Should().Be(ResultStatus.NotFound);
    }
}

// ═══════════════════════════════════════════════════════
// TEST DATA GENERATOR
// ═══════════════════════════════════════════════════════

public static class TestDataGenerator
{
    private static readonly IFixture Fixture = new Fixture();

    public static FlowDefinition CreateFlowDefinition(int nodeCount = 3) => new()
    {
        FlowId = $"flow-{Guid.NewGuid():N}",
        Name = Fixture.Create<string>(),
        Nodes = Enumerable.Range(1, nodeCount).Select(i => new FlowNode
        {
            NodeId = $"node-{i}",
            NodeType = i % 2 == 0 ? "ai-transform" : "ai-review",
            Config = new Dictionary<string, object> { ["model"] = "claude" }
        }).ToList(),
        Edges = Enumerable.Range(1, nodeCount - 1).Select(i => new FlowEdge
        {
            From = $"node-{i}", To = $"node-{i + 1}"
        }).ToList()
    };

    public static AiRequest CreateAiRequest(string prompt = null) => new()
    {
        Prompt = prompt ?? Fixture.Create<string>(),
        SystemPrompt = "You are a helpful assistant.",
        MaxTokens = 1000,
        Temperature = 0.5f
    };

    public static Dictionary<string, object> CreateFigmaNodes(int count = 5) =>
        new() { ["nodes"] = Enumerable.Range(1, count).Select(i => new
        {
            id = $"figma-{i}", type = "FRAME", name = $"Component{i}",
            width = 200 + i * 50, height = 100 + i * 30,
            fills = new[] { new { type = "SOLID", color = new { r = 0.2, g = 0.4, b = 0.8 } } }
        }).ToArray() };
}

// ═══════════════════════════════════════════════════════
// PLACEHOLDER CLASSES (referenced in tests)
// ═══════════════════════════════════════════════════════

public class FlowOrchestrator { }
public class AiDispatcher { }
public class FlowDefinition
{
    public string FlowId { get; set; }
    public string Name { get; set; }
    public List<FlowNode> Nodes { get; set; } = [];
    public List<FlowEdge> Edges { get; set; } = [];
}
public class FlowNode
{
    public string NodeId { get; set; }
    public string NodeType { get; set; }
    public Dictionary<string, object> Config { get; set; } = [];
}
public class FlowEdge { public string From { get; set; } public string To { get; set; } }
