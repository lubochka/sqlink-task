// XIIGen.Quality/UnitTesting/UnitTestGeneratorService.cs — Skill 29 | .NET 9
// MACHINE: Test generator engine (analyze → AI → tests)
// FREEDOM: Test patterns, fixtures, thresholds — dynamic documents
// DNA: ParseObjectAlternative, BuildSearchFilter, DataProcessResult, scope injection
using System.Text.Json;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Quality.UnitTesting;

public interface IUnitTestGeneratorService
{
    Task<DataProcessResult<Dictionary<string, object>>> GenerateTestsAsync(
        Dictionary<string, object> request, string userId, string traceId, CancellationToken ct = default);
    Task<DataProcessResult<string>> StorePatternAsync(
        Dictionary<string, object> pattern, CancellationToken ct = default);
    Task<DataProcessResult<List<Dictionary<string, object>>>> SearchPatternsAsync(
        Dictionary<string, object> filter, string userId, bool isAdmin = false, CancellationToken ct = default);
    Task<DataProcessResult<string>> StoreFixtureAsync(
        Dictionary<string, object> fixture, CancellationToken ct = default);
    Task<DataProcessResult<List<Dictionary<string, object>>>> SearchFixturesAsync(
        Dictionary<string, object> filter, string userId, bool isAdmin = false, CancellationToken ct = default);
    Task<DataProcessResult<Dictionary<string, object>>> GetCoverageAsync(
        string projectId, string moduleId, CancellationToken ct = default);
    Task<DataProcessResult<string>> UpdateCoverageAsync(
        Dictionary<string, object> coverageData, CancellationToken ct = default);
    Task<DataProcessResult<int>> SeedSystemPatternsAsync(CancellationToken ct = default);
}

public sealed class UnitTestGeneratorService : IUnitTestGeneratorService
{
    private const string PatternIndex = "xiigen-test-patterns";
    private const string FixtureIndex = "xiigen-test-fixtures";
    private const string ResultIndex = "xiigen-test-results";
    private const string CoverageIndex = "xiigen-test-coverage";

    private readonly IDataStore _db;
    private readonly IObjectProcessor _processor;
    private readonly IAiProvider _ai;
    private readonly IPromptTemplateService _prompts;
    private readonly ILogger<UnitTestGeneratorService> _logger;

    public UnitTestGeneratorService(
        IDataStore db, IObjectProcessor processor, IAiProvider ai,
        IPromptTemplateService prompts, ILogger<UnitTestGeneratorService> logger)
    {
        _db = db; _processor = processor; _ai = ai; _prompts = prompts; _logger = logger;
    }

    // ═══ Generate Tests — MACHINE logic ═══

    public async Task<DataProcessResult<Dictionary<string, object>>> GenerateTestsAsync(
        Dictionary<string, object> request, string userId, string traceId, CancellationToken ct = default)
    {
        try
        {
            var sourceCode = GetStr(request, "sourceCode");
            var language = GetStr(request, "language", "csharp");
            var framework = GetStr(request, "testFramework", "xunit");
            var patternId = GetStr(request, "patternId", "sys-unit-standard");
            var coverageTarget = Convert.ToInt32(request.GetValueOrDefault("coverageTarget", 80));

            // 1. Load test pattern (FREEDOM — dynamic doc)
            var pattern = await LoadPatternOrDefault(patternId, ct);

            // 2. Load relevant fixtures
            var fixtures = await SearchFixturesAsync(
                new Dictionary<string, object> { ["language"] = language, ["category"] = "unit" },
                userId, ct: ct);

            // 3. Build prompt via Skill 28
            var vars = new Dictionary<string, object>
            {
                ["sourceCode"] = sourceCode,
                ["language"] = language,
                ["testFramework"] = framework,
                ["coverageTarget"] = coverageTarget,
                ["testStyle"] = GetStr(pattern, "testStyle", "arrange-act-assert"),
                ["extraInstructions"] = GetStr(pattern, "extraInstructions", ""),
                ["fixtures"] = fixtures.IsSuccess ? JsonSerializer.Serialize(fixtures.Data) : "[]"
            };

            var promptResult = await _prompts.ResolveWithFeedbackAsync("sys-test-gen", vars, traceId, ct: ct);
            if (!promptResult.IsSuccess)
                return DataProcessResult<Dictionary<string, object>>.Fail($"Prompt resolution failed: {promptResult.Error}");

            // 4. Call AI to generate tests
            var aiResult = await _ai.GenerateAsync(promptResult.Data, ct);
            if (!aiResult.IsSuccess)
                return DataProcessResult<Dictionary<string, object>>.Fail($"AI generation failed: {aiResult.Error}");

            // 5. Store result as dynamic document
            var result = new Dictionary<string, object>
            {
                ["id"] = $"test-{traceId}",
                ["traceId"] = traceId,
                ["sourceLanguage"] = language,
                ["testFramework"] = framework,
                ["generatedCode"] = aiResult.Data,
                ["patternId"] = patternId,
                ["coverageTarget"] = coverageTarget,
                ["ownerId"] = userId,
                ["status"] = "generated",
                ["createdAt"] = DateTime.UtcNow
            };

            await _db.StoreAsync(ResultIndex, result["id"].ToString()!, result, ct: ct);
            _logger.LogInformation("[Skill29] Tests generated: {TraceId} lang={Lang}", traceId, language);
            return DataProcessResult<Dictionary<string, object>>.Ok(result);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[Skill29] GenerateTestsAsync failed");
            return DataProcessResult<Dictionary<string, object>>.Fail(ex.Message);
        }
    }

    // ═══ Test Patterns CRUD — FREEDOM (dynamic docs) ═══

    public async Task<DataProcessResult<string>> StorePatternAsync(
        Dictionary<string, object> pattern, CancellationToken ct = default)
    {
        try
        {
            var processed = _processor.ParseObjectAlternative(pattern);
            processed.TryAdd("id", Guid.NewGuid().ToString());
            processed.TryAdd("createdAt", DateTime.UtcNow);
            processed["updatedAt"] = DateTime.UtcNow;
            processed.TryAdd("scope", "private");
            processed.TryAdd("testType", "unit");

            var id = processed["id"].ToString()!;
            var result = await _db.StoreAsync(PatternIndex, id, processed, ct: ct);
            return result.IsSuccess
                ? DataProcessResult<string>.Ok(id)
                : DataProcessResult<string>.Fail(result.Error);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[Skill29] StorePatternAsync failed");
            return DataProcessResult<string>.Fail(ex.Message);
        }
    }

    public async Task<DataProcessResult<List<Dictionary<string, object>>>> SearchPatternsAsync(
        Dictionary<string, object> filter, string userId, bool isAdmin = false, CancellationToken ct = default)
    {
        try
        {
            var scoped = InjectScope(filter, userId, isAdmin);
            var searchFilter = _processor.BuildSearchFilter(scoped);
            return await _db.SearchAsync(PatternIndex, searchFilter, ct: ct);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[Skill29] SearchPatternsAsync failed");
            return DataProcessResult<List<Dictionary<string, object>>>.Fail(ex.Message);
        }
    }

    // ═══ Test Fixtures CRUD — FREEDOM (dynamic docs, any shape) ═══

    public async Task<DataProcessResult<string>> StoreFixtureAsync(
        Dictionary<string, object> fixture, CancellationToken ct = default)
    {
        try
        {
            var processed = _processor.ParseObjectAlternative(fixture);
            processed.TryAdd("id", Guid.NewGuid().ToString());
            processed.TryAdd("createdAt", DateTime.UtcNow);
            processed.TryAdd("scope", "private");

            var id = processed["id"].ToString()!;
            await _db.StoreAsync(FixtureIndex, id, processed, ct: ct);
            return DataProcessResult<string>.Ok(id);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[Skill29] StoreFixtureAsync failed");
            return DataProcessResult<string>.Fail(ex.Message);
        }
    }

    public async Task<DataProcessResult<List<Dictionary<string, object>>>> SearchFixturesAsync(
        Dictionary<string, object> filter, string userId, bool isAdmin = false, CancellationToken ct = default)
    {
        try
        {
            var scoped = InjectScope(filter, userId, isAdmin);
            var searchFilter = _processor.BuildSearchFilter(scoped);
            return await _db.SearchAsync(FixtureIndex, searchFilter, ct: ct);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[Skill29] SearchFixturesAsync failed");
            return DataProcessResult<List<Dictionary<string, object>>>.Fail(ex.Message);
        }
    }

    // ═══ Coverage Tracking ═══

    public async Task<DataProcessResult<Dictionary<string, object>>> GetCoverageAsync(
        string projectId, string moduleId, CancellationToken ct = default)
    {
        var id = $"cov-{projectId}-{moduleId}";
        return await _db.GetByIdAsync(CoverageIndex, id, ct);
    }

    public async Task<DataProcessResult<string>> UpdateCoverageAsync(
        Dictionary<string, object> coverageData, CancellationToken ct = default)
    {
        var processed = _processor.ParseObjectAlternative(coverageData);
        processed["updatedAt"] = DateTime.UtcNow;
        var id = processed.GetValueOrDefault("id")?.ToString() ?? Guid.NewGuid().ToString();
        var result = await _db.StoreAsync(CoverageIndex, id, processed, ct: ct);
        return result.IsSuccess ? DataProcessResult<string>.Ok(id) : DataProcessResult<string>.Fail(result.Error);
    }

    // ═══ System Pattern Seeding ═══

    public async Task<DataProcessResult<int>> SeedSystemPatternsAsync(CancellationToken ct = default)
    {
        var patterns = new List<Dictionary<string, object>>
        {
            new() {
                ["id"] = "sys-unit-standard", ["patternName"] = "Standard Unit Tests",
                ["testType"] = "unit", ["category"] = "standard",
                ["testStyle"] = "arrange-act-assert",
                ["categories"] = new List<string> { "happy-path", "error-handling", "edge-cases", "boundary" },
                ["coverageTarget"] = 80,
                ["scope"] = "system", ["ownerId"] = "system"
            },
            new() {
                ["id"] = "sys-unit-tdd", ["patternName"] = "TDD Red-Green-Refactor",
                ["testType"] = "unit", ["category"] = "tdd",
                ["testStyle"] = "given-when-then",
                ["categories"] = new List<string> { "behavior", "contract", "regression" },
                ["coverageTarget"] = 90,
                ["scope"] = "system", ["ownerId"] = "system"
            },
            new() {
                ["id"] = "sys-unit-security", ["patternName"] = "Security-Focused Tests",
                ["testType"] = "unit", ["category"] = "security",
                ["testStyle"] = "arrange-act-assert",
                ["categories"] = new List<string> { "injection", "auth-bypass", "input-validation", "overflow" },
                ["coverageTarget"] = 95,
                ["scope"] = "system", ["ownerId"] = "system"
            }
        };

        int seeded = 0;
        foreach (var p in patterns)
        {
            var r = await _db.StoreAsync(PatternIndex, p["id"].ToString()!, p, ct: ct);
            if (r.IsSuccess) seeded++;
        }
        return DataProcessResult<int>.Ok(seeded);
    }

    // ═══ Helpers ═══

    private async Task<Dictionary<string, object>> LoadPatternOrDefault(string patternId, CancellationToken ct)
    {
        var result = await _db.GetByIdAsync(PatternIndex, patternId, ct);
        return result.IsSuccess ? result.Data : new Dictionary<string, object>
        {
            ["testStyle"] = "arrange-act-assert",
            ["categories"] = new List<string> { "happy-path", "error-handling" },
            ["coverageTarget"] = 80
        };
    }

    private static Dictionary<string, object> InjectScope(Dictionary<string, object> filter, string userId, bool isAdmin)
    {
        var scoped = new Dictionary<string, object>(filter);
        if (!isAdmin && !string.IsNullOrEmpty(userId))
            scoped["_scope_userId"] = userId;
        return scoped;
    }

    private static string GetStr(Dictionary<string, object> doc, string key, string fallback = "")
    {
        if (doc.TryGetValue(key, out var val))
            return val switch { string s => s, JsonElement je => je.ToString(), _ => val?.ToString() ?? fallback };
        return fallback;
    }
}

public static class UnitTestingExtensions
{
    public static IServiceCollection AddUnitTesting(this IServiceCollection services)
    {
        services.AddSingleton<IUnitTestGeneratorService, UnitTestGeneratorService>();
        return services;
    }
}
