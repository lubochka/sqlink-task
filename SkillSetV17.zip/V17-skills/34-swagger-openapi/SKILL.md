---
skill_id: "34"
name: swagger-openapi
title: "Swagger / OpenAPI Generator"
layer: "L8: Quality Assurance"
version: "17.1"
status: "active"
priority: "P1"
dependencies: ["01-core-interfaces", "15-api-gateway", "33-documentation"]
alternatives_server: [swashbuckle, nswag, tsoa, fastapi-openapi, springdoc, utoipa]
genie_dna:
  - "DNA-DOC: Auto-generate OpenAPI specs from code and dynamic schemas"
  - "DNA-6: Spec generation works across all server language alternatives"
  - "DNA-RESULT: Spec generation returns DataProcessResult with validation"
triggers: swagger, openapi, API spec, API documentation, REST API, endpoint docs, schema generation
estimated_loc: 500
---

# Skill 34: Swagger / OpenAPI Generator
## Auto-Generate OpenAPI 3.1 Specifications from XIIGen Services

**Classification:** MACHINE — OpenAPI templates are static  
**Priority:** P1 — Required for API discoverability and MCP integration  
**Dependencies:** Skill 01 (Core), Skill 15 (API Gateway), Skill 33 (Documentation)  
**Layer:** L8: Quality Assurance  
**Estimated LOC:** ~500  

---

## Overview

The Swagger/OpenAPI Generator auto-creates OpenAPI 3.1 specifications from XIIGen microservice endpoints, dynamic document models, and flow definitions. It produces specs that power Swagger UI for interactive API testing, client SDK generation, and MCP tool definitions (Skill 35) that let AI assistants call APIs directly. Specs are validated against the OpenAPI standard and stored as dynamic documents for versioning and diff tracking.

## Key Concepts

- **Dynamic Schema Discovery** — Reads Elasticsearch index mappings and service interfaces to build request/response schemas without hardcoded models.
- **Gateway Aggregation** — Combines specs from all microservices into a unified API Gateway spec with proper routing prefixes.
- **MCP Bridge** — Generated specs are transformed into MCP tool definitions, enabling AI assistants to discover and call APIs.
- **Version Tracking** — Each spec generation is stored with version metadata, enabling diff views between API versions for breaking change detection.
- **Client SDK Generation** — Specs feed into code generators for TypeScript, Python, Java, Swift, and Kotlin client SDKs.

---

## DNA Integration

### Required Patterns
- **DataProcessResult** — Spec generation returns validation results, warnings for undocumented endpoints, breaking changes.
- **Dynamic Document** — Specs stored as dynamic documents. Schema definitions extracted from dynamic document patterns, not fixed models.
- **ObjectProcessor** — Recursively traverses service code to extract endpoint definitions, parameter types, response shapes.
- **BuildSearchFilter** — Query spec history by service, version, date — filter empty fields automatically.

### Anti-Patterns to AVOID
- ❌ Manually maintaining OpenAPI YAML files — auto-generate from code
- ❌ Ignoring dynamic document fields in schema — include `additionalProperties: true`
- ❌ Generating specs without validation — always validate against OpenAPI 3.1 standard
- ❌ Separate specs per service without aggregation — always provide unified gateway spec

---

## Primary Implementation (.NET 9)

### Models

```csharp
namespace XIIGen.Swagger.Models;

public record SpecGenerationRequest(
    string ServiceId,
    string Version,
    string OutputFormat,     // yaml | json
    bool IncludeExamples = true,
    bool AggregateGateway = false,
    DateTime CreatedAt = default
);

public record SpecGenerationResult(
    string ServiceId,
    string Version,
    string Spec,
    SpecValidation Validation,
    List<BreakingChange> BreakingChanges,
    List<string> Warnings
);

public record SpecValidation(bool IsValid, List<string> Errors, int EndpointCount, int SchemaCount);
public record BreakingChange(string Path, string Method, string ChangeType, string Description);
```

### Service Interface

```csharp
namespace XIIGen.Swagger.Interfaces;

public interface ISwaggerService
{
    Task<DataProcessResult<SpecGenerationResult>> GenerateSpecAsync(SpecGenerationRequest request, CancellationToken ct = default);
    Task<DataProcessResult<string>> GetAggregatedSpecAsync(string version, CancellationToken ct = default);
    Task<DataProcessResult<List<BreakingChange>>> CompareVersionsAsync(string serviceId, string v1, string v2, CancellationToken ct = default);
    Task<DataProcessResult<List<McpToolDefinition>>> GenerateMcpToolsAsync(string serviceId, CancellationToken ct = default);
    Task<DataProcessResult<string>> GenerateClientSdkAsync(string serviceId, string language, CancellationToken ct = default);
}
```

### Core Implementation Pattern

```csharp
public class SwaggerService : ISwaggerService
{
    private readonly IDatabaseService _db;
    private readonly ILogger<SwaggerService> _logger;

    public async Task<DataProcessResult<SpecGenerationResult>> GenerateSpecAsync(
        SpecGenerationRequest request, CancellationToken ct = default)
    {
        try
        {
            var endpoints = await IntrospectEndpointsAsync(request.ServiceId, ct);
            var schemas = await IntrospectSchemasAsync(request.ServiceId, ct);
            
            var spec = BuildOpenApiSpec(endpoints, schemas, request);
            var validation = ValidateSpec(spec);
            
            // Check for breaking changes against previous version
            var prevSpec = await _db.GetAsync<string>("openapi-specs",
                $"{request.ServiceId}-latest", ct);
            var breakingChanges = prevSpec.Success 
                ? DetectBreakingChanges(prevSpec.Data, spec) 
                : new List<BreakingChange>();

            // DNA: Store as dynamic document with version tracking
            await _db.UpsertAsync("openapi-specs", new Dictionary<string, object>
            {
                ["id"] = $"{request.ServiceId}-{request.Version}",
                ["serviceId"] = request.ServiceId,
                ["version"] = request.Version,
                ["spec"] = spec,
                ["validation"] = validation,
                ["generatedAt"] = DateTime.UtcNow
            }, ct);
            
            // Update latest pointer
            await _db.UpsertAsync("openapi-specs", new Dictionary<string, object>
            {
                ["id"] = $"{request.ServiceId}-latest",
                ["version"] = request.Version,
                ["spec"] = spec
            }, ct);

            return DataProcessResult<SpecGenerationResult>.Ok(
                new SpecGenerationResult(request.ServiceId, request.Version, spec, validation, breakingChanges, new()));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Spec generation failed for {ServiceId}", request.ServiceId);
            return DataProcessResult<SpecGenerationResult>.Fail(ex.Message);
        }
    }
}
```

### DI Registration

```csharp
services.AddScoped<ISwaggerService, SwaggerService>();
services.AddScoped<IEndpointIntrospector, ReflectionEndpointIntrospector>();
services.AddScoped<ISpecValidator, OpenApi31Validator>();
```

---

## Test Scenarios

1. Generate spec for service with 5 endpoints → verify valid OpenAPI 3.1 with all paths
2. Generate aggregated gateway spec → verify all services merged with correct prefixes
3. Compare v1.0 and v2.0 → verify breaking change detected (removed endpoint)
4. Generate MCP tools from spec → verify tool definitions match endpoint signatures
5. Generate TypeScript SDK → verify type-safe client code with async methods
6. Spec with dynamic document model → verify `additionalProperties: true` in schema
7. Query spec history → verify BuildSearchFilter pattern

## Component Classification
- **Category:** API Specification Automation
- **Inputs:** Service code, endpoint metadata, ES index mappings
- **Outputs:** OpenAPI specs (YAML/JSON), MCP tools, client SDKs, breaking change reports
- **Side Effects:** Stores specs in ES, updates latest pointers
- **ES Indexes:** `openapi-specs`
