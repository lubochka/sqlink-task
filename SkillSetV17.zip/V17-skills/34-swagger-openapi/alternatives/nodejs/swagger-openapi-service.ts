/**
 * XIIGen Skill 34: Swagger / OpenAPI Generator — Node.js Alternative
 * Auto-generates OpenAPI 3.1 specs from XIIGen dynamic schemas
 * DNA: DataProcessResult, dynamic documents, BuildSearchFilter, scope isolation
 */
import { DataProcessResult, IDatabaseService, ILogger } from '../../01-core-interfaces/alternatives/nodejs/core-interfaces';

// --- Interfaces ---
interface OpenApiSpec {
  openapi: string;
  info: { title: string; version: string; description: string };
  servers: Array<{ url: string; description: string }>;
  paths: Record<string, PathItem>;
  components: { schemas: Record<string, SchemaObject>; securitySchemes: Record<string, any> };
}

interface PathItem {
  [method: string]: OperationObject;
}

interface OperationObject {
  operationId: string; summary: string; tags: string[];
  parameters?: ParameterObject[]; requestBody?: RequestBodyObject;
  responses: Record<string, ResponseObject>; security?: any[];
}

interface ParameterObject { name: string; in: string; required: boolean; schema: SchemaObject; }
interface RequestBodyObject { required: boolean; content: Record<string, { schema: SchemaObject }>; }
interface ResponseObject { description: string; content?: Record<string, { schema: SchemaObject }>; }
interface SchemaObject { type?: string; properties?: Record<string, any>; items?: any; $ref?: string; }

interface SpecGenerationRequest {
  serviceName: string;
  version: string;
  endpoints: EndpointDefinition[];
  scopeId: string; // DNA: scope isolation
}

interface EndpointDefinition {
  path: string;
  method: string;
  operationId: string;
  summary: string;
  tags: string[];
  requestSchema?: Record<string, any>;
  responseSchema?: Record<string, any>;
  requiresAuth: boolean;
  parameters?: Array<{ name: string; in: string; type: string; required: boolean }>;
}

// --- Service ---
export class SwaggerOpenApiService {
  private readonly INDEX = 'api-specs';

  constructor(
    private db: IDatabaseService,
    private logger: ILogger
  ) {}

  /**
   * Generate OpenAPI 3.1 spec from service endpoint definitions
   * DNA: DataProcessResult wrapping, dynamic document storage
   */
  async generateSpec(request: SpecGenerationRequest): Promise<DataProcessResult<OpenApiSpec>> {
    try {
      const spec = this.buildSpec(request);
      const validation = this.validateSpec(spec);
      if (!validation.success) {
        return { success: false, data: spec, message: `Validation failed: ${validation.message}` };
      }

      // DNA: Store as dynamic document with scope isolation
      await this.db.upsert(this.INDEX, {
        id: `${request.scopeId}-${request.serviceName}-${request.version}`,
        scopeId: request.scopeId,
        serviceName: request.serviceName,
        version: request.version,
        spec: JSON.stringify(spec),
        endpointCount: request.endpoints.length,
        generatedAt: new Date().toISOString(),
        status: 'active'
      });

      this.logger.info('OpenAPI spec generated', {
        service: request.serviceName, version: request.version,
        endpoints: request.endpoints.length
      });

      return { success: true, data: spec, message: `Spec generated: ${request.endpoints.length} endpoints` };
    } catch (error: any) {
      this.logger.error('Spec generation failed', { error: error.message, service: request.serviceName });
      return { success: false, data: {} as OpenApiSpec, message: error.message };
    }
  }

  /**
   * Query stored specs with dynamic filtering
   * DNA: BuildSearchFilter — skip empty/null values
   */
  async querySpecs(filter: Record<string, any>): Promise<DataProcessResult<any[]>> {
    try {
      // DNA: BuildSearchFilter — only include non-empty values
      const cleanFilter = Object.entries(filter)
        .filter(([_, v]) => v !== null && v !== undefined && v !== '')
        .reduce((acc, [k, v]) => ({ ...acc, [k]: v }), {} as Record<string, any>);

      const results = await this.db.query(this.INDEX, cleanFilter);
      return { success: true, data: results, message: `Found ${results.length} specs` };
    } catch (error: any) {
      return { success: false, data: [], message: error.message };
    }
  }

  /**
   * Merge specs from multiple services into a unified API doc
   */
  async mergeSpecs(scopeId: string, title: string, version: string): Promise<DataProcessResult<OpenApiSpec>> {
    try {
      const allSpecs = await this.db.query(this.INDEX, { scopeId, status: 'active' });
      if (!allSpecs.length) {
        return { success: false, data: {} as OpenApiSpec, message: 'No specs found for scope' };
      }

      const merged: OpenApiSpec = {
        openapi: '3.1.0',
        info: { title, version, description: `Unified API for scope ${scopeId}` },
        servers: [{ url: '/api', description: 'API Gateway' }],
        paths: {},
        components: { schemas: {}, securitySchemes: { bearerAuth: { type: 'http', scheme: 'bearer', bearerFormat: 'JWT' } } }
      };

      for (const specDoc of allSpecs) {
        const spec: OpenApiSpec = JSON.parse(specDoc.spec);
        Object.assign(merged.paths, spec.paths);
        Object.assign(merged.components.schemas, spec.components?.schemas || {});
      }

      return { success: true, data: merged, message: `Merged ${allSpecs.length} service specs` };
    } catch (error: any) {
      return { success: false, data: {} as OpenApiSpec, message: error.message };
    }
  }

  /**
   * Generate spec from dynamic document index schema (Genie DNA pattern)
   * Converts ES index mappings into OpenAPI schemas automatically
   */
  async generateFromDynamicSchema(
    scopeId: string, indexName: string, basePath: string
  ): Promise<DataProcessResult<OpenApiSpec>> {
    try {
      // DNA: Dynamic documents → auto-generate CRUD endpoints
      const endpoints: EndpointDefinition[] = [
        { path: `${basePath}`, method: 'get', operationId: `list_${indexName}`, summary: `List ${indexName}`, tags: [indexName], requiresAuth: true, responseSchema: { type: 'array' } },
        { path: `${basePath}/{id}`, method: 'get', operationId: `get_${indexName}`, summary: `Get ${indexName} by ID`, tags: [indexName], requiresAuth: true, parameters: [{ name: 'id', in: 'path', type: 'string', required: true }] },
        { path: `${basePath}`, method: 'post', operationId: `create_${indexName}`, summary: `Create ${indexName}`, tags: [indexName], requiresAuth: true, requestSchema: { type: 'object' } },
        { path: `${basePath}/{id}`, method: 'put', operationId: `update_${indexName}`, summary: `Update ${indexName}`, tags: [indexName], requiresAuth: true, requestSchema: { type: 'object' } },
        { path: `${basePath}/{id}`, method: 'delete', operationId: `delete_${indexName}`, summary: `Delete ${indexName}`, tags: [indexName], requiresAuth: true },
        { path: `${basePath}/search`, method: 'post', operationId: `search_${indexName}`, summary: `Search ${indexName}`, tags: [indexName], requiresAuth: true, requestSchema: { type: 'object' } }
      ];

      return this.generateSpec({ serviceName: indexName, version: '1.0.0', endpoints, scopeId });
    } catch (error: any) {
      return { success: false, data: {} as OpenApiSpec, message: error.message };
    }
  }

  // --- Private Helpers ---

  private buildSpec(request: SpecGenerationRequest): OpenApiSpec {
    const paths: Record<string, PathItem> = {};
    const schemas: Record<string, SchemaObject> = {};

    for (const ep of request.endpoints) {
      if (!paths[ep.path]) paths[ep.path] = {};
      const operation: OperationObject = {
        operationId: ep.operationId,
        summary: ep.summary,
        tags: ep.tags,
        responses: {
          '200': { description: 'Success', content: ep.responseSchema ? { 'application/json': { schema: ep.responseSchema as SchemaObject } } : undefined },
          '400': { description: 'Bad Request' },
          '401': { description: 'Unauthorized' },
          '500': { description: 'Internal Server Error' }
        }
      };
      if (ep.requiresAuth) operation.security = [{ bearerAuth: [] }];
      if (ep.requestSchema) operation.requestBody = { required: true, content: { 'application/json': { schema: ep.requestSchema as SchemaObject } } };
      if (ep.parameters) operation.parameters = ep.parameters.map(p => ({ name: p.name, in: p.in, required: p.required, schema: { type: p.type } }));
      paths[ep.path][ep.method] = operation;
    }

    return {
      openapi: '3.1.0',
      info: { title: `${request.serviceName} API`, version: request.version, description: `Auto-generated spec for ${request.serviceName}` },
      servers: [{ url: `/api/${request.serviceName}`, description: request.serviceName }],
      paths,
      components: { schemas, securitySchemes: { bearerAuth: { type: 'http', scheme: 'bearer', bearerFormat: 'JWT' } } }
    };
  }

  private validateSpec(spec: OpenApiSpec): { success: boolean; message: string } {
    if (!spec.openapi) return { success: false, message: 'Missing openapi version' };
    if (!spec.info?.title) return { success: false, message: 'Missing info.title' };
    if (!spec.paths || Object.keys(spec.paths).length === 0) return { success: false, message: 'No paths defined' };
    return { success: true, message: 'Valid' };
  }
}

// --- Express Middleware for Swagger UI ---
export function createSwaggerMiddleware(swaggerService: SwaggerOpenApiService, scopeId: string) {
  return async (req: any, res: any, next: any) => {
    if (req.path === '/api-docs.json') {
      const result = await swaggerService.mergeSpecs(scopeId, 'XIIGen API', '1.0.0');
      if (result.success) res.json(result.data);
      else res.status(500).json({ error: result.message });
    } else next();
  };
}
