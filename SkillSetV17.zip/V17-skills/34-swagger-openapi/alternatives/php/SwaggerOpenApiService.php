<?php
/**
 * XIIGen Skill 34: Swagger / OpenAPI Generator — PHP Alternative
 * Auto-generates OpenAPI 3.1 specs from XIIGen dynamic schemas
 * DNA: DataProcessResult, dynamic documents, BuildSearchFilter, scope isolation
 */

namespace XIIGen\Swagger;

class DataProcessResult {
    public function __construct(
        public readonly bool $success,
        public readonly mixed $data,
        public readonly string $message
    ) {}

    public static function ok(mixed $data, string $msg): self {
        return new self(true, $data, $msg);
    }

    public static function error(string $msg): self {
        return new self(false, null, $msg);
    }
}

class EndpointDefinition {
    public function __construct(
        public readonly string $path,
        public readonly string $method,
        public readonly string $operationId,
        public readonly string $summary,
        public readonly array $tags,
        public readonly bool $requiresAuth = true,
        public readonly ?array $requestSchema = null,
        public readonly ?array $responseSchema = null,
        public readonly ?array $parameters = null
    ) {}
}

class SpecGenerationRequest {
    public function __construct(
        public readonly string $serviceName,
        public readonly string $version,
        /** @var EndpointDefinition[] */
        public readonly array $endpoints,
        public readonly string $scopeId // DNA: scope isolation
    ) {}
}

class SwaggerOpenApiService {
    private const INDEX = 'api-specs';

    public function __construct(
        private readonly object $db,     // IDatabaseService
        private readonly object $logger  // ILogger
    ) {}

    /**
     * Generate OpenAPI 3.1 spec from endpoint definitions.
     * DNA: DataProcessResult wrapping, dynamic document storage, scope isolation.
     */
    public function generateSpec(SpecGenerationRequest $request): DataProcessResult {
        try {
            $spec = $this->buildSpec($request);
            $validation = $this->validateSpec($spec);
            if (!$validation->success) {
                return DataProcessResult::error("Validation failed: {$validation->message}");
            }

            // DNA: Store as dynamic document with scope isolation
            $this->db->upsert(self::INDEX, [
                'id' => "{$request->scopeId}-{$request->serviceName}-{$request->version}",
                'scopeId' => $request->scopeId,
                'serviceName' => $request->serviceName,
                'version' => $request->version,
                'spec' => json_encode($spec),
                'endpointCount' => count($request->endpoints),
                'generatedAt' => (new \DateTimeImmutable())->format(\DateTimeInterface::ATOM),
                'status' => 'active',
            ]);

            $count = count($request->endpoints);
            $this->logger->info("OpenAPI spec generated: {$request->serviceName} v{$request->version}, {$count} endpoints");
            return DataProcessResult::ok($spec, "Spec generated: {$count} endpoints");

        } catch (\Throwable $e) {
            $this->logger->error("Spec generation failed: {$e->getMessage()}");
            return DataProcessResult::error($e->getMessage());
        }
    }

    /**
     * Query stored specs with dynamic filtering.
     * DNA: BuildSearchFilter — skip null/empty values.
     */
    public function querySpecs(array $filters): DataProcessResult {
        try {
            // DNA: BuildSearchFilter — remove empty entries
            $cleanFilter = array_filter($filters, fn($v) => $v !== null && $v !== '');
            $results = $this->db->query(self::INDEX, $cleanFilter);
            $count = count($results);
            return DataProcessResult::ok($results, "Found {$count} specs");
        } catch (\Throwable $e) {
            return DataProcessResult::error($e->getMessage());
        }
    }

    /**
     * Merge specs from multiple services into unified API doc.
     */
    public function mergeSpecs(string $scopeId, string $title, string $version): DataProcessResult {
        try {
            $allSpecs = $this->db->query(self::INDEX, ['scopeId' => $scopeId, 'status' => 'active']);
            if (empty($allSpecs)) {
                return DataProcessResult::error('No specs found for scope');
            }

            $merged = [
                'openapi' => '3.1.0',
                'info' => ['title' => $title, 'version' => $version,
                           'description' => "Unified API for scope {$scopeId}"],
                'servers' => [['url' => '/api', 'description' => 'API Gateway']],
                'paths' => [],
                'components' => [
                    'schemas' => [],
                    'securitySchemes' => [
                        'bearerAuth' => ['type' => 'http', 'scheme' => 'bearer', 'bearerFormat' => 'JWT']
                    ]
                ]
            ];

            foreach ($allSpecs as $specDoc) {
                $spec = json_decode($specDoc['spec'] ?? '{}', true);
                $merged['paths'] = array_merge($merged['paths'], $spec['paths'] ?? []);
                $merged['components']['schemas'] = array_merge(
                    $merged['components']['schemas'],
                    $spec['components']['schemas'] ?? []
                );
            }

            $count = count($allSpecs);
            return DataProcessResult::ok($merged, "Merged {$count} service specs");
        } catch (\Throwable $e) {
            return DataProcessResult::error($e->getMessage());
        }
    }

    /**
     * Generate spec from dynamic document index (Genie DNA pattern).
     * Auto-creates CRUD endpoints for any dynamic document index.
     */
    public function generateFromDynamicSchema(string $scopeId, string $indexName, string $basePath): DataProcessResult {
        try {
            $endpoints = [
                new EndpointDefinition($basePath, 'get', "list_{$indexName}", "List {$indexName}", [$indexName]),
                new EndpointDefinition("{$basePath}/{id}", 'get', "get_{$indexName}", "Get {$indexName} by ID", [$indexName], true, null, null, [['name'=>'id','in'=>'path','type'=>'string','required'=>true]]),
                new EndpointDefinition($basePath, 'post', "create_{$indexName}", "Create {$indexName}", [$indexName], true, ['type'=>'object']),
                new EndpointDefinition("{$basePath}/{id}", 'put', "update_{$indexName}", "Update {$indexName}", [$indexName], true, ['type'=>'object']),
                new EndpointDefinition("{$basePath}/{id}", 'delete', "delete_{$indexName}", "Delete {$indexName}", [$indexName]),
                new EndpointDefinition("{$basePath}/search", 'post', "search_{$indexName}", "Search {$indexName}", [$indexName], true, ['type'=>'object']),
            ];
            return $this->generateSpec(new SpecGenerationRequest($indexName, '1.0.0', $endpoints, $scopeId));
        } catch (\Throwable $e) {
            return DataProcessResult::error($e->getMessage());
        }
    }

    // --- Private Helpers ---

    private function buildSpec(SpecGenerationRequest $request): array {
        $paths = [];
        foreach ($request->endpoints as $ep) {
            $operation = [
                'operationId' => $ep->operationId,
                'summary' => $ep->summary,
                'tags' => $ep->tags,
                'responses' => [
                    '200' => ['description' => 'Success'],
                    '400' => ['description' => 'Bad Request'],
                    '401' => ['description' => 'Unauthorized'],
                    '500' => ['description' => 'Internal Server Error'],
                ],
            ];
            if ($ep->responseSchema) {
                $operation['responses']['200']['content'] = ['application/json' => ['schema' => $ep->responseSchema]];
            }
            if ($ep->requiresAuth) { $operation['security'] = [['bearerAuth' => []]]; }
            if ($ep->requestSchema) { $operation['requestBody'] = ['required' => true, 'content' => ['application/json' => ['schema' => $ep->requestSchema]]]; }
            if ($ep->parameters) {
                $operation['parameters'] = array_map(fn($p) => ['name' => $p['name'], 'in' => $p['in'], 'required' => $p['required'], 'schema' => ['type' => $p['type']]], $ep->parameters);
            }
            $paths[$ep->path][$ep->method] = $operation;
        }

        return [
            'openapi' => '3.1.0',
            'info' => ['title' => "{$request->serviceName} API", 'version' => $request->version, 'description' => "Auto-generated for {$request->serviceName}"],
            'servers' => [['url' => "/api/{$request->serviceName}", 'description' => $request->serviceName]],
            'paths' => $paths,
            'components' => ['schemas' => [], 'securitySchemes' => ['bearerAuth' => ['type' => 'http', 'scheme' => 'bearer', 'bearerFormat' => 'JWT']]],
        ];
    }

    private function validateSpec(array $spec): DataProcessResult {
        if (empty($spec['openapi'])) return DataProcessResult::error('Missing openapi version');
        if (empty($spec['info']['title'])) return DataProcessResult::error('Missing info.title');
        if (empty($spec['paths'])) return DataProcessResult::error('No paths defined');
        return DataProcessResult::ok(null, 'Valid');
    }
}
