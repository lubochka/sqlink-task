// XIIGen Skill 34: Swagger / OpenAPI Generator — Rust Alternative
// Auto-generates OpenAPI 3.1 specs from XIIGen dynamic schemas
// DNA: DataProcessResult, dynamic documents, BuildSearchFilter, scope isolation

use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use chrono::Utc;

// --- Core DNA Types ---
#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct DataProcessResult<T> {
    pub success: bool,
    pub data: T,
    pub message: String,
}

impl<T: Default> DataProcessResult<T> {
    pub fn ok(data: T, msg: &str) -> Self {
        Self { success: true, data, message: msg.to_string() }
    }
    pub fn err(msg: &str) -> Self {
        Self { success: false, data: T::default(), message: msg.to_string() }
    }
}

// --- Models ---
#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct SpecGenerationRequest {
    pub service_name: String,
    pub version: String,
    pub endpoints: Vec<EndpointDefinition>,
    pub scope_id: String, // DNA: scope isolation
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct EndpointDefinition {
    pub path: String,
    pub method: String,
    pub operation_id: String,
    pub summary: String,
    pub tags: Vec<String>,
    pub requires_auth: bool,
    pub request_schema: Option<serde_json::Value>,
    pub response_schema: Option<serde_json::Value>,
    pub parameters: Option<Vec<ParameterDef>>,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct ParameterDef {
    pub name: String,
    pub location: String, // "path", "query", "header"
    pub param_type: String,
    pub required: bool,
}

#[derive(Debug, Serialize, Deserialize, Clone, Default)]
pub struct OpenApiSpec {
    pub openapi: String,
    pub info: SpecInfo,
    pub servers: Vec<ServerDef>,
    pub paths: HashMap<String, HashMap<String, OperationObject>>,
    pub components: Components,
}

#[derive(Debug, Serialize, Deserialize, Clone, Default)]
pub struct SpecInfo { pub title: String, pub version: String, pub description: String }
#[derive(Debug, Serialize, Deserialize, Clone, Default)]
pub struct ServerDef { pub url: String, pub description: String }
#[derive(Debug, Serialize, Deserialize, Clone, Default)]
pub struct Components {
    pub schemas: HashMap<String, serde_json::Value>,
    pub security_schemes: HashMap<String, serde_json::Value>,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct OperationObject {
    pub operation_id: String,
    pub summary: String,
    pub tags: Vec<String>,
    pub responses: HashMap<String, ResponseObject>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub security: Option<Vec<HashMap<String, Vec<String>>>>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub request_body: Option<serde_json::Value>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub parameters: Option<Vec<serde_json::Value>>,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct ResponseObject {
    pub description: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub content: Option<serde_json::Value>,
}

// --- Traits ---
#[async_trait::async_trait]
pub trait IDatabaseService: Send + Sync {
    async fn upsert(&self, index: &str, doc: serde_json::Value) -> Result<(), Box<dyn std::error::Error>>;
    async fn query(&self, index: &str, filter: serde_json::Value) -> Result<Vec<serde_json::Value>, Box<dyn std::error::Error>>;
}

pub trait ILogger: Send + Sync {
    fn info(&self, msg: &str);
    fn error(&self, msg: &str);
}

// --- Service ---
pub struct SwaggerOpenApiService {
    db: Box<dyn IDatabaseService>,
    logger: Box<dyn ILogger>,
}

impl SwaggerOpenApiService {
    const INDEX: &'static str = "api-specs";

    pub fn new(db: Box<dyn IDatabaseService>, logger: Box<dyn ILogger>) -> Self {
        Self { db, logger }
    }

    /// Generate OpenAPI 3.1 spec from endpoint definitions
    /// DNA: DataProcessResult wrapping, dynamic document storage
    pub async fn generate_spec(&self, request: &SpecGenerationRequest) -> DataProcessResult<OpenApiSpec> {
        match self.try_generate(request).await {
            Ok(spec) => spec,
            Err(e) => {
                self.logger.error(&format!("Spec generation failed: {}", e));
                DataProcessResult::err(&e.to_string())
            }
        }
    }

    async fn try_generate(&self, request: &SpecGenerationRequest) -> Result<DataProcessResult<OpenApiSpec>, Box<dyn std::error::Error>> {
        let spec = self.build_spec(request);
        if let Err(msg) = self.validate_spec(&spec) {
            return Ok(DataProcessResult::err(&format!("Validation failed: {}", msg)));
        }

        // DNA: Store as dynamic document with scope isolation
        let doc = serde_json::json!({
            "id": format!("{}-{}-{}", request.scope_id, request.service_name, request.version),
            "scopeId": request.scope_id,
            "serviceName": request.service_name,
            "version": request.version,
            "spec": serde_json::to_string(&spec)?,
            "endpointCount": request.endpoints.len(),
            "generatedAt": Utc::now().to_rfc3339(),
            "status": "active"
        });
        self.db.upsert(Self::INDEX, doc).await?;

        self.logger.info(&format!("OpenAPI spec generated: {} v{}, {} endpoints",
            request.service_name, request.version, request.endpoints.len()));
        Ok(DataProcessResult::ok(spec, &format!("Spec generated: {} endpoints", request.endpoints.len())))
    }

    /// Query stored specs with dynamic filtering
    /// DNA: BuildSearchFilter — skip empty/None values
    pub async fn query_specs(&self, filters: HashMap<String, String>) -> DataProcessResult<Vec<serde_json::Value>> {
        // DNA: BuildSearchFilter — only non-empty values
        let clean: HashMap<&str, &str> = filters.iter()
            .filter(|(_, v)| !v.is_empty())
            .map(|(k, v)| (k.as_str(), v.as_str()))
            .collect();

        match self.db.query(Self::INDEX, serde_json::to_value(&clean).unwrap_or_default()).await {
            Ok(results) => {
                let count = results.len();
                DataProcessResult::ok(results, &format!("Found {} specs", count))
            }
            Err(e) => DataProcessResult::err(&e.to_string()),
        }
    }

    /// Generate spec from dynamic document index (Genie DNA pattern)
    pub async fn generate_from_dynamic_schema(
        &self, scope_id: &str, index_name: &str, base_path: &str
    ) -> DataProcessResult<OpenApiSpec> {
        let endpoints = vec![
            EndpointDefinition { path: base_path.to_string(), method: "get".into(), operation_id: format!("list_{}", index_name), summary: format!("List {}", index_name), tags: vec![index_name.to_string()], requires_auth: true, request_schema: None, response_schema: None, parameters: None },
            EndpointDefinition { path: format!("{}/{{id}}", base_path), method: "get".into(), operation_id: format!("get_{}", index_name), summary: format!("Get {} by ID", index_name), tags: vec![index_name.to_string()], requires_auth: true, request_schema: None, response_schema: None, parameters: Some(vec![ParameterDef { name: "id".into(), location: "path".into(), param_type: "string".into(), required: true }]) },
            EndpointDefinition { path: base_path.to_string(), method: "post".into(), operation_id: format!("create_{}", index_name), summary: format!("Create {}", index_name), tags: vec![index_name.to_string()], requires_auth: true, request_schema: Some(serde_json::json!({"type":"object"})), response_schema: None, parameters: None },
            EndpointDefinition { path: format!("{}/{{id}}", base_path), method: "put".into(), operation_id: format!("update_{}", index_name), summary: format!("Update {}", index_name), tags: vec![index_name.to_string()], requires_auth: true, request_schema: Some(serde_json::json!({"type":"object"})), response_schema: None, parameters: None },
            EndpointDefinition { path: format!("{}/{{id}}", base_path), method: "delete".into(), operation_id: format!("delete_{}", index_name), summary: format!("Delete {}", index_name), tags: vec![index_name.to_string()], requires_auth: true, request_schema: None, response_schema: None, parameters: None },
            EndpointDefinition { path: format!("{}/search", base_path), method: "post".into(), operation_id: format!("search_{}", index_name), summary: format!("Search {}", index_name), tags: vec![index_name.to_string()], requires_auth: true, request_schema: Some(serde_json::json!({"type":"object"})), response_schema: None, parameters: None },
        ];
        let req = SpecGenerationRequest { service_name: index_name.to_string(), version: "1.0.0".to_string(), endpoints, scope_id: scope_id.to_string() };
        self.generate_spec(&req).await
    }

    // --- Private ---
    fn build_spec(&self, request: &SpecGenerationRequest) -> OpenApiSpec {
        let mut paths: HashMap<String, HashMap<String, OperationObject>> = HashMap::new();
        for ep in &request.endpoints {
            let entry = paths.entry(ep.path.clone()).or_insert_with(HashMap::new);
            let mut responses = HashMap::new();
            responses.insert("200".into(), ResponseObject { description: "Success".into(), content: ep.response_schema.as_ref().map(|s| serde_json::json!({"application/json":{"schema":s}})) });
            responses.insert("400".into(), ResponseObject { description: "Bad Request".into(), content: None });
            responses.insert("401".into(), ResponseObject { description: "Unauthorized".into(), content: None });
            entry.insert(ep.method.clone(), OperationObject {
                operation_id: ep.operation_id.clone(), summary: ep.summary.clone(), tags: ep.tags.clone(),
                responses,
                security: if ep.requires_auth { Some(vec![HashMap::from([("bearerAuth".to_string(), vec![])])]) } else { None },
                request_body: ep.request_schema.as_ref().map(|s| serde_json::json!({"required":true,"content":{"application/json":{"schema":s}}})),
                parameters: ep.parameters.as_ref().map(|ps| ps.iter().map(|p| serde_json::json!({"name":p.name,"in":p.location,"required":p.required,"schema":{"type":p.param_type}})).collect()),
            });
        }
        let mut security_schemes = HashMap::new();
        security_schemes.insert("bearerAuth".into(), serde_json::json!({"type":"http","scheme":"bearer","bearerFormat":"JWT"}));
        OpenApiSpec {
            openapi: "3.1.0".into(),
            info: SpecInfo { title: format!("{} API", request.service_name), version: request.version.clone(), description: format!("Auto-generated for {}", request.service_name) },
            servers: vec![ServerDef { url: format!("/api/{}", request.service_name), description: request.service_name.clone() }],
            paths, components: Components { schemas: HashMap::new(), security_schemes },
        }
    }

    fn validate_spec(&self, spec: &OpenApiSpec) -> Result<(), String> {
        if spec.openapi.is_empty() { return Err("Missing openapi version".into()); }
        if spec.info.title.is_empty() { return Err("Missing info.title".into()); }
        if spec.paths.is_empty() { return Err("No paths defined".into()); }
        Ok(())
    }
}
