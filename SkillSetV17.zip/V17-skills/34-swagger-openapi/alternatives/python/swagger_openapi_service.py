"""
XIIGen Skill 34: Swagger / OpenAPI Generator — Python Alternative
Auto-generates OpenAPI 3.1 specs from XIIGen dynamic schemas
DNA: DataProcessResult, dynamic documents, BuildSearchFilter, scope isolation
"""
from dataclasses import dataclass, field
from typing import Any, Optional
from datetime import datetime
import json


@dataclass
class DataProcessResult:
    success: bool
    data: Any
    message: str


@dataclass
class EndpointDefinition:
    path: str
    method: str
    operation_id: str
    summary: str
    tags: list[str]
    requires_auth: bool = True
    request_schema: Optional[dict] = None
    response_schema: Optional[dict] = None
    parameters: Optional[list[dict]] = None


@dataclass
class SpecGenerationRequest:
    service_name: str
    version: str
    endpoints: list[EndpointDefinition]
    scope_id: str  # DNA: scope isolation


class SwaggerOpenApiService:
    """
    Generates and manages OpenAPI 3.1 specifications for XIIGen services.
    DNA patterns: DataProcessResult, dynamic documents, BuildSearchFilter, scope isolation.
    """
    INDEX = "api-specs"

    def __init__(self, db, logger):
        self._db = db
        self._logger = logger

    async def generate_spec(self, request: SpecGenerationRequest) -> DataProcessResult:
        """Generate OpenAPI 3.1 spec from endpoint definitions."""
        try:
            spec = self._build_spec(request)
            validation = self._validate_spec(spec)
            if not validation.success:
                return DataProcessResult(False, spec, f"Validation failed: {validation.message}")

            # DNA: Store as dynamic document with scope isolation
            await self._db.upsert(self.INDEX, {
                "id": f"{request.scope_id}-{request.service_name}-{request.version}",
                "scopeId": request.scope_id,
                "serviceName": request.service_name,
                "version": request.version,
                "spec": json.dumps(spec),
                "endpointCount": len(request.endpoints),
                "generatedAt": datetime.utcnow().isoformat(),
                "status": "active"
            })

            self._logger.info(f"OpenAPI spec generated: {request.service_name} v{request.version}, "
                              f"{len(request.endpoints)} endpoints")
            return DataProcessResult(True, spec, f"Spec generated: {len(request.endpoints)} endpoints")

        except Exception as e:
            self._logger.error(f"Spec generation failed: {e}")
            return DataProcessResult(False, {}, str(e))

    async def query_specs(self, **filters) -> DataProcessResult:
        """
        Query stored specs with dynamic filtering.
        DNA: BuildSearchFilter — skip empty/None values.
        """
        try:
            # DNA: BuildSearchFilter
            clean_filter = {k: v for k, v in filters.items()
                           if v is not None and v != ""}
            results = await self._db.query(self.INDEX, clean_filter)
            return DataProcessResult(True, results, f"Found {len(results)} specs")
        except Exception as e:
            return DataProcessResult(False, [], str(e))

    async def merge_specs(self, scope_id: str, title: str, version: str) -> DataProcessResult:
        """Merge specs from multiple services into unified API doc."""
        try:
            all_specs = await self._db.query(self.INDEX, {"scopeId": scope_id, "status": "active"})
            if not all_specs:
                return DataProcessResult(False, {}, "No specs found for scope")

            merged = {
                "openapi": "3.1.0",
                "info": {"title": title, "version": version,
                         "description": f"Unified API for scope {scope_id}"},
                "servers": [{"url": "/api", "description": "API Gateway"}],
                "paths": {},
                "components": {
                    "schemas": {},
                    "securitySchemes": {
                        "bearerAuth": {"type": "http", "scheme": "bearer", "bearerFormat": "JWT"}
                    }
                }
            }

            for spec_doc in all_specs:
                spec = json.loads(spec_doc.get("spec", "{}"))
                merged["paths"].update(spec.get("paths", {}))
                merged["components"]["schemas"].update(
                    spec.get("components", {}).get("schemas", {}))

            return DataProcessResult(True, merged, f"Merged {len(all_specs)} service specs")
        except Exception as e:
            return DataProcessResult(False, {}, str(e))

    async def generate_from_dynamic_schema(
        self, scope_id: str, index_name: str, base_path: str
    ) -> DataProcessResult:
        """
        Generate spec from dynamic document index schema (Genie DNA pattern).
        Auto-creates CRUD endpoints for any dynamic document index.
        """
        try:
            endpoints = [
                EndpointDefinition(base_path, "get", f"list_{index_name}",
                                   f"List {index_name}", [index_name]),
                EndpointDefinition(f"{base_path}/{{id}}", "get", f"get_{index_name}",
                                   f"Get {index_name} by ID", [index_name],
                                   parameters=[{"name": "id", "in": "path", "type": "string", "required": True}]),
                EndpointDefinition(base_path, "post", f"create_{index_name}",
                                   f"Create {index_name}", [index_name],
                                   request_schema={"type": "object"}),
                EndpointDefinition(f"{base_path}/{{id}}", "put", f"update_{index_name}",
                                   f"Update {index_name}", [index_name],
                                   request_schema={"type": "object"}),
                EndpointDefinition(f"{base_path}/{{id}}", "delete", f"delete_{index_name}",
                                   f"Delete {index_name}", [index_name]),
                EndpointDefinition(f"{base_path}/search", "post", f"search_{index_name}",
                                   f"Search {index_name}", [index_name],
                                   request_schema={"type": "object"}),
            ]
            return await self.generate_spec(
                SpecGenerationRequest(index_name, "1.0.0", endpoints, scope_id))
        except Exception as e:
            return DataProcessResult(False, {}, str(e))

    # --- Private Helpers ---

    def _build_spec(self, request: SpecGenerationRequest) -> dict:
        paths: dict[str, dict] = {}
        for ep in request.endpoints:
            if ep.path not in paths:
                paths[ep.path] = {}
            operation: dict[str, Any] = {
                "operationId": ep.operation_id,
                "summary": ep.summary,
                "tags": ep.tags,
                "responses": {
                    "200": {"description": "Success"},
                    "400": {"description": "Bad Request"},
                    "401": {"description": "Unauthorized"},
                    "500": {"description": "Internal Server Error"},
                }
            }
            if ep.response_schema:
                operation["responses"]["200"]["content"] = {
                    "application/json": {"schema": ep.response_schema}}
            if ep.requires_auth:
                operation["security"] = [{"bearerAuth": []}]
            if ep.request_schema:
                operation["requestBody"] = {
                    "required": True,
                    "content": {"application/json": {"schema": ep.request_schema}}}
            if ep.parameters:
                operation["parameters"] = [
                    {"name": p["name"], "in": p["in"], "required": p["required"],
                     "schema": {"type": p["type"]}} for p in ep.parameters]
            paths[ep.path][ep.method] = operation

        return {
            "openapi": "3.1.0",
            "info": {"title": f"{request.service_name} API",
                     "version": request.version,
                     "description": f"Auto-generated spec for {request.service_name}"},
            "servers": [{"url": f"/api/{request.service_name}",
                         "description": request.service_name}],
            "paths": paths,
            "components": {
                "schemas": {},
                "securitySchemes": {
                    "bearerAuth": {"type": "http", "scheme": "bearer", "bearerFormat": "JWT"}
                }
            }
        }

    def _validate_spec(self, spec: dict) -> DataProcessResult:
        if not spec.get("openapi"):
            return DataProcessResult(False, None, "Missing openapi version")
        if not spec.get("info", {}).get("title"):
            return DataProcessResult(False, None, "Missing info.title")
        if not spec.get("paths"):
            return DataProcessResult(False, None, "No paths defined")
        return DataProcessResult(True, None, "Valid")


# --- FastAPI Integration ---
def create_openapi_router(service: SwaggerOpenApiService, scope_id: str):
    """FastAPI router for serving generated OpenAPI specs."""
    from fastapi import APIRouter
    router = APIRouter(prefix="/swagger", tags=["OpenAPI"])

    @router.get("/spec.json")
    async def get_merged_spec():
        result = await service.merge_specs(scope_id, "XIIGen API", "1.0.0")
        if result.success:
            return result.data
        return {"error": result.message}

    @router.post("/generate/{service_name}")
    async def generate_spec(service_name: str, body: dict):
        endpoints = [EndpointDefinition(**ep) for ep in body.get("endpoints", [])]
        request = SpecGenerationRequest(service_name, body.get("version", "1.0.0"),
                                        endpoints, scope_id)
        return await service.generate_spec(request)

    return router
