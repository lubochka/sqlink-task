/**
 * XIIGen Skill 34: Swagger / OpenAPI Generator — Java Alternative
 * Auto-generates OpenAPI 3.1 specs from XIIGen dynamic schemas
 * DNA: DataProcessResult, dynamic documents, BuildSearchFilter, scope isolation
 */
package com.xiigen.swagger;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

public class SwaggerOpenApiService {

    private static final String INDEX = "api-specs";
    private final IDatabaseService db;
    private final ILogger logger;
    private final ObjectMapper mapper = new ObjectMapper();

    public SwaggerOpenApiService(IDatabaseService db, ILogger logger) {
        this.db = db;
        this.logger = logger;
    }

    /**
     * Generate OpenAPI 3.1 spec from endpoint definitions.
     * DNA: DataProcessResult wrapping, dynamic document storage, scope isolation.
     */
    public DataProcessResult<Map<String, Object>> generateSpec(SpecGenerationRequest request) {
        try {
            Map<String, Object> spec = buildSpec(request);
            DataProcessResult<Void> validation = validateSpec(spec);
            if (!validation.isSuccess()) {
                return DataProcessResult.error("Validation failed: " + validation.getMessage());
            }

            // DNA: Store as dynamic document with scope isolation
            Map<String, Object> doc = new HashMap<>();
            doc.put("id", request.getScopeId() + "-" + request.getServiceName() + "-" + request.getVersion());
            doc.put("scopeId", request.getScopeId());
            doc.put("serviceName", request.getServiceName());
            doc.put("version", request.getVersion());
            doc.put("spec", mapper.writeValueAsString(spec));
            doc.put("endpointCount", request.getEndpoints().size());
            doc.put("generatedAt", Instant.now().toString());
            doc.put("status", "active");

            db.upsert(INDEX, doc);
            logger.info("OpenAPI spec generated: " + request.getServiceName() +
                        " v" + request.getVersion() + ", " + request.getEndpoints().size() + " endpoints");
            return DataProcessResult.success(spec, "Spec generated: " + request.getEndpoints().size() + " endpoints");

        } catch (Exception e) {
            logger.error("Spec generation failed", e);
            return DataProcessResult.error(e.getMessage());
        }
    }

    /**
     * Query stored specs with dynamic filtering.
     * DNA: BuildSearchFilter — skip null/empty values.
     */
    public DataProcessResult<List<Map<String, Object>>> querySpecs(Map<String, Object> filters) {
        try {
            // DNA: BuildSearchFilter — remove null/empty entries
            Map<String, Object> cleanFilter = filters.entrySet().stream()
                .filter(e -> e.getValue() != null && !"".equals(e.getValue()))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

            List<Map<String, Object>> results = db.query(INDEX, cleanFilter);
            return DataProcessResult.success(results, "Found " + results.size() + " specs");
        } catch (Exception e) {
            return DataProcessResult.error(e.getMessage());
        }
    }

    /**
     * Merge specs from multiple services into unified API doc.
     */
    @SuppressWarnings("unchecked")
    public DataProcessResult<Map<String, Object>> mergeSpecs(String scopeId, String title, String version) {
        try {
            Map<String, Object> filter = Map.of("scopeId", scopeId, "status", "active");
            List<Map<String, Object>> allSpecs = db.query(INDEX, filter);
            if (allSpecs.isEmpty()) {
                return DataProcessResult.error("No specs found for scope");
            }

            Map<String, Object> merged = new LinkedHashMap<>();
            merged.put("openapi", "3.1.0");
            merged.put("info", Map.of("title", title, "version", version,
                    "description", "Unified API for scope " + scopeId));
            merged.put("servers", List.of(Map.of("url", "/api", "description", "API Gateway")));

            Map<String, Object> mergedPaths = new LinkedHashMap<>();
            Map<String, Object> mergedSchemas = new LinkedHashMap<>();

            for (Map<String, Object> specDoc : allSpecs) {
                Map<String, Object> spec = mapper.readValue((String) specDoc.get("spec"), Map.class);
                Map<String, Object> paths = (Map<String, Object>) spec.getOrDefault("paths", Map.of());
                mergedPaths.putAll(paths);
                Map<String, Object> components = (Map<String, Object>) spec.getOrDefault("components", Map.of());
                Map<String, Object> schemas = (Map<String, Object>) components.getOrDefault("schemas", Map.of());
                mergedSchemas.putAll(schemas);
            }

            merged.put("paths", mergedPaths);
            merged.put("components", Map.of(
                "schemas", mergedSchemas,
                "securitySchemes", Map.of("bearerAuth",
                    Map.of("type", "http", "scheme", "bearer", "bearerFormat", "JWT"))
            ));

            return DataProcessResult.success(merged, "Merged " + allSpecs.size() + " service specs");
        } catch (Exception e) {
            return DataProcessResult.error(e.getMessage());
        }
    }

    /**
     * Generate spec from dynamic document index (Genie DNA pattern).
     * Auto-creates CRUD endpoints for any dynamic document index.
     */
    public DataProcessResult<Map<String, Object>> generateFromDynamicSchema(
            String scopeId, String indexName, String basePath) {
        try {
            List<EndpointDefinition> endpoints = List.of(
                new EndpointDefinition(basePath, "get", "list_" + indexName,
                    "List " + indexName, List.of(indexName), true, null, null, null),
                new EndpointDefinition(basePath + "/{id}", "get", "get_" + indexName,
                    "Get " + indexName + " by ID", List.of(indexName), true, null, null,
                    List.of(Map.of("name", "id", "in", "path", "type", "string", "required", true))),
                new EndpointDefinition(basePath, "post", "create_" + indexName,
                    "Create " + indexName, List.of(indexName), true, Map.of("type", "object"), null, null),
                new EndpointDefinition(basePath + "/{id}", "put", "update_" + indexName,
                    "Update " + indexName, List.of(indexName), true, Map.of("type", "object"), null, null),
                new EndpointDefinition(basePath + "/{id}", "delete", "delete_" + indexName,
                    "Delete " + indexName, List.of(indexName), true, null, null, null),
                new EndpointDefinition(basePath + "/search", "post", "search_" + indexName,
                    "Search " + indexName, List.of(indexName), true, Map.of("type", "object"), null, null)
            );
            return generateSpec(new SpecGenerationRequest(indexName, "1.0.0", endpoints, scopeId));
        } catch (Exception e) {
            return DataProcessResult.error(e.getMessage());
        }
    }

    // --- Private Helpers ---

    private Map<String, Object> buildSpec(SpecGenerationRequest request) {
        Map<String, Object> paths = new LinkedHashMap<>();
        for (EndpointDefinition ep : request.getEndpoints()) {
            paths.computeIfAbsent(ep.getPath(), k -> new LinkedHashMap<>());
            Map<String, Object> operation = new LinkedHashMap<>();
            operation.put("operationId", ep.getOperationId());
            operation.put("summary", ep.getSummary());
            operation.put("tags", ep.getTags());
            operation.put("responses", buildResponses(ep));
            if (ep.isRequiresAuth()) operation.put("security", List.of(Map.of("bearerAuth", List.of())));
            if (ep.getRequestSchema() != null) operation.put("requestBody",
                Map.of("required", true, "content", Map.of("application/json", Map.of("schema", ep.getRequestSchema()))));
            if (ep.getParameters() != null) operation.put("parameters", ep.getParameters().stream()
                .map(p -> Map.of("name", p.get("name"), "in", p.get("in"),
                    "required", p.get("required"), "schema", Map.of("type", p.get("type"))))
                .collect(Collectors.toList()));
            ((Map<String, Object>) paths.get(ep.getPath())).put(ep.getMethod(), operation);
        }

        return Map.of(
            "openapi", "3.1.0",
            "info", Map.of("title", request.getServiceName() + " API", "version", request.getVersion(),
                "description", "Auto-generated spec for " + request.getServiceName()),
            "servers", List.of(Map.of("url", "/api/" + request.getServiceName(), "description", request.getServiceName())),
            "paths", paths,
            "components", Map.of("schemas", Map.of(), "securitySchemes",
                Map.of("bearerAuth", Map.of("type", "http", "scheme", "bearer", "bearerFormat", "JWT")))
        );
    }

    private Map<String, Object> buildResponses(EndpointDefinition ep) {
        Map<String, Object> responses = new LinkedHashMap<>();
        responses.put("200", ep.getResponseSchema() != null
            ? Map.of("description", "Success", "content", Map.of("application/json", Map.of("schema", ep.getResponseSchema())))
            : Map.of("description", "Success"));
        responses.put("400", Map.of("description", "Bad Request"));
        responses.put("401", Map.of("description", "Unauthorized"));
        responses.put("500", Map.of("description", "Internal Server Error"));
        return responses;
    }

    private DataProcessResult<Void> validateSpec(Map<String, Object> spec) {
        if (!spec.containsKey("openapi")) return DataProcessResult.error("Missing openapi version");
        Map<String, Object> info = (Map<String, Object>) spec.get("info");
        if (info == null || !info.containsKey("title")) return DataProcessResult.error("Missing info.title");
        if (!spec.containsKey("paths") || ((Map<?, ?>) spec.get("paths")).isEmpty())
            return DataProcessResult.error("No paths defined");
        return DataProcessResult.success(null, "Valid");
    }

    // --- Spring Boot Controller ---
    // @RestController @RequestMapping("/swagger")
    // public class SwaggerController { ... }
}

// --- Records ---
record SpecGenerationRequest(String serviceName, String version,
    List<EndpointDefinition> endpoints, String scopeId) {
    public String getServiceName() { return serviceName; }
    public String getVersion() { return version; }
    public List<EndpointDefinition> getEndpoints() { return endpoints; }
    public String getScopeId() { return scopeId; }
}

record EndpointDefinition(String path, String method, String operationId,
    String summary, List<String> tags, boolean requiresAuth,
    Map<String, Object> requestSchema, Map<String, Object> responseSchema,
    List<Map<String, Object>> parameters) {
    public String getPath() { return path; }
    public String getMethod() { return method; }
    public String getOperationId() { return operationId; }
    public String getSummary() { return summary; }
    public List<String> getTags() { return tags; }
    public boolean isRequiresAuth() { return requiresAuth; }
    public Map<String, Object> getRequestSchema() { return requestSchema; }
    public Map<String, Object> getResponseSchema() { return responseSchema; }
    public List<Map<String, Object>> getParameters() { return parameters; }
}
