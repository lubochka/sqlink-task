# Skill 34: Swagger/OpenAPI — Implementation Prompt

## Phase 1: Swagger Setup
Swashbuckle (.NET) or swagger-jsdoc (Node). Base configuration.

## Phase 2: Dynamic Endpoint Generation
Generate endpoint specs from entity definitions. Same 4-endpoint pattern per entity.

## Phase 3: Response Schema
Generic DataProcessResult wrapper in Swagger schema. Dynamic data field.

## Phase 4: Auto-Update
New entity registered -> Swagger spec auto-updates.

---

## Genie DNA Compliance — MANDATORY
☐ DNA-1: Dynamic Documents — Dictionary<string, object>, NOT typed models
☐ DNA-2: BuildSearchFilter — skip empty fields, no entity-specific query code
☐ DNA-3: MicroserviceBase — inherit DB, queue, cache, logger
☐ DNA-5: DataProcessResult<T> — all methods return result wrapper
☐ DNA-6: Generic Interfaces — swap via config
☐ DNA-SCOPE: Non-admin queries auto-inject userId filter
