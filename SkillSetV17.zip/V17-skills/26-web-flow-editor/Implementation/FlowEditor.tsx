// Web Flow Editor - Skill 26 | React + React Flow
import React, { useState, useCallback } from 'react';
import ReactFlow, { Controls, Background, addEdge, useNodesState, useEdgesState, Connection, Node, Edge } from 'reactflow';
import 'reactflow/dist/style.css';

const nodeTypes = ['Trigger', 'FigmaParser', 'AiTransform', 'AiReview', 'CodeGenerator', 'Feedback', 'Debug'];

const initialNodes: Node[] = [
  { id: 'trigger', position: { x: 50, y: 200 }, data: { label: 'Trigger', type: 'Trigger', status: 'idle' }, type: 'default' },
  { id: 'parse', position: { x: 300, y: 200 }, data: { label: 'Figma Parser', type: 'FigmaParser', status: 'idle' } },
  { id: 'transform', position: { x: 550, y: 200 }, data: { label: 'AI Transform', type: 'AiTransform', status: 'idle' } },
  { id: 'review', position: { x: 800, y: 200 }, data: { label: 'AI Review', type: 'AiReview', status: 'idle' } },
];

const initialEdges: Edge[] = [
  { id: 'e1', source: 'trigger', target: 'parse', animated: false },
  { id: 'e2', source: 'parse', target: 'transform', animated: false },
  { id: 'e3', source: 'transform', target: 'review', animated: false },
];

export default function FlowEditor() {
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);

  const onConnect = useCallback((params: Connection) => setEdges((eds) => addEdge(params, eds)), [setEdges]);

  const addNode = (type: string) => {
    const id = `${type.toLowerCase()}-${Date.now()}`;
    const newNode: Node = { id, position: { x: Math.random() * 500 + 100, y: Math.random() * 300 + 100 },
      data: { label: type, type, status: 'idle' } };
    setNodes((nds) => [...nds, newNode]);
  };

  return (
    <div style={{ width: '100vw', height: '100vh', display: 'flex' }}>
      <div style={{ width: 200, padding: 16, background: '#f5f6fa', borderRight: '1px solid #ddd' }}>
        <h3>Nodes</h3>
        {nodeTypes.map(type => (
          <button key={type} onClick={() => addNode(type)} style={{ display: 'block', width: '100%', padding: 8, marginBottom: 8, cursor: 'pointer' }}>
            {type}
          </button>
        ))}
      </div>
      <div style={{ flex: 1 }}>
        <ReactFlow nodes={nodes} edges={edges} onNodesChange={onNodesChange} onEdgesChange={onEdgesChange} onConnect={onConnect} fitView>
          <Controls />
          <Background />
        </ReactFlow>
      </div>
    </div>
  );
}
