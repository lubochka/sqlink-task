/**
 * XIIGen Skill 26: Web Flow Editor — SolidJS Alternative
 * Visual drag-and-drop flow builder using SolidJS reactive primitives
 * DNA: DataProcessResult, FlowDefinition schema (Skill 08), WebSocket execution overlay
 * Dependencies: solid-js, @solidjs/router
 */
import { createSignal, createEffect, onMount, onCleanup, For, Show, createMemo } from 'solid-js';
import { createStore, produce } from 'solid-js/store';

// --- DNA: DataProcessResult ---
interface DataProcessResult<T> { success: boolean; data: T; message: string; }

// --- FlowDefinition (DNA: same schema as Skill 08) ---
interface FlowDefinition {
  id: string; scopeId: string; name: string; version: string;
  nodes: FlowNodeDef[]; edges: FlowEdgeDef[];
  metadata: Record<string, any>;
}
interface FlowNodeDef {
  id: string; skillId: string; label: string; type: string;
  position: { x: number; y: number }; config: Record<string, any>;
}
interface FlowEdgeDef { id: string; source: string; target: string; }
interface NodeExecution {
  nodeId: string; status: 'pending' | 'running' | 'success' | 'error' | 'skipped';
  durationMs?: number; input?: any; output?: any; prompt?: string; error?: string;
}

// --- API ---
const API_BASE = '/api/v1';

const flowApi = {
  loadFlow: async (id: string): Promise<DataProcessResult<FlowDefinition>> =>
    (await fetch(`${API_BASE}/flows/${id}`)).json(),
  saveFlow: async (flow: FlowDefinition): Promise<DataProcessResult<FlowDefinition>> =>
    (await fetch(`${API_BASE}/flows/${flow.id}`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(flow),
    })).json(),
  triggerExecution: async (id: string): Promise<DataProcessResult<{ traceId: string }>> =>
    (await fetch(`${API_BASE}/flows/${id}/execute`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{"source":"editor"}',
    })).json(),
  getNodeDebug: async (traceId: string, nodeId: string): Promise<DataProcessResult<NodeExecution>> =>
    (await fetch(`${API_BASE}/debug/${traceId}/nodes/${nodeId}`)).json(),
};

// --- Skill Palette ---
const SKILL_PALETTE = [
  { skillId: '10', label: 'Figma Parser', icon: '🎨' },
  { skillId: '11', label: 'AI Transform', icon: '🤖' },
  { skillId: '12', label: 'AI Review', icon: '🔍' },
  { skillId: '13', label: 'Feedback', icon: '💬' },
  { skillId: '17', label: 'Code Generator', icon: '💻' },
  { skillId: '06', label: 'AI Provider', icon: '🧠' },
  { skillId: 'trigger', label: 'HTTP Trigger', icon: '🔌' },
  { skillId: 'condition', label: 'Condition', icon: '🔀' },
  { skillId: 'output', label: 'Output', icon: '📤' },
];

const STATUS_COLORS: Record<string, string> = {
  pending: '#6b7280', running: '#f59e0b', success: '#10b981', error: '#ef4444', skipped: '#9ca3af',
};

// --- Main Component ---
export default function FlowEditor(props: { flowId: string }) {
  // --- SolidJS reactive state ---
  const [flowDef, setFlowDef] = createSignal<FlowDefinition | null>(null);
  const [traceId, setTraceId] = createSignal<string | null>(null);
  const [isExecuting, setIsExecuting] = createSignal(false);
  const [selectedNodeId, setSelectedNodeId] = createSignal<string | null>(null);
  const [debugData, setDebugData] = createSignal<NodeExecution | null>(null);

  // Use createStore for the mutable collections
  const [state, setState] = createStore({
    nodes: [] as (FlowNodeDef & { icon: string })[],
    edges: [] as FlowEdgeDef[],
    nodeExecutions: {} as Record<string, NodeExecution>,
  });

  // --- WebSocket ---
  let ws: WebSocket | null = null;

  function connectWs(trace: string) {
    ws?.close();
    ws = new WebSocket(`ws://${window.location.host}/api/v1/ws/flow/${trace}`);
    ws.onopen = () => setIsExecuting(true);
    ws.onmessage = (e) => {
      const exec: NodeExecution = JSON.parse(e.data);
      setState('nodeExecutions', exec.nodeId, exec);
    };
    ws.onclose = () => setIsExecuting(false);
  }

  // --- Load Flow ---
  onMount(async () => {
    const result = await flowApi.loadFlow(props.flowId);
    if (result.success) {
      setFlowDef(result.data);
      setState('nodes', result.data.nodes.map(n => ({
        ...n,
        icon: SKILL_PALETTE.find(s => s.skillId === n.skillId)?.icon || '⚙️',
      })));
      setState('edges', result.data.edges);
    }
  });

  onCleanup(() => ws?.close());

  // --- Auto-save ---
  createEffect(() => {
    const flow = flowDef();
    if (!flow) return;
    const timer = setTimeout(() => flowApi.saveFlow(flow), 3000);
    return () => clearTimeout(timer);
  });

  // --- Fetch debug data when selecting a node ---
  createEffect(async () => {
    const nodeId = selectedNodeId();
    const trace = traceId();
    if (nodeId && trace) {
      const r = await flowApi.getNodeDebug(trace, nodeId);
      if (r.success) setDebugData(r.data);
    } else {
      setDebugData(null);
    }
  });

  // --- Computed ---
  const selectedExecution = createMemo(() => {
    const id = selectedNodeId();
    return id ? state.nodeExecutions[id] || null : null;
  });

  const inspectorData = createMemo(() => debugData() || selectedExecution());

  // --- Actions ---
  const executeFlow = async () => {
    const result = await flowApi.triggerExecution(props.flowId);
    if (result.success) {
      setTraceId(result.data.traceId);
      connectWs(result.data.traceId);
    }
  };

  const onDragStart = (event: DragEvent, skill: typeof SKILL_PALETTE[0]) => {
    event.dataTransfer?.setData('application/xiigen-skill', JSON.stringify(skill));
  };

  const onCanvasDrop = (event: DragEvent) => {
    event.preventDefault();
    const raw = event.dataTransfer?.getData('application/xiigen-skill');
    if (!raw) return;
    const skill = JSON.parse(raw);
    const newNode = {
      id: `node-${Date.now()}`, skillId: skill.skillId, label: skill.label,
      type: skill.type || 'skill',
      position: { x: event.offsetX - 90, y: event.offsetY - 30 },
      config: {}, icon: skill.icon || '⚙️',
    };
    setState('nodes', produce((n: any[]) => n.push(newNode)));
  };

  const getNodeBorder = (nodeId: string) =>
    STATUS_COLORS[state.nodeExecutions[nodeId]?.status || 'pending'] || '#6b7280';

  // --- Render ---
  return (
    <div style={{ display: 'flex', height: '100vh' }}>
      {/* Palette */}
      <div style={{ width: '220px', 'border-right': '1px solid #e5e7eb', padding: '12px', 'overflow-y': 'auto' }}>
        <h3 style={{ 'font-size': '14px', 'font-weight': '600', 'margin-bottom': '12px' }}>Skills</h3>
        <For each={SKILL_PALETTE}>
          {(skill) => (
            <div
              draggable={true}
              onDragStart={(e) => onDragStart(e, skill)}
              style={{
                padding: '8px', 'margin-bottom': '6px', border: '1px solid #e5e7eb',
                'border-radius': '6px', cursor: 'grab', display: 'flex',
                'align-items': 'center', gap: '8px', 'font-size': '13px', background: '#f9fafb',
              }}
            >
              <span>{skill.icon}</span>
              <span>{skill.label}</span>
            </div>
          )}
        </For>
      </div>

      {/* Canvas */}
      <div
        style={{ flex: 1, position: 'relative', background: '#fafafa' }}
        onDrop={onCanvasDrop}
        onDragOver={(e) => e.preventDefault()}
      >
        <div style={{ position: 'absolute', top: '12px', right: '12px', 'z-index': '10' }}>
          <button
            onClick={executeFlow}
            disabled={isExecuting()}
            style={{
              padding: '8px 16px', background: '#3b82f6', color: '#fff',
              border: 'none', 'border-radius': '6px', cursor: 'pointer', 'font-weight': '600',
            }}
          >
            ▶ Run Flow
          </button>
        </div>

        {/* SVG Canvas for nodes and edges */}
        <svg style={{ width: '100%', height: '100%' }} viewBox="0 0 1200 800">
          <defs>
            <marker id="arrow" markerWidth="10" markerHeight="7" refX="10" refY="3.5" orient="auto">
              <polygon points="0 0, 10 3.5, 0 7" fill="#94a3b8" />
            </marker>
          </defs>

          {/* Edges */}
          <For each={state.edges}>
            {(edge) => {
              const src = () => state.nodes.find(n => n.id === edge.source);
              const tgt = () => state.nodes.find(n => n.id === edge.target);
              return (
                <Show when={src() && tgt()}>
                  <line
                    x1={src()!.position.x + 90} y1={src()!.position.y + 30}
                    x2={tgt()!.position.x + 90} y2={tgt()!.position.y + 30}
                    stroke="#94a3b8" stroke-width="2" marker-end="url(#arrow)"
                  />
                </Show>
              );
            }}
          </For>

          {/* Nodes */}
          <For each={state.nodes}>
            {(node) => (
              <g
                transform={`translate(${node.position.x},${node.position.y})`}
                onClick={() => setSelectedNodeId(node.id)}
                style={{ cursor: 'pointer' }}
              >
                <rect
                  width="180" height="60" rx="8"
                  fill="#fff" stroke={getNodeBorder(node.id)} stroke-width="2"
                />
                <text x="40" y="25" font-size="13" font-weight="600">{node.label}</text>
                <text x="40" y="42" font-size="10" fill="#6b7280">Skill {node.skillId}</text>
                <text x="12" y="35" font-size="18">{node.icon}</text>
              </g>
            )}
          </For>
        </svg>
      </div>

      {/* Inspector */}
      <div style={{ width: '300px', 'border-left': '1px solid #e5e7eb', padding: '16px', 'overflow-y': 'auto' }}>
        <h3 style={{ 'font-size': '14px', 'font-weight': '600' }}>Node Inspector</h3>
        <Show when={!selectedNodeId()}>
          <div style={{ color: '#9ca3af', 'font-size': '13px' }}>Select a node to inspect</div>
        </Show>
        <Show when={inspectorData()}>
          {(exec) => (
            <>
              <div style={{ 'margin-top': '12px' }}>
                <div style={{ 'font-size': '12px', 'font-weight': '600' }}>Status</div>
                <span style={{ color: STATUS_COLORS[exec().status] }}>{exec().status}</span>
              </div>
              <Show when={exec().input}>
                <div style={{ 'margin-top': '12px' }}>
                  <div style={{ 'font-size': '12px', 'font-weight': '600' }}>Input</div>
                  <pre style={{ 'font-size': '10px', background: '#f3f4f6', padding: '8px', 'border-radius': '4px', overflow: 'auto', 'max-height': '200px' }}>
                    {JSON.stringify(exec().input, null, 2)}
                  </pre>
                </div>
              </Show>
              <Show when={exec().prompt}>
                <div style={{ 'margin-top': '12px' }}>
                  <div style={{ 'font-size': '12px', 'font-weight': '600' }}>Prompt</div>
                  <pre style={{ 'font-size': '10px', background: '#fffbeb', padding: '8px', 'border-radius': '4px', overflow: 'auto', 'max-height': '200px' }}>
                    {exec().prompt}
                  </pre>
                </div>
              </Show>
              <Show when={exec().output}>
                <div style={{ 'margin-top': '12px' }}>
                  <div style={{ 'font-size': '12px', 'font-weight': '600' }}>Output</div>
                  <pre style={{ 'font-size': '10px', background: '#ecfdf5', padding: '8px', 'border-radius': '4px', overflow: 'auto', 'max-height': '200px' }}>
                    {JSON.stringify(exec().output, null, 2)}
                  </pre>
                </div>
              </Show>
              <Show when={exec().error}>
                <div style={{ 'margin-top': '12px' }}>
                  <div style={{ 'font-size': '12px', 'font-weight': '600', color: '#ef4444' }}>Error</div>
                  <pre style={{ 'font-size': '10px', background: '#fef2f2', padding: '8px', 'border-radius': '4px' }}>
                    {exec().error}
                  </pre>
                </div>
              </Show>
            </>
          )}
        </Show>
      </div>
    </div>
  );
}
