<!--
  XIIGen Skill 26: Web Flow Editor — Svelte Alternative
  Visual drag-and-drop flow builder using @xyflow/svelte
  DNA: DataProcessResult, FlowDefinition schema (Skill 08), WebSocket execution overlay
  Dependencies: @xyflow/svelte, svelte-dnd-action
-->
<script lang="ts">
  import { SvelteFlow, Background, Controls, MiniMap, useSvelteFlow, type Node, type Edge } from '@xyflow/svelte';
  import { writable, derived, get } from 'svelte/store';
  import { onMount, onDestroy } from 'svelte';

  // --- DNA: DataProcessResult ---
  interface DataProcessResult<T> { success: boolean; data: T; message: string; }

  // --- FlowDefinition (DNA: same schema as Skill 08) ---
  interface FlowDefinition {
    id: string; scopeId: string; name: string; version: string;
    nodes: FlowNodeDef[]; edges: FlowEdgeDef[];
    metadata: Record<string, any>;
  }
  interface FlowNodeDef {
    id: string; skillId: string; label: string; type: string;
    position: { x: number; y: number }; config: Record<string, any>;
  }
  interface FlowEdgeDef { id: string; source: string; target: string; }
  interface NodeExecution {
    nodeId: string; status: 'pending' | 'running' | 'success' | 'error' | 'skipped';
    durationMs?: number; input?: any; output?: any; prompt?: string; error?: string;
  }

  // --- Props ---
  export let flowId: string;

  // --- Stores ---
  const nodes = writable<Node[]>([]);
  const edges = writable<Edge[]>([]);
  const flowDef = writable<FlowDefinition | null>(null);
  const traceId = writable<string | null>(null);
  const isExecuting = writable(false);
  const nodeExecutions = writable<Record<string, NodeExecution>>({});
  const selectedNodeId = writable<string | null>(null);

  const selectedExecution = derived(
    [selectedNodeId, nodeExecutions],
    ([$id, $execs]) => $id ? $execs[$id] || null : null
  );

  // --- API ---
  const API_BASE = '/api/v1';

  async function loadFlow(id: string): Promise<DataProcessResult<FlowDefinition>> {
    return (await fetch(`${API_BASE}/flows/${id}`)).json();
  }
  async function saveFlow(flow: FlowDefinition): Promise<DataProcessResult<FlowDefinition>> {
    return (await fetch(`${API_BASE}/flows/${flow.id}`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(flow),
    })).json();
  }
  async function triggerExecution(id: string): Promise<DataProcessResult<{ traceId: string }>> {
    return (await fetch(`${API_BASE}/flows/${id}/execute`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{"source":"editor"}',
    })).json();
  }
  async function getNodeDebug(trace: string, nodeId: string): Promise<DataProcessResult<NodeExecution>> {
    return (await fetch(`${API_BASE}/debug/${trace}/nodes/${nodeId}`)).json();
  }

  // --- Skill Palette ---
  const skillPalette = [
    { skillId: '10', label: 'Figma Parser', icon: '🎨' },
    { skillId: '11', label: 'AI Transform', icon: '🤖' },
    { skillId: '12', label: 'AI Review', icon: '🔍' },
    { skillId: '13', label: 'Feedback', icon: '💬' },
    { skillId: '17', label: 'Code Generator', icon: '💻' },
    { skillId: '06', label: 'AI Provider', icon: '🧠' },
    { skillId: 'trigger', label: 'HTTP Trigger', icon: '🔌' },
    { skillId: 'condition', label: 'Condition', icon: '🔀' },
    { skillId: 'output', label: 'Output', icon: '📤' },
  ];

  const statusColors: Record<string, string> = {
    pending: '#6b7280', running: '#f59e0b', success: '#10b981', error: '#ef4444', skipped: '#9ca3af',
  };

  // --- WebSocket ---
  let ws: WebSocket | null = null;

  function connectWs(trace: string) {
    ws?.close();
    ws = new WebSocket(`ws://${window.location.host}/api/v1/ws/flow/${trace}`);
    ws.onopen = () => isExecuting.set(true);
    ws.onmessage = (e) => {
      const exec: NodeExecution = JSON.parse(e.data);
      nodeExecutions.update(m => ({ ...m, [exec.nodeId]: exec }));
    };
    ws.onclose = () => isExecuting.set(false);
  }

  // --- Drag & Drop ---
  function onDragStart(event: DragEvent, skill: typeof skillPalette[0]) {
    event.dataTransfer?.setData('application/xiigen-skill', JSON.stringify(skill));
  }

  function onCanvasDrop(event: DragEvent) {
    event.preventDefault();
    const raw = event.dataTransfer?.getData('application/xiigen-skill');
    if (!raw) return;
    const skill = JSON.parse(raw);
    const newNode: Node = {
      id: `node-${Date.now()}`, type: 'skill',
      position: { x: event.offsetX - 90, y: event.offsetY - 30 },
      data: { ...skill, nodeId: `node-${Date.now()}` },
    };
    nodes.update(n => [...n, newNode]);
  }

  // --- Actions ---
  async function executeFlow() {
    const result = await triggerExecution(flowId);
    if (result.success) {
      traceId.set(result.data.traceId);
      connectWs(result.data.traceId);
    }
  }

  function onNodeClick(_event: MouseEvent, node: Node) {
    selectedNodeId.set(node.id);
  }

  // --- Debug Data ---
  let debugData: NodeExecution | null = null;
  $: if ($selectedNodeId && $traceId) {
    getNodeDebug($traceId, $selectedNodeId).then(r => {
      if (r.success) debugData = r.data;
    });
  }

  // --- Auto-save ---
  let saveTimer: any;
  $: if ($flowDef) {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => { if ($flowDef) saveFlow($flowDef); }, 3000);
  }

  // --- Lifecycle ---
  onMount(async () => {
    const result = await loadFlow(flowId);
    if (result.success) {
      flowDef.set(result.data);
      nodes.set(result.data.nodes.map(n => ({
        id: n.id, type: 'skill', position: n.position,
        data: { skillId: n.skillId, label: n.label, nodeId: n.id,
                icon: skillPalette.find(s => s.skillId === n.skillId)?.icon || '⚙️', ...n.config },
      })));
      edges.set(result.data.edges.map(e => ({ id: e.id, source: e.source, target: e.target })));
    }
  });

  onDestroy(() => ws?.close());
</script>

<div class="flow-editor-container">
  <!-- Palette -->
  <div class="palette-sidebar">
    <h3>Skills</h3>
    {#each skillPalette as skill}
      <div class="palette-item" draggable="true" on:dragstart={(e) => onDragStart(e, skill)}>
        <span>{skill.icon}</span>
        <span>{skill.label}</span>
      </div>
    {/each}
  </div>

  <!-- Canvas -->
  <div class="canvas-area" on:drop={onCanvasDrop} on:dragover|preventDefault>
    <div class="toolbar">
      <button class="run-btn" on:click={executeFlow} disabled={$isExecuting}>▶ Run Flow</button>
    </div>
    <SvelteFlow {nodes} {edges} fitView on:nodeclick={(e) => onNodeClick(e, e.detail.node)}>
      <Background />
      <Controls />
      <MiniMap />
    </SvelteFlow>
  </div>

  <!-- Inspector -->
  <div class="inspector-panel">
    <h3>Node Inspector</h3>
    {#if !$selectedNodeId}
      <div class="empty">Select a node to inspect</div>
    {:else}
      {#if $selectedExecution || debugData}
        {@const exec = debugData || $selectedExecution}
        <div class="field">
          <label>Status</label>
          <span style="color: {statusColors[exec?.status || 'pending']}">{exec?.status}</span>
        </div>
        {#if exec?.input}
          <div class="field"><label>Input</label><pre>{JSON.stringify(exec.input, null, 2)}</pre></div>
        {/if}
        {#if exec?.prompt}
          <div class="field"><label>Prompt</label><pre class="prompt-pre">{exec.prompt}</pre></div>
        {/if}
        {#if exec?.output}
          <div class="field"><label>Output</label><pre class="output-pre">{JSON.stringify(exec.output, null, 2)}</pre></div>
        {/if}
        {#if exec?.error}
          <div class="field error"><label>Error</label><pre>{exec.error}</pre></div>
        {/if}
      {/if}
    {/if}
  </div>
</div>

<style>
  .flow-editor-container { display: flex; height: 100vh; }
  .palette-sidebar { width: 220px; border-right: 1px solid #e5e7eb; padding: 12px; overflow-y: auto; }
  .palette-sidebar h3 { font-size: 14px; font-weight: 600; margin-bottom: 12px; }
  .palette-item { padding: 8px; margin-bottom: 6px; border: 1px solid #e5e7eb; border-radius: 6px;
                  cursor: grab; display: flex; align-items: center; gap: 8px; font-size: 13px; background: #f9fafb; }
  .canvas-area { flex: 1; position: relative; }
  .toolbar { position: absolute; top: 12px; right: 12px; z-index: 10; }
  .run-btn { padding: 8px 16px; background: #3b82f6; color: #fff; border: none; border-radius: 6px;
             cursor: pointer; font-weight: 600; }
  .inspector-panel { width: 300px; border-left: 1px solid #e5e7eb; padding: 16px; overflow-y: auto; }
  .empty { color: #9ca3af; font-size: 13px; }
  .field { margin-top: 12px; }
  .field label { font-size: 12px; font-weight: 600; display: block; margin-bottom: 4px; }
  .field pre { font-size: 10px; background: #f3f4f6; padding: 8px; border-radius: 4px;
               overflow: auto; max-height: 200px; white-space: pre-wrap; }
  .prompt-pre { background: #fffbeb !important; }
  .output-pre { background: #ecfdf5 !important; }
  .error label { color: #ef4444; }
  .error pre { background: #fef2f2 !important; }
</style>
