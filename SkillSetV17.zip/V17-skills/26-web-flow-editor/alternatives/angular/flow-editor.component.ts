/**
 * XIIGen Skill 26: Web Flow Editor — Angular Alternative
 * Visual drag-and-drop flow builder using ngx-graph / Angular CDK Drag-Drop
 * DNA: DataProcessResult, FlowDefinition schema (Skill 08), WebSocket execution overlay
 *
 * Dependencies: @angular/cdk, @swimlane/ngx-graph, rxjs
 */
import { Component, OnInit, OnDestroy, Injectable, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Subject, Observable, takeUntil, debounceTime, distinctUntilChanged } from 'rxjs';
import { webSocket, WebSocketSubject } from 'rxjs/webSocket';
import { CdkDragDrop } from '@angular/cdk/drag-drop';

// --- DNA: DataProcessResult ---
interface DataProcessResult<T> { success: boolean; data: T; message: string; }

// --- FlowDefinition (DNA: same schema as Skill 08) ---
interface FlowDefinition {
  id: string; scopeId: string; name: string; version: string;
  nodes: FlowNodeDef[]; edges: FlowEdgeDef[];
  metadata: Record<string, any>; createdAt: string; updatedAt: string;
}

interface FlowNodeDef {
  id: string; skillId: string; label: string; type: string;
  position: { x: number; y: number };
  config: Record<string, any>; inputs: string[]; outputs: string[];
}

interface FlowEdgeDef {
  id: string; source: string; target: string; condition?: string;
}

interface NodeExecution {
  nodeId: string; status: 'pending' | 'running' | 'success' | 'error' | 'skipped';
  startedAt?: string; completedAt?: string; durationMs?: number;
  input?: any; output?: any; prompt?: string; error?: string;
}

// --- Angular Service: Flow API ---

@Injectable({ providedIn: 'root' })
export class FlowApiService {
  private readonly apiBase = '/api/v1';

  constructor(private http: HttpClient) {}

  loadFlow(flowId: string): Observable<DataProcessResult<FlowDefinition>> {
    return this.http.get<DataProcessResult<FlowDefinition>>(`${this.apiBase}/flows/${flowId}`);
  }

  saveFlow(flow: FlowDefinition): Observable<DataProcessResult<FlowDefinition>> {
    return this.http.put<DataProcessResult<FlowDefinition>>(`${this.apiBase}/flows/${flow.id}`, flow);
  }

  triggerExecution(flowId: string, input: any): Observable<DataProcessResult<{ traceId: string }>> {
    return this.http.post<DataProcessResult<{ traceId: string }>>(`${this.apiBase}/flows/${flowId}/execute`, input);
  }

  getNodeDebug(traceId: string, nodeId: string): Observable<DataProcessResult<NodeExecution>> {
    return this.http.get<DataProcessResult<NodeExecution>>(`${this.apiBase}/debug/${traceId}/nodes/${nodeId}`);
  }
}

// --- Angular Service: Flow Editor State (RxJS-based store) ---

@Injectable({ providedIn: 'root' })
export class FlowEditorStateService {
  private _flow$ = new BehaviorSubject<FlowDefinition | null>(null);
  private _traceId$ = new BehaviorSubject<string | null>(null);
  private _nodeExecutions$ = new BehaviorSubject<Record<string, NodeExecution>>({});
  private _selectedNodeId$ = new BehaviorSubject<string | null>(null);
  private _isExecuting$ = new BehaviorSubject<boolean>(false);

  flow$ = this._flow$.asObservable();
  traceId$ = this._traceId$.asObservable();
  nodeExecutions$ = this._nodeExecutions$.asObservable();
  selectedNodeId$ = this._selectedNodeId$.asObservable();
  isExecuting$ = this._isExecuting$.asObservable();

  setFlow(flow: FlowDefinition) { this._flow$.next(flow); }
  setTraceId(id: string) { this._traceId$.next(id); }
  selectNode(id: string | null) { this._selectedNodeId$.next(id); }
  setExecuting(v: boolean) { this._isExecuting$.next(v); }

  updateNodeExecution(exec: NodeExecution) {
    const current = this._nodeExecutions$.value;
    this._nodeExecutions$.next({ ...current, [exec.nodeId]: exec });
  }

  getNodeExecution(nodeId: string): NodeExecution | undefined {
    return this._nodeExecutions$.value[nodeId];
  }
}

// --- Angular Service: WebSocket Execution ---

@Injectable({ providedIn: 'root' })
export class ExecutionSocketService {
  private ws$: WebSocketSubject<any> | null = null;

  constructor(private state: FlowEditorStateService) {}

  connect(traceId: string) {
    this.disconnect();
    const wsUrl = `ws://${window.location.host}/api/v1/ws/flow/${traceId}`;
    this.ws$ = webSocket(wsUrl);
    this.state.setExecuting(true);

    this.ws$.subscribe({
      next: (event: NodeExecution) => this.state.updateNodeExecution(event),
      error: () => this.state.setExecuting(false),
      complete: () => this.state.setExecuting(false),
    });
  }

  disconnect() {
    this.ws$?.complete();
    this.ws$ = null;
  }
}

// --- Skill Palette Data ---

const SKILL_PALETTE = [
  { skillId: '10', label: 'Figma Parser', icon: '🎨', type: 'skill' },
  { skillId: '11', label: 'AI Transform', icon: '🤖', type: 'skill' },
  { skillId: '12', label: 'AI Review', icon: '🔍', type: 'skill' },
  { skillId: '13', label: 'Feedback', icon: '💬', type: 'skill' },
  { skillId: '17', label: 'Code Generator', icon: '💻', type: 'skill' },
  { skillId: '06', label: 'AI Provider', icon: '🧠', type: 'skill' },
  { skillId: 'trigger', label: 'HTTP Trigger', icon: '🔌', type: 'trigger' },
  { skillId: 'condition', label: 'Condition', icon: '🔀', type: 'condition' },
  { skillId: 'output', label: 'Output', icon: '📤', type: 'output' },
];

// --- Angular Component: Flow Editor (Main) ---

@Component({
  selector: 'xiigen-flow-editor',
  template: `
    <div class="flow-editor-container">
      <!-- Node Palette Sidebar -->
      <div class="palette-sidebar">
        <h3>Skills</h3>
        <div cdkDropList (cdkDropListDropped)="onPaletteDrop($event)">
          <div *ngFor="let skill of skillPalette" cdkDrag
               class="palette-item" [cdkDragData]="skill">
            <span class="palette-icon">{{ skill.icon }}</span>
            <span>{{ skill.label }}</span>
          </div>
        </div>
      </div>

      <!-- Canvas (ngx-graph or custom SVG) -->
      <div class="canvas-area" (drop)="onCanvasDrop($event)" (dragover)="$event.preventDefault()">
        <div class="toolbar">
          <button class="run-btn" (click)="executeFlow()" [disabled]="isExecuting$ | async">
            ▶ Run Flow
          </button>
          <button class="save-btn" (click)="saveFlow()">💾 Save</button>
        </div>

        <svg class="flow-canvas" [attr.viewBox]="viewBox">
          <!-- Edges -->
          <g *ngFor="let edge of edges">
            <line [attr.x1]="getNodeCenter(edge.source).x" [attr.y1]="getNodeCenter(edge.source).y"
                  [attr.x2]="getNodeCenter(edge.target).x" [attr.y2]="getNodeCenter(edge.target).y"
                  stroke="#94a3b8" stroke-width="2" marker-end="url(#arrowhead)" />
          </g>

          <!-- Nodes -->
          <g *ngFor="let node of nodes" [attr.transform]="'translate(' + node.position.x + ',' + node.position.y + ')'"
             (click)="selectNode(node.id)" class="flow-node" [class.selected]="(selectedNodeId$ | async) === node.id">
            <rect width="180" height="60" rx="8"
                  [attr.fill]="'#fff'"
                  [attr.stroke]="getNodeBorderColor(node.id)"
                  stroke-width="2" />
            <text x="40" y="25" font-size="13" font-weight="600">{{ node.label }}</text>
            <text x="40" y="42" font-size="10" fill="#6b7280">Skill {{ node.skillId }}</text>
            <text x="12" y="35" font-size="18">{{ getNodeIcon(node) }}</text>
          </g>

          <!-- Arrow marker -->
          <defs>
            <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="10" refY="3.5" orient="auto">
              <polygon points="0 0, 10 3.5, 0 7" fill="#94a3b8" />
            </marker>
          </defs>
        </svg>
      </div>

      <!-- Inspector Panel -->
      <xiigen-node-inspector
        [nodeId]="selectedNodeId$ | async"
        [traceId]="traceId$ | async">
      </xiigen-node-inspector>
    </div>
  `,
  styles: [`
    .flow-editor-container { display: flex; height: 100vh; }
    .palette-sidebar { width: 220px; border-right: 1px solid #e5e7eb; padding: 12px; overflow-y: auto; }
    .palette-item { padding: 8px; margin-bottom: 6px; border: 1px solid #e5e7eb; border-radius: 6px;
                    cursor: grab; display: flex; align-items: center; gap: 8px; font-size: 13px; background: #f9fafb; }
    .canvas-area { flex: 1; position: relative; background: #fafafa; }
    .toolbar { position: absolute; top: 12px; right: 12px; z-index: 10; display: flex; gap: 8px; }
    .run-btn { padding: 8px 16px; background: #3b82f6; color: #fff; border: none; border-radius: 6px; cursor: pointer; font-weight: 600; }
    .save-btn { padding: 8px 16px; background: #10b981; color: #fff; border: none; border-radius: 6px; cursor: pointer; }
    .flow-canvas { width: 100%; height: 100%; }
    .flow-node { cursor: pointer; }
    .flow-node.selected rect { stroke: #3b82f6 !important; stroke-width: 3; }
  `],
})
export class FlowEditorComponent implements OnInit, OnDestroy {
  @Input() flowId!: string;

  skillPalette = SKILL_PALETTE;
  nodes: FlowNodeDef[] = [];
  edges: FlowEdgeDef[] = [];
  viewBox = '0 0 1200 800';

  selectedNodeId$ = this.state.selectedNodeId$;
  isExecuting$ = this.state.isExecuting$;
  traceId$ = this.state.traceId$;

  private destroy$ = new Subject<void>();

  constructor(
    private flowApi: FlowApiService,
    private state: FlowEditorStateService,
    private executionSocket: ExecutionSocketService,
  ) {}

  ngOnInit() {
    this.flowApi.loadFlow(this.flowId).pipe(takeUntil(this.destroy$)).subscribe((result) => {
      if (result.success) {
        this.state.setFlow(result.data);
        this.nodes = result.data.nodes;
        this.edges = result.data.edges;
      }
    });

    // Auto-save on flow changes (debounced)
    this.state.flow$.pipe(
      takeUntil(this.destroy$), debounceTime(3000), distinctUntilChanged(),
    ).subscribe((flow) => {
      if (flow) this.flowApi.saveFlow(flow).subscribe();
    });
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
    this.executionSocket.disconnect();
  }

  selectNode(id: string) { this.state.selectNode(id); }

  executeFlow() {
    this.flowApi.triggerExecution(this.flowId, { source: 'editor' })
      .pipe(takeUntil(this.destroy$))
      .subscribe((result) => {
        if (result.success) {
          this.state.setTraceId(result.data.traceId);
          this.executionSocket.connect(result.data.traceId);
        }
      });
  }

  saveFlow() {
    const flow = this.state['_flow$'].value;
    if (flow) this.flowApi.saveFlow(flow).subscribe();
  }

  onCanvasDrop(event: DragEvent) {
    event.preventDefault();
    const data = event.dataTransfer?.getData('application/xiigen-skill');
    if (!data) return;
    const skill = JSON.parse(data);
    const newNode: FlowNodeDef = {
      id: `node-${Date.now()}`, skillId: skill.skillId, label: skill.label,
      type: skill.type, position: { x: event.offsetX - 90, y: event.offsetY - 30 },
      config: {}, inputs: ['in'], outputs: ['out'],
    };
    this.nodes = [...this.nodes, newNode];
  }

  onPaletteDrop(event: CdkDragDrop<any>) { /* handled by onCanvasDrop */ }

  getNodeCenter(nodeId: string): { x: number; y: number } {
    const node = this.nodes.find((n) => n.id === nodeId);
    return node ? { x: node.position.x + 90, y: node.position.y + 30 } : { x: 0, y: 0 };
  }

  getNodeBorderColor(nodeId: string): string {
    const exec = this.state.getNodeExecution(nodeId);
    const colors: Record<string, string> = {
      pending: '#6b7280', running: '#f59e0b', success: '#10b981', error: '#ef4444', skipped: '#9ca3af',
    };
    return colors[exec?.status || 'pending'] || '#6b7280';
  }

  getNodeIcon(node: FlowNodeDef): string {
    return SKILL_PALETTE.find((s) => s.skillId === node.skillId)?.icon || '⚙️';
  }
}

// --- Node Inspector Component ---

@Component({
  selector: 'xiigen-node-inspector',
  template: `
    <div class="inspector-panel">
      <h3>Node Inspector</h3>
      <div *ngIf="!nodeId" class="empty">Select a node to inspect</div>
      <div *ngIf="nodeId && execution">
        <div class="field"><label>Status</label><span [style.color]="statusColor">{{ execution.status }}</span></div>
        <div *ngIf="execution.input" class="field"><label>Input</label><pre>{{ execution.input | json }}</pre></div>
        <div *ngIf="execution.prompt" class="field"><label>Prompt</label><pre class="prompt-pre">{{ execution.prompt }}</pre></div>
        <div *ngIf="execution.output" class="field"><label>Output</label><pre class="output-pre">{{ execution.output | json }}</pre></div>
        <div *ngIf="execution.error" class="field error"><label>Error</label><pre>{{ execution.error }}</pre></div>
      </div>
    </div>
  `,
  styles: [`
    .inspector-panel { width: 300px; border-left: 1px solid #e5e7eb; padding: 16px; overflow-y: auto; }
    .empty { color: #9ca3af; font-size: 13px; }
    .field { margin-top: 12px; }
    .field label { font-size: 12px; font-weight: 600; display: block; margin-bottom: 4px; }
    .field pre { font-size: 10px; background: #f3f4f6; padding: 8px; border-radius: 4px; overflow: auto; max-height: 200px; }
    .prompt-pre { background: #fffbeb; }
    .output-pre { background: #ecfdf5; }
    .error label { color: #ef4444; }
    .error pre { background: #fef2f2; }
  `],
})
export class NodeInspectorComponent implements OnInit {
  @Input() nodeId: string | null = null;
  @Input() traceId: string | null = null;
  execution: NodeExecution | null = null;
  statusColor = '#6b7280';

  constructor(private flowApi: FlowApiService, private state: FlowEditorStateService) {}

  ngOnInit() {
    this.state.selectedNodeId$.subscribe((nodeId) => {
      if (nodeId && this.traceId) {
        this.flowApi.getNodeDebug(this.traceId, nodeId).subscribe((r) => {
          if (r.success) {
            this.execution = r.data;
            const colors: Record<string, string> = {
              pending: '#6b7280', running: '#f59e0b', success: '#10b981', error: '#ef4444',
            };
            this.statusColor = colors[r.data.status] || '#6b7280';
          }
        });
      }
    });
  }
}
