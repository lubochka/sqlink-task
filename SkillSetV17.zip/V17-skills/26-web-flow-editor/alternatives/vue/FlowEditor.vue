<!--
  XIIGen Skill 26: Web Flow Editor — Vue 3 Alternative
  Visual drag-and-drop flow builder using @vue-flow/core
  DNA: DataProcessResult, FlowDefinition schema (Skill 08), WebSocket execution overlay
  Dependencies: @vue-flow/core, @vue-flow/background, @vue-flow/controls, @vue-flow/minimap, pinia
-->
<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted, watch } from 'vue';
import { VueFlow, useVueFlow, Position } from '@vue-flow/core';
import { Background } from '@vue-flow/background';
import { Controls } from '@vue-flow/controls';
import { MiniMap } from '@vue-flow/minimap';
import { defineStore, storeToRefs } from 'pinia';

// --- DNA: DataProcessResult ---
interface DataProcessResult<T> { success: boolean; data: T; message: string; }

// --- FlowDefinition (DNA: same schema as Skill 08) ---
interface FlowDefinition {
  id: string; scopeId: string; name: string; version: string;
  nodes: FlowNodeDef[]; edges: FlowEdgeDef[];
  metadata: Record<string, any>; createdAt: string; updatedAt: string;
}
interface FlowNodeDef {
  id: string; skillId: string; label: string; type: string;
  position: { x: number; y: number }; config: Record<string, any>;
}
interface FlowEdgeDef { id: string; source: string; target: string; condition?: string; }
interface NodeExecution {
  nodeId: string; status: 'pending' | 'running' | 'success' | 'error' | 'skipped';
  durationMs?: number; input?: any; output?: any; prompt?: string; error?: string;
}

// --- Props ---
const props = defineProps<{ flowId: string }>();

// --- Pinia Store ---
const useFlowStore = defineStore('flowEditor', {
  state: () => ({
    flowDefinition: null as FlowDefinition | null,
    traceId: null as string | null,
    isExecuting: false,
    nodeExecutions: {} as Record<string, NodeExecution>,
    selectedNodeId: null as string | null,
  }),
  actions: {
    setFlow(flow: FlowDefinition) { this.flowDefinition = flow; },
    setTraceId(id: string) { this.traceId = id; },
    updateNodeExecution(exec: NodeExecution) {
      this.nodeExecutions = { ...this.nodeExecutions, [exec.nodeId]: exec };
    },
    selectNode(id: string | null) { this.selectedNodeId = id; },
    setExecuting(v: boolean) { this.isExecuting = v; },
  },
});

const store = useFlowStore();
const { flowDefinition, traceId, isExecuting, nodeExecutions, selectedNodeId } = storeToRefs(store);

// --- API ---
const API_BASE = '/api/v1';

const flowApi = {
  async loadFlow(id: string): Promise<DataProcessResult<FlowDefinition>> {
    return (await fetch(`${API_BASE}/flows/${id}`)).json();
  },
  async saveFlow(flow: FlowDefinition): Promise<DataProcessResult<FlowDefinition>> {
    return (await fetch(`${API_BASE}/flows/${flow.id}`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(flow),
    })).json();
  },
  async triggerExecution(id: string, input: any): Promise<DataProcessResult<{ traceId: string }>> {
    return (await fetch(`${API_BASE}/flows/${id}/execute`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input),
    })).json();
  },
  async getNodeDebug(traceId: string, nodeId: string): Promise<DataProcessResult<NodeExecution>> {
    return (await fetch(`${API_BASE}/debug/${traceId}/nodes/${nodeId}`)).json();
  },
};

// --- Vue Flow ---
const { onConnect, addEdges, addNodes, setNodes, setEdges } = useVueFlow();

// --- Skill Palette ---
const skillPalette = [
  { skillId: '10', label: 'Figma Parser', icon: '🎨' },
  { skillId: '11', label: 'AI Transform', icon: '🤖' },
  { skillId: '12', label: 'AI Review', icon: '🔍' },
  { skillId: '13', label: 'Feedback', icon: '💬' },
  { skillId: '17', label: 'Code Generator', icon: '💻' },
  { skillId: '06', label: 'AI Provider', icon: '🧠' },
  { skillId: 'trigger', label: 'HTTP Trigger', icon: '🔌' },
  { skillId: 'condition', label: 'Condition', icon: '🔀' },
  { skillId: 'output', label: 'Output', icon: '📤' },
];

// --- Status Colors ---
const statusColors: Record<string, string> = {
  pending: '#6b7280', running: '#f59e0b', success: '#10b981', error: '#ef4444', skipped: '#9ca3af',
};

const getNodeBorder = (nodeId: string) => {
  const exec = nodeExecutions.value[nodeId];
  return statusColors[exec?.status || 'pending'] || '#6b7280';
};

// --- WebSocket ---
let ws: WebSocket | null = null;

const connectWs = (traceId: string) => {
  ws?.close();
  ws = new WebSocket(`ws://${window.location.host}/api/v1/ws/flow/${traceId}`);
  ws.onopen = () => store.setExecuting(true);
  ws.onmessage = (e) => store.updateNodeExecution(JSON.parse(e.data));
  ws.onclose = () => store.setExecuting(false);
};

// --- Drag & Drop ---
const onDragStart = (event: DragEvent, skill: typeof skillPalette[0]) => {
  event.dataTransfer?.setData('application/xiigen-skill', JSON.stringify(skill));
};

const onCanvasDrop = (event: DragEvent) => {
  event.preventDefault();
  const raw = event.dataTransfer?.getData('application/xiigen-skill');
  if (!raw) return;
  const skill = JSON.parse(raw);
  addNodes([{
    id: `node-${Date.now()}`, type: 'skill',
    position: { x: event.offsetX - 90, y: event.offsetY - 30 },
    data: { ...skill, nodeId: `node-${Date.now()}` },
  }]);
};

onConnect((params) => addEdges([{ ...params, id: `edge-${Date.now()}` }]));

// --- Load Flow ---
onMounted(async () => {
  const result = await flowApi.loadFlow(props.flowId);
  if (result.success) {
    store.setFlow(result.data);
    setNodes(result.data.nodes.map((n) => ({
      id: n.id, type: 'skill', position: n.position,
      data: { ...n.config, skillId: n.skillId, label: n.label, nodeId: n.id, icon: skillPalette.find(s => s.skillId === n.skillId)?.icon || '⚙️' },
    })));
    setEdges(result.data.edges.map((e) => ({ id: e.id, source: e.source, target: e.target })));
  }
});

onUnmounted(() => ws?.close());

// --- Auto-save ---
let saveTimer: any;
watch(flowDefinition, (flow) => {
  if (!flow) return;
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => flowApi.saveFlow(flow), 3000);
}, { deep: true });

// --- Actions ---
const executeFlow = async () => {
  const result = await flowApi.triggerExecution(props.flowId, { source: 'editor' });
  if (result.success) {
    store.setTraceId(result.data.traceId);
    connectWs(result.data.traceId);
  }
};

const onNodeClick = (_event: MouseEvent, node: any) => {
  store.selectNode(node.id);
};

// --- Inspector ---
const selectedExecution = computed(() =>
  selectedNodeId.value ? nodeExecutions.value[selectedNodeId.value] : null
);

const debugData = ref<NodeExecution | null>(null);
watch(selectedNodeId, async (nodeId) => {
  if (nodeId && traceId.value) {
    const r = await flowApi.getNodeDebug(traceId.value, nodeId);
    if (r.success) debugData.value = r.data;
  } else {
    debugData.value = null;
  }
});
</script>

<template>
  <div class="flow-editor-container">
    <!-- Palette -->
    <div class="palette-sidebar">
      <h3>Skills</h3>
      <div v-for="skill in skillPalette" :key="skill.skillId"
           class="palette-item" draggable="true"
           @dragstart="(e) => onDragStart(e, skill)">
        <span>{{ skill.icon }}</span>
        <span>{{ skill.label }}</span>
      </div>
    </div>

    <!-- Canvas -->
    <div class="canvas-area" @drop="onCanvasDrop" @dragover.prevent>
      <div class="toolbar">
        <button class="run-btn" @click="executeFlow" :disabled="isExecuting">▶ Run Flow</button>
      </div>
      <VueFlow @node-click="onNodeClick" fit-view-on-init>
        <template #node-skill="{ data }">
          <div class="skill-node" :style="{ borderColor: getNodeBorder(data.nodeId) }">
            <span class="node-icon">{{ data.icon || '⚙️' }}</span>
            <div>
              <div class="node-label">{{ data.label }}</div>
              <div class="node-skill-id">Skill {{ data.skillId }}</div>
            </div>
          </div>
        </template>
        <Background />
        <Controls />
        <MiniMap />
      </VueFlow>
    </div>

    <!-- Inspector -->
    <div class="inspector-panel">
      <h3>Node Inspector</h3>
      <div v-if="!selectedNodeId" class="empty">Select a node to inspect</div>
      <div v-else-if="selectedExecution || debugData">
        <div class="field">
          <label>Status</label>
          <span :style="{ color: statusColors[(selectedExecution || debugData)?.status || 'pending'] }">
            {{ (selectedExecution || debugData)?.status }}
          </span>
        </div>
        <div v-if="(debugData || selectedExecution)?.input" class="field">
          <label>Input</label>
          <pre>{{ JSON.stringify((debugData || selectedExecution)?.input, null, 2) }}</pre>
        </div>
        <div v-if="(debugData || selectedExecution)?.prompt" class="field">
          <label>Prompt</label>
          <pre class="prompt-pre">{{ (debugData || selectedExecution)?.prompt }}</pre>
        </div>
        <div v-if="(debugData || selectedExecution)?.output" class="field">
          <label>Output</label>
          <pre class="output-pre">{{ JSON.stringify((debugData || selectedExecution)?.output, null, 2) }}</pre>
        </div>
        <div v-if="(debugData || selectedExecution)?.error" class="field error">
          <label>Error</label>
          <pre>{{ (debugData || selectedExecution)?.error }}</pre>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.flow-editor-container { display: flex; height: 100vh; }
.palette-sidebar { width: 220px; border-right: 1px solid #e5e7eb; padding: 12px; overflow-y: auto; }
.palette-sidebar h3 { font-size: 14px; font-weight: 600; margin-bottom: 12px; }
.palette-item { padding: 8px; margin-bottom: 6px; border: 1px solid #e5e7eb; border-radius: 6px;
                cursor: grab; display: flex; align-items: center; gap: 8px; font-size: 13px; background: #f9fafb; }
.canvas-area { flex: 1; position: relative; }
.toolbar { position: absolute; top: 12px; right: 12px; z-index: 10; }
.run-btn { padding: 8px 16px; background: #3b82f6; color: #fff; border: none; border-radius: 6px; cursor: pointer; font-weight: 600; }
.skill-node { display: flex; align-items: center; gap: 8px; padding: 12px; border: 2px solid #6b7280;
              border-radius: 8px; background: #fff; min-width: 180px; }
.node-icon { font-size: 18px; }
.node-label { font-weight: 600; font-size: 13px; }
.node-skill-id { font-size: 11px; color: #6b7280; }
.inspector-panel { width: 300px; border-left: 1px solid #e5e7eb; padding: 16px; overflow-y: auto; }
.empty { color: #9ca3af; font-size: 13px; }
.field { margin-top: 12px; }
.field label { font-size: 12px; font-weight: 600; display: block; margin-bottom: 4px; }
.field pre { font-size: 10px; background: #f3f4f6; padding: 8px; border-radius: 4px; overflow: auto; max-height: 200px; }
.prompt-pre { background: #fffbeb !important; }
.output-pre { background: #ecfdf5 !important; }
.error label { color: #ef4444; }
.error pre { background: #fef2f2 !important; }
</style>
