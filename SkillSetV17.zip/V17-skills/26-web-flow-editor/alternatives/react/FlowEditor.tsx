/**
 * XIIGen Skill 26: Web Flow Editor — React Alternative (Primary)
 * Visual drag-and-drop flow builder using React Flow
 * DNA: DataProcessResult for operations, FlowDefinition schema from Skill 08, WebSocket execution overlay
 */
import React, { useCallback, useEffect, useState, useMemo } from 'react';
import ReactFlow, {
  addEdge, Background, Controls, MiniMap,
  useNodesState, useEdgesState, Connection, Edge, Node,
  Handle, Position, NodeProps, ReactFlowProvider,
} from 'reactflow';
import { create } from 'zustand';

// --- DNA: DataProcessResult for UI operations ---
interface DataProcessResult<T> { success: boolean; data: T; message: string; }

// --- FlowDefinition (DNA: same schema as Skill 08) ---
interface FlowDefinition {
  id: string; scopeId: string; name: string; version: string;
  nodes: FlowNodeDef[]; edges: FlowEdgeDef[];
  metadata: Record<string, any>; createdAt: string; updatedAt: string;
}

interface FlowNodeDef {
  id: string; skillId: string; label: string; type: string;
  position: { x: number; y: number };
  config: Record<string, any>; inputs: string[]; outputs: string[];
}

interface FlowEdgeDef {
  id: string; source: string; target: string;
  sourceHandle?: string; targetHandle?: string;
  condition?: string;
}

// --- Execution state from WebSocket ---
interface NodeExecution {
  nodeId: string; status: 'pending' | 'running' | 'success' | 'error' | 'skipped';
  startedAt?: string; completedAt?: string; durationMs?: number;
  input?: any; output?: any; prompt?: string; error?: string;
}

// --- Zustand Store (DNA: centralized flow state) ---
interface FlowEditorStore {
  flowId: string | null; flowDefinition: FlowDefinition | null;
  traceId: string | null; isExecuting: boolean;
  nodeExecutions: Record<string, NodeExecution>;
  selectedNodeId: string | null;
  setFlow: (flow: FlowDefinition) => void;
  setTraceId: (id: string) => void;
  updateNodeExecution: (exec: NodeExecution) => void;
  selectNode: (id: string | null) => void;
  setExecuting: (v: boolean) => void;
}

const useFlowEditorStore = create<FlowEditorStore>((set) => ({
  flowId: null, flowDefinition: null, traceId: null,
  isExecuting: false, nodeExecutions: {}, selectedNodeId: null,
  setFlow: (flow) => set({ flowDefinition: flow, flowId: flow.id }),
  setTraceId: (id) => set({ traceId: id }),
  updateNodeExecution: (exec) => set((s) => ({
    nodeExecutions: { ...s.nodeExecutions, [exec.nodeId]: exec },
  })),
  selectNode: (id) => set({ selectedNodeId: id }),
  setExecuting: (v) => set({ isExecuting: v }),
}));

// --- API Service (calls Skill 15 API Gateway) ---
const API_BASE = process.env.REACT_APP_API_URL || '/api/v1';

const flowApi = {
  async loadFlow(flowId: string): Promise<DataProcessResult<FlowDefinition>> {
    const res = await fetch(`${API_BASE}/flows/${flowId}`);
    const data = await res.json();
    return data;
  },

  async saveFlow(flow: FlowDefinition): Promise<DataProcessResult<FlowDefinition>> {
    const res = await fetch(`${API_BASE}/flows/${flow.id}`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(flow),
    });
    return res.json();
  },

  async triggerExecution(flowId: string, input: any): Promise<DataProcessResult<{ traceId: string }>> {
    const res = await fetch(`${API_BASE}/flows/${flowId}/execute`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input),
    });
    return res.json();
  },

  async getNodeDebug(traceId: string, nodeId: string): Promise<DataProcessResult<NodeExecution>> {
    const res = await fetch(`${API_BASE}/debug/${traceId}/nodes/${nodeId}`);
    return res.json();
  },
};

// --- Custom Hooks ---

/** WebSocket hook for real-time execution updates */
const useExecutionSocket = (traceId: string | null) => {
  const updateNodeExecution = useFlowEditorStore((s) => s.updateNodeExecution);
  const setExecuting = useFlowEditorStore((s) => s.setExecuting);

  useEffect(() => {
    if (!traceId) return;
    const wsUrl = `${API_BASE.replace('http', 'ws')}/ws/flow/${traceId}`;
    const ws = new WebSocket(wsUrl);

    ws.onopen = () => setExecuting(true);
    ws.onmessage = (e) => {
      const event = JSON.parse(e.data) as NodeExecution;
      updateNodeExecution(event);
      if (event.status === 'success' || event.status === 'error') {
        // Check if all nodes are done
      }
    };
    ws.onclose = () => setExecuting(false);
    ws.onerror = () => setExecuting(false);

    return () => { ws.close(); };
  }, [traceId, updateNodeExecution, setExecuting]);
};

/** Auto-save hook */
const useAutoSave = (flow: FlowDefinition | null, debounceMs: number = 3000) => {
  useEffect(() => {
    if (!flow) return;
    const timer = setTimeout(async () => {
      // Save to localStorage as draft
      localStorage.setItem(`flow-draft-${flow.id}`, JSON.stringify(flow));
      // Save to server
      await flowApi.saveFlow(flow);
    }, debounceMs);
    return () => clearTimeout(timer);
  }, [flow, debounceMs]);
};

// --- Skill Node Component (DNA: renders any XIIGen skill) ---

const statusColors: Record<string, string> = {
  pending: '#6b7280', running: '#f59e0b', success: '#10b981',
  error: '#ef4444', skipped: '#9ca3af',
};

const SkillNode: React.FC<NodeProps> = ({ data, selected }) => {
  const execution = useFlowEditorStore((s) => s.nodeExecutions[data.nodeId]);
  const status = execution?.status || 'pending';
  const borderColor = statusColors[status] || '#6b7280';

  return (
    <div style={{
      border: `2px solid ${borderColor}`,
      borderRadius: 8, padding: 12, background: '#fff', minWidth: 180,
      boxShadow: selected ? '0 0 0 2px #3b82f6' : '0 1px 3px rgba(0,0,0,0.1)',
    }}>
      <Handle type="target" position={Position.Left} />
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <span style={{ fontSize: 18 }}>{data.icon || '⚙️'}</span>
        <div>
          <div style={{ fontWeight: 600, fontSize: 13 }}>{data.label}</div>
          <div style={{ fontSize: 11, color: '#6b7280' }}>Skill {data.skillId}</div>
        </div>
      </div>
      {execution?.durationMs && (
        <div style={{ fontSize: 10, color: '#9ca3af', marginTop: 4 }}>
          {execution.durationMs}ms
        </div>
      )}
      {status === 'running' && (
        <div style={{ fontSize: 10, color: '#f59e0b', marginTop: 4 }}>● Running...</div>
      )}
      <Handle type="source" position={Position.Right} />
    </div>
  );
};

// --- Node Palette (sidebar with draggable skill nodes) ---

const SKILL_PALETTE = [
  { skillId: '10', label: 'Figma Parser', icon: '🎨', type: 'skill' },
  { skillId: '11', label: 'AI Transform', icon: '🤖', type: 'skill' },
  { skillId: '12', label: 'AI Review', icon: '🔍', type: 'skill' },
  { skillId: '13', label: 'Feedback', icon: '💬', type: 'skill' },
  { skillId: '17', label: 'Code Generator', icon: '💻', type: 'skill' },
  { skillId: '06', label: 'AI Provider', icon: '🧠', type: 'skill' },
  { skillId: 'trigger', label: 'HTTP Trigger', icon: '🔌', type: 'trigger' },
  { skillId: 'condition', label: 'Condition', icon: '🔀', type: 'condition' },
  { skillId: 'output', label: 'Output', icon: '📤', type: 'output' },
];

const NodePalette: React.FC = () => {
  const onDragStart = (event: React.DragEvent, skill: typeof SKILL_PALETTE[0]) => {
    event.dataTransfer.setData('application/xiigen-skill', JSON.stringify(skill));
    event.dataTransfer.effectAllowed = 'move';
  };

  return (
    <div style={{ width: 220, borderRight: '1px solid #e5e7eb', padding: 12, overflowY: 'auto' }}>
      <h3 style={{ fontSize: 14, fontWeight: 600, marginBottom: 12 }}>Skills</h3>
      {SKILL_PALETTE.map((skill) => (
        <div
          key={skill.skillId}
          draggable
          onDragStart={(e) => onDragStart(e, skill)}
          style={{
            padding: 8, marginBottom: 6, borderRadius: 6, cursor: 'grab',
            border: '1px solid #e5e7eb', background: '#f9fafb',
            display: 'flex', alignItems: 'center', gap: 8, fontSize: 13,
          }}
        >
          <span>{skill.icon}</span>
          <span>{skill.label}</span>
        </div>
      ))}
    </div>
  );
};

// --- Node Inspector (debug panel for selected node) ---

const NodeInspector: React.FC = () => {
  const selectedNodeId = useFlowEditorStore((s) => s.selectedNodeId);
  const execution = useFlowEditorStore((s) => selectedNodeId ? s.nodeExecutions[selectedNodeId] : null);
  const traceId = useFlowEditorStore((s) => s.traceId);
  const [debugData, setDebugData] = useState<NodeExecution | null>(null);

  useEffect(() => {
    if (!traceId || !selectedNodeId) return;
    flowApi.getNodeDebug(traceId, selectedNodeId).then((r) => {
      if (r.success) setDebugData(r.data);
    });
  }, [traceId, selectedNodeId]);

  if (!selectedNodeId) {
    return <div style={{ width: 300, padding: 16, color: '#9ca3af' }}>Select a node to inspect</div>;
  }

  const data = debugData || execution;

  return (
    <div style={{ width: 300, borderLeft: '1px solid #e5e7eb', padding: 16, overflowY: 'auto' }}>
      <h3 style={{ fontSize: 14, fontWeight: 600 }}>Node Inspector</h3>
      <div style={{ fontSize: 12, color: '#6b7280', marginTop: 8 }}>ID: {selectedNodeId}</div>
      {data && (
        <>
          <div style={{ marginTop: 12 }}>
            <div style={{ fontSize: 12, fontWeight: 600 }}>Status</div>
            <div style={{ color: statusColors[data.status] }}>{data.status}</div>
          </div>
          {data.input && (
            <div style={{ marginTop: 12 }}>
              <div style={{ fontSize: 12, fontWeight: 600 }}>Input</div>
              <pre style={{ fontSize: 10, background: '#f3f4f6', padding: 8, borderRadius: 4, overflow: 'auto', maxHeight: 200 }}>
                {JSON.stringify(data.input, null, 2)}
              </pre>
            </div>
          )}
          {data.prompt && (
            <div style={{ marginTop: 12 }}>
              <div style={{ fontSize: 12, fontWeight: 600 }}>Prompt</div>
              <pre style={{ fontSize: 10, background: '#fffbeb', padding: 8, borderRadius: 4, overflow: 'auto', maxHeight: 200 }}>
                {data.prompt}
              </pre>
            </div>
          )}
          {data.output && (
            <div style={{ marginTop: 12 }}>
              <div style={{ fontSize: 12, fontWeight: 600 }}>Output</div>
              <pre style={{ fontSize: 10, background: '#ecfdf5', padding: 8, borderRadius: 4, overflow: 'auto', maxHeight: 200 }}>
                {JSON.stringify(data.output, null, 2)}
              </pre>
            </div>
          )}
          {data.error && (
            <div style={{ marginTop: 12 }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: '#ef4444' }}>Error</div>
              <pre style={{ fontSize: 10, background: '#fef2f2', padding: 8, borderRadius: 4 }}>{data.error}</pre>
            </div>
          )}
        </>
      )}
    </div>
  );
};

// --- Main Flow Editor Component ---

const nodeTypes = { skill: SkillNode };

export const FlowEditor: React.FC<{ flowId: string }> = ({ flowId }) => {
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const { flowDefinition, setFlow, selectNode, traceId, setTraceId } = useFlowEditorStore();

  // Load flow
  useEffect(() => {
    flowApi.loadFlow(flowId).then((result) => {
      if (result.success) {
        setFlow(result.data);
        setNodes(result.data.nodes.map((n) => ({
          id: n.id, type: 'skill', position: n.position,
          data: { ...n.config, skillId: n.skillId, label: n.label, nodeId: n.id },
        })));
        setEdges(result.data.edges.map((e) => ({
          id: e.id, source: e.source, target: e.target, animated: false,
        })));
      }
    });
  }, [flowId]);

  // WebSocket for execution
  useExecutionSocket(traceId);

  // Auto-save
  useAutoSave(flowDefinition);

  const onConnect = useCallback(
    (connection: Connection) => setEdges((eds) => addEdge(connection, eds)),
    [setEdges],
  );

  const onDrop = useCallback(
    (event: React.DragEvent) => {
      event.preventDefault();
      const skillData = JSON.parse(event.dataTransfer.getData('application/xiigen-skill'));
      const position = { x: event.clientX - 200, y: event.clientY - 100 };
      const newNode: Node = {
        id: `node-${Date.now()}`, type: 'skill', position,
        data: { ...skillData, nodeId: `node-${Date.now()}` },
      };
      setNodes((nds) => [...nds, newNode]);
    },
    [setNodes],
  );

  const onDragOver = useCallback((event: React.DragEvent) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
  }, []);

  const handleExecute = async () => {
    const result = await flowApi.triggerExecution(flowId, { source: 'editor' });
    if (result.success) {
      setTraceId(result.data.traceId);
    }
  };

  return (
    <div style={{ display: 'flex', height: '100vh' }}>
      <NodePalette />
      <div style={{ flex: 1, position: 'relative' }}>
        <div style={{ position: 'absolute', top: 12, right: 12, zIndex: 10, display: 'flex', gap: 8 }}>
          <button onClick={handleExecute} style={{
            padding: '8px 16px', background: '#3b82f6', color: '#fff',
            border: 'none', borderRadius: 6, cursor: 'pointer', fontWeight: 600,
          }}>
            ▶ Run Flow
          </button>
        </div>
        <ReactFlow
          nodes={nodes} edges={edges} nodeTypes={nodeTypes}
          onNodesChange={onNodesChange} onEdgesChange={onEdgesChange}
          onConnect={onConnect} onDrop={onDrop} onDragOver={onDragOver}
          onNodeClick={(_, node) => selectNode(node.id)}
          fitView
        >
          <Background /> <Controls /> <MiniMap />
        </ReactFlow>
      </div>
      <NodeInspector />
    </div>
  );
};

export default function FlowEditorPage({ flowId }: { flowId: string }) {
  return (
    <ReactFlowProvider>
      <FlowEditor flowId={flowId} />
    </ReactFlowProvider>
  );
}
