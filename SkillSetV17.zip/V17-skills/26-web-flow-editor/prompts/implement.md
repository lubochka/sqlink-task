# Skill 26: Web Flow Editor — Implementation Prompt

## Phase 1: Flow Canvas
React + React Flow setup. Draggable canvas with zoom/pan. Node palette sidebar with available node types.

## Phase 2: Node Types & Connections
Implement node types: trigger, ai-transform, ai-review, condition, output, custom.
Edge creation with validation (prevent cycles via topological check).
Node configuration panel (click node → edit properties).

## Phase 3: Flow State Management
Zustand store for flow state. Undo/redo stack. Auto-save flow definitions as dynamic documents to API.
Flow validation: ensure at least one trigger, no orphan nodes, no cycles.

## Phase 4: Entity-Driven Node Palette (DNA-4)
Node types loaded from entity definitions API. New entity registered → new node type appears.
Platform templates loaded dynamically — admin adds platform → new trigger option.

## Phase 5: Execution Overlay
Connect to FlowOrchestrator API. Show live execution status per node (pending/running/done/failed).
Trace polling with progress indicators. Result display on completed nodes.

---

## Genie DNA Compliance — MANDATORY
☐ DNA-1: Dynamic Documents — `Dictionary<string, object>`, NOT typed models
☐ DNA-2: BuildSearchFilter — skip empty fields, no entity-specific query code
☐ DNA-3: MicroserviceBase — inherit DB, queue, cache, logger
☐ DNA-5: DataProcessResult<T> — all methods return result wrapper
☐ DNA-6: Generic Interfaces — external deps behind interfaces, swap via config
☐ DNA-SCOPE: Non-admin queries auto-inject userId filter
