---
skill_id: "26"
name: web-flow-editor
title: "Web Flow Editor"
layer: "L9: Showroom"
version: "17.1"
status: "active"
priority: "P0"
dependencies: ["08-flow-definition", "09-flow-orchestrator", "14-node-debugger", "15-api-gateway"]
alternatives_client: [react-flow, angular-flow, vue-flow, svelte-flow, solid-flow]
genie_dna:
  - "DNA-UI: Visual flow editor renders flow definitions as draggable node graphs"
  - "DNA-6: Flow editor uses same FlowDefinition schema across all client alternatives"
  - "DNA-RESULT: Flow operations return DataProcessResult for consistent status feedback"
triggers: flow editor, visual editor, drag and drop, n8n-style, node graph, flow builder, workflow editor, web editor
estimated_loc: 1500
---

# Skill 26: Web Flow Editor
## Visual Drag-and-Drop Flow Builder (n8n-Style)

**Classification:** HUMAN — Visual design requires user creativity  
**Priority:** P0 — Core user interface for flow management  
**Dependencies:** Skill 08 (Flow Definition), Skill 09 (Orchestrator), Skill 14 (Debugger), Skill 15 (Gateway)  
**Layer:** L9: Showroom  
**Estimated LOC:** ~1500  

---

## Overview

The Web Flow Editor provides a visual, drag-and-drop interface for creating, editing, and monitoring XIIGen flows — similar to n8n, Retool, or Node-RED. Users connect skill nodes (AI transform, review, feedback, code gen, etc.) into pipelines, configure each node's parameters, trigger executions with traceIds, and watch real-time progress with node-level debugging. The editor reads/writes FlowDefinition JSON (Skill 08) and integrates with the orchestrator (Skill 09) and debugger (Skill 14).

## Key Concepts

- **Node Palette** — Sidebar listing all available skills as draggable nodes. Each node type has input/output ports, configurable parameters, and a DNA compliance badge.
- **Canvas** — Zoomable, pannable canvas where nodes are placed and connected via edges (data flow or event triggers).
- **Execution Overlay** — When a flow runs, nodes light up green/yellow/red in real-time showing execution progress, with timing and status.
- **Node Inspector** — Click a node to see: configuration, input data, prompt used, AI output, execution time, debug info (Skill 14).
- **Flow Templates** — Pre-built flow templates (Phase F) that users can import and customize.
- **Version History** — Every save creates a version. Diff view shows changes between versions.

---

## DNA Integration

### Required Patterns
- **Dynamic Document** — Flow definitions stored as dynamic documents. The editor reads/writes the same JSON format as Skill 08.
- **DataProcessResult** — Flow save/execute/debug operations return DataProcessResult for consistent UI feedback.
- **EventDriven** — WebSocket connection receives node execution events in real-time for the execution overlay.

### Anti-Patterns to AVOID
- ❌ Custom flow format different from FlowDefinition (Skill 08) — use the same JSON schema
- ❌ Polling for execution status — use WebSocket for real-time updates
- ❌ Client-side flow validation only — always validate on server too
- ❌ Losing unsaved work — auto-save drafts to localStorage + server

---

## Primary Implementation (React + React Flow)

### Architecture

```
src/
├── components/
│   ├── Canvas.tsx           // React Flow canvas wrapper
│   ├── NodePalette.tsx      // Draggable skill nodes sidebar
│   ├── NodeInspector.tsx    // Node detail panel
│   ├── ExecutionOverlay.tsx // Real-time execution visualization
│   ├── FlowToolbar.tsx      // Save, run, debug, template buttons
│   └── nodes/
│       ├── SkillNode.tsx    // Generic skill node component
│       ├── TriggerNode.tsx  // HTTP/event trigger node
│       ├── ConditionNode.tsx // If/else branching
│       └── OutputNode.tsx   // Final result node
├── hooks/
│   ├── useFlowDefinition.ts // Load/save flow JSON
│   ├── useExecution.ts      // WebSocket execution tracking
│   └── useNodeDebug.ts      // Node debug data fetching
├── services/
│   ├── flowApi.ts           // CRUD for flow definitions
│   └── executionApi.ts      // Trigger + status APIs
└── store/
    └── flowEditorStore.ts   // Zustand store for editor state
```

### Key Components

```tsx
// SkillNode — renders any XIIGen skill as a flow node
const SkillNode = ({ data }: NodeProps) => {
  const { skillId, label, status, duration } = data;
  return (
    <div className={`skill-node ${status}`}>
      <Handle type="target" position={Position.Left} />
      <div className="node-header">
        <SkillIcon skillId={skillId} />
        <span>{label}</span>
      </div>
      {status && <StatusBadge status={status} duration={duration} />}
      <Handle type="source" position={Position.Right} />
    </div>
  );
};

// Execution overlay — real-time node status updates
const useExecution = (traceId: string) => {
  const [nodeStatuses, setNodeStatuses] = useState<Record<string, NodeStatus>>({});
  useEffect(() => {
    const ws = new WebSocket(`${WS_URL}/flow/${traceId}`);
    ws.onmessage = (e) => {
      const event = JSON.parse(e.data);
      setNodeStatuses(prev => ({...prev, [event.nodeId]: event}));
    };
    return () => ws.close();
  }, [traceId]);
  return nodeStatuses;
};
```

---

## Test Scenarios

1. Drag skill node to canvas → verify node created with correct input/output ports
2. Connect two nodes → verify edge created, flow definition JSON updated
3. Save flow → verify server receives valid FlowDefinition JSON
4. Trigger execution → verify real-time node status updates via WebSocket
5. Click completed node → verify debug data (input/prompt/output) displayed
6. Import flow template → verify all nodes and edges rendered correctly
7. Version diff → verify changes highlighted between two saved versions

## Component Classification
- **Category:** Visual Flow Builder
- **Inputs:** User drag/drop/click actions, FlowDefinition JSON, WebSocket events
- **Outputs:** FlowDefinition JSON, execution triggers, debug queries
- **Side Effects:** WebSocket connections, auto-save to localStorage
