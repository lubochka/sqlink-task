// =============================================================================
// Skill 11 — AI Transform Service (.NET 9)
// Multi-model parallel AI code generation with feedback injection
// Genie DNA: Dynamic documents, BuildSearchFilter, DataProcessResult
// =============================================================================

using System.Collections.Concurrent;
using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace XIIGen.Services.AiTransform;

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------
public sealed record TransformConfig
{
    public List<string> Models { get; init; } = ["claude-sonnet", "gpt-4o"];
    public string MergeStrategy { get; init; } = "best-score";
    public int MaxTokens { get; init; } = 4096;
    public double Temperature { get; init; } = 0.3;
    public int FeedbackLookback { get; init; } = 10;
    public bool RetryOnFailure { get; init; } = true;
    public int TimeoutSeconds { get; init; } = 120;
    public TargetStackConfig TargetStack { get; init; } = new();
}

public sealed record TargetStackConfig
{
    public string Client { get; init; } = "react";
    public string Server { get; init; } = "dotnet";
    public string Database { get; init; } = "elasticsearch";
}

// ---------------------------------------------------------------------------
// Models (dynamic document wrappers)
// ---------------------------------------------------------------------------
public sealed record ModelResponse
{
    public string ModelId { get; init; } = "";
    public string Provider { get; init; } = "";
    public bool Success { get; init; }
    public string? RawResponse { get; init; }
    public string? ClientCode { get; init; }
    public string? ServerCode { get; init; }
    public string? DatabaseCode { get; init; }
    public double Score { get; init; }
    public string? Error { get; init; }
    public long LatencyMs { get; init; }
    public int TokensUsed { get; init; }
}

public sealed record TransformOutput
{
    public string TransformId { get; init; } = Guid.NewGuid().ToString("N");
    public string? ClientCode { get; init; }
    public string? ServerCode { get; init; }
    public string? DatabaseCode { get; init; }
    public double MergedScore { get; init; }
    public string MergeStrategy { get; init; } = "";
    public List<ModelResponse> ModelResults { get; init; } = [];
    public string PromptUsed { get; init; } = "";
    public int FeedbackItemsInjected { get; init; }
    public DateTime CompletedAt { get; init; } = DateTime.UtcNow;
}

public sealed record MergedResult
{
    public string? ClientCode { get; init; }
    public string? ServerCode { get; init; }
    public string? DatabaseCode { get; init; }
    public double Score { get; init; }
    public string StrategyUsed { get; init; } = "";
}

// ---------------------------------------------------------------------------
// DataProcessResult (Genie DNA-3)
// ---------------------------------------------------------------------------
public sealed record DataProcessResult<T>
{
    public bool IsSuccess { get; init; }
    public T? Data { get; init; }
    public string? Error { get; init; }
    public Dictionary<string, object>? Metadata { get; init; }

    public static DataProcessResult<T> Ok(T data, Dictionary<string, object>? meta = null)
        => new() { IsSuccess = true, Data = data, Metadata = meta };
    public static DataProcessResult<T> Failure(string error, Dictionary<string, object>? meta = null)
        => new() { IsSuccess = false, Error = error, Metadata = meta };
}

// ---------------------------------------------------------------------------
// Interfaces (Genie DNA-5 — generic provider pattern)
// ---------------------------------------------------------------------------
public interface IAiTransformService
{
    Task<DataProcessResult<TransformOutput>> ExecuteAsync(
        FlowStepContext context, CancellationToken ct = default);

    Task<DataProcessResult<TransformOutput>> TransformComponentsAsync(
        IReadOnlyList<Dictionary<string, object>> components,
        TransformConfig config, CancellationToken ct = default);

    Task<string> AssemblePromptAsync(
        IReadOnlyList<Dictionary<string, object>> components,
        TransformConfig config,
        IReadOnlyList<Dictionary<string, object>> feedbackHistory,
        CancellationToken ct = default);

    Task<DataProcessResult<MergedResult>> MergeResultsAsync(
        IReadOnlyList<ModelResponse> responses, string mergeStrategy,
        CancellationToken ct = default);
}

/// <summary>Flow step context — passed by Skill 09 (Flow Orchestrator)</summary>
public record FlowStepContext
{
    public string TraceId { get; init; } = "";
    public string FlowId { get; init; } = "";
    public string NodeId { get; init; } = "";
    public Dictionary<string, object> Input { get; init; } = [];
    public Dictionary<string, object> NodeConfig { get; init; } = [];
    public Dictionary<string, object> FlowVariables { get; init; } = [];
}

// Skill 06 / 07 interfaces (expected from earlier phases)
public interface IAiDispatcher
{
    Task<Dictionary<string, object>> DispatchAsync(
        string modelId, string prompt, Dictionary<string, object>? options = null,
        CancellationToken ct = default);

    Task<IReadOnlyList<Dictionary<string, object>>> DispatchParallelAsync(
        IReadOnlyList<string> modelIds, string prompt,
        Dictionary<string, object>? options = null, CancellationToken ct = default);
}

// Skill 13 interface
public interface IFeedbackService
{
    Task<IReadOnlyList<Dictionary<string, object>>> GetFeedbackHistoryAsync(
        Dictionary<string, object> filter, int limit = 10,
        CancellationToken ct = default);
}

// Skill 14 interface
public interface INodeDebugger
{
    Task StoreSnapshotAsync(string traceId, string nodeId,
        Dictionary<string, object> snapshot, CancellationToken ct = default);
}

// Skill 02 interface
public interface IObjectProcessor
{
    Dictionary<string, object> ParseObjectAlternative(object input);
    Dictionary<string, object> BuildSearchFilter(object filter);
    Dictionary<string, object> MergeObjects(
        Dictionary<string, object> a, Dictionary<string, object> b);
}

// ---------------------------------------------------------------------------
// Implementation
// ---------------------------------------------------------------------------
public sealed class AiTransformService : IAiTransformService
{
    private readonly IAiDispatcher _dispatcher;
    private readonly IFeedbackService _feedback;
    private readonly INodeDebugger _debugger;
    private readonly IObjectProcessor _objectProcessor;
    private readonly ILogger<AiTransformService> _logger;

    // Regex patterns for response parsing (from FigmaCodeGenerator pattern)
    private static readonly Regex ClientCodeRegex = new(
        @"//\s*===\s*CLIENT\s*CODE\s*===[\s\S]*?```[\w]*\n([\s\S]*?)```",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);
    private static readonly Regex ServerCodeRegex = new(
        @"//\s*===\s*SERVER\s*CODE\s*===[\s\S]*?```[\w]*\n([\s\S]*?)```",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);
    private static readonly Regex DatabaseCodeRegex = new(
        @"//\s*===\s*DATABASE\s*CODE\s*===[\s\S]*?```[\w]*\n([\s\S]*?)```",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);
    private static readonly Regex CodeBlockRegex = new(
        @"```[\w]*\n([\s\S]*?)```",
        RegexOptions.Compiled);

    public AiTransformService(
        IAiDispatcher dispatcher,
        IFeedbackService feedback,
        INodeDebugger debugger,
        IObjectProcessor objectProcessor,
        ILogger<AiTransformService> logger)
    {
        _dispatcher = dispatcher;
        _feedback = feedback;
        _debugger = debugger;
        _objectProcessor = objectProcessor;
        _logger = logger;
    }

    // -----------------------------------------------------------------------
    // Execute — called by Flow Orchestrator (Skill 09) as a step executor
    // -----------------------------------------------------------------------
    public async Task<DataProcessResult<TransformOutput>> ExecuteAsync(
        FlowStepContext context, CancellationToken ct = default)
    {
        _logger.LogInformation("AI Transform executing for trace {TraceId}, node {NodeId}",
            context.TraceId, context.NodeId);

        try
        {
            // Extract config from node configuration (Genie DNA — dynamic document)
            var config = ExtractConfig(context.NodeConfig);

            // Extract components from input (dynamic document — no fixed schema)
            var components = ExtractComponents(context.Input);

            var result = await TransformComponentsAsync(components, config, ct);

            // Store debug snapshot (Skill 14)
            if (result.IsSuccess && result.Data is not null)
            {
                await StoreDebugSnapshot(context, result.Data, ct);
            }

            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "AI Transform failed for trace {TraceId}", context.TraceId);
            return DataProcessResult<TransformOutput>.Failure(
                $"Transform execution failed: {ex.Message}");
        }
    }

    // -----------------------------------------------------------------------
    // TransformComponents — core pipeline
    // -----------------------------------------------------------------------
    public async Task<DataProcessResult<TransformOutput>> TransformComponentsAsync(
        IReadOnlyList<Dictionary<string, object>> components,
        TransformConfig config, CancellationToken ct = default)
    {
        // Step 1: Load feedback history
        var feedbackHistory = await LoadFeedbackAsync(components, config, ct);
        _logger.LogInformation("Loaded {Count} feedback items for injection",
            feedbackHistory.Count);

        // Step 2: Assemble prompt
        var prompt = await AssemblePromptAsync(components, config, feedbackHistory, ct);

        // Step 3: Dispatch to multiple models in parallel
        var modelResponses = await DispatchToModelsAsync(
            config.Models, prompt, config, ct);

        // Step 4: Parse responses
        var parsedResponses = modelResponses
            .Select(ParseModelResponse)
            .ToList();

        // Step 5: Merge results
        var mergeResult = await MergeResultsAsync(
            parsedResponses, config.MergeStrategy, ct);

        if (!mergeResult.IsSuccess || mergeResult.Data is null)
        {
            return DataProcessResult<TransformOutput>.Failure(
                mergeResult.Error ?? "Merge failed with no results");
        }

        // Step 6: Build output
        var output = new TransformOutput
        {
            ClientCode = mergeResult.Data.ClientCode,
            ServerCode = mergeResult.Data.ServerCode,
            DatabaseCode = mergeResult.Data.DatabaseCode,
            MergedScore = mergeResult.Data.Score,
            MergeStrategy = config.MergeStrategy,
            ModelResults = parsedResponses,
            PromptUsed = prompt,
            FeedbackItemsInjected = feedbackHistory.Count,
            CompletedAt = DateTime.UtcNow
        };

        return DataProcessResult<TransformOutput>.Ok(output);
    }

    // -----------------------------------------------------------------------
    // Prompt Assembly (4-layer pattern from FigmaCodeGenerator)
    // -----------------------------------------------------------------------
    public async Task<string> AssemblePromptAsync(
        IReadOnlyList<Dictionary<string, object>> components,
        TransformConfig config,
        IReadOnlyList<Dictionary<string, object>> feedbackHistory,
        CancellationToken ct = default)
    {
        var sections = new List<string>();

        // Layer 1: System Context
        sections.Add(BuildSystemContext(config));

        // Layer 2: Design Data (from components)
        sections.Add(BuildDesignDataSection(components));

        // Layer 3: Feedback History (positive + negative examples)
        if (feedbackHistory.Count > 0)
        {
            sections.Add(BuildFeedbackSection(feedbackHistory));
        }

        // Layer 4: Target-Specific Instructions
        sections.Add(BuildTargetInstructions(config.TargetStack));

        return string.Join("\n\n", sections);
    }

    private static string BuildSystemContext(TransformConfig config)
    {
        return """
            You are a senior full-stack developer converting Figma design components into production-ready code.
            You will receive structured HTML/CSS fragments along with component metadata.
            
            CRITICAL OUTPUT FORMAT:
            - Respond with clearly separated code sections using markdown code blocks.
            - Label each section with a comment on its own line:
              // === CLIENT CODE ===
              // === SERVER CODE ===
              // === DATABASE CODE ===
            - Each label must be followed by a code block with the language specified.
            - Include TypeScript types, error handling, and accessibility attributes.
            - Follow SOLID principles and clean architecture patterns.
            """;
    }

    private string BuildDesignDataSection(
        IReadOnlyList<Dictionary<string, object>> components)
    {
        var sb = new System.Text.StringBuilder();
        sb.AppendLine("## Design Components");
        sb.AppendLine();

        for (int i = 0; i < components.Count; i++)
        {
            var comp = components[i];
            var name = GetDynamic(comp, "name", $"component_{i}");
            var html = GetDynamic(comp, "html", "");
            var css = GetDynamic(comp, "css", "");
            var type = GetDynamic(comp, "type", "unknown");

            sb.AppendLine($"### Component {i + 1}: {name} (type: {type})");
            if (!string.IsNullOrWhiteSpace(html))
            {
                sb.AppendLine($"```html\n{html}\n```");
            }
            if (!string.IsNullOrWhiteSpace(css))
            {
                sb.AppendLine($"```css\n{css}\n```");
            }
            sb.AppendLine();
        }

        return sb.ToString();
    }

    private static string BuildFeedbackSection(
        IReadOnlyList<Dictionary<string, object>> feedbackHistory)
    {
        var sb = new System.Text.StringBuilder();
        sb.AppendLine("## Previous Feedback (from similar conversions)");
        sb.AppendLine();

        var positive = feedbackHistory
            .Where(f => GetDynamic(f, "rating", "") == "positive")
            .ToList();
        var negative = feedbackHistory
            .Where(f => GetDynamic(f, "rating", "") == "negative")
            .ToList();

        if (positive.Count > 0)
        {
            sb.AppendLine("### ✅ What worked well:");
            foreach (var fb in positive)
            {
                var text = GetDynamic(fb, "text", "No details");
                sb.AppendLine($"- \"{text}\" (rating: positive)");
            }
            sb.AppendLine();
        }

        if (negative.Count > 0)
        {
            sb.AppendLine("### ❌ What to avoid:");
            foreach (var fb in negative)
            {
                var text = GetDynamic(fb, "text", "No details");
                sb.AppendLine($"- \"{text}\" (rating: negative)");
            }
            sb.AppendLine();
        }

        sb.AppendLine("Please apply these learnings to the current generation.");
        return sb.ToString();
    }

    private static string BuildTargetInstructions(TargetStackConfig stack)
    {
        var sb = new System.Text.StringBuilder();
        sb.AppendLine("## Generation Targets");
        sb.AppendLine();

        sb.AppendLine($"""
            ### Client-Side Code ({stack.Client})
            Generate frontend code that:
            1. Faithfully reproduces the visual design
            2. Uses semantic HTML elements
            3. Implements responsive design with mobile-first approach
            4. Handles interactive states (hover, focus, active, disabled)
            5. Includes form validation where applicable
            6. Follows accessibility best practices (ARIA labels, roles, keyboard nav)
            7. Uses TypeScript types for all props and state
            """);

        sb.AppendLine($"""
            ### Server-Side Code ({stack.Server})
            Generate backend code that:
            1. Provides API endpoints for all interactive elements
            2. Includes input validation and sanitization
            3. Implements proper error handling with structured responses
            4. Follows RESTful conventions with proper HTTP status codes
            5. Includes authentication/authorization scaffolding
            6. Uses dependency injection for all services
            """);

        sb.AppendLine($"""
            ### Database Schema ({stack.Database})
            Generate database code that:
            1. Models data entities inferred from the design
            2. Infers field types from form inputs and data displays
            3. Includes constraints, indexes, and relationships
            4. Provides migration/seed scripts
            5. Uses dynamic document approach where schema flexibility needed
            """);

        return sb.ToString();
    }

    // -----------------------------------------------------------------------
    // Multi-Model Dispatch
    // -----------------------------------------------------------------------
    private async Task<IReadOnlyList<Dictionary<string, object>>> DispatchToModelsAsync(
        List<string> modelIds, string prompt, TransformConfig config,
        CancellationToken ct)
    {
        var options = new Dictionary<string, object>
        {
            ["maxTokens"] = config.MaxTokens,
            ["temperature"] = config.Temperature,
            ["timeoutSeconds"] = config.TimeoutSeconds
        };

        try
        {
            // Use Skill 07 AI Dispatcher for parallel execution
            var results = await _dispatcher.DispatchParallelAsync(
                modelIds, prompt, options, ct);
            return results;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Parallel dispatch failed, attempting sequential fallback");
            return await DispatchSequentialFallbackAsync(modelIds, prompt, options, ct);
        }
    }

    private async Task<IReadOnlyList<Dictionary<string, object>>> DispatchSequentialFallbackAsync(
        List<string> modelIds, string prompt,
        Dictionary<string, object> options, CancellationToken ct)
    {
        var results = new List<Dictionary<string, object>>();

        foreach (var modelId in modelIds)
        {
            try
            {
                var result = await _dispatcher.DispatchAsync(modelId, prompt, options, ct);
                results.Add(result);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Sequential dispatch to {Model} failed", modelId);
                results.Add(new Dictionary<string, object>
                {
                    ["modelId"] = modelId,
                    ["success"] = false,
                    ["error"] = ex.Message
                });
            }
        }

        return results;
    }

    // -----------------------------------------------------------------------
    // Response Parsing (FigmaCodeGenerator pattern — labeled sections → fallback)
    // -----------------------------------------------------------------------
    private ModelResponse ParseModelResponse(Dictionary<string, object> raw)
    {
        var modelId = GetDynamic(raw, "modelId", "unknown");
        var success = GetDynamicBool(raw, "success", false);
        var rawText = GetDynamic(raw, "response", GetDynamic(raw, "text", ""));
        var latency = GetDynamicLong(raw, "latencyMs", 0);
        var tokens = GetDynamicInt(raw, "tokensUsed", 0);

        if (!success || string.IsNullOrWhiteSpace(rawText))
        {
            return new ModelResponse
            {
                ModelId = modelId,
                Success = false,
                RawResponse = rawText,
                Error = GetDynamic(raw, "error", "No response"),
                LatencyMs = latency
            };
        }

        // Priority 1: Labeled sections
        var clientMatch = ClientCodeRegex.Match(rawText);
        var serverMatch = ServerCodeRegex.Match(rawText);
        var dbMatch = DatabaseCodeRegex.Match(rawText);

        string? clientCode = clientMatch.Success ? clientMatch.Groups[1].Value.Trim() : null;
        string? serverCode = serverMatch.Success ? serverMatch.Groups[1].Value.Trim() : null;
        string? dbCode = dbMatch.Success ? dbMatch.Groups[1].Value.Trim() : null;

        // Priority 2: Sequential fallback (if no labeled sections found)
        if (clientCode is null && serverCode is null && dbCode is null)
        {
            var codeBlocks = CodeBlockRegex.Matches(rawText)
                .Select(m => m.Groups[1].Value.Trim())
                .ToList();

            if (codeBlocks.Count >= 1) clientCode = codeBlocks[0];
            if (codeBlocks.Count >= 2) serverCode = codeBlocks[1];
            if (codeBlocks.Count >= 3) dbCode = codeBlocks[2];
        }

        // Priority 3: Raw fallback
        clientCode ??= rawText;

        // Score based on completeness
        var score = CalculateResponseScore(clientCode, serverCode, dbCode);

        return new ModelResponse
        {
            ModelId = modelId,
            Provider = GetDynamic(raw, "provider", ""),
            Success = true,
            RawResponse = rawText,
            ClientCode = clientCode,
            ServerCode = serverCode,
            DatabaseCode = dbCode,
            Score = score,
            LatencyMs = latency,
            TokensUsed = tokens
        };
    }

    private static double CalculateResponseScore(
        string? client, string? server, string? db)
    {
        double score = 0;
        if (!string.IsNullOrWhiteSpace(client))
        {
            score += 0.4;
            if (client.Contains("TypeScript") || client.Contains("interface ") ||
                client.Contains(": string") || client.Contains(": number"))
                score += 0.05; // Has types
            if (client.Contains("aria-") || client.Contains("role="))
                score += 0.05; // Accessibility
        }
        if (!string.IsNullOrWhiteSpace(server))
        {
            score += 0.3;
            if (server.Contains("try") || server.Contains("catch") ||
                server.Contains("except"))
                score += 0.05; // Error handling
        }
        if (!string.IsNullOrWhiteSpace(db))
        {
            score += 0.2;
        }
        return Math.Min(score, 1.0);
    }

    // -----------------------------------------------------------------------
    // Result Merging
    // -----------------------------------------------------------------------
    public Task<DataProcessResult<MergedResult>> MergeResultsAsync(
        IReadOnlyList<ModelResponse> responses, string mergeStrategy,
        CancellationToken ct = default)
    {
        var successful = responses.Where(r => r.Success).ToList();

        if (successful.Count == 0)
        {
            var errors = string.Join("; ",
                responses.Select(r => $"{r.ModelId}: {r.Error}"));
            return Task.FromResult(
                DataProcessResult<MergedResult>.Failure(
                    $"All models failed: {errors}"));
        }

        var merged = mergeStrategy switch
        {
            "section-best" => MergeSectionBest(successful),
            "consensus" => MergeConsensus(successful),
            _ => MergeBestScore(successful) // default: best-score
        };

        return Task.FromResult(DataProcessResult<MergedResult>.Ok(merged));
    }

    private static MergedResult MergeBestScore(List<ModelResponse> responses)
    {
        var best = responses.OrderByDescending(r => r.Score).First();
        return new MergedResult
        {
            ClientCode = best.ClientCode,
            ServerCode = best.ServerCode,
            DatabaseCode = best.DatabaseCode,
            Score = best.Score,
            StrategyUsed = $"best-score (from {best.ModelId})"
        };
    }

    private static MergedResult MergeSectionBest(List<ModelResponse> responses)
    {
        var bestClient = responses
            .Where(r => !string.IsNullOrWhiteSpace(r.ClientCode))
            .OrderByDescending(r => r.Score)
            .FirstOrDefault();
        var bestServer = responses
            .Where(r => !string.IsNullOrWhiteSpace(r.ServerCode))
            .OrderByDescending(r => r.Score)
            .FirstOrDefault();
        var bestDb = responses
            .Where(r => !string.IsNullOrWhiteSpace(r.DatabaseCode))
            .OrderByDescending(r => r.Score)
            .FirstOrDefault();

        var sources = new List<string>();
        if (bestClient is not null) sources.Add($"client:{bestClient.ModelId}");
        if (bestServer is not null) sources.Add($"server:{bestServer.ModelId}");
        if (bestDb is not null) sources.Add($"db:{bestDb.ModelId}");

        return new MergedResult
        {
            ClientCode = bestClient?.ClientCode,
            ServerCode = bestServer?.ServerCode,
            DatabaseCode = bestDb?.DatabaseCode,
            Score = (bestClient?.Score ?? 0 + bestServer?.Score ?? 0 + bestDb?.Score ?? 0) / 3.0,
            StrategyUsed = $"section-best ({string.Join(", ", sources)})"
        };
    }

    private static MergedResult MergeConsensus(List<ModelResponse> responses)
    {
        // For consensus, pick sections that appear in 2+ responses
        // Simple heuristic: use best-score if only 1-2 models, consensus if 3+
        if (responses.Count < 3) return MergeBestScore(responses);

        // Use the response with the highest score as base,
        // but only include sections present in majority of responses
        var best = responses.OrderByDescending(r => r.Score).First();
        var clientCount = responses.Count(r => !string.IsNullOrWhiteSpace(r.ClientCode));
        var serverCount = responses.Count(r => !string.IsNullOrWhiteSpace(r.ServerCode));
        var dbCount = responses.Count(r => !string.IsNullOrWhiteSpace(r.DatabaseCode));
        var threshold = responses.Count / 2.0;

        return new MergedResult
        {
            ClientCode = clientCount >= threshold ? best.ClientCode : null,
            ServerCode = serverCount >= threshold ? best.ServerCode : null,
            DatabaseCode = dbCount >= threshold ? best.DatabaseCode : null,
            Score = best.Score * 0.9, // slight penalty for consensus filtering
            StrategyUsed = $"consensus (threshold: {threshold:F0}/{responses.Count})"
        };
    }

    // -----------------------------------------------------------------------
    // Feedback Loading (Skill 13 integration)
    // -----------------------------------------------------------------------
    private async Task<IReadOnlyList<Dictionary<string, object>>> LoadFeedbackAsync(
        IReadOnlyList<Dictionary<string, object>> components,
        TransformConfig config, CancellationToken ct)
    {
        try
        {
            // Build filter using Genie DNA-2 (BuildSearchFilter — empty fields skipped)
            var componentTypes = components
                .Select(c => GetDynamic(c, "type", ""))
                .Where(t => !string.IsNullOrEmpty(t))
                .Distinct()
                .ToList();

            var filter = _objectProcessor.BuildSearchFilter(new
            {
                componentTypes = componentTypes.Count > 0 ? componentTypes : null,
                targetClient = config.TargetStack.Client,
                targetServer = config.TargetStack.Server,
                rating = new[] { "positive", "negative" } // skip neutral for prompt injection
            });

            return await _feedback.GetFeedbackHistoryAsync(
                filter, config.FeedbackLookback, ct);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to load feedback history, continuing without");
            return Array.Empty<Dictionary<string, object>>();
        }
    }

    // -----------------------------------------------------------------------
    // Debug Snapshot (Skill 14 integration)
    // -----------------------------------------------------------------------
    private async Task StoreDebugSnapshot(
        FlowStepContext context, TransformOutput output, CancellationToken ct)
    {
        try
        {
            // Store as dynamic document (Genie DNA-1)
            var snapshot = _objectProcessor.ParseObjectAlternative(new
            {
                type = "ai-transform",
                traceId = context.TraceId,
                nodeId = context.NodeId,
                transformId = output.TransformId,
                promptUsed = output.PromptUsed,
                mergeStrategy = output.MergeStrategy,
                mergedScore = output.MergedScore,
                feedbackItemsInjected = output.FeedbackItemsInjected,
                modelCount = output.ModelResults.Count,
                successfulModels = output.ModelResults.Count(r => r.Success),
                modelSummaries = output.ModelResults.Select(r => new
                {
                    r.ModelId, r.Success, r.Score, r.LatencyMs, r.TokensUsed, r.Error
                }),
                timestamp = DateTime.UtcNow
            });

            await _debugger.StoreSnapshotAsync(context.TraceId, context.NodeId, snapshot, ct);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to store debug snapshot for {TraceId}", context.TraceId);
        }
    }

    // -----------------------------------------------------------------------
    // Config Extraction (dynamic document → typed config)
    // -----------------------------------------------------------------------
    private TransformConfig ExtractConfig(Dictionary<string, object> nodeConfig)
    {
        return new TransformConfig
        {
            Models = GetDynamicList(nodeConfig, "models", ["claude-sonnet", "gpt-4o"]),
            MergeStrategy = GetDynamic(nodeConfig, "mergeStrategy", "best-score"),
            MaxTokens = GetDynamicInt(nodeConfig, "maxTokens", 4096),
            Temperature = GetDynamicDouble(nodeConfig, "temperature", 0.3),
            FeedbackLookback = GetDynamicInt(nodeConfig, "feedbackLookback", 10),
            RetryOnFailure = GetDynamicBool(nodeConfig, "retryOnFailure", true),
            TimeoutSeconds = GetDynamicInt(nodeConfig, "timeoutSeconds", 120),
            TargetStack = new TargetStackConfig
            {
                Client = GetDynamic(nodeConfig, "targetClient",
                    GetDynamic(nodeConfig, "client", "react")),
                Server = GetDynamic(nodeConfig, "targetServer",
                    GetDynamic(nodeConfig, "server", "dotnet")),
                Database = GetDynamic(nodeConfig, "targetDatabase",
                    GetDynamic(nodeConfig, "database", "elasticsearch"))
            }
        };
    }

    private static IReadOnlyList<Dictionary<string, object>> ExtractComponents(
        Dictionary<string, object> input)
    {
        if (input.TryGetValue("components", out var comps) && comps is IEnumerable<object> list)
        {
            return list
                .OfType<Dictionary<string, object>>()
                .ToList();
        }
        // Wrap single input as a component
        return [input];
    }

    // -----------------------------------------------------------------------
    // Dynamic field helpers (Genie DNA — no fixed schema)
    // -----------------------------------------------------------------------
    private static string GetDynamic(Dictionary<string, object> doc, string key, string fallback)
        => doc.TryGetValue(key, out var v) && v is string s ? s : fallback;

    private static bool GetDynamicBool(Dictionary<string, object> doc, string key, bool fallback)
        => doc.TryGetValue(key, out var v) ? Convert.ToBoolean(v) : fallback;

    private static int GetDynamicInt(Dictionary<string, object> doc, string key, int fallback)
        => doc.TryGetValue(key, out var v) ? Convert.ToInt32(v) : fallback;

    private static long GetDynamicLong(Dictionary<string, object> doc, string key, long fallback)
        => doc.TryGetValue(key, out var v) ? Convert.ToInt64(v) : fallback;

    private static double GetDynamicDouble(Dictionary<string, object> doc, string key, double fallback)
        => doc.TryGetValue(key, out var v) ? Convert.ToDouble(v) : fallback;

    private static List<string> GetDynamicList(
        Dictionary<string, object> doc, string key, List<string> fallback)
    {
        if (doc.TryGetValue(key, out var v) && v is IEnumerable<object> list)
            return list.Select(x => x?.ToString() ?? "").ToList();
        return fallback;
    }
}

// ---------------------------------------------------------------------------
// DI Registration
// ---------------------------------------------------------------------------
public static class AiTransformServiceExtensions
{
    public static IServiceCollection AddXIIGenAiTransform(this IServiceCollection services)
    {
        services.AddSingleton<IAiTransformService, AiTransformService>();
        return services;
    }
}
