/*
 * Skill 11 — AI Transform Service (Java 21+)
 * Multi-model parallel AI code generation with feedback injection
 * Genie DNA: Dynamic documents, BuildSearchFilter, DataProcessResult
 */
package com.xiigen.services.aitransform;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;
import java.util.stream.*;
import org.slf4j.*;

// ---------------------------------------------------------------------------
// Interfaces (Skills 02, 06, 07, 13, 14)
// ---------------------------------------------------------------------------
interface IAiDispatcher {
    Map<String, Object> dispatch(String modelId, String prompt, Map<String, Object> options) throws Exception;
    List<Map<String, Object>> dispatchParallel(List<String> modelIds, String prompt, Map<String, Object> options) throws Exception;
}

interface IFeedbackService {
    List<Map<String, Object>> getFeedbackHistory(Map<String, Object> filter, int limit) throws Exception;
}

interface INodeDebugger {
    void storeSnapshot(String traceId, String nodeId, Map<String, Object> snapshot) throws Exception;
}

interface IObjectProcessor {
    Map<String, Object> parseObjectAlternative(Object input);
    Map<String, Object> buildSearchFilter(Object filter);
    Map<String, Object> mergeObjects(Map<String, Object> a, Map<String, Object> b);
}

// ---------------------------------------------------------------------------
// Records
// ---------------------------------------------------------------------------
record TransformConfig(
    List<String> models, String mergeStrategy, int maxTokens, double temperature,
    int feedbackLookback, boolean retryOnFailure, int timeoutSeconds,
    String targetClient, String targetServer, String targetDatabase
) {
    static TransformConfig defaults() {
        return new TransformConfig(List.of("claude-sonnet", "gpt-4o"), "best-score",
            4096, 0.3, 10, true, 120, "react", "java", "elasticsearch");
    }
}

record ModelResponse(
    String modelId, String provider, boolean success, String rawResponse,
    String clientCode, String serverCode, String databaseCode,
    double score, String error, long latencyMs, int tokensUsed
) {}

record TransformOutput(
    String transformId, String clientCode, String serverCode, String databaseCode,
    double mergedScore, String mergeStrategy, List<ModelResponse> modelResults,
    String promptUsed, int feedbackItemsInjected, Instant completedAt
) {}

record FlowStepContext(
    String traceId, String flowId, String nodeId,
    Map<String, Object> input, Map<String, Object> nodeConfig,
    Map<String, Object> flowVariables
) {}

record DataProcessResult<T>(boolean isSuccess, T data, String error, Map<String, Object> metadata) {
    static <T> DataProcessResult<T> ok(T data) { return new DataProcessResult<>(true, data, null, null); }
    static <T> DataProcessResult<T> failure(String error) { return new DataProcessResult<>(false, null, error, null); }
}

// ---------------------------------------------------------------------------
// Service Implementation
// ---------------------------------------------------------------------------
public class AiTransformService {
    private static final Logger log = LoggerFactory.getLogger(AiTransformService.class);

    // Response parsing regex (FigmaCodeGenerator pattern)
    private static final Pattern CLIENT_RE = Pattern.compile(
        "//\\s*===\\s*CLIENT\\s*CODE\\s*===[\\s\\S]*?```\\w*\\n([\\s\\S]*?)```", Pattern.CASE_INSENSITIVE);
    private static final Pattern SERVER_RE = Pattern.compile(
        "//\\s*===\\s*SERVER\\s*CODE\\s*===[\\s\\S]*?```\\w*\\n([\\s\\S]*?)```", Pattern.CASE_INSENSITIVE);
    private static final Pattern DB_RE = Pattern.compile(
        "//\\s*===\\s*DATABASE\\s*CODE\\s*===[\\s\\S]*?```\\w*\\n([\\s\\S]*?)```", Pattern.CASE_INSENSITIVE);
    private static final Pattern CODE_BLOCK_RE = Pattern.compile("```\\w*\\n([\\s\\S]*?)```");

    private final IAiDispatcher dispatcher;
    private final IFeedbackService feedback;
    private final INodeDebugger debugger;
    private final IObjectProcessor objectProcessor;

    public AiTransformService(IAiDispatcher dispatcher, IFeedbackService feedback,
                              INodeDebugger debugger, IObjectProcessor objectProcessor) {
        this.dispatcher = dispatcher;
        this.feedback = feedback;
        this.debugger = debugger;
        this.objectProcessor = objectProcessor;
    }

    /** Execute — called by Flow Orchestrator (Skill 09). */
    public DataProcessResult<TransformOutput> execute(FlowStepContext context) {
        try {
            var config = extractConfig(context.nodeConfig());
            var components = extractComponents(context.input());
            var result = transformComponents(components, config);

            if (result.isSuccess() && result.data() != null) {
                try { storeDebugSnapshot(context, result.data()); }
                catch (Exception e) { log.warn("Debug snapshot failed: {}", e.getMessage()); }
            }
            return result;
        } catch (Exception e) {
            log.error("Transform failed for trace {}", context.traceId(), e);
            return DataProcessResult.failure("Transform failed: " + e.getMessage());
        }
    }

    /** Core pipeline: feedback → prompt → dispatch → parse → merge. */
    public DataProcessResult<TransformOutput> transformComponents(
            List<Map<String, Object>> components, TransformConfig config) {
        var feedbackHistory = loadFeedback(components, config);
        var prompt = assemblePrompt(components, config, feedbackHistory);
        var rawResponses = dispatchToModels(config.models(), prompt, config);
        var parsed = rawResponses.stream().map(this::parseModelResponse).toList();
        var mergeResult = mergeResults(parsed, config.mergeStrategy());

        if (!mergeResult.isSuccess()) return DataProcessResult.failure(mergeResult.error());

        @SuppressWarnings("unchecked")
        var merged = (Map<String, Object>) mergeResult.data();
        var output = new TransformOutput(
            UUID.randomUUID().toString().replace("-", ""),
            (String) merged.get("clientCode"), (String) merged.get("serverCode"),
            (String) merged.get("databaseCode"),
            ((Number) merged.getOrDefault("score", 0.0)).doubleValue(),
            config.mergeStrategy(), parsed, prompt,
            feedbackHistory.size(), Instant.now()
        );
        return DataProcessResult.ok(output);
    }

    // -----------------------------------------------------------------------
    // Prompt Assembly (4-layer pattern)
    // -----------------------------------------------------------------------
    public String assemblePrompt(List<Map<String, Object>> components,
                                  TransformConfig config, List<Map<String, Object>> feedbackHistory) {
        var sections = new ArrayList<String>();
        sections.add(buildSystemContext());
        sections.add(buildDesignData(components));
        if (!feedbackHistory.isEmpty()) sections.add(buildFeedbackSection(feedbackHistory));
        sections.add(buildTargetInstructions(config));
        return String.join("\n\n", sections);
    }

    private String buildSystemContext() {
        return """
            You are a senior full-stack developer converting Figma design components into production-ready code.
            Label each section: // === CLIENT CODE ===, // === SERVER CODE ===, // === DATABASE CODE ===
            Include types, error handling, and accessibility attributes.""";
    }

    private String buildDesignData(List<Map<String, Object>> components) {
        var sb = new StringBuilder("## Design Components\n\n");
        for (int i = 0; i < components.size(); i++) {
            var comp = components.get(i);
            sb.append("### Component %d: %s (type: %s)\n".formatted(
                i + 1, comp.getOrDefault("name", "component_" + i), comp.getOrDefault("type", "unknown")));
            var html = Objects.toString(comp.get("html"), "");
            var css = Objects.toString(comp.get("css"), "");
            if (!html.isBlank()) sb.append("```html\n").append(html).append("\n```\n");
            if (!css.isBlank()) sb.append("```css\n").append(css).append("\n```\n");
            sb.append("\n");
        }
        return sb.toString();
    }

    private String buildFeedbackSection(List<Map<String, Object>> history) {
        var sb = new StringBuilder("## Previous Feedback\n\n");
        var positive = history.stream().filter(f -> "positive".equals(f.get("rating"))).toList();
        var negative = history.stream().filter(f -> "negative".equals(f.get("rating"))).toList();
        if (!positive.isEmpty()) {
            sb.append("### ✅ What worked well:\n");
            positive.forEach(f -> sb.append("- \"%s\" (positive)\n".formatted(f.getOrDefault("text", "No details"))));
            sb.append("\n");
        }
        if (!negative.isEmpty()) {
            sb.append("### ❌ What to avoid:\n");
            negative.forEach(f -> sb.append("- \"%s\" (negative)\n".formatted(f.getOrDefault("text", "No details"))));
            sb.append("\n");
        }
        sb.append("Please apply these learnings.");
        return sb.toString();
    }

    private String buildTargetInstructions(TransformConfig config) {
        return """
            ## Generation Targets
            ### Client-Side (%s) — Semantic HTML, responsive, accessible, typed.
            ### Server-Side (%s) — API endpoints, validation, error handling, DI.
            ### Database (%s) — Entities, constraints, indexes, migrations.
            """.formatted(config.targetClient(), config.targetServer(), config.targetDatabase());
    }

    // -----------------------------------------------------------------------
    // Dispatch + Parse + Merge (same patterns as .NET/Node/Python)
    // -----------------------------------------------------------------------
    private List<Map<String, Object>> dispatchToModels(List<String> modelIds, String prompt, TransformConfig config) {
        var options = Map.<String, Object>of(
            "maxTokens", config.maxTokens(), "temperature", config.temperature(),
            "timeoutSeconds", config.timeoutSeconds());
        try {
            return dispatcher.dispatchParallel(modelIds, prompt, options);
        } catch (Exception e) {
            log.warn("Parallel dispatch failed, using sequential: {}", e.getMessage());
            var results = new ArrayList<Map<String, Object>>();
            for (var id : modelIds) {
                try { results.add(dispatcher.dispatch(id, prompt, options)); }
                catch (Exception ex) { results.add(Map.of("modelId", id, "success", false, "error", ex.getMessage())); }
            }
            return results;
        }
    }

    private ModelResponse parseModelResponse(Map<String, Object> raw) {
        var modelId = Objects.toString(raw.get("modelId"), "unknown");
        var success = Boolean.TRUE.equals(raw.get("success"));
        var rawText = Objects.toString(raw.getOrDefault("response", raw.get("text")), "");
        var latency = raw.containsKey("latencyMs") ? ((Number) raw.get("latencyMs")).longValue() : 0L;
        var tokens = raw.containsKey("tokensUsed") ? ((Number) raw.get("tokensUsed")).intValue() : 0;

        if (!success || rawText.isBlank())
            return new ModelResponse(modelId, "", false, rawText, null, null, null, 0, Objects.toString(raw.get("error"), "No response"), latency, tokens);

        var cm = CLIENT_RE.matcher(rawText); String client = cm.find() ? cm.group(1).strip() : null;
        var sm = SERVER_RE.matcher(rawText); String server = sm.find() ? sm.group(1).strip() : null;
        var dm = DB_RE.matcher(rawText); String db = dm.find() ? dm.group(1).strip() : null;

        if (client == null && server == null && db == null) {
            var blocks = new ArrayList<String>();
            var bm = CODE_BLOCK_RE.matcher(rawText);
            while (bm.find()) blocks.add(bm.group(1).strip());
            if (blocks.size() >= 1) client = blocks.get(0);
            if (blocks.size() >= 2) server = blocks.get(1);
            if (blocks.size() >= 3) db = blocks.get(2);
        }
        if (client == null) client = rawText;

        double score = calculateScore(client, server, db);
        return new ModelResponse(modelId, Objects.toString(raw.get("provider"), ""), true, rawText, client, server, db, score, null, latency, tokens);
    }

    private double calculateScore(String client, String server, String db) {
        double s = 0;
        if (client != null && !client.isBlank()) { s += 0.4; if (client.contains("interface ") || client.contains(": String")) s += 0.05; }
        if (server != null && !server.isBlank()) { s += 0.3; if (server.contains("try") || server.contains("catch")) s += 0.05; }
        if (db != null && !db.isBlank()) s += 0.2;
        return Math.min(s, 1.0);
    }

    @SuppressWarnings("unchecked")
    public DataProcessResult<Object> mergeResults(List<ModelResponse> responses, String strategy) {
        var ok = responses.stream().filter(ModelResponse::success).sorted(Comparator.comparingDouble(ModelResponse::score).reversed()).toList();
        if (ok.isEmpty())
            return DataProcessResult.failure("All models failed: " + responses.stream().map(r -> r.modelId() + ": " + r.error()).collect(Collectors.joining("; ")));

        if ("section-best".equals(strategy)) {
            var bc = ok.stream().filter(r -> r.clientCode() != null).findFirst().orElse(null);
            var bs = ok.stream().filter(r -> r.serverCode() != null).findFirst().orElse(null);
            var bd = ok.stream().filter(r -> r.databaseCode() != null).findFirst().orElse(null);
            return DataProcessResult.ok(Map.of(
                "clientCode", bc != null ? bc.clientCode() : "", "serverCode", bs != null ? bs.serverCode() : "",
                "databaseCode", bd != null ? bd.databaseCode() : "",
                "score", ((bc != null ? bc.score() : 0) + (bs != null ? bs.score() : 0) + (bd != null ? bd.score() : 0)) / 3.0));
        }

        var best = ok.get(0);
        return DataProcessResult.ok(Map.of(
            "clientCode", Objects.toString(best.clientCode(), ""), "serverCode", Objects.toString(best.serverCode(), ""),
            "databaseCode", Objects.toString(best.databaseCode(), ""), "score", best.score()));
    }

    // -----------------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------------
    private List<Map<String, Object>> loadFeedback(List<Map<String, Object>> components, TransformConfig config) {
        try {
            var types = components.stream().map(c -> Objects.toString(c.get("type"), "")).filter(t -> !t.isBlank()).distinct().toList();
            var filter = objectProcessor.buildSearchFilter(Map.of(
                "componentTypes", types.isEmpty() ? "" : types, "targetClient", config.targetClient(),
                "rating", List.of("positive", "negative")));
            return feedback.getFeedbackHistory(filter, config.feedbackLookback());
        } catch (Exception e) { log.warn("Feedback load failed: {}", e.getMessage()); return List.of(); }
    }

    private void storeDebugSnapshot(FlowStepContext ctx, TransformOutput output) throws Exception {
        var snapshot = objectProcessor.parseObjectAlternative(Map.of(
            "type", "ai-transform", "traceId", ctx.traceId(), "nodeId", ctx.nodeId(),
            "transformId", output.transformId(), "mergedScore", output.mergedScore(),
            "modelCount", output.modelResults().size(), "timestamp", Instant.now().toString()));
        debugger.storeSnapshot(ctx.traceId(), ctx.nodeId(), snapshot);
    }

    private TransformConfig extractConfig(Map<String, Object> nc) {
        return new TransformConfig(
            nc.containsKey("models") ? ((List<?>) nc.get("models")).stream().map(Object::toString).toList() : List.of("claude-sonnet", "gpt-4o"),
            Objects.toString(nc.getOrDefault("mergeStrategy", "best-score"), "best-score"),
            nc.containsKey("maxTokens") ? ((Number) nc.get("maxTokens")).intValue() : 4096,
            nc.containsKey("temperature") ? ((Number) nc.get("temperature")).doubleValue() : 0.3,
            nc.containsKey("feedbackLookback") ? ((Number) nc.get("feedbackLookback")).intValue() : 10,
            Boolean.TRUE.equals(nc.getOrDefault("retryOnFailure", true)),
            nc.containsKey("timeoutSeconds") ? ((Number) nc.get("timeoutSeconds")).intValue() : 120,
            Objects.toString(nc.getOrDefault("targetClient", nc.getOrDefault("client", "react")), "react"),
            Objects.toString(nc.getOrDefault("targetServer", nc.getOrDefault("server", "java")), "java"),
            Objects.toString(nc.getOrDefault("targetDatabase", nc.getOrDefault("database", "elasticsearch")), "elasticsearch"));
    }

    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> extractComponents(Map<String, Object> input) {
        if (input.containsKey("components") && input.get("components") instanceof List<?> list)
            return (List<Map<String, Object>>) list;
        return List.of(input);
    }
}
