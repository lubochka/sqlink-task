<?php
/**
 * Skill 11 — AI Transform Service (PHP 8.3+)
 * Multi-model parallel AI code generation with feedback injection
 * Genie DNA: Dynamic documents (arrays), DataProcessResult
 */

namespace XIIGen\Services\AiTransform;

// ---------------------------------------------------------------------------
// Interfaces (Skills 02, 06, 07, 13, 14)
// ---------------------------------------------------------------------------
interface AiDispatcherInterface {
    public function dispatch(string $modelId, string $prompt, array $options = []): array;
    public function dispatchParallel(array $modelIds, string $prompt, array $options = []): array;
}

interface FeedbackServiceInterface {
    public function getFeedbackHistory(array $filter, int $limit = 10): array;
}

interface NodeDebuggerInterface {
    public function storeSnapshot(string $traceId, string $nodeId, array $snapshot): void;
}

interface ObjectProcessorInterface {
    public function parseObjectAlternative(mixed $input): array;
    public function buildSearchFilter(mixed $filter): array;
    public function mergeObjects(array $a, array $b): array;
}

// ---------------------------------------------------------------------------
// DataProcessResult (Genie DNA-3)
// ---------------------------------------------------------------------------
readonly class DataProcessResult {
    public function __construct(
        public bool $isSuccess,
        public mixed $data = null,
        public ?string $error = null,
        public ?array $metadata = null,
    ) {}

    public static function ok(mixed $data, ?array $meta = null): self {
        return new self(true, $data, metadata: $meta);
    }

    public static function failure(string $error, ?array $meta = null): self {
        return new self(false, error: $error, metadata: $meta);
    }
}

// ---------------------------------------------------------------------------
// Config
// ---------------------------------------------------------------------------
readonly class TransformConfig {
    public function __construct(
        public array $models = ['claude-sonnet', 'gpt-4o'],
        public string $mergeStrategy = 'best-score',
        public int $maxTokens = 4096,
        public float $temperature = 0.3,
        public int $feedbackLookback = 10,
        public int $timeoutSeconds = 120,
        public string $targetClient = 'react',
        public string $targetServer = 'php',
        public string $targetDatabase = 'elasticsearch',
    ) {}

    public static function fromArray(array $nc): self {
        return new self(
            models: $nc['models'] ?? ['claude-sonnet', 'gpt-4o'],
            mergeStrategy: $nc['mergeStrategy'] ?? 'best-score',
            maxTokens: (int)($nc['maxTokens'] ?? 4096),
            temperature: (float)($nc['temperature'] ?? 0.3),
            feedbackLookback: (int)($nc['feedbackLookback'] ?? 10),
            timeoutSeconds: (int)($nc['timeoutSeconds'] ?? 120),
            targetClient: $nc['targetClient'] ?? $nc['client'] ?? 'react',
            targetServer: $nc['targetServer'] ?? $nc['server'] ?? 'php',
            targetDatabase: $nc['targetDatabase'] ?? $nc['database'] ?? 'elasticsearch',
        );
    }
}

// ---------------------------------------------------------------------------
// AI Transform Service
// ---------------------------------------------------------------------------
class AiTransformService {
    // FigmaCodeGenerator response parsing patterns
    private const CLIENT_RE = '/\/\/\s*===\s*CLIENT\s*CODE\s*===[\s\S]*?```\w*\n([\s\S]*?)```/i';
    private const SERVER_RE = '/\/\/\s*===\s*SERVER\s*CODE\s*===[\s\S]*?```\w*\n([\s\S]*?)```/i';
    private const DB_RE = '/\/\/\s*===\s*DATABASE\s*CODE\s*===[\s\S]*?```\w*\n([\s\S]*?)```/i';
    private const CODE_BLOCK_RE = '/```\w*\n([\s\S]*?)```/';

    public function __construct(
        private readonly AiDispatcherInterface $dispatcher,
        private readonly FeedbackServiceInterface $feedback,
        private readonly NodeDebuggerInterface $debugger,
        private readonly ObjectProcessorInterface $objectProcessor,
    ) {}

    /** Execute — called by Flow Orchestrator (Skill 09). */
    public function execute(array $context): DataProcessResult {
        try {
            $config = TransformConfig::fromArray($context['nodeConfig'] ?? []);
            $components = $this->extractComponents($context['input'] ?? []);
            $result = $this->transformComponents($components, $config);

            if ($result->isSuccess && $result->data) {
                try {
                    $this->storeDebugSnapshot($context, $result->data);
                } catch (\Throwable $e) {
                    error_log("Debug snapshot failed: " . $e->getMessage());
                }
            }
            return $result;
        } catch (\Throwable $e) {
            return DataProcessResult::failure("Transform failed: " . $e->getMessage());
        }
    }

    /** Core pipeline: feedback → prompt → dispatch → parse → merge. */
    public function transformComponents(array $components, TransformConfig $config): DataProcessResult {
        // Step 1: Feedback
        $feedbackHistory = $this->loadFeedback($components, $config);

        // Step 2: Prompt
        $prompt = $this->assemblePrompt($components, $config, $feedbackHistory);

        // Step 3: Dispatch
        $rawResponses = $this->dispatchToModels($config->models, $prompt, $config);

        // Step 4: Parse
        $parsed = array_map(fn($r) => $this->parseModelResponse($r), $rawResponses);

        // Step 5: Merge
        $mergeResult = $this->mergeResults($parsed, $config->mergeStrategy);
        if (!$mergeResult->isSuccess) {
            return DataProcessResult::failure($mergeResult->error ?? 'Merge failed');
        }

        // Step 6: Output
        $merged = $mergeResult->data;
        return DataProcessResult::ok([
            'transformId' => bin2hex(random_bytes(16)),
            'clientCode' => $merged['clientCode'] ?? null,
            'serverCode' => $merged['serverCode'] ?? null,
            'databaseCode' => $merged['databaseCode'] ?? null,
            'mergedScore' => $merged['score'] ?? 0.0,
            'mergeStrategy' => $config->mergeStrategy,
            'modelResults' => $parsed,
            'promptUsed' => $prompt,
            'feedbackItemsInjected' => count($feedbackHistory),
            'completedAt' => (new \DateTimeImmutable())->format(\DateTimeInterface::ATOM),
        ]);
    }

    // -----------------------------------------------------------------------
    // Prompt Assembly (4-layer pattern)
    // -----------------------------------------------------------------------
    public function assemblePrompt(array $components, TransformConfig $config, array $feedback): string {
        $sections = [
            $this->buildSystemContext(),
            $this->buildDesignData($components),
        ];
        if (!empty($feedback)) $sections[] = $this->buildFeedbackSection($feedback);
        $sections[] = $this->buildTargetInstructions($config);
        return implode("\n\n", $sections);
    }

    private function buildSystemContext(): string {
        return "You are a senior full-stack developer converting Figma design components into production-ready code.\n" .
            "Label sections: // === CLIENT CODE ===, // === SERVER CODE ===, // === DATABASE CODE ===\n" .
            "Include types, error handling, accessibility.";
    }

    private function buildDesignData(array $components): string {
        $out = "## Design Components\n\n";
        foreach ($components as $i => $comp) {
            $name = $comp['name'] ?? "component_$i";
            $type = $comp['type'] ?? 'unknown';
            $out .= "### Component " . ($i + 1) . ": $name (type: $type)\n";
            if (!empty($comp['html'])) $out .= "```html\n{$comp['html']}\n```\n";
            if (!empty($comp['css'])) $out .= "```css\n{$comp['css']}\n```\n";
            $out .= "\n";
        }
        return $out;
    }

    private function buildFeedbackSection(array $history): string {
        $out = "## Previous Feedback\n\n";
        $positive = array_filter($history, fn($f) => ($f['rating'] ?? '') === 'positive');
        $negative = array_filter($history, fn($f) => ($f['rating'] ?? '') === 'negative');
        if ($positive) {
            $out .= "### ✅ What worked well:\n";
            foreach ($positive as $f) $out .= '- "' . ($f['text'] ?? 'No details') . "\" (positive)\n";
        }
        if ($negative) {
            $out .= "### ❌ What to avoid:\n";
            foreach ($negative as $f) $out .= '- "' . ($f['text'] ?? 'No details') . "\" (negative)\n";
        }
        $out .= "Please apply these learnings.";
        return $out;
    }

    private function buildTargetInstructions(TransformConfig $config): string {
        return "## Generation Targets\n\n" .
            "### Client-Side ({$config->targetClient}) — Semantic HTML, responsive, accessible.\n" .
            "### Server-Side ({$config->targetServer}) — API endpoints, validation, error handling.\n" .
            "### Database ({$config->targetDatabase}) — Entities, constraints, indexes.";
    }

    // -----------------------------------------------------------------------
    // Dispatch + Parse + Merge
    // -----------------------------------------------------------------------
    private function dispatchToModels(array $modelIds, string $prompt, TransformConfig $config): array {
        $options = ['maxTokens' => $config->maxTokens, 'temperature' => $config->temperature];
        try {
            return $this->dispatcher->dispatchParallel($modelIds, $prompt, $options);
        } catch (\Throwable) {
            $results = [];
            foreach ($modelIds as $id) {
                try { $results[] = $this->dispatcher->dispatch($id, $prompt, $options); }
                catch (\Throwable $e) { $results[] = ['modelId' => $id, 'success' => false, 'error' => $e->getMessage()]; }
            }
            return $results;
        }
    }

    private function parseModelResponse(array $raw): array {
        $modelId = $raw['modelId'] ?? 'unknown';
        $success = (bool)($raw['success'] ?? false);
        $rawText = (string)($raw['response'] ?? $raw['text'] ?? '');

        if (!$success || empty($rawText)) {
            return ['modelId' => $modelId, 'success' => false, 'rawResponse' => $rawText,
                'score' => 0, 'error' => $raw['error'] ?? 'No response', 'latencyMs' => $raw['latencyMs'] ?? 0];
        }

        preg_match(self::CLIENT_RE, $rawText, $cm);
        preg_match(self::SERVER_RE, $rawText, $sm);
        preg_match(self::DB_RE, $rawText, $dm);
        $client = isset($cm[1]) ? trim($cm[1]) : null;
        $server = isset($sm[1]) ? trim($sm[1]) : null;
        $db = isset($dm[1]) ? trim($dm[1]) : null;

        if (!$client && !$server && !$db) {
            preg_match_all(self::CODE_BLOCK_RE, $rawText, $blocks);
            $b = $blocks[1] ?? [];
            if (count($b) >= 1) $client = trim($b[0]);
            if (count($b) >= 2) $server = trim($b[1]);
            if (count($b) >= 3) $db = trim($b[2]);
        }
        if (!$client) $client = $rawText;

        $score = $this->calculateScore($client, $server, $db);
        return ['modelId' => $modelId, 'success' => true, 'rawResponse' => $rawText,
            'clientCode' => $client, 'serverCode' => $server, 'databaseCode' => $db,
            'score' => $score, 'latencyMs' => $raw['latencyMs'] ?? 0];
    }

    private function calculateScore(?string $client, ?string $server, ?string $db): float {
        $s = 0.0;
        if ($client) { $s += 0.4; if (preg_match('/interface |: string|: int/', $client)) $s += 0.05; }
        if ($server) { $s += 0.3; if (preg_match('/try|catch/', $server)) $s += 0.05; }
        if ($db) $s += 0.2;
        return min($s, 1.0);
    }

    public function mergeResults(array $responses, string $strategy): DataProcessResult {
        $ok = array_filter($responses, fn($r) => $r['success'] ?? false);
        if (empty($ok)) {
            $errors = implode('; ', array_map(fn($r) => ($r['modelId'] ?? '?') . ': ' . ($r['error'] ?? '?'), $responses));
            return DataProcessResult::failure("All models failed: $errors");
        }
        usort($ok, fn($a, $b) => ($b['score'] ?? 0) <=> ($a['score'] ?? 0));
        $best = $ok[0];
        return DataProcessResult::ok([
            'clientCode' => $best['clientCode'] ?? null,
            'serverCode' => $best['serverCode'] ?? null,
            'databaseCode' => $best['databaseCode'] ?? null,
            'score' => $best['score'] ?? 0,
        ]);
    }

    // Helpers
    private function loadFeedback(array $components, TransformConfig $config): array {
        try {
            $filter = $this->objectProcessor->buildSearchFilter([
                'targetClient' => $config->targetClient,
                'rating' => ['positive', 'negative'],
            ]);
            return $this->feedback->getFeedbackHistory($filter, $config->feedbackLookback);
        } catch (\Throwable) { return []; }
    }

    private function storeDebugSnapshot(array $ctx, array $output): void {
        $snapshot = $this->objectProcessor->parseObjectAlternative([
            'type' => 'ai-transform', 'traceId' => $ctx['traceId'] ?? '',
            'nodeId' => $ctx['nodeId'] ?? '', 'transformId' => $output['transformId'] ?? '',
            'mergedScore' => $output['mergedScore'] ?? 0,
        ]);
        $this->debugger->storeSnapshot($ctx['traceId'] ?? '', $ctx['nodeId'] ?? '', $snapshot);
    }

    private function extractComponents(array $input): array {
        if (isset($input['components']) && is_array($input['components'])) return $input['components'];
        return [$input];
    }
}
