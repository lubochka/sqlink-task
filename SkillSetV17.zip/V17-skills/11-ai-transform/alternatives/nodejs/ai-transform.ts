/**
 * Skill 11 — AI Transform Service (Node.js / TypeScript)
 * Multi-model parallel AI code generation with feedback injection
 * Genie DNA: Dynamic documents, BuildSearchFilter, DataProcessResult
 */

import { EventEmitter } from 'events';

// ---------------------------------------------------------------------------
// Types (all dynamic-document compatible — no fixed schemas)
// ---------------------------------------------------------------------------
export interface TransformConfig {
  models: string[];
  mergeStrategy: 'best-score' | 'section-best' | 'consensus' | 'custom';
  maxTokens: number;
  temperature: number;
  feedbackLookback: number;
  retryOnFailure: boolean;
  timeoutSeconds: number;
  targetStack: { client: string; server: string; database: string };
}

export interface ModelResponse {
  modelId: string;
  provider: string;
  success: boolean;
  rawResponse?: string;
  clientCode?: string;
  serverCode?: string;
  databaseCode?: string;
  score: number;
  error?: string;
  latencyMs: number;
  tokensUsed: number;
}

export interface TransformOutput {
  transformId: string;
  clientCode?: string;
  serverCode?: string;
  databaseCode?: string;
  mergedScore: number;
  mergeStrategy: string;
  modelResults: ModelResponse[];
  promptUsed: string;
  feedbackItemsInjected: number;
  completedAt: string;
}

export interface DataProcessResult<T> {
  isSuccess: boolean;
  data?: T;
  error?: string;
  metadata?: Record<string, unknown>;
}

export interface FlowStepContext {
  traceId: string;
  flowId: string;
  nodeId: string;
  input: Record<string, unknown>;
  nodeConfig: Record<string, unknown>;
  flowVariables: Record<string, unknown>;
}

// Dependency interfaces (Skills 06, 07, 13, 14)
export interface IAiDispatcher {
  dispatch(modelId: string, prompt: string, options?: Record<string, unknown>): Promise<Record<string, unknown>>;
  dispatchParallel(modelIds: string[], prompt: string, options?: Record<string, unknown>): Promise<Record<string, unknown>[]>;
}

export interface IFeedbackService {
  getFeedbackHistory(filter: Record<string, unknown>, limit?: number): Promise<Record<string, unknown>[]>;
}

export interface INodeDebugger {
  storeSnapshot(traceId: string, nodeId: string, snapshot: Record<string, unknown>): Promise<void>;
}

export interface IObjectProcessor {
  parseObjectAlternative(input: unknown): Record<string, unknown>;
  buildSearchFilter(filter: unknown): Record<string, unknown>;
  mergeObjects(a: Record<string, unknown>, b: Record<string, unknown>): Record<string, unknown>;
}

// ---------------------------------------------------------------------------
// Response parsing regex (FigmaCodeGenerator pattern)
// ---------------------------------------------------------------------------
const CLIENT_CODE_RE = /\/\/\s*===\s*CLIENT\s*CODE\s*===[\s\S]*?```\w*\n([\s\S]*?)```/i;
const SERVER_CODE_RE = /\/\/\s*===\s*SERVER\s*CODE\s*===[\s\S]*?```\w*\n([\s\S]*?)```/i;
const DB_CODE_RE = /\/\/\s*===\s*DATABASE\s*CODE\s*===[\s\S]*?```\w*\n([\s\S]*?)```/i;
const CODE_BLOCK_RE = /```\w*\n([\s\S]*?)```/g;

// ---------------------------------------------------------------------------
// Default config
// ---------------------------------------------------------------------------
const DEFAULT_CONFIG: TransformConfig = {
  models: ['claude-sonnet', 'gpt-4o'],
  mergeStrategy: 'best-score',
  maxTokens: 4096,
  temperature: 0.3,
  feedbackLookback: 10,
  retryOnFailure: true,
  timeoutSeconds: 120,
  targetStack: { client: 'react', server: 'node', database: 'elasticsearch' },
};

// ---------------------------------------------------------------------------
// AI Transform Service
// ---------------------------------------------------------------------------
export class AiTransformService extends EventEmitter {
  constructor(
    private dispatcher: IAiDispatcher,
    private feedback: IFeedbackService,
    private debugger_: INodeDebugger,
    private objectProcessor: IObjectProcessor,
  ) {
    super();
  }

  // Execute — called by Flow Orchestrator (Skill 09)
  async execute(context: FlowStepContext): Promise<DataProcessResult<TransformOutput>> {
    try {
      const config = this.extractConfig(context.nodeConfig);
      const components = this.extractComponents(context.input);
      const result = await this.transformComponents(components, config);

      if (result.isSuccess && result.data) {
        await this.storeDebugSnapshot(context, result.data).catch((err) =>
          console.warn('Debug snapshot failed:', err.message),
        );
      }
      return result;
    } catch (err: any) {
      return { isSuccess: false, error: `Transform failed: ${err.message}` };
    }
  }

  // Core pipeline
  async transformComponents(
    components: Record<string, unknown>[],
    config: TransformConfig,
  ): Promise<DataProcessResult<TransformOutput>> {
    // Step 1: Load feedback
    const feedbackHistory = await this.loadFeedback(components, config);

    // Step 2: Assemble prompt
    const prompt = this.assemblePrompt(components, config, feedbackHistory);

    // Step 3: Dispatch to models
    const rawResponses = await this.dispatchToModels(config.models, prompt, config);

    // Step 4: Parse
    const parsed = rawResponses.map((r) => this.parseModelResponse(r));

    // Step 5: Merge
    const mergeResult = this.mergeResults(parsed, config.mergeStrategy);
    if (!mergeResult.isSuccess || !mergeResult.data) {
      return { isSuccess: false, error: mergeResult.error ?? 'Merge failed' };
    }

    // Step 6: Output
    const output: TransformOutput = {
      transformId: crypto.randomUUID().replace(/-/g, ''),
      clientCode: mergeResult.data.clientCode,
      serverCode: mergeResult.data.serverCode,
      databaseCode: mergeResult.data.databaseCode,
      mergedScore: mergeResult.data.score,
      mergeStrategy: config.mergeStrategy,
      modelResults: parsed,
      promptUsed: prompt,
      feedbackItemsInjected: feedbackHistory.length,
      completedAt: new Date().toISOString(),
    };

    return { isSuccess: true, data: output };
  }

  // -----------------------------------------------------------------------
  // Prompt Assembly (4-layer pattern)
  // -----------------------------------------------------------------------
  assemblePrompt(
    components: Record<string, unknown>[],
    config: TransformConfig,
    feedbackHistory: Record<string, unknown>[],
  ): string {
    const sections: string[] = [];

    // Layer 1: System context
    sections.push(this.buildSystemContext());

    // Layer 2: Design data
    sections.push(this.buildDesignDataSection(components));

    // Layer 3: Feedback
    if (feedbackHistory.length > 0) {
      sections.push(this.buildFeedbackSection(feedbackHistory));
    }

    // Layer 4: Targets
    sections.push(this.buildTargetInstructions(config.targetStack));

    return sections.join('\n\n');
  }

  private buildSystemContext(): string {
    return `You are a senior full-stack developer converting Figma design components into production-ready code.
Respond with clearly separated code sections using markdown code blocks.
Label each section: // === CLIENT CODE ===, // === SERVER CODE ===, // === DATABASE CODE ===
Include TypeScript types, error handling, and accessibility attributes.`;
  }

  private buildDesignDataSection(components: Record<string, unknown>[]): string {
    const lines = ['## Design Components\n'];
    components.forEach((comp, i) => {
      const name = String(comp.name ?? `component_${i}`);
      const html = String(comp.html ?? '');
      const css = String(comp.css ?? '');
      const type = String(comp.type ?? 'unknown');
      lines.push(`### Component ${i + 1}: ${name} (type: ${type})`);
      if (html) lines.push('```html\n' + html + '\n```');
      if (css) lines.push('```css\n' + css + '\n```');
      lines.push('');
    });
    return lines.join('\n');
  }

  private buildFeedbackSection(history: Record<string, unknown>[]): string {
    const lines = ['## Previous Feedback\n'];
    const positive = history.filter((f) => f.rating === 'positive');
    const negative = history.filter((f) => f.rating === 'negative');

    if (positive.length) {
      lines.push('### ✅ What worked well:');
      positive.forEach((f) => lines.push(`- "${f.text ?? 'No details'}" (positive)`));
      lines.push('');
    }
    if (negative.length) {
      lines.push('### ❌ What to avoid:');
      negative.forEach((f) => lines.push(`- "${f.text ?? 'No details'}" (negative)`));
      lines.push('');
    }
    lines.push('Please apply these learnings.');
    return lines.join('\n');
  }

  private buildTargetInstructions(stack: { client: string; server: string; database: string }): string {
    return `## Generation Targets

### Client-Side Code (${stack.client})
Generate frontend code with semantic HTML, responsive design, accessibility, TypeScript types.

### Server-Side Code (${stack.server})
Generate backend code with API endpoints, validation, error handling, DI, RESTful conventions.

### Database Schema (${stack.database})
Generate schema with entities, constraints, indexes, migrations, dynamic document support.`;
  }

  // -----------------------------------------------------------------------
  // Model Dispatch
  // -----------------------------------------------------------------------
  private async dispatchToModels(
    modelIds: string[],
    prompt: string,
    config: TransformConfig,
  ): Promise<Record<string, unknown>[]> {
    const options = {
      maxTokens: config.maxTokens,
      temperature: config.temperature,
      timeoutSeconds: config.timeoutSeconds,
    };

    try {
      return await this.dispatcher.dispatchParallel(modelIds, prompt, options);
    } catch {
      // Sequential fallback
      const results: Record<string, unknown>[] = [];
      for (const id of modelIds) {
        try {
          results.push(await this.dispatcher.dispatch(id, prompt, options));
        } catch (err: any) {
          results.push({ modelId: id, success: false, error: err.message });
        }
      }
      return results;
    }
  }

  // -----------------------------------------------------------------------
  // Response Parsing
  // -----------------------------------------------------------------------
  private parseModelResponse(raw: Record<string, unknown>): ModelResponse {
    const modelId = String(raw.modelId ?? 'unknown');
    const success = Boolean(raw.success);
    const rawText = String(raw.response ?? raw.text ?? '');
    const latencyMs = Number(raw.latencyMs ?? 0);
    const tokensUsed = Number(raw.tokensUsed ?? 0);

    if (!success || !rawText) {
      return { modelId, provider: '', success: false, rawResponse: rawText,
        score: 0, error: String(raw.error ?? 'No response'), latencyMs, tokensUsed };
    }

    // Priority 1: Labeled sections
    let clientCode = CLIENT_CODE_RE.exec(rawText)?.[1]?.trim();
    let serverCode = SERVER_CODE_RE.exec(rawText)?.[1]?.trim();
    let databaseCode = DB_CODE_RE.exec(rawText)?.[1]?.trim();

    // Priority 2: Sequential fallback
    if (!clientCode && !serverCode && !databaseCode) {
      const blocks: string[] = [];
      let m: RegExpExecArray | null;
      const re = new RegExp(CODE_BLOCK_RE.source, CODE_BLOCK_RE.flags);
      while ((m = re.exec(rawText)) !== null) blocks.push(m[1].trim());
      if (blocks.length >= 1) clientCode = blocks[0];
      if (blocks.length >= 2) serverCode = blocks[1];
      if (blocks.length >= 3) databaseCode = blocks[2];
    }

    // Priority 3: Raw fallback
    if (!clientCode) clientCode = rawText;

    const score = this.calculateScore(clientCode, serverCode, databaseCode);

    return {
      modelId, provider: String(raw.provider ?? ''), success: true,
      rawResponse: rawText, clientCode, serverCode, databaseCode,
      score, latencyMs, tokensUsed,
    };
  }

  private calculateScore(client?: string, server?: string, db?: string): number {
    let score = 0;
    if (client) { score += 0.4; if (/interface |: string|: number/.test(client)) score += 0.05; }
    if (server) { score += 0.3; if (/try|catch|except/.test(server)) score += 0.05; }
    if (db) score += 0.2;
    return Math.min(score, 1.0);
  }

  // -----------------------------------------------------------------------
  // Result Merging
  // -----------------------------------------------------------------------
  mergeResults(
    responses: ModelResponse[],
    strategy: string,
  ): DataProcessResult<{ clientCode?: string; serverCode?: string; databaseCode?: string; score: number }> {
    const ok = responses.filter((r) => r.success);
    if (!ok.length) {
      return { isSuccess: false, error: 'All models failed: ' + responses.map((r) => `${r.modelId}: ${r.error}`).join('; ') };
    }

    const sorted = [...ok].sort((a, b) => b.score - a.score);

    if (strategy === 'section-best') {
      const bestClient = ok.filter((r) => r.clientCode).sort((a, b) => b.score - a.score)[0];
      const bestServer = ok.filter((r) => r.serverCode).sort((a, b) => b.score - a.score)[0];
      const bestDb = ok.filter((r) => r.databaseCode).sort((a, b) => b.score - a.score)[0];
      return {
        isSuccess: true,
        data: {
          clientCode: bestClient?.clientCode, serverCode: bestServer?.serverCode,
          databaseCode: bestDb?.databaseCode,
          score: ((bestClient?.score ?? 0) + (bestServer?.score ?? 0) + (bestDb?.score ?? 0)) / 3,
        },
      };
    }

    if (strategy === 'consensus' && ok.length >= 3) {
      const threshold = ok.length / 2;
      const best = sorted[0];
      return {
        isSuccess: true,
        data: {
          clientCode: ok.filter((r) => r.clientCode).length >= threshold ? best.clientCode : undefined,
          serverCode: ok.filter((r) => r.serverCode).length >= threshold ? best.serverCode : undefined,
          databaseCode: ok.filter((r) => r.databaseCode).length >= threshold ? best.databaseCode : undefined,
          score: best.score * 0.9,
        },
      };
    }

    // Default: best-score
    const best = sorted[0];
    return {
      isSuccess: true,
      data: { clientCode: best.clientCode, serverCode: best.serverCode, databaseCode: best.databaseCode, score: best.score },
    };
  }

  // -----------------------------------------------------------------------
  // Helpers
  // -----------------------------------------------------------------------
  private async loadFeedback(
    components: Record<string, unknown>[],
    config: TransformConfig,
  ): Promise<Record<string, unknown>[]> {
    try {
      const types = [...new Set(components.map((c) => String(c.type ?? '')).filter(Boolean))];
      const filter = this.objectProcessor.buildSearchFilter({
        componentTypes: types.length ? types : undefined,
        targetClient: config.targetStack.client,
        rating: ['positive', 'negative'],
      });
      return await this.feedback.getFeedbackHistory(filter, config.feedbackLookback);
    } catch {
      return [];
    }
  }

  private async storeDebugSnapshot(ctx: FlowStepContext, output: TransformOutput): Promise<void> {
    const snapshot = this.objectProcessor.parseObjectAlternative({
      type: 'ai-transform', traceId: ctx.traceId, nodeId: ctx.nodeId,
      transformId: output.transformId, mergeStrategy: output.mergeStrategy,
      mergedScore: output.mergedScore, modelCount: output.modelResults.length,
      successfulModels: output.modelResults.filter((r) => r.success).length,
      timestamp: new Date().toISOString(),
    });
    await this.debugger_.storeSnapshot(ctx.traceId, ctx.nodeId, snapshot);
  }

  private extractConfig(nodeConfig: Record<string, unknown>): TransformConfig {
    return {
      models: Array.isArray(nodeConfig.models) ? nodeConfig.models.map(String) : DEFAULT_CONFIG.models,
      mergeStrategy: (String(nodeConfig.mergeStrategy ?? DEFAULT_CONFIG.mergeStrategy)) as any,
      maxTokens: Number(nodeConfig.maxTokens ?? DEFAULT_CONFIG.maxTokens),
      temperature: Number(nodeConfig.temperature ?? DEFAULT_CONFIG.temperature),
      feedbackLookback: Number(nodeConfig.feedbackLookback ?? DEFAULT_CONFIG.feedbackLookback),
      retryOnFailure: Boolean(nodeConfig.retryOnFailure ?? DEFAULT_CONFIG.retryOnFailure),
      timeoutSeconds: Number(nodeConfig.timeoutSeconds ?? DEFAULT_CONFIG.timeoutSeconds),
      targetStack: {
        client: String(nodeConfig.targetClient ?? nodeConfig.client ?? DEFAULT_CONFIG.targetStack.client),
        server: String(nodeConfig.targetServer ?? nodeConfig.server ?? DEFAULT_CONFIG.targetStack.server),
        database: String(nodeConfig.targetDatabase ?? nodeConfig.database ?? DEFAULT_CONFIG.targetStack.database),
      },
    };
  }

  private extractComponents(input: Record<string, unknown>): Record<string, unknown>[] {
    if (Array.isArray(input.components)) return input.components as Record<string, unknown>[];
    return [input];
  }
}

export default AiTransformService;
