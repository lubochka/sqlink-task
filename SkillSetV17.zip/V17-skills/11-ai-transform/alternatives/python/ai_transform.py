"""
Skill 11 — AI Transform Service (Python)
Multi-model parallel AI code generation with feedback injection
Genie DNA: Dynamic documents, BuildSearchFilter, DataProcessResult
"""

import asyncio
import re
import uuid
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Protocol

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Protocols (dependency interfaces — Skills 06, 07, 13, 14, 02)
# ---------------------------------------------------------------------------
class IAiDispatcher(Protocol):
    async def dispatch(self, model_id: str, prompt: str, options: dict | None = None) -> dict: ...
    async def dispatch_parallel(self, model_ids: list[str], prompt: str, options: dict | None = None) -> list[dict]: ...

class IFeedbackService(Protocol):
    async def get_feedback_history(self, filter_: dict, limit: int = 10) -> list[dict]: ...

class INodeDebugger(Protocol):
    async def store_snapshot(self, trace_id: str, node_id: str, snapshot: dict) -> None: ...

class IObjectProcessor(Protocol):
    def parse_object_alternative(self, input_: Any) -> dict: ...
    def build_search_filter(self, filter_: Any) -> dict: ...
    def merge_objects(self, a: dict, b: dict) -> dict: ...

# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------
@dataclass
class TransformConfig:
    models: list[str] = field(default_factory=lambda: ["claude-sonnet", "gpt-4o"])
    merge_strategy: str = "best-score"
    max_tokens: int = 4096
    temperature: float = 0.3
    feedback_lookback: int = 10
    retry_on_failure: bool = True
    timeout_seconds: int = 120
    target_client: str = "react"
    target_server: str = "python"
    target_database: str = "elasticsearch"

@dataclass
class ModelResponse:
    model_id: str = ""
    provider: str = ""
    success: bool = False
    raw_response: str | None = None
    client_code: str | None = None
    server_code: str | None = None
    database_code: str | None = None
    score: float = 0.0
    error: str | None = None
    latency_ms: int = 0
    tokens_used: int = 0

@dataclass
class TransformOutput:
    transform_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    client_code: str | None = None
    server_code: str | None = None
    database_code: str | None = None
    merged_score: float = 0.0
    merge_strategy: str = ""
    model_results: list[ModelResponse] = field(default_factory=list)
    prompt_used: str = ""
    feedback_items_injected: int = 0
    completed_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

@dataclass
class DataProcessResult:
    is_success: bool = False
    data: Any = None
    error: str | None = None
    metadata: dict | None = None

    @staticmethod
    def ok(data: Any, meta: dict | None = None) -> "DataProcessResult":
        return DataProcessResult(is_success=True, data=data, metadata=meta)

    @staticmethod
    def failure(error: str, meta: dict | None = None) -> "DataProcessResult":
        return DataProcessResult(is_success=False, error=error, metadata=meta)

@dataclass
class FlowStepContext:
    trace_id: str = ""
    flow_id: str = ""
    node_id: str = ""
    input: dict = field(default_factory=dict)
    node_config: dict = field(default_factory=dict)
    flow_variables: dict = field(default_factory=dict)

# ---------------------------------------------------------------------------
# Response parsing regex (FigmaCodeGenerator pattern)
# ---------------------------------------------------------------------------
CLIENT_RE = re.compile(r"//\s*===\s*CLIENT\s*CODE\s*===[\s\S]*?```\w*\n([\s\S]*?)```", re.IGNORECASE)
SERVER_RE = re.compile(r"//\s*===\s*SERVER\s*CODE\s*===[\s\S]*?```\w*\n([\s\S]*?)```", re.IGNORECASE)
DB_RE = re.compile(r"//\s*===\s*DATABASE\s*CODE\s*===[\s\S]*?```\w*\n([\s\S]*?)```", re.IGNORECASE)
CODE_BLOCK_RE = re.compile(r"```\w*\n([\s\S]*?)```")

# ---------------------------------------------------------------------------
# AI Transform Service
# ---------------------------------------------------------------------------
class AiTransformService:
    def __init__(
        self,
        dispatcher: IAiDispatcher,
        feedback: IFeedbackService,
        debugger: INodeDebugger,
        object_processor: IObjectProcessor,
    ):
        self._dispatcher = dispatcher
        self._feedback = feedback
        self._debugger = debugger
        self._op = object_processor

    async def execute(self, context: FlowStepContext) -> DataProcessResult:
        """Execute — called by Flow Orchestrator (Skill 09)."""
        try:
            config = self._extract_config(context.node_config)
            components = self._extract_components(context.input)
            result = await self.transform_components(components, config)

            if result.is_success and result.data:
                try:
                    await self._store_debug_snapshot(context, result.data)
                except Exception as e:
                    logger.warning("Debug snapshot failed: %s", e)
            return result
        except Exception as e:
            logger.error("Transform failed for trace %s: %s", context.trace_id, e)
            return DataProcessResult.failure(f"Transform failed: {e}")

    async def transform_components(
        self, components: list[dict], config: TransformConfig
    ) -> DataProcessResult:
        """Core pipeline: feedback → prompt → dispatch → parse → merge."""
        # Step 1: Feedback
        feedback_history = await self._load_feedback(components, config)

        # Step 2: Prompt
        prompt = self.assemble_prompt(components, config, feedback_history)

        # Step 3: Dispatch
        raw_responses = await self._dispatch_to_models(config.models, prompt, config)

        # Step 4: Parse
        parsed = [self._parse_model_response(r) for r in raw_responses]

        # Step 5: Merge
        merge_result = self.merge_results(parsed, config.merge_strategy)
        if not merge_result.is_success:
            return DataProcessResult.failure(merge_result.error or "Merge failed")

        # Step 6: Output
        merged = merge_result.data
        output = TransformOutput(
            client_code=merged.get("client_code"),
            server_code=merged.get("server_code"),
            database_code=merged.get("database_code"),
            merged_score=merged.get("score", 0.0),
            merge_strategy=config.merge_strategy,
            model_results=parsed,
            prompt_used=prompt,
            feedback_items_injected=len(feedback_history),
        )
        return DataProcessResult.ok(output)

    # -----------------------------------------------------------------------
    # Prompt Assembly
    # -----------------------------------------------------------------------
    def assemble_prompt(
        self, components: list[dict], config: TransformConfig, feedback: list[dict]
    ) -> str:
        sections = [
            self._build_system_context(),
            self._build_design_data(components),
        ]
        if feedback:
            sections.append(self._build_feedback_section(feedback))
        sections.append(self._build_target_instructions(config))
        return "\n\n".join(sections)

    @staticmethod
    def _build_system_context() -> str:
        return (
            "You are a senior full-stack developer converting Figma design components "
            "into production-ready code.\n"
            "Label each section: // === CLIENT CODE ===, // === SERVER CODE ===, "
            "// === DATABASE CODE ===\n"
            "Include types, error handling, and accessibility attributes."
        )

    @staticmethod
    def _build_design_data(components: list[dict]) -> str:
        lines = ["## Design Components\n"]
        for i, comp in enumerate(components):
            name = comp.get("name", f"component_{i}")
            html = comp.get("html", "")
            css = comp.get("css", "")
            typ = comp.get("type", "unknown")
            lines.append(f"### Component {i + 1}: {name} (type: {typ})")
            if html:
                lines.append(f"```html\n{html}\n```")
            if css:
                lines.append(f"```css\n{css}\n```")
            lines.append("")
        return "\n".join(lines)

    @staticmethod
    def _build_feedback_section(history: list[dict]) -> str:
        lines = ["## Previous Feedback\n"]
        positive = [f for f in history if f.get("rating") == "positive"]
        negative = [f for f in history if f.get("rating") == "negative"]
        if positive:
            lines.append("### ✅ What worked well:")
            for f in positive:
                lines.append(f'- "{f.get("text", "No details")}" (positive)')
            lines.append("")
        if negative:
            lines.append("### ❌ What to avoid:")
            for f in negative:
                lines.append(f'- "{f.get("text", "No details")}" (negative)')
            lines.append("")
        lines.append("Please apply these learnings.")
        return "\n".join(lines)

    @staticmethod
    def _build_target_instructions(config: TransformConfig) -> str:
        return (
            f"## Generation Targets\n\n"
            f"### Client-Side ({config.target_client})\n"
            f"Semantic HTML, responsive, accessible, typed.\n\n"
            f"### Server-Side ({config.target_server})\n"
            f"API endpoints, validation, error handling, DI.\n\n"
            f"### Database ({config.target_database})\n"
            f"Entities, constraints, indexes, migrations, dynamic docs."
        )

    # -----------------------------------------------------------------------
    # Dispatch
    # -----------------------------------------------------------------------
    async def _dispatch_to_models(
        self, model_ids: list[str], prompt: str, config: TransformConfig
    ) -> list[dict]:
        options = {
            "maxTokens": config.max_tokens,
            "temperature": config.temperature,
            "timeoutSeconds": config.timeout_seconds,
        }
        try:
            return await self._dispatcher.dispatch_parallel(model_ids, prompt, options)
        except Exception:
            results = []
            for mid in model_ids:
                try:
                    results.append(await self._dispatcher.dispatch(mid, prompt, options))
                except Exception as e:
                    results.append({"modelId": mid, "success": False, "error": str(e)})
            return results

    # -----------------------------------------------------------------------
    # Response Parsing
    # -----------------------------------------------------------------------
    def _parse_model_response(self, raw: dict) -> ModelResponse:
        model_id = str(raw.get("modelId", "unknown"))
        success = bool(raw.get("success", False))
        raw_text = str(raw.get("response", raw.get("text", "")))
        latency = int(raw.get("latencyMs", 0))
        tokens = int(raw.get("tokensUsed", 0))

        if not success or not raw_text:
            return ModelResponse(model_id=model_id, success=False, raw_response=raw_text,
                                 error=str(raw.get("error", "No response")), latency_ms=latency)

        # Priority 1: Labeled
        cm = CLIENT_RE.search(raw_text)
        sm = SERVER_RE.search(raw_text)
        dm = DB_RE.search(raw_text)
        client = cm.group(1).strip() if cm else None
        server = sm.group(1).strip() if sm else None
        db = dm.group(1).strip() if dm else None

        # Priority 2: Sequential
        if not client and not server and not db:
            blocks = [m.group(1).strip() for m in CODE_BLOCK_RE.finditer(raw_text)]
            if len(blocks) >= 1: client = blocks[0]
            if len(blocks) >= 2: server = blocks[1]
            if len(blocks) >= 3: db = blocks[2]

        # Priority 3: Raw
        if not client:
            client = raw_text

        score = self._calculate_score(client, server, db)
        return ModelResponse(
            model_id=model_id, provider=str(raw.get("provider", "")), success=True,
            raw_response=raw_text, client_code=client, server_code=server,
            database_code=db, score=score, latency_ms=latency, tokens_used=tokens,
        )

    @staticmethod
    def _calculate_score(client: str | None, server: str | None, db: str | None) -> float:
        score = 0.0
        if client:
            score += 0.4
            if re.search(r"interface |: str|: int|typing\.", client):
                score += 0.05
        if server:
            score += 0.3
            if re.search(r"try|except|catch", server):
                score += 0.05
        if db:
            score += 0.2
        return min(score, 1.0)

    # -----------------------------------------------------------------------
    # Merge
    # -----------------------------------------------------------------------
    def merge_results(self, responses: list[ModelResponse], strategy: str) -> DataProcessResult:
        ok = [r for r in responses if r.success]
        if not ok:
            errors = "; ".join(f"{r.model_id}: {r.error}" for r in responses)
            return DataProcessResult.failure(f"All models failed: {errors}")

        ok.sort(key=lambda r: r.score, reverse=True)

        if strategy == "section-best":
            bc = sorted([r for r in ok if r.client_code], key=lambda r: r.score, reverse=True)
            bs = sorted([r for r in ok if r.server_code], key=lambda r: r.score, reverse=True)
            bd = sorted([r for r in ok if r.database_code], key=lambda r: r.score, reverse=True)
            return DataProcessResult.ok({
                "client_code": bc[0].client_code if bc else None,
                "server_code": bs[0].server_code if bs else None,
                "database_code": bd[0].database_code if bd else None,
                "score": sum(x[0].score for x in [bc, bs, bd] if x) / 3,
            })

        if strategy == "consensus" and len(ok) >= 3:
            threshold = len(ok) / 2
            best = ok[0]
            return DataProcessResult.ok({
                "client_code": best.client_code if sum(1 for r in ok if r.client_code) >= threshold else None,
                "server_code": best.server_code if sum(1 for r in ok if r.server_code) >= threshold else None,
                "database_code": best.database_code if sum(1 for r in ok if r.database_code) >= threshold else None,
                "score": best.score * 0.9,
            })

        best = ok[0]
        return DataProcessResult.ok({
            "client_code": best.client_code,
            "server_code": best.server_code,
            "database_code": best.database_code,
            "score": best.score,
        })

    # -----------------------------------------------------------------------
    # Helpers
    # -----------------------------------------------------------------------
    async def _load_feedback(self, components: list[dict], config: TransformConfig) -> list[dict]:
        try:
            types = list({str(c.get("type", "")) for c in components if c.get("type")})
            filter_ = self._op.build_search_filter({
                "componentTypes": types or None,
                "targetClient": config.target_client,
                "rating": ["positive", "negative"],
            })
            return await self._feedback.get_feedback_history(filter_, config.feedback_lookback)
        except Exception:
            return []

    async def _store_debug_snapshot(self, ctx: FlowStepContext, output: TransformOutput) -> None:
        snapshot = self._op.parse_object_alternative({
            "type": "ai-transform", "traceId": ctx.trace_id, "nodeId": ctx.node_id,
            "transformId": output.transform_id, "mergeStrategy": output.merge_strategy,
            "mergedScore": output.merged_score, "modelCount": len(output.model_results),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })
        await self._debugger.store_snapshot(ctx.trace_id, ctx.node_id, snapshot)

    @staticmethod
    def _extract_config(nc: dict) -> TransformConfig:
        return TransformConfig(
            models=nc.get("models", ["claude-sonnet", "gpt-4o"]),
            merge_strategy=str(nc.get("mergeStrategy", "best-score")),
            max_tokens=int(nc.get("maxTokens", 4096)),
            temperature=float(nc.get("temperature", 0.3)),
            feedback_lookback=int(nc.get("feedbackLookback", 10)),
            timeout_seconds=int(nc.get("timeoutSeconds", 120)),
            target_client=str(nc.get("targetClient", nc.get("client", "react"))),
            target_server=str(nc.get("targetServer", nc.get("server", "python"))),
            target_database=str(nc.get("targetDatabase", nc.get("database", "elasticsearch"))),
        )

    @staticmethod
    def _extract_components(input_: dict) -> list[dict]:
        comps = input_.get("components")
        if isinstance(comps, list):
            return comps
        return [input_]
