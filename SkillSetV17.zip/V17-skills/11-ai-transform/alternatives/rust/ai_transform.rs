// =============================================================================
// Skill 11 — AI Transform Service (Rust)
// Multi-model parallel AI code generation with feedback injection
// Genie DNA: Dynamic documents (serde_json::Value), DataProcessResult
// =============================================================================

use async_trait::async_trait;
use regex::Regex;
use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::collections::HashMap;
use std::sync::Arc;
use tokio::time::{timeout, Duration};
use uuid::Uuid;

// ---------------------------------------------------------------------------
// Trait interfaces (Skills 02, 06, 07, 13, 14)
// ---------------------------------------------------------------------------
#[async_trait]
pub trait AiDispatcher: Send + Sync {
    async fn dispatch(&self, model_id: &str, prompt: &str, options: &Value) -> Result<Value, Box<dyn std::error::Error + Send + Sync>>;
    async fn dispatch_parallel(&self, model_ids: &[String], prompt: &str, options: &Value) -> Result<Vec<Value>, Box<dyn std::error::Error + Send + Sync>>;
}

#[async_trait]
pub trait FeedbackService: Send + Sync {
    async fn get_feedback_history(&self, filter: &Value, limit: usize) -> Result<Vec<Value>, Box<dyn std::error::Error + Send + Sync>>;
}

#[async_trait]
pub trait NodeDebugger: Send + Sync {
    async fn store_snapshot(&self, trace_id: &str, node_id: &str, snapshot: &Value) -> Result<(), Box<dyn std::error::Error + Send + Sync>>;
}

pub trait ObjectProcessor: Send + Sync {
    fn parse_object_alternative(&self, input: &Value) -> Value;
    fn build_search_filter(&self, filter: &Value) -> Value;
}

// ---------------------------------------------------------------------------
// Models
// ---------------------------------------------------------------------------
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TransformConfig {
    pub models: Vec<String>,
    pub merge_strategy: String,
    pub max_tokens: u32,
    pub temperature: f64,
    pub feedback_lookback: usize,
    pub timeout_seconds: u64,
    pub target_client: String,
    pub target_server: String,
    pub target_database: String,
}

impl Default for TransformConfig {
    fn default() -> Self {
        Self {
            models: vec!["claude-sonnet".into(), "gpt-4o".into()],
            merge_strategy: "best-score".into(),
            max_tokens: 4096, temperature: 0.3, feedback_lookback: 10,
            timeout_seconds: 120,
            target_client: "react".into(), target_server: "rust".into(),
            target_database: "elasticsearch".into(),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ModelResponse {
    pub model_id: String,
    pub success: bool,
    pub raw_response: Option<String>,
    pub client_code: Option<String>,
    pub server_code: Option<String>,
    pub database_code: Option<String>,
    pub score: f64,
    pub error: Option<String>,
    pub latency_ms: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TransformOutput {
    pub transform_id: String,
    pub client_code: Option<String>,
    pub server_code: Option<String>,
    pub database_code: Option<String>,
    pub merged_score: f64,
    pub merge_strategy: String,
    pub model_results: Vec<ModelResponse>,
    pub prompt_used: String,
    pub feedback_items_injected: usize,
}

#[derive(Debug, Clone)]
pub struct DataProcessResult<T> {
    pub is_success: bool,
    pub data: Option<T>,
    pub error: Option<String>,
}

impl<T> DataProcessResult<T> {
    pub fn ok(data: T) -> Self { Self { is_success: true, data: Some(data), error: None } }
    pub fn failure(error: impl Into<String>) -> Self { Self { is_success: false, data: None, error: Some(error.into()) } }
}

#[derive(Debug, Clone)]
pub struct FlowStepContext {
    pub trace_id: String,
    pub flow_id: String,
    pub node_id: String,
    pub input: Value,
    pub node_config: Value,
}

// ---------------------------------------------------------------------------
// Lazy regex (compiled once)
// ---------------------------------------------------------------------------
lazy_static::lazy_static! {
    static ref CLIENT_RE: Regex = Regex::new(r"(?i)//\s*===\s*CLIENT\s*CODE\s*===[\s\S]*?```\w*\n([\s\S]*?)```").unwrap();
    static ref SERVER_RE: Regex = Regex::new(r"(?i)//\s*===\s*SERVER\s*CODE\s*===[\s\S]*?```\w*\n([\s\S]*?)```").unwrap();
    static ref DB_RE: Regex = Regex::new(r"(?i)//\s*===\s*DATABASE\s*CODE\s*===[\s\S]*?```\w*\n([\s\S]*?)```").unwrap();
    static ref CODE_BLOCK_RE: Regex = Regex::new(r"```\w*\n([\s\S]*?)```").unwrap();
}

// ---------------------------------------------------------------------------
// Service
// ---------------------------------------------------------------------------
pub struct AiTransformService {
    dispatcher: Arc<dyn AiDispatcher>,
    feedback: Arc<dyn FeedbackService>,
    debugger: Arc<dyn NodeDebugger>,
    object_processor: Arc<dyn ObjectProcessor>,
}

impl AiTransformService {
    pub fn new(
        dispatcher: Arc<dyn AiDispatcher>,
        feedback: Arc<dyn FeedbackService>,
        debugger: Arc<dyn NodeDebugger>,
        object_processor: Arc<dyn ObjectProcessor>,
    ) -> Self {
        Self { dispatcher, feedback, debugger, object_processor }
    }

    /// Execute — called by Flow Orchestrator (Skill 09)
    pub async fn execute(&self, ctx: &FlowStepContext) -> DataProcessResult<TransformOutput> {
        let config = self.extract_config(&ctx.node_config);
        let components = self.extract_components(&ctx.input);

        let result = self.transform_components(&components, &config).await;

        if let Some(ref output) = result.data {
            if let Err(e) = self.store_debug_snapshot(ctx, output).await {
                eprintln!("Debug snapshot failed: {e}");
            }
        }
        result
    }

    /// Core pipeline
    pub async fn transform_components(
        &self, components: &[Value], config: &TransformConfig,
    ) -> DataProcessResult<TransformOutput> {
        // Step 1: Feedback
        let feedback_history = self.load_feedback(components, config).await;

        // Step 2: Prompt
        let prompt = self.assemble_prompt(components, config, &feedback_history);

        // Step 3: Dispatch
        let raw = self.dispatch_to_models(&config.models, &prompt, config).await;

        // Step 4: Parse
        let parsed: Vec<ModelResponse> = raw.iter().map(|r| self.parse_model_response(r)).collect();

        // Step 5: Merge
        let merge_result = self.merge_results(&parsed, &config.merge_strategy);
        match merge_result.data {
            None => DataProcessResult::failure(merge_result.error.unwrap_or_default()),
            Some((client, server, db, score)) => {
                DataProcessResult::ok(TransformOutput {
                    transform_id: Uuid::new_v4().to_string().replace('-', ""),
                    client_code: client, server_code: server, database_code: db,
                    merged_score: score, merge_strategy: config.merge_strategy.clone(),
                    model_results: parsed, prompt_used: prompt,
                    feedback_items_injected: feedback_history.len(),
                })
            }
        }
    }

    // -----------------------------------------------------------------------
    // Prompt Assembly
    // -----------------------------------------------------------------------
    pub fn assemble_prompt(&self, components: &[Value], config: &TransformConfig, feedback: &[Value]) -> String {
        let mut sections = vec![
            self.build_system_context(),
            self.build_design_data(components),
        ];
        if !feedback.is_empty() { sections.push(self.build_feedback_section(feedback)); }
        sections.push(self.build_target_instructions(config));
        sections.join("\n\n")
    }

    fn build_system_context(&self) -> String {
        "You are a senior full-stack developer converting Figma design components into production-ready code.\n\
         Label sections: // === CLIENT CODE ===, // === SERVER CODE ===, // === DATABASE CODE ===\n\
         Include types, error handling, accessibility.".to_string()
    }

    fn build_design_data(&self, components: &[Value]) -> String {
        let mut out = String::from("## Design Components\n\n");
        for (i, comp) in components.iter().enumerate() {
            let name = comp.get("name").and_then(|v| v.as_str()).unwrap_or("component");
            let typ = comp.get("type").and_then(|v| v.as_str()).unwrap_or("unknown");
            out.push_str(&format!("### Component {}: {} (type: {})\n", i + 1, name, typ));
            if let Some(html) = comp.get("html").and_then(|v| v.as_str()) {
                out.push_str(&format!("```html\n{}\n```\n", html));
            }
            if let Some(css) = comp.get("css").and_then(|v| v.as_str()) {
                out.push_str(&format!("```css\n{}\n```\n", css));
            }
            out.push('\n');
        }
        out
    }

    fn build_feedback_section(&self, history: &[Value]) -> String {
        let mut out = String::from("## Previous Feedback\n\n");
        let positive: Vec<_> = history.iter().filter(|f| f.get("rating").and_then(|v| v.as_str()) == Some("positive")).collect();
        let negative: Vec<_> = history.iter().filter(|f| f.get("rating").and_then(|v| v.as_str()) == Some("negative")).collect();
        if !positive.is_empty() {
            out.push_str("### ✅ What worked well:\n");
            for f in &positive { out.push_str(&format!("- \"{}\" (positive)\n", f.get("text").and_then(|v| v.as_str()).unwrap_or("No details"))); }
        }
        if !negative.is_empty() {
            out.push_str("### ❌ What to avoid:\n");
            for f in &negative { out.push_str(&format!("- \"{}\" (negative)\n", f.get("text").and_then(|v| v.as_str()).unwrap_or("No details"))); }
        }
        out.push_str("Please apply these learnings.");
        out
    }

    fn build_target_instructions(&self, config: &TransformConfig) -> String {
        format!(
            "## Generation Targets\n\
             ### Client-Side ({})\n### Server-Side ({})\n### Database ({})",
            config.target_client, config.target_server, config.target_database
        )
    }

    // -----------------------------------------------------------------------
    // Dispatch
    // -----------------------------------------------------------------------
    async fn dispatch_to_models(&self, model_ids: &[String], prompt: &str, config: &TransformConfig) -> Vec<Value> {
        let options = serde_json::json!({ "maxTokens": config.max_tokens, "temperature": config.temperature });
        match self.dispatcher.dispatch_parallel(model_ids, prompt, &options).await {
            Ok(results) => results,
            Err(_) => {
                let mut results = Vec::new();
                for id in model_ids {
                    match self.dispatcher.dispatch(id, prompt, &options).await {
                        Ok(r) => results.push(r),
                        Err(e) => results.push(serde_json::json!({ "modelId": id, "success": false, "error": e.to_string() })),
                    }
                }
                results
            }
        }
    }

    // -----------------------------------------------------------------------
    // Parse + Merge + Score (same patterns as other languages)
    // -----------------------------------------------------------------------
    fn parse_model_response(&self, raw: &Value) -> ModelResponse {
        let model_id = raw.get("modelId").and_then(|v| v.as_str()).unwrap_or("unknown").to_string();
        let success = raw.get("success").and_then(|v| v.as_bool()).unwrap_or(false);
        let raw_text = raw.get("response").or_else(|| raw.get("text")).and_then(|v| v.as_str()).unwrap_or("").to_string();
        let latency = raw.get("latencyMs").and_then(|v| v.as_u64()).unwrap_or(0);

        if !success || raw_text.is_empty() {
            return ModelResponse { model_id, success: false, raw_response: Some(raw_text),
                client_code: None, server_code: None, database_code: None, score: 0.0,
                error: Some(raw.get("error").and_then(|v| v.as_str()).unwrap_or("No response").into()), latency_ms: latency };
        }

        let client = CLIENT_RE.captures(&raw_text).map(|c| c[1].trim().to_string());
        let server = SERVER_RE.captures(&raw_text).map(|c| c[1].trim().to_string());
        let db = DB_RE.captures(&raw_text).map(|c| c[1].trim().to_string());

        let (client, server, db) = if client.is_none() && server.is_none() && db.is_none() {
            let blocks: Vec<String> = CODE_BLOCK_RE.captures_iter(&raw_text).map(|c| c[1].trim().to_string()).collect();
            (blocks.get(0).cloned(), blocks.get(1).cloned(), blocks.get(2).cloned())
        } else {
            (client, server, db)
        };

        let client = client.or_else(|| Some(raw_text.clone()));
        let score = Self::calculate_score(&client, &server, &db);

        ModelResponse { model_id, success: true, raw_response: Some(raw_text),
            client_code: client, server_code: server, database_code: db,
            score, error: None, latency_ms: latency }
    }

    fn calculate_score(client: &Option<String>, server: &Option<String>, db: &Option<String>) -> f64 {
        let mut s = 0.0;
        if let Some(c) = client { s += 0.4; if c.contains("interface ") || c.contains(": string") { s += 0.05; } }
        if let Some(sv) = server { if !sv.is_empty() { s += 0.3; } }
        if let Some(d) = db { if !d.is_empty() { s += 0.2; } }
        s.min(1.0)
    }

    fn merge_results(&self, responses: &[ModelResponse], strategy: &str)
        -> DataProcessResult<(Option<String>, Option<String>, Option<String>, f64)>
    {
        let mut ok: Vec<&ModelResponse> = responses.iter().filter(|r| r.success).collect();
        if ok.is_empty() {
            let errs: Vec<String> = responses.iter().map(|r| format!("{}: {}", r.model_id, r.error.as_deref().unwrap_or("?"))).collect();
            return DataProcessResult::failure(format!("All models failed: {}", errs.join("; ")));
        }
        ok.sort_by(|a, b| b.score.partial_cmp(&a.score).unwrap_or(std::cmp::Ordering::Equal));
        let best = ok[0];
        DataProcessResult::ok((best.client_code.clone(), best.server_code.clone(), best.database_code.clone(), best.score))
    }

    // Helpers
    async fn load_feedback(&self, _components: &[Value], config: &TransformConfig) -> Vec<Value> {
        let filter = serde_json::json!({ "targetClient": config.target_client, "rating": ["positive", "negative"] });
        let filter = self.object_processor.build_search_filter(&filter);
        self.feedback.get_feedback_history(&filter, config.feedback_lookback).await.unwrap_or_default()
    }

    async fn store_debug_snapshot(&self, ctx: &FlowStepContext, output: &TransformOutput) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        let snapshot = serde_json::json!({
            "type": "ai-transform", "traceId": ctx.trace_id, "nodeId": ctx.node_id,
            "transformId": output.transform_id, "mergedScore": output.merged_score,
            "modelCount": output.model_results.len(),
        });
        self.debugger.store_snapshot(&ctx.trace_id, &ctx.node_id, &snapshot).await
    }

    fn extract_config(&self, nc: &Value) -> TransformConfig {
        TransformConfig {
            models: nc.get("models").and_then(|v| serde_json::from_value(v.clone()).ok()).unwrap_or_else(|| vec!["claude-sonnet".into(), "gpt-4o".into()]),
            merge_strategy: nc.get("mergeStrategy").and_then(|v| v.as_str()).unwrap_or("best-score").to_string(),
            max_tokens: nc.get("maxTokens").and_then(|v| v.as_u64()).unwrap_or(4096) as u32,
            temperature: nc.get("temperature").and_then(|v| v.as_f64()).unwrap_or(0.3),
            feedback_lookback: nc.get("feedbackLookback").and_then(|v| v.as_u64()).unwrap_or(10) as usize,
            timeout_seconds: nc.get("timeoutSeconds").and_then(|v| v.as_u64()).unwrap_or(120),
            target_client: nc.get("targetClient").and_then(|v| v.as_str()).unwrap_or("react").to_string(),
            target_server: nc.get("targetServer").and_then(|v| v.as_str()).unwrap_or("rust").to_string(),
            target_database: nc.get("targetDatabase").and_then(|v| v.as_str()).unwrap_or("elasticsearch").to_string(),
        }
    }

    fn extract_components(&self, input: &Value) -> Vec<Value> {
        input.get("components").and_then(|v| v.as_array()).cloned()
            .unwrap_or_else(|| vec![input.clone()])
    }
}
