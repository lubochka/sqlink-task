# Skill 11 — AI Transform: Implementation Prompts

## Prerequisites
- Skill 01 (Core Interfaces) — DataProcessResult, IService
- Skill 02 (Object Processor) — ParseObjectAlternative, BuildSearchFilter
- Skill 06 (AI Providers) — IAiProvider interface
- Skill 07 (AI Dispatcher) — parallel dispatch + retry
- Skill 13 (Feedback Service) — feedback history lookup
- Skill 14 (Node Debugger) — debug snapshot storage

## Phase 1: Core Service Scaffold
```
Create the AiTransformService class implementing IAiTransformService.
- Constructor takes IAiDispatcher, IFeedbackService, INodeDebugger, IObjectProcessor
- ExecuteAsync method extracts config from FlowStepContext.NodeConfig (dynamic document)
- TransformComponentsAsync runs the 6-step pipeline:
  1. LoadFeedback → 2. AssemblePrompt → 3. DispatchToModels → 4. ParseResponses → 5. MergeResults → 6. BuildOutput
- All documents stored via ObjectProcessor.ParseObjectAlternative (Genie DNA-1)
- All errors wrapped in DataProcessResult (Genie DNA-3)
```

## Phase 2: Prompt Assembly (4-Layer Pattern)
```
Implement the 4-layer prompt assembly from FigmaCodeGenerator:
Layer 1: System Context — role definition + output format (labeled code sections)
Layer 2: Design Data — iterate components, include HTML/CSS in code blocks
Layer 3: Feedback History — positive examples to repeat, negative to avoid
Layer 4: Target Instructions — client/server/database stack specifics

Output format requires: // === CLIENT CODE ===, // === SERVER CODE ===, // === DATABASE CODE ===
Each followed by a markdown code block with language specified.
```

## Phase 3: Response Parsing
```
Implement the priority-chain response parser:
Priority 1: Regex match for labeled sections (CLIENT/SERVER/DATABASE CODE markers)
Priority 2: Sequential fallback — first code block → client, second → server, third → database
Priority 3: Raw fallback — entire response → clientCode

Score each response based on completeness:
- Client present: +0.4, has types: +0.05, has accessibility: +0.05
- Server present: +0.3, has error handling: +0.05
- Database present: +0.2
```

## Phase 4: Multi-Model Dispatch + Merge Strategies
```
Implement 3 merge strategies:
1. best-score: Pick highest-scoring single response
2. section-best: Pick best client from model A, best server from model B, etc.
3. consensus: Only keep code sections present in majority (2+/3) of responses

Use IAiDispatcher.DispatchParallelAsync for concurrent execution.
Fall back to sequential dispatch if parallel fails.
```

## Phase 5: Feedback Integration
```
Implement feedback loading via IFeedbackService:
- Build filter using BuildSearchFilter (Genie DNA-2) with component types + target stack
- Load top N (configurable, default 10) positive + negative feedback items
- Inject into prompt Layer 3
- Skip neutral feedback (not useful for prompt injection)

Store debug snapshot via INodeDebugger after each transform:
- All prompts, model summaries, merge result, timing
```

## Phase 6: DI Registration + Integration Tests
```
Create extension method: services.AddXIIGenAiTransform()
Register IAiTransformService → AiTransformService as singleton.

Test scenarios:
1. Single model + clean labeled response → correct parse
2. Multi-model, one failure → others succeed
3. Feedback injection with mixed ratings → prompt contains both
4. No labeled sections → sequential fallback
5. All models fail → DataProcessResult.Failure
```

## Genie DNA Checklist
- [ ] All documents use ParseObjectAlternative (DNA-1)
- [ ] Feedback queries use BuildSearchFilter (DNA-2)
- [ ] All returns use DataProcessResult<T> (DNA-3)
- [ ] AI accessed via IAiDispatcher (DNA-5)
- [ ] No fixed model classes for AI responses
- [ ] Config extracted from dynamic NodeConfig dictionary
