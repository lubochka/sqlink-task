---
name: ai-transform
description: Multi-model AI code generation with parallel dispatch, feedback injection, prompt assembly, and result merging
triggers: ai transform, ai generate, code generation, multi-model, parallel ai, prompt assembly, figma to code ai
dependencies: [01-core-interfaces, 02-object-processor, 03-elasticsearch-datastore, 06-ai-providers, 07-ai-dispatcher, 13-feedback-service]
layer: L4-StepExecutors
genie-dna: All prompts, responses, and merged results stored as dynamic documents via ObjectProcessor. Search uses BuildSearchFilter for feedback history lookup.
phase: 3
---

# Skill 11: AI Transform
## Multi-Model Parallel AI Code Generation with Feedback Loop

The **chef** of the pipeline. Takes structured component fragments (from Skill 10) and dispatches them to multiple AI models in parallel, injects feedback from previous runs, assembles prompts with context, merges the best results, and stores everything in Elasticsearch for debugging and learning.

---

## Architecture

```
Input (from Skill 10 or flow context):
  { components[], metadata, targetStack, userInstructions }
       ↓
  AiTransformService.ExecuteAsync(context)
       ↓
  ┌──────────────────────────────────┐
  │ 1. Load Feedback History         │ ← Skill 13 (positive + negative examples)
  │ 2. Load RAG Context              │ ← Skill 16 (similar past jobs)
  │ 3. Assemble Prompts per Model    │ ← System + Design + Feedback + User
  │ 4. Dispatch to N Models          │ ← Skill 07 (parallel async)
  │ 5. Parse Responses               │ ← Extract client/server/db code sections
  │ 6. Merge Best Results            │ ← Score & combine across models
  │ 7. Store Debug Snapshot          │ ← Skill 14 (all prompts + responses)
  └──────────────────────────────────┘
       ↓
  Output: { clientCode, serverCode, databaseCode, mergedScore, modelResults[] }
```

## Core Concepts

### Prompt Assembly (4 Layers)

| Layer | Source | Purpose |
|-------|--------|---------|
| System Context | Built-in template | Role definition, output format (labeled code sections) |
| Design Data | Skill 10 output | HTML, CSS, component tree, screen metadata |
| Feedback History | Skill 13 | Positive examples to repeat, negative examples to avoid |
| User Instructions | Flow input | Custom stack preferences, constraints, style |

### Multi-Model Dispatch Strategy

The service dispatches the same prompt (with model-specific adjustments) to multiple AI providers simultaneously:

```
┌─ Claude Sonnet ──→ Response A ─┐
│                                 │
├─ GPT-4o ────────→ Response B ──┤──→ ResultMerger ──→ Best Output
│                                 │
├─ Gemini Pro ────→ Response C ──┤
│                                 │
└─ Claude Opus ───→ Response D ──┘
```

Default: 2-4 models. Configurable per flow node. Each model invocation tracked separately.

### Response Parsing

Priority chain (same as FigmaCodeGenerator pattern):
1. **Labeled sections** — `// === CLIENT CODE ===`, `// === SERVER CODE ===`, `// === DATABASE CODE ===`
2. **Sequential fallback** — First code block → client, second → server, third → database
3. **Raw fallback** — Entire response → clientCode

### Result Merging Strategies

| Strategy | Description | When to Use |
|----------|-------------|-------------|
| `best-score` | Pick highest-rated single response | Default — simplest |
| `section-best` | Pick best client from one model, best server from another | Different models excel at different layers |
| `consensus` | Only keep code patterns that appear in 2+ responses | High-reliability requirements |
| `custom` | User-provided merge function | Advanced scenarios |

### Feedback Injection

When previous feedback exists for similar components:

```
## Previous Feedback (from similar conversions)

### ✅ What worked well:
- "Clean component separation with proper TypeScript types" (rating: positive)
- "Good use of CSS modules for style isolation" (rating: positive)

### ❌ What to avoid:
- "Don't use inline styles for responsive breakpoints" (rating: negative)
- "Missing error boundaries around async components" (rating: negative)

Please apply these learnings to the current generation.
```

## Configuration

```yaml
# Flow node config for AI Transform
nodeType: AiTransform
config:
  models: ["claude-sonnet", "gpt-4o"]  # Which models to use
  mergeStrategy: "section-best"         # How to combine results
  maxTokens: 4096                       # Per-model token limit
  temperature: 0.3                      # Lower = more deterministic
  feedbackLookback: 10                  # How many past feedbacks to include
  retryOnFailure: true                  # Retry failed model calls
  timeoutSeconds: 120                   # Per-model timeout
  targetStack:
    client: "react"                     # Target client framework
    server: "dotnet"                    # Target server framework
    database: "elasticsearch"           # Target database
```

## Genie DNA Integration

- **DNA-1 (Dynamic Documents):** All prompts, responses, and merged results stored via `ObjectProcessor.ParseObjectAlternative()`. No fixed response model — supports any AI output structure.
- **DNA-2 (Empty-Field Skipping):** Feedback history queries use `BuildSearchFilter` to find relevant past feedback by component type, screen name, or user.
- **DNA-3 (DataProcessResult):** Every model call returns `DataProcessResult<AiModelResponse>` with structured error handling.
- **DNA-5 (Generic Provider):** AI models accessed via `IAiProvider` interface from Skill 06, dispatched through `IAiDispatcher` from Skill 07.

## Key Interfaces

```csharp
public interface IAiTransformService
{
    Task<DataProcessResult<TransformOutput>> ExecuteAsync(
        FlowStepContext context, CancellationToken ct = default);

    Task<DataProcessResult<TransformOutput>> TransformComponentsAsync(
        IReadOnlyList<dynamic> components, TransformConfig config,
        CancellationToken ct = default);

    Task<string> AssemblePromptAsync(
        IReadOnlyList<dynamic> components, TransformConfig config,
        IReadOnlyList<dynamic> feedbackHistory, CancellationToken ct = default);

    Task<DataProcessResult<MergedResult>> MergeResultsAsync(
        IReadOnlyList<ModelResponse> responses, string mergeStrategy,
        CancellationToken ct = default);
}
```

## Dependencies

| Skill | Usage |
|-------|-------|
| 01-core-interfaces | DataProcessResult, IService base |
| 02-object-processor | ParseObjectAlternative for all documents |
| 06-ai-providers | IAiProvider for model communication |
| 07-ai-dispatcher | Parallel multi-model dispatch + retry |
| 13-feedback-service | Load past feedback for prompt injection |
| 14-node-debugger | Store debug snapshots (prompts + responses) |
| 03-elasticsearch | Persistent storage of all transform data |

## Error Handling

- Individual model failure: logged, other models continue
- All models fail: return DataProcessResult.Failure with aggregated errors
- Timeout: configurable per-model, default 120s
- Rate limiting: exponential backoff via Skill 07
- Parse failure: raw response preserved in debug snapshot

## Test Scenarios

1. Single model transform with clean response → parsed correctly
2. Multi-model dispatch, one fails → remaining succeed, failure logged
3. Feedback injection with 5 positive + 3 negative → prompt contains both
4. Response with no labeled sections → sequential fallback works
5. Merge strategy "consensus" with 3 models → only shared patterns kept
6. Timeout on all models → DataProcessResult.Failure returned
7. Dynamic document storage → any field structure preserved
