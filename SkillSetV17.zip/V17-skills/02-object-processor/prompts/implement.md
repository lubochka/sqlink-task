# Implement Skill 02: Object Processor

## Prerequisites
- Skill 01 (Core Interfaces) implemented
- .NET 9 SDK

## Step 1: Add to XIIGen.Shared Project
```bash
dotnet new classlib -n XIIGen.Shared -f net9.0
dotnet add XIIGen.Shared reference XIIGen.Core
```

## Step 2: Copy ObjectProcessor.cs
Copy the implementation from `Implementation/ObjectProcessor.cs` into `XIIGen.Shared/ObjectProcessor.cs`.

## Step 3: Register in DI
The ObjectProcessor is already registered by `AddXIIGenCore()` from Skill 01:
```csharp
services.AddSingleton<IObjectProcessor, ObjectProcessor>();
```

## Step 4: Test
```csharp
// Parse any object
var proc = new ObjectProcessor();
var doc = proc.ParseDocument(new { Name = "Test", Nested = new { X = 1 } });
Assert.True(doc.ContainsKey("name"));

// Build filters — empty fields skipped
var filters = proc.BuildQueryFilters(new { Name = "John", Email = "" });
Assert.Single(filters); // Only Name

// Flatten nested
var flat = proc.FlattenDocument(new { A = new { B = 1 } });
Assert.Equal(1L, flat["a.b"]);
```

## Key Pattern: Empty-Field Skipping
This is the core DNA. When building query filters, ANY empty field (null, "", [], {}) is automatically excluded. This means you can pass a "search form" object where the user only filled some fields, and the query will only filter by what was provided.

## Alternative Stacks
- **Node.js:** `alternatives/nodejs/object-processor.ts`
- **Python:** `alternatives/python/object_processor.py`
- **Java:** `alternatives/java/ObjectProcessor.java`
- **Rust:** `alternatives/rust/object_processor.rs`
- **PHP:** `alternatives/php/ObjectProcessor.php`


---

## Genie DNA Compliance — MANDATORY for All Implementations

> Before writing ANY code, classify each component:
> **MACHINE** (static): Infrastructure that enables freedom. Build once, generic, interface-based.
> **FREEDOM** (dynamic): Anything users define. No fixed models, config-driven.

### DNA Checklist — Every Implementation MUST:
☐ **DNA-1 (Dynamic Documents):** Store data as `Dictionary<string, object>` / `Record<string, any>` — NOT typed model classes. User fields preserved without schema changes.
☐ **DNA-2 (BuildSearchFilter):** All queries use BuildSearchFilter/equivalent. Empty fields auto-skipped. No entity-specific query code.
☐ **DNA-3 (MicroserviceBase):** Inherit base class with DB, queue, cache, logger built in.
☐ **DNA-5 (DataProcessResult):** All public methods return `DataProcessResult<T>`. Errors return failure, not throw exceptions.
☐ **DNA-6 (Generic Interfaces):** External dependencies behind interfaces. Swap via config.
☐ **DNA-SCOPE:** Non-admin queries auto-inject userId filter. Cannot be bypassed.

### The Three Tests:
1. Can a business user change this without a developer? (YES = correct)
2. Does it work for entity types that do not exist yet? (YES = correct)
3. Can I swap the database/service/UI without changing this? (YES = correct)
