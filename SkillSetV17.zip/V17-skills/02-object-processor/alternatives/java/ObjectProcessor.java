// Skill 02: Object Processor — Java / Jackson
// ParseObjectAlternative + CreateQueryContainerList pattern
package com.xiigen.shared;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.xiigen.core.*;
import java.util.*;

public class ObjectProcessor implements IObjectProcessor {
    private static final ObjectMapper mapper = new ObjectMapper();

    @Override
    public Map<String, Object> parseDocument(Object document) {
        if (document == null) return new HashMap<>();
        if (document instanceof Map) return deepParse((Map<String, Object>) document);
        try {
            JsonNode node = document instanceof String
                ? mapper.readTree((String) document)
                : mapper.valueToTree(document);
            return jsonNodeToMap(node);
        } catch (Exception e) { return new HashMap<>(); }
    }

    private Map<String, Object> deepParse(Map<String, Object> obj) {
        Map<String, Object> result = new LinkedHashMap<>();
        for (var entry : obj.entrySet()) {
            Object value = entry.getValue();
            if (value instanceof Map) result.put(entry.getKey(), deepParse((Map<String, Object>) value));
            else if (value instanceof List) result.put(entry.getKey(), ((List<?>) value).stream()
                .map(v -> v instanceof Map ? deepParse((Map<String, Object>) v) : inferType(v)).toList());
            else result.put(entry.getKey(), inferType(value));
        }
        return result;
    }

    private Object inferType(Object value) {
        if (value == null) return null;
        if (value instanceof Boolean || value instanceof Number) return value;
        if (value instanceof String s) {
            if ("true".equalsIgnoreCase(s) || "false".equalsIgnoreCase(s)) return Boolean.parseBoolean(s);
            try { return Long.parseLong(s); } catch (NumberFormatException ignored) {}
            try { return Double.parseDouble(s); } catch (NumberFormatException ignored) {}
        }
        return value;
    }

    @Override
    public List<SearchCondition> buildQueryFilters(Object filterObject) {
        List<SearchCondition> conditions = new ArrayList<>();
        Map<String, Object> parsed = parseDocument(filterObject);
        buildFiltersRecursive(parsed, "", conditions);
        return conditions;
    }

    private void buildFiltersRecursive(Map<String, Object> obj, String prefix, List<SearchCondition> conditions) {
        for (var entry : obj.entrySet()) {
            if (isEmpty(entry.getValue())) continue; // SKIP empty — the DNA
            String fullKey = prefix.isEmpty() ? entry.getKey() : prefix + "." + entry.getKey();
            Object value = entry.getValue();
            if (value instanceof Map) buildFiltersRecursive((Map<String, Object>) value, fullKey, conditions);
            else if (value instanceof List list && !list.isEmpty())
                conditions.add(new SearchCondition(fullKey, QueryType.IN, value, null));
            else conditions.add(new SearchCondition(fullKey, inferQueryType(value), value, null));
        }
    }

    public boolean isEmpty(Object value) {
        if (value == null) return true;
        if (value instanceof String s) return s.isBlank();
        if (value instanceof Collection<?> c) return c.isEmpty();
        if (value instanceof Map<?,?> m) return m.isEmpty();
        return false;
    }

    public Map<String, Object> flattenDocument(Object document, String prefix) {
        Map<String, Object> result = new LinkedHashMap<>();
        flattenRecursive(parseDocument(document), prefix, result);
        return result;
    }

    private void flattenRecursive(Map<String, Object> obj, String prefix, Map<String, Object> result) {
        for (var entry : obj.entrySet()) {
            String fullKey = prefix.isEmpty() ? entry.getKey() : prefix + "." + entry.getKey();
            if (entry.getValue() instanceof Map) flattenRecursive((Map<String, Object>) entry.getValue(), fullKey, result);
            else result.put(fullKey, entry.getValue());
        }
    }

    public Map<String, Object> mergeDocuments(Object original, Object update) {
        Map<String, Object> orig = parseDocument(original);
        for (var entry : parseDocument(update).entrySet())
            if (!isEmpty(entry.getValue())) orig.put(entry.getKey(), entry.getValue());
        return orig;
    }

    @Override
    public String inferFieldType(Object value) {
        if (value == null) return "null";
        if (value instanceof Boolean) return "boolean";
        if (value instanceof Long || value instanceof Integer) return "long";
        if (value instanceof Double || value instanceof Float) return "double";
        if (value instanceof String) return "text";
        if (value instanceof List) return "nested";
        if (value instanceof Map) return "object";
        return "text";
    }

    private QueryType inferQueryType(Object value) {
        if (value instanceof String s && s.contains("*")) return QueryType.PREFIX;
        if (value instanceof String s && s.length() > 50) return QueryType.CONTAINS;
        return QueryType.EQUALS;
    }

    private Map<String, Object> jsonNodeToMap(JsonNode node) {
        Map<String, Object> result = new LinkedHashMap<>();
        if (!node.isObject()) return result;
        node.fields().forEachRemaining(entry -> result.put(entry.getKey(), convertNode(entry.getValue())));
        return result;
    }

    private Object convertNode(JsonNode node) {
        if (node.isObject()) return jsonNodeToMap(node);
        if (node.isArray()) { List<Object> list = new ArrayList<>(); node.forEach(n -> list.add(convertNode(n))); return list; }
        if (node.isBoolean()) return node.booleanValue();
        if (node.isLong() || node.isInt()) return node.longValue();
        if (node.isDouble() || node.isFloat()) return node.doubleValue();
        if (node.isTextual()) return node.textValue();
        return null;
    }
}
