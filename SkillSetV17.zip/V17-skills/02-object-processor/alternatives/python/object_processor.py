# Skill 02: Object Processor — Python
# ParseObjectAlternative + CreateQueryContainerList pattern

from datetime import datetime
from typing import Any
from core_interfaces import SearchCondition, QueryType

class ObjectProcessor:
    """The DNA pattern: dynamic document parsing + auto-skip-empty query building."""

    def parse_document(self, document: Any) -> dict[str, Any]:
        if document is None: return {}
        if isinstance(document, dict): return self._deep_parse(document)
        if isinstance(document, str):
            import json
            try: return self._deep_parse(json.loads(document))
            except: return {}
        if hasattr(document, "__dict__"): return self._deep_parse(vars(document))
        return {}

    def _deep_parse(self, obj: dict) -> dict[str, Any]:
        result = {}
        for key, value in obj.items():
            if isinstance(value, dict):
                result[key] = self._deep_parse(value)
            elif isinstance(value, list):
                result[key] = [self._deep_parse(v) if isinstance(v, dict) else self._infer_type(v) for v in value]
            else:
                result[key] = self._infer_type(value)
        return result

    def _infer_type(self, value: Any) -> Any:
        if value is None: return None
        if isinstance(value, (bool, int, float)): return value
        if isinstance(value, str):
            if value.lower() in ("true", "false"): return value.lower() == "true"
            try: return int(value)
            except ValueError: pass
            try: return float(value)
            except ValueError: pass
            try: datetime.fromisoformat(value); return value
            except: pass
        return value

    def build_query_filters(self, filter_object: Any) -> list[SearchCondition]:
        """CreateQueryContainerList: only non-empty fields become conditions."""
        conditions: list[SearchCondition] = []
        parsed = self.parse_document(filter_object)
        self._build_recursive(parsed, "", conditions)
        return conditions

    def _build_recursive(self, obj: dict, prefix: str, conditions: list):
        for key, value in obj.items():
            if self.is_empty(value): continue  # SKIP empty — the DNA
            full_key = f"{prefix}.{key}" if prefix else key
            if isinstance(value, dict):
                self._build_recursive(value, full_key, conditions)
            elif isinstance(value, list) and len(value) > 0:
                conditions.append(SearchCondition(property=full_key, query_type=QueryType.IN, value=value))
            else:
                qt = QueryType.PREFIX if isinstance(value, str) and "*" in value else QueryType.EQUALS
                conditions.append(SearchCondition(property=full_key, query_type=qt, value=value))

    def is_empty(self, value: Any) -> bool:
        if value is None: return True
        if isinstance(value, str): return value.strip() == ""
        if isinstance(value, (list, dict)): return len(value) == 0
        return False

    def flatten_document(self, document: Any, prefix: str = "") -> dict[str, Any]:
        result = {}
        parsed = self.parse_document(document)
        self._flatten_recursive(parsed, prefix, result)
        return result

    def _flatten_recursive(self, obj: dict, prefix: str, result: dict):
        for key, value in obj.items():
            full_key = f"{prefix}.{key}" if prefix else key
            if isinstance(value, dict): self._flatten_recursive(value, full_key, result)
            else: result[full_key] = value

    def merge_documents(self, original: Any, update: Any) -> dict[str, Any]:
        orig = self.parse_document(original)
        for key, value in self.parse_document(update).items():
            if not self.is_empty(value): orig[key] = value
        return orig

    def infer_field_type(self, value: Any) -> str:
        if value is None: return "null"
        if isinstance(value, bool): return "boolean"
        if isinstance(value, int): return "long"
        if isinstance(value, float): return "double"
        if isinstance(value, str): return "text"
        if isinstance(value, list): return "nested"
        if isinstance(value, dict): return "object"
        return "text"
