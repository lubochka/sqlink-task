// Skill 02: Object Processor — Rust
// ParseObjectAlternative + CreateQueryContainerList pattern

use serde_json::{Map, Value};
use crate::core_interfaces::{SearchCondition, QueryType};
use std::collections::HashMap;

pub struct ObjectProcessor;

impl ObjectProcessor {
    pub fn parse_document(&self, document: Value) -> HashMap<String, Value> {
        match document {
            Value::Object(map) => self.deep_parse(map),
            Value::String(s) => {
                if let Ok(Value::Object(map)) = serde_json::from_str(&s) {
                    self.deep_parse(map)
                } else { HashMap::new() }
            }
            _ => HashMap::new(),
        }
    }

    fn deep_parse(&self, obj: Map<String, Value>) -> HashMap<String, Value> {
        let mut result = HashMap::new();
        for (key, value) in obj {
            match &value {
                Value::Object(nested) => {
                    result.insert(key, Value::Object(
                        self.deep_parse(nested.clone()).into_iter()
                            .map(|(k, v)| (k, v)).collect()
                    ));
                }
                Value::Array(arr) => {
                    let parsed: Vec<Value> = arr.iter().map(|v| match v {
                        Value::Object(m) => Value::Object(
                            self.deep_parse(m.clone()).into_iter().collect()
                        ),
                        _ => self.infer_type(v.clone()),
                    }).collect();
                    result.insert(key, Value::Array(parsed));
                }
                _ => { result.insert(key, self.infer_type(value)); }
            }
        }
        result
    }

    fn infer_type(&self, value: Value) -> Value {
        match &value {
            Value::String(s) => {
                if s == "true" || s == "false" { return Value::Bool(s == "true"); }
                if let Ok(n) = s.parse::<i64>() { return Value::Number(n.into()); }
                if let Ok(n) = s.parse::<f64>() {
                    return serde_json::Number::from_f64(n).map(Value::Number).unwrap_or(value);
                }
                value
            }
            _ => value,
        }
    }

    /// CreateQueryContainerList: only non-empty fields become conditions
    pub fn build_query_filters(&self, filter: Value) -> Vec<SearchCondition> {
        let mut conditions = Vec::new();
        let parsed = self.parse_document(filter);
        self.build_recursive(&parsed, "", &mut conditions);
        conditions
    }

    fn build_recursive(&self, obj: &HashMap<String, Value>, prefix: &str, conditions: &mut Vec<SearchCondition>) {
        for (key, value) in obj {
            if self.is_empty(value) { continue; } // SKIP empty — the DNA
            let full_key = if prefix.is_empty() { key.clone() } else { format!("{}.{}", prefix, key) };
            match value {
                Value::Object(nested) => {
                    let map: HashMap<String, Value> = nested.iter().map(|(k, v)| (k.clone(), v.clone())).collect();
                    self.build_recursive(&map, &full_key, conditions);
                }
                Value::Array(arr) if !arr.is_empty() => {
                    conditions.push(SearchCondition { property: full_key, query_type: QueryType::In, value: value.clone(), value_to: None });
                }
                _ => {
                    let qt = self.infer_query_type(value);
                    conditions.push(SearchCondition { property: full_key, query_type: qt, value: value.clone(), value_to: None });
                }
            }
        }
    }

    pub fn is_empty(&self, value: &Value) -> bool {
        match value {
            Value::Null => true,
            Value::String(s) => s.trim().is_empty(),
            Value::Array(a) => a.is_empty(),
            Value::Object(o) => o.is_empty(),
            _ => false,
        }
    }

    pub fn flatten_document(&self, document: Value) -> HashMap<String, Value> {
        let mut result = HashMap::new();
        let parsed = self.parse_document(document);
        self.flatten_recursive(&parsed, "", &mut result);
        result
    }

    fn flatten_recursive(&self, obj: &HashMap<String, Value>, prefix: &str, result: &mut HashMap<String, Value>) {
        for (key, value) in obj {
            let full_key = if prefix.is_empty() { key.clone() } else { format!("{}.{}", prefix, key) };
            if let Value::Object(nested) = value {
                let map: HashMap<String, Value> = nested.iter().map(|(k, v)| (k.clone(), v.clone())).collect();
                self.flatten_recursive(&map, &full_key, result);
            } else {
                result.insert(full_key, value.clone());
            }
        }
    }

    pub fn merge_documents(&self, original: Value, update: Value) -> HashMap<String, Value> {
        let mut orig = self.parse_document(original);
        for (key, value) in self.parse_document(update) {
            if !self.is_empty(&value) { orig.insert(key, value); }
        }
        orig
    }

    pub fn infer_field_type(&self, value: &Value) -> &str {
        match value {
            Value::Null => "null", Value::Bool(_) => "boolean",
            Value::Number(n) => if n.is_i64() { "long" } else { "double" },
            Value::String(_) => "text", Value::Array(_) => "nested",
            Value::Object(_) => "object",
        }
    }

    fn infer_query_type(&self, value: &Value) -> QueryType {
        match value {
            Value::String(s) if s.contains('*') => QueryType::Prefix,
            Value::String(s) if s.len() > 50 => QueryType::Contains,
            _ => QueryType::Equals,
        }
    }
}
