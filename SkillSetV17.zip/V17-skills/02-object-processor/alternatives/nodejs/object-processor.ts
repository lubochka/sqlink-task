// Skill 02: Object Processor — Node.js/TypeScript
// ParseObjectAlternative + CreateQueryContainerList pattern

import { SearchCondition, QueryType } from "./core-interfaces";

export class ObjectProcessor {
  parseDocument(document: unknown): Record<string, unknown> {
    if (document === null || document === undefined) return {};
    if (typeof document === "object" && !Array.isArray(document)) {
      return this.flatParse(document as Record<string, unknown>);
    }
    if (typeof document === "string") {
      try { return this.flatParse(JSON.parse(document)); } catch { return {}; }
    }
    return {};
  }

  private flatParse(obj: Record<string, unknown>): Record<string, unknown> {
    const result: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(obj)) {
      if (value !== null && typeof value === "object" && !Array.isArray(value)) {
        result[key] = this.flatParse(value as Record<string, unknown>);
      } else if (Array.isArray(value)) {
        result[key] = value.map(v => typeof v === "object" && v !== null ? this.flatParse(v as Record<string, unknown>) : this.inferType(v));
      } else {
        result[key] = this.inferType(value);
      }
    }
    return result;
  }

  private inferType(value: unknown): unknown {
    if (value === null || value === undefined) return null;
    if (typeof value === "boolean" || typeof value === "number") return value;
    if (typeof value === "string") {
      if (value === "true" || value === "false") return value === "true";
      const num = Number(value);
      if (!isNaN(num) && value.trim() !== "") return num;
      const d = Date.parse(value);
      if (!isNaN(d) && value.length > 5) return new Date(d).toISOString();
    }
    return value;
  }

  // CreateQueryContainerList: only non-empty fields become conditions
  buildQueryFilters(filterObject: unknown): SearchCondition[] {
    const conditions: SearchCondition[] = [];
    const parsed = this.parseDocument(filterObject);
    this.buildFiltersRecursive(parsed, "", conditions);
    return conditions;
  }

  private buildFiltersRecursive(obj: Record<string, unknown>, prefix: string, conditions: SearchCondition[]): void {
    for (const [key, value] of Object.entries(obj)) {
      if (this.isEmpty(value)) continue; // SKIP empty — the DNA pattern
      const fullKey = prefix ? `${prefix}.${key}` : key;
      if (typeof value === "object" && value !== null && !Array.isArray(value)) {
        this.buildFiltersRecursive(value as Record<string, unknown>, fullKey, conditions);
      } else if (Array.isArray(value) && value.length > 0) {
        conditions.push({ property: fullKey, queryType: QueryType.In, value });
      } else {
        conditions.push({ property: fullKey, queryType: this.inferQueryType(value), value });
      }
    }
  }

  isEmpty(value: unknown): boolean {
    if (value === null || value === undefined) return true;
    if (typeof value === "string") return value.trim() === "";
    if (Array.isArray(value)) return value.length === 0;
    if (typeof value === "object") return Object.keys(value).length === 0;
    return false;
  }

  flattenDocument(document: unknown, prefix = ""): Record<string, unknown> {
    const result: Record<string, unknown> = {};
    const parsed = this.parseDocument(document);
    this.flattenRecursive(parsed, prefix, result);
    return result;
  }

  private flattenRecursive(obj: Record<string, unknown>, prefix: string, result: Record<string, unknown>): void {
    for (const [key, value] of Object.entries(obj)) {
      const fullKey = prefix ? `${prefix}.${key}` : key;
      if (typeof value === "object" && value !== null && !Array.isArray(value)) {
        this.flattenRecursive(value as Record<string, unknown>, fullKey, result);
      } else { result[fullKey] = value; }
    }
  }

  mergeDocuments(original: unknown, update: unknown): Record<string, unknown> {
    const orig = this.parseDocument(original);
    const upd = this.parseDocument(update);
    for (const [key, value] of Object.entries(upd)) {
      if (!this.isEmpty(value)) orig[key] = value;
    }
    return orig;
  }

  inferFieldType(value: unknown): string {
    if (value === null || value === undefined) return "null";
    if (typeof value === "boolean") return "boolean";
    if (typeof value === "number") return Number.isInteger(value) ? "long" : "double";
    if (value instanceof Date) return "date";
    if (typeof value === "string") return "text";
    if (Array.isArray(value)) return "nested";
    if (typeof value === "object") return "object";
    return "text";
  }

  private inferQueryType(value: unknown): QueryType {
    if (typeof value === "string" && value.includes("*")) return QueryType.Prefix;
    if (typeof value === "string" && value.length > 50) return QueryType.Contains;
    return QueryType.Equals;
  }
}
