<?php
// Skill 02: Object Processor — PHP 8.3
// ParseObjectAlternative + CreateQueryContainerList pattern

namespace XIIGen\Shared;

use XIIGen\Core\SearchCondition;
use XIIGen\Core\QueryType;
use XIIGen\Core\IObjectProcessor;

class ObjectProcessor implements IObjectProcessor
{
    /**
     * ParseObjectAlternative: recursively convert any input to associative array
     */
    public function parseDocument(mixed $document): array
    {
        if ($document === null) return [];
        if (is_array($document)) return $this->deepParse($document);
        if (is_string($document)) {
            $decoded = json_decode($document, true);
            return is_array($decoded) ? $this->deepParse($decoded) : [];
        }
        if (is_object($document)) return $this->deepParse((array)$document);
        return [];
    }

    private function deepParse(array $obj): array
    {
        $result = [];
        foreach ($obj as $key => $value) {
            if (is_array($value) && $this->isAssoc($value)) {
                $result[$key] = $this->deepParse($value);
            } elseif (is_array($value)) {
                $result[$key] = array_map(
                    fn($v) => is_array($v) && $this->isAssoc($v) ? $this->deepParse($v) : $this->inferType($v),
                    $value
                );
            } else {
                $result[$key] = $this->inferType($value);
            }
        }
        return $result;
    }

    private function inferType(mixed $value): mixed
    {
        if ($value === null) return null;
        if (is_bool($value) || is_int($value) || is_float($value)) return $value;
        if (is_string($value)) {
            if (strtolower($value) === 'true') return true;
            if (strtolower($value) === 'false') return false;
            if (ctype_digit($value)) return (int)$value;
            if (is_numeric($value)) return (float)$value;
        }
        return $value;
    }

    /**
     * CreateQueryContainerList: only non-empty fields become query conditions
     */
    public function buildQueryFilters(mixed $filterObject): array
    {
        $conditions = [];
        $parsed = $this->parseDocument($filterObject);
        $this->buildFiltersRecursive($parsed, '', $conditions);
        return $conditions;
    }

    private function buildFiltersRecursive(array $obj, string $prefix, array &$conditions): void
    {
        foreach ($obj as $key => $value) {
            if ($this->isEmpty($value)) continue; // SKIP empty — the DNA pattern
            $fullKey = $prefix === '' ? $key : "{$prefix}.{$key}";

            if (is_array($value) && $this->isAssoc($value)) {
                $this->buildFiltersRecursive($value, $fullKey, $conditions);
            } elseif (is_array($value) && count($value) > 0) {
                $conditions[] = new SearchCondition(property: $fullKey, queryType: QueryType::In, value: $value);
            } else {
                $qt = $this->inferQueryType($value);
                $conditions[] = new SearchCondition(property: $fullKey, queryType: $qt, value: $value);
            }
        }
    }

    public function isEmpty(mixed $value): bool
    {
        if ($value === null) return true;
        if (is_string($value)) return trim($value) === '';
        if (is_array($value)) return count($value) === 0;
        return false;
    }

    public function flattenDocument(mixed $document, string $prefix = ''): array
    {
        $result = [];
        $this->flattenRecursive($this->parseDocument($document), $prefix, $result);
        return $result;
    }

    private function flattenRecursive(array $obj, string $prefix, array &$result): void
    {
        foreach ($obj as $key => $value) {
            $fullKey = $prefix === '' ? $key : "{$prefix}.{$key}";
            if (is_array($value) && $this->isAssoc($value)) {
                $this->flattenRecursive($value, $fullKey, $result);
            } else {
                $result[$fullKey] = $value;
            }
        }
    }

    public function mergeDocuments(mixed $original, mixed $update): array
    {
        $orig = $this->parseDocument($original);
        foreach ($this->parseDocument($update) as $key => $value) {
            if (!$this->isEmpty($value)) $orig[$key] = $value;
        }
        return $orig;
    }

    public function inferFieldType(mixed $value): string
    {
        return match (true) {
            $value === null => 'null',
            is_bool($value) => 'boolean',
            is_int($value) => 'long',
            is_float($value) => 'double',
            is_string($value) => 'text',
            is_array($value) && $this->isAssoc($value) => 'object',
            is_array($value) => 'nested',
            default => 'text',
        };
    }

    private function inferQueryType(mixed $value): QueryType
    {
        if (is_string($value) && str_contains($value, '*')) return QueryType::Prefix;
        if (is_string($value) && strlen($value) > 50) return QueryType::Contains;
        return QueryType::Equals;
    }

    private function isAssoc(array $arr): bool
    {
        return array_keys($arr) !== range(0, count($arr) - 1);
    }
}
