// XIIGen.Shared/ObjectProcessor.cs - Skill 02 | .NET 9
using System.Text.Json;
using XIIGen.Core.Enums;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Shared;

public class ObjectProcessor : IObjectProcessor
{
    private static readonly JsonSerializerOptions JsonOpts = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        PropertyNameCaseInsensitive = true,
        WriteIndented = false
    };

    public Dictionary<string, object> ParseDocument(object document)
    {
        if (document is null) return [];
        if (document is Dictionary<string, object> dict) return dict;
        var json = document is JsonElement je ? je : JsonSerializer.SerializeToElement(document, JsonOpts);
        return ParseJsonElement(json);
    }

    public List<SearchCondition> BuildQueryFilters(object filterObject)
    {
        // CreateQueryContainerList pattern: only non-empty fields become query conditions
        var conditions = new List<SearchCondition>();
        var parsed = ParseDocument(filterObject);
        BuildFiltersRecursive(parsed, "", conditions);
        return conditions;
    }

    private void BuildFiltersRecursive(Dictionary<string, object> obj, string prefix, List<SearchCondition> conditions)
    {
        foreach (var (key, value) in obj)
        {
            if (IsEmpty(value)) continue;
            var fullKey = string.IsNullOrEmpty(prefix) ? key : $"{prefix}.{key}";

            if (value is Dictionary<string, object> nested)
            {
                BuildFiltersRecursive(nested, fullKey, conditions);
            }
            else if (value is List<object> list && list.Count > 0 && list.All(i => !IsEmpty(i)))
            {
                conditions.Add(new SearchCondition { Property = fullKey, QueryType = QueryType.In, Value = list });
            }
            else
            {
                var qt = InferQueryType(value);
                conditions.Add(new SearchCondition { Property = fullKey, QueryType = qt, Value = value });
            }
        }
    }

    public string InferFieldType(object value) => value switch
    {
        null => "null",
        bool => "boolean",
        int or long => "long",
        float or double or decimal => "double",
        DateTime => "date",
        string s when DateTime.TryParse(s, out _) => "date",
        string s when long.TryParse(s, out _) => "long",
        string s when double.TryParse(s, out _) => "double",
        string => "text",
        Dictionary<string, object> => "object",
        List<object> => "nested",
        _ => "text"
    };

    private static QueryType InferQueryType(object value) => value switch
    {
        string s when s.Contains('*') => QueryType.Wildcard,
        string s when s.Length > 50 => QueryType.Contains,
        string => QueryType.Equal,
        _ => QueryType.Equal
    };

    public Dictionary<string, object> FlattenDocument(object document, string prefix = "")
    {
        var result = new Dictionary<string, object>();
        var parsed = ParseDocument(document);
        FlattenRecursive(parsed, prefix, result);
        return result;
    }

    private void FlattenRecursive(Dictionary<string, object> obj, string prefix, Dictionary<string, object> result)
    {
        foreach (var (key, value) in obj)
        {
            var fullKey = string.IsNullOrEmpty(prefix) ? key : $"{prefix}.{key}";
            if (value is Dictionary<string, object> nested) FlattenRecursive(nested, fullKey, result);
            else result[fullKey] = value;
        }
    }

    public object MergeDocuments(object original, object update)
    {
        var orig = ParseDocument(original);
        var upd = ParseDocument(update);
        foreach (var (key, value) in upd)
        {
            if (!IsEmpty(value)) orig[key] = value;
        }
        return orig;
    }

    public bool IsEmpty(object value) => value switch
    {
        null => true,
        string s => string.IsNullOrWhiteSpace(s),
        List<object> l => l.Count == 0 || l.All(IsEmpty),
        Dictionary<string, object> d => d.Count == 0,
        JsonElement je => je.ValueKind == JsonValueKind.Null || je.ValueKind == JsonValueKind.Undefined,
        _ => false
    };

    private Dictionary<string, object> ParseJsonElement(JsonElement element)
    {
        var result = new Dictionary<string, object>();
        if (element.ValueKind != JsonValueKind.Object) return result;

        foreach (var prop in element.EnumerateObject())
        {
            result[prop.Name] = ConvertJsonValue(prop.Value);
        }
        return result;
    }

    private object ConvertJsonValue(JsonElement element) => element.ValueKind switch
    {
        JsonValueKind.Object => ParseJsonElement(element),
        JsonValueKind.Array => element.EnumerateArray().Select(ConvertJsonValue).ToList(),
        JsonValueKind.String => element.GetString(),
        JsonValueKind.Number => element.TryGetInt64(out var l) ? l : element.GetDouble(),
        JsonValueKind.True => true,
        JsonValueKind.False => false,
        _ => null
    };
}
