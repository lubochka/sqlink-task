# Skill 02: Object Processor
## Dynamic Document Parsing & Query Building — The XIIGen DNA Pattern

**Status:** Ready to Generate  
**Priority:** P0 — Core pattern, used by every database operation  
**Dependencies:** Skill 01 (Core Interfaces)  
**Layer:** L1: Foundation  
**Phase:** 1  
**Estimated LOC:** ~150  

---

## Overview

The Object Processor is the **genetic code of XIIGen**. It originated as PHP's `DF_DataBase` (2013), evolved through WordPress dynamic forms, and now lives as .NET 9's `ObjectProcessor`. It does two critical things:

1. **ParseDocument** — Takes ANY incoming JSON/object and recursively converts it to `Dictionary<string, object>` with automatic type inference (int, decimal, DateTime, bool, string). No schemas needed.
2. **BuildQueryFilters** (CreateQueryContainerList pattern) — Takes a filter object and only generates query conditions for non-null, non-empty fields. Empty fields are automatically skipped.

This enables the entire platform to work without fixed schemas or migrations.

## Key Concepts

- **ParseObjectAlternative** → `ParseDocument()` — Recursive JSON→Dictionary conversion with type detection
- **CreateQueryContainerList** → `BuildQueryFilters()` — Only non-empty fields become query conditions
- **IsEmpty** — Checks null, empty string, empty array, empty object, JsonElement.Null
- **FlattenDocument** — Converts nested `{a: {b: 1}}` to flat `{"a.b": 1}` for Elasticsearch
- **MergeDocuments** — Overlay update fields onto original, skipping empty values
- **InferFieldType** — Detects: boolean, long, double, date, text, object, nested

---

## Primary Implementation (.NET 9)

### Interface (from Skill 01)

```csharp
public interface IObjectProcessor
{
    Dictionary<string, object> ParseDocument(object document);
    List<SearchCondition> BuildQueryFilters(object filterObject);
    string InferFieldType(object value);
    T MapTo<T>(Dictionary<string, object> document) where T : new();
}
```

### Full Implementation

```csharp
// File: XIIGen.Shared/ObjectProcessor.cs
namespace XIIGen.Shared;

public class ObjectProcessor : IObjectProcessor
{
    private static readonly JsonSerializerOptions JsonOpts = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        PropertyNameCaseInsensitive = true, WriteIndented = false
    };

    // ─── ParseObjectAlternative (modernized) ───
    public Dictionary<string, object> ParseDocument(object document)
    {
        if (document is null) return [];
        if (document is Dictionary<string, object> dict) return dict;
        var json = document is JsonElement je ? je : JsonSerializer.SerializeToElement(document, JsonOpts);
        return ParseJsonElement(json);
    }

    // ─── CreateQueryContainerList (modernized) ───
    public List<SearchCondition> BuildQueryFilters(object filterObject)
    {
        var conditions = new List<SearchCondition>();
        var parsed = ParseDocument(filterObject);
        BuildFiltersRecursive(parsed, "", conditions);
        return conditions; // Only non-empty fields included
    }

    private void BuildFiltersRecursive(Dictionary<string, object> obj, string prefix, List<SearchCondition> conditions)
    {
        foreach (var (key, value) in obj)
        {
            if (IsEmpty(value)) continue; // SKIP empty — the core pattern
            var fullKey = string.IsNullOrEmpty(prefix) ? key : $"{prefix}.{key}";
            if (value is Dictionary<string, object> nested) BuildFiltersRecursive(nested, fullKey, conditions);
            else if (value is List<object> list && list.Count > 0) conditions.Add(new SearchCondition { Property = fullKey, QueryType = QueryType.In, Value = list });
            else conditions.Add(new SearchCondition { Property = fullKey, QueryType = InferQueryType(value), Value = value });
        }
    }

    public string InferFieldType(object value) => value switch
    {
        null => "null", bool => "boolean", int or long => "long",
        float or double or decimal => "double", DateTime => "date",
        string s when DateTime.TryParse(s, out _) => "date",
        string s when long.TryParse(s, out _) => "long",
        string => "text", Dictionary<string, object> => "object",
        List<object> => "nested", _ => "text"
    };

    public bool IsEmpty(object value) => value switch
    {
        null => true, string s => string.IsNullOrWhiteSpace(s),
        List<object> l => l.Count == 0, Dictionary<string, object> d => d.Count == 0,
        JsonElement je => je.ValueKind is JsonValueKind.Null or JsonValueKind.Undefined,
        _ => false
    };

    public Dictionary<string, object> FlattenDocument(object document, string prefix = "")
    {
        var result = new Dictionary<string, object>();
        FlattenRecursive(ParseDocument(document), prefix, result);
        return result;
    }

    public object MergeDocuments(object original, object update)
    {
        var orig = ParseDocument(original);
        foreach (var (key, value) in ParseDocument(update))
            if (!IsEmpty(value)) orig[key] = value;
        return orig;
    }

    public T MapTo<T>(Dictionary<string, object> document) where T : new()
    {
        var json = JsonSerializer.Serialize(document, JsonOpts);
        return JsonSerializer.Deserialize<T>(json, JsonOpts) ?? new T();
    }

    private Dictionary<string, object> ParseJsonElement(JsonElement element)
    {
        var result = new Dictionary<string, object>();
        if (element.ValueKind != JsonValueKind.Object) return result;
        foreach (var prop in element.EnumerateObject()) result[prop.Name] = ConvertJsonValue(prop.Value);
        return result;
    }

    private object ConvertJsonValue(JsonElement el) => el.ValueKind switch
    {
        JsonValueKind.Object => ParseJsonElement(el),
        JsonValueKind.Array => el.EnumerateArray().Select(ConvertJsonValue).ToList(),
        JsonValueKind.String => el.GetString(),
        JsonValueKind.Number => el.TryGetInt64(out var l) ? l : el.GetDouble(),
        JsonValueKind.True => true, JsonValueKind.False => false, _ => null
    };

    private static QueryType InferQueryType(object value) => value switch
    {
        string s when s.Contains('*') => QueryType.Prefix,
        string s when s.Length > 50 => QueryType.Contains,
        _ => QueryType.Equals
    };

    private void FlattenRecursive(Dictionary<string, object> obj, string prefix, Dictionary<string, object> result)
    {
        foreach (var (key, value) in obj)
        {
            var fullKey = string.IsNullOrEmpty(prefix) ? key : $"{prefix}.{key}";
            if (value is Dictionary<string, object> nested) FlattenRecursive(nested, fullKey, result);
            else result[fullKey] = value;
        }
    }
}
```

### Usage Examples

```csharp
var processor = new ObjectProcessor();

// Parse any JSON into dynamic dictionary
var doc = processor.ParseDocument(new { Name = "John", Age = 30, Address = new { City = "TLV" } });
// → {"name": "John", "age": 30, "address": {"city": "TLV"}}

// Build query filters — empty fields auto-skipped
var filters = processor.BuildQueryFilters(new { Name = "John", Email = "", Age = (int?)null });
// → [SearchCondition { Property = "name", Value = "John" }]  ← only Name included!

// Flatten for Elasticsearch
var flat = processor.FlattenDocument(doc);
// → {"name": "John", "age": 30, "address.city": "TLV"}

// Merge (overlay update onto original)
var merged = processor.MergeDocuments(doc, new { Name = "Jane", Phone = "" });
// → Name updated to "Jane", Phone skipped (empty), Age preserved
```

---

## Unit Tests

```csharp
[Fact] public void ParseDocument_ConvertsAnonymousObject() { var r = new ObjectProcessor().ParseDocument(new { A = 1 }); Assert.Equal(1L, r["a"]); }
[Fact] public void BuildQueryFilters_SkipsEmpty() { var r = new ObjectProcessor().BuildQueryFilters(new { Name = "X", Email = "" }); Assert.Single(r); }
[Fact] public void FlattenDocument_FlattensNested() { var r = new ObjectProcessor().FlattenDocument(new { A = new { B = 1 } }); Assert.Equal(1L, r["a.b"]); }
[Fact] public void MergeDocuments_SkipsEmptyValues() { var r = new ObjectProcessor().MergeDocuments(new { A = 1 }, new { A = 2, B = "" }); Assert.Equal(2L, ((Dictionary<string, object>)r)["a"]); }
[Fact] public void IsEmpty_DetectsAllEmpty() { var p = new ObjectProcessor(); Assert.True(p.IsEmpty(null)); Assert.True(p.IsEmpty("")); Assert.True(p.IsEmpty("   ")); Assert.False(p.IsEmpty("x")); }
```

## Anti-Patterns
- **Don't** create typed models for stored documents — use ParseDocument for everything
- **Don't** manually check each filter field — BuildQueryFilters does it automatically
- **Don't** use Newtonsoft.Json — stick with System.Text.Json for .NET 9
