// XIIGen Content Generation Pipeline — Java | Skill 40
package com.xiigen.pipeline.content;
import com.xiigen.core.*;
import java.util.*;

public class ContentPipelineExecutor extends MicroserviceBase {
    private final Map<String, IAiProvider> providers = new HashMap<>();

    public ContentPipelineExecutor(IDatabaseService db, IQueueService queue, List<IAiProvider> aiProviders) {
        super(db, queue, "content-pipeline");
        if (aiProviders != null) aiProviders.forEach(p -> providers.put(p.getProviderName(), p));
    }

    public DataProcessResult<Map<String, Object>> executeStep(String subStep, Map<String, Object> inputs, Map<String, Object> config) throws Exception {
        return switch (subStep) {
            case "generate-script" -> generateScript((String) inputs.getOrDefault("topic", ""), (String) inputs.getOrDefault("style", "engaging"));
            case "full" -> fullPipeline(inputs, config);
            default -> DataProcessResult.failure("Unknown sub-step: " + subStep);
        };
    }

    private DataProcessResult<Map<String, Object>> generateScript(String topic, String style) throws Exception {
        var ai = providers.values().stream().findFirst().orElse(null);
        if (ai == null) return DataProcessResult.failure("No AI provider");
        var result = ai.complete("Create a short-form video script about: " + topic + ". Style: " + style);
        return DataProcessResult.success(Map.of("script", result, "topic", topic));
    }

    private DataProcessResult<Map<String, Object>> fullPipeline(Map<String, Object> inputs, Map<String, Object> config) throws Exception {
        var script = generateScript((String) inputs.getOrDefault("topic", ""), (String) inputs.getOrDefault("style", "engaging"));
        if (!script.isSuccess()) return script;
        storeDocument("content-jobs", inputs.getOrDefault("traceId", "unknown").toString(), Map.of("step", "script", "data", script.getData()));
        return DataProcessResult.success(Map.of("pipeline", "started", "data", script.getData()));
    }
}
