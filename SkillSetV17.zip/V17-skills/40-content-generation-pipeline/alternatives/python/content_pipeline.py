# XIIGen Content Generation Pipeline — Python | Skill 40
from typing import Optional
from core_interfaces import IDatabaseService, IQueueService, IAiProvider, DataProcessResult, MicroserviceBase

PLATFORM_TEMPLATES = {
    "tiktok": {"platform": "tiktok", "width": 1080, "height": 1920, "maxDurationSec": 60, "maxCaptionLength": 2200},
    "instagram-reels": {"platform": "instagram-reels", "width": 1080, "height": 1920, "maxDurationSec": 90, "maxCaptionLength": 2200},
    "youtube-shorts": {"platform": "youtube-shorts", "width": 1080, "height": 1920, "maxDurationSec": 60, "maxCaptionLength": 5000},
}

class ContentPipelineExecutor(MicroserviceBase):
    service_name = "content-pipeline"

    def __init__(self, db: IDatabaseService, queue: IQueueService, ai_providers: list[IAiProvider] = None):
        super().__init__(db, queue)
        self._providers = {p.provider_name: p for p in (ai_providers or [])}

    async def execute_step(self, sub_step: str, inputs: dict, config: dict = None) -> DataProcessResult:
        config = config or {}
        handlers = {
            "generate-script": lambda: self._generate_script(inputs.get("topic", ""), inputs.get("style", "engaging")),
            "generate-images": lambda: self._generate_images(inputs.get("script", ""), config.get("imageProvider", "dalle")),
            "full": lambda: self._full_pipeline(inputs, config),
        }
        handler = handlers.get(sub_step)
        if not handler: return DataProcessResult.failure(f"Unknown sub-step: {sub_step}")
        return await handler()

    async def _generate_script(self, topic: str, style: str) -> DataProcessResult:
        ai = next(iter(self._providers.values()), None)
        if not ai: return DataProcessResult.failure("No AI provider")
        result = await ai.complete(f"Create a short-form video script about: {topic}. Style: {style}.")
        return DataProcessResult.success({"script": result, "topic": topic})

    async def _generate_images(self, script: str, provider: str) -> DataProcessResult:
        return DataProcessResult.success({"images": [], "provider": provider, "status": "pending"})

    async def _full_pipeline(self, inputs: dict, config: dict) -> DataProcessResult:
        script = await self._generate_script(inputs.get("topic", ""), inputs.get("style", "engaging"))
        if not script.is_success: return script
        await self.store_document("content-jobs", inputs.get("traceId", "unknown"), {"step": "script", "data": script.data})
        return DataProcessResult.success({"pipeline": "started", "currentStep": "script", "data": script.data})
