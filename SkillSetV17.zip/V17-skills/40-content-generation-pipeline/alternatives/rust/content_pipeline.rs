// XIIGen Content Generation Pipeline — Rust | Skill 40
use serde_json::{json, Value};
use std::collections::HashMap;
use crate::core::{DataProcessResult, IAiProvider, IDatabaseService, IQueueService, MicroserviceBase};

pub struct ContentPipelineExecutor {
    base: MicroserviceBase,
    providers: HashMap<String, Box<dyn IAiProvider>>,
}

impl ContentPipelineExecutor {
    pub fn new(db: Box<dyn IDatabaseService>, queue: Box<dyn IQueueService>, providers: Vec<Box<dyn IAiProvider>>) -> Self {
        let mut map = HashMap::new();
        for p in providers { map.insert(p.provider_name().to_string(), p); }
        Self { base: MicroserviceBase::new(db, queue, "content-pipeline"), providers: map }
    }

    pub async fn execute_step(&self, sub_step: &str, inputs: &Value, config: &Value) -> DataProcessResult<Value> {
        match sub_step {
            "generate-script" => self.generate_script(inputs["topic"].as_str().unwrap_or(""), inputs["style"].as_str().unwrap_or("engaging")).await,
            "full" => self.full_pipeline(inputs, config).await,
            _ => DataProcessResult::failure(&format!("Unknown sub-step: {}", sub_step)),
        }
    }

    async fn generate_script(&self, topic: &str, style: &str) -> DataProcessResult<Value> {
        let ai = match self.providers.values().next() { Some(p) => p, None => return DataProcessResult::failure("No AI provider") };
        let prompt = format!("Create a short-form video script about: {}. Style: {}.", topic, style);
        let result = ai.complete(&prompt).await;
        DataProcessResult::success(json!({"script": result, "topic": topic}))
    }

    async fn full_pipeline(&self, inputs: &Value, _config: &Value) -> DataProcessResult<Value> {
        let script = self.generate_script(inputs["topic"].as_str().unwrap_or(""), inputs["style"].as_str().unwrap_or("engaging")).await;
        if !script.is_success { return script; }
        let trace = inputs["traceId"].as_str().unwrap_or("unknown");
        self.base.store_document("content-jobs", trace, &json!({"step": "script", "data": script.data})).await;
        DataProcessResult::success(json!({"pipeline": "started", "data": script.data}))
    }
}
