<?php
// XIIGen Content Generation Pipeline — PHP | Skill 40
namespace XIIGen\Pipeline\Content;
use XIIGen\Core\{MicroserviceBase, DataProcessResult, IDatabaseService, IQueueService, IAiProvider};

class ContentPipelineExecutor extends MicroserviceBase {
    protected string $serviceName = 'content-pipeline';
    private array $providers = [];

    public function __construct(IDatabaseService $db, IQueueService $queue, array $aiProviders = []) {
        parent::__construct($db, $queue);
        foreach ($aiProviders as $p) $this->providers[$p->getProviderName()] = $p;
    }

    public function executeStep(string $subStep, array $inputs, array $config = []): DataProcessResult {
        return match($subStep) {
            'generate-script' => $this->generateScript($inputs['topic'] ?? '', $inputs['style'] ?? 'engaging'),
            'full' => $this->fullPipeline($inputs, $config),
            default => DataProcessResult::failure("Unknown sub-step: $subStep"),
        };
    }

    private function generateScript(string $topic, string $style): DataProcessResult {
        $ai = reset($this->providers);
        if (!$ai) return DataProcessResult::failure('No AI provider');
        $result = $ai->complete("Create a short-form video script about: $topic. Style: $style.");
        return DataProcessResult::success(['script' => $result, 'topic' => $topic]);
    }

    private function fullPipeline(array $inputs, array $config): DataProcessResult {
        $script = $this->generateScript($inputs['topic'] ?? '', $inputs['style'] ?? 'engaging');
        if (!$script->isSuccess) return $script;
        $this->storeDocument('content-jobs', $inputs['traceId'] ?? 'unknown', ['step' => 'script', 'data' => $script->data]);
        return DataProcessResult::success(['pipeline' => 'started', 'data' => $script->data]);
    }
}
