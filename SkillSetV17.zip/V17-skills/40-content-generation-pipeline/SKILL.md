---
skill_id: "40"
name: content-generation-pipeline
title: "Content Generation Pipeline"
layer: "L8: Specialty"
version: "17.0"
status: "active"
dependencies:
  - "01-core-interfaces"
  - "02-object-processor"
  - "03-elasticsearch-datastore"
  - "06-ai-providers"
  - "09-flow-orchestrator"
  - "13-feedback-service"
dotnet_namespace: "XIIGen.Services.ContentPipeline"
di_registration: "services.AddXIIGenContentPipeline()"
es_index: "xiigen-content"
genie_dna:
  - "DNA-1: Content records (scripts, media refs, publish results) as dynamic documents"
  - "DNA-2: BuildSearchFilter for content search (platform, status, creator — skip empty)"
  - "DNA-3: Inherits MicroserviceBase (DB, queue, AI provider, logger)"
  - "DNA-5: DataProcessResult for all pipeline operations"
  - "DNA-6: IAiProvider generic interface — swap AI models per pipeline step"
  - "DNA-7: Pipeline steps communicate via events (queue-based orchestration)"
  - "DNA-FREEDOM: Platform templates are dynamic documents — admins add new platforms without code"
triggers: content pipeline, video generation, script, TikTok, Instagram, YouTube, content creation, media
---

# Skill 40: Content Generation Pipeline
## Multi-Platform Content Generation with AI

**Classification: HYBRID — MACHINE pipeline engine, FREEDOM platform templates**

---

## Genie DNA Integration

### Platform Templates as Dynamic Documents (DNA-1, DNA-FREEDOM)
Platform specs are NOT hardcoded — they're dynamic documents admins create:
```json
{
  "platform": "TikTok",
  "resolution": "1080x1920",
  "maxDuration": 60,
  "aspectRatio": "9:16",
  "toneGuide": "casual, trendy, fast-paced",
  "hashtagStrategy": "3-5 trending + 2 niche"
}
```
Adding a new platform (e.g., "Threads", "BlueSky") = adding a document. No code changes.

### Pipeline Steps as Events (DNA-7)
```
trigger → [generate-script] → [generate-images] → [generate-audio] → [compose-video] → [publish]
Each step is a queue event. Steps can run in parallel (images + audio simultaneously).
Each step's output stored as dynamic document with traceId correlation.
```

### AI Provider Flexibility (DNA-6)
Each step uses IAiProvider — swap models per step:
```
Script generation → Claude (best for creative writing)
Image generation → DALL-E or Stability AI (via IAiProvider)
Audio generation → ElevenLabs (via IAiProvider)
// Change provider per step via config. Same interface.
```

## Interface
```csharp
public interface IContentPipelineService
{
    Task<DataProcessResult<string>> TriggerPipelineAsync(Dictionary<string, object> request);
    Task<DataProcessResult<Dictionary<string, object>>> ExecuteStepAsync(
        string subStep, Dictionary<string, object> input, string traceId);
    Task<DataProcessResult<Dictionary<string, object>>> GetPlatformTemplateAsync(string platform);
    Task<DataProcessResult<string>> CreatePlatformTemplateAsync(Dictionary<string, object> templateDoc);
}
```

All parameters are `Dictionary<string, object>` — dynamic documents.

## Sub-Steps
| Step | Input | Output | AI Provider |
|---|---|---|---|
| generate-script | topic + platform template | script text + timestamps | Claude/GPT |
| generate-images | script scenes | image URLs array | DALL-E/Stability |
| generate-audio | script text | audio URL + duration | ElevenLabs/Suno |
| compose-video | images + audio + timing | video URL | Runway/Pika |
| publish | video + metadata | publish result | Platform API |

## Alternatives
All alternatives MUST: store all content as dynamic documents, use IAiProvider interface, communicate steps via queue events, return DataProcessResult.
