# Content Generation Pipeline — Implementation Prompt | Skill 40
## Phase 1: Pipeline Structure
1. `IStepExecutor` implementation with sub-step routing
2. Platform templates: TikTok, Instagram Reels, YouTube Shorts, LinkedIn
3. Config: imageProvider, videoProvider, musicProvider, autoSchedule

## Phase 2: Script Generation
1. AI-powered script creation (hook→body→CTA)
2. Store job state as dynamic doc per traceId for resumability
3. Multi-provider support via IAiProvider interface

## Phase 3: Media Generation
1. Image generation (DALL-E/Stability/Midjourney adapters)
2. Audio/music generation (Suno/ElevenLabs adapters)
3. Video composition with platform-specific dimensions

## Phase 4: Publishing & Testing
1. Multi-platform publishing with caption adaptation
2. Auto-scheduling with optimal time slots
3. **Genie DNA Checklist:** ☐ DataProcessResult ☐ ParseObjectAlternative for configs ☐ BuildSearchFilter ☐ IStepExecutor


---

## Genie DNA Compliance — MANDATORY for All Implementations

> Before writing ANY code, classify each component:
> **MACHINE** (static): Infrastructure that enables freedom. Build once, generic, interface-based.
> **FREEDOM** (dynamic): Anything users define. No fixed models, config-driven.

### DNA Checklist — Every Implementation MUST:
☐ **DNA-1 (Dynamic Documents):** Store data as `Dictionary<string, object>` / `Record<string, any>` — NOT typed model classes. User fields preserved without schema changes.
☐ **DNA-2 (BuildSearchFilter):** All queries use BuildSearchFilter/equivalent. Empty fields auto-skipped. No entity-specific query code.
☐ **DNA-3 (MicroserviceBase):** Inherit base class with DB, queue, cache, logger built in.
☐ **DNA-5 (DataProcessResult):** All public methods return `DataProcessResult<T>`. Errors return failure, not throw exceptions.
☐ **DNA-6 (Generic Interfaces):** External dependencies behind interfaces. Swap via config.
☐ **DNA-SCOPE:** Non-admin queries auto-inject userId filter. Cannot be bypassed.

### The Three Tests:
1. Can a business user change this without a developer? (YES = correct)
2. Does it work for entity types that do not exist yet? (YES = correct)
3. Can I swap the database/service/UI without changing this? (YES = correct)
