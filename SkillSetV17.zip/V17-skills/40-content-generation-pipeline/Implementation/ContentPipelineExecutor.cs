// XIIGen.Pipeline.Content/ContentPipelineExecutor.cs - Skill 40 | .NET 9
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using XIIGen.Core.Enums;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Pipeline.Content;

// ─── Config ─────────────────────────────────────────
public class ContentPipelineConfig
{
    public bool SkipAudio { get; set; }
    public string ImageProvider { get; set; } = "dalle";       // dalle, stability, midjourney
    public string VideoProvider { get; set; } = "runway";      // runway, pika, kling
    public string MusicProvider { get; set; } = "suno";        // suno, udio, elevenlabs
    public string AvatarProvider { get; set; } = "heygen";     // heygen, synthesia, did
    public List<string> TargetPlatforms { get; set; } = ["tiktok", "instagram-reels", "youtube-shorts"];
    public bool AutoSchedule { get; set; }
}

public class PlatformTemplate
{
    public string Platform { get; set; } = "";
    public int Width { get; set; }
    public int Height { get; set; }
    public int MaxDurationSec { get; set; }
    public string Format { get; set; } = "mp4";
    public int MaxCaptionLength { get; set; }

    public static PlatformTemplate ForPlatform(string p) => p switch
    {
        "tiktok" => new() { Platform = "tiktok", Width = 1080, Height = 1920, MaxDurationSec = 60, MaxCaptionLength = 2200 },
        "instagram-reels" => new() { Platform = "instagram-reels", Width = 1080, Height = 1920, MaxDurationSec = 90, MaxCaptionLength = 2200 },
        "youtube-shorts" => new() { Platform = "youtube-shorts", Width = 1080, Height = 1920, MaxDurationSec = 60, MaxCaptionLength = 5000 },
        "linkedin" => new() { Platform = "linkedin", Width = 1920, Height = 1080, MaxDurationSec = 600, MaxCaptionLength = 3000 },
        _ => new() { Platform = p, Width = 1080, Height = 1920, MaxDurationSec = 60, MaxCaptionLength = 2200 }
    };
}

// ─── Executor ───────────────────────────────────────
public class ContentPipelineExecutor : IStepExecutor
{
    private readonly IEnumerable<IAiProvider> _aiProviders;
    private readonly IDatabaseService _db;
    private readonly ILogger<ContentPipelineExecutor> _logger;

    public NodeType StepType => NodeType.ContentPipeline;

    public ContentPipelineExecutor(IEnumerable<IAiProvider> aiProviders, IDatabaseService db, ILogger<ContentPipelineExecutor> logger)
    { _aiProviders = aiProviders; _db = db; _logger = logger; }

    public async Task<DataProcessResult<Dictionary<string, object>>> ExecuteAsync(
        FlowStep step, Dictionary<string, object> inputs, CancellationToken ct = default)
    {
        try
        {
            var subStep = step.Config.GetValueOrDefault("subStep")?.ToString() ?? "full";
            return subStep switch
            {
                "audio-to-text"           => await AudioToTextAsync(inputs, ct),
                "text-improve"            => await TextImproveAsync(inputs, ct),
                "image-plan"              => await ImagePlanAsync(inputs, ct),
                "image-generate"          => await ImageGenerateAsync(inputs, ct),
                "video-generate"          => await VideoGenerateAsync(inputs, ct),
                "music-generate"          => await MusicGenerateAsync(inputs, ct),
                "avatar-video"            => await AvatarVideoAsync(inputs, ct),
                "platform-assembly"       => await PlatformAssemblyAsync(inputs, ct),
                "platform-descriptions"   => await PlatformDescriptionsAsync(inputs, ct),
                "schedule-posts"          => await SchedulePostsAsync(inputs, ct),
                "full"                    => await RunFullPipelineAsync(inputs, ct),
                _ => DataProcessResult<Dictionary<string, object>>.Error($"Unknown sub-step: {subStep}")
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Content pipeline failed at step {StepId}", step.Id);
            return DataProcessResult<Dictionary<string, object>>.Error(ex.Message);
        }
    }

    // ─── Full Pipeline ──────────────────────────────
    private async Task<DataProcessResult<Dictionary<string, object>>> RunFullPipelineAsync(
        Dictionary<string, object> inputs, CancellationToken ct)
    {
        var results = new Dictionary<string, object>();
        var text = inputs.GetValueOrDefault("text")?.ToString() ?? "";

        // 1. Audio → Text
        if (inputs.ContainsKey("audioBase64") || inputs.ContainsKey("audioUrl"))
        {
            var tr = await AudioToTextAsync(inputs, ct);
            if (tr.IsSuccess) { text = tr.Data!["transcribedText"]?.ToString() ?? text; results["transcription"] = tr.Data!; }
        }

        // 2. Improve text
        var improved = await TextImproveAsync(new() { ["text"] = text }, ct);
        if (improved.IsSuccess) { text = improved.Data!["improvedText"]?.ToString() ?? text; results["improvedText"] = text; }

        // 3. Image plan
        var plan = await ImagePlanAsync(new() { ["text"] = text }, ct);
        if (plan.IsSuccess) results["imagePlan"] = plan.Data!;

        // 4. Generate images
        var imgs = await ImageGenerateAsync(plan.IsSuccess ? plan.Data! : new() { ["text"] = text }, ct);
        if (imgs.IsSuccess) results["images"] = imgs.Data!;

        // 5. Generate videos
        var vids = await VideoGenerateAsync(new() { ["text"] = text, ["images"] = results.GetValueOrDefault("images", new object()) }, ct);
        if (vids.IsSuccess) results["videos"] = vids.Data!;

        // 6. Generate music
        var music = await MusicGenerateAsync(new() { ["text"] = text }, ct);
        if (music.IsSuccess) results["music"] = music.Data!;

        // 7. Avatar video (optional — requires voiceSample)
        if (inputs.ContainsKey("voiceSample"))
        {
            var avatar = await AvatarVideoAsync(inputs, ct);
            if (avatar.IsSuccess) results["avatarVideo"] = avatar.Data!;
        }

        // 8. Platform assembly
        var assembly = await PlatformAssemblyAsync(results, ct);
        if (assembly.IsSuccess) results["assembly"] = assembly.Data!;

        // 9. Platform descriptions
        var descs = await PlatformDescriptionsAsync(new() { ["text"] = text }, ct);
        if (descs.IsSuccess) results["descriptions"] = descs.Data!;

        // 10. Schedule (if auto-schedule enabled)
        if (inputs.ContainsKey("autoSchedule") && (bool)inputs["autoSchedule"])
        {
            var sched = await SchedulePostsAsync(results, ct);
            if (sched.IsSuccess) results["schedule"] = sched.Data!;
        }

        results["status"] = "pipeline_complete";
        results["completedAt"] = DateTime.UtcNow;
        await _db.StoreDocumentAsync("content-pipeline-results", "cp", Guid.NewGuid().ToString(), results, ct);
        return DataProcessResult<Dictionary<string, object>>.Success(results);
    }

    // ─── Sub-steps ──────────────────────────────────
    private async Task<DataProcessResult<Dictionary<string, object>>> AudioToTextAsync(Dictionary<string, object> inputs, CancellationToken ct)
    {
        var provider = GetProvider("claude");
        var req = new AiRequest
        {
            SystemPrompt = "Transcribe the audio content accurately. Return only the transcribed text.",
            Prompt = $"Transcribe: {inputs.GetValueOrDefault("audioDescription", "audio content")}",
            MaxTokens = 4000
        };
        var r = await provider.ExecuteAsync(req, ct);
        return r.IsSuccess
            ? DataProcessResult<Dictionary<string, object>>.Success(new() { ["transcribedText"] = r.Data!.Content })
            : DataProcessResult<Dictionary<string, object>>.Error(r.Message);
    }

    private async Task<DataProcessResult<Dictionary<string, object>>> TextImproveAsync(Dictionary<string, object> inputs, CancellationToken ct)
    {
        var provider = GetProvider("claude");
        var req = new AiRequest
        {
            SystemPrompt = "Improve this text for social media. Make it engaging, clear, platform-ready. Keep original meaning. Return only improved text.",
            Prompt = inputs.GetValueOrDefault("text")?.ToString() ?? "",
            MaxTokens = 4000
        };
        var r = await provider.ExecuteAsync(req, ct);
        return r.IsSuccess
            ? DataProcessResult<Dictionary<string, object>>.Success(new() { ["improvedText"] = r.Data!.Content })
            : DataProcessResult<Dictionary<string, object>>.Error(r.Message);
    }

    private async Task<DataProcessResult<Dictionary<string, object>>> ImagePlanAsync(Dictionary<string, object> inputs, CancellationToken ct)
    {
        var provider = GetProvider("claude");
        var req = new AiRequest
        {
            SystemPrompt = "Plan 3-5 images for this content. Return JSON array: [{\"description\": \"...\", \"style\": \"...\", \"prompt\": \"...\"}]",
            Prompt = inputs.GetValueOrDefault("text")?.ToString() ?? "",
            MaxTokens = 2000, OutputFormat = "json"
        };
        var r = await provider.ExecuteAsync(req, ct);
        return r.IsSuccess
            ? DataProcessResult<Dictionary<string, object>>.Success(new() { ["imagePlan"] = r.Data!.Content })
            : DataProcessResult<Dictionary<string, object>>.Error(r.Message);
    }

    private Task<DataProcessResult<Dictionary<string, object>>> ImageGenerateAsync(Dictionary<string, object> inputs, CancellationToken ct)
    {
        _logger.LogInformation("Image generation — plug in DALL-E / Stability / Midjourney provider");
        return Task.FromResult(DataProcessResult<Dictionary<string, object>>.Success(
            new() { ["images"] = new List<string>(), ["provider"] = "placeholder", ["note"] = "Integrate image API" }));
    }

    private Task<DataProcessResult<Dictionary<string, object>>> VideoGenerateAsync(Dictionary<string, object> inputs, CancellationToken ct)
    {
        _logger.LogInformation("Video generation — plug in Runway / Pika / Kling provider");
        return Task.FromResult(DataProcessResult<Dictionary<string, object>>.Success(
            new() { ["videos"] = new List<string>(), ["provider"] = "placeholder", ["note"] = "Integrate video API" }));
    }

    private Task<DataProcessResult<Dictionary<string, object>>> MusicGenerateAsync(Dictionary<string, object> inputs, CancellationToken ct)
    {
        _logger.LogInformation("Music generation — plug in Suno / Udio / ElevenLabs provider");
        return Task.FromResult(DataProcessResult<Dictionary<string, object>>.Success(
            new() { ["music"] = new List<string>(), ["provider"] = "placeholder", ["note"] = "Integrate music API" }));
    }

    private Task<DataProcessResult<Dictionary<string, object>>> AvatarVideoAsync(Dictionary<string, object> inputs, CancellationToken ct)
    {
        _logger.LogInformation("Avatar video — plug in HeyGen / Synthesia / D-ID provider");
        return Task.FromResult(DataProcessResult<Dictionary<string, object>>.Success(
            new() { ["avatarVideo"] = "", ["provider"] = "placeholder", ["note"] = "Integrate avatar API" }));
    }

    private Task<DataProcessResult<Dictionary<string, object>>> PlatformAssemblyAsync(Dictionary<string, object> inputs, CancellationToken ct)
    {
        var platforms = new[] { "tiktok", "instagram-reels", "youtube-shorts", "linkedin" };
        var assembled = platforms.Select(p =>
        {
            var tmpl = PlatformTemplate.ForPlatform(p);
            return new { tmpl.Platform, tmpl.Width, tmpl.Height, tmpl.MaxDurationSec, status = "template_ready" };
        }).ToList();
        return Task.FromResult(DataProcessResult<Dictionary<string, object>>.Success(
            new Dictionary<string, object> { ["platforms"] = assembled }));
    }

    private async Task<DataProcessResult<Dictionary<string, object>>> PlatformDescriptionsAsync(Dictionary<string, object> inputs, CancellationToken ct)
    {
        var provider = GetProvider("claude");
        var req = new AiRequest
        {
            SystemPrompt = "Generate social media descriptions. Return JSON: {\"tiktok\": \"...\", \"instagram\": \"...\", \"youtube\": \"...\", \"linkedin\": \"...\"}. Include hashtags and emojis where appropriate.",
            Prompt = $"Content: {inputs.GetValueOrDefault("text", "")}",
            MaxTokens = 2000, OutputFormat = "json"
        };
        var r = await provider.ExecuteAsync(req, ct);
        return r.IsSuccess
            ? DataProcessResult<Dictionary<string, object>>.Success(new() { ["descriptions"] = r.Data!.Content })
            : DataProcessResult<Dictionary<string, object>>.Error(r.Message);
    }

    private Task<DataProcessResult<Dictionary<string, object>>> SchedulePostsAsync(Dictionary<string, object> inputs, CancellationToken ct)
    {
        _logger.LogInformation("Post scheduling — plug in Meta / YouTube / LinkedIn / TikTok APIs");
        return Task.FromResult(DataProcessResult<Dictionary<string, object>>.Success(
            new() { ["scheduled"] = false, ["note"] = "Integrate platform scheduling APIs" }));
    }

    private IAiProvider GetProvider(string preferred) =>
        _aiProviders.FirstOrDefault(p => p.ProviderName == preferred) ?? _aiProviders.First();
}

// ─── DI Extension ───────────────────────────────────
public static class ContentPipelineExtensions
{
    public static IServiceCollection AddXIIGenContentPipeline(this IServiceCollection services)
    {
        services.AddSingleton<IStepExecutor, ContentPipelineExecutor>();
        return services;
    }
}
