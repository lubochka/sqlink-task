// XIIGen API Gateway — Skill 15 | Java (Spring Boot WebFlux)
// Trace-ID polling, WebSocket live updates, rate limiting, dynamic documents
// Genie DNA: No fixed DTOs — all request/response as Map<String, Object>

package com.xiigen.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.HandlerMapping;
import org.springframework.web.reactive.function.server.*;
import org.springframework.web.reactive.handler.SimpleUrlHandlerMapping;
import org.springframework.web.reactive.socket.WebSocketHandler;
import org.springframework.web.reactive.socket.WebSocketMessage;
import org.springframework.web.reactive.socket.WebSocketSession;
import reactor.core.publisher.Mono;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Sinks;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

// ─── Interfaces (matching Skill 01 contracts) ───────
interface IObjectProcessor {
    Map<String, Object> parseObjectAlternative(Object obj);
    Object buildSearchFilter(Map<String, Object> filter);
}

interface FlowOrchestrator {
    Mono<Map<String, Object>> triggerFlowAsync(Object flowDef, Object input, String traceId);
    Mono<Map<String, Object>> getExecutionAsync(String traceId);
    void onStepComplete(String traceId, StepCallback callback);
    void onFlowComplete(String traceId, FlowCallback callback);
}

@FunctionalInterface interface StepCallback { void apply(String stepId, String status, Object output); }
@FunctionalInterface interface FlowCallback { void apply(Object result); }

interface FlowDefinitionService {
    Mono<DataProcessResult> getAsync(String flowId);
    Mono<List<Object>> listAsync(Object filter);
    Mono<DataProcessResult> createFromDynamicAsync(Map<String, Object> doc);
    Mono<DataProcessResult> updateFromDynamicAsync(Map<String, Object> doc);
    Mono<DataProcessResult> deleteAsync(String flowId);
}

interface FeedbackService {
    Mono<DataProcessResult> submitDynamicFeedbackAsync(Map<String, Object> feedback);
    Mono<List<Object>> getByTraceAsync(String traceId);
}

interface NodeDebugService {
    Mono<List<Object>> getTraceDebugAsync(String traceId);
    Mono<Object> getStepDebugAsync(String traceId, String stepId);
}

record DataProcessResult(boolean isSuccess, Object data, String message) {}

// ─── WebSocket Manager ──────────────────────────────
class WsManager {
    private final ConcurrentHashMap<String, ConcurrentHashMap<String, Sinks.Many<String>>> connections = new ConcurrentHashMap<>();

    public Sinks.Many<String> addConnection(String traceId, String connId) {
        var traceConns = connections.computeIfAbsent(traceId, k -> new ConcurrentHashMap<>());
        var sink = Sinks.many().multicast().onBackpressureBuffer();
        traceConns.put(connId, sink);
        return sink;
    }

    public void removeConnection(String traceId, String connId) {
        var conns = connections.get(traceId);
        if (conns != null) {
            conns.remove(connId);
            if (conns.isEmpty()) connections.remove(traceId);
        }
    }

    public void broadcast(String traceId, String json) {
        var conns = connections.get(traceId);
        if (conns == null) return;
        conns.values().forEach(sink -> sink.tryEmitNext(json));
    }
}

// ─── Error Helpers ──────────────────────────────────
record ErrorResponse(String error, String message, String traceId, String timestamp) {
    static ErrorResponse of(String error, String message, String traceId) {
        return new ErrorResponse(error, message, traceId, Instant.now().toString());
    }
    static ErrorResponse of(String error, String message) { return of(error, message, null); }
}

// ─── Gateway Application ────────────────────────────
@SpringBootApplication
public class ApiGateway {
    public static void main(String[] args) { SpringApplication.run(ApiGateway.class, args); }
}

@Configuration
class GatewayRouterConfig {

    private final FlowOrchestrator orchestrator;
    private final FlowDefinitionService flowDefs;
    private final FeedbackService feedbackSvc;
    private final NodeDebugService debugSvc;
    private final IObjectProcessor objProcessor;
    private final WsManager wsManager = new WsManager();

    GatewayRouterConfig(FlowOrchestrator orch, FlowDefinitionService fd,
                        FeedbackService fb, NodeDebugService ds, IObjectProcessor op) {
        this.orchestrator = orch; this.flowDefs = fd;
        this.feedbackSvc = fb; this.debugSvc = ds; this.objProcessor = op;
    }

    @Bean
    public RouterFunction<ServerResponse> routes() {
        return RouterFunctions.route()
            // Flow trigger
            .POST("/api/flow/trigger", this::triggerFlow)
            // Status polling
            .GET("/api/flow/{traceId}/status", this::getFlowStatus)
            // Feedback
            .POST("/api/flow/{traceId}/feedback", this::submitFeedback)
            .GET("/api/flow/{traceId}/feedback", this::getFeedback)
            // Debug
            .GET("/api/debug/{traceId}", this::getDebugTrace)
            .GET("/api/debug/{traceId}/{stepId}", this::getStepDebug)
            // Flow CRUD
            .GET("/api/flows", this::listFlows)
            .GET("/api/flows/{flowId}", this::getFlow)
            .POST("/api/flows", this::createFlow)
            .PUT("/api/flows/{flowId}", this::updateFlow)
            .DELETE("/api/flows/{flowId}", this::deleteFlow)
            // Health
            .GET("/api/health", req -> ServerResponse.ok().bodyValue(
                Map.of("status", "healthy", "timestamp", Instant.now().toString())))
            .build();
    }

    // ─── Flow Trigger ───────────────────────────────
    private Mono<ServerResponse> triggerFlow(ServerRequest req) {
        return req.bodyToMono(Object.class).flatMap(body -> {
            var parsed = objProcessor.parseObjectAlternative(body);
            var flowId = (String) parsed.get("flowId");
            var traceId = parsed.containsKey("traceId") ? (String) parsed.get("traceId")
                        : UUID.randomUUID().toString().replace("-", "");
            var input = parsed.getOrDefault("input", parsed);

            if (flowId == null || flowId.isBlank())
                return ServerResponse.badRequest().bodyValue(ErrorResponse.of("INVALID_REQUEST", "flowId is required", traceId));

            return flowDefs.getAsync(flowId).flatMap(flowDef -> {
                if (!flowDef.isSuccess())
                    return ServerResponse.status(404).bodyValue(ErrorResponse.of("FLOW_NOT_FOUND", "No flow '" + flowId + "'", traceId));

                return orchestrator.triggerFlowAsync(flowDef.data(), input, traceId).flatMap(execution -> {
                    // Register WS callbacks
                    orchestrator.onStepComplete(traceId, (stepId, status, output) ->
                        wsManager.broadcast(traceId, toJson(Map.of("event", "step_complete", "stepId", stepId, "timestamp", Instant.now().toString()))));
                    orchestrator.onFlowComplete(traceId, result ->
                        wsManager.broadcast(traceId, toJson(Map.of("event", "flow_complete", "traceId", traceId, "timestamp", Instant.now().toString()))));

                    return ServerResponse.status(HttpStatus.ACCEPTED).bodyValue(Map.of(
                        "traceId", traceId, "flowId", execution.get("flowId"),
                        "status", execution.get("status"), "pollIntervalMs", 2000,
                        "wsUrl", "/ws/flow/" + traceId, "startedAt", execution.get("startedAt")));
                });
            });
        });
    }

    // ─── Status Polling ─────────────────────────────
    private Mono<ServerResponse> getFlowStatus(ServerRequest req) {
        var traceId = req.pathVariable("traceId");
        return orchestrator.getExecutionAsync(traceId).flatMap(execution -> {
            if (execution == null)
                return ServerResponse.status(404).bodyValue(ErrorResponse.of("EXECUTION_NOT_FOUND", "No execution for '" + traceId + "'", traceId));

            @SuppressWarnings("unchecked")
            var stepStatuses = (Map<String, Object>) execution.getOrDefault("stepStatuses", Map.of());
            int total = stepStatuses.size();
            long completed = stepStatuses.values().stream()
                .filter(s -> "Completed".equals(((Map<?,?>) s).get("status"))).count();

            var result = new HashMap<>(execution);
            result.put("progress", total > 0 ? Math.round((double) completed / total * 100.0) / 100.0 : 0);
            return ServerResponse.ok().bodyValue(result);
        }).switchIfEmpty(ServerResponse.status(404).bodyValue(
            ErrorResponse.of("EXECUTION_NOT_FOUND", "No execution for '" + req.pathVariable("traceId") + "'")));
    }

    // ─── Feedback ───────────────────────────────────
    private Mono<ServerResponse> submitFeedback(ServerRequest req) {
        var traceId = req.pathVariable("traceId");
        return req.bodyToMono(Object.class).flatMap(body -> {
            var feedback = objProcessor.parseObjectAlternative(body);
            feedback.put("traceId", traceId);
            feedback.put("submittedAt", Instant.now().toString());
            if (!feedback.containsKey("rating"))
                return ServerResponse.badRequest().bodyValue(ErrorResponse.of("INVALID_FEEDBACK", "rating is required", traceId));
            return feedbackSvc.submitDynamicFeedbackAsync(feedback).flatMap(result ->
                result.isSuccess()
                    ? ServerResponse.status(HttpStatus.CREATED).bodyValue(Map.of("traceId", traceId, "feedbackId", result.data(), "status", "saved"))
                    : ServerResponse.badRequest().bodyValue(ErrorResponse.of("FEEDBACK_FAILED", result.message(), traceId)));
        });
    }

    private Mono<ServerResponse> getFeedback(ServerRequest req) {
        return feedbackSvc.getByTraceAsync(req.pathVariable("traceId")).flatMap(f -> ServerResponse.ok().bodyValue(f));
    }

    // ─── Debug ──────────────────────────────────────
    private Mono<ServerResponse> getDebugTrace(ServerRequest req) {
        var traceId = req.pathVariable("traceId");
        return debugSvc.getTraceDebugAsync(traceId).flatMap(traces ->
            ServerResponse.ok().bodyValue(Map.of("traceId", traceId, "steps", traces, "count", traces.size())));
    }

    private Mono<ServerResponse> getStepDebug(ServerRequest req) {
        return debugSvc.getStepDebugAsync(req.pathVariable("traceId"), req.pathVariable("stepId"))
            .flatMap(d -> d != null ? ServerResponse.ok().bodyValue(d)
                : ServerResponse.status(404).bodyValue(ErrorResponse.of("STEP_NOT_FOUND", "No debug data")));
    }

    // ─── Flow CRUD ──────────────────────────────────
    private Mono<ServerResponse> listFlows(ServerRequest req) {
        var filterDict = new HashMap<String, Object>();
        req.queryParams().forEach((k, v) -> { if (!v.isEmpty() && !v.get(0).isBlank()) filterDict.put(k, v.get(0)); });
        var filter = filterDict.isEmpty() ? null : objProcessor.buildSearchFilter(filterDict);
        return flowDefs.listAsync(filter).flatMap(flows -> ServerResponse.ok().bodyValue(flows));
    }

    private Mono<ServerResponse> getFlow(ServerRequest req) {
        return flowDefs.getAsync(req.pathVariable("flowId")).flatMap(r ->
            r.isSuccess() ? ServerResponse.ok().bodyValue(r.data())
                : ServerResponse.status(404).bodyValue(ErrorResponse.of("FLOW_NOT_FOUND", r.message())));
    }

    private Mono<ServerResponse> createFlow(ServerRequest req) {
        return req.bodyToMono(Object.class).flatMap(body -> {
            var doc = objProcessor.parseObjectAlternative(body);
            return flowDefs.createFromDynamicAsync(doc).flatMap(r ->
                r.isSuccess() ? ServerResponse.status(HttpStatus.CREATED).bodyValue(Map.of("flowId", r.data()))
                    : ServerResponse.badRequest().bodyValue(ErrorResponse.of("CREATE_FAILED", r.message())));
        });
    }

    private Mono<ServerResponse> updateFlow(ServerRequest req) {
        var flowId = req.pathVariable("flowId");
        return req.bodyToMono(Object.class).flatMap(body -> {
            var doc = objProcessor.parseObjectAlternative(body);
            doc.put("flowId", flowId);
            return flowDefs.updateFromDynamicAsync(doc).flatMap(r ->
                r.isSuccess() ? ServerResponse.ok().bodyValue(Map.of("flowId", flowId, "updated", true))
                    : ServerResponse.badRequest().bodyValue(ErrorResponse.of("UPDATE_FAILED", r.message())));
        });
    }

    private Mono<ServerResponse> deleteFlow(ServerRequest req) {
        var flowId = req.pathVariable("flowId");
        return flowDefs.deleteAsync(flowId).flatMap(r ->
            r.isSuccess() ? ServerResponse.ok().bodyValue(Map.of("flowId", flowId, "deleted", true))
                : ServerResponse.status(404).bodyValue(ErrorResponse.of("FLOW_NOT_FOUND", r.message())));
    }

    // ─── WebSocket Config ───────────────────────────
    @Bean
    public HandlerMapping webSocketMapping() {
        var map = new SimpleUrlHandlerMapping();
        map.setUrlMap(Map.of("/ws/flow/**", (WebSocketHandler) session -> {
            var path = session.getHandshakeInfo().getUri().getPath();
            var traceId = path.substring(path.lastIndexOf('/') + 1);
            var connId = UUID.randomUUID().toString().replace("-", "");
            var sink = wsManager.addConnection(traceId, connId);

            var output = session.send(sink.asFlux().map(session::textMessage));
            var input = session.receive().doFinally(sig -> wsManager.removeConnection(traceId, connId)).then();
            return Mono.zip(output, input).then();
        }));
        map.setOrder(-1);
        return map;
    }

    private String toJson(Object obj) {
        try { return new com.fasterxml.jackson.databind.ObjectMapper().writeValueAsString(obj); }
        catch (Exception e) { return "{}"; }
    }
}
