// XIIGen API Gateway — Skill 15 | Node.js/TypeScript (Express)
// Trace-ID polling, WebSocket live updates, rate limiting, dynamic documents
// Genie DNA: No fixed DTOs — all request/response handled as plain objects

import express, { Request, Response, NextFunction } from 'express';
import { createServer } from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import { v4 as uuid } from 'uuid';
import { URL } from 'url';
import rateLimit from 'express-rate-limit';
import cors from 'cors';

// ─── Interfaces (matching Skill 01 contracts) ───────
interface IObjectProcessor {
  parseObjectAlternative(obj: any): Record<string, any>;
  buildSearchFilter(filter: Record<string, any>): any;
}

interface FlowOrchestrator {
  triggerFlowAsync(flowDef: any, input: any, traceId: string): Promise<any>;
  getExecutionAsync(traceId: string): Promise<any | null>;
  onStepComplete(traceId: string, cb: (stepId: string, status: string, output: any) => void): void;
  onFlowComplete(traceId: string, cb: (result: any) => void): void;
}

interface FlowDefinitionService {
  getAsync(flowId: string): Promise<{ isSuccess: boolean; data?: any; message?: string }>;
  listAsync(filter?: any): Promise<any[]>;
  createFromDynamicAsync(doc: Record<string, any>): Promise<{ isSuccess: boolean; data?: string; message?: string }>;
  updateFromDynamicAsync(doc: Record<string, any>): Promise<{ isSuccess: boolean; message?: string }>;
  deleteAsync(flowId: string): Promise<{ isSuccess: boolean; message?: string }>;
}

interface FeedbackService {
  submitDynamicFeedbackAsync(feedback: Record<string, any>): Promise<{ isSuccess: boolean; data?: string; message?: string }>;
  getByTraceAsync(traceId: string): Promise<any[]>;
}

interface NodeDebugService {
  getTraceDebugAsync(traceId: string): Promise<any[]>;
  getStepDebugAsync(traceId: string, stepId: string): Promise<any | null>;
}

interface ErrorResponse {
  error: string;
  message: string;
  traceId?: string;
  timestamp: string;
}

// ─── Configuration ──────────────────────────────────
const config = {
  port: parseInt(process.env.PORT || '3000'),
  pollIntervalHintMs: parseInt(process.env.POLL_INTERVAL_MS || '2000'),
  maxPollCount: parseInt(process.env.MAX_POLL_COUNT || '300'),
  rateLimiting: {
    triggerPerMinute: parseInt(process.env.TRIGGER_RATE || '10'),
    statusPerMinute: parseInt(process.env.STATUS_RATE || '60'),
    generalPerMinute: parseInt(process.env.GENERAL_RATE || '30'),
  },
  corsOrigins: (process.env.CORS_ORIGINS || '*').split(','),
};

// ─── WebSocket Manager ──────────────────────────────
class WsManager {
  private connections = new Map<string, Map<string, WebSocket>>();

  add(traceId: string, connId: string, ws: WebSocket): void {
    if (!this.connections.has(traceId)) this.connections.set(traceId, new Map());
    this.connections.get(traceId)!.set(connId, ws);
  }

  remove(traceId: string, connId: string): void {
    const conns = this.connections.get(traceId);
    if (conns) {
      conns.delete(connId);
      if (conns.size === 0) this.connections.delete(traceId);
    }
  }

  async broadcast(traceId: string, message: any): Promise<void> {
    const conns = this.connections.get(traceId);
    if (!conns) return;
    const json = JSON.stringify(message);
    for (const [connId, ws] of conns) {
      try {
        if (ws.readyState === WebSocket.OPEN) ws.send(json);
      } catch {
        conns.delete(connId);
      }
    }
  }
}

// ─── Error Helper ───────────────────────────────────
function errorResponse(error: string, message: string, traceId?: string): ErrorResponse {
  return { error, message, traceId, timestamp: new Date().toISOString() };
}

// ─── Create Gateway ─────────────────────────────────
export function createGateway(deps: {
  orchestrator: FlowOrchestrator;
  flowDefs: FlowDefinitionService;
  feedbackSvc: FeedbackService;
  debugSvc: NodeDebugService;
  objProcessor: IObjectProcessor;
}) {
  const { orchestrator, flowDefs, feedbackSvc, debugSvc, objProcessor } = deps;
  const app = express();
  const server = createServer(app);
  const wss = new WebSocketServer({ server, path: undefined }); // manually upgraded
  const wsManager = new WsManager();

  // ─── Middleware ──────────────────────────────────
  app.use(cors({ origin: config.corsOrigins, credentials: true }));
  app.use(express.json({ limit: '10mb' }));

  // Request logging
  app.use((req: Request, _res: Response, next: NextFunction) => {
    const start = Date.now();
    _res.on('finish', () => {
      console.log(`${req.method} ${req.path} → ${_res.statusCode} in ${Date.now() - start}ms`);
    });
    next();
  });

  // Rate limiters
  const triggerLimiter = rateLimit({ windowMs: 60000, max: config.rateLimiting.triggerPerMinute, standardHeaders: true });
  const statusLimiter = rateLimit({ windowMs: 60000, max: config.rateLimiting.statusPerMinute, standardHeaders: true });
  const generalLimiter = rateLimit({ windowMs: 60000, max: config.rateLimiting.generalPerMinute, standardHeaders: true });

  // ─── Flow Trigger ─────────────────────────────────
  app.post('/api/flow/trigger', triggerLimiter, async (req: Request, res: Response) => {
    try {
      const body = objProcessor.parseObjectAlternative(req.body);
      const flowId = body.flowId as string;
      const traceId = (body.traceId as string) || uuid().replace(/-/g, '');
      const input = body.input || body;

      if (!flowId) return res.status(400).json(errorResponse('INVALID_REQUEST', 'flowId is required', traceId));

      const flowDef = await flowDefs.getAsync(flowId);
      if (!flowDef.isSuccess) return res.status(404).json(errorResponse('FLOW_NOT_FOUND', `No flow '${flowId}'`, traceId));

      const execution = await orchestrator.triggerFlowAsync(flowDef.data, input, traceId);

      // Register WebSocket callbacks
      orchestrator.onStepComplete(traceId, (stepId, status, output) => {
        wsManager.broadcast(traceId, { event: status === 'Completed' ? 'step_complete' : 'step_started', stepId, output, timestamp: new Date().toISOString() });
      });
      orchestrator.onFlowComplete(traceId, (result) => {
        wsManager.broadcast(traceId, { event: 'flow_complete', traceId, result, timestamp: new Date().toISOString() });
      });

      res.status(202).json({
        traceId, flowId: execution.flowId, status: execution.status,
        pollIntervalMs: config.pollIntervalHintMs, wsUrl: `/ws/flow/${traceId}`, startedAt: execution.startedAt,
      });
    } catch (err: any) {
      res.status(500).json(errorResponse('INTERNAL_ERROR', err.message));
    }
  });

  // ─── Flow Status Polling ──────────────────────────
  app.get('/api/flow/:traceId/status', statusLimiter, async (req: Request, res: Response) => {
    const exec = await orchestrator.getExecutionAsync(req.params.traceId);
    if (!exec) return res.status(404).json(errorResponse('EXECUTION_NOT_FOUND', `No execution for '${req.params.traceId}'`, req.params.traceId));

    const total = Object.keys(exec.stepStatuses || {}).length;
    const completed = Object.values(exec.stepStatuses || {}).filter((s: any) => s.status === 'Completed').length;

    res.json({
      traceId: exec.traceId, flowId: exec.flowId, status: exec.status,
      currentStep: exec.currentStepId, progress: total > 0 ? Math.round((completed / total) * 100) / 100 : 0,
      steps: Object.entries(exec.stepStatuses || {}).map(([k, v]: [string, any]) => ({ stepId: k, status: v.status, startedAt: v.startedAt, completedAt: v.completedAt })),
      result: exec.status === 'Completed' ? exec.finalResult : undefined,
      startedAt: exec.startedAt, completedAt: exec.completedAt, error: exec.error,
    });
  });

  // ─── Feedback ─────────────────────────────────────
  app.post('/api/flow/:traceId/feedback', generalLimiter, async (req: Request, res: Response) => {
    const feedback = objProcessor.parseObjectAlternative(req.body);
    feedback.traceId = req.params.traceId;
    feedback.submittedAt = new Date().toISOString();
    if (!feedback.rating) return res.status(400).json(errorResponse('INVALID_FEEDBACK', 'rating is required', req.params.traceId));
    const result = await feedbackSvc.submitDynamicFeedbackAsync(feedback);
    result.isSuccess ? res.status(201).json({ traceId: req.params.traceId, feedbackId: result.data, status: 'saved' })
                     : res.status(400).json(errorResponse('FEEDBACK_FAILED', result.message || 'Unknown error', req.params.traceId));
  });

  app.get('/api/flow/:traceId/feedback', generalLimiter, async (req: Request, res: Response) => {
    const feedbacks = await feedbackSvc.getByTraceAsync(req.params.traceId);
    res.json(feedbacks);
  });

  // ─── Debug ────────────────────────────────────────
  app.get('/api/debug/:traceId', generalLimiter, async (req: Request, res: Response) => {
    const traces = await debugSvc.getTraceDebugAsync(req.params.traceId);
    res.json({ traceId: req.params.traceId, steps: traces, count: traces?.length ?? 0 });
  });

  app.get('/api/debug/:traceId/:stepId', generalLimiter, async (req: Request, res: Response) => {
    const debug = await debugSvc.getStepDebugAsync(req.params.traceId, req.params.stepId);
    debug ? res.json(debug) : res.status(404).json(errorResponse('STEP_NOT_FOUND', `No debug for step '${req.params.stepId}'`, req.params.traceId));
  });

  // ─── Flow CRUD ────────────────────────────────────
  app.get('/api/flows', generalLimiter, async (req: Request, res: Response) => {
    const filterDict: Record<string, any> = {};
    for (const [k, v] of Object.entries(req.query)) if (v) filterDict[k] = v;
    const filter = Object.keys(filterDict).length > 0 ? objProcessor.buildSearchFilter(filterDict) : undefined;
    const flows = await flowDefs.listAsync(filter);
    res.json(flows);
  });

  app.get('/api/flows/:flowId', generalLimiter, async (req: Request, res: Response) => {
    const result = await flowDefs.getAsync(req.params.flowId);
    result.isSuccess ? res.json(result.data) : res.status(404).json(errorResponse('FLOW_NOT_FOUND', result.message || '', req.params.flowId));
  });

  app.post('/api/flows', generalLimiter, async (req: Request, res: Response) => {
    const doc = objProcessor.parseObjectAlternative(req.body);
    const result = await flowDefs.createFromDynamicAsync(doc);
    result.isSuccess ? res.status(201).json({ flowId: result.data }) : res.status(400).json(errorResponse('CREATE_FAILED', result.message || ''));
  });

  app.put('/api/flows/:flowId', generalLimiter, async (req: Request, res: Response) => {
    const doc = objProcessor.parseObjectAlternative(req.body);
    doc.flowId = req.params.flowId;
    const result = await flowDefs.updateFromDynamicAsync(doc);
    result.isSuccess ? res.json({ flowId: req.params.flowId, updated: true }) : res.status(400).json(errorResponse('UPDATE_FAILED', result.message || ''));
  });

  app.delete('/api/flows/:flowId', generalLimiter, async (req: Request, res: Response) => {
    const result = await flowDefs.deleteAsync(req.params.flowId);
    result.isSuccess ? res.json({ flowId: req.params.flowId, deleted: true }) : res.status(404).json(errorResponse('FLOW_NOT_FOUND', result.message || ''));
  });

  // ─── Health ───────────────────────────────────────
  app.get('/api/health', (_req, res) => res.json({ status: 'healthy', timestamp: new Date().toISOString() }));

  // ─── WebSocket Upgrade ────────────────────────────
  server.on('upgrade', (request, socket, head) => {
    const url = new URL(request.url || '', `http://${request.headers.host}`);
    const match = url.pathname.match(/^\/ws\/flow\/(.+)$/);
    if (!match) { socket.destroy(); return; }
    const traceId = match[1];
    wss.handleUpgrade(request, socket, head, (ws) => {
      const connId = uuid().replace(/-/g, '');
      wsManager.add(traceId, connId, ws);
      ws.on('close', () => wsManager.remove(traceId, connId));
    });
  });

  return { app, server, start: () => server.listen(config.port, () => console.log(`XIIGen Gateway on :${config.port}`)) };
}
