// XIIGen API Gateway — Skill 15 | Rust (Axum)
// Trace-ID polling, WebSocket live updates, rate limiting, dynamic documents
// Genie DNA: No fixed structs for flow I/O — all handled as serde_json::Value / HashMap

use axum::{
    extract::{Path, Query, State, WebSocketUpgrade, ws::{Message, WebSocket}},
    http::StatusCode,
    response::{IntoResponse, Json},
    routing::{get, post, put, delete},
    Router,
};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::{collections::HashMap, sync::Arc};
use tokio::sync::{broadcast, RwLock};
use tower_http::cors::CorsLayer;
use uuid::Uuid;
use chrono::Utc;

// ─── Traits (matching Skill 01 contracts) ───────────
#[async_trait::async_trait]
pub trait ObjectProcessor: Send + Sync {
    fn parse_object_alternative(&self, obj: Value) -> HashMap<String, Value>;
    fn build_search_filter(&self, filter: &HashMap<String, Value>) -> Value;
}

#[async_trait::async_trait]
pub trait FlowOrchestrator: Send + Sync {
    async fn trigger_flow_async(&self, flow_def: &Value, input: Value, trace_id: &str) -> Result<Value, String>;
    async fn get_execution_async(&self, trace_id: &str) -> Option<Value>;
}

#[async_trait::async_trait]
pub trait FlowDefinitionService: Send + Sync {
    async fn get_async(&self, flow_id: &str) -> DataProcessResult;
    async fn list_async(&self, filter: Option<Value>) -> Vec<Value>;
    async fn create_from_dynamic(&self, doc: HashMap<String, Value>) -> DataProcessResult;
    async fn update_from_dynamic(&self, doc: HashMap<String, Value>) -> DataProcessResult;
    async fn delete_async(&self, flow_id: &str) -> DataProcessResult;
}

#[async_trait::async_trait]
pub trait FeedbackService: Send + Sync {
    async fn submit_dynamic_feedback(&self, feedback: HashMap<String, Value>) -> DataProcessResult;
    async fn get_by_trace(&self, trace_id: &str) -> Vec<Value>;
}

#[async_trait::async_trait]
pub trait NodeDebugService: Send + Sync {
    async fn get_trace_debug(&self, trace_id: &str) -> Vec<Value>;
    async fn get_step_debug(&self, trace_id: &str, step_id: &str) -> Option<Value>;
}

pub struct DataProcessResult {
    pub is_success: bool,
    pub data: Option<Value>,
    pub message: Option<String>,
}

// ─── Error Response ─────────────────────────────────
#[derive(Serialize)]
struct ErrorResponse {
    error: String,
    message: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    trace_id: Option<String>,
    timestamp: String,
}

impl ErrorResponse {
    fn new(error: &str, message: &str, trace_id: Option<&str>) -> Self {
        Self {
            error: error.to_string(), message: message.to_string(),
            trace_id: trace_id.map(|s| s.to_string()), timestamp: Utc::now().to_rfc3339(),
        }
    }
}

// ─── WebSocket Manager ──────────────────────────────
struct WsManager {
    channels: RwLock<HashMap<String, broadcast::Sender<String>>>,
}

impl WsManager {
    fn new() -> Self { Self { channels: RwLock::new(HashMap::new()) } }

    async fn get_or_create(&self, trace_id: &str) -> broadcast::Receiver<String> {
        let mut channels = self.channels.write().await;
        let sender = channels.entry(trace_id.to_string())
            .or_insert_with(|| broadcast::channel(100).0);
        sender.subscribe()
    }

    async fn broadcast(&self, trace_id: &str, message: &str) {
        let channels = self.channels.read().await;
        if let Some(sender) = channels.get(trace_id) {
            let _ = sender.send(message.to_string());
        }
    }

    async fn cleanup(&self, trace_id: &str) {
        let channels = self.channels.read().await;
        if let Some(sender) = channels.get(trace_id) {
            if sender.receiver_count() == 0 {
                drop(channels);
                self.channels.write().await.remove(trace_id);
            }
        }
    }
}

// ─── App State ──────────────────────────────────────
struct AppState {
    orchestrator: Box<dyn FlowOrchestrator>,
    flow_defs: Box<dyn FlowDefinitionService>,
    feedback_svc: Box<dyn FeedbackService>,
    debug_svc: Box<dyn NodeDebugService>,
    obj_processor: Box<dyn ObjectProcessor>,
    ws_manager: WsManager,
    poll_interval_ms: u64,
}

pub type SharedState = Arc<AppState>;

// ─── Router Factory ─────────────────────────────────
pub fn create_gateway(
    orchestrator: Box<dyn FlowOrchestrator>,
    flow_defs: Box<dyn FlowDefinitionService>,
    feedback_svc: Box<dyn FeedbackService>,
    debug_svc: Box<dyn NodeDebugService>,
    obj_processor: Box<dyn ObjectProcessor>,
    poll_interval_ms: u64,
) -> Router {
    let state = Arc::new(AppState {
        orchestrator, flow_defs, feedback_svc, debug_svc,
        obj_processor, ws_manager: WsManager::new(), poll_interval_ms,
    });

    Router::new()
        // Flow endpoints
        .route("/api/flow/trigger", post(trigger_flow))
        .route("/api/flow/{traceId}/status", get(get_flow_status))
        .route("/api/flow/{traceId}/result", get(get_flow_result))
        .route("/api/flow/{traceId}/feedback", post(submit_feedback).get(get_feedback))
        // Debug endpoints
        .route("/api/debug/{traceId}", get(get_debug_trace))
        .route("/api/debug/{traceId}/{stepId}", get(get_step_debug))
        // Flow CRUD
        .route("/api/flows", get(list_flows).post(create_flow))
        .route("/api/flows/{flowId}", get(get_flow).put(update_flow).delete(delete_flow))
        // WebSocket
        .route("/ws/flow/{traceId}", get(ws_handler))
        // Health
        .route("/api/health", get(health))
        .layer(CorsLayer::permissive())
        .with_state(state)
}

// ─── Flow Trigger ───────────────────────────────────
async fn trigger_flow(State(s): State<SharedState>, Json(body): Json<Value>) -> impl IntoResponse {
    let parsed = s.obj_processor.parse_object_alternative(body);
    let flow_id = parsed.get("flowId").and_then(|v| v.as_str()).unwrap_or_default();
    let trace_id = parsed.get("traceId").and_then(|v| v.as_str())
        .map(|s| s.to_string())
        .unwrap_or_else(|| Uuid::new_v4().to_string().replace('-', ""));
    let input = parsed.get("input").cloned().unwrap_or(Value::Object(
        parsed.into_iter().collect::<serde_json::Map<String, Value>>()));

    if flow_id.is_empty() {
        return (StatusCode::BAD_REQUEST, Json(json!(ErrorResponse::new("INVALID_REQUEST", "flowId is required", Some(&trace_id))))).into_response();
    }

    let flow_def = s.flow_defs.get_async(flow_id).await;
    if !flow_def.is_success {
        return (StatusCode::NOT_FOUND, Json(json!(ErrorResponse::new("FLOW_NOT_FOUND", &format!("No flow '{flow_id}'"), Some(&trace_id))))).into_response();
    }

    match s.orchestrator.trigger_flow_async(flow_def.data.as_ref().unwrap(), input, &trace_id).await {
        Ok(execution) => {
            (StatusCode::ACCEPTED, Json(json!({
                "traceId": trace_id, "flowId": execution["flowId"],
                "status": execution["status"], "pollIntervalMs": s.poll_interval_ms,
                "wsUrl": format!("/ws/flow/{trace_id}"), "startedAt": execution["startedAt"],
            }))).into_response()
        }
        Err(err) => (StatusCode::INTERNAL_SERVER_ERROR, Json(json!(ErrorResponse::new("TRIGGER_FAILED", &err, Some(&trace_id))))).into_response(),
    }
}

// ─── Status Polling ─────────────────────────────────
async fn get_flow_status(State(s): State<SharedState>, Path(trace_id): Path<String>) -> impl IntoResponse {
    match s.orchestrator.get_execution_async(&trace_id).await {
        Some(exec) => {
            let steps = exec.get("stepStatuses").and_then(|s| s.as_object()).map(|m| m.len()).unwrap_or(0);
            let completed = exec.get("stepStatuses").and_then(|s| s.as_object())
                .map(|m| m.values().filter(|v| v.get("status").and_then(|s| s.as_str()) == Some("Completed")).count())
                .unwrap_or(0);
            let progress = if steps > 0 { (completed as f64 / steps as f64 * 100.0).round() / 100.0 } else { 0.0 };

            let mut result = exec.clone();
            if let Some(obj) = result.as_object_mut() { obj.insert("progress".to_string(), json!(progress)); }
            Json(result).into_response()
        }
        None => (StatusCode::NOT_FOUND, Json(json!(ErrorResponse::new("EXECUTION_NOT_FOUND", &format!("No execution for '{trace_id}'"), Some(&trace_id))))).into_response(),
    }
}

async fn get_flow_result(State(s): State<SharedState>, Path(trace_id): Path<String>) -> impl IntoResponse {
    match s.orchestrator.get_execution_async(&trace_id).await {
        Some(exec) if exec.get("status").and_then(|s| s.as_str()) == Some("Completed") =>
            Json(json!({"traceId": trace_id, "result": exec["finalResult"]})).into_response(),
        Some(exec) => Json(json!({"traceId": trace_id, "status": exec["status"], "message": "Not yet complete"})).into_response(),
        None => (StatusCode::NOT_FOUND, Json(json!(ErrorResponse::new("EXECUTION_NOT_FOUND", "Not found", Some(&trace_id))))).into_response(),
    }
}

// ─── Feedback ───────────────────────────────────────
async fn submit_feedback(State(s): State<SharedState>, Path(trace_id): Path<String>, Json(body): Json<Value>) -> impl IntoResponse {
    let mut feedback = s.obj_processor.parse_object_alternative(body);
    feedback.insert("traceId".to_string(), Value::String(trace_id.clone()));
    feedback.insert("submittedAt".to_string(), Value::String(Utc::now().to_rfc3339()));
    if !feedback.contains_key("rating") {
        return (StatusCode::BAD_REQUEST, Json(json!(ErrorResponse::new("INVALID_FEEDBACK", "rating is required", Some(&trace_id))))).into_response();
    }
    let result = s.feedback_svc.submit_dynamic_feedback(feedback).await;
    if result.is_success {
        (StatusCode::CREATED, Json(json!({"traceId": trace_id, "feedbackId": result.data, "status": "saved"}))).into_response()
    } else {
        (StatusCode::BAD_REQUEST, Json(json!(ErrorResponse::new("FEEDBACK_FAILED", &result.message.unwrap_or_default(), Some(&trace_id))))).into_response()
    }
}

async fn get_feedback(State(s): State<SharedState>, Path(trace_id): Path<String>) -> Json<Vec<Value>> {
    Json(s.feedback_svc.get_by_trace(&trace_id).await)
}

// ─── Debug ──────────────────────────────────────────
async fn get_debug_trace(State(s): State<SharedState>, Path(trace_id): Path<String>) -> Json<Value> {
    let traces = s.debug_svc.get_trace_debug(&trace_id).await;
    Json(json!({"traceId": trace_id, "steps": traces, "count": traces.len()}))
}

async fn get_step_debug(State(s): State<SharedState>, Path((trace_id, step_id)): Path<(String, String)>) -> impl IntoResponse {
    match s.debug_svc.get_step_debug(&trace_id, &step_id).await {
        Some(d) => Json(d).into_response(),
        None => (StatusCode::NOT_FOUND, Json(json!(ErrorResponse::new("STEP_NOT_FOUND", "No debug data", Some(&trace_id))))).into_response(),
    }
}

// ─── Flow CRUD ──────────────────────────────────────
async fn list_flows(State(s): State<SharedState>, Query(params): Query<HashMap<String, String>>) -> Json<Vec<Value>> {
    let filter: HashMap<String, Value> = params.into_iter().filter(|(_, v)| !v.is_empty()).map(|(k, v)| (k, Value::String(v))).collect();
    let search = if filter.is_empty() { None } else { Some(s.obj_processor.build_search_filter(&filter)) };
    Json(s.flow_defs.list_async(search).await)
}

async fn get_flow(State(s): State<SharedState>, Path(flow_id): Path<String>) -> impl IntoResponse {
    let r = s.flow_defs.get_async(&flow_id).await;
    if r.is_success { Json(r.data.unwrap_or(Value::Null)).into_response() }
    else { (StatusCode::NOT_FOUND, Json(json!(ErrorResponse::new("FLOW_NOT_FOUND", &r.message.unwrap_or_default(), None)))).into_response() }
}

async fn create_flow(State(s): State<SharedState>, Json(body): Json<Value>) -> impl IntoResponse {
    let doc = s.obj_processor.parse_object_alternative(body);
    let r = s.flow_defs.create_from_dynamic(doc).await;
    if r.is_success { (StatusCode::CREATED, Json(json!({"flowId": r.data}))).into_response() }
    else { (StatusCode::BAD_REQUEST, Json(json!(ErrorResponse::new("CREATE_FAILED", &r.message.unwrap_or_default(), None)))).into_response() }
}

async fn update_flow(State(s): State<SharedState>, Path(flow_id): Path<String>, Json(body): Json<Value>) -> impl IntoResponse {
    let mut doc = s.obj_processor.parse_object_alternative(body);
    doc.insert("flowId".to_string(), Value::String(flow_id.clone()));
    let r = s.flow_defs.update_from_dynamic(doc).await;
    if r.is_success { Json(json!({"flowId": flow_id, "updated": true})).into_response() }
    else { (StatusCode::BAD_REQUEST, Json(json!(ErrorResponse::new("UPDATE_FAILED", &r.message.unwrap_or_default(), None)))).into_response() }
}

async fn delete_flow(State(s): State<SharedState>, Path(flow_id): Path<String>) -> impl IntoResponse {
    let r = s.flow_defs.delete_async(&flow_id).await;
    if r.is_success { Json(json!({"flowId": flow_id, "deleted": true})).into_response() }
    else { (StatusCode::NOT_FOUND, Json(json!(ErrorResponse::new("FLOW_NOT_FOUND", &r.message.unwrap_or_default(), None)))).into_response() }
}

// ─── WebSocket ──────────────────────────────────────
async fn ws_handler(State(s): State<SharedState>, Path(trace_id): Path<String>, ws: WebSocketUpgrade) -> impl IntoResponse {
    ws.on_upgrade(move |socket| handle_ws(s, trace_id, socket))
}

async fn handle_ws(state: SharedState, trace_id: String, mut socket: WebSocket) {
    let mut rx = state.ws_manager.get_or_create(&trace_id).await;
    let send_task = tokio::spawn(async move {
        while let Ok(msg) = rx.recv().await {
            if socket.send(Message::Text(msg)).await.is_err() { break; }
        }
    });
    send_task.await.ok();
    state.ws_manager.cleanup(&trace_id).await;
}

// ─── Health ─────────────────────────────────────────
async fn health() -> Json<Value> {
    Json(json!({"status": "healthy", "timestamp": Utc::now().to_rfc3339()}))
}
