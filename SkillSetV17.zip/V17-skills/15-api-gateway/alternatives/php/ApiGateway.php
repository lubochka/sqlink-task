<?php
// XIIGen API Gateway — Skill 15 | PHP (Laravel + Ratchet WebSocket)
// Trace-ID polling, WebSocket live updates, rate limiting, dynamic documents
// Genie DNA: No fixed models for flow I/O — all handled as associative arrays

namespace App\Http\Controllers;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Carbon\Carbon;

// ─── Interfaces (matching Skill 01 contracts) ───────
interface ObjectProcessorInterface {
    public function parseObjectAlternative($obj): array;
    public function buildSearchFilter(array $filter): mixed;
}

interface FlowOrchestratorInterface {
    public function triggerFlowAsync(mixed $flowDef, mixed $input, string $traceId): array;
    public function getExecutionAsync(string $traceId): ?array;
}

interface FlowDefinitionServiceInterface {
    public function getAsync(string $flowId): array; // ['isSuccess' => bool, 'data' => ?, 'message' => ?]
    public function listAsync(mixed $filter = null): array;
    public function createFromDynamicAsync(array $doc): array;
    public function updateFromDynamicAsync(array $doc): array;
    public function deleteAsync(string $flowId): array;
}

interface FeedbackServiceInterface {
    public function submitDynamicFeedbackAsync(array $feedback): array;
    public function getByTraceAsync(string $traceId): array;
}

interface NodeDebugServiceInterface {
    public function getTraceDebugAsync(string $traceId): array;
    public function getStepDebugAsync(string $traceId, string $stepId): ?array;
}

// ─── Error Helper ───────────────────────────────────
trait ErrorResponseTrait {
    protected function errorResponse(string $error, string $message, ?string $traceId = null, int $status = 400): JsonResponse {
        return response()->json([
            'error' => $error, 'message' => $message,
            'traceId' => $traceId, 'timestamp' => Carbon::now()->toIso8601String(),
        ], $status);
    }
}

// ─── Gateway Controller ─────────────────────────────
class FlowGatewayController extends Controller
{
    use ErrorResponseTrait;

    public function __construct(
        protected FlowOrchestratorInterface $orchestrator,
        protected FlowDefinitionServiceInterface $flowDefs,
        protected FeedbackServiceInterface $feedbackSvc,
        protected NodeDebugServiceInterface $debugSvc,
        protected ObjectProcessorInterface $objProcessor,
    ) {}

    // ─── Flow Trigger (POST /api/flow/trigger) ──────
    public function triggerFlow(Request $request): JsonResponse
    {
        // Genie DNA: parse as dynamic document
        $body = $this->objProcessor->parseObjectAlternative($request->all());
        $flowId = $body['flowId'] ?? null;
        $traceId = $body['traceId'] ?? Str::replace('-', '', Str::uuid()->toString());
        $input = $body['input'] ?? $body;

        if (empty($flowId)) {
            return $this->errorResponse('INVALID_REQUEST', 'flowId is required', $traceId);
        }

        $flowDef = $this->flowDefs->getAsync($flowId);
        if (!$flowDef['isSuccess']) {
            return $this->errorResponse('FLOW_NOT_FOUND', "No flow definition '{$flowId}'", $traceId, 404);
        }

        $execution = $this->orchestrator->triggerFlowAsync($flowDef['data'], $input, $traceId);
        $pollInterval = config('gateway.poll_interval_ms', 2000);

        return response()->json([
            'traceId' => $traceId,
            'flowId' => $execution['flowId'],
            'status' => $execution['status'],
            'pollIntervalMs' => $pollInterval,
            'wsUrl' => "/ws/flow/{$traceId}",
            'startedAt' => $execution['startedAt'],
        ], 202);
    }

    // ─── Status Polling (GET /api/flow/{traceId}/status) ──
    public function getFlowStatus(string $traceId): JsonResponse
    {
        $execution = $this->orchestrator->getExecutionAsync($traceId);
        if ($execution === null) {
            return $this->errorResponse('EXECUTION_NOT_FOUND', "No execution for '{$traceId}'", $traceId, 404);
        }

        $stepStatuses = $execution['stepStatuses'] ?? [];
        $total = count($stepStatuses);
        $completed = count(array_filter($stepStatuses, fn($s) => ($s['status'] ?? '') === 'Completed'));
        $progress = $total > 0 ? round($completed / $total, 2) : 0;

        $steps = [];
        foreach ($stepStatuses as $stepId => $status) {
            $steps[] = [
                'stepId' => $stepId, 'status' => $status['status'] ?? 'Unknown',
                'startedAt' => $status['startedAt'] ?? null, 'completedAt' => $status['completedAt'] ?? null,
            ];
        }

        return response()->json([
            'traceId' => $execution['traceId'], 'flowId' => $execution['flowId'],
            'status' => $execution['status'], 'currentStep' => $execution['currentStepId'] ?? null,
            'progress' => $progress, 'steps' => $steps,
            'result' => ($execution['status'] === 'Completed') ? ($execution['finalResult'] ?? null) : null,
            'startedAt' => $execution['startedAt'] ?? null, 'completedAt' => $execution['completedAt'] ?? null,
            'error' => $execution['error'] ?? null,
        ]);
    }

    // ─── Flow Result (GET /api/flow/{traceId}/result) ──
    public function getFlowResult(string $traceId): JsonResponse
    {
        $execution = $this->orchestrator->getExecutionAsync($traceId);
        if ($execution === null) {
            return $this->errorResponse('EXECUTION_NOT_FOUND', "Not found", $traceId, 404);
        }
        if ($execution['status'] !== 'Completed') {
            return response()->json(['traceId' => $traceId, 'status' => $execution['status'], 'message' => 'Not yet complete']);
        }
        return response()->json(['traceId' => $traceId, 'result' => $execution['finalResult'] ?? null]);
    }

    // ─── Feedback (POST /api/flow/{traceId}/feedback) ──
    public function submitFeedback(Request $request, string $traceId): JsonResponse
    {
        $feedback = $this->objProcessor->parseObjectAlternative($request->all());
        $feedback['traceId'] = $traceId;
        $feedback['submittedAt'] = Carbon::now()->toIso8601String();

        if (empty($feedback['rating'])) {
            return $this->errorResponse('INVALID_FEEDBACK', 'rating is required', $traceId);
        }

        $result = $this->feedbackSvc->submitDynamicFeedbackAsync($feedback);
        if ($result['isSuccess']) {
            return response()->json(['traceId' => $traceId, 'feedbackId' => $result['data'], 'status' => 'saved'], 201);
        }
        return $this->errorResponse('FEEDBACK_FAILED', $result['message'] ?? 'Unknown error', $traceId);
    }

    // ─── Feedback List (GET /api/flow/{traceId}/feedback) ──
    public function getFeedback(string $traceId): JsonResponse
    {
        return response()->json($this->feedbackSvc->getByTraceAsync($traceId));
    }

    // ─── Debug (GET /api/debug/{traceId}) ───────────
    public function getDebugTrace(string $traceId): JsonResponse
    {
        $traces = $this->debugSvc->getTraceDebugAsync($traceId);
        return response()->json(['traceId' => $traceId, 'steps' => $traces, 'count' => count($traces)]);
    }

    // ─── Debug Step (GET /api/debug/{traceId}/{stepId}) ──
    public function getStepDebug(string $traceId, string $stepId): JsonResponse
    {
        $debug = $this->debugSvc->getStepDebugAsync($traceId, $stepId);
        if ($debug === null) {
            return $this->errorResponse('STEP_NOT_FOUND', "No debug for '{$stepId}'", $traceId, 404);
        }
        return response()->json($debug);
    }

    // ─── Flow CRUD ──────────────────────────────────
    public function listFlows(Request $request): JsonResponse
    {
        $filterDict = array_filter($request->query(), fn($v) => !empty($v));
        $filter = !empty($filterDict) ? $this->objProcessor->buildSearchFilter($filterDict) : null;
        return response()->json($this->flowDefs->listAsync($filter));
    }

    public function getFlow(string $flowId): JsonResponse
    {
        $result = $this->flowDefs->getAsync($flowId);
        if ($result['isSuccess']) return response()->json($result['data']);
        return $this->errorResponse('FLOW_NOT_FOUND', $result['message'] ?? '', $flowId, 404);
    }

    public function createFlow(Request $request): JsonResponse
    {
        $doc = $this->objProcessor->parseObjectAlternative($request->all());
        $result = $this->flowDefs->createFromDynamicAsync($doc);
        if ($result['isSuccess']) return response()->json(['flowId' => $result['data']], 201);
        return $this->errorResponse('CREATE_FAILED', $result['message'] ?? '');
    }

    public function updateFlow(Request $request, string $flowId): JsonResponse
    {
        $doc = $this->objProcessor->parseObjectAlternative($request->all());
        $doc['flowId'] = $flowId;
        $result = $this->flowDefs->updateFromDynamicAsync($doc);
        if ($result['isSuccess']) return response()->json(['flowId' => $flowId, 'updated' => true]);
        return $this->errorResponse('UPDATE_FAILED', $result['message'] ?? '');
    }

    public function deleteFlow(string $flowId): JsonResponse
    {
        $result = $this->flowDefs->deleteAsync($flowId);
        if ($result['isSuccess']) return response()->json(['flowId' => $flowId, 'deleted' => true]);
        return $this->errorResponse('FLOW_NOT_FOUND', $result['message'] ?? '', $flowId, 404);
    }

    // ─── Health ─────────────────────────────────────
    public function health(): JsonResponse
    {
        return response()->json(['status' => 'healthy', 'timestamp' => Carbon::now()->toIso8601String()]);
    }
}

// ─── Routes (routes/api.php) ────────────────────────
// Route::post('/flow/trigger', [FlowGatewayController::class, 'triggerFlow'])->middleware('throttle:10,1');
// Route::get('/flow/{traceId}/status', [FlowGatewayController::class, 'getFlowStatus'])->middleware('throttle:60,1');
// Route::get('/flow/{traceId}/result', [FlowGatewayController::class, 'getFlowResult'])->middleware('throttle:60,1');
// Route::post('/flow/{traceId}/feedback', [FlowGatewayController::class, 'submitFeedback'])->middleware('throttle:20,1');
// Route::get('/flow/{traceId}/feedback', [FlowGatewayController::class, 'getFeedback'])->middleware('throttle:30,1');
// Route::get('/debug/{traceId}', [FlowGatewayController::class, 'getDebugTrace'])->middleware('throttle:30,1');
// Route::get('/debug/{traceId}/{stepId}', [FlowGatewayController::class, 'getStepDebug'])->middleware('throttle:30,1');
// Route::apiResource('flows', FlowGatewayController::class)->middleware('throttle:30,1');
// Route::get('/health', [FlowGatewayController::class, 'health']);

// ─── WebSocket Server (separate process using Ratchet) ──
// Use Laravel WebSockets or Ratchet for real-time WebSocket support.
// The WebSocket server subscribes to Redis pub/sub for trace events
// and forwards them to connected clients on /ws/flow/{traceId}.
