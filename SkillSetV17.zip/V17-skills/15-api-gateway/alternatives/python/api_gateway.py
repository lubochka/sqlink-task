# XIIGen API Gateway — Skill 15 | Python (FastAPI)
# Trace-ID polling, WebSocket live updates, rate limiting, dynamic documents
# Genie DNA: No fixed Pydantic models for flow I/O — all handled as dicts

import asyncio
import json
import time
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Protocol

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from slowapi import Limiter
from slowapi.util import get_remote_address

# ─── Interfaces (matching Skill 01 contracts) ───────
class IObjectProcessor(Protocol):
    def parse_object_alternative(self, obj: Any) -> dict[str, Any]: ...
    def build_search_filter(self, filter_dict: dict[str, Any]) -> Any: ...

class IFlowOrchestrator(Protocol):
    async def trigger_flow_async(self, flow_def: Any, input_data: Any, trace_id: str) -> Any: ...
    async def get_execution_async(self, trace_id: str) -> Any | None: ...
    def on_step_complete(self, trace_id: str, callback) -> None: ...
    def on_flow_complete(self, trace_id: str, callback) -> None: ...

class IFlowDefinitionService(Protocol):
    async def get_async(self, flow_id: str) -> Any: ...
    async def list_async(self, search_filter: Any = None) -> list[Any]: ...
    async def create_from_dynamic_async(self, doc: dict) -> Any: ...
    async def update_from_dynamic_async(self, doc: dict) -> Any: ...
    async def delete_async(self, flow_id: str) -> Any: ...

class IFeedbackService(Protocol):
    async def submit_dynamic_feedback_async(self, feedback: dict) -> Any: ...
    async def get_by_trace_async(self, trace_id: str) -> list[Any]: ...

class INodeDebugService(Protocol):
    async def get_trace_debug_async(self, trace_id: str) -> list[Any]: ...
    async def get_step_debug_async(self, trace_id: str, step_id: str) -> Any | None: ...


# ─── Error Response ──────────────────────────────────
def error_response(error: str, message: str, trace_id: str | None = None) -> dict:
    return {"error": error, "message": message, "traceId": trace_id, "timestamp": datetime.now(timezone.utc).isoformat()}


# ─── WebSocket Manager ──────────────────────────────
class WsManager:
    def __init__(self):
        self._connections: dict[str, dict[str, WebSocket]] = defaultdict(dict)

    def add(self, trace_id: str, conn_id: str, ws: WebSocket):
        self._connections[trace_id][conn_id] = ws

    def remove(self, trace_id: str, conn_id: str):
        conns = self._connections.get(trace_id, {})
        conns.pop(conn_id, None)
        if not conns:
            self._connections.pop(trace_id, None)

    async def broadcast(self, trace_id: str, message: dict):
        conns = self._connections.get(trace_id, {})
        payload = json.dumps(message, default=str)
        dead = []
        for conn_id, ws in conns.items():
            try:
                await ws.send_text(payload)
            except Exception:
                dead.append(conn_id)
        for cid in dead:
            conns.pop(cid, None)


# ─── Gateway Factory ────────────────────────────────
def create_gateway(
    orchestrator: IFlowOrchestrator,
    flow_defs: IFlowDefinitionService,
    feedback_svc: IFeedbackService,
    debug_svc: INodeDebugService,
    obj_processor: IObjectProcessor,
    poll_interval_ms: int = 2000,
    cors_origins: list[str] | None = None,
) -> FastAPI:

    app = FastAPI(title="XIIGen Gateway", version="1.0")
    ws_manager = WsManager()
    limiter = Limiter(key_func=get_remote_address)
    app.state.limiter = limiter

    app.add_middleware(CORSMiddleware, allow_origins=cors_origins or ["*"],
                       allow_methods=["*"], allow_headers=["*"], allow_credentials=True)

    # Request logging middleware
    @app.middleware("http")
    async def log_requests(request: Request, call_next):
        start = time.monotonic()
        response = await call_next(request)
        duration_ms = round((time.monotonic() - start) * 1000)
        print(f"{request.method} {request.url.path} → {response.status_code} in {duration_ms}ms")
        return response

    # Global exception handler
    @app.exception_handler(Exception)
    async def global_exception_handler(request: Request, exc: Exception):
        return JSONResponse(status_code=500, content=error_response("INTERNAL_ERROR", str(exc)))

    # ─── Flow Trigger ────────────────────────────────
    @app.post("/api/flow/trigger", status_code=202)
    @limiter.limit("10/minute")
    async def trigger_flow(request: Request):
        body = await request.json()
        parsed = obj_processor.parse_object_alternative(body)

        flow_id = parsed.get("flowId")
        trace_id = parsed.get("traceId") or uuid.uuid4().hex
        input_data = parsed.get("input", parsed)

        if not flow_id:
            raise HTTPException(400, detail=error_response("INVALID_REQUEST", "flowId is required", trace_id))

        flow_def = await flow_defs.get_async(flow_id)
        if not getattr(flow_def, "is_success", False):
            raise HTTPException(404, detail=error_response("FLOW_NOT_FOUND", f"No flow '{flow_id}'", trace_id))

        execution = await orchestrator.trigger_flow_async(flow_def.data, input_data, trace_id)

        # Register WS callbacks
        orchestrator.on_step_complete(trace_id, lambda sid, status, output:
            asyncio.create_task(ws_manager.broadcast(trace_id, {
                "event": "step_complete" if status == "Completed" else "step_started",
                "stepId": sid, "output": output, "timestamp": datetime.now(timezone.utc).isoformat()
            })))
        orchestrator.on_flow_complete(trace_id, lambda result:
            asyncio.create_task(ws_manager.broadcast(trace_id, {
                "event": "flow_complete", "traceId": trace_id, "result": result,
                "timestamp": datetime.now(timezone.utc).isoformat()
            })))

        return {
            "traceId": trace_id, "flowId": execution.flow_id, "status": execution.status,
            "pollIntervalMs": poll_interval_ms, "wsUrl": f"/ws/flow/{trace_id}",
            "startedAt": execution.started_at,
        }

    # ─── Status Polling ──────────────────────────────
    @app.get("/api/flow/{trace_id}/status")
    @limiter.limit("60/minute")
    async def get_flow_status(trace_id: str, request: Request):
        execution = await orchestrator.get_execution_async(trace_id)
        if not execution:
            raise HTTPException(404, detail=error_response("EXECUTION_NOT_FOUND", f"No execution for '{trace_id}'", trace_id))

        step_statuses = getattr(execution, "step_statuses", {}) or {}
        total = len(step_statuses)
        completed = sum(1 for s in step_statuses.values() if getattr(s, "status", None) == "Completed")

        return {
            "traceId": execution.trace_id, "flowId": execution.flow_id, "status": execution.status,
            "currentStep": execution.current_step_id,
            "progress": round(completed / total, 2) if total > 0 else 0,
            "steps": [{"stepId": k, "status": v.status} for k, v in step_statuses.items()],
            "result": execution.final_result if execution.status == "Completed" else None,
            "startedAt": execution.started_at, "completedAt": execution.completed_at,
            "error": execution.error,
        }

    # ─── Feedback ────────────────────────────────────
    @app.post("/api/flow/{trace_id}/feedback", status_code=201)
    @limiter.limit("20/minute")
    async def submit_feedback(trace_id: str, request: Request):
        body = await request.json()
        feedback = obj_processor.parse_object_alternative(body)
        feedback["traceId"] = trace_id
        feedback["submittedAt"] = datetime.now(timezone.utc).isoformat()
        if "rating" not in feedback:
            raise HTTPException(400, detail=error_response("INVALID_FEEDBACK", "rating is required", trace_id))
        result = await feedback_svc.submit_dynamic_feedback_async(feedback)
        if not result.is_success:
            raise HTTPException(400, detail=error_response("FEEDBACK_FAILED", result.message, trace_id))
        return {"traceId": trace_id, "feedbackId": result.data, "status": "saved"}

    @app.get("/api/flow/{trace_id}/feedback")
    @limiter.limit("30/minute")
    async def get_feedback(trace_id: str, request: Request):
        return await feedback_svc.get_by_trace_async(trace_id)

    # ─── Debug ───────────────────────────────────────
    @app.get("/api/debug/{trace_id}")
    @limiter.limit("30/minute")
    async def get_debug_trace(trace_id: str, request: Request):
        traces = await debug_svc.get_trace_debug_async(trace_id)
        return {"traceId": trace_id, "steps": traces, "count": len(traces) if traces else 0}

    @app.get("/api/debug/{trace_id}/{step_id}")
    @limiter.limit("30/minute")
    async def get_step_debug(trace_id: str, step_id: str, request: Request):
        debug = await debug_svc.get_step_debug_async(trace_id, step_id)
        if not debug:
            raise HTTPException(404, detail=error_response("STEP_NOT_FOUND", f"No debug for '{step_id}'", trace_id))
        return debug

    # ─── Flow CRUD ───────────────────────────────────
    @app.get("/api/flows")
    @limiter.limit("30/minute")
    async def list_flows(request: Request):
        filter_dict = {k: v for k, v in request.query_params.items() if v}
        search_filter = obj_processor.build_search_filter(filter_dict) if filter_dict else None
        return await flow_defs.list_async(search_filter)

    @app.get("/api/flows/{flow_id}")
    @limiter.limit("30/minute")
    async def get_flow(flow_id: str, request: Request):
        result = await flow_defs.get_async(flow_id)
        if not result.is_success:
            raise HTTPException(404, detail=error_response("FLOW_NOT_FOUND", result.message, flow_id))
        return result.data

    @app.post("/api/flows", status_code=201)
    @limiter.limit("30/minute")
    async def create_flow(request: Request):
        body = await request.json()
        doc = obj_processor.parse_object_alternative(body)
        result = await flow_defs.create_from_dynamic_async(doc)
        if not result.is_success:
            raise HTTPException(400, detail=error_response("CREATE_FAILED", result.message))
        return {"flowId": result.data}

    @app.put("/api/flows/{flow_id}")
    @limiter.limit("30/minute")
    async def update_flow(flow_id: str, request: Request):
        body = await request.json()
        doc = obj_processor.parse_object_alternative(body)
        doc["flowId"] = flow_id
        result = await flow_defs.update_from_dynamic_async(doc)
        if not result.is_success:
            raise HTTPException(400, detail=error_response("UPDATE_FAILED", result.message))
        return {"flowId": flow_id, "updated": True}

    @app.delete("/api/flows/{flow_id}")
    @limiter.limit("30/minute")
    async def delete_flow(flow_id: str, request: Request):
        result = await flow_defs.delete_async(flow_id)
        if not result.is_success:
            raise HTTPException(404, detail=error_response("FLOW_NOT_FOUND", result.message))
        return {"flowId": flow_id, "deleted": True}

    # ─── Health ──────────────────────────────────────
    @app.get("/api/health")
    async def health():
        return {"status": "healthy", "timestamp": datetime.now(timezone.utc).isoformat()}

    # ─── WebSocket ───────────────────────────────────
    @app.websocket("/ws/flow/{trace_id}")
    async def websocket_flow(websocket: WebSocket, trace_id: str):
        await websocket.accept()
        conn_id = uuid.uuid4().hex
        ws_manager.add(trace_id, conn_id, websocket)
        try:
            while True:
                await websocket.receive_text()  # keep alive, listen for close
        except WebSocketDisconnect:
            pass
        finally:
            ws_manager.remove(trace_id, conn_id)

    return app
