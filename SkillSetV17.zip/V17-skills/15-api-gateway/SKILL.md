---
name: api-gateway
description: ASP.NET 9 Minimal API gateway with trace-ID polling, WebSocket live updates, rate limiting, and flow management endpoints
triggers: api gateway, REST API, flow trigger, poll status, trace id, webhook, rate limit, gateway
dependencies: [01-core-interfaces, 02-object-processor, 03-elasticsearch-datastore, 09-flow-orchestrator, 13-feedback-service, 14-node-debugger, 20-auth-service]
layer: L4-Application
genie-dna: All request/response bodies handled as dynamic documents via ObjectProcessor. No fixed DTOs for flow input/output. BuildSearchFilter used for flow listing queries.
phase: 2
---

# Skill 15: API Gateway
## Flow Trigger + Trace Polling + WebSocket Live Updates + Debug API

The **front door** of XIIGen. Clients trigger flows via REST, then poll (or subscribe via WebSocket) for results. Also exposes debug, feedback, and flow management endpoints.

---

## Architecture

```
Client (React Native / Web / CLI)
  │
  ├─ POST /api/flow/trigger        → returns { traceId, status }
  │    └─ body: { flowId, input, traceId? }
  │
  ├─ GET  /api/flow/{traceId}/status → poll for completion
  │    └─ returns: { status, progress, currentStep, result? }
  │
  ├─ WS   /ws/flow/{traceId}       → real-time step updates
  │    └─ pushes: { event: "step_complete"|"flow_complete"|"error", data }
  │
  ├─ POST /api/flow/{traceId}/feedback → submit user feedback
  ├─ GET  /api/debug/{traceId}     → full debug timeline
  ├─ GET  /api/debug/{traceId}/{stepId} → single step debug
  │
  └─ CRUD /api/flows               → flow definition management
       ├─ GET    /api/flows          → list (with dynamic filters)
       ├─ GET    /api/flows/{id}     → get definition
       ├─ POST   /api/flows          → create
       ├─ PUT    /api/flows/{id}     → update
       └─ DELETE /api/flows/{id}     → delete
```

## Core Pattern: Trace-ID Polling

The fundamental interaction pattern for XIIGen:

```
1. Client → POST /api/flow/trigger { flowId, input }
2. Server → 202 Accepted { traceId: "abc-123", status: "Running" }
3. Client polls GET /api/flow/abc-123/status every N seconds
4. Server → 200 { status: "Running", progress: 0.4, currentStep: "ai-transform" }
5. Server → 200 { status: "Completed", progress: 1.0, result: { ... } }
```

Client polling strategy (recommended):
- Initial delay: 1 second
- Poll interval: 2-5 seconds (configurable)
- Max poll count: 300 (10 minutes at 2s intervals)
- Exponential backoff on server errors: 2s → 4s → 8s → 16s (cap 30s)

Alternative: WebSocket subscription for real-time updates (preferred for UI).

## WebSocket Protocol

Connect to `ws://{host}/ws/flow/{traceId}` after triggering a flow.

Messages pushed by server:
```json
{ "event": "step_started", "stepId": "s2", "nodeName": "AI Transform", "timestamp": "..." }
{ "event": "step_complete", "stepId": "s2", "output": { ... }, "durationMs": 4200 }
{ "event": "flow_complete", "traceId": "abc-123", "result": { ... }, "totalDurationMs": 18500 }
{ "event": "flow_error", "traceId": "abc-123", "error": "...", "failedStep": "s3" }
```

## Rate Limiting

Configurable per-endpoint rate limiting via sliding window:

| Endpoint | Default Limit | Window |
|---|---|---|
| POST /api/flow/trigger | 10 req/min per user | Sliding 60s |
| GET /api/flow/*/status | 60 req/min per user | Sliding 60s |
| POST /api/flow/*/feedback | 20 req/min per user | Sliding 60s |
| GET /api/debug/* | 30 req/min per user | Sliding 60s |
| CRUD /api/flows | 30 req/min per user | Sliding 60s |

Returns `429 Too Many Requests` with `Retry-After` header when exceeded.

## Auth Integration (Skill 20)

All endpoints except `/api/health` require Bearer token authentication. The gateway validates tokens via the Auth Service middleware and injects `userId` into the request context. Flow triggers and feedback are automatically tagged with the authenticated user.

## Middleware Pipeline

```
Request → CORS → RateLimiter → Auth → RequestLogging → ExceptionHandler → Endpoint
                                                                              ↓
Response ← ResponseLogging ← Compression ← Result
```

## Genie DNA Integration

- **Request bodies**: Parsed via `ObjectProcessor.ParseObjectAlternative` — no fixed DTO classes. The gateway forwards whatever the client sends as dynamic documents.
- **Flow listing**: Uses `ObjectProcessor.BuildSearchFilter` — clients can filter flows by any field combination, empty fields are automatically skipped.
- **Debug data**: Returned as raw dynamic documents from Elasticsearch — no reshaping.

## Configuration

```json
{
  "Gateway": {
    "PollIntervalHintMs": 2000,
    "MaxPollCount": 300,
    "WebSocketEnabled": true,
    "RateLimiting": {
      "Enabled": true,
      "TriggerPerMinute": 10,
      "StatusPerMinute": 60
    },
    "Cors": {
      "AllowedOrigins": ["http://localhost:3000", "https://app.xiigen.io"]
    }
  }
}
```

## Health & Readiness

- `GET /api/health` — basic liveness (always returns 200)
- `GET /api/health/ready` — checks Elasticsearch + Redis connectivity
- `GET /api/health/detailed` — returns status of all downstream services (admin only)

## Error Response Model

All errors follow a consistent structure:
```json
{
  "error": "FLOW_NOT_FOUND",
  "message": "No flow definition found with id 'xyz'",
  "traceId": "abc-123",
  "timestamp": "2026-02-07T10:00:00Z"
}
```

## Anti-Patterns

- ❌ Do NOT create fixed DTO classes for flow input/output — use dynamic documents
- ❌ Do NOT block on flow execution in the trigger endpoint — always return 202 immediately
- ❌ Do NOT expose internal Elasticsearch queries directly — use the debug service abstraction
- ❌ Do NOT hardcode rate limits — use configuration for different deployment profiles

## Test Scenarios

1. Trigger a flow → verify 202 with traceId
2. Poll status → verify progress increments → verify final result
3. WebSocket subscription → verify real-time events
4. Submit feedback → verify stored in feedback service
5. Get debug timeline → verify ordered by timestamp
6. Rate limit exceeded → verify 429 with Retry-After
7. Invalid flow ID → verify 404 error model
8. Auth token missing → verify 401
9. Flow listing with dynamic filters → verify empty fields skipped
10. Health check → verify all downstream services checked

## Dependencies

| Skill | Purpose |
|---|---|
| 01-core-interfaces | IDatabaseService, IQueueService, IObjectProcessor |
| 02-object-processor | ParseObjectAlternative, BuildSearchFilter |
| 09-flow-orchestrator | TriggerFlowAsync, GetExecutionAsync |
| 13-feedback-service | SubmitFeedbackAsync |
| 14-node-debugger | GetTraceDebugAsync, GetStepDebugAsync |
| 20-auth-service | Token validation middleware |

## File Structure

```
skills/15-api-gateway/
├── SKILL.md
├── Implementation/
│   ├── Program.cs              # Minimal API setup + all endpoints
│   ├── GatewayMiddleware.cs    # Rate limiting, logging, error handling
│   └── appsettings.json        # Gateway configuration
├── alternatives/
│   ├── nodejs/api-gateway.ts
│   ├── python/api_gateway.py
│   ├── java/ApiGateway.java
│   ├── rust/api_gateway.rs
│   └── php/ApiGateway.php
└── prompts/
    └── implement.md
```
