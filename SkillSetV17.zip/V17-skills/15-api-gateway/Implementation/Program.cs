// XIIGen.Gateway/Program.cs — Skill 15 | .NET 9 Minimal APIs
// Full API Gateway: trace-ID polling, WebSocket live updates, rate limiting, debug, feedback
// Genie DNA: All request/response as dynamic documents via ObjectProcessor

using System.Collections.Concurrent;
using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Threading.RateLimiting;
using Microsoft.AspNetCore.RateLimiting;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;
using XIIGen.FlowEngine;
using XIIGen.FlowEngine.Models;
using XIIGen.Services.Debug;
using XIIGen.Services.Feedback;

var builder = WebApplication.CreateBuilder(args);

// ─── Configuration ─────────────────────────────────
var gatewayConfig = builder.Configuration.GetSection("Gateway");

// ─── Services ──────────────────────────────────────
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c => c.SwaggerDoc("v1", new() { Title = "XIIGen Gateway", Version = "v1" }));
builder.Services.AddCors(o => o.AddDefaultPolicy(p =>
{
    var origins = gatewayConfig.GetSection("Cors:AllowedOrigins").Get<string[]>() ?? ["*"];
    p.WithOrigins(origins).AllowAnyMethod().AllowAnyHeader().AllowCredentials();
}));

builder.Services.AddResponseCompression();
builder.Services.AddHealthChecks();

// Rate limiting (sliding window per user)
builder.Services.AddRateLimiter(opt =>
{
    opt.RejectionStatusCode = 429;
    opt.AddPolicy("trigger", ctx => RateLimitPartition.GetSlidingWindowLimiter(
        ctx.Connection.RemoteIpAddress?.ToString() ?? "anon",
        _ => new SlidingWindowRateLimiterOptions
        {
            PermitLimit = gatewayConfig.GetValue("RateLimiting:TriggerPerMinute", 10),
            Window = TimeSpan.FromMinutes(1), SegmentsPerWindow = 6, AutoReplenishment = true
        }));
    opt.AddPolicy("status", ctx => RateLimitPartition.GetSlidingWindowLimiter(
        ctx.Connection.RemoteIpAddress?.ToString() ?? "anon",
        _ => new SlidingWindowRateLimiterOptions
        {
            PermitLimit = gatewayConfig.GetValue("RateLimiting:StatusPerMinute", 60),
            Window = TimeSpan.FromMinutes(1), SegmentsPerWindow = 6, AutoReplenishment = true
        }));
    opt.AddPolicy("general", ctx => RateLimitPartition.GetSlidingWindowLimiter(
        ctx.Connection.RemoteIpAddress?.ToString() ?? "anon",
        _ => new SlidingWindowRateLimiterOptions
        {
            PermitLimit = 30, Window = TimeSpan.FromMinutes(1), SegmentsPerWindow = 6, AutoReplenishment = true
        }));
});

// Register XIIGen services (actual implementations injected via DI)
// builder.Services.AddSingleton<IObjectProcessor, ObjectProcessor>();
// builder.Services.AddSingleton<FlowOrchestrator>();
// builder.Services.AddSingleton<FlowDefinitionService>();
// builder.Services.AddSingleton<FeedbackService>();
// builder.Services.AddSingleton<NodeDebugService>();

builder.Services.AddSingleton<WebSocketManager>();

var app = builder.Build();

// ─── Middleware Pipeline ───────────────────────────
app.UseResponseCompression();
app.UseCors();
app.UseRateLimiter();
app.UseWebSockets(new WebSocketOptions { KeepAliveInterval = TimeSpan.FromSeconds(30) });

// Global exception handler middleware
app.Use(async (ctx, next) =>
{
    try
    {
        await next(ctx);
    }
    catch (Exception ex)
    {
        var logger = ctx.RequestServices.GetRequiredService<ILogger<Program>>();
        logger.LogError(ex, "Unhandled exception on {Method} {Path}", ctx.Request.Method, ctx.Request.Path);
        ctx.Response.StatusCode = 500;
        ctx.Response.ContentType = "application/json";
        await ctx.Response.WriteAsJsonAsync(new ErrorResponse("INTERNAL_ERROR", ex.Message, ctx.TraceIdentifier));
    }
});

// Request logging middleware
app.Use(async (ctx, next) =>
{
    var sw = System.Diagnostics.Stopwatch.StartNew();
    await next(ctx);
    sw.Stop();
    var logger = ctx.RequestServices.GetRequiredService<ILogger<Program>>();
    logger.LogInformation("{Method} {Path} → {Status} in {Ms}ms",
        ctx.Request.Method, ctx.Request.Path, ctx.Response.StatusCode, sw.ElapsedMilliseconds);
});

app.UseSwagger();
app.UseSwaggerUI();

// ═══════════════════════════════════════════════════
// FLOW TRIGGER + POLLING ENDPOINTS
// ═══════════════════════════════════════════════════

// POST /api/flow/trigger — Start a flow execution (returns 202 immediately)
app.MapPost("/api/flow/trigger", async (
    HttpContext httpCtx,
    FlowOrchestrator orchestrator,
    FlowDefinitionService flowDefs,
    IObjectProcessor objProcessor,
    WebSocketManager wsManager) =>
{
    // Genie DNA: parse request body as dynamic document
    var bodyJson = await JsonSerializer.DeserializeAsync<JsonElement>(httpCtx.Request.Body);
    var body = objProcessor.ParseObjectAlternative(bodyJson);

    var flowId = body.TryGetValue("flowId", out var fid) ? fid?.ToString() : null;
    var traceId = body.TryGetValue("traceId", out var tid) ? tid?.ToString() : Guid.NewGuid().ToString("N");
    var input = body.TryGetValue("input", out var inp) ? inp : body;

    if (string.IsNullOrEmpty(flowId))
        return Results.BadRequest(new ErrorResponse("INVALID_REQUEST", "flowId is required", traceId));

    var flowDef = await flowDefs.GetAsync(flowId);
    if (!flowDef.IsSuccess)
        return Results.NotFound(new ErrorResponse("FLOW_NOT_FOUND", $"No flow definition found with id '{flowId}'", traceId));

    // Trigger async execution — returns immediately
    var execution = await orchestrator.TriggerFlowAsync(flowDef.Data, input, traceId);

    // Register WebSocket notification callback
    orchestrator.OnStepComplete(traceId, async (stepId, status, output) =>
    {
        await wsManager.BroadcastToTrace(traceId, new
        {
            @event = status == FlowStatus.Completed ? "step_complete" : "step_started",
            stepId, output, timestamp = DateTime.UtcNow
        });
    });

    orchestrator.OnFlowComplete(traceId, async (result) =>
    {
        await wsManager.BroadcastToTrace(traceId, new
        {
            @event = "flow_complete", traceId, result, timestamp = DateTime.UtcNow
        });
    });

    var pollHint = app.Configuration.GetValue("Gateway:PollIntervalHintMs", 2000);

    return Results.Accepted($"/api/flow/{traceId}/status", new
    {
        traceId,
        flowId = execution.FlowId,
        status = execution.Status.ToString(),
        pollIntervalMs = pollHint,
        wsUrl = $"/ws/flow/{traceId}",
        startedAt = execution.StartedAt
    });
})
.RequireRateLimiting("trigger")
.WithName("TriggerFlow")
.WithOpenApi()
.Produces(202)
.Produces(400)
.Produces(404);

// GET /api/flow/{traceId}/status — Poll for execution status
app.MapGet("/api/flow/{traceId}/status", async (
    string traceId,
    FlowOrchestrator orchestrator) =>
{
    var execution = await orchestrator.GetExecutionAsync(traceId);
    if (execution is null)
        return Results.NotFound(new ErrorResponse("EXECUTION_NOT_FOUND", $"No execution found for trace '{traceId}'", traceId));

    var totalSteps = execution.StepStatuses.Count;
    var completedSteps = execution.StepStatuses.Values.Count(s => s.Status == FlowStatus.Completed);

    return Results.Ok(new
    {
        traceId = execution.TraceId,
        flowId = execution.FlowId,
        status = execution.Status.ToString(),
        currentStep = execution.CurrentStepId,
        progress = totalSteps > 0 ? Math.Round((double)completedSteps / totalSteps, 2) : 0,
        steps = execution.StepStatuses.Select(kvp => new
        {
            stepId = kvp.Key,
            status = kvp.Value.Status.ToString(),
            startedAt = kvp.Value.StartedAt,
            completedAt = kvp.Value.CompletedAt,
            error = kvp.Value.Error
        }),
        result = execution.Status == FlowStatus.Completed ? execution.FinalResult : null,
        startedAt = execution.StartedAt,
        completedAt = execution.CompletedAt,
        error = execution.Error
    });
})
.RequireRateLimiting("status")
.WithName("GetFlowStatus")
.WithOpenApi();

// GET /api/flow/{traceId}/result — Get final result only (convenience)
app.MapGet("/api/flow/{traceId}/result", async (string traceId, FlowOrchestrator orchestrator) =>
{
    var execution = await orchestrator.GetExecutionAsync(traceId);
    if (execution is null)
        return Results.NotFound(new ErrorResponse("EXECUTION_NOT_FOUND", $"No execution for '{traceId}'", traceId));

    if (execution.Status != FlowStatus.Completed)
        return Results.Ok(new { traceId, status = execution.Status.ToString(), message = "Execution not yet complete" });

    return Results.Ok(new { traceId, result = execution.FinalResult });
})
.RequireRateLimiting("status")
.WithName("GetFlowResult")
.WithOpenApi();

// ═══════════════════════════════════════════════════
// FEEDBACK ENDPOINTS
// ═══════════════════════════════════════════════════

app.MapPost("/api/flow/{traceId}/feedback", async (
    string traceId,
    HttpContext httpCtx,
    FeedbackService feedbackSvc,
    IObjectProcessor objProcessor) =>
{
    // Genie DNA: parse as dynamic document — any feedback fields accepted
    var bodyJson = await JsonSerializer.DeserializeAsync<JsonElement>(httpCtx.Request.Body);
    var feedback = objProcessor.ParseObjectAlternative(bodyJson);
    feedback["traceId"] = traceId;
    feedback["submittedAt"] = DateTime.UtcNow.ToString("o");

    if (!feedback.ContainsKey("rating"))
        return Results.BadRequest(new ErrorResponse("INVALID_FEEDBACK", "rating field is required (good/neutral/negative)", traceId));

    var result = await feedbackSvc.SubmitDynamicFeedbackAsync(feedback);
    return result.IsSuccess
        ? Results.Created($"/api/flow/{traceId}/feedback", new { traceId, feedbackId = result.Data, status = "saved" })
        : Results.BadRequest(new ErrorResponse("FEEDBACK_FAILED", result.Message, traceId));
})
.RequireRateLimiting("general")
.WithName("SubmitFeedback")
.WithOpenApi();

// GET /api/flow/{traceId}/feedback — List feedback for a trace
app.MapGet("/api/flow/{traceId}/feedback", async (
    string traceId,
    FeedbackService feedbackSvc) =>
{
    var feedbacks = await feedbackSvc.GetByTraceAsync(traceId);
    return Results.Ok(feedbacks);
})
.RequireRateLimiting("general")
.WithName("GetFeedback")
.WithOpenApi();

// ═══════════════════════════════════════════════════
// DEBUG ENDPOINTS
// ═══════════════════════════════════════════════════

app.MapGet("/api/debug/{traceId}", async (string traceId, NodeDebugService debugSvc) =>
{
    var traces = await debugSvc.GetTraceDebugAsync(traceId);
    return Results.Ok(new { traceId, steps = traces, count = traces?.Count() ?? 0 });
})
.RequireRateLimiting("general")
.WithName("GetDebugTrace")
.WithOpenApi();

app.MapGet("/api/debug/{traceId}/{stepId}", async (string traceId, string stepId, NodeDebugService debugSvc) =>
{
    var debug = await debugSvc.GetStepDebugAsync(traceId, stepId);
    return debug is not null ? Results.Ok(debug) : Results.NotFound(new ErrorResponse("STEP_NOT_FOUND", $"No debug data for step '{stepId}'", traceId));
})
.RequireRateLimiting("general")
.WithName("GetStepDebug")
.WithOpenApi();

// ═══════════════════════════════════════════════════
// FLOW DEFINITION CRUD
// ═══════════════════════════════════════════════════

app.MapGet("/api/flows", async (
    HttpContext httpCtx,
    FlowDefinitionService flowDefs,
    IObjectProcessor objProcessor) =>
{
    // Genie DNA: Build search filter from query params — empty fields auto-skipped
    var filterDict = new Dictionary<string, object>();
    foreach (var q in httpCtx.Request.Query)
        if (!string.IsNullOrEmpty(q.Value)) filterDict[q.Key] = q.Value.ToString();

    var filter = filterDict.Count > 0 ? objProcessor.BuildSearchFilter(filterDict) : null;
    var flows = await flowDefs.ListAsync(filter);
    return Results.Ok(flows);
})
.RequireRateLimiting("general")
.WithName("ListFlows")
.WithOpenApi();

app.MapGet("/api/flows/{flowId}", async (string flowId, FlowDefinitionService flowDefs) =>
{
    var flow = await flowDefs.GetAsync(flowId);
    return flow.IsSuccess ? Results.Ok(flow.Data) : Results.NotFound(new ErrorResponse("FLOW_NOT_FOUND", flow.Message, flowId));
})
.RequireRateLimiting("general")
.WithName("GetFlow")
.WithOpenApi();

app.MapPost("/api/flows", async (HttpContext httpCtx, FlowDefinitionService flowDefs, IObjectProcessor objProcessor) =>
{
    var bodyJson = await JsonSerializer.DeserializeAsync<JsonElement>(httpCtx.Request.Body);
    var flowDoc = objProcessor.ParseObjectAlternative(bodyJson);
    var result = await flowDefs.CreateFromDynamicAsync(flowDoc);
    return result.IsSuccess
        ? Results.Created($"/api/flows/{result.Data}", new { flowId = result.Data })
        : Results.BadRequest(new ErrorResponse("CREATE_FAILED", result.Message));
})
.RequireRateLimiting("general")
.WithName("CreateFlow")
.WithOpenApi();

app.MapPut("/api/flows/{flowId}", async (string flowId, HttpContext httpCtx, FlowDefinitionService flowDefs, IObjectProcessor objProcessor) =>
{
    var bodyJson = await JsonSerializer.DeserializeAsync<JsonElement>(httpCtx.Request.Body);
    var flowDoc = objProcessor.ParseObjectAlternative(bodyJson);
    flowDoc["flowId"] = flowId;
    var result = await flowDefs.UpdateFromDynamicAsync(flowDoc);
    return result.IsSuccess ? Results.Ok(new { flowId, updated = true }) : Results.BadRequest(new ErrorResponse("UPDATE_FAILED", result.Message, flowId));
})
.RequireRateLimiting("general")
.WithName("UpdateFlow")
.WithOpenApi();

app.MapDelete("/api/flows/{flowId}", async (string flowId, FlowDefinitionService flowDefs) =>
{
    var result = await flowDefs.DeleteAsync(flowId);
    return result.IsSuccess ? Results.Ok(new { flowId, deleted = true }) : Results.NotFound(new ErrorResponse("FLOW_NOT_FOUND", result.Message, flowId));
})
.RequireRateLimiting("general")
.WithName("DeleteFlow")
.WithOpenApi();

// ═══════════════════════════════════════════════════
// WEBSOCKET ENDPOINT
// ═══════════════════════════════════════════════════

app.Map("/ws/flow/{traceId}", async (HttpContext ctx, string traceId, WebSocketManager wsManager) =>
{
    if (!ctx.WebSockets.IsWebSocketRequest)
    {
        ctx.Response.StatusCode = 400;
        await ctx.Response.WriteAsync("WebSocket connection required");
        return;
    }

    var ws = await ctx.WebSockets.AcceptWebSocketAsync();
    var connectionId = Guid.NewGuid().ToString("N");
    wsManager.AddConnection(traceId, connectionId, ws);

    try
    {
        // Keep connection alive — listen for client close
        var buffer = new byte[1024];
        while (ws.State == WebSocketState.Open)
        {
            var result = await ws.ReceiveAsync(buffer, CancellationToken.None);
            if (result.MessageType == WebSocketMessageType.Close)
                break;
        }
    }
    finally
    {
        wsManager.RemoveConnection(traceId, connectionId);
        if (ws.State == WebSocketState.Open)
            await ws.CloseAsync(WebSocketCloseStatus.NormalClosure, "Closed", CancellationToken.None);
    }
});

// ═══════════════════════════════════════════════════
// HEALTH ENDPOINTS
// ═══════════════════════════════════════════════════

app.MapGet("/api/health", () => Results.Ok(new { status = "healthy", timestamp = DateTime.UtcNow }))
    .WithName("HealthLiveness").ExcludeFromDescription();

app.MapGet("/api/health/ready", async (IServiceProvider sp) =>
{
    var checks = new Dictionary<string, string>();
    try
    {
        // Check Elasticsearch (via IDatabaseService)
        var db = sp.GetService<IDatabaseService>();
        if (db is not null) { await db.PingAsync(); checks["elasticsearch"] = "ok"; }
        else checks["elasticsearch"] = "not_configured";
    }
    catch (Exception ex) { checks["elasticsearch"] = $"error: {ex.Message}"; }

    try
    {
        // Check Redis (via IQueueService)
        var queue = sp.GetService<IQueueService>();
        if (queue is not null) { await queue.PingAsync(); checks["redis"] = "ok"; }
        else checks["redis"] = "not_configured";
    }
    catch (Exception ex) { checks["redis"] = $"error: {ex.Message}"; }

    var allOk = checks.Values.All(v => v == "ok" || v == "not_configured");
    return allOk
        ? Results.Ok(new { status = "ready", checks, timestamp = DateTime.UtcNow })
        : Results.Json(new { status = "degraded", checks, timestamp = DateTime.UtcNow }, statusCode: 503);
}).WithName("HealthReady");

app.Run();

// ═══════════════════════════════════════════════════
// SUPPORTING TYPES
// ═══════════════════════════════════════════════════

record ErrorResponse(string Error, string Message, string? TraceId = null)
{
    public DateTime Timestamp { get; init; } = DateTime.UtcNow;
}

// ─── WebSocket Manager ──────────────────────────────
class WebSocketManager
{
    private readonly ConcurrentDictionary<string, ConcurrentDictionary<string, WebSocket>> _connections = new();
    private readonly ILogger<WebSocketManager> _logger;

    public WebSocketManager(ILogger<WebSocketManager> logger) => _logger = logger;

    public void AddConnection(string traceId, string connectionId, WebSocket ws)
    {
        var traceConns = _connections.GetOrAdd(traceId, _ => new ConcurrentDictionary<string, WebSocket>());
        traceConns[connectionId] = ws;
        _logger.LogInformation("WebSocket connected: trace={TraceId} conn={ConnId}", traceId, connectionId);
    }

    public void RemoveConnection(string traceId, string connectionId)
    {
        if (_connections.TryGetValue(traceId, out var conns))
        {
            conns.TryRemove(connectionId, out _);
            if (conns.IsEmpty) _connections.TryRemove(traceId, out _);
        }
    }

    public async Task BroadcastToTrace(string traceId, object message)
    {
        if (!_connections.TryGetValue(traceId, out var conns)) return;

        var json = JsonSerializer.Serialize(message);
        var bytes = Encoding.UTF8.GetBytes(json);

        foreach (var (connId, ws) in conns)
        {
            try
            {
                if (ws.State == WebSocketState.Open)
                    await ws.SendAsync(bytes, WebSocketMessageType.Text, true, CancellationToken.None);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to send WS message to {ConnId}", connId);
                conns.TryRemove(connId, out _);
            }
        }
    }
}
