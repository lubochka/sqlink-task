# Skill 15 — API Gateway: Implementation Guide

## Prerequisites
- Skill 01 (Core Interfaces) — IObjectProcessor, IDatabaseService, IQueueService
- Skill 02 (ObjectProcessor) — ParseObjectAlternative, BuildSearchFilter
- Skill 09 (Flow Orchestrator) — FlowOrchestrator service registered in DI
- Skill 13 (Feedback Service) — FeedbackService registered
- Skill 14 (Node Debugger) — NodeDebugService registered
- .NET 9 SDK with ASP.NET

## Step 1: Create the Minimal API Project
1. Create new ASP.NET 9 Minimal API project: `dotnet new web -n XIIGen.Gateway`
2. Add NuGet packages: `Microsoft.AspNetCore.RateLimiting`, `Swashbuckle.AspNetCore`
3. Register CORS, Swagger, RateLimiter, ResponseCompression, HealthChecks
4. Register all XIIGen services (FlowOrchestrator, FlowDefinitionService, etc.) via DI

## Step 2: Configure Rate Limiting
1. Add sliding window rate limiter with 3 policies: `trigger` (10/min), `status` (60/min), `general` (30/min)
2. Partition by remote IP address (or authenticated user ID when auth is enabled)
3. Configure rejection status code as 429
4. Add `Retry-After` header in response

## Step 3: Implement Flow Trigger Endpoint
1. `POST /api/flow/trigger` — accepts dynamic JSON body
2. Parse body via `ObjectProcessor.ParseObjectAlternative` (Genie DNA — no fixed DTOs)
3. Extract `flowId`, `traceId` (generate if missing), `input`
4. Validate flowId exists via FlowDefinitionService
5. Call `FlowOrchestrator.TriggerFlowAsync` — this returns immediately (async execution)
6. Return `202 Accepted` with `{ traceId, flowId, status, pollIntervalMs, wsUrl, startedAt }`

## Step 4: Implement Status Polling Endpoint
1. `GET /api/flow/{traceId}/status`
2. Call `FlowOrchestrator.GetExecutionAsync(traceId)`
3. Calculate progress: `completedSteps / totalSteps`
4. Return step-by-step status with progress percentage
5. Include `result` field only when status is "Completed"
6. Return 404 with structured error if traceId not found

## Step 5: Implement WebSocket Live Updates
1. Add WebSocket middleware: `app.UseWebSockets()`
2. Create `WebSocketManager` class with ConcurrentDictionary<traceId, connections>
3. Map `/ws/flow/{traceId}` endpoint that accepts WebSocket upgrade
4. Register callbacks on FlowOrchestrator for step_complete and flow_complete events
5. Broadcast JSON messages to all connected WebSocket clients for that traceId
6. Handle client disconnection gracefully

## Step 6: Implement Feedback Endpoints
1. `POST /api/flow/{traceId}/feedback` — dynamic document with `rating` (required) + any extra fields
2. Parse via ObjectProcessor (Genie DNA)
3. Inject `traceId` and `submittedAt` into the feedback document
4. Validate `rating` field exists
5. Forward to FeedbackService.SubmitDynamicFeedbackAsync
6. `GET /api/flow/{traceId}/feedback` — list all feedback for a trace

## Step 7: Implement Debug Endpoints
1. `GET /api/debug/{traceId}` — full debug timeline for a trace
2. `GET /api/debug/{traceId}/{stepId}` — single step debug data
3. Forward to NodeDebugService methods
4. Return raw dynamic documents (Genie DNA — no reshaping)

## Step 8: Implement Flow CRUD Endpoints
1. `GET /api/flows` — list with dynamic query param filters via BuildSearchFilter
2. `GET /api/flows/{flowId}` — get single definition
3. `POST /api/flows` — create from dynamic document
4. `PUT /api/flows/{flowId}` — update from dynamic document
5. `DELETE /api/flows/{flowId}` — delete
6. All use ObjectProcessor for request parsing (Genie DNA)

## Step 9: Implement Health Endpoints
1. `GET /api/health` — simple liveness (always 200)
2. `GET /api/health/ready` — check Elasticsearch + Redis connectivity
3. Return 503 if any downstream service is unhealthy

## Step 10: Add Middleware
1. Global exception handler — catch all unhandled exceptions, return structured ErrorResponse
2. Request logging — log method, path, status code, duration
3. Response compression — enable for JSON responses
4. Configure OpenAPI decorators on all endpoints

## Step 11: Configure appsettings.json
1. Gateway section: PollIntervalHintMs, MaxPollCount, WebSocketEnabled
2. RateLimiting section: per-endpoint limits
3. CORS section: AllowedOrigins array
4. Auth section: Enabled flag, ExcludedPaths

## Step 12: Register in DI and Test
1. Register WebSocketManager as singleton
2. Wire all endpoints with rate limiting policies
3. Test: trigger → poll → verify completion
4. Test: trigger → WebSocket → verify real-time events
5. Test: rate limit exceeded → verify 429
6. Test: invalid flowId → verify 404 with ErrorResponse

## Troubleshooting
- **WebSocket not connecting**: Ensure `app.UseWebSockets()` is called BEFORE endpoint mapping
- **Rate limiter not working**: Verify `app.UseRateLimiter()` is in the pipeline
- **CORS errors**: Check AllowedOrigins includes your client URL; use `AllowCredentials()` for WebSocket
- **502 on polling**: Check FlowOrchestrator is registered and Elasticsearch is reachable

## Customization
- Replace sliding window with token bucket for burstier traffic patterns
- Add JWT auth middleware (Skill 20) before rate limiter for per-user limits
- Add response caching for completed flow results
- Add Server-Sent Events (SSE) as alternative to WebSocket for simpler clients
