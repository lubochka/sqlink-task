---
skill_id: "23"
name: monitoring-service
title: "Monitoring Service"
layer: "L6: Platform Services"
version: "17.0"
status: "active"
dependencies:
  - "01-core-interfaces"
  - "02-object-processor"
  - "03-elasticsearch-datastore"
  - "04-redis-queue-service"
  - "22-logger-service"
dotnet_namespace: "XIIGen.Services.Monitoring"
di_registration: "services.AddXIIGenMonitoringService()"
es_index: "xiigen-metrics"
genie_dna:
  - "DNA-1: Metric records and alert rules as dynamic documents"
  - "DNA-2: BuildSearchFilter for metric queries (service, metric, timerange — skip empty)"
  - "DNA-3: Inherits MicroserviceBase (components #15 Sanity check, #12 Data Validation)"
  - "DNA-5: DataProcessResult for all operations"
  - "DNA-FREEDOM: Alert rules are DYNAMIC — admins define thresholds without code"
triggers: monitoring, metrics, health check, heartbeat, alert, Prometheus, service registry, performance, sanity check
---

# Skill 23: Monitoring Service
## Service Health, Metrics & Alerts — Components #12, #15

**Classification: HYBRID — MACHINE health checks, FREEDOM alert rules**
From Architecture.docx: Component #12 "Data Validation — compare internal with external" and #15 "Sanity check — system health." The monitoring INFRASTRUCTURE is static. But alert RULES and metric DEFINITIONS are dynamic documents that admins configure.

---

## Genie DNA Integration

### Alert Rules as Dynamic Documents (DNA-1, FREEDOM)
Admins define alert rules without code — just store a rule document:
```json
{
  "ruleName": "high_error_rate",
  "service": "AITransform",
  "metric": "error_count",
  "condition": "gt",
  "threshold": 50,
  "window": "5m",
  "severity": "critical",
  "notifyChannels": ["internal", "email"],
  "createdBy": "admin@company.com"
}
```
Adding/modifying alert rules = updating a document. No deployment.

### Metric Records as Dynamic Documents (DNA-1)
```csharp
// Each service reports metrics as dynamic documents
var metric = ObjectProcessor.ParseDocument(new {
    service = "FlowOrchestrator",
    metric = "flow_execution_time",
    value = 3250.5,
    unit = "ms",
    tags = new { flowId = "flow_123", success = true },
    timestamp = DateTime.UtcNow
});
```

---

## Interface

```csharp
public interface IMonitoringService
{
    Task<DataProcessResult<bool>> RegisterServiceAsync(Dictionary<string, object> serviceInfo);
    Task RecordMetricAsync(Dictionary<string, object> metricDoc);
    Task<DataProcessResult<bool>> RecordHeartbeatAsync(string serviceName);
    Task<DataProcessResult<List<Dictionary<string, object>>>> GetMetricsAsync(
        Dictionary<string, object> filter);
    Task<DataProcessResult<string>> CreateAlertRuleAsync(Dictionary<string, object> ruleDoc);
    Task<DataProcessResult<Dictionary<string, object>>> GetHealthStatusAsync();
}
```

All parameters use `Dictionary<string, object>` — dynamic documents, not typed models.

## Health Check Model
Services send heartbeats every 30s. Missing 3 consecutive heartbeats = service marked unhealthy.

## Prometheus Compatibility
Metrics exposed in Prometheus format at `/metrics` endpoint for grafana dashboards.

## Alternatives
All alternatives MUST: store metrics/rules as dynamic documents, use BuildSearchFilter for metric queries, support dynamic alert rule definitions, return DataProcessResult.
