<?php
// XIIGen Monitoring Service — PHP | Skill 23
namespace XIIGen\Platform\Monitoring;
use XIIGen\Core\{MicroserviceBase, DataProcessResult, IDatabaseService, IQueueService};

class MonitoringService extends MicroserviceBase {
    protected string $serviceName = 'monitoring-service';
    private array $metrics = [];

    public function __construct(IDatabaseService $db, IQueueService $queue) { parent::__construct($db, $queue); }

    public function recordMetric(string $name, float $value, array $tags = []): void {
        $this->metrics[$name] ??= [];
        $this->metrics[$name][] = ['value' => $value, 'tags' => $tags, 'timestamp' => date('c')];
        if (count($this->metrics[$name]) > 1000) $this->metrics[$name] = array_slice($this->metrics[$name], -500);
    }

    public function getLatestMetrics(): array {
        $latest = [];
        foreach ($this->metrics as $name => $points) if (!empty($points)) $latest[$name] = end($points)['value'];
        return $latest;
    }

    public function checkAllServices(): DataProcessResult {
        $health = ['status' => 'healthy', 'timestamp' => date('c'), 'metrics' => $this->getLatestMetrics()];
        $this->storeDocument('health-checks', date('YmdHis'), $health);
        return DataProcessResult::success($health);
    }
}
