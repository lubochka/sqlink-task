// XIIGen Monitoring Service — Java | Skill 23
package com.xiigen.platform.monitoring;
import com.xiigen.core.*;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class MonitoringService extends MicroserviceBase {
    private record MetricPoint(double value, Map<String, String> tags, Instant timestamp) {}
    private final Map<String, List<MetricPoint>> metrics = new ConcurrentHashMap<>();

    public MonitoringService(IDatabaseService db, IQueueService queue) { super(db, queue, "monitoring-service"); }

    public void recordMetric(String name, double value, Map<String, String> tags) {
        metrics.computeIfAbsent(name, k -> new ArrayList<>()).add(new MetricPoint(value, tags != null ? tags : Map.of(), Instant.now()));
        var list = metrics.get(name); if (list.size() > 1000) list.subList(0, 500).clear();
    }

    public Map<String, Double> getLatestMetrics() {
        Map<String, Double> latest = new HashMap<>();
        metrics.forEach((name, points) -> { if (!points.isEmpty()) latest.put(name, points.get(points.size() - 1).value()); });
        return latest;
    }

    public DataProcessResult<Map<String, Object>> checkAllServices() throws Exception {
        var health = Map.of("status", "healthy", "timestamp", Instant.now().toString(), "metrics", (Object) getLatestMetrics());
        storeDocument("health-checks", Instant.now().toString().replace(":", ""), health);
        return DataProcessResult.success(health);
    }
}
