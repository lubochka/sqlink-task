# XIIGen Monitoring Service — Python | Skill 23
from datetime import datetime, timezone
from dataclasses import dataclass, field
from core_interfaces import IDatabaseService, IQueueService, DataProcessResult, MicroserviceBase

@dataclass
class MetricPoint:
    value: float; tags: dict = field(default_factory=dict); timestamp: str = ""

class MonitoringService(MicroserviceBase):
    service_name = "monitoring-service"
    def __init__(self, db: IDatabaseService, queue: IQueueService):
        super().__init__(db, queue)
        self._metrics: dict[str, list[MetricPoint]] = {}

    def record_metric(self, name: str, value: float, tags: dict = None):
        if name not in self._metrics: self._metrics[name] = []
        self._metrics[name].append(MetricPoint(value=value, tags=tags or {}, timestamp=datetime.now(timezone.utc).isoformat()))
        if len(self._metrics[name]) > 1000: self._metrics[name] = self._metrics[name][-500:]

    def get_latest_metrics(self) -> dict[str, float]:
        return {name: points[-1].value for name, points in self._metrics.items() if points}

    async def check_all_services(self) -> DataProcessResult:
        health = {"status": "healthy", "timestamp": datetime.now(timezone.utc).isoformat(), "metrics": self.get_latest_metrics()}
        await self.store_document("health-checks", datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S"), health)
        return DataProcessResult.success(health)
