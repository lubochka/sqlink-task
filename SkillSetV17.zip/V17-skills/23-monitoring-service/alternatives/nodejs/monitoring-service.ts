// XIIGen Monitoring Service — Node.js/TypeScript | Skill 23
import { IDatabaseService, IQueueService, DataProcessResult, MicroserviceBase } from '../../01-core-interfaces';

interface MetricPoint { value: number; tags: Record<string, string>; timestamp: Date; }

export class MonitoringService extends MicroserviceBase {
  private metrics: Map<string, MetricPoint[]> = new Map();
  protected serviceName = 'monitoring-service';

  constructor(db: IDatabaseService, queue: IQueueService) { super(db, queue); }

  recordMetric(name: string, value: number, tags: Record<string, string> = {}): void {
    if (!this.metrics.has(name)) this.metrics.set(name, []);
    const points = this.metrics.get(name)!;
    points.push({ value, tags, timestamp: new Date() });
    if (points.length > 1000) points.splice(0, 500);
  }

  getLatestMetrics(): Record<string, number> {
    const latest: Record<string, number> = {};
    for (const [name, points] of this.metrics) if (points.length > 0) latest[name] = points[points.length - 1].value;
    return latest;
  }

  async checkAllServices(): Promise<DataProcessResult<any>> {
    const health = { status: 'healthy', timestamp: new Date(), metrics: this.getLatestMetrics() };
    await this.storeDocument('health-checks', new Date().toISOString().replace(/[:.]/g, ''), health);
    return DataProcessResult.success(health);
  }

  getMetricHistory(name: string, limit = 100): MetricPoint[] {
    return (this.metrics.get(name) || []).slice(-limit);
  }
}
