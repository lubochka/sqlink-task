// XIIGen Monitoring Service — Rust | Skill 23
use serde_json::{json, Value};
use std::collections::HashMap;
use std::sync::RwLock;
use chrono::Utc;
use crate::core::{DataProcessResult, IDatabaseService, IQueueService, MicroserviceBase};

struct MetricPoint { value: f64, tags: HashMap<String, String>, timestamp: String }

pub struct MonitoringService {
    base: MicroserviceBase,
    metrics: RwLock<HashMap<String, Vec<MetricPoint>>>,
}

impl MonitoringService {
    pub fn new(db: Box<dyn IDatabaseService>, queue: Box<dyn IQueueService>) -> Self {
        Self { base: MicroserviceBase::new(db, queue, "monitoring-service"), metrics: RwLock::new(HashMap::new()) }
    }

    pub fn record_metric(&self, name: &str, value: f64, tags: Option<HashMap<String, String>>) {
        let mut m = self.metrics.write().unwrap();
        let points = m.entry(name.to_string()).or_insert_with(Vec::new);
        points.push(MetricPoint { value, tags: tags.unwrap_or_default(), timestamp: Utc::now().to_rfc3339() });
        if points.len() > 1000 { points.drain(..500); }
    }

    pub fn get_latest_metrics(&self) -> HashMap<String, f64> {
        let m = self.metrics.read().unwrap();
        m.iter().filter_map(|(k, v)| v.last().map(|p| (k.clone(), p.value))).collect()
    }

    pub async fn check_all_services(&self) -> DataProcessResult<Value> {
        let health = json!({"status": "healthy", "timestamp": Utc::now().to_rfc3339(), "metrics": self.get_latest_metrics()});
        self.base.store_document("health-checks", &Utc::now().format("%Y%m%d%H%M%S").to_string(), &health).await;
        DataProcessResult::success(health)
    }
}
