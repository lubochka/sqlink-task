// XIIGen.Platform.Monitoring/MonitoringService.cs - Skill 23 | .NET 9
using Microsoft.Extensions.Logging;
using XIIGen.Core.Base;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Platform.Monitoring;

public class MonitoringService : MicroserviceBase
{
    private readonly Dictionary<string, List<MetricPoint>> _metrics = [];

    public MonitoringService(IDatabaseService db, IQueueService queue, ILogger<MonitoringService> logger)
        : base(db, queue, logger) { ServiceName = "monitoring-service"; }

    public void RecordMetric(string name, double value, Dictionary<string, string> tags = null)
    {
        if (!_metrics.ContainsKey(name)) _metrics[name] = [];
        _metrics[name].Add(new MetricPoint { Value = value, Tags = tags ?? [], Timestamp = DateTime.UtcNow });
        if (_metrics[name].Count > 1000) _metrics[name].RemoveRange(0, 500); // Keep last 500
    }

    public async Task<HealthCheckResult> CheckAllServicesAsync(CancellationToken ct = default)
    {
        var result = await CheckHealthAsync();
        await StoreDocumentAsync("health-checks", DateTime.UtcNow.ToString("yyyyMMddHHmmss"), result, ct: ct);
        return result;
    }

    public Dictionary<string, double> GetLatestMetrics()
    {
        var latest = new Dictionary<string, double>();
        foreach (var (name, points) in _metrics)
            if (points.Count > 0) latest[name] = points[^1].Value;
        return latest;
    }

    protected override async Task ProcessAsync(CancellationToken ct)
    {
        await CheckAllServicesAsync(ct);
        await Task.Delay(TimeSpan.FromSeconds(30), ct);
    }
}

public class MetricPoint
{
    public double Value { get; set; }
    public Dictionary<string, string> Tags { get; set; } = [];
    public DateTime Timestamp { get; set; }
}
