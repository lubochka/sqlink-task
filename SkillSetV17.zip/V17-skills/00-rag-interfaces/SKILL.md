# Skill 00a: RAG Interfaces
## Generic RAG Contracts for Vector + Graph Backends

**Status:** ✅ Complete | **Priority:** P0 | **Layer:** L0: Foundation
**Dependencies:** 01 (Core Interfaces) | **Phase:** 6
**Estimated LOC:** 250 (primary) + 150/alt × 5

## Overview
Defines the generic `IRagService` interface that abstracts over all RAG backends — vector stores, graph databases, and hybrid systems. Any backend (Neo4j, Pinecone, Azure AI Search, CosmosDB, Elasticsearch kNN, Gremlin, LightRAG, LlamaIndex, etc.) implements this single contract.

## Key Concepts
- **Unified interface:** Vector search, hybrid search, graph traversal, and storage through one contract
- **RagCapabilities:** Each provider declares what it supports (vector, graph, hybrid, full-text)
- **Provider-agnostic:** Swap backends via DI configuration, no code changes
- **10 backend alternatives:** Neo4j, LightRAG, nano-graphrag, LangChain, LlamaIndex, Graphlit, Memgraph, Neptune+Bedrock, Contextual AI, HybridRAG DIY

## Interface Contract

### IRagService
| Method | Purpose |
|--------|---------|
| `StoreEmbeddingAsync` | Store vector embedding + metadata |
| `VectorSearchAsync` | Similarity search by embedding |
| `HybridSearchAsync` | Combined text + vector search |
| `StoreNodeAsync` | Store graph node (graph backends) |
| `StoreEdgeAsync` | Store graph edge/relationship |
| `TraverseAsync` | Graph traversal (BFS/DFS) |
| `DeleteAsync` | Remove embedding/node |
| `CollectionExistsAsync` | Check if collection/index exists |
| `CreateCollectionAsync` | Initialize collection with schema |

### Supporting Models
- `RagSearchResult`: id, score, content, metadata
- `RagGraphResult`: nodeId, label, properties, edges
- `RagCapabilities`: flags for supported operations
- `TraversalDirection`: Outgoing, Incoming, Both

## Primary Implementation (.NET 9)
See `Implementation/IRagService.cs` (253 lines) — contains full interface, models, enums, and DI registration extensions.

## RAG Backend Alternatives (10)
| # | Backend | Type | Best For |
|---|---------|------|----------|
| 1 | Neo4j GraphRAG | Graph+Vector | Enterprise, rich ecosystem |
| 2 | LightRAG | Vector+Graph | Budget-conscious, 80-90% fewer API calls |
| 3 | nano-graphrag | Graph | Full control, hackable |
| 4 | LangChain KG RAG | Orchestration | LangChain ecosystem |
| 5 | LlamaIndex GraphRAG | Data pipeline | 160+ connectors |
| 6 | Graphlit | Managed SaaS | Zero-ops, auto-extraction |
| 7 | Memgraph | In-memory graph | Real-time streaming |
| 8 | Neptune + Bedrock | AWS managed | Enterprise AWS |
| 9 | Contextual AI | Agentic | No static graph needed |
| 10 | HybridRAG DIY | Pattern | Maximum flexibility |

## Integration Points
- **Consumed by:** Skill 00b (RAG Planner), Skill 16 (AI Context Service)
- **Implementations:** Each backend gets its own service class implementing IRagService
- **DI Registration:** `services.AddRagService<Neo4jRagService>(config)`
