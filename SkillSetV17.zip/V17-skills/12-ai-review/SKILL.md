---
name: ai-review
description: AI-powered code review service that validates generated code for quality, security, accessibility, and pattern compliance
triggers: ai review, code review, quality check, validation, review generated code, security scan, accessibility check
dependencies: [01-core-interfaces, 02-object-processor, 06-ai-providers, 07-ai-dispatcher, 11-ai-transform]
layer: L4-StepExecutors
genie-dna: Review results stored as dynamic documents via ObjectProcessor. Review criteria queries use BuildSearchFilter. All returns use DataProcessResult.
phase: 3
---

# Skill 12: AI Review
## AI-Powered Code Quality, Security & Accessibility Validation

The **quality inspector** of the pipeline. Takes generated code (from Skill 11) and submits it to a dedicated review AI model. The reviewer checks for bugs, security vulnerabilities, accessibility issues, pattern compliance (Genie DNA), and provides an overall quality score with specific fix suggestions.

---

## Architecture

```
Input (from Skill 11 output or flow context):
  { clientCode, serverCode, databaseCode, targetStack, originalComponents }
       ↓
  AiReviewService.ExecuteAsync(context)
       ↓
  ┌──────────────────────────────────────┐
  │ 1. Build Review Prompt               │ ← Code + review criteria
  │ 2. Load Past Review Patterns         │ ← Common issues from history
  │ 3. Dispatch to Review Model          │ ← Separate model from generator
  │ 4. Parse Structured Review Response  │ ← Issues[], score, suggestions
  │ 5. Apply Auto-Fix Suggestions        │ ← Optional: fix simple issues
  │ 6. Store Review in ES                │ ← Debug snapshot
  │ 7. Return Pass/Fail + Details        │
  └──────────────────────────────────────┘
       ↓
  Output: { passed, overallScore, issues[], suggestions[], fixedCode? }
```

## Review Categories

| Category | Weight | Checks |
|----------|--------|--------|
| Correctness | 30% | Syntax valid, logic errors, type mismatches |
| Security | 25% | XSS, injection, auth gaps, secrets exposure |
| Accessibility | 15% | ARIA labels, keyboard nav, contrast, semantic HTML |
| Performance | 10% | N+1 queries, memory leaks, bundle size |
| Patterns | 10% | Genie DNA compliance, SOLID, clean architecture |
| Completeness | 10% | All design elements covered, error states handled |

## Issue Severity Levels

| Level | Action | Description |
|-------|--------|-------------|
| `critical` | Block | Security vulnerability, data loss risk |
| `error` | Block | Logic bug, missing error handling |
| `warning` | Pass with notes | Accessibility gap, missing types |
| `info` | Pass | Style suggestion, optimization hint |

## Review Prompt Structure

```
You are a senior code reviewer. Review the following generated code for:
1. Correctness — syntax, logic, types
2. Security — XSS, injection, auth, secrets
3. Accessibility — ARIA, keyboard, semantics
4. Performance — queries, memory, bundle size
5. Pattern compliance — dependency injection, error handling
6. Completeness — all design elements, error states

## Code to Review

### Client Code ({stack})
```{language}
{clientCode}
```

### Server Code ({stack})
```{language}
{serverCode}
```

### Database Code ({stack})
```{language}
{databaseCode}
```

## Common Issues from Past Reviews
{pastIssuePatterns}

## Required Response Format (JSON)
{
  "overallScore": 0.0-1.0,
  "passed": true/false,
  "issues": [
    { "category": "security", "severity": "critical", "line": 42,
      "code": "clientCode", "message": "...", "suggestion": "..." }
  ],
  "suggestions": ["..."],
  "summary": "..."
}
```

## Configuration

```yaml
nodeType: AiReview
config:
  reviewModel: "claude-opus"           # Dedicated review model (different from generator)
  passThreshold: 0.7                   # Score below this = fail
  blockOnCritical: true                # Any critical issue = fail regardless of score
  maxIssues: 50                        # Stop after N issues
  categories: ["correctness", "security", "accessibility", "performance", "patterns", "completeness"]
  autoFixSimple: false                 # Attempt to fix simple issues automatically
  includeHistoricalPatterns: true      # Include common issues from past reviews
  timeoutSeconds: 90                   # Review timeout
```

## Key Interfaces

```csharp
public interface IAiReviewService
{
    Task<DataProcessResult<ReviewOutput>> ExecuteAsync(
        FlowStepContext context, CancellationToken ct = default);

    Task<DataProcessResult<ReviewOutput>> ReviewCodeAsync(
        ReviewInput input, ReviewConfig config,
        CancellationToken ct = default);
}

public record ReviewInput(
    string? ClientCode, string? ServerCode, string? DatabaseCode,
    string TargetClient, string TargetServer, string TargetDatabase,
    IReadOnlyList<Dictionary<string, object>>? OriginalComponents);

public record ReviewOutput(
    string ReviewId, bool Passed, double OverallScore,
    IReadOnlyList<ReviewIssue> Issues,
    IReadOnlyList<string> Suggestions, string Summary,
    string? FixedClientCode, string? FixedServerCode, string? FixedDatabaseCode);

public record ReviewIssue(
    string Category, string Severity, int? Line,
    string CodeSection, string Message, string? Suggestion);
```

## Genie DNA Integration

- **DNA-1:** Review results stored as dynamic documents — any additional fields from AI response preserved
- **DNA-2:** Historical issue queries use BuildSearchFilter with empty-field skipping
- **DNA-3:** All operations return DataProcessResult<ReviewOutput>
- **DNA-5:** Review model accessed via IAiProvider/IAiDispatcher

## Dependencies

| Skill | Usage |
|-------|-------|
| 06-ai-providers | IAiProvider for review model |
| 07-ai-dispatcher | Dispatch with retry + timeout |
| 11-ai-transform | Input: receives transform output |
| 13-feedback-service | Load common issue patterns |
| 14-node-debugger | Store review snapshots |

## Error Handling

- Review model timeout: return DataProcessResult.Failure, flow can retry or proceed with warning
- JSON parse failure on review response: extract what's parseable, score as 0.5 (uncertain)
- No code to review: return auto-pass with score 1.0

## Test Scenarios

1. Clean code submission → passed: true, score > 0.8, no critical issues
2. Code with XSS vulnerability → passed: false, critical security issue flagged
3. Missing ARIA attributes → passed: true (warning only), accessibility issue noted
4. Review model timeout → DataProcessResult.Failure with timeout error
5. Malformed review JSON → partial parse, score 0.5, warning about incomplete review
6. Empty code sections → auto-pass with 1.0 score
7. Historical patterns loaded → review prompt includes past common issues
