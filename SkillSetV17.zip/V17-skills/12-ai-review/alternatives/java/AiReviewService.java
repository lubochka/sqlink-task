// =============================================================================
// Skill 12 — AI Review Service (Java 21+)
// AI-powered code quality, security & accessibility review
// Genie DNA: Dynamic documents (Map), buildSearchFilter, DataProcessResult
// =============================================================================

package com.xiigen.services.aireview;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

// ---------------------------------------------------------------------------
// Interfaces (matching XIIGen generic contracts)
// ---------------------------------------------------------------------------
interface AiProvider {
    CompletableFuture<String> complete(String model, String system, String prompt,
                                       double temperature, int maxTokens);
}

interface DatabaseProvider {
    CompletableFuture<List<Map<String, Object>>> query(String index, Map<String, Object> filters);
    CompletableFuture<Map<String, Object>> upsert(String index, String docId, Map<String, Object> doc);
}

interface NodeDebugger {
    CompletableFuture<Void> snapshot(String traceId, String nodeId, String phase,
                                     Map<String, Object> data);
}

interface ObjectProcessor {
    Map<String, Object> parseObjectAlternative(Map<String, Object> doc);
    Map<String, Object> buildSearchFilter(Map<String, Object> params);
}

// ---------------------------------------------------------------------------
// Models
// ---------------------------------------------------------------------------
record ReviewConfig(
    String reviewModel,
    double passThreshold,
    boolean blockOnCritical,
    int maxIssues,
    List<String> categories,
    boolean autoFixSimple,
    boolean includeHistoricalPatterns,
    int timeoutSeconds
) {
    static ReviewConfig defaults() {
        return new ReviewConfig("claude-opus", 0.7, true, 50,
            List.of("correctness", "security", "accessibility", "performance", "patterns", "completeness"),
            false, true, 90);
    }
}

record ReviewInput(
    String clientCode, String serverCode, String databaseCode,
    String targetClient, String targetServer, String targetDatabase,
    List<Map<String, Object>> originalComponents
) {}

record ReviewIssue(String category, String severity, Integer line,
                   String codeSection, String message, String suggestion) {}

record ReviewOutput(
    String reviewId, boolean passed, double overallScore,
    List<ReviewIssue> issues, List<String> suggestions, String summary,
    String fixedClientCode, String fixedServerCode, String fixedDatabaseCode,
    Instant reviewedAt
) {
    static ReviewOutput empty() {
        return new ReviewOutput(UUID.randomUUID().toString().replace("-", ""),
            true, 1.0, List.of(), List.of(), "No code to review",
            null, null, null, Instant.now());
    }
}

record DataProcessResult<T>(boolean success, T data, String error, Map<String, Object> metadata) {
    static <T> DataProcessResult<T> ok(T data) {
        return new DataProcessResult<>(true, data, null, Map.of());
    }
    static <T> DataProcessResult<T> fail(String error) {
        return new DataProcessResult<>(false, null, error, Map.of());
    }
}

// ---------------------------------------------------------------------------
// Service
// ---------------------------------------------------------------------------
public class AiReviewService {

    private static final Logger log = Logger.getLogger(AiReviewService.class.getName());
    private static final Pattern MD_FENCE = Pattern.compile("```(?:json)?\\s*|```");
    private static final Gson GSON = new Gson();

    private final AiProvider ai;
    private final DatabaseProvider db;
    private final NodeDebugger debugger;
    private final ObjectProcessor obj;
    private final ReviewConfig cfg;

    public AiReviewService(AiProvider ai, DatabaseProvider db,
                           NodeDebugger debugger, ObjectProcessor obj,
                           ReviewConfig cfg) {
        this.ai = ai;
        this.db = db;
        this.debugger = debugger;
        this.obj = obj;
        this.cfg = cfg != null ? cfg : ReviewConfig.defaults();
    }

    // -- Public entry point -----------------------------------------------
    public CompletableFuture<DataProcessResult<ReviewOutput>> review(
            String traceId, String nodeId, ReviewInput input) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                // 1. Collect code sections
                var sections = collectCode(input);
                if (sections.isEmpty()) {
                    return DataProcessResult.ok(ReviewOutput.empty());
                }

                debugger.snapshot(traceId, nodeId, "review-input",
                    Map.of("sections", new ArrayList<>(sections.keySet()))).join();

                // 2. Load historical patterns
                String history = "";
                if (cfg.includeHistoricalPatterns()) {
                    history = loadHistoricalPatterns(input);
                }

                // 3. Build prompt
                String prompt = buildPrompt(sections, input, history);

                // 4. Call AI
                String raw = ai.complete(cfg.reviewModel(), buildSystemPrompt(),
                    prompt, 0.1, 4096).join();

                debugger.snapshot(traceId, nodeId, "review-raw",
                    Map.of("rawLength", raw.length())).join();

                // 5. Parse response
                ReviewOutput output = parseResponse(raw, sections);

                // 6. Store review
                var doc = obj.parseObjectAlternative(Map.of(
                    "reviewId", output.reviewId(),
                    "traceId", traceId,
                    "nodeId", nodeId,
                    "passed", output.passed(),
                    "score", output.overallScore(),
                    "issueCount", output.issues().size(),
                    "summary", output.summary(),
                    "reviewedAt", output.reviewedAt().toString()
                ));
                db.upsert("xiigen-reviews", output.reviewId(), doc).join();

                debugger.snapshot(traceId, nodeId, "review-output", Map.of(
                    "passed", output.passed(),
                    "score", output.overallScore(),
                    "issues", output.issues().size(),
                    "critical", output.issues().stream()
                        .filter(i -> "critical".equals(i.severity())).count()
                )).join();

                return DataProcessResult.ok(output);
            } catch (Exception ex) {
                log.severe("AiReviewService.review failed: " + ex.getMessage());
                return DataProcessResult.fail(ex.getMessage());
            }
        });
    }

    // -- Private helpers --------------------------------------------------
    private Map<String, String> collectCode(ReviewInput input) {
        var sections = new LinkedHashMap<String, String>();
        if (input.clientCode() != null && !input.clientCode().isBlank())
            sections.put("client", input.clientCode());
        if (input.serverCode() != null && !input.serverCode().isBlank())
            sections.put("server", input.serverCode());
        if (input.databaseCode() != null && !input.databaseCode().isBlank())
            sections.put("database", input.databaseCode());
        return sections;
    }

    private String buildSystemPrompt() {
        String cats = String.join(", ", cfg.categories());
        return "You are a senior code reviewer. Review code across: " + cats + ".\n" +
            "Respond ONLY with JSON:\n" +
            "{\"overallScore\":0.0-1.0,\"issues\":[{\"category\":\"...\",\"severity\":\"critical|error|warning|info\"," +
            "\"line\":null,\"codeSection\":\"client|server|database\",\"message\":\"...\",\"suggestion\":\"...\"}]," +
            "\"suggestions\":[\"...\"],\"summary\":\"...\"}\n" +
            "Severity: critical=security/crash, error=bug, warning=style, info=improvement.";
    }

    private String buildPrompt(Map<String, String> sections, ReviewInput input, String history) {
        var sb = new StringBuilder();
        sb.append("Review code targeting %s/%s/%s:\n".formatted(
            input.targetClient(), input.targetServer(), input.targetDatabase()));
        for (var entry : sections.entrySet()) {
            sb.append("\n=== ").append(entry.getKey().toUpperCase()).append(" CODE ===\n");
            sb.append(entry.getValue()).append("\n");
        }
        if (history != null && !history.isBlank()) {
            sb.append("\nHistorical patterns:\n").append(history);
        }
        return sb.toString();
    }

    private String loadHistoricalPatterns(ReviewInput input) {
        try {
            var filter = obj.buildSearchFilter(Map.of(
                "severity", "critical,error",
                "targetServer", input.targetServer(),
                "targetClient", input.targetClient()
            ));
            var docs = db.query("xiigen-reviews", filter).join();
            if (docs == null || docs.isEmpty()) return "";
            return docs.stream()
                .limit(5)
                .map(d -> d.getOrDefault("summary", "").toString())
                .filter(s -> !s.isBlank())
                .reduce("", (a, b) -> a + "\n- " + b);
        } catch (Exception ex) {
            log.warning("Failed to load historical patterns: " + ex.getMessage());
            return "";
        }
    }

    @SuppressWarnings("unchecked")
    private ReviewOutput parseResponse(String raw, Map<String, String> sections) {
        String cleaned = MD_FENCE.matcher(raw).replaceAll("").strip();
        String reviewId = UUID.randomUUID().toString().replace("-", "");

        try {
            Map<String, Object> parsed = GSON.fromJson(cleaned, Map.class);
            double score = ((Number) parsed.getOrDefault("overallScore", 0.5)).doubleValue();

            List<ReviewIssue> issues = new ArrayList<>();
            List<Map<String, Object>> rawIssues = (List<Map<String, Object>>) parsed.getOrDefault("issues", List.of());
            for (var ri : rawIssues) {
                if (issues.size() >= cfg.maxIssues()) break;
                issues.add(new ReviewIssue(
                    (String) ri.getOrDefault("category", "correctness"),
                    (String) ri.getOrDefault("severity", "info"),
                    ri.get("line") instanceof Number n ? n.intValue() : null,
                    (String) ri.getOrDefault("codeSection", "client"),
                    (String) ri.getOrDefault("message", ""),
                    (String) ri.get("suggestion")
                ));
            }

            boolean hasCritical = issues.stream().anyMatch(i -> "critical".equals(i.severity()));
            boolean passed = score >= cfg.passThreshold() && !(hasCritical && cfg.blockOnCritical());

            List<String> suggestions = (List<String>) parsed.getOrDefault("suggestions", List.of());
            String summary = (String) parsed.getOrDefault("summary", "");

            return new ReviewOutput(reviewId, passed, score, issues, suggestions,
                summary, null, null, null, Instant.now());
        } catch (JsonSyntaxException ex) {
            log.warning("Failed to parse review JSON: " + ex.getMessage());
            return new ReviewOutput(reviewId, false, 0.5,
                List.of(new ReviewIssue("correctness", "warning", null, "client",
                    "AI response could not be fully parsed", null)),
                List.of(), "Review partially completed", null, null, null, Instant.now());
        }
    }
}
