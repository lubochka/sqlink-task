<?php
// =============================================================================
// Skill 12 — AI Review Service (PHP 8.3+)
// AI-powered code quality, security & accessibility review
// Genie DNA: Dynamic documents (array), buildSearchFilter, DataProcessResult
// =============================================================================

declare(strict_types=1);

namespace XIIGen\Services\AiReview;

// ---------------------------------------------------------------------------
// Interfaces
// ---------------------------------------------------------------------------
interface AiProviderInterface {
    public function complete(string $model, string $system, string $prompt,
                             float $temperature, int $maxTokens): string;
}

interface DatabaseProviderInterface {
    /** @return array<int, array<string, mixed>> */
    public function query(string $index, array $filters): array;
    /** @return array<string, mixed> */
    public function upsert(string $index, string $docId, array $doc): array;
}

interface NodeDebuggerInterface {
    /** @param array<string, mixed> $data */
    public function snapshot(string $traceId, string $nodeId, string $phase, array $data): void;
}

interface ObjectProcessorInterface {
    /** @param array<string, mixed> $doc @return array<string, mixed> */
    public function parseObjectAlternative(array $doc): array;
    /** @param array<string, mixed> $params @return array<string, mixed> */
    public function buildSearchFilter(array $params): array;
}

// ---------------------------------------------------------------------------
// Models
// ---------------------------------------------------------------------------
readonly class ReviewConfig {
    /** @param list<string> $categories */
    public function __construct(
        public string $reviewModel = 'claude-opus',
        public float $passThreshold = 0.7,
        public bool $blockOnCritical = true,
        public int $maxIssues = 50,
        public array $categories = ['correctness','security','accessibility','performance','patterns','completeness'],
        public bool $autoFixSimple = false,
        public bool $includeHistoricalPatterns = true,
        public int $timeoutSeconds = 90,
    ) {}
}

readonly class ReviewInput {
    /** @param list<array<string,mixed>>|null $originalComponents */
    public function __construct(
        public ?string $clientCode = null,
        public ?string $serverCode = null,
        public ?string $databaseCode = null,
        public string $targetClient = 'react-native',
        public string $targetServer = 'dotnet',
        public string $targetDatabase = 'elasticsearch',
        public ?array $originalComponents = null,
    ) {}
}

readonly class ReviewIssue {
    public function __construct(
        public string $category,
        public string $severity,
        public ?int $line,
        public string $codeSection,
        public string $message,
        public ?string $suggestion = null,
    ) {}
}

readonly class ReviewOutput {
    /** @param list<ReviewIssue> $issues @param list<string> $suggestions */
    public function __construct(
        public string $reviewId,
        public bool $passed,
        public float $overallScore,
        public array $issues = [],
        public array $suggestions = [],
        public string $summary = '',
        public ?string $fixedClientCode = null,
        public ?string $fixedServerCode = null,
        public ?string $fixedDatabaseCode = null,
        public string $reviewedAt = '',
    ) {}
}

/** @template T */
readonly class DataProcessResult {
    /** @param T|null $data @param array<string,mixed> $metadata */
    public function __construct(
        public bool $success,
        public mixed $data = null,
        public ?string $error = null,
        public array $metadata = [],
    ) {}

    /** @param T $data @return self<T> */
    public static function ok(mixed $data): self { return new self(true, $data); }
    public static function fail(string $err): self { return new self(false, error: $err); }
}

// ---------------------------------------------------------------------------
// Service
// ---------------------------------------------------------------------------
class AiReviewService {
    private readonly ReviewConfig $cfg;

    public function __construct(
        private readonly AiProviderInterface $ai,
        private readonly DatabaseProviderInterface $db,
        private readonly NodeDebuggerInterface $debugger,
        private readonly ObjectProcessorInterface $obj,
        ?ReviewConfig $config = null,
    ) {
        $this->cfg = $config ?? new ReviewConfig();
    }

    /** @return DataProcessResult<ReviewOutput> */
    public function review(string $traceId, string $nodeId, ReviewInput $input): DataProcessResult
    {
        try {
            // 1. Collect code sections
            $sections = $this->collectCode($input);
            if (empty($sections)) {
                return DataProcessResult::ok(new ReviewOutput(
                    reviewId: bin2hex(random_bytes(16)),
                    passed: true, overallScore: 1.0,
                    summary: 'No code to review',
                    reviewedAt: date('c'),
                ));
            }

            $this->debugger->snapshot($traceId, $nodeId, 'review-input',
                ['sections' => array_keys($sections)]);

            // 2. Historical patterns
            $history = $this->cfg->includeHistoricalPatterns
                ? $this->loadHistoricalPatterns($input)
                : '';

            // 3. Build prompt
            $prompt = $this->buildPrompt($sections, $input, $history);

            // 4. Call AI
            $raw = $this->ai->complete(
                $this->cfg->reviewModel,
                $this->buildSystemPrompt(),
                $prompt, 0.1, 4096,
            );

            $this->debugger->snapshot($traceId, $nodeId, 'review-raw',
                ['rawLength' => strlen($raw)]);

            // 5. Parse response
            $output = $this->parseResponse($raw);

            // 6. Store review
            $doc = $this->obj->parseObjectAlternative([
                'reviewId' => $output->reviewId,
                'traceId' => $traceId,
                'nodeId' => $nodeId,
                'passed' => $output->passed,
                'score' => $output->overallScore,
                'issueCount' => count($output->issues),
                'summary' => $output->summary,
                'reviewedAt' => $output->reviewedAt,
            ]);
            $this->db->upsert('xiigen-reviews', $output->reviewId, $doc);

            $criticalCount = count(array_filter($output->issues,
                fn(ReviewIssue $i) => $i->severity === 'critical'));

            $this->debugger->snapshot($traceId, $nodeId, 'review-output', [
                'passed' => $output->passed,
                'score' => $output->overallScore,
                'issues' => count($output->issues),
                'critical' => $criticalCount,
            ]);

            return DataProcessResult::ok($output);
        } catch (\Throwable $ex) {
            error_log("AiReviewService::review failed: {$ex->getMessage()}");
            return DataProcessResult::fail($ex->getMessage());
        }
    }

    // -- Private helpers --------------------------------------------------

    /** @return array<string, string> */
    private function collectCode(ReviewInput $input): array
    {
        $sections = [];
        if ($input->clientCode && trim($input->clientCode) !== '')
            $sections['client'] = $input->clientCode;
        if ($input->serverCode && trim($input->serverCode) !== '')
            $sections['server'] = $input->serverCode;
        if ($input->databaseCode && trim($input->databaseCode) !== '')
            $sections['database'] = $input->databaseCode;
        return $sections;
    }

    private function buildSystemPrompt(): string
    {
        $cats = implode(', ', $this->cfg->categories);
        return "You are a senior code reviewer. Review code across: {$cats}.\n" .
            "Respond ONLY with JSON:\n" .
            '{"overallScore":0.0-1.0,"issues":[{"category":"...","severity":"critical|error|warning|info",' .
            '"line":null,"codeSection":"client|server|database","message":"...","suggestion":"..."}],' .
            '"suggestions":["..."],"summary":"..."}' . "\n" .
            "Severity: critical=security/crash, error=bug, warning=style, info=improvement.";
    }

    /** @param array<string,string> $sections */
    private function buildPrompt(array $sections, ReviewInput $input, string $history): string
    {
        $parts = ["Review code targeting {$input->targetClient}/{$input->targetServer}/{$input->targetDatabase}:\n"];
        foreach ($sections as $name => $code) {
            $upper = strtoupper($name);
            $parts[] = "\n=== {$upper} CODE ===\n{$code}\n";
        }
        if ($history !== '') {
            $parts[] = "\nHistorical patterns:\n{$history}";
        }
        return implode('', $parts);
    }

    private function loadHistoricalPatterns(ReviewInput $input): string
    {
        try {
            $filter = $this->obj->buildSearchFilter([
                'severity' => 'critical,error',
                'targetServer' => $input->targetServer,
                'targetClient' => $input->targetClient,
            ]);
            $docs = $this->db->query('xiigen-reviews', $filter);
            if (empty($docs)) return '';

            return implode("\n", array_map(
                fn(array $d) => '- ' . ($d['summary'] ?? ''),
                array_slice(array_filter($docs, fn($d) => !empty($d['summary'])), 0, 5)
            ));
        } catch (\Throwable) {
            return '';
        }
    }

    private function parseResponse(string $raw): ReviewOutput
    {
        $cleaned = trim(preg_replace('/```(?:json)?\s*|```/', '', $raw));
        $reviewId = bin2hex(random_bytes(16));

        $parsed = json_decode($cleaned, true);
        if (!is_array($parsed)) {
            return new ReviewOutput(
                reviewId: $reviewId, passed: false, overallScore: 0.5,
                issues: [new ReviewIssue('correctness', 'warning', null, 'client',
                    'AI response could not be fully parsed')],
                summary: 'Review partially completed',
                reviewedAt: date('c'),
            );
        }

        $score = (float)($parsed['overallScore'] ?? 0.5);
        $rawIssues = array_slice($parsed['issues'] ?? [], 0, $this->cfg->maxIssues);

        $issues = array_map(fn(array $i) => new ReviewIssue(
            category: $i['category'] ?? 'correctness',
            severity: $i['severity'] ?? 'info',
            line: isset($i['line']) ? (int)$i['line'] : null,
            codeSection: $i['codeSection'] ?? 'client',
            message: $i['message'] ?? '',
            suggestion: $i['suggestion'] ?? null,
        ), $rawIssues);

        $hasCritical = count(array_filter($issues, fn(ReviewIssue $i) => $i->severity === 'critical')) > 0;
        $passed = $score >= $this->cfg->passThreshold
            && !($hasCritical && $this->cfg->blockOnCritical);

        return new ReviewOutput(
            reviewId: $reviewId,
            passed: $passed,
            overallScore: $score,
            issues: $issues,
            suggestions: $parsed['suggestions'] ?? [],
            summary: $parsed['summary'] ?? '',
            reviewedAt: date('c'),
        );
    }
}
