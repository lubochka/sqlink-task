# =============================================================================
# Skill 12 — AI Review Service (Python)
# AI-powered code quality, security & accessibility review
# Genie DNA: Dynamic documents, build_search_filter, DataProcessResult
# =============================================================================

from __future__ import annotations
import json, re, logging, asyncio
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Protocol, Optional
from uuid import uuid4

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Protocols (interfaces)
# ---------------------------------------------------------------------------
class AiProvider(Protocol):
    async def complete(self, model: str, system: str, prompt: str,
                       temperature: float, max_tokens: int) -> str: ...

class DatabaseProvider(Protocol):
    async def query(self, index: str, filters: dict[str, Any]) -> list[dict[str, Any]]: ...
    async def upsert(self, index: str, doc_id: str, doc: dict[str, Any]) -> dict[str, Any]: ...

class NodeDebugger(Protocol):
    async def snapshot(self, trace_id: str, node_id: str, phase: str,
                       data: dict[str, Any]) -> None: ...

class ObjectProcessor(Protocol):
    def parse_object_alternative(self, doc: dict[str, Any]) -> dict[str, Any]: ...
    def build_search_filter(self, **kwargs: Any) -> dict[str, Any]: ...

# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------
@dataclass
class ReviewConfig:
    review_model: str = "claude-opus"
    pass_threshold: float = 0.7
    block_on_critical: bool = True
    max_issues: int = 50
    categories: list[str] = field(default_factory=lambda: [
        "correctness", "security", "accessibility", "performance", "patterns", "completeness"
    ])
    auto_fix_simple: bool = False
    include_historical_patterns: bool = True
    timeout_seconds: int = 90

@dataclass
class ReviewInput:
    client_code: Optional[str] = None
    server_code: Optional[str] = None
    database_code: Optional[str] = None
    target_client: str = "react-native"
    target_server: str = "dotnet"
    target_database: str = "elasticsearch"
    original_components: Optional[list[dict[str, Any]]] = None

@dataclass
class ReviewIssue:
    category: str
    severity: str  # critical | error | warning | info
    line: Optional[int]
    code_section: str  # client | server | database
    message: str
    suggestion: Optional[str] = None

@dataclass
class ReviewOutput:
    review_id: str = field(default_factory=lambda: uuid4().hex)
    passed: bool = False
    overall_score: float = 0.0
    issues: list[ReviewIssue] = field(default_factory=list)
    suggestions: list[str] = field(default_factory=list)
    summary: str = ""
    fixed_client_code: Optional[str] = None
    fixed_server_code: Optional[str] = None
    fixed_database_code: Optional[str] = None
    reviewed_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

@dataclass
class DataProcessResult:
    success: bool
    data: Any = None
    error: Optional[str] = None
    metadata: dict[str, Any] = field(default_factory=dict)

# ---------------------------------------------------------------------------
# Review Category Weights
# ---------------------------------------------------------------------------
CATEGORY_WEIGHTS = {
    "correctness": 0.30,
    "security": 0.25,
    "accessibility": 0.15,
    "performance": 0.10,
    "patterns": 0.10,
    "completeness": 0.10,
}

# ---------------------------------------------------------------------------
# Service
# ---------------------------------------------------------------------------
class AiReviewService:
    """Runs AI-powered code review with 6 quality dimensions."""

    def __init__(
        self,
        ai: AiProvider,
        db: DatabaseProvider,
        debugger: NodeDebugger,
        obj: ObjectProcessor,
        config: Optional[ReviewConfig] = None,
    ):
        self._ai = ai
        self._db = db
        self._dbg = debugger
        self._obj = obj
        self._cfg = config or ReviewConfig()

    # -- public entry point ------------------------------------------------
    async def review(
        self, trace_id: str, node_id: str, review_input: ReviewInput
    ) -> DataProcessResult:
        try:
            # 1. check if there is code to review
            code_sections = self._collect_code(review_input)
            if not code_sections:
                empty_output = ReviewOutput(passed=True, overall_score=1.0,
                                            summary="No code to review")
                return DataProcessResult(success=True, data=empty_output)

            await self._dbg.snapshot(trace_id, node_id, "review-input",
                                     {"sections": list(code_sections.keys())})

            # 2. load historical patterns
            history_prompt = ""
            if self._cfg.include_historical_patterns:
                history_prompt = await self._load_historical_patterns(review_input)

            # 3. build review prompt
            prompt = self._build_prompt(code_sections, review_input, history_prompt)

            # 4. call AI
            raw = await self._ai.complete(
                model=self._cfg.review_model,
                system=self._system_prompt(),
                prompt=prompt,
                temperature=0.1,
                max_tokens=4096,
            )

            await self._dbg.snapshot(trace_id, node_id, "review-raw", {"raw_length": len(raw)})

            # 5. parse response
            output = self._parse_response(raw, code_sections)

            # 6. store review
            doc = self._obj.parse_object_alternative({
                "reviewId": output.review_id,
                "traceId": trace_id,
                "nodeId": node_id,
                "passed": output.passed,
                "score": output.overall_score,
                "issueCount": len(output.issues),
                "summary": output.summary,
                "reviewedAt": output.reviewed_at.isoformat(),
            })
            await self._db.upsert("xiigen-reviews", output.review_id, doc)

            await self._dbg.snapshot(trace_id, node_id, "review-output", {
                "passed": output.passed, "score": output.overall_score,
                "issues": len(output.issues),
                "critical": sum(1 for i in output.issues if i.severity == "critical"),
            })

            return DataProcessResult(success=True, data=output)

        except Exception as ex:
            logger.error("AiReviewService.review failed: %s", ex, exc_info=True)
            return DataProcessResult(success=False, error=str(ex))

    # -- private helpers ---------------------------------------------------
    def _collect_code(self, ri: ReviewInput) -> dict[str, str]:
        sections: dict[str, str] = {}
        if ri.client_code and ri.client_code.strip():
            sections["client"] = ri.client_code
        if ri.server_code and ri.server_code.strip():
            sections["server"] = ri.server_code
        if ri.database_code and ri.database_code.strip():
            sections["database"] = ri.database_code
        return sections

    def _system_prompt(self) -> str:
        cats = ", ".join(self._cfg.categories)
        return (
            "You are a senior code reviewer. Review code across these categories: "
            f"{cats}.\n"
            "Respond ONLY with a JSON object:\n"
            '{"overallScore": 0.0-1.0, "issues": [{"category":"...","severity":"critical|error|warning|info",'
            '"line":null,"codeSection":"client|server|database","message":"...","suggestion":"..."}],'
            '"suggestions":["..."],"summary":"..."}\n'
            "Severity guide: critical=security/crash, error=bug/logic, "
            "warning=style/minor, info=improvement."
        )

    def _build_prompt(self, sections: dict[str, str],
                      ri: ReviewInput, history: str) -> str:
        parts = [f"Review the following code targeting {ri.target_client}/{ri.target_server}/{ri.target_database}:\n"]
        for name, code in sections.items():
            parts.append(f"=== {name.upper()} CODE ===\n{code}\n")
        if history:
            parts.append(f"\nHistorical patterns to watch for:\n{history}")
        return "\n".join(parts)

    async def _load_historical_patterns(self, ri: ReviewInput) -> str:
        try:
            flt = self._obj.build_search_filter(
                severity="critical,error",
                targetServer=ri.target_server,
                targetClient=ri.target_client,
            )
            docs = await self._db.query("xiigen-reviews", flt)
            if not docs:
                return ""
            summaries = [d.get("summary", "") for d in docs[:5] if d.get("summary")]
            return "\n".join(f"- {s}" for s in summaries)
        except Exception as ex:
            logger.warning("Failed to load historical patterns: %s", ex)
            return ""

    def _parse_response(self, raw: str, sections: dict[str, str]) -> ReviewOutput:
        # strip markdown fences
        cleaned = re.sub(r"```(?:json)?\s*", "", raw).strip().rstrip("`")

        try:
            parsed = json.loads(cleaned)
        except json.JSONDecodeError:
            logger.warning("Failed to parse review JSON, using fallback")
            return ReviewOutput(
                passed=False, overall_score=0.5,
                summary="Review partially completed — could not parse AI response",
                issues=[ReviewIssue("correctness", "warning", None, "client",
                                    "AI response could not be fully parsed", None)],
            )

        issues = [
            ReviewIssue(
                category=i.get("category", "correctness"),
                severity=i.get("severity", "info"),
                line=i.get("line"),
                code_section=i.get("codeSection", "client"),
                message=i.get("message", ""),
                suggestion=i.get("suggestion"),
            )
            for i in parsed.get("issues", [])[:self._cfg.max_issues]
        ]

        score = float(parsed.get("overallScore", 0.5))
        has_critical = any(i.severity == "critical" for i in issues)
        passed = score >= self._cfg.pass_threshold and not (has_critical and self._cfg.block_on_critical)

        return ReviewOutput(
            passed=passed,
            overall_score=score,
            issues=issues,
            suggestions=parsed.get("suggestions", []),
            summary=parsed.get("summary", ""),
        )


# ---------------------------------------------------------------------------
# DI Registration helper
# ---------------------------------------------------------------------------
def register_ai_review(container: dict[str, Any], config: Optional[ReviewConfig] = None) -> None:
    """Register AiReviewService in a simple DI container dict."""
    container["ai_review_service"] = AiReviewService(
        ai=container["ai_provider"],
        db=container["database_provider"],
        debugger=container["node_debugger"],
        obj=container["object_processor"],
        config=config,
    )
