/**
 * Skill 12: AI Review Service — Node.js/TypeScript
 * AI-powered code quality, security & accessibility review.
 * Genie DNA: Dynamic documents (Record<string,any>), BuildSearchFilter, DataProcessResult.
 */

// --- Interfaces ---
interface IAiDispatcher {
  dispatch(modelId: string, prompt: string, options?: Record<string, any>): Promise<Record<string, any>>;
}
interface IFeedbackService {
  getFeedbackHistory(filter: Record<string, any>, limit?: number): Promise<Record<string, any>[]>;
}
interface INodeDebugger {
  storeSnapshot(traceId: string, nodeId: string, snapshot: Record<string, any>): Promise<void>;
}
interface IObjectProcessor {
  parseObjectAlternative(input: any): Record<string, any>;
  buildSearchFilter(filter: any): Record<string, any>;
}

// --- Types ---
interface ReviewConfig {
  reviewModel: string;
  passThreshold: number;
  blockOnCritical: boolean;
  maxIssues: number;
  categories: string[];
  autoFixSimple: boolean;
  includeHistoricalPatterns: boolean;
  timeoutSeconds: number;
}

interface ReviewInput {
  clientCode?: string;
  serverCode?: string;
  databaseCode?: string;
  targetClient: string;
  targetServer: string;
  targetDatabase: string;
  originalComponents?: Record<string, any>[];
}

interface ReviewIssue {
  category: string;
  severity: 'critical' | 'error' | 'warning' | 'info';
  line?: number;
  codeSection: string;
  message: string;
  suggestion?: string;
}

interface ReviewOutput {
  reviewId: string;
  passed: boolean;
  overallScore: number;
  issues: ReviewIssue[];
  suggestions: string[];
  summary: string;
  fixedClientCode?: string;
  fixedServerCode?: string;
  fixedDatabaseCode?: string;
  reviewedAt: string;
}

interface DataProcessResult<T> {
  success: boolean;
  data?: T;
  error?: string;
}

interface FlowStepContext {
  traceId: string;
  nodeId: string;
  input: Record<string, any>;
  nodeConfig: Record<string, any>;
}

const DEFAULT_CONFIG: ReviewConfig = {
  reviewModel: 'claude-opus',
  passThreshold: 0.7,
  blockOnCritical: true,
  maxIssues: 50,
  categories: ['correctness', 'security', 'accessibility', 'performance', 'patterns', 'completeness'],
  autoFixSimple: false,
  includeHistoricalPatterns: true,
  timeoutSeconds: 90,
};

// --- Service ---
export class AiReviewService {
  constructor(
    private readonly dispatcher: IAiDispatcher,
    private readonly feedback: IFeedbackService,
    private readonly debugger: INodeDebugger,
    private readonly objectProcessor: IObjectProcessor,
  ) {}

  /** Flow entry point — extracts config/input from context, runs review. */
  async execute(context: FlowStepContext): Promise<DataProcessResult<ReviewOutput>> {
    const config = this.extractConfig(context.nodeConfig);
    const input = this.extractInput(context.input);

    // Auto-pass if no code to review
    if (!input.clientCode && !input.serverCode && !input.databaseCode) {
      const autoPass: ReviewOutput = {
        reviewId: crypto.randomUUID(),
        passed: true,
        overallScore: 1.0,
        issues: [],
        suggestions: [],
        summary: 'No code to review — auto-pass.',
        reviewedAt: new Date().toISOString(),
      };
      return { success: true, data: autoPass };
    }

    const result = await this.reviewCode(input, config);

    if (result.success && result.data) {
      await this.storeDebugSnapshot(context, result.data).catch(() => {});
    }
    return result;
  }

  /** Core review logic: prompt → AI → parse → pass/fail. */
  async reviewCode(input: ReviewInput, config: ReviewConfig): Promise<DataProcessResult<ReviewOutput>> {
    // Step 1: Load historical patterns
    const historicalPatterns = config.includeHistoricalPatterns
      ? await this.loadHistoricalPatterns(input)
      : [];

    // Step 2: Build review prompt
    const prompt = this.buildReviewPrompt(input, config, historicalPatterns);

    // Step 3: Dispatch to review model
    let rawResponse: Record<string, any>;
    try {
      rawResponse = await this.dispatcher.dispatch(config.reviewModel, prompt, {
        maxTokens: 4096,
        temperature: 0.1, // Low temperature for consistent reviews
        timeoutSeconds: config.timeoutSeconds,
      });
    } catch (err: any) {
      return { success: false, error: `Review model failed: ${err.message}` };
    }

    // Step 4: Parse response
    const output = this.parseReviewResponse(rawResponse, config);
    return { success: true, data: output };
  }

  // -----------------------------------------------------------------------
  // Prompt Building
  // -----------------------------------------------------------------------
  private buildReviewPrompt(
    input: ReviewInput,
    config: ReviewConfig,
    historicalPatterns: Record<string, any>[],
  ): string {
    const lines: string[] = [];

    lines.push(`You are a senior code reviewer. Review the following generated code strictly for quality issues.

## Review Categories (check ALL that apply):
1. Correctness — syntax errors, logic bugs, type mismatches, missing returns
2. Security — XSS, SQL injection, auth bypasses, hardcoded secrets, CSRF
3. Accessibility — missing ARIA labels, keyboard navigation, semantic HTML, contrast
4. Performance — N+1 queries, memory leaks, unnecessary re-renders, large bundle
5. Pattern compliance — dependency injection, error handling, SOLID principles
6. Completeness — all design elements implemented, error states handled, loading states

## REQUIRED RESPONSE FORMAT (strict JSON, no markdown):
{
  "overallScore": 0.85,
  "passed": true,
  "issues": [
    {
      "category": "security",
      "severity": "critical",
      "line": 42,
      "code": "clientCode",
      "message": "Unescaped user input in innerHTML",
      "suggestion": "Use textContent or sanitize input"
    }
  ],
  "suggestions": ["Consider adding loading states", "Add error boundary"],
  "summary": "Code is generally well-structured with one critical security issue..."
}

Severity levels: critical (must fix), error (should fix), warning (nice to fix), info (suggestion)`);

    if (input.clientCode) {
      lines.push(`\n## Client Code (${input.targetClient})\n\`\`\`\n${input.clientCode}\n\`\`\``);
    }
    if (input.serverCode) {
      lines.push(`\n## Server Code (${input.targetServer})\n\`\`\`\n${input.serverCode}\n\`\`\``);
    }
    if (input.databaseCode) {
      lines.push(`\n## Database Code (${input.targetDatabase})\n\`\`\`\n${input.databaseCode}\n\`\`\``);
    }

    if (historicalPatterns.length > 0) {
      lines.push('\n## Common Issues from Past Reviews (pay extra attention):');
      for (const p of historicalPatterns.slice(0, 10)) {
        const cat = (p['category'] as string) ?? 'unknown';
        const msg = (p['message'] as string) ?? '';
        lines.push(`- [${cat}] ${msg}`);
      }
    }

    return lines.join('\n');
  }

  // -----------------------------------------------------------------------
  // Response Parsing
  // -----------------------------------------------------------------------
  private parseReviewResponse(rawResponse: Record<string, any>, config: ReviewConfig): ReviewOutput {
    const responseText = (rawResponse['response'] ?? rawResponse['text'] ?? '') as string;

    if (!responseText.trim()) {
      return {
        reviewId: crypto.randomUUID(),
        passed: false,
        overallScore: 0,
        issues: [{ category: 'review', severity: 'error', codeSection: 'all', message: 'Empty review response', suggestion: 'Retry review' }],
        suggestions: [],
        summary: 'Review model returned empty response',
        reviewedAt: new Date().toISOString(),
      };
    }

    try {
      // Strip markdown code fences if present
      let json = responseText.trim();
      if (json.startsWith('```')) json = json.slice(json.indexOf('\n') + 1);
      if (json.endsWith('```')) json = json.slice(0, json.lastIndexOf('\n'));
      json = json.trim();

      const parsed = JSON.parse(json);

      const score: number = parsed.overallScore ?? 0.5;

      const issues: ReviewIssue[] = (parsed.issues ?? [])
        .slice(0, config.maxIssues)
        .map((i: any) => ({
          category: i.category ?? 'unknown',
          severity: i.severity ?? 'warning',
          line: i.line ?? undefined,
          codeSection: i.code ?? 'unknown',
          message: i.message ?? '',
          suggestion: i.suggestion ?? undefined,
        }));

      const suggestions: string[] = (parsed.suggestions ?? []).map((s: any) => String(s));
      const summary: string = parsed.summary ?? 'Review complete';

      const hasCritical = issues.some(i => i.severity === 'critical');
      const passed = score >= config.passThreshold && !(config.blockOnCritical && hasCritical);

      return {
        reviewId: crypto.randomUUID(),
        passed,
        overallScore: score,
        issues,
        suggestions,
        summary,
        reviewedAt: new Date().toISOString(),
      };
    } catch {
      return {
        reviewId: crypto.randomUUID(),
        passed: false,
        overallScore: 0.5,
        issues: [{ category: 'review', severity: 'warning', codeSection: 'all', message: 'Review response was not valid JSON', suggestion: 'Manual review recommended' }],
        suggestions: [],
        summary: `Partial review (JSON parse error): ${responseText.slice(0, 200)}...`,
        reviewedAt: new Date().toISOString(),
      };
    }
  }

  // -----------------------------------------------------------------------
  // Historical Patterns (Genie DNA-2: BuildSearchFilter)
  // -----------------------------------------------------------------------
  private async loadHistoricalPatterns(input: ReviewInput): Promise<Record<string, any>[]> {
    try {
      const filter = this.objectProcessor.buildSearchFilter({
        type: 'review-issue',
        severity: ['critical', 'error'],
        targetClient: input.targetClient || undefined,
        targetServer: input.targetServer || undefined,
      });
      return await this.feedback.getFeedbackHistory(filter, 10);
    } catch {
      return [];
    }
  }

  // -----------------------------------------------------------------------
  // Debug Snapshot (Genie DNA-1)
  // -----------------------------------------------------------------------
  private async storeDebugSnapshot(context: FlowStepContext, output: ReviewOutput): Promise<void> {
    const snapshot = this.objectProcessor.parseObjectAlternative({
      type: 'ai-review',
      traceId: context.traceId,
      nodeId: context.nodeId,
      reviewId: output.reviewId,
      passed: output.passed,
      overallScore: output.overallScore,
      issueCount: output.issues.length,
      criticalCount: output.issues.filter(i => i.severity === 'critical').length,
      errorCount: output.issues.filter(i => i.severity === 'error').length,
      categories: [...new Set(output.issues.map(i => i.category))],
      summary: output.summary,
      timestamp: new Date().toISOString(),
    });
    await this.debugger.storeSnapshot(context.traceId, context.nodeId, snapshot);
  }

  // -----------------------------------------------------------------------
  // Config / Input extraction (dynamic documents)
  // -----------------------------------------------------------------------
  private extractConfig(nc: Record<string, any>): ReviewConfig {
    return {
      reviewModel: (nc['reviewModel'] as string) ?? DEFAULT_CONFIG.reviewModel,
      passThreshold: Number(nc['passThreshold'] ?? DEFAULT_CONFIG.passThreshold),
      blockOnCritical: nc['blockOnCritical'] !== false,
      maxIssues: Number(nc['maxIssues'] ?? DEFAULT_CONFIG.maxIssues),
      categories: (nc['categories'] as string[]) ?? DEFAULT_CONFIG.categories,
      autoFixSimple: nc['autoFixSimple'] === true,
      includeHistoricalPatterns: nc['includeHistoricalPatterns'] !== false,
      timeoutSeconds: Number(nc['timeoutSeconds'] ?? DEFAULT_CONFIG.timeoutSeconds),
    };
  }

  private extractInput(input: Record<string, any>): ReviewInput {
    return {
      clientCode: input['clientCode'] as string | undefined,
      serverCode: input['serverCode'] as string | undefined,
      databaseCode: input['databaseCode'] as string | undefined,
      targetClient: (input['targetClient'] as string) ?? 'react',
      targetServer: (input['targetServer'] as string) ?? 'dotnet',
      targetDatabase: (input['targetDatabase'] as string) ?? 'elasticsearch',
      originalComponents: input['originalComponents'] as Record<string, any>[] | undefined,
    };
  }
}

// --- DI Registration ---
export function registerAiReviewService(container: any): void {
  container.register('IAiReviewService', AiReviewService);
}
