// =============================================================================
// Skill 12 — AI Review Service (Rust)
// AI-powered code quality, security & accessibility review
// Genie DNA: Dynamic documents (serde_json::Value), build_search_filter, DataProcessResult
// =============================================================================

use async_trait::async_trait;
use chrono::{DateTime, Utc};
use lazy_static::lazy_static;
use regex::Regex;
use serde::{Deserialize, Serialize};
use serde_json::{json, Map, Value};
use std::collections::HashMap;
use uuid::Uuid;

// ---------------------------------------------------------------------------
// Interfaces (traits)
// ---------------------------------------------------------------------------
#[async_trait]
pub trait AiProvider: Send + Sync {
    async fn complete(&self, model: &str, system: &str, prompt: &str,
                      temperature: f64, max_tokens: u32) -> Result<String, Box<dyn std::error::Error>>;
}

#[async_trait]
pub trait DatabaseProvider: Send + Sync {
    async fn query(&self, index: &str, filters: Value) -> Result<Vec<Value>, Box<dyn std::error::Error>>;
    async fn upsert(&self, index: &str, doc_id: &str, doc: Value) -> Result<Value, Box<dyn std::error::Error>>;
}

#[async_trait]
pub trait NodeDebugger: Send + Sync {
    async fn snapshot(&self, trace_id: &str, node_id: &str, phase: &str,
                      data: Value) -> Result<(), Box<dyn std::error::Error>>;
}

pub trait ObjectProcessor: Send + Sync {
    fn parse_object_alternative(&self, doc: Value) -> Value;
    fn build_search_filter(&self, params: &HashMap<String, String>) -> Value;
}

// ---------------------------------------------------------------------------
// Models
// ---------------------------------------------------------------------------
#[derive(Clone, Debug)]
pub struct ReviewConfig {
    pub review_model: String,
    pub pass_threshold: f64,
    pub block_on_critical: bool,
    pub max_issues: usize,
    pub categories: Vec<String>,
    pub include_historical_patterns: bool,
    pub timeout_seconds: u64,
}

impl Default for ReviewConfig {
    fn default() -> Self {
        Self {
            review_model: "claude-opus".into(),
            pass_threshold: 0.7,
            block_on_critical: true,
            max_issues: 50,
            categories: vec![
                "correctness", "security", "accessibility",
                "performance", "patterns", "completeness",
            ].into_iter().map(String::from).collect(),
            include_historical_patterns: true,
            timeout_seconds: 90,
        }
    }
}

#[derive(Clone, Debug)]
pub struct ReviewInput {
    pub client_code: Option<String>,
    pub server_code: Option<String>,
    pub database_code: Option<String>,
    pub target_client: String,
    pub target_server: String,
    pub target_database: String,
    pub original_components: Option<Vec<Value>>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ReviewIssue {
    pub category: String,
    pub severity: String,
    pub line: Option<u32>,
    pub code_section: String,
    pub message: String,
    pub suggestion: Option<String>,
}

#[derive(Clone, Debug, Serialize)]
pub struct ReviewOutput {
    pub review_id: String,
    pub passed: bool,
    pub overall_score: f64,
    pub issues: Vec<ReviewIssue>,
    pub suggestions: Vec<String>,
    pub summary: String,
    pub fixed_client_code: Option<String>,
    pub fixed_server_code: Option<String>,
    pub fixed_database_code: Option<String>,
    pub reviewed_at: DateTime<Utc>,
}

#[derive(Clone, Debug)]
pub struct DataProcessResult<T> {
    pub success: bool,
    pub data: Option<T>,
    pub error: Option<String>,
}

impl<T> DataProcessResult<T> {
    pub fn ok(data: T) -> Self { Self { success: true, data: Some(data), error: None } }
    pub fn fail(err: String) -> Self { Self { success: false, data: None, error: Some(err) } }
}

lazy_static! {
    static ref MD_FENCE: Regex = Regex::new(r"```(?:json)?\s*|```").unwrap();
}

// ---------------------------------------------------------------------------
// Service
// ---------------------------------------------------------------------------
pub struct AiReviewService {
    ai: Box<dyn AiProvider>,
    db: Box<dyn DatabaseProvider>,
    debugger: Box<dyn NodeDebugger>,
    obj: Box<dyn ObjectProcessor>,
    cfg: ReviewConfig,
}

impl AiReviewService {
    pub fn new(
        ai: Box<dyn AiProvider>,
        db: Box<dyn DatabaseProvider>,
        debugger: Box<dyn NodeDebugger>,
        obj: Box<dyn ObjectProcessor>,
        cfg: Option<ReviewConfig>,
    ) -> Self {
        Self { ai, db, debugger, obj, cfg: cfg.unwrap_or_default() }
    }

    /// Run AI review on submitted code
    pub async fn review(
        &self, trace_id: &str, node_id: &str, input: &ReviewInput,
    ) -> DataProcessResult<ReviewOutput> {
        // 1. Collect code sections
        let sections = self.collect_code(input);
        if sections.is_empty() {
            return DataProcessResult::ok(ReviewOutput {
                review_id: Uuid::new_v4().to_string(),
                passed: true,
                overall_score: 1.0,
                issues: vec![],
                suggestions: vec![],
                summary: "No code to review".into(),
                fixed_client_code: None,
                fixed_server_code: None,
                fixed_database_code: None,
                reviewed_at: Utc::now(),
            });
        }

        if let Err(e) = self.debugger.snapshot(trace_id, node_id, "review-input",
            json!({"sections": sections.keys().collect::<Vec<_>>()})).await {
            log::warn!("Debug snapshot failed: {}", e);
        }

        // 2. Historical patterns
        let history = if self.cfg.include_historical_patterns {
            self.load_historical_patterns(input).await
        } else {
            String::new()
        };

        // 3. Build prompt
        let prompt = self.build_prompt(&sections, input, &history);

        // 4. Call AI
        let raw = match self.ai.complete(
            &self.cfg.review_model, &self.system_prompt(), &prompt, 0.1, 4096,
        ).await {
            Ok(r) => r,
            Err(e) => return DataProcessResult::fail(format!("AI call failed: {}", e)),
        };

        let _ = self.debugger.snapshot(trace_id, node_id, "review-raw",
            json!({"raw_length": raw.len()})).await;

        // 5. Parse response
        let output = self.parse_response(&raw);

        // 6. Store review
        let doc = self.obj.parse_object_alternative(json!({
            "reviewId": output.review_id,
            "traceId": trace_id,
            "nodeId": node_id,
            "passed": output.passed,
            "score": output.overall_score,
            "issueCount": output.issues.len(),
            "summary": output.summary,
            "reviewedAt": output.reviewed_at.to_rfc3339(),
        }));
        let _ = self.db.upsert("xiigen-reviews", &output.review_id, doc).await;

        let _ = self.debugger.snapshot(trace_id, node_id, "review-output", json!({
            "passed": output.passed,
            "score": output.overall_score,
            "issues": output.issues.len(),
            "critical": output.issues.iter().filter(|i| i.severity == "critical").count(),
        })).await;

        DataProcessResult::ok(output)
    }

    // -- Private helpers --------------------------------------------------
    fn collect_code(&self, input: &ReviewInput) -> HashMap<String, String> {
        let mut sections = HashMap::new();
        if let Some(ref c) = input.client_code { if !c.trim().is_empty() { sections.insert("client".into(), c.clone()); } }
        if let Some(ref s) = input.server_code { if !s.trim().is_empty() { sections.insert("server".into(), s.clone()); } }
        if let Some(ref d) = input.database_code { if !d.trim().is_empty() { sections.insert("database".into(), d.clone()); } }
        sections
    }

    fn system_prompt(&self) -> String {
        let cats = self.cfg.categories.join(", ");
        format!(
            "You are a senior code reviewer. Review code across: {}.\n\
             Respond ONLY with JSON:\n\
             {{\"overallScore\":0.0-1.0,\"issues\":[{{\"category\":\"...\",\"severity\":\"critical|error|warning|info\",\
             \"line\":null,\"codeSection\":\"client|server|database\",\"message\":\"...\",\"suggestion\":\"...\"}}],\
             \"suggestions\":[\"...\"],\"summary\":\"...\"}}\n\
             Severity: critical=security/crash, error=bug, warning=style, info=improvement.", cats
        )
    }

    fn build_prompt(&self, sections: &HashMap<String, String>,
                    input: &ReviewInput, history: &str) -> String {
        let mut parts = vec![format!(
            "Review code targeting {}/{}/{}:\n",
            input.target_client, input.target_server, input.target_database
        )];
        for (name, code) in sections {
            parts.push(format!("\n=== {} CODE ===\n{}\n", name.to_uppercase(), code));
        }
        if !history.is_empty() {
            parts.push(format!("\nHistorical patterns:\n{}", history));
        }
        parts.join("")
    }

    async fn load_historical_patterns(&self, input: &ReviewInput) -> String {
        let mut params = HashMap::new();
        params.insert("severity".into(), "critical,error".into());
        params.insert("targetServer".into(), input.target_server.clone());
        params.insert("targetClient".into(), input.target_client.clone());

        let filter = self.obj.build_search_filter(&params);
        match self.db.query("xiigen-reviews", filter).await {
            Ok(docs) => docs.iter().take(5)
                .filter_map(|d| d.get("summary").and_then(|s| s.as_str()))
                .map(|s| format!("- {}", s))
                .collect::<Vec<_>>()
                .join("\n"),
            Err(_) => String::new(),
        }
    }

    fn parse_response(&self, raw: &str) -> ReviewOutput {
        let cleaned = MD_FENCE.replace_all(raw, "").trim().to_string();
        let review_id = Uuid::new_v4().to_string();

        let parsed: Value = match serde_json::from_str(&cleaned) {
            Ok(v) => v,
            Err(_) => {
                return ReviewOutput {
                    review_id,
                    passed: false,
                    overall_score: 0.5,
                    issues: vec![ReviewIssue {
                        category: "correctness".into(),
                        severity: "warning".into(),
                        line: None,
                        code_section: "client".into(),
                        message: "AI response could not be fully parsed".into(),
                        suggestion: None,
                    }],
                    suggestions: vec![],
                    summary: "Review partially completed".into(),
                    fixed_client_code: None,
                    fixed_server_code: None,
                    fixed_database_code: None,
                    reviewed_at: Utc::now(),
                };
            }
        };

        let score = parsed["overallScore"].as_f64().unwrap_or(0.5);
        let issues: Vec<ReviewIssue> = parsed["issues"].as_array()
            .map(|arr| arr.iter().take(self.cfg.max_issues).map(|i| ReviewIssue {
                category: i["category"].as_str().unwrap_or("correctness").into(),
                severity: i["severity"].as_str().unwrap_or("info").into(),
                line: i["line"].as_u64().map(|n| n as u32),
                code_section: i["codeSection"].as_str().unwrap_or("client").into(),
                message: i["message"].as_str().unwrap_or("").into(),
                suggestion: i["suggestion"].as_str().map(String::from),
            }).collect())
            .unwrap_or_default();

        let has_critical = issues.iter().any(|i| i.severity == "critical");
        let passed = score >= self.cfg.pass_threshold
            && !(has_critical && self.cfg.block_on_critical);

        let suggestions: Vec<String> = parsed["suggestions"].as_array()
            .map(|a| a.iter().filter_map(|v| v.as_str().map(String::from)).collect())
            .unwrap_or_default();

        ReviewOutput {
            review_id,
            passed,
            overall_score: score,
            issues,
            suggestions,
            summary: parsed["summary"].as_str().unwrap_or("").into(),
            fixed_client_code: None,
            fixed_server_code: None,
            fixed_database_code: None,
            reviewed_at: Utc::now(),
        }
    }
}
