// =============================================================================
// Skill 12 — AI Review Service (.NET 9)
// AI-powered code quality, security & accessibility review
// Genie DNA: Dynamic documents, BuildSearchFilter, DataProcessResult
// =============================================================================

using System.Text.Json;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace XIIGen.Services.AiReview;

// ---------------------------------------------------------------------------
// Models
// ---------------------------------------------------------------------------
public sealed record ReviewConfig
{
    public string ReviewModel { get; init; } = "claude-opus";
    public double PassThreshold { get; init; } = 0.7;
    public bool BlockOnCritical { get; init; } = true;
    public int MaxIssues { get; init; } = 50;
    public List<string> Categories { get; init; } = ["correctness", "security", "accessibility", "performance", "patterns", "completeness"];
    public bool AutoFixSimple { get; init; } = false;
    public bool IncludeHistoricalPatterns { get; init; } = true;
    public int TimeoutSeconds { get; init; } = 90;
}

public sealed record ReviewInput(
    string? ClientCode, string? ServerCode, string? DatabaseCode,
    string TargetClient, string TargetServer, string TargetDatabase,
    IReadOnlyList<Dictionary<string, object>>? OriginalComponents);

public sealed record ReviewOutput
{
    public string ReviewId { get; init; } = Guid.NewGuid().ToString("N");
    public bool Passed { get; init; }
    public double OverallScore { get; init; }
    public List<ReviewIssue> Issues { get; init; } = [];
    public List<string> Suggestions { get; init; } = [];
    public string Summary { get; init; } = "";
    public string? FixedClientCode { get; init; }
    public string? FixedServerCode { get; init; }
    public string? FixedDatabaseCode { get; init; }
    public DateTime ReviewedAt { get; init; } = DateTime.UtcNow;
}

public sealed record ReviewIssue(
    string Category, string Severity, int? Line,
    string CodeSection, string Message, string? Suggestion);

// DataProcessResult (Genie DNA-3)
public sealed record DataProcessResult<T>
{
    public bool IsSuccess { get; init; }
    public T? Data { get; init; }
    public string? Error { get; init; }
    public static DataProcessResult<T> Ok(T data) => new() { IsSuccess = true, Data = data };
    public static DataProcessResult<T> Failure(string error) => new() { IsSuccess = false, Error = error };
}

// Flow context (from Skill 09)
public record FlowStepContext
{
    public string TraceId { get; init; } = "";
    public string NodeId { get; init; } = "";
    public Dictionary<string, object> Input { get; init; } = [];
    public Dictionary<string, object> NodeConfig { get; init; } = [];
}

// Dependency interfaces
public interface IAiDispatcher
{
    Task<Dictionary<string, object>> DispatchAsync(string modelId, string prompt,
        Dictionary<string, object>? options = null, CancellationToken ct = default);
}
public interface IFeedbackService
{
    Task<IReadOnlyList<Dictionary<string, object>>> GetFeedbackHistoryAsync(
        Dictionary<string, object> filter, int limit = 10, CancellationToken ct = default);
}
public interface INodeDebugger
{
    Task StoreSnapshotAsync(string traceId, string nodeId,
        Dictionary<string, object> snapshot, CancellationToken ct = default);
}
public interface IObjectProcessor
{
    Dictionary<string, object> ParseObjectAlternative(object input);
    Dictionary<string, object> BuildSearchFilter(object filter);
}

// ---------------------------------------------------------------------------
// Interface
// ---------------------------------------------------------------------------
public interface IAiReviewService
{
    Task<DataProcessResult<ReviewOutput>> ExecuteAsync(FlowStepContext context, CancellationToken ct = default);
    Task<DataProcessResult<ReviewOutput>> ReviewCodeAsync(ReviewInput input, ReviewConfig config, CancellationToken ct = default);
}

// ---------------------------------------------------------------------------
// Implementation
// ---------------------------------------------------------------------------
public sealed class AiReviewService : IAiReviewService
{
    private readonly IAiDispatcher _dispatcher;
    private readonly IFeedbackService _feedback;
    private readonly INodeDebugger _debugger;
    private readonly IObjectProcessor _objectProcessor;
    private readonly ILogger<AiReviewService> _logger;

    public AiReviewService(IAiDispatcher dispatcher, IFeedbackService feedback,
        INodeDebugger debugger, IObjectProcessor objectProcessor, ILogger<AiReviewService> logger)
    {
        _dispatcher = dispatcher; _feedback = feedback; _debugger = debugger;
        _objectProcessor = objectProcessor; _logger = logger;
    }

    public async Task<DataProcessResult<ReviewOutput>> ExecuteAsync(
        FlowStepContext context, CancellationToken ct = default)
    {
        try
        {
            var config = ExtractConfig(context.NodeConfig);
            var input = ExtractInput(context.Input);

            // Auto-pass if nothing to review
            if (string.IsNullOrWhiteSpace(input.ClientCode) &&
                string.IsNullOrWhiteSpace(input.ServerCode) &&
                string.IsNullOrWhiteSpace(input.DatabaseCode))
            {
                return DataProcessResult<ReviewOutput>.Ok(new ReviewOutput
                {
                    Passed = true, OverallScore = 1.0, Summary = "No code to review — auto-pass"
                });
            }

            var result = await ReviewCodeAsync(input, config, ct);

            if (result.IsSuccess && result.Data is not null)
            {
                await StoreDebugSnapshot(context, result.Data, ct);
            }
            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "AI Review failed for trace {TraceId}", context.TraceId);
            return DataProcessResult<ReviewOutput>.Failure($"Review failed: {ex.Message}");
        }
    }

    public async Task<DataProcessResult<ReviewOutput>> ReviewCodeAsync(
        ReviewInput input, ReviewConfig config, CancellationToken ct = default)
    {
        // Step 1: Build review prompt
        var historicalPatterns = config.IncludeHistoricalPatterns
            ? await LoadHistoricalPatterns(input, ct)
            : [];
        var prompt = BuildReviewPrompt(input, config, historicalPatterns);

        // Step 2: Dispatch to review model
        var options = new Dictionary<string, object>
        {
            ["maxTokens"] = 4096,
            ["temperature"] = 0.1, // Low temperature for consistent reviews
            ["timeoutSeconds"] = config.TimeoutSeconds
        };

        Dictionary<string, object> rawResponse;
        try
        {
            rawResponse = await _dispatcher.DispatchAsync(
                config.ReviewModel, prompt, options, ct);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Review model dispatch failed");
            return DataProcessResult<ReviewOutput>.Failure($"Review model failed: {ex.Message}");
        }

        // Step 3: Parse review response
        var output = ParseReviewResponse(rawResponse, config);
        return DataProcessResult<ReviewOutput>.Ok(output);
    }

    // -----------------------------------------------------------------------
    // Prompt Building
    // -----------------------------------------------------------------------
    private static string BuildReviewPrompt(
        ReviewInput input, ReviewConfig config,
        IReadOnlyList<Dictionary<string, object>> historicalPatterns)
    {
        var sb = new System.Text.StringBuilder();

        sb.AppendLine("""
            You are a senior code reviewer. Review the following generated code strictly for quality issues.
            
            ## Review Categories (check ALL that apply):
            1. Correctness — syntax errors, logic bugs, type mismatches, missing returns
            2. Security — XSS, SQL injection, auth bypasses, hardcoded secrets, CSRF
            3. Accessibility — missing ARIA labels, keyboard navigation, semantic HTML, contrast
            4. Performance — N+1 queries, memory leaks, unnecessary re-renders, large bundle
            5. Pattern compliance — dependency injection, error handling, SOLID principles
            6. Completeness — all design elements implemented, error states handled, loading states
            
            ## REQUIRED RESPONSE FORMAT (strict JSON, no markdown):
            {
              "overallScore": 0.85,
              "passed": true,
              "issues": [
                {
                  "category": "security",
                  "severity": "critical",
                  "line": 42,
                  "code": "clientCode",
                  "message": "Unescaped user input in innerHTML",
                  "suggestion": "Use textContent or sanitize input"
                }
              ],
              "suggestions": ["Consider adding loading states", "Add error boundary"],
              "summary": "Code is generally well-structured with one critical security issue..."
            }
            
            Severity levels: critical (must fix), error (should fix), warning (nice to fix), info (suggestion)
            """);

        // Code sections
        if (!string.IsNullOrWhiteSpace(input.ClientCode))
        {
            sb.AppendLine($"\n## Client Code ({input.TargetClient})");
            sb.AppendLine($"```\n{input.ClientCode}\n```");
        }
        if (!string.IsNullOrWhiteSpace(input.ServerCode))
        {
            sb.AppendLine($"\n## Server Code ({input.TargetServer})");
            sb.AppendLine($"```\n{input.ServerCode}\n```");
        }
        if (!string.IsNullOrWhiteSpace(input.DatabaseCode))
        {
            sb.AppendLine($"\n## Database Code ({input.TargetDatabase})");
            sb.AppendLine($"```\n{input.DatabaseCode}\n```");
        }

        // Historical patterns
        if (historicalPatterns.Count > 0)
        {
            sb.AppendLine("\n## Common Issues from Past Reviews (pay extra attention):");
            foreach (var pattern in historicalPatterns.Take(10))
            {
                var cat = GetStr(pattern, "category", "unknown");
                var msg = GetStr(pattern, "message", "");
                sb.AppendLine($"- [{cat}] {msg}");
            }
        }

        return sb.ToString();
    }

    // -----------------------------------------------------------------------
    // Response Parsing
    // -----------------------------------------------------------------------
    private ReviewOutput ParseReviewResponse(
        Dictionary<string, object> rawResponse, ReviewConfig config)
    {
        var responseText = GetStr(rawResponse, "response",
            GetStr(rawResponse, "text", ""));

        if (string.IsNullOrWhiteSpace(responseText))
        {
            return new ReviewOutput
            {
                Passed = false, OverallScore = 0,
                Summary = "Review model returned empty response",
                Issues = [new ReviewIssue("review", "error", null, "all", "Empty review response", "Retry review")]
            };
        }

        try
        {
            // Strip markdown code fences if present
            var json = responseText.Trim();
            if (json.StartsWith("```")) json = json[json.IndexOf('\n')..];
            if (json.EndsWith("```")) json = json[..json.LastIndexOf('\n')];
            json = json.Trim();

            using var doc = JsonDocument.Parse(json);
            var root = doc.RootElement;

            var score = root.TryGetProperty("overallScore", out var scoreProp)
                ? scoreProp.GetDouble() : 0.5;

            var issues = new List<ReviewIssue>();
            if (root.TryGetProperty("issues", out var issuesArr))
            {
                foreach (var issue in issuesArr.EnumerateArray().Take(config.MaxIssues))
                {
                    issues.Add(new ReviewIssue(
                        GetJsonStr(issue, "category", "unknown"),
                        GetJsonStr(issue, "severity", "warning"),
                        issue.TryGetProperty("line", out var line) ? line.GetInt32() : null,
                        GetJsonStr(issue, "code", "unknown"),
                        GetJsonStr(issue, "message", ""),
                        issue.TryGetProperty("suggestion", out var sug) ? sug.GetString() : null
                    ));
                }
            }

            var suggestions = new List<string>();
            if (root.TryGetProperty("suggestions", out var sugArr))
            {
                foreach (var s in sugArr.EnumerateArray())
                    suggestions.Add(s.GetString() ?? "");
            }

            var summary = GetJsonStr(root, "summary", "Review complete");

            // Determine pass/fail
            var hasCritical = issues.Any(i => i.Severity == "critical");
            var passed = score >= config.PassThreshold &&
                         !(config.BlockOnCritical && hasCritical);

            return new ReviewOutput
            {
                Passed = passed,
                OverallScore = score,
                Issues = issues,
                Suggestions = suggestions,
                Summary = summary,
                ReviewedAt = DateTime.UtcNow
            };
        }
        catch (JsonException ex)
        {
            _logger.LogWarning(ex, "Failed to parse review JSON, using partial result");
            return new ReviewOutput
            {
                Passed = false, OverallScore = 0.5,
                Summary = $"Partial review (JSON parse error): {responseText[..Math.Min(200, responseText.Length)]}...",
                Issues = [new ReviewIssue("review", "warning", null, "all",
                    "Review response was not valid JSON", "Manual review recommended")]
            };
        }
    }

    // -----------------------------------------------------------------------
    // Historical Patterns (Genie DNA-2: BuildSearchFilter)
    // -----------------------------------------------------------------------
    private async Task<IReadOnlyList<Dictionary<string, object>>> LoadHistoricalPatterns(
        ReviewInput input, CancellationToken ct)
    {
        try
        {
            var filter = _objectProcessor.BuildSearchFilter(new
            {
                type = "review-issue",
                severity = new[] { "critical", "error" },
                targetClient = !string.IsNullOrEmpty(input.TargetClient) ? input.TargetClient : null,
                targetServer = !string.IsNullOrEmpty(input.TargetServer) ? input.TargetServer : null,
            });
            return await _feedback.GetFeedbackHistoryAsync(filter, 10, ct);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to load historical review patterns");
            return [];
        }
    }

    // -----------------------------------------------------------------------
    // Debug Snapshot (Genie DNA-1)
    // -----------------------------------------------------------------------
    private async Task StoreDebugSnapshot(
        FlowStepContext context, ReviewOutput output, CancellationToken ct)
    {
        try
        {
            var snapshot = _objectProcessor.ParseObjectAlternative(new
            {
                type = "ai-review",
                traceId = context.TraceId,
                nodeId = context.NodeId,
                reviewId = output.ReviewId,
                passed = output.Passed,
                overallScore = output.OverallScore,
                issueCount = output.Issues.Count,
                criticalCount = output.Issues.Count(i => i.Severity == "critical"),
                errorCount = output.Issues.Count(i => i.Severity == "error"),
                categories = output.Issues.Select(i => i.Category).Distinct().ToList(),
                summary = output.Summary,
                timestamp = DateTime.UtcNow
            });
            await _debugger.StoreSnapshotAsync(context.TraceId, context.NodeId, snapshot, ct);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Debug snapshot failed for review {ReviewId}", output.ReviewId);
        }
    }

    // -----------------------------------------------------------------------
    // Config / Input extraction (dynamic documents)
    // -----------------------------------------------------------------------
    private static ReviewConfig ExtractConfig(Dictionary<string, object> nc) => new()
    {
        ReviewModel = GetStr(nc, "reviewModel", "claude-opus"),
        PassThreshold = GetDbl(nc, "passThreshold", 0.7),
        BlockOnCritical = GetBool(nc, "blockOnCritical", true),
        MaxIssues = GetInt(nc, "maxIssues", 50),
        AutoFixSimple = GetBool(nc, "autoFixSimple", false),
        IncludeHistoricalPatterns = GetBool(nc, "includeHistoricalPatterns", true),
        TimeoutSeconds = GetInt(nc, "timeoutSeconds", 90)
    };

    private static ReviewInput ExtractInput(Dictionary<string, object> input) => new(
        ClientCode: GetStr(input, "clientCode", null),
        ServerCode: GetStr(input, "serverCode", null),
        DatabaseCode: GetStr(input, "databaseCode", null),
        TargetClient: GetStr(input, "targetClient", "react"),
        TargetServer: GetStr(input, "targetServer", "dotnet"),
        TargetDatabase: GetStr(input, "targetDatabase", "elasticsearch"),
        OriginalComponents: null);

    // Dynamic field helpers
    private static string GetStr(Dictionary<string, object> d, string k, string? fb)
        => d.TryGetValue(k, out var v) && v is string s ? s : fb ?? "";
    private static double GetDbl(Dictionary<string, object> d, string k, double fb)
        => d.TryGetValue(k, out var v) ? Convert.ToDouble(v) : fb;
    private static int GetInt(Dictionary<string, object> d, string k, int fb)
        => d.TryGetValue(k, out var v) ? Convert.ToInt32(v) : fb;
    private static bool GetBool(Dictionary<string, object> d, string k, bool fb)
        => d.TryGetValue(k, out var v) ? Convert.ToBoolean(v) : fb;
    private static string GetJsonStr(JsonElement el, string prop, string fb)
        => el.TryGetProperty(prop, out var p) ? p.GetString() ?? fb : fb;
}

// ---------------------------------------------------------------------------
// DI Registration
// ---------------------------------------------------------------------------
public static class AiReviewServiceExtensions
{
    public static IServiceCollection AddXIIGenAiReview(this IServiceCollection services)
    {
        services.AddSingleton<IAiReviewService, AiReviewService>();
        return services;
    }
}
