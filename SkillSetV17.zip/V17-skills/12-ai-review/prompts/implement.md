# Skill 12 — AI Review Service: Implementation Prompt

## Overview
Implement an AI-powered code review service that evaluates generated code across 6 quality dimensions (correctness, security, accessibility, performance, patterns, completeness) and returns structured pass/fail results.

## Phase 1: Models & Interfaces
1. Create `ReviewConfig` with fields: reviewModel, passThreshold (0.7), blockOnCritical, maxIssues (50), categories list
2. Create `ReviewInput` with client/server/database code strings + target stack info
3. Create `ReviewIssue` with category, severity (critical|error|warning|info), line, codeSection, message, suggestion
4. Create `ReviewOutput` with reviewId, passed, overallScore, issues[], suggestions[], summary, optional fixed code
5. Implement `DataProcessResult<T>` wrapper (Genie DNA pattern)

## Phase 2: Core Review Pipeline
1. Implement `collectCode()` — extract non-empty code sections from input
2. If no code sections, return auto-pass (score 1.0)
3. Implement `buildSystemPrompt()` — instruct AI to return structured JSON with issues by category
4. Implement `buildPrompt()` — combine code sections + historical patterns + target stack info
5. Call AI with **low temperature (0.1)** for consistent reviews

## Phase 3: Response Parsing
1. Strip markdown fences (`\`\`\`json ... \`\`\``) from AI response
2. Parse JSON response — extract overallScore, issues[], suggestions[], summary
3. Map raw issues to ReviewIssue objects, limit to maxIssues
4. Calculate pass/fail: `score >= threshold AND !(hasCritical AND blockOnCritical)`
5. On parse failure: return fallback ReviewOutput with score 0.5 and warning issue

## Phase 4: Historical Patterns
1. Use `ObjectProcessor.buildSearchFilter()` with severity=critical,error + target stack
2. Query `xiigen-reviews` index for past critical/error issues
3. Take top 5 summaries and inject into review prompt
4. Gracefully handle failures (return empty string)

## Phase 5: Storage & Debug
1. Store review result via `ObjectProcessor.parseObjectAlternative()` — no fixed schema
2. Upsert to `xiigen-reviews` ES index with reviewId as doc ID
3. Debug snapshots at: review-input, review-raw, review-output
4. Output snapshot includes: passed, score, issue count, critical count by severity

## Phase 6: Integration & Testing
1. Register in DI container with all dependencies
2. Wire into flow orchestrator as a node type

### Test Scenarios
| # | Scenario | Expected |
|---|----------|----------|
| 1 | No code in input | Auto-pass, score 1.0 |
| 2 | Clean code, no issues | Pass, score > 0.7 |
| 3 | Code with critical security flaw | Fail (blockOnCritical=true) |
| 4 | Code with warnings only | Pass with notes |
| 5 | AI returns malformed JSON | Fallback score 0.5, warning issue |
| 6 | Historical patterns exist | Patterns injected into prompt |
| 7 | Multiple code sections | All sections reviewed together |

## Genie DNA Checklist
- [ ] All documents via `ObjectProcessor.parseObjectAlternative()` — no fixed schemas
- [ ] Queries via `buildSearchFilter()` with automatic empty-field skipping
- [ ] All returns wrapped in `DataProcessResult<T>`
- [ ] AI access via `IAiProvider` interface (swappable)
- [ ] Database via `IDatabaseProvider` interface (swappable)
- [ ] Debug snapshots at every pipeline stage

## Dependencies
- **Skill 06** (AI Providers) — for AI completion calls
- **Skill 07** (AI Dispatcher) — if dispatching to multiple review models
- **Skill 11** (AI Transform) — upstream: provides code to review
- **Skill 13** (Feedback Service) — downstream: review results feed into feedback
- **Skill 14** (Node Debugger) — for debug snapshot storage
