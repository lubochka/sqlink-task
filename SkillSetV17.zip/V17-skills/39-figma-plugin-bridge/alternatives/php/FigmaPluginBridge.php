<?php
// =============================================================================
// Skill 39 — Figma Plugin Bridge (PHP 8.3+)
// Connects Figma plugins to XIIGen flow engine via webhook/polling
// Genie DNA: Dynamic documents (array), buildSearchFilter, DataProcessResult
// =============================================================================

declare(strict_types=1);

namespace XIIGen\Pipeline\FigmaBridge;

// ---------------------------------------------------------------------------
// Interfaces
// ---------------------------------------------------------------------------
interface DatabaseProviderInterface {
    /** @return list<array<string, mixed>> */
    public function query(string $index, array $filters): array;
    /** @return array<string, mixed> */
    public function upsert(string $index, string $docId, array $doc): array;
}

interface ObjectProcessorInterface {
    /** @return array<string, mixed> */
    public function parseObjectAlternative(array $doc): array;
    /** @return array<string, mixed> */
    public function buildSearchFilter(array $params): array;
}

interface FlowOrchestratorInterface {
    /** @return DataProcessResult<string> */
    public function triggerFlow(string $flowId, array $input): DataProcessResult;
    /** @return DataProcessResult<array<string,mixed>> */
    public function getFlowStatus(string $traceId): DataProcessResult;
}

// ---------------------------------------------------------------------------
// Models
// ---------------------------------------------------------------------------
readonly class BridgeConfig {
    public function __construct(
        public string $indexName = 'figma-submissions',
        public string $defaultFlowId = 'figma-to-code',
        public int $maxBatchSize = 20,
        public string $targetTech = 'react-native',
        public string $cssFramework = 'tailwind',
        public bool $autoTrigger = true,
        public ?string $webhookSecret = null,
    ) {}
}

class FigmaElement {
    public function __construct(
        public string $name = '',
        public string $sourceType = '',
        public ?string $containingString = null,
        public string $type = '',
        /** @var list<FigmaElement> */
        public array $subElements = [],
        public ?FigmaStyle $style = null,
        public string $code = '',
        public string $codeCss = '',
        /** @var list<string> */
        public array $classNames = [],
    ) {}
}

readonly class FigmaStyle {
    /** @param list<array<string,mixed>> $settings */
    public function __construct(
        public string $name = '',
        public array $settings = [],
    ) {}
}

class FigmaSubmission {
    public string $submissionId;
    public ?string $screenName;
    /** @var list<FigmaElement> */
    public array $scenes;
    /** @var array<string, mixed> */
    public array $metadata;
    public string $submittedAt;
    public ?string $traceId;
    public string $status;

    public function __construct() {
        $this->submissionId = bin2hex(random_bytes(16));
        $this->screenName = null;
        $this->scenes = [];
        $this->metadata = [];
        $this->submittedAt = date('c');
        $this->traceId = null;
        $this->status = 'Received';
    }
}

readonly class FigmaBatchRequest {
    /** @param list<FigmaSubmission> $screens */
    public function __construct(
        public array $screens = [],
        public ?string $projectName = null,
        public ?string $targetTech = null,
        public ?string $cssFramework = null,
    ) {}
}

/** @template T */
readonly class DataProcessResult {
    /** @param T|null $data */
    public function __construct(
        public bool $success,
        public mixed $data = null,
        public ?string $error = null,
    ) {}

    /** @param T $data @return self<T> */
    public static function ok(mixed $data): self { return new self(true, $data); }
    public static function fail(string $err): self { return new self(false, error: $err); }
}

// ---------------------------------------------------------------------------
// Service
// ---------------------------------------------------------------------------
class FigmaPluginBridge {
    private readonly BridgeConfig $cfg;

    public function __construct(
        private readonly DatabaseProviderInterface $db,
        private readonly ObjectProcessorInterface $obj,
        private readonly FlowOrchestratorInterface $orchestrator,
        ?BridgeConfig $config = null,
    ) {
        $this->cfg = $config ?? new BridgeConfig();
    }

    /** @return DataProcessResult<array<string,mixed>> */
    public function handleWebhook(FigmaSubmission $submission, ?string $flowId = null): DataProcessResult
    {
        try {
            $fid = $flowId ?? $this->cfg->defaultFlowId;
            $submission->status = 'Received';
            $submission->submittedAt = date('c');

            // Store
            $doc = $this->obj->parseObjectAlternative([
                'submissionId' => $submission->submissionId,
                'screenName' => $submission->screenName ?? '',
                'status' => $submission->status,
                'submittedAt' => $submission->submittedAt,
                'componentCount' => $this->countElements($submission->scenes),
                'metadata' => $submission->metadata,
            ]);
            $this->db->upsert($this->cfg->indexName, $submission->submissionId, $doc);

            // Map to flow input
            $flowInput = $this->mapToFlowInput($submission);

            // Trigger
            if ($this->cfg->autoTrigger) {
                $result = $this->orchestrator->triggerFlow($fid, $flowInput);
                if (!$result->success) {
                    $submission->status = 'Failed';
                    return DataProcessResult::fail("Flow trigger failed: {$result->error}");
                }
                $submission->traceId = $result->data;
                $submission->status = 'Processing';

                $this->db->upsert($this->cfg->indexName, $submission->submissionId,
                    $this->obj->parseObjectAlternative([
                        'submissionId' => $submission->submissionId,
                        'traceId' => $submission->traceId,
                        'status' => 'Processing',
                    ]));
            }

            return DataProcessResult::ok([
                'submissionId' => $submission->submissionId,
                'traceId' => $submission->traceId,
                'status' => $submission->status,
            ]);
        } catch (\Throwable $ex) {
            error_log("FigmaPluginBridge::handleWebhook failed: {$ex->getMessage()}");
            return DataProcessResult::fail($ex->getMessage());
        }
    }

    /** @return DataProcessResult<array<string,mixed>> */
    public function handleBatch(FigmaBatchRequest $batch): DataProcessResult
    {
        try {
            if (count($batch->screens) > $this->cfg->maxBatchSize) {
                return DataProcessResult::fail("Batch exceeds max {$this->cfg->maxBatchSize}");
            }

            $batchId = bin2hex(random_bytes(16));
            $results = [];

            foreach ($batch->screens as $screen) {
                $screen->metadata['batchId'] = $batchId;
                $screen->metadata['projectName'] = $batch->projectName ?? '';
                $screen->metadata['targetTech'] = $batch->targetTech ?? $this->cfg->targetTech;

                $r = $this->handleWebhook($screen);
                if ($r->success) {
                    $results[] = $r->data;
                }
            }

            $this->db->upsert("{$this->cfg->indexName}-batches", $batchId,
                $this->obj->parseObjectAlternative([
                    'batchId' => $batchId,
                    'screenCount' => count($batch->screens),
                    'completedCount' => count($results),
                    'status' => count($results) === count($batch->screens) ? 'Processing' : 'PartialFailure',
                    'createdAt' => date('c'),
                ]));

            return DataProcessResult::ok(['batchId' => $batchId, 'submissions' => $results]);
        } catch (\Throwable $ex) {
            return DataProcessResult::fail($ex->getMessage());
        }
    }

    /** @return DataProcessResult<array<string,mixed>> */
    public function getStatus(string $traceId): DataProcessResult
    {
        return $this->orchestrator->getFlowStatus($traceId);
    }

    /** @param array<string, string> $filters @return DataProcessResult<list<array<string,mixed>>> */
    public function listSubmissions(array $filters = []): DataProcessResult
    {
        try {
            $filter = $this->obj->buildSearchFilter($filters);
            $docs = $this->db->query($this->cfg->indexName, $filter);
            return DataProcessResult::ok($docs);
        } catch (\Throwable $ex) {
            return DataProcessResult::fail($ex->getMessage());
        }
    }

    // -- Element mapping (recursive) --------------------------------------

    /** @return array<string, mixed> */
    private function mapToFlowInput(FigmaSubmission $sub): array
    {
        $nodes = array_map(fn(FigmaElement $el) => $this->mapElement($el), $sub->scenes);
        return [
            'nodes' => $nodes,
            'metadata' => [
                'screenName' => $sub->screenName ?? 'Untitled',
                'componentCount' => $this->countElements($sub->scenes),
                'hasImages' => $this->hasImages($sub->scenes),
                'submissionId' => $sub->submissionId,
                'targetTech' => $sub->metadata['targetTech'] ?? $this->cfg->targetTech,
                'cssFramework' => $sub->metadata['cssFramework'] ?? $this->cfg->cssFramework,
            ],
        ];
    }

    /** @return array<string, mixed> */
    private function mapElement(FigmaElement $el): array
    {
        return [
            'name' => $el->name,
            'type' => $el->sourceType !== '' ? $el->sourceType : ($el->type ?: 'unknown'),
            'text' => $el->containingString,
            'children' => array_map(fn(FigmaElement $sub) => $this->mapElement($sub), $el->subElements),
            'html' => $el->code,
            'css' => $el->codeCss,
            'classNames' => $el->classNames,
            'styles' => $el->style ? ['name' => $el->style->name, 'settings' => $el->style->settings] : [],
        ];
    }

    /** @param list<FigmaElement> $elements */
    private function countElements(array $elements): int
    {
        $count = 0;
        foreach ($elements as $el) {
            $count++;
            $count += $this->countElements($el->subElements);
        }
        return $count;
    }

    /** @param list<FigmaElement> $elements */
    private function hasImages(array $elements): bool
    {
        foreach ($elements as $el) {
            if ($el->type === 'IMAGE' || $el->sourceType === 'IMAGE') return true;
            if ($this->hasImages($el->subElements)) return true;
        }
        return false;
    }
}
