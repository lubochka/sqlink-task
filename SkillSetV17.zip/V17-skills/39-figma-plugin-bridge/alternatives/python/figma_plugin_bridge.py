# =============================================================================
# Skill 39 — Figma Plugin Bridge (Python)
# Connects Figma plugins to XIIGen flow engine via webhook/polling
# Genie DNA: Dynamic documents, build_search_filter, DataProcessResult
# =============================================================================

from __future__ import annotations
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional, Protocol
from uuid import uuid4

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Protocols
# ---------------------------------------------------------------------------
class DatabaseProvider(Protocol):
    async def query(self, index: str, filters: dict[str, Any]) -> list[dict[str, Any]]: ...
    async def upsert(self, index: str, doc_id: str, doc: dict[str, Any]) -> dict[str, Any]: ...

class ObjectProcessor(Protocol):
    def parse_object_alternative(self, doc: dict[str, Any]) -> dict[str, Any]: ...
    def build_search_filter(self, **kwargs: Any) -> dict[str, Any]: ...

class FlowOrchestrator(Protocol):
    async def trigger_flow(self, flow_id: str, input_data: dict[str, Any]) -> DataProcessResult: ...
    async def get_flow_status(self, trace_id: str) -> DataProcessResult: ...

class NodeDebugger(Protocol):
    async def snapshot(self, trace_id: str, node_id: str, phase: str,
                       data: dict[str, Any]) -> None: ...

# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------
@dataclass
class BridgeConfig:
    index_name: str = "figma-submissions"
    default_flow_id: str = "figma-to-code"
    max_batch_size: int = 20
    target_tech: str = "react-native"
    css_framework: str = "tailwind"
    auto_trigger: bool = True
    webhook_secret: Optional[str] = None

@dataclass
class FigmaStyle:
    name: str = ""
    settings: list[dict[str, Any]] = field(default_factory=list)

@dataclass
class FigmaElement:
    name: str = ""
    source_type: str = ""
    containing_string: Optional[str] = None
    type: str = ""
    sub_elements: list[FigmaElement] = field(default_factory=list)
    style: Optional[FigmaStyle] = None
    code: str = ""
    code_css: str = ""
    class_names: list[str] = field(default_factory=list)

@dataclass
class FigmaSubmission:
    submission_id: str = field(default_factory=lambda: uuid4().hex)
    screen_name: Optional[str] = None
    scenes: list[FigmaElement] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    submitted_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    trace_id: Optional[str] = None
    status: str = "Received"

@dataclass
class FigmaBatchRequest:
    screens: list[FigmaSubmission] = field(default_factory=list)
    project_name: Optional[str] = None
    target_tech: Optional[str] = None
    css_framework: Optional[str] = None

@dataclass
class DataProcessResult:
    success: bool
    data: Any = None
    error: Optional[str] = None

# ---------------------------------------------------------------------------
# Service
# ---------------------------------------------------------------------------
class FigmaPluginBridge:
    """Connects Figma plugins to XIIGen flow engine via webhook/polling."""

    def __init__(
        self,
        db: DatabaseProvider,
        obj: ObjectProcessor,
        orchestrator: FlowOrchestrator,
        debugger: NodeDebugger,
        config: Optional[BridgeConfig] = None,
    ):
        self._db = db
        self._obj = obj
        self._orch = orchestrator
        self._dbg = debugger
        self._cfg = config or BridgeConfig()

    async def handle_webhook(
        self, submission: FigmaSubmission, flow_id: Optional[str] = None,
    ) -> DataProcessResult:
        """Receive single screen from Figma plugin, trigger flow."""
        try:
            fid = flow_id or self._cfg.default_flow_id
            submission.status = "Received"
            submission.submitted_at = datetime.now(timezone.utc).isoformat()

            # Store submission
            doc = self._obj.parse_object_alternative({
                "submissionId": submission.submission_id,
                "screenName": submission.screen_name or "",
                "status": submission.status,
                "submittedAt": submission.submitted_at,
                "componentCount": self._count_elements(submission.scenes),
                "metadata": submission.metadata,
            })
            await self._db.upsert(self._cfg.index_name, submission.submission_id, doc)

            # Map to flow input
            flow_input = self._map_to_flow_input(submission)

            # Trigger flow
            if self._cfg.auto_trigger:
                result = await self._orch.trigger_flow(fid, flow_input)
                if not result.success:
                    submission.status = "Failed"
                    return DataProcessResult(False, error=f"Flow trigger failed: {result.error}")

                submission.trace_id = result.data
                submission.status = "Processing"

                await self._db.upsert(self._cfg.index_name, submission.submission_id,
                    self._obj.parse_object_alternative({
                        "submissionId": submission.submission_id,
                        "traceId": submission.trace_id,
                        "status": "Processing",
                    }))

            return DataProcessResult(True, data={
                "submissionId": submission.submission_id,
                "traceId": submission.trace_id,
                "status": submission.status,
            })
        except Exception as ex:
            logger.error("handle_webhook failed: %s", ex, exc_info=True)
            return DataProcessResult(False, error=str(ex))

    async def handle_batch(self, batch: FigmaBatchRequest) -> DataProcessResult:
        """Submit multiple screens, trigger per-screen flows."""
        try:
            if len(batch.screens) > self._cfg.max_batch_size:
                return DataProcessResult(False, error=f"Batch exceeds max {self._cfg.max_batch_size}")

            batch_id = uuid4().hex
            results = []

            for screen in batch.screens:
                screen.metadata.update({
                    "batchId": batch_id,
                    "projectName": batch.project_name or "",
                    "targetTech": batch.target_tech or self._cfg.target_tech,
                    "cssFramework": batch.css_framework or self._cfg.css_framework,
                })
                r = await self.handle_webhook(screen)
                if r.success:
                    results.append(r.data)

            await self._db.upsert(f"{self._cfg.index_name}-batches", batch_id,
                self._obj.parse_object_alternative({
                    "batchId": batch_id,
                    "projectName": batch.project_name or "",
                    "screenCount": len(batch.screens),
                    "completedCount": len(results),
                    "status": "Processing" if len(results) == len(batch.screens) else "PartialFailure",
                    "createdAt": datetime.now(timezone.utc).isoformat(),
                }))

            return DataProcessResult(True, data={"batchId": batch_id, "submissions": results})
        except Exception as ex:
            return DataProcessResult(False, error=str(ex))

    async def get_status(self, trace_id: str) -> DataProcessResult:
        """Poll for flow result."""
        return await self._orch.get_flow_status(trace_id)

    async def list_submissions(self, **filters: Any) -> DataProcessResult:
        """List past submissions with filters."""
        try:
            flt = self._obj.build_search_filter(**filters)
            docs = await self._db.query(self._cfg.index_name, flt)
            return DataProcessResult(True, data=docs)
        except Exception as ex:
            return DataProcessResult(False, error=str(ex))

    # -- Element mapping (recursive) --------------------------------------
    def _map_to_flow_input(self, sub: FigmaSubmission) -> dict[str, Any]:
        nodes = [self._map_element(el) for el in sub.scenes]
        return {
            "nodes": nodes,
            "metadata": {
                "screenName": sub.screen_name or "Untitled",
                "componentCount": self._count_elements(sub.scenes),
                "hasImages": self._has_images(sub.scenes),
                "submissionId": sub.submission_id,
                "targetTech": sub.metadata.get("targetTech", self._cfg.target_tech),
                "cssFramework": sub.metadata.get("cssFramework", self._cfg.css_framework),
            },
        }

    def _map_element(self, el: FigmaElement) -> dict[str, Any]:
        return {
            "name": el.name,
            "type": el.source_type or el.type or "unknown",
            "text": el.containing_string,
            "children": [self._map_element(sub) for sub in el.sub_elements],
            "html": el.code,
            "css": el.code_css,
            "classNames": el.class_names,
            "styles": {"name": el.style.name, "settings": el.style.settings} if el.style else {},
        }

    def _count_elements(self, elements: list[FigmaElement]) -> int:
        count = 0
        for el in elements:
            count += 1
            count += self._count_elements(el.sub_elements)
        return count

    def _has_images(self, elements: list[FigmaElement]) -> bool:
        for el in elements:
            if el.type == "IMAGE" or el.source_type == "IMAGE":
                return True
            if self._has_images(el.sub_elements):
                return True
        return False


def register_figma_plugin_bridge(container: dict[str, Any], config: Optional[BridgeConfig] = None) -> None:
    container["figma_plugin_bridge"] = FigmaPluginBridge(
        db=container["database_provider"],
        obj=container["object_processor"],
        orchestrator=container["flow_orchestrator"],
        debugger=container["node_debugger"],
        config=config,
    )
