// =============================================================================
// Skill 39 — Figma Plugin Bridge (Node.js/TypeScript)
// Connects Figma plugins to XIIGen flow engine via webhook/polling
// Genie DNA: Dynamic documents, buildSearchFilter, DataProcessResult
// =============================================================================

import { EventEmitter } from 'events';

// ---------------------------------------------------------------------------
// Interfaces
// ---------------------------------------------------------------------------
interface DatabaseProvider {
  query(index: string, filters: Record<string, unknown>): Promise<Record<string, unknown>[]>;
  upsert(index: string, docId: string, doc: Record<string, unknown>): Promise<Record<string, unknown>>;
}

interface ObjectProcessor {
  parseObjectAlternative(doc: Record<string, unknown>): Record<string, unknown>;
  buildSearchFilter(params: Record<string, unknown>): Record<string, unknown>;
}

interface FlowOrchestrator {
  triggerFlow(flowId: string, input: Record<string, unknown>): Promise<DataProcessResult<string>>;
  getFlowStatus(traceId: string): Promise<DataProcessResult<Record<string, unknown>>>;
}

interface NodeDebugger {
  snapshot(traceId: string, nodeId: string, phase: string, data: Record<string, unknown>): Promise<void>;
}

// ---------------------------------------------------------------------------
// Models
// ---------------------------------------------------------------------------
interface FigmaStyle {
  name: string;
  settings: Record<string, unknown>[];
  sceneSettings?: Record<string, unknown>[];
}

interface FigmaElement {
  name: string;
  sourceType: string;
  containingString?: string;
  type: string;
  subElements: FigmaElement[];
  style?: FigmaStyle;
  code: string;
  codeCss: string;
  classNames: string[];
}

interface FigmaSubmission {
  submissionId: string;
  screenName?: string;
  scenes: FigmaElement[];
  metadata: Record<string, unknown>;
  submittedAt: string;
  traceId?: string;
  status: 'Received' | 'Processing' | 'Complete' | 'Failed';
}

interface FigmaBatchRequest {
  screens: FigmaSubmission[];
  projectName?: string;
  targetTech?: string;
  cssFramework?: string;
}

interface BridgeConfig {
  indexName: string;
  defaultFlowId: string;
  maxBatchSize: number;
  targetTech: string;
  cssFramework: string;
  autoTrigger: boolean;
  webhookSecret?: string;
}

interface FlowInputNode {
  name: string;
  type: string;
  text?: string;
  children: FlowInputNode[];
  html: string;
  css: string;
  classNames: string[];
  styles: Record<string, unknown>;
}

interface DataProcessResult<T> {
  success: boolean;
  data?: T;
  error?: string;
  metadata?: Record<string, unknown>;
}

// ---------------------------------------------------------------------------
// Service
// ---------------------------------------------------------------------------
export class FigmaPluginBridge extends EventEmitter {
  private readonly db: DatabaseProvider;
  private readonly obj: ObjectProcessor;
  private readonly orchestrator: FlowOrchestrator;
  private readonly debugger: NodeDebugger;
  private readonly cfg: BridgeConfig;

  constructor(
    db: DatabaseProvider,
    obj: ObjectProcessor,
    orchestrator: FlowOrchestrator,
    debugger_: NodeDebugger,
    config?: Partial<BridgeConfig>,
  ) {
    super();
    this.db = db;
    this.obj = obj;
    this.orchestrator = orchestrator;
    this.debugger = debugger_;
    this.cfg = {
      indexName: 'figma-submissions',
      defaultFlowId: 'figma-to-code',
      maxBatchSize: 20,
      targetTech: 'react-native',
      cssFramework: 'tailwind',
      autoTrigger: true,
      ...config,
    };
  }

  // -- Webhook: receive single screen ------------------------------------
  async handleWebhook(
    submission: FigmaSubmission,
    flowId?: string,
  ): Promise<DataProcessResult<FigmaSubmission>> {
    try {
      const fid = flowId ?? this.cfg.defaultFlowId;
      submission.submissionId = submission.submissionId || crypto.randomUUID();
      submission.status = 'Received';
      submission.submittedAt = new Date().toISOString();

      // Store submission
      const doc = this.obj.parseObjectAlternative({
        submissionId: submission.submissionId,
        screenName: submission.screenName ?? '',
        status: submission.status,
        submittedAt: submission.submittedAt,
        componentCount: this.countElements(submission.scenes),
        metadata: submission.metadata ?? {},
      });
      await this.db.upsert(this.cfg.indexName, submission.submissionId, doc);

      // Map to flow input
      const flowInput = this.mapToFlowInput(submission);

      // Trigger flow
      if (this.cfg.autoTrigger) {
        const triggerResult = await this.orchestrator.triggerFlow(fid, flowInput);
        if (!triggerResult.success) {
          submission.status = 'Failed';
          return { success: false, error: `Flow trigger failed: ${triggerResult.error}` };
        }
        submission.traceId = triggerResult.data;
        submission.status = 'Processing';

        // Update submission with traceId
        await this.db.upsert(this.cfg.indexName, submission.submissionId,
          this.obj.parseObjectAlternative({
            submissionId: submission.submissionId,
            traceId: submission.traceId,
            status: 'Processing',
          }));
      }

      this.emit('submission', { submissionId: submission.submissionId, traceId: submission.traceId });
      return { success: true, data: submission };
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      return { success: false, error: msg };
    }
  }

  // -- Batch: multiple screens -------------------------------------------
  async handleBatch(
    batch: FigmaBatchRequest,
  ): Promise<DataProcessResult<{ batchId: string; submissions: FigmaSubmission[] }>> {
    try {
      if (batch.screens.length > this.cfg.maxBatchSize) {
        return { success: false, error: `Batch exceeds max size ${this.cfg.maxBatchSize}` };
      }

      const batchId = crypto.randomUUID();
      const results: FigmaSubmission[] = [];

      // Process each screen in parallel
      const promises = batch.screens.map(async (screen) => {
        screen.metadata = {
          ...screen.metadata,
          batchId,
          projectName: batch.projectName ?? '',
          targetTech: batch.targetTech ?? this.cfg.targetTech,
          cssFramework: batch.cssFramework ?? this.cfg.cssFramework,
        };
        return this.handleWebhook(screen);
      });

      const settled = await Promise.allSettled(promises);
      for (const result of settled) {
        if (result.status === 'fulfilled' && result.value.success && result.value.data) {
          results.push(result.value.data);
        }
      }

      // Store batch record
      await this.db.upsert(this.cfg.indexName + '-batches', batchId,
        this.obj.parseObjectAlternative({
          batchId,
          projectName: batch.projectName ?? '',
          screenCount: batch.screens.length,
          completedCount: results.length,
          status: results.length === batch.screens.length ? 'Processing' : 'PartialFailure',
          createdAt: new Date().toISOString(),
        }));

      return { success: true, data: { batchId, submissions: results } };
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      return { success: false, error: msg };
    }
  }

  // -- Poll for status ---------------------------------------------------
  async getStatus(traceId: string): Promise<DataProcessResult<Record<string, unknown>>> {
    return this.orchestrator.getFlowStatus(traceId);
  }

  // -- List submissions --------------------------------------------------
  async listSubmissions(
    filters: { screenName?: string; status?: string; batchId?: string },
  ): Promise<DataProcessResult<Record<string, unknown>[]>> {
    try {
      const filter = this.obj.buildSearchFilter(filters as Record<string, unknown>);
      const docs = await this.db.query(this.cfg.indexName, filter);
      return { success: true, data: docs };
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      return { success: false, error: msg };
    }
  }

  // -- Element → FlowInput mapping (recursive) --------------------------
  private mapToFlowInput(submission: FigmaSubmission): Record<string, unknown> {
    const nodes = submission.scenes.map((el) => this.mapElement(el));
    return {
      nodes,
      metadata: {
        screenName: submission.screenName ?? 'Untitled',
        componentCount: this.countElements(submission.scenes),
        hasImages: this.hasImages(submission.scenes),
        submissionId: submission.submissionId,
        targetTech: submission.metadata?.targetTech ?? this.cfg.targetTech,
        cssFramework: submission.metadata?.cssFramework ?? this.cfg.cssFramework,
      },
    };
  }

  private mapElement(el: FigmaElement): FlowInputNode {
    return {
      name: el.name,
      type: el.sourceType || el.type || 'unknown',
      text: el.containingString ?? undefined,
      children: (el.subElements ?? []).map((sub) => this.mapElement(sub)),
      html: el.code ?? '',
      css: el.codeCss ?? '',
      classNames: el.classNames ?? [],
      styles: el.style ? { name: el.style.name, settings: el.style.settings } : {},
    };
  }

  private countElements(elements: FigmaElement[]): number {
    let count = 0;
    for (const el of elements) {
      count += 1;
      if (el.subElements?.length) count += this.countElements(el.subElements);
    }
    return count;
  }

  private hasImages(elements: FigmaElement[]): boolean {
    for (const el of elements) {
      if (el.type === 'IMAGE' || el.sourceType === 'IMAGE') return true;
      if (el.subElements?.length && this.hasImages(el.subElements)) return true;
    }
    return false;
  }
}

// ---------------------------------------------------------------------------
// DI Registration
// ---------------------------------------------------------------------------
export function registerFigmaPluginBridge(
  container: Record<string, unknown>,
  config?: Partial<BridgeConfig>,
): void {
  container['figmaPluginBridge'] = new FigmaPluginBridge(
    container['databaseProvider'] as DatabaseProvider,
    container['objectProcessor'] as ObjectProcessor,
    container['flowOrchestrator'] as FlowOrchestrator,
    container['nodeDebugger'] as NodeDebugger,
    config,
  );
}
