// =============================================================================
// Skill 39 — Figma Plugin Bridge (Rust)
// Connects Figma plugins to XIIGen flow engine via webhook/polling
// Genie DNA: Dynamic documents (serde_json::Value), build_search_filter, DataProcessResult
// =============================================================================

use async_trait::async_trait;
use chrono::Utc;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::collections::HashMap;
use uuid::Uuid;

// ---------------------------------------------------------------------------
// Interfaces
// ---------------------------------------------------------------------------
#[async_trait]
pub trait DatabaseProvider: Send + Sync {
    async fn query(&self, index: &str, filters: Value) -> Result<Vec<Value>, Box<dyn std::error::Error>>;
    async fn upsert(&self, index: &str, doc_id: &str, doc: Value) -> Result<Value, Box<dyn std::error::Error>>;
}

pub trait ObjectProcessor: Send + Sync {
    fn parse_object_alternative(&self, doc: Value) -> Value;
    fn build_search_filter(&self, params: &HashMap<String, String>) -> Value;
}

#[async_trait]
pub trait FlowOrchestrator: Send + Sync {
    async fn trigger_flow(&self, flow_id: &str, input: Value) -> DataProcessResult<String>;
    async fn get_flow_status(&self, trace_id: &str) -> DataProcessResult<Value>;
}

// ---------------------------------------------------------------------------
// Models
// ---------------------------------------------------------------------------
#[derive(Clone, Debug)]
pub struct BridgeConfig {
    pub index_name: String,
    pub default_flow_id: String,
    pub max_batch_size: usize,
    pub target_tech: String,
    pub css_framework: String,
    pub auto_trigger: bool,
}

impl Default for BridgeConfig {
    fn default() -> Self {
        Self {
            index_name: "figma-submissions".into(),
            default_flow_id: "figma-to-code".into(),
            max_batch_size: 20,
            target_tech: "react-native".into(),
            css_framework: "tailwind".into(),
            auto_trigger: true,
        }
    }
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct FigmaStyle {
    pub name: String,
    pub settings: Vec<Value>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct FigmaElement {
    pub name: String,
    pub source_type: String,
    pub containing_string: Option<String>,
    #[serde(rename = "type")]
    pub elem_type: String,
    pub sub_elements: Vec<FigmaElement>,
    pub style: Option<FigmaStyle>,
    pub code: String,
    pub code_css: String,
    pub class_names: Vec<String>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct FigmaSubmission {
    pub submission_id: String,
    pub screen_name: Option<String>,
    pub scenes: Vec<FigmaElement>,
    pub metadata: HashMap<String, Value>,
    pub submitted_at: String,
    pub trace_id: Option<String>,
    pub status: String,
}

impl Default for FigmaSubmission {
    fn default() -> Self {
        Self {
            submission_id: Uuid::new_v4().to_string(),
            screen_name: None,
            scenes: vec![],
            metadata: HashMap::new(),
            submitted_at: Utc::now().to_rfc3339(),
            trace_id: None,
            status: "Received".into(),
        }
    }
}

#[derive(Clone, Debug)]
pub struct DataProcessResult<T> {
    pub success: bool,
    pub data: Option<T>,
    pub error: Option<String>,
}

impl<T> DataProcessResult<T> {
    pub fn ok(data: T) -> Self { Self { success: true, data: Some(data), error: None } }
    pub fn fail(err: String) -> Self { Self { success: false, data: None, error: Some(err) } }
}

// ---------------------------------------------------------------------------
// Service
// ---------------------------------------------------------------------------
pub struct FigmaPluginBridge {
    db: Box<dyn DatabaseProvider>,
    obj: Box<dyn ObjectProcessor>,
    orchestrator: Box<dyn FlowOrchestrator>,
    cfg: BridgeConfig,
}

impl FigmaPluginBridge {
    pub fn new(
        db: Box<dyn DatabaseProvider>,
        obj: Box<dyn ObjectProcessor>,
        orchestrator: Box<dyn FlowOrchestrator>,
        cfg: Option<BridgeConfig>,
    ) -> Self {
        Self { db, obj, orchestrator, cfg: cfg.unwrap_or_default() }
    }

    /// Handle single screen webhook from Figma plugin
    pub async fn handle_webhook(
        &self, submission: &mut FigmaSubmission, flow_id: Option<&str>,
    ) -> DataProcessResult<Value> {
        let fid = flow_id.unwrap_or(&self.cfg.default_flow_id);
        submission.status = "Received".into();
        submission.submitted_at = Utc::now().to_rfc3339();

        // Store submission
        let doc = self.obj.parse_object_alternative(json!({
            "submissionId": submission.submission_id,
            "screenName": submission.screen_name.as_deref().unwrap_or(""),
            "status": submission.status,
            "submittedAt": submission.submitted_at,
            "componentCount": count_elements(&submission.scenes),
        }));

        if let Err(e) = self.db.upsert(&self.cfg.index_name, &submission.submission_id, doc).await {
            return DataProcessResult::fail(format!("Store failed: {}", e));
        }

        // Map to flow input
        let flow_input = self.map_to_flow_input(submission);

        // Trigger flow
        if self.cfg.auto_trigger {
            let result = self.orchestrator.trigger_flow(fid, flow_input).await;
            if !result.success {
                submission.status = "Failed".into();
                return DataProcessResult::fail(format!("Flow trigger failed: {:?}", result.error));
            }
            submission.trace_id = result.data.clone();
            submission.status = "Processing".into();

            let update = self.obj.parse_object_alternative(json!({
                "submissionId": submission.submission_id,
                "traceId": submission.trace_id,
                "status": "Processing",
            }));
            let _ = self.db.upsert(&self.cfg.index_name, &submission.submission_id, update).await;
        }

        DataProcessResult::ok(json!({
            "submissionId": submission.submission_id,
            "traceId": submission.trace_id,
            "status": submission.status,
        }))
    }

    /// Poll for flow result
    pub async fn get_status(&self, trace_id: &str) -> DataProcessResult<Value> {
        self.orchestrator.get_flow_status(trace_id).await
    }

    /// List submissions with filters
    pub async fn list_submissions(&self, filters: &HashMap<String, String>) -> DataProcessResult<Vec<Value>> {
        let filter = self.obj.build_search_filter(filters);
        match self.db.query(&self.cfg.index_name, filter).await {
            Ok(docs) => DataProcessResult::ok(docs),
            Err(e) => DataProcessResult::fail(format!("Query failed: {}", e)),
        }
    }

    // -- Element mapping (recursive) --------------------------------------
    fn map_to_flow_input(&self, sub: &FigmaSubmission) -> Value {
        let nodes: Vec<Value> = sub.scenes.iter().map(|el| map_element(el)).collect();
        json!({
            "nodes": nodes,
            "metadata": {
                "screenName": sub.screen_name.as_deref().unwrap_or("Untitled"),
                "componentCount": count_elements(&sub.scenes),
                "hasImages": has_images(&sub.scenes),
                "submissionId": sub.submission_id,
                "targetTech": sub.metadata.get("targetTech")
                    .and_then(|v| v.as_str())
                    .unwrap_or(&self.cfg.target_tech),
            }
        })
    }
}

fn map_element(el: &FigmaElement) -> Value {
    let children: Vec<Value> = el.sub_elements.iter().map(|s| map_element(s)).collect();
    let styles = match &el.style {
        Some(s) => json!({"name": s.name, "settings": s.settings}),
        None => json!({}),
    };
    json!({
        "name": el.name,
        "type": if el.source_type.is_empty() { &el.elem_type } else { &el.source_type },
        "text": el.containing_string,
        "children": children,
        "html": el.code,
        "css": el.code_css,
        "classNames": el.class_names,
        "styles": styles,
    })
}

fn count_elements(elements: &[FigmaElement]) -> usize {
    elements.iter().fold(0, |acc, el| acc + 1 + count_elements(&el.sub_elements))
}

fn has_images(elements: &[FigmaElement]) -> bool {
    elements.iter().any(|el|
        el.elem_type == "IMAGE" || el.source_type == "IMAGE" || has_images(&el.sub_elements)
    )
}
