// =============================================================================
// Skill 39 — Figma Plugin Bridge (Java 21+)
// Connects Figma plugins to XIIGen flow engine via webhook/polling
// Genie DNA: Dynamic documents (Map), buildSearchFilter, DataProcessResult
// =============================================================================

package com.xiigen.pipeline.figmabridge;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Logger;

// ---------------------------------------------------------------------------
// Interfaces
// ---------------------------------------------------------------------------
interface DatabaseProvider {
    CompletableFuture<List<Map<String, Object>>> query(String index, Map<String, Object> filters);
    CompletableFuture<Map<String, Object>> upsert(String index, String docId, Map<String, Object> doc);
}

interface ObjectProcessor {
    Map<String, Object> parseObjectAlternative(Map<String, Object> doc);
    Map<String, Object> buildSearchFilter(Map<String, Object> params);
}

interface FlowOrchestrator {
    CompletableFuture<DataProcessResult<String>> triggerFlow(String flowId, Map<String, Object> input);
    CompletableFuture<DataProcessResult<Map<String, Object>>> getFlowStatus(String traceId);
}

// ---------------------------------------------------------------------------
// Models
// ---------------------------------------------------------------------------
record BridgeConfig(
    String indexName, String defaultFlowId, int maxBatchSize,
    String targetTech, String cssFramework, boolean autoTrigger, String webhookSecret
) {
    static BridgeConfig defaults() {
        return new BridgeConfig("figma-submissions", "figma-to-code", 20,
            "react-native", "tailwind", true, null);
    }
}

record FigmaStyle(String name, List<Map<String, Object>> settings) {}

record DataProcessResult<T>(boolean success, T data, String error) {
    static <T> DataProcessResult<T> ok(T data) { return new DataProcessResult<>(true, data, null); }
    static <T> DataProcessResult<T> fail(String err) { return new DataProcessResult<>(false, null, err); }
}

class FigmaElement {
    String name = "";
    String sourceType = "";
    String containingString;
    String type = "";
    List<FigmaElement> subElements = new ArrayList<>();
    FigmaStyle style;
    String code = "";
    String codeCss = "";
    List<String> classNames = new ArrayList<>();
}

class FigmaSubmission {
    String submissionId = UUID.randomUUID().toString().replace("-", "");
    String screenName;
    List<FigmaElement> scenes = new ArrayList<>();
    Map<String, Object> metadata = new HashMap<>();
    String submittedAt = Instant.now().toString();
    String traceId;
    String status = "Received";
}

record FigmaBatchRequest(
    List<FigmaSubmission> screens, String projectName,
    String targetTech, String cssFramework
) {}

// ---------------------------------------------------------------------------
// Service
// ---------------------------------------------------------------------------
public class FigmaPluginBridge {
    private static final Logger log = Logger.getLogger(FigmaPluginBridge.class.getName());

    private final DatabaseProvider db;
    private final ObjectProcessor obj;
    private final FlowOrchestrator orchestrator;
    private final BridgeConfig cfg;

    public FigmaPluginBridge(DatabaseProvider db, ObjectProcessor obj,
                             FlowOrchestrator orchestrator, BridgeConfig cfg) {
        this.db = db;
        this.obj = obj;
        this.orchestrator = orchestrator;
        this.cfg = cfg != null ? cfg : BridgeConfig.defaults();
    }

    // -- Webhook handler --------------------------------------------------
    public CompletableFuture<DataProcessResult<Map<String, Object>>> handleWebhook(
            FigmaSubmission submission, String flowId) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                String fid = flowId != null ? flowId : cfg.defaultFlowId();
                submission.status = "Received";
                submission.submittedAt = Instant.now().toString();

                // Store
                var doc = obj.parseObjectAlternative(Map.of(
                    "submissionId", submission.submissionId,
                    "screenName", Optional.ofNullable(submission.screenName).orElse(""),
                    "status", submission.status,
                    "submittedAt", submission.submittedAt,
                    "componentCount", countElements(submission.scenes)
                ));
                db.upsert(cfg.indexName(), submission.submissionId, doc).join();

                // Map to flow input
                var flowInput = mapToFlowInput(submission);

                // Trigger
                if (cfg.autoTrigger()) {
                    var result = orchestrator.triggerFlow(fid, flowInput).join();
                    if (!result.success()) {
                        submission.status = "Failed";
                        return DataProcessResult.fail("Flow trigger failed: " + result.error());
                    }
                    submission.traceId = result.data();
                    submission.status = "Processing";

                    db.upsert(cfg.indexName(), submission.submissionId,
                        obj.parseObjectAlternative(Map.of(
                            "submissionId", submission.submissionId,
                            "traceId", submission.traceId,
                            "status", "Processing"
                        ))).join();
                }

                return DataProcessResult.ok(Map.of(
                    "submissionId", submission.submissionId,
                    "traceId", Optional.ofNullable(submission.traceId).orElse(""),
                    "status", submission.status
                ));
            } catch (Exception ex) {
                log.severe("handleWebhook failed: " + ex.getMessage());
                return DataProcessResult.fail(ex.getMessage());
            }
        });
    }

    // -- Batch handler ----------------------------------------------------
    public CompletableFuture<DataProcessResult<Map<String, Object>>> handleBatch(
            FigmaBatchRequest batch) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                if (batch.screens().size() > cfg.maxBatchSize()) {
                    return DataProcessResult.fail("Batch exceeds max " + cfg.maxBatchSize());
                }

                String batchId = UUID.randomUUID().toString().replace("-", "");
                var results = new ArrayList<Map<String, Object>>();

                for (var screen : batch.screens()) {
                    screen.metadata.put("batchId", batchId);
                    screen.metadata.put("projectName", Optional.ofNullable(batch.projectName()).orElse(""));
                    screen.metadata.put("targetTech",
                        Optional.ofNullable(batch.targetTech()).orElse(cfg.targetTech()));

                    var r = handleWebhook(screen, null).join();
                    if (r.success() && r.data() != null) results.add(r.data());
                }

                db.upsert(cfg.indexName() + "-batches", batchId,
                    obj.parseObjectAlternative(Map.of(
                        "batchId", batchId,
                        "screenCount", batch.screens().size(),
                        "completedCount", results.size(),
                        "status", results.size() == batch.screens().size() ? "Processing" : "PartialFailure",
                        "createdAt", Instant.now().toString()
                    ))).join();

                return DataProcessResult.ok(Map.of("batchId", batchId, "submissions", results));
            } catch (Exception ex) {
                return DataProcessResult.fail(ex.getMessage());
            }
        });
    }

    // -- Status polling ---------------------------------------------------
    public CompletableFuture<DataProcessResult<Map<String, Object>>> getStatus(String traceId) {
        return orchestrator.getFlowStatus(traceId);
    }

    // -- Element mapping (recursive) --------------------------------------
    private Map<String, Object> mapToFlowInput(FigmaSubmission sub) {
        var nodes = sub.scenes.stream().map(this::mapElement).toList();
        return Map.of(
            "nodes", nodes,
            "metadata", Map.of(
                "screenName", Optional.ofNullable(sub.screenName).orElse("Untitled"),
                "componentCount", countElements(sub.scenes),
                "hasImages", hasImages(sub.scenes),
                "submissionId", sub.submissionId,
                "targetTech", sub.metadata.getOrDefault("targetTech", cfg.targetTech())
            )
        );
    }

    private Map<String, Object> mapElement(FigmaElement el) {
        var children = el.subElements.stream().map(this::mapElement).toList();
        var styles = el.style != null
            ? Map.of("name", el.style.name(), "settings", el.style.settings())
            : Map.of();
        return Map.of(
            "name", el.name, "type", el.sourceType.isEmpty() ? el.type : el.sourceType,
            "text", Optional.ofNullable(el.containingString).orElse(""),
            "children", children, "html", el.code, "css", el.codeCss,
            "classNames", el.classNames, "styles", styles
        );
    }

    private int countElements(List<FigmaElement> elements) {
        int count = 0;
        for (var el : elements) {
            count++;
            count += countElements(el.subElements);
        }
        return count;
    }

    private boolean hasImages(List<FigmaElement> elements) {
        for (var el : elements) {
            if ("IMAGE".equals(el.type) || "IMAGE".equals(el.sourceType)) return true;
            if (hasImages(el.subElements)) return true;
        }
        return false;
    }
}
