---
name: figma-plugin-bridge
description: Connects Figma plugins to XIIGen flow engine via webhook/polling
triggers: figma plugin, figma webhook, design import, figma bridge, figma submission
dependencies: [01-core-interfaces, 02-object-processor, 05-database-fabric, 09-flow-orchestrator, 10-figma-parser, 15-api-gateway]
layer: L5-PipelineSteps
genie-dna: Uses ObjectProcessor for all element mapping, BuildSearchFilter for submission queries
version: v17
---

# Skill 39 — Figma Plugin Bridge

## Purpose
Receives Figma node trees from the FigmaCodeGenerator plugin (or any Figma export) via webhook, maps plugin-specific element structures to generic flow inputs, and triggers the figma-to-code pipeline. Supports single-screen webhook, batch multi-screen, and polling for results.

## Architecture

```
Figma Plugin → POST /api/figma/webhook → FigmaPluginBridge
  ↓ maps FigmaElement → FlowInput
  ↓ stores submission in ES (figma-submissions)
  ↓ triggers FlowOrchestrator with flowId="figma-to-code"
  ↓ returns traceId for polling
Client → GET /api/figma/{traceId}/status → poll result
```

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/figma/webhook` | Receive single Figma screen, trigger flow |
| POST | `/api/figma/batch` | Submit multiple screens, trigger per-screen flows |
| GET | `/api/figma/{traceId}/status` | Poll for flow result by traceId |
| GET | `/api/figma/submissions` | List past submissions with filters |

## Element Mapping

The bridge translates FigmaCodeGenerator's `Element` model into XIIGen's generic `FlowInput`:

```
FigmaElement {                       FlowInput {
  name ─────────────────────────→      nodes: [{
  sourceType ───────────────────→        name, type,
  containingString ─────────────→        text,
  subElements[] ────────────────→        children[],  (recursive)
  style { name, settings[] } ───→        styles: {},
  code ─────────────────────────→        html,
  codeCss ──────────────────────→        css,
  classNames[] ─────────────────→        classNames[]
}                                      }],
                                       metadata: { screenName, componentCount, hasImages }
                                     }
```

## Configuration

```json
{
  "indexName": "figma-submissions",
  "defaultFlowId": "figma-to-code",
  "maxBatchSize": 20,
  "targetTech": "react-native",
  "cssFramework": "tailwind",
  "autoTrigger": true,
  "webhookSecret": null,
  "allowedOrigins": ["*"]
}
```

## Key Models

### FigmaElement
Mirrors the FigmaCodeGenerator plugin output. Fields: name, sourceType, containingString, type, subElements[], style (name + settings[]), code, codeCss, classNames[].

### FigmaSubmission
Wrapper for a complete screen submission. Fields: submissionId, screenName, scenes[] (FigmaElement[]), metadata (dynamic), submittedAt, traceId, status (Received|Processing|Complete|Failed).

### FigmaBatchRequest
Multi-screen submission. Fields: screens[] (FigmaSubmission[]), projectName, targetTech, cssFramework.

## Pipeline Flow

1. **Receive** — Plugin POSTs FigmaElement tree to webhook endpoint
2. **Validate** — Check webhook secret (if configured), validate element structure
3. **Store** — Persist submission in ES index `figma-submissions` via `parseObjectAlternative()`
4. **Map** — Recursive FigmaElement → FlowInput node mapping (preserves full tree structure)
5. **Trigger** — Call `FlowOrchestrator.triggerFlow("figma-to-code", flowInput)` → returns traceId
6. **Return** — Respond with traceId + submissionId for client polling

## Batch Processing

For multi-screen submissions (e.g., entire Figma page):
1. Validate all screens (reject batch if any invalid)
2. Create parent batch record in ES
3. Trigger individual flows per screen (parallel)
4. Aggregate results under batch traceId
5. Batch status = Complete only when all screens complete

## Genie DNA Integration

- **DNA-1**: All submissions stored via `ObjectProcessor.parseObjectAlternative()` — no fixed ES mappings
- **DNA-2**: Submission queries use `buildSearchFilter()` with automatic empty-field skipping
- **DNA-3**: All returns wrapped in `DataProcessResult<T>`
- **DNA-4**: Extends `MicroserviceBase` for standardized service lifecycle

## Dependencies
- **Skill 01** (Core) — MicroserviceBase, DataProcessResult
- **Skill 02** (ObjectProcessor) — Dynamic document storage
- **Skill 05** (Database Fabric) — ES storage for submissions
- **Skill 09** (Flow Orchestrator) — Triggers figma-to-code flow
- **Skill 10** (Figma Parser) — Downstream: parses the mapped elements
- **Skill 15** (API Gateway) — Exposes webhook/polling endpoints

## Technology Alternatives
- **.NET 9** (primary) — `Implementation/FigmaPluginBridge.cs`
- **Node.js** — `alternatives/nodejs/figma-plugin-bridge.ts`
- **Python** — `alternatives/python/figma_plugin_bridge.py`
- **Java** — `alternatives/java/FigmaPluginBridge.java`
- **Rust** — `alternatives/rust/figma_plugin_bridge.rs`
- **PHP** — `alternatives/php/FigmaPluginBridge.php`
