# Skill 39 — Figma Plugin Bridge: Implementation Prompt

## Overview
Implement a bridge service that receives Figma node trees from the FigmaCodeGenerator plugin (or any Figma export), maps them to generic flow inputs, and triggers the figma-to-code pipeline. Supports webhook, batch, and polling.

## Phase 1: Models
1. Create `BridgeConfig`: indexName ("figma-submissions"), defaultFlowId ("figma-to-code"), maxBatchSize (20), targetTech, cssFramework, autoTrigger, webhookSecret
2. Create `FigmaElement` matching plugin output: name, sourceType, containingString, type, subElements[] (recursive), style (name + settings[]), code, codeCss, classNames[]
3. Create `FigmaStyle`: name, settings[] (dynamic array of style properties)
4. Create `FigmaSubmission`: submissionId, screenName, scenes[] (FigmaElement[]), metadata (dynamic), submittedAt, traceId, status (Received|Processing|Complete|Failed)
5. Create `FigmaBatchRequest`: screens[] (FigmaSubmission[]), projectName, targetTech, cssFramework

## Phase 2: Element Mapping
1. Implement recursive `mapToFlowInput()` — converts FigmaSubmission → generic FlowInput
2. `mapElement()` — recursive FigmaElement → FlowInputNode:
   - `name` → name, `sourceType`/`type` → type, `containingString` → text
   - `subElements[]` → children[] (recursive), `code` → html, `codeCss` → css
   - `style` → styles object, `classNames[]` → classNames[]
3. `countElements()` — recursive count of all elements in tree
4. `hasImages()` — recursive check for IMAGE type elements
5. Build metadata: screenName, componentCount, hasImages, submissionId, targetTech

## Phase 3: Webhook Handler
1. Receive FigmaSubmission from POST endpoint
2. Set status = "Received", generate submissionId if missing
3. Store submission in ES via `parseObjectAlternative()` — no fixed schema
4. Call `mapToFlowInput()` to create generic flow input
5. If autoTrigger: call `FlowOrchestrator.triggerFlow("figma-to-code", flowInput)`
6. Update submission with traceId and status = "Processing"
7. Return traceId + submissionId for client polling

## Phase 4: Batch Processing
1. Validate batch size ≤ maxBatchSize
2. Generate batchId for the group
3. Add batch metadata to each screen (batchId, projectName, targetTech)
4. Process each screen via handleWebhook (parallel where possible)
5. Store batch record in ES with aggregate status
6. Status = "Processing" if all succeeded, "PartialFailure" if some failed

## Phase 5: Polling & Query
1. `getStatus(traceId)` — delegates to FlowOrchestrator.getFlowStatus()
2. `listSubmissions(filters)` — query ES using buildSearchFilter() with screenName, status, batchId

## Phase 6: Integration & Security
1. Optional webhook secret validation (HMAC or shared secret)
2. CORS configuration for Figma plugin origin
3. Rate limiting for webhook endpoint
4. Register in DI container with all dependencies

### Test Scenarios
| # | Scenario | Expected |
|---|----------|----------|
| 1 | Single screen webhook | Stored, flow triggered, traceId returned |
| 2 | Batch of 5 screens | 5 flows triggered, batch record created |
| 3 | Batch exceeds maxBatchSize | Rejected with error |
| 4 | Element tree with nested children | Recursive mapping preserves structure |
| 5 | Element with IMAGE type | hasImages = true in metadata |
| 6 | Poll for completed flow | Returns flow result |
| 7 | autoTrigger = false | Stored but no flow triggered |

## Genie DNA Checklist
- [ ] All submissions stored via `ObjectProcessor.parseObjectAlternative()` — no fixed schemas
- [ ] Queries via `buildSearchFilter()` with automatic empty-field skipping
- [ ] All returns wrapped in `DataProcessResult<T>`
- [ ] Flow orchestrator via `IFlowOrchestrator` interface (swappable)
- [ ] Database via `IDatabaseProvider` interface (swappable)

## Dependencies
- **Skill 01** (Core) — MicroserviceBase, DataProcessResult
- **Skill 02** (ObjectProcessor) — Dynamic document storage
- **Skill 05** (Database Fabric) — ES storage for submissions
- **Skill 09** (Flow Orchestrator) — Triggers figma-to-code flow
- **Skill 10** (Figma Parser) — Downstream: parses the mapped elements
- **Skill 15** (API Gateway) — Exposes webhook/polling endpoints
