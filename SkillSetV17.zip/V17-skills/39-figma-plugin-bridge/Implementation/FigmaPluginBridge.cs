// XIIGen.Pipeline.FigmaBridge/FigmaPluginBridge.cs - Skill 39 | .NET 9
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System.Text.Json;
using System.Text.Json.Nodes;
using XIIGen.Core.Base;
using XIIGen.Core.Enums;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Pipeline.FigmaBridge;

// ─── Element model matching FigmaCodeGenerator plugin output ────
public class FigmaElement
{
    public string Name { get; set; } = "";
    public string SourceType { get; set; } = "";
    public string? ContainingString { get; set; }
    public string Type { get; set; } = "";
    public List<FigmaElement> SubElements { get; set; } = [];
    public FigmaStyle? Style { get; set; }
    public string Code { get; set; } = "";
    public string CodeCss { get; set; } = "";
    public List<string> ClassNames { get; set; } = [];
}

public class FigmaStyle
{
    public string Name { get; set; } = "";
    public List<JsonObject> Settings { get; set; } = [];
    public List<JsonObject> SceneSettings { get; set; } = [];
}

public class FigmaSubmission
{
    public string SubmissionId { get; set; } = Guid.NewGuid().ToString();
    public string? ScreenName { get; set; }
    public List<FigmaElement> Scenes { get; set; } = [];
    public Dictionary<string, object> Metadata { get; set; } = [];
    public DateTime SubmittedAt { get; set; } = DateTime.UtcNow;
    public string? TraceId { get; set; }
    public string Status { get; set; } = "Received";
}

public class FigmaBatchRequest
{
    public List<FigmaSubmission> Screens { get; set; } = [];
    public string? ProjectName { get; set; }
    public string? TargetTech { get; set; }      // "react", "angular", "vue", "react-native"
    public string? CssFramework { get; set; }    // "tailwind", "css-modules", "styled-components"
}

// ─── Bridge: maps plugin output → flow input → triggers orchestrator ────
public class FigmaPluginBridge : MicroserviceBase
{
    private readonly IFlowOrchestrator _orchestrator;

    public FigmaPluginBridge(
        IDatabaseService db, IQueueService queue, ILogger<FigmaPluginBridge> logger,
        IFlowOrchestrator orchestrator, ICacheService cache = null)
        : base(db, queue, logger, cache)
    {
        ServiceName = "figma-plugin-bridge";
        _orchestrator = orchestrator;
    }

    /// <summary>Receive a single screen from Figma plugin and trigger the figma-to-code flow.</summary>
    public async Task<DataProcessResult<FigmaSubmission>> HandleWebhookAsync(
        FigmaSubmission submission, string flowId = "figma-to-code", CancellationToken ct = default)
    {
        try
        {
            await StoreDocumentAsync("figma-submissions", submission.SubmissionId, submission, ct: ct);

            var flowInput = MapToFlowInput(submission);
            var triggerResult = await _orchestrator.TriggerFlowAsync(flowId, flowInput, ct);
            if (!triggerResult.IsSuccess)
                return DataProcessResult<FigmaSubmission>.Error($"Flow trigger failed: {triggerResult.Message}");

            submission.TraceId = triggerResult.Data;
            submission.Status = "Processing";
            await StoreDocumentAsync("figma-submissions", submission.SubmissionId, submission, ct: ct);

            Logger.LogInformation("Figma submission {Id} → flow trace {TraceId}", submission.SubmissionId, submission.TraceId);
            return DataProcessResult<FigmaSubmission>.Success(submission);
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Failed handling Figma webhook for {Id}", submission.SubmissionId);
            return DataProcessResult<FigmaSubmission>.Error(ex.Message);
        }
    }

    /// <summary>Submit multiple screens → triggers one flow per screen, returns all traceIds.</summary>
    public async Task<DataProcessResult<List<FigmaSubmission>>> HandleBatchAsync(
        FigmaBatchRequest batch, string flowId = "figma-to-code", CancellationToken ct = default)
    {
        var results = new List<FigmaSubmission>();
        foreach (var screen in batch.Screens)
        {
            screen.Metadata["projectName"] = batch.ProjectName ?? "unnamed";
            screen.Metadata["targetTech"] = batch.TargetTech ?? "react";
            screen.Metadata["cssFramework"] = batch.CssFramework ?? "tailwind";
            var result = await HandleWebhookAsync(screen, flowId, ct);
            results.Add(result.IsSuccess ? result.Data! : screen);
        }
        return DataProcessResult<List<FigmaSubmission>>.Success(results);
    }

    /// <summary>Poll for flow result by traceId (called by Figma plugin).</summary>
    public async Task<DataProcessResult<object>> PollResultAsync(string traceId, CancellationToken ct = default)
    {
        var status = await _orchestrator.GetFlowStatusAsync(traceId, ct);
        if (!status.IsSuccess) return DataProcessResult<object>.Error(status.Message);

        var flowState = status.Data!;
        return DataProcessResult<object>.Success(new
        {
            flowState.TraceId,
            Status = flowState.Status.ToString(),
            flowState.CompletedSteps,
            flowState.TotalSteps,
            IsComplete = flowState.Status == FlowStatus.Completed,
            Results = flowState.Status == FlowStatus.Completed ? flowState.StepStates : null
        });
    }

    /// <summary>Map FigmaCodeGenerator Element tree → flat flow input for FigmaParserExecutor.</summary>
    public Dictionary<string, object> MapToFlowInput(FigmaSubmission submission)
    {
        var nodes = new List<Dictionary<string, object>>();
        foreach (var scene in submission.Scenes)
            FlattenElement(scene, nodes, 0);

        return new Dictionary<string, object>
        {
            ["nodes"] = nodes,
            ["screenName"] = submission.ScreenName ?? submission.Scenes.FirstOrDefault()?.Name ?? "unknown",
            ["componentCount"] = nodes.Count,
            ["hasImages"] = nodes.Any(n => n.ContainsKey("sourceType") && n["sourceType"]?.ToString() == "IMAGE"),
            ["metadata"] = submission.Metadata
        };
    }

    private void FlattenElement(FigmaElement el, List<Dictionary<string, object>> nodes, int depth)
    {
        nodes.Add(new Dictionary<string, object>
        {
            ["name"] = el.Name,
            ["sourceType"] = el.SourceType,
            ["type"] = MapSourceType(el.SourceType),
            ["text"] = el.ContainingString ?? "",
            ["html"] = el.Code,
            ["css"] = el.CodeCss,
            ["classNames"] = el.ClassNames,
            ["depth"] = depth,
            ["childCount"] = el.SubElements.Count
        });
        foreach (var child in el.SubElements)
            FlattenElement(child, nodes, depth + 1);
    }

    private static string MapSourceType(string figmaType) => figmaType switch
    {
        "FRAME" => "div", "TEXT" => "text", "RECTANGLE" => "div", "ELLIPSE" => "div",
        "GROUP" => "div", "COMPONENT" => "component", "INSTANCE" => "instance",
        "VECTOR" => "svg", "IMAGE" => "img", _ => "div"
    };
}

// ─── DI Extension ────
public static class FigmaPluginBridgeExtensions
{
    public static IServiceCollection AddXIIGenFigmaPluginBridge(this IServiceCollection services)
    {
        services.AddSingleton<FigmaPluginBridge>();
        return services;
    }
}
