# Skill 46 — Feed Service: Implementation Prompt

## Overview
Implement a personalized feed generation service with 4-tier ranking (immediate/high/normal/low), time-based weight decay, content deduplication, and admin-configurable thresholds. The feed aggregates content from posts, events, recommendations, and ads into a unified, scored, paginated stream per user.

## Phase 1: Configuration & Models
1. Create `FeedConfig`: feedItemsIndex ("feed-items"), feedConfigIndex ("feed-config"), defaultPageSize (20), maxFeedSize (500), decayHalfLifeHours (24), immediateMinScore (90), highMinScore (70), normalMinScore (40)
2. Create `FeedPage`: items (list of dynamic docs), cursor (string), totalCount, hasMore
3. All returns use `DataProcessResult<T>` (Genie DNA-5)
4. **DNA-1**: Feed items are `Dictionary<string, object>` (or language equivalent), NOT typed models

## Phase 2: Tier Calculator (MACHINE component)
1. `calculateTier(score, config)` — returns "immediate" if score ≥ config.immediateMinScore, "high" if ≥ highMinScore, "normal" if ≥ normalMinScore, else "low"
2. `applyDecay(originalScore, createdAt, halfLifeHours)` — exponential decay: `score × 0.5^(hoursElapsed / halfLife)`
3. Tier boundaries come from config (FREEDOM), but the calculation logic is MACHINE

## Phase 3: Deduplication
1. `computeFingerprint(item)` — SHA-256 hash of "userId:sourceType:sourceId", truncated to 16 hex chars
2. Before ingestion, query for existing fingerprint + userId combo
3. Reject duplicates with descriptive error message

## Phase 4: Ingestion (Core)
1. **IngestItem**: parse via `parseObjectAlternative()`, validate required fields (userId, sourceType, sourceId), generate feedItemId if missing, compute fingerprint, check dedup, calculate tier from score, set timestamps, store in ES, publish FeedItemIngested event
2. **IngestBatch**: iterate items, track success/failure count, return aggregate result
3. **InjectHighPriority**: force tier="immediate", score=100, bypass normal queue

## Phase 5: Retrieval
1. **GetFeed**: BuildSearchFilter with userId (scope isolation) + hidden=false, query ES with pagination, apply decay to each item's currentScore, recalculate tier, sort by tier priority then score descending, return FeedPage with cursor
2. **GetFeedByType**: same as GetFeed but add sourceType to filter
3. **RefreshFeed**: load all items for user, recalculate scores with decay, update tier assignments, store updated docs, publish FeedUpdated event

## Phase 6: Management
1. **MarkSeen**: load item, verify scope (userId match), set seen=true + seenAt timestamp
2. **HideItem**: load item, verify scope, set hidden=true, publish FeedItemHidden event
3. **ExpireItems**: query items with expiresAt < now, delete them, publish FeedItemsExpired
4. **ReorderFeed**: call RefreshFeed, then publish FeedReordered event

## Phase 7: Config (FREEDOM)
1. **GetConfig**: load from feed-config index by scopeId, fall back to FeedConfig defaults
2. **UpdateConfig**: store config as dynamic document with configId, scopeId, updatedAt
3. Config includes: tier thresholds, decay half-life, max feed size — all admin-editable

## Phase 8: Integration
1. Wire into DI container with IDatabaseService, IQueueService, IObjectProcessor
2. Subscribe to events: PostCreated → ingest to followers, EventCreated → ingest to matched users, MatchScoreUpdated → reorder affected feeds, RankingRecalculated → update scores
3. API endpoints: GET /feed/{userId}, GET /feed/{userId}/type/{type}, POST /feed/ingest, PUT /feed/config/{scopeId}

## DNA Compliance Checklist
- [ ] All data stored as `Dictionary<string, object>` (DNA-1)
- [ ] All queries use `BuildSearchFilter` with empty-field skipping (DNA-2)
- [ ] All operations return `DataProcessResult<T>` (DNA-5)
- [ ] userId always included in queries (DNA-SCOPE)
- [ ] Tier thresholds stored as dynamic config documents (DNA-FREEDOM)
- [ ] Events published for all state changes (DNA-7)
- [ ] No typed model classes for feed items

## Test Scenarios
1. Ingest item with score 85 → tier "high", stored in ES, event published
2. Ingest duplicate (same sourceId+userId) → rejected
3. GetFeed → items sorted by tier priority then score
4. Apply decay: item with score 80 after 24h → score ~40
5. HideItem → item no longer appears in feed
6. UpdateConfig → new tier thresholds apply to next GetFeed
7. ExpireItems → removes items past TTL
8. Scope isolation: user A cannot see user B's feed items

## Abstraction Prompt (for AI agents)
> Given a feed service that distributes personalized content using tiered ranking and weight decay,
> extract the following patterns: (1) Content aggregation from multiple source types into a unified
> stream, (2) Score-based tier classification with configurable boundaries, (3) Time-based score
> decay using half-life formula, (4) Content deduplication via fingerprinting, (5) Event-driven
> feed updates on source content changes. These patterns can be applied to any ranked content
> delivery system: news feeds, recommendation engines, notification priority queues, search result
> ranking, or ad placement systems.
