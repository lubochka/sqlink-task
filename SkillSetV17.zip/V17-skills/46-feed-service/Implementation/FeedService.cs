// XIIGen.Services.Feed/FeedService.cs — Skill 46 | .NET 9
// Personalized feed generation with 4-tier ranking, weight decay, deduplication
// Genie DNA: DNA-1 (Dictionary<string,object>), DNA-2 (BuildSearchFilter), DNA-5 (DataProcessResult)

using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using XIIGen.Core.Base;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Services.Feed;

// ─── Configuration ──────────────────────────────────────────────
public class FeedConfig
{
    public string FeedItemsIndex { get; set; } = "feed-items";
    public string FeedConfigIndex { get; set; } = "feed-config";
    public int DefaultPageSize { get; set; } = 20;
    public int MaxFeedSize { get; set; } = 500;
    public double DecayHalfLifeHours { get; set; } = 24.0;
    public string DeduplicationWindow { get; set; } = "7d";
    public double ImmediateMinScore { get; set; } = 90.0;
    public double HighMinScore { get; set; } = 70.0;
    public double NormalMinScore { get; set; } = 40.0;
}

// ─── Feed Page Result ───────────────────────────────────────────
public class FeedPage
{
    public List<Dictionary<string, object>> Items { get; set; } = [];
    public string? Cursor { get; set; }
    public int TotalCount { get; set; }
    public bool HasMore { get; set; }
}

// ─── Tier Calculator ────────────────────────────────────────────
public class TierCalculator
{
    public string CalculateTier(double score, Dictionary<string, object> config)
    {
        var immediateMin = GetDouble(config, "immediateMinScore", 90.0);
        var highMin = GetDouble(config, "highMinScore", 70.0);
        var normalMin = GetDouble(config, "normalMinScore", 40.0);

        return score switch
        {
            _ when score >= immediateMin => "immediate",
            _ when score >= highMin => "high",
            _ when score >= normalMin => "normal",
            _ => "low"
        };
    }

    public double ApplyDecay(double originalScore, DateTime createdAt, double halfLifeHours)
    {
        if (halfLifeHours <= 0) return originalScore;
        var hoursElapsed = (DateTime.UtcNow - createdAt).TotalHours;
        var decayFactor = Math.Pow(0.5, hoursElapsed / halfLifeHours);
        return originalScore * decayFactor;
    }

    private static double GetDouble(Dictionary<string, object> doc, string key, double fallback)
    {
        if (doc.TryGetValue(key, out var val))
        {
            if (val is double d) return d;
            if (val is int i) return i;
            if (val is long l) return l;
            if (val is JsonElement je && je.TryGetDouble(out var jd)) return jd;
            if (double.TryParse(val?.ToString(), out var parsed)) return parsed;
        }
        return fallback;
    }
}

// ─── Deduplication ──────────────────────────────────────────────
public class FeedDeduplicator
{
    public string ComputeFingerprint(Dictionary<string, object> item)
    {
        var sourceType = GetString(item, "sourceType");
        var sourceId = GetString(item, "sourceId");
        var userId = GetString(item, "userId");
        var raw = $"{userId}:{sourceType}:{sourceId}";
        var hash = SHA256.HashData(Encoding.UTF8.GetBytes(raw));
        return Convert.ToHexString(hash)[..16];
    }

    private static string GetString(Dictionary<string, object> doc, string key)
    {
        if (doc.TryGetValue(key, out var val))
        {
            if (val is JsonElement je) return je.GetString() ?? "";
            return val?.ToString() ?? "";
        }
        return "";
    }
}

// ─── Service Interface ──────────────────────────────────────────
public interface IFeedService
{
    // Ingestion
    Task<DataProcessResult<Dictionary<string, object>>> IngestItemAsync(
        Dictionary<string, object> item, CancellationToken ct = default);
    Task<DataProcessResult<int>> IngestBatchAsync(
        List<Dictionary<string, object>> items, string targetType, CancellationToken ct = default);
    Task<DataProcessResult<Dictionary<string, object>>> InjectHighPriorityAsync(
        Dictionary<string, object> item, CancellationToken ct = default);

    // Retrieval
    Task<DataProcessResult<FeedPage>> GetFeedAsync(
        string userId, int page, int pageSize, CancellationToken ct = default);
    Task<DataProcessResult<FeedPage>> GetFeedByTypeAsync(
        string userId, string sourceType, int page, int pageSize, CancellationToken ct = default);
    Task<DataProcessResult<Dictionary<string, object>>> RefreshFeedAsync(
        string userId, CancellationToken ct = default);

    // Management
    Task<DataProcessResult<bool>> MarkSeenAsync(
        string userId, string feedItemId, CancellationToken ct = default);
    Task<DataProcessResult<bool>> HideItemAsync(
        string userId, string feedItemId, CancellationToken ct = default);
    Task<DataProcessResult<int>> ExpireItemsAsync(CancellationToken ct = default);
    Task<DataProcessResult<Dictionary<string, object>>> ReorderFeedAsync(
        string userId, CancellationToken ct = default);

    // Config (FREEDOM)
    Task<DataProcessResult<Dictionary<string, object>>> GetConfigAsync(
        string scopeId, CancellationToken ct = default);
    Task<DataProcessResult<Dictionary<string, object>>> UpdateConfigAsync(
        string scopeId, Dictionary<string, object> config, CancellationToken ct = default);
}

// ─── Service Implementation ─────────────────────────────────────
public class FeedService : IFeedService
{
    private readonly IDatabaseService _db;
    private readonly IQueueService _queue;
    private readonly IObjectProcessor _objectProcessor;
    private readonly ILogger<FeedService> _logger;
    private readonly FeedConfig _config;
    private readonly TierCalculator _tierCalc;
    private readonly FeedDeduplicator _dedup;

    public FeedService(
        IDatabaseService db,
        IQueueService queue,
        IObjectProcessor objectProcessor,
        ILogger<FeedService> logger,
        FeedConfig? config = null)
    {
        _db = db;
        _queue = queue;
        _objectProcessor = objectProcessor;
        _logger = logger;
        _config = config ?? new FeedConfig();
        _tierCalc = new TierCalculator();
        _dedup = new FeedDeduplicator();
    }

    // ─── Ingestion ──────────────────────────────────────────────

    public async Task<DataProcessResult<Dictionary<string, object>>> IngestItemAsync(
        Dictionary<string, object> item, CancellationToken ct = default)
    {
        try
        {
            // DNA-1: Parse as dynamic document
            var doc = _objectProcessor.ParseObjectAlternative(item);

            // Ensure required fields
            if (!doc.ContainsKey("userId") || !doc.ContainsKey("sourceType") || !doc.ContainsKey("sourceId"))
                return DataProcessResult<Dictionary<string, object>>.Error(
                    "Missing required fields: userId, sourceType, sourceId");

            // Generate ID and fingerprint
            if (!doc.ContainsKey("feedItemId"))
                doc["feedItemId"] = Guid.NewGuid().ToString();
            doc["fingerprint"] = _dedup.ComputeFingerprint(doc);

            // Check deduplication
            var existingFilter = _objectProcessor.BuildSearchFilter(new Dictionary<string, object>
            {
                ["fingerprint"] = doc["fingerprint"],
                ["userId"] = doc["userId"]
            });
            var existing = await _db.QueryAsync(_config.FeedItemsIndex, existingFilter, 1, 0, ct);
            if (existing?.Count > 0)
                return DataProcessResult<Dictionary<string, object>>.Error(
                    "Duplicate feed item detected");

            // Calculate score and tier
            var score = GetDouble(doc, "score", 50.0);
            var scopeConfig = await LoadConfigAsync(GetString(doc, "scopeId"), ct);
            doc["tier"] = _tierCalc.CalculateTier(score, scopeConfig);
            doc["originalScore"] = score;
            doc["currentScore"] = score;

            // Set timestamps
            if (!doc.ContainsKey("createdAt"))
                doc["createdAt"] = DateTime.UtcNow.ToString("o");
            if (!doc.ContainsKey("expiresAt"))
                doc["expiresAt"] = DateTime.UtcNow.AddDays(7).ToString("o");
            doc["seen"] = false;
            doc["hidden"] = false;

            // DNA-1: Store as dynamic document
            await _db.UpsertAsync(_config.FeedItemsIndex, doc["feedItemId"].ToString()!, doc, ct);

            // DNA-7: Publish event
            await _queue.PublishAsync("feed-events", new Dictionary<string, object>
            {
                ["eventType"] = "FeedItemIngested",
                ["feedItemId"] = doc["feedItemId"],
                ["userId"] = doc["userId"],
                ["sourceType"] = doc["sourceType"],
                ["tier"] = doc["tier"],
                ["timestamp"] = DateTime.UtcNow.ToString("o")
            }, ct);

            _logger.LogInformation("Feed item {FeedItemId} ingested for user {UserId} at tier {Tier}",
                doc["feedItemId"], doc["userId"], doc["tier"]);

            return DataProcessResult<Dictionary<string, object>>.Success(doc);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "FeedService.IngestItem failed");
            return DataProcessResult<Dictionary<string, object>>.Error(ex.Message);
        }
    }

    public async Task<DataProcessResult<int>> IngestBatchAsync(
        List<Dictionary<string, object>> items, string targetType, CancellationToken ct = default)
    {
        try
        {
            var successCount = 0;
            var errors = new List<string>();

            foreach (var item in items)
            {
                var result = await IngestItemAsync(item, ct);
                if (result.Success)
                    successCount++;
                else
                    errors.Add(result.Message ?? "Unknown error");
            }

            if (successCount == 0 && errors.Count > 0)
                return DataProcessResult<int>.Error($"All {errors.Count} items failed: {errors[0]}");

            _logger.LogInformation("Batch ingested {Success}/{Total} items", successCount, items.Count);
            return DataProcessResult<int>.Success(successCount,
                $"Ingested {successCount}/{items.Count} items" +
                (errors.Count > 0 ? $", {errors.Count} failures" : ""));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "FeedService.IngestBatch failed");
            return DataProcessResult<int>.Error(ex.Message);
        }
    }

    public async Task<DataProcessResult<Dictionary<string, object>>> InjectHighPriorityAsync(
        Dictionary<string, object> item, CancellationToken ct = default)
    {
        try
        {
            var doc = _objectProcessor.ParseObjectAlternative(item);
            doc["tier"] = "immediate";
            doc["score"] = 100.0;
            doc["originalScore"] = 100.0;
            doc["currentScore"] = 100.0;
            doc["highPriority"] = true;

            return await IngestItemAsync(doc, ct);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "FeedService.InjectHighPriority failed");
            return DataProcessResult<Dictionary<string, object>>.Error(ex.Message);
        }
    }

    // ─── Retrieval ──────────────────────────────────────────────

    public async Task<DataProcessResult<FeedPage>> GetFeedAsync(
        string userId, int page, int pageSize, CancellationToken ct = default)
    {
        try
        {
            pageSize = Math.Clamp(pageSize, 1, 100);

            // DNA-2: BuildSearchFilter with scope isolation
            var filter = _objectProcessor.BuildSearchFilter(new Dictionary<string, object>
            {
                ["userId"] = userId,    // DNA-SCOPE: always set
                ["hidden"] = false
            });

            var totalCount = await _db.CountAsync(_config.FeedItemsIndex, filter, ct);
            var items = await _db.QueryAsync(_config.FeedItemsIndex, filter,
                pageSize, page * pageSize, ct);

            // Apply decay to current scores
            var scopeConfig = await LoadConfigAsync("", ct);
            var halfLife = GetDouble(scopeConfig, "decayHalfLifeHours", _config.DecayHalfLifeHours);

            var decayedItems = new List<Dictionary<string, object>>();
            foreach (var item in items ?? [])
            {
                var parsed = _objectProcessor.ParseObjectAlternative(item);
                var originalScore = GetDouble(parsed, "originalScore", 50.0);
                var createdStr = GetString(parsed, "createdAt");
                if (DateTime.TryParse(createdStr, out var createdAt))
                {
                    parsed["currentScore"] = _tierCalc.ApplyDecay(originalScore, createdAt, halfLife);
                    parsed["tier"] = _tierCalc.CalculateTier(
                        (double)parsed["currentScore"], scopeConfig);
                }
                decayedItems.Add(parsed);
            }

            // Sort by tier priority then score
            var tierOrder = new Dictionary<string, int>
            {
                ["immediate"] = 0, ["high"] = 1, ["normal"] = 2, ["low"] = 3
            };
            var sorted = decayedItems
                .OrderBy(i => tierOrder.GetValueOrDefault(GetString(i, "tier"), 4))
                .ThenByDescending(i => GetDouble(i, "currentScore", 0))
                .ToList();

            var feedPage = new FeedPage
            {
                Items = sorted,
                TotalCount = (int)(totalCount ?? 0),
                HasMore = (page + 1) * pageSize < (totalCount ?? 0),
                Cursor = sorted.Count > 0 ? sorted[^1].GetValueOrDefault("feedItemId")?.ToString() : null
            };

            return DataProcessResult<FeedPage>.Success(feedPage);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "FeedService.GetFeed failed for user {UserId}", userId);
            return DataProcessResult<FeedPage>.Error(ex.Message);
        }
    }

    public async Task<DataProcessResult<FeedPage>> GetFeedByTypeAsync(
        string userId, string sourceType, int page, int pageSize, CancellationToken ct = default)
    {
        try
        {
            pageSize = Math.Clamp(pageSize, 1, 100);

            // DNA-2: BuildSearchFilter — sourceType filter added, empty fields skipped
            var filter = _objectProcessor.BuildSearchFilter(new Dictionary<string, object>
            {
                ["userId"] = userId,
                ["sourceType"] = sourceType,   // specific type filter
                ["hidden"] = false
            });

            var items = await _db.QueryAsync(_config.FeedItemsIndex, filter,
                pageSize, page * pageSize, ct);
            var totalCount = await _db.CountAsync(_config.FeedItemsIndex, filter, ct);

            var feedPage = new FeedPage
            {
                Items = (items ?? []).Select(i => _objectProcessor.ParseObjectAlternative(i)).ToList(),
                TotalCount = (int)(totalCount ?? 0),
                HasMore = (page + 1) * pageSize < (totalCount ?? 0)
            };

            return DataProcessResult<FeedPage>.Success(feedPage);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "FeedService.GetFeedByType failed");
            return DataProcessResult<FeedPage>.Error(ex.Message);
        }
    }

    public async Task<DataProcessResult<Dictionary<string, object>>> RefreshFeedAsync(
        string userId, CancellationToken ct = default)
    {
        try
        {
            var filter = _objectProcessor.BuildSearchFilter(new Dictionary<string, object>
            {
                ["userId"] = userId,
                ["hidden"] = false
            });

            var allItems = await _db.QueryAsync(_config.FeedItemsIndex, filter,
                _config.MaxFeedSize, 0, ct);

            var scopeConfig = await LoadConfigAsync("", ct);
            var halfLife = GetDouble(scopeConfig, "decayHalfLifeHours", _config.DecayHalfLifeHours);
            var updatedCount = 0;

            foreach (var item in allItems ?? [])
            {
                var parsed = _objectProcessor.ParseObjectAlternative(item);
                var originalScore = GetDouble(parsed, "originalScore", 50.0);
                var createdStr = GetString(parsed, "createdAt");

                if (DateTime.TryParse(createdStr, out var createdAt))
                {
                    var newScore = _tierCalc.ApplyDecay(originalScore, createdAt, halfLife);
                    var newTier = _tierCalc.CalculateTier(newScore, scopeConfig);

                    parsed["currentScore"] = newScore;
                    parsed["tier"] = newTier;
                    parsed["refreshedAt"] = DateTime.UtcNow.ToString("o");

                    await _db.UpsertAsync(_config.FeedItemsIndex,
                        parsed["feedItemId"]?.ToString() ?? "", parsed, ct);
                    updatedCount++;
                }
            }

            await _queue.PublishAsync("feed-events", new Dictionary<string, object>
            {
                ["eventType"] = "FeedUpdated",
                ["userId"] = userId,
                ["itemsUpdated"] = updatedCount,
                ["timestamp"] = DateTime.UtcNow.ToString("o")
            }, ct);

            return DataProcessResult<Dictionary<string, object>>.Success(
                new Dictionary<string, object>
                {
                    ["userId"] = userId,
                    ["itemsRefreshed"] = updatedCount,
                    ["refreshedAt"] = DateTime.UtcNow.ToString("o")
                });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "FeedService.RefreshFeed failed for user {UserId}", userId);
            return DataProcessResult<Dictionary<string, object>>.Error(ex.Message);
        }
    }

    // ─── Management ─────────────────────────────────────────────

    public async Task<DataProcessResult<bool>> MarkSeenAsync(
        string userId, string feedItemId, CancellationToken ct = default)
    {
        try
        {
            var item = await _db.GetByIdAsync(_config.FeedItemsIndex, feedItemId, ct);
            if (item == null)
                return DataProcessResult<bool>.Error("Feed item not found");

            var parsed = _objectProcessor.ParseObjectAlternative(item);
            if (GetString(parsed, "userId") != userId)
                return DataProcessResult<bool>.Error("Access denied — scope mismatch");

            parsed["seen"] = true;
            parsed["seenAt"] = DateTime.UtcNow.ToString("o");
            await _db.UpsertAsync(_config.FeedItemsIndex, feedItemId, parsed, ct);

            return DataProcessResult<bool>.Success(true);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "FeedService.MarkSeen failed");
            return DataProcessResult<bool>.Error(ex.Message);
        }
    }

    public async Task<DataProcessResult<bool>> HideItemAsync(
        string userId, string feedItemId, CancellationToken ct = default)
    {
        try
        {
            var item = await _db.GetByIdAsync(_config.FeedItemsIndex, feedItemId, ct);
            if (item == null)
                return DataProcessResult<bool>.Error("Feed item not found");

            var parsed = _objectProcessor.ParseObjectAlternative(item);
            if (GetString(parsed, "userId") != userId)
                return DataProcessResult<bool>.Error("Access denied — scope mismatch");

            parsed["hidden"] = true;
            parsed["hiddenAt"] = DateTime.UtcNow.ToString("o");
            await _db.UpsertAsync(_config.FeedItemsIndex, feedItemId, parsed, ct);

            await _queue.PublishAsync("feed-events", new Dictionary<string, object>
            {
                ["eventType"] = "FeedItemHidden",
                ["feedItemId"] = feedItemId,
                ["userId"] = userId,
                ["sourceType"] = GetString(parsed, "sourceType"),
                ["timestamp"] = DateTime.UtcNow.ToString("o")
            }, ct);

            return DataProcessResult<bool>.Success(true);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "FeedService.HideItem failed");
            return DataProcessResult<bool>.Error(ex.Message);
        }
    }

    public async Task<DataProcessResult<int>> ExpireItemsAsync(CancellationToken ct = default)
    {
        try
        {
            var filter = _objectProcessor.BuildSearchFilter(new Dictionary<string, object>
            {
                ["expiresAtBefore"] = DateTime.UtcNow.ToString("o")
            });

            var expired = await _db.QueryAsync(_config.FeedItemsIndex, filter, 1000, 0, ct);
            var count = 0;

            foreach (var item in expired ?? [])
            {
                var parsed = _objectProcessor.ParseObjectAlternative(item);
                var id = GetString(parsed, "feedItemId");
                if (!string.IsNullOrEmpty(id))
                {
                    await _db.DeleteAsync(_config.FeedItemsIndex, id, ct);
                    count++;
                }
            }

            if (count > 0)
            {
                await _queue.PublishAsync("feed-events", new Dictionary<string, object>
                {
                    ["eventType"] = "FeedItemsExpired",
                    ["count"] = count,
                    ["timestamp"] = DateTime.UtcNow.ToString("o")
                }, ct);
            }

            _logger.LogInformation("Expired {Count} feed items", count);
            return DataProcessResult<int>.Success(count);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "FeedService.ExpireItems failed");
            return DataProcessResult<int>.Error(ex.Message);
        }
    }

    public async Task<DataProcessResult<Dictionary<string, object>>> ReorderFeedAsync(
        string userId, CancellationToken ct = default)
    {
        try
        {
            var refreshResult = await RefreshFeedAsync(userId, ct);
            if (!refreshResult.Success)
                return refreshResult;

            await _queue.PublishAsync("feed-events", new Dictionary<string, object>
            {
                ["eventType"] = "FeedReordered",
                ["userId"] = userId,
                ["timestamp"] = DateTime.UtcNow.ToString("o")
            }, ct);

            return refreshResult;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "FeedService.ReorderFeed failed");
            return DataProcessResult<Dictionary<string, object>>.Error(ex.Message);
        }
    }

    // ─── Config (FREEDOM) ───────────────────────────────────────

    public async Task<DataProcessResult<Dictionary<string, object>>> GetConfigAsync(
        string scopeId, CancellationToken ct = default)
    {
        try
        {
            var config = await LoadConfigAsync(scopeId, ct);
            return DataProcessResult<Dictionary<string, object>>.Success(config);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "FeedService.GetConfig failed");
            return DataProcessResult<Dictionary<string, object>>.Error(ex.Message);
        }
    }

    public async Task<DataProcessResult<Dictionary<string, object>>> UpdateConfigAsync(
        string scopeId, Dictionary<string, object> config, CancellationToken ct = default)
    {
        try
        {
            var doc = _objectProcessor.ParseObjectAlternative(config);
            doc["configId"] = $"feed-config-{scopeId}";
            doc["scopeId"] = scopeId;
            doc["updatedAt"] = DateTime.UtcNow.ToString("o");

            await _db.UpsertAsync(_config.FeedConfigIndex, doc["configId"].ToString()!, doc, ct);

            _logger.LogInformation("Feed config updated for scope {ScopeId}", scopeId);
            return DataProcessResult<Dictionary<string, object>>.Success(doc);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "FeedService.UpdateConfig failed");
            return DataProcessResult<Dictionary<string, object>>.Error(ex.Message);
        }
    }

    // ─── Helpers ─────────────────────────────────────────────────

    private async Task<Dictionary<string, object>> LoadConfigAsync(string scopeId, CancellationToken ct)
    {
        try
        {
            var configId = $"feed-config-{scopeId}";
            var config = await _db.GetByIdAsync(_config.FeedConfigIndex, configId, ct);
            if (config != null)
                return _objectProcessor.ParseObjectAlternative(config);
        }
        catch { /* fall through to defaults */ }

        return new Dictionary<string, object>
        {
            ["immediateMinScore"] = _config.ImmediateMinScore,
            ["highMinScore"] = _config.HighMinScore,
            ["normalMinScore"] = _config.NormalMinScore,
            ["decayHalfLifeHours"] = _config.DecayHalfLifeHours,
            ["maxFeedSize"] = _config.MaxFeedSize
        };
    }

    private static double GetDouble(Dictionary<string, object> doc, string key, double fallback)
    {
        if (doc.TryGetValue(key, out var val))
        {
            if (val is double d) return d;
            if (val is int i) return i;
            if (val is long l) return l;
            if (val is JsonElement je && je.TryGetDouble(out var jd)) return jd;
            if (double.TryParse(val?.ToString(), out var parsed)) return parsed;
        }
        return fallback;
    }

    private static string GetString(Dictionary<string, object> doc, string key)
    {
        if (doc.TryGetValue(key, out var val))
        {
            if (val is JsonElement je) return je.GetString() ?? "";
            return val?.ToString() ?? "";
        }
        return "";
    }
}

// ─── DI Registration ────────────────────────────────────────────
public static class FeedServiceExtensions
{
    public static IServiceCollection AddXIIGenFeedService(
        this IServiceCollection services, Action<FeedConfig>? configure = null)
    {
        var config = new FeedConfig();
        configure?.Invoke(config);
        services.AddSingleton(config);
        services.AddSingleton<TierCalculator>();
        services.AddSingleton<FeedDeduplicator>();
        services.AddSingleton<IFeedService, FeedService>();
        return services;
    }
}
