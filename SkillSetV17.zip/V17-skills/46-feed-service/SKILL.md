---
skill_id: "46"
name: "feed-service"
title: "Feed Service"
layer: "L9: Social Engine"
version: "17.0"
status: "active"
dependencies:
  - "01-core-interfaces"
  - "02-object-processor"
  - "03-elasticsearch-datastore"
  - "04-redis-queue-service"
  - "43-calculator-metrics"
dotnet_namespace: "XIIGen.Services.Feed"
di_registration: "services.AddXIIGenFeedService()"
es_indices:
  - "feed-items"
  - "feed-config"
genie_dna:
  - "DNA-1: Feed items as Dictionary<string,object> — any content type (post, event, ad, recommendation)"
  - "DNA-2: BuildSearchFilter for feed queries — userId, type, priority, dateRange — skip empty"
  - "DNA-3: Inherits MicroserviceBase with all 19 architectural components"
  - "DNA-5: All operations return DataProcessResult<T>"
  - "DNA-SCOPE: Users see ONLY their own feed; admins see all; moderators see flagged"
  - "DNA-FREEDOM: Tier thresholds, weight formulas, and decay rates are dynamic documents — admins configure without code changes"
  - "DNA-7: Event-driven — publishes FeedUpdated, FeedReordered, FeedItemExpired; subscribes to PostCreated, EventCreated, MatchScoreUpdated"
component_classification:
  machine_parts:
    - "4-tier distribution engine (immediate/high/normal/low)"
    - "Weight decay calculation (time-based score reduction)"
    - "Feed deduplication (content fingerprinting)"
  freedom_parts:
    - "Tier thresholds (admin-configurable boundaries)"
    - "Weight formulas (admin-defined scoring expressions)"
    - "Content type priorities (admin-managed ranking rules)"
    - "Decay rate curves (admin-tunable half-life parameters)"
---

# Skill 46: Feed Service

## Purpose
Generates and manages personalized content feeds for users across the XIIGen social platform.
The Feed Service aggregates content from multiple sources (posts, events, recommendations,
ads), applies tiered ranking based on composite scores from the Ranking Engine (Skill 54),
and delivers paginated feeds with real-time updates. It is the most-referenced service across
all 8 UML diagrams (appears in 7 of 8), making it the central distribution hub of the platform.

## Architecture

```
┌──────────────┐     ┌────────────────────┐     ┌─────────────────┐
│ Post Service │────▶│                    │     │  Elasticsearch  │
│ (Skill 52)   │     │   Feed Service     │────▶│  "feed-items"   │
├──────────────┤     │                    │     └─────────────────┘
│ Event Mgmt   │────▶│  ┌──────────────┐  │            │
│ (Skill 53)   │     │  │ Ingest       │  │◀───────────┘
├──────────────┤     │  │ Rank         │  │     ┌─────────────────┐
│ Matching     │────▶│  │ Distribute   │  │────▶│  Redis Cache    │
│ (Skill 47)   │     │  │ Expire       │  │     │  hot feeds      │
├──────────────┤     │  │ Reorder      │  │     └─────────────────┘
│ Ranking Eng  │────▶│  └──────────────┘  │            │
│ (Skill 54)   │     │                    │     ┌──────▼──────────┐
└──────────────┘     └────────────────────┘     │  Event Bus      │
                              │                 │  FeedUpdated    │
                     ┌────────▼────────┐        │  FeedReordered  │
                     │  Feed Config    │        └─────────────────┘
                     │  (dynamic docs) │
                     │  tier thresholds│
                     │  weight formulas│
                     │  decay curves   │
                     └─────────────────┘
```

## Key Concepts

- **4-Tier Distribution** — Content enters the feed at one of four priority tiers: Immediate (score ≥ 90, shown first), High (70-89, top section), Normal (40-69, main scroll), Low (< 40, bottom/discoverable). Tier boundaries are FREEDOM components — admins adjust without code.
- **Weight Decay** — Feed items lose positional weight over time using configurable half-life curves. A post with score 85 at T=0 might decay to 60 after 24 hours. Decay formula is a dynamic document.
- **Content Deduplication** — Prevents the same content from appearing multiple times via fingerprinting (content hash + source ID).
- **Real-Time Injection** — When a high-priority event occurs (e.g., friend's post, matched event), it is injected into active feed sessions via queue notification.
- **Feed Snapshot** — Each feed request returns a point-in-time snapshot with cursor for pagination, ensuring consistent scrolling even as new items arrive.

## Core Operations

### 1. Feed Ingestion
| Method | Description | Returns |
|--------|-------------|---------|
| `IngestItemAsync` | Add a single item to target user feeds | DataProcessResult<Dictionary> |
| `IngestBatchAsync` | Fan-out content to multiple user feeds | DataProcessResult<int> (count) |
| `InjectHighPriorityAsync` | Bypass normal queue for immediate items | DataProcessResult<Dictionary> |

### 2. Feed Retrieval
| Method | Description | Returns |
|--------|-------------|---------|
| `GetFeedAsync` | Paginated feed for a user with tier ordering | DataProcessResult<FeedPage> |
| `GetFeedByTypeAsync` | Filtered feed (only posts, only events, etc.) | DataProcessResult<FeedPage> |
| `RefreshFeedAsync` | Recalculate scores and reorder | DataProcessResult<Dictionary> |

### 3. Feed Management
| Method | Description | Returns |
|--------|-------------|---------|
| `MarkSeenAsync` | Track which items user has viewed | DataProcessResult<bool> |
| `HideItemAsync` | User hides an item (affects future ranking) | DataProcessResult<bool> |
| `ExpireItemsAsync` | Remove items past their TTL | DataProcessResult<int> |
| `ReorderFeedAsync` | Apply updated weights/rankings | DataProcessResult<Dictionary> |

### 4. Configuration (FREEDOM)
| Method | Description | Returns |
|--------|-------------|---------|
| `GetConfigAsync` | Retrieve current feed config | DataProcessResult<Dictionary> |
| `UpdateConfigAsync` | Admin updates tier thresholds, weights, decay | DataProcessResult<Dictionary> |

## DNA Integration

### DNA-1: Dynamic Documents
Feed items are `Dictionary<string, object>` — any content type with any metadata:
```csharp
var feedItem = ObjectProcessor.ParseObjectAlternative(new {
    feedItemId = Guid.NewGuid().ToString(),
    userId = targetUserId,
    sourceType = "post",          // or "event", "ad", "recommendation"
    sourceId = postId,
    score = 85.5,
    tier = "high",
    metadata = new { authorName, thumbnail, preview },
    createdAt = DateTime.UtcNow,
    expiresAt = DateTime.UtcNow.AddDays(7)
});
await _db.UpsertAsync("feed-items", feedItem["feedItemId"].ToString(), feedItem);
```

### DNA-2: BuildSearchFilter
All feed queries use empty-field skipping:
```csharp
var filter = ObjectProcessor.BuildSearchFilter(new {
    userId = currentUserId,     // always set (scope isolation)
    sourceType = typeFilter,    // null if "all types" → skipped
    tier = tierFilter,          // null if "all tiers" → skipped
    minScore = minScore         // 0 → skipped
});
```

### DNA-5: DataProcessResult
Every operation returns success/failure with data:
```csharp
public async Task<DataProcessResult<Dictionary<string, object>>> IngestItemAsync(
    Dictionary<string, object> item, CancellationToken ct)
{
    try {
        // validate, score, store
        return DataProcessResult<Dictionary<string, object>>.Success(stored);
    } catch (Exception ex) {
        return DataProcessResult<Dictionary<string, object>>.Error(ex.Message);
    }
}
```

### DNA-SCOPE: Scope Isolation
Feed queries ALWAYS include userId. Admin endpoints check role before allowing cross-user access.

### DNA-FREEDOM: Dynamic Configuration
Tier thresholds stored as dynamic documents in "feed-config" index:
```json
{
  "configId": "tier-thresholds",
  "scopeId": "tenant-123",
  "immediate": { "minScore": 90 },
  "high": { "minScore": 70 },
  "normal": { "minScore": 40 },
  "low": { "minScore": 0 },
  "decayHalfLifeHours": 24,
  "maxFeedSize": 500,
  "deduplicationWindow": "7d"
}
```

## Events

### Published
- `FeedItemIngested` — new item added to feeds
- `FeedUpdated` — feed recalculated for a user
- `FeedReordered` — weights changed, feed reordered
- `FeedItemExpired` — item removed due to TTL
- `FeedItemHidden` — user explicitly hid an item

### Subscribed
- `PostCreated` (from Skill 52) → ingest into followers' feeds
- `EventCreated` (from Skill 53) → ingest into matched users' feeds
- `MatchScoreUpdated` (from Skill 47) → reorder affected feeds
- `RankingRecalculated` (from Skill 54) → update item scores

## Anti-Patterns

```csharp
// ❌ BAD: Fixed model class
public class FeedItem { public string PostId; public string UserId; public DateTime Created; }

// ❌ BAD: No tier system, just chronological
return items.OrderByDescending(i => i.Created).ToList();

// ❌ BAD: Hardcoded thresholds
if (score > 90) tier = "immediate"; // Should be dynamic config

// ❌ BAD: No scope isolation
var allItems = await _db.QueryAsync("feed-items", new {}); // Returns ALL users' feeds!
```

## Test Scenarios

1. **Ingest + Retrieve**: Ingest 10 items with varying scores → GetFeed returns them ordered by tier then score
2. **Deduplication**: Ingest same sourceId twice → second is rejected or merged
3. **Weight Decay**: Ingest item with score 80, advance time 24h → score should be ~40 (half-life)
4. **Scope Isolation**: User A's feed request never returns User B's items
5. **High Priority Injection**: InjectHighPriority places item at top regardless of normal score
6. **Config Update**: Admin changes tier threshold → next GetFeed uses new boundaries
7. **Expiration**: Items past TTL are removed by ExpireItemsAsync
8. **Pagination**: GetFeed with cursor returns consistent pages even with new ingestions
