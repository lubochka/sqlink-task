// XIIGen Feed Service — Skill 46 | Java/Spring Boot Alternative
// Personalized feed generation with 4-tier ranking, weight decay, deduplication
// Genie DNA: DNA-1 (Map<String,Object>), DNA-2 (buildSearchFilter), DNA-5 (DataProcessResult)

package com.xiigen.services.feed;

import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

// ─── Configuration ──────────────────────────────────────────────
record FeedConfig(
    String feedItemsIndex,
    String feedConfigIndex,
    int defaultPageSize,
    int maxFeedSize,
    double decayHalfLifeHours,
    double immediateMinScore,
    double highMinScore,
    double normalMinScore
) {
    static FeedConfig defaults() {
        return new FeedConfig("feed-items", "feed-config", 20, 500, 24.0, 90.0, 70.0, 40.0);
    }
}

record FeedPage(
    List<Map<String, Object>> items,
    String cursor,
    int totalCount,
    boolean hasMore
) {}

record DataProcessResult<T>(boolean success, T data, String message) {
    static <T> DataProcessResult<T> ok(T data) { return new DataProcessResult<>(true, data, ""); }
    static <T> DataProcessResult<T> ok(T data, String msg) { return new DataProcessResult<>(true, data, msg); }
    static <T> DataProcessResult<T> error(String msg) { return new DataProcessResult<>(false, null, msg); }
}

// ─── Interfaces (Genie DNA) ────────────────────────────────────
interface IDatabaseService {
    void upsert(String index, String id, Map<String, Object> doc);
    Map<String, Object> getById(String index, String id);
    List<Map<String, Object>> query(String index, Map<String, Object> filter, int limit, int offset);
    long count(String index, Map<String, Object> filter);
    void delete(String index, String id);
}

interface IQueueService {
    void publish(String channel, Map<String, Object> message);
}

interface IObjectProcessor {
    Map<String, Object> parseObjectAlternative(Object obj);
    Map<String, Object> buildSearchFilter(Map<String, Object> filter);
}

// ─── Tier Calculator ────────────────────────────────────────────
class TierCalculator {
    String calculateTier(double score, Map<String, Object> config) {
        double immediateMin = getDouble(config, "immediateMinScore", 90.0);
        double highMin = getDouble(config, "highMinScore", 70.0);
        double normalMin = getDouble(config, "normalMinScore", 40.0);

        if (score >= immediateMin) return "immediate";
        if (score >= highMin) return "high";
        if (score >= normalMin) return "normal";
        return "low";
    }

    double applyDecay(double originalScore, Instant createdAt, double halfLifeHours) {
        if (halfLifeHours <= 0) return originalScore;
        double hoursElapsed = Duration.between(createdAt, Instant.now()).toMillis() / 3_600_000.0;
        double decayFactor = Math.pow(0.5, hoursElapsed / halfLifeHours);
        return originalScore * decayFactor;
    }

    private double getDouble(Map<String, Object> m, String key, double fallback) {
        Object v = m.get(key);
        if (v instanceof Number n) return n.doubleValue();
        if (v != null) { try { return Double.parseDouble(v.toString()); } catch (Exception e) { /* ignore */ } }
        return fallback;
    }
}

// ─── Deduplication ──────────────────────────────────────────────
class FeedDeduplicator {
    String computeFingerprint(Map<String, Object> item) {
        String raw = getString(item, "userId") + ":" + getString(item, "sourceType") + ":" + getString(item, "sourceId");
        try {
            byte[] hash = MessageDigest.getInstance("SHA-256").digest(raw.getBytes(StandardCharsets.UTF_8));
            StringBuilder hex = new StringBuilder();
            for (int i = 0; i < 8; i++) hex.append(String.format("%02x", hash[i]));
            return hex.toString();
        } catch (Exception e) { return raw.hashCode() + ""; }
    }

    private String getString(Map<String, Object> m, String key) {
        Object v = m.get(key);
        return v != null ? v.toString() : "";
    }
}

// ─── Service Interface ──────────────────────────────────────────
interface IFeedService {
    DataProcessResult<Map<String, Object>> ingestItem(Map<String, Object> item);
    DataProcessResult<Integer> ingestBatch(List<Map<String, Object>> items, String targetType);
    DataProcessResult<Map<String, Object>> injectHighPriority(Map<String, Object> item);

    DataProcessResult<FeedPage> getFeed(String userId, int page, int pageSize);
    DataProcessResult<FeedPage> getFeedByType(String userId, String sourceType, int page, int pageSize);
    DataProcessResult<Map<String, Object>> refreshFeed(String userId);

    DataProcessResult<Boolean> markSeen(String userId, String feedItemId);
    DataProcessResult<Boolean> hideItem(String userId, String feedItemId);
    DataProcessResult<Integer> expireItems();
    DataProcessResult<Map<String, Object>> reorderFeed(String userId);

    DataProcessResult<Map<String, Object>> getConfig(String scopeId);
    DataProcessResult<Map<String, Object>> updateConfig(String scopeId, Map<String, Object> config);
}

// ─── Service Implementation ─────────────────────────────────────
@Service
public class FeedService implements IFeedService {
    private static final Logger log = LoggerFactory.getLogger(FeedService.class);

    private final IDatabaseService db;
    private final IQueueService queue;
    private final IObjectProcessor objectProcessor;
    private final FeedConfig config;
    private final TierCalculator tierCalc = new TierCalculator();
    private final FeedDeduplicator dedup = new FeedDeduplicator();

    public FeedService(IDatabaseService db, IQueueService queue, IObjectProcessor objectProcessor) {
        this(db, queue, objectProcessor, FeedConfig.defaults());
    }

    public FeedService(IDatabaseService db, IQueueService queue, IObjectProcessor objectProcessor, FeedConfig config) {
        this.db = db;
        this.queue = queue;
        this.objectProcessor = objectProcessor;
        this.config = config;
    }

    // ─── Ingestion ──────────────────────────────────────────────

    @Override
    public DataProcessResult<Map<String, Object>> ingestItem(Map<String, Object> item) {
        try {
            Map<String, Object> doc = objectProcessor.parseObjectAlternative(item);

            if (!hasValue(doc, "userId") || !hasValue(doc, "sourceType") || !hasValue(doc, "sourceId"))
                return DataProcessResult.error("Missing required fields: userId, sourceType, sourceId");

            doc.putIfAbsent("feedItemId", UUID.randomUUID().toString());
            doc.put("fingerprint", dedup.computeFingerprint(doc));

            // Deduplication — DNA-2
            var dupFilter = objectProcessor.buildSearchFilter(Map.of(
                "fingerprint", doc.get("fingerprint"),
                "userId", doc.get("userId")
            ));
            var existing = db.query(config.feedItemsIndex(), dupFilter, 1, 0);
            if (existing != null && !existing.isEmpty())
                return DataProcessResult.error("Duplicate feed item detected");

            double score = getDouble(doc, "score", 50.0);
            var scopeConfig = loadConfig(getString(doc, "scopeId"));
            doc.put("tier", tierCalc.calculateTier(score, scopeConfig));
            doc.put("originalScore", score);
            doc.put("currentScore", score);
            doc.putIfAbsent("createdAt", Instant.now().toString());
            doc.putIfAbsent("expiresAt", Instant.now().plus(Duration.ofDays(7)).toString());
            doc.put("seen", false);
            doc.put("hidden", false);

            db.upsert(config.feedItemsIndex(), doc.get("feedItemId").toString(), doc);

            queue.publish("feed-events", Map.of(
                "eventType", "FeedItemIngested",
                "feedItemId", doc.get("feedItemId"),
                "userId", doc.get("userId"),
                "sourceType", doc.get("sourceType"),
                "tier", doc.get("tier"),
                "timestamp", Instant.now().toString()
            ));

            log.info("Feed item {} ingested for user {} at tier {}",
                doc.get("feedItemId"), doc.get("userId"), doc.get("tier"));
            return DataProcessResult.ok(doc, "Feed item ingested");
        } catch (Exception e) {
            log.error("FeedService.ingestItem failed", e);
            return DataProcessResult.error(e.getMessage());
        }
    }

    @Override
    public DataProcessResult<Integer> ingestBatch(List<Map<String, Object>> items, String targetType) {
        try {
            int successCount = 0;
            List<String> errors = new ArrayList<>();
            for (var item : items) {
                var result = ingestItem(item);
                if (result.success()) successCount++;
                else errors.add(result.message());
            }
            if (successCount == 0 && !errors.isEmpty())
                return DataProcessResult.error("All " + errors.size() + " items failed: " + errors.get(0));
            String msg = "Ingested " + successCount + "/" + items.size();
            if (!errors.isEmpty()) msg += ", " + errors.size() + " failures";
            return DataProcessResult.ok(successCount, msg);
        } catch (Exception e) {
            return DataProcessResult.error(e.getMessage());
        }
    }

    @Override
    public DataProcessResult<Map<String, Object>> injectHighPriority(Map<String, Object> item) {
        var doc = objectProcessor.parseObjectAlternative(item);
        doc.put("tier", "immediate");
        doc.put("score", 100.0);
        doc.put("originalScore", 100.0);
        doc.put("currentScore", 100.0);
        doc.put("highPriority", true);
        return ingestItem(doc);
    }

    // ─── Retrieval ──────────────────────────────────────────────

    @Override
    public DataProcessResult<FeedPage> getFeed(String userId, int page, int pageSize) {
        try {
            pageSize = Math.max(1, Math.min(pageSize, 100));
            var filter = objectProcessor.buildSearchFilter(Map.of("userId", userId, "hidden", false));
            long totalCount = db.count(config.feedItemsIndex(), filter);
            var items = db.query(config.feedItemsIndex(), filter, pageSize, page * pageSize);

            var scopeConfig = loadConfig("");
            double halfLife = getDouble(scopeConfig, "decayHalfLifeHours", config.decayHalfLifeHours());

            var tierOrder = Map.of("immediate", 0, "high", 1, "normal", 2, "low", 3);

            var sorted = (items != null ? items : List.<Map<String, Object>>of()).stream()
                .map(i -> {
                    var parsed = objectProcessor.parseObjectAlternative(i);
                    double orig = getDouble(parsed, "originalScore", 50.0);
                    try {
                        var created = Instant.parse(getString(parsed, "createdAt"));
                        parsed.put("currentScore", tierCalc.applyDecay(orig, created, halfLife));
                        parsed.put("tier", tierCalc.calculateTier((double) parsed.get("currentScore"), scopeConfig));
                    } catch (Exception ignored) {}
                    return parsed;
                })
                .sorted(Comparator
                    .<Map<String, Object>, Integer>comparing(m -> tierOrder.getOrDefault(getString(m, "tier"), 4))
                    .thenComparing(m -> -getDouble(m, "currentScore", 0)))
                .collect(Collectors.toList());

            String cursor = sorted.isEmpty() ? null : getString(sorted.get(sorted.size() - 1), "feedItemId");
            return DataProcessResult.ok(new FeedPage(sorted, cursor, (int) totalCount, (page + 1) * pageSize < totalCount));
        } catch (Exception e) {
            log.error("FeedService.getFeed failed for user {}", userId, e);
            return DataProcessResult.error(e.getMessage());
        }
    }

    @Override
    public DataProcessResult<FeedPage> getFeedByType(String userId, String sourceType, int page, int pageSize) {
        try {
            pageSize = Math.max(1, Math.min(pageSize, 100));
            var filter = objectProcessor.buildSearchFilter(Map.of("userId", userId, "sourceType", sourceType, "hidden", false));
            var items = db.query(config.feedItemsIndex(), filter, pageSize, page * pageSize);
            long totalCount = db.count(config.feedItemsIndex(), filter);
            var mapped = (items != null ? items : List.<Map<String, Object>>of()).stream()
                .map(objectProcessor::parseObjectAlternative).collect(Collectors.toList());
            return DataProcessResult.ok(new FeedPage(mapped, null, (int) totalCount, (page + 1) * pageSize < totalCount));
        } catch (Exception e) {
            return DataProcessResult.error(e.getMessage());
        }
    }

    @Override
    public DataProcessResult<Map<String, Object>> refreshFeed(String userId) {
        try {
            var filter = objectProcessor.buildSearchFilter(Map.of("userId", userId, "hidden", false));
            var all = db.query(config.feedItemsIndex(), filter, config.maxFeedSize(), 0);
            var scopeConfig = loadConfig("");
            double halfLife = getDouble(scopeConfig, "decayHalfLifeHours", config.decayHalfLifeHours());
            int updated = 0;

            for (var item : all != null ? all : List.<Map<String, Object>>of()) {
                var parsed = objectProcessor.parseObjectAlternative(item);
                try {
                    double orig = getDouble(parsed, "originalScore", 50.0);
                    var created = Instant.parse(getString(parsed, "createdAt"));
                    parsed.put("currentScore", tierCalc.applyDecay(orig, created, halfLife));
                    parsed.put("tier", tierCalc.calculateTier((double) parsed.get("currentScore"), scopeConfig));
                    parsed.put("refreshedAt", Instant.now().toString());
                    db.upsert(config.feedItemsIndex(), getString(parsed, "feedItemId"), parsed);
                    updated++;
                } catch (Exception ignored) {}
            }

            queue.publish("feed-events", Map.of(
                "eventType", "FeedUpdated", "userId", userId,
                "itemsUpdated", updated, "timestamp", Instant.now().toString()));
            return DataProcessResult.ok(Map.of("userId", userId, "itemsRefreshed", updated));
        } catch (Exception e) {
            return DataProcessResult.error(e.getMessage());
        }
    }

    // ─── Management ─────────────────────────────────────────────

    @Override
    public DataProcessResult<Boolean> markSeen(String userId, String feedItemId) {
        try {
            var item = db.getById(config.feedItemsIndex(), feedItemId);
            if (item == null) return DataProcessResult.error("Feed item not found");
            var parsed = objectProcessor.parseObjectAlternative(item);
            if (!userId.equals(getString(parsed, "userId"))) return DataProcessResult.error("Access denied — scope mismatch");
            parsed.put("seen", true);
            parsed.put("seenAt", Instant.now().toString());
            db.upsert(config.feedItemsIndex(), feedItemId, parsed);
            return DataProcessResult.ok(true, "Marked as seen");
        } catch (Exception e) {
            return DataProcessResult.error(e.getMessage());
        }
    }

    @Override
    public DataProcessResult<Boolean> hideItem(String userId, String feedItemId) {
        try {
            var item = db.getById(config.feedItemsIndex(), feedItemId);
            if (item == null) return DataProcessResult.error("Feed item not found");
            var parsed = objectProcessor.parseObjectAlternative(item);
            if (!userId.equals(getString(parsed, "userId"))) return DataProcessResult.error("Access denied — scope mismatch");
            parsed.put("hidden", true);
            parsed.put("hiddenAt", Instant.now().toString());
            db.upsert(config.feedItemsIndex(), feedItemId, parsed);
            queue.publish("feed-events", Map.of(
                "eventType", "FeedItemHidden", "feedItemId", feedItemId,
                "userId", userId, "timestamp", Instant.now().toString()));
            return DataProcessResult.ok(true, "Item hidden");
        } catch (Exception e) {
            return DataProcessResult.error(e.getMessage());
        }
    }

    @Override
    public DataProcessResult<Integer> expireItems() {
        try {
            var filter = objectProcessor.buildSearchFilter(Map.of("expiresAtBefore", Instant.now().toString()));
            var expired = db.query(config.feedItemsIndex(), filter, 1000, 0);
            int count = 0;
            for (var item : expired != null ? expired : List.<Map<String, Object>>of()) {
                var parsed = objectProcessor.parseObjectAlternative(item);
                String id = getString(parsed, "feedItemId");
                if (!id.isEmpty()) { db.delete(config.feedItemsIndex(), id); count++; }
            }
            if (count > 0)
                queue.publish("feed-events", Map.of("eventType", "FeedItemsExpired", "count", count, "timestamp", Instant.now().toString()));
            return DataProcessResult.ok(count, "Expired " + count + " items");
        } catch (Exception e) {
            return DataProcessResult.error(e.getMessage());
        }
    }

    @Override
    public DataProcessResult<Map<String, Object>> reorderFeed(String userId) {
        var result = refreshFeed(userId);
        if (result.success())
            queue.publish("feed-events", Map.of("eventType", "FeedReordered", "userId", userId, "timestamp", Instant.now().toString()));
        return result;
    }

    @Override
    public DataProcessResult<Map<String, Object>> getConfig(String scopeId) {
        return DataProcessResult.ok(loadConfig(scopeId));
    }

    @Override
    public DataProcessResult<Map<String, Object>> updateConfig(String scopeId, Map<String, Object> cfg) {
        try {
            var doc = objectProcessor.parseObjectAlternative(cfg);
            doc.put("configId", "feed-config-" + scopeId);
            doc.put("scopeId", scopeId);
            doc.put("updatedAt", Instant.now().toString());
            db.upsert(config.feedConfigIndex(), doc.get("configId").toString(), doc);
            return DataProcessResult.ok(doc, "Config updated");
        } catch (Exception e) {
            return DataProcessResult.error(e.getMessage());
        }
    }

    // ─── Helpers ────────────────────────────────────────────────

    private Map<String, Object> loadConfig(String scopeId) {
        try {
            var c = db.getById(config.feedConfigIndex(), "feed-config-" + scopeId);
            if (c != null) return objectProcessor.parseObjectAlternative(c);
        } catch (Exception ignored) {}
        return new HashMap<>(Map.of(
            "immediateMinScore", config.immediateMinScore(),
            "highMinScore", config.highMinScore(),
            "normalMinScore", config.normalMinScore(),
            "decayHalfLifeHours", config.decayHalfLifeHours(),
            "maxFeedSize", config.maxFeedSize()));
    }

    private boolean hasValue(Map<String, Object> m, String key) {
        Object v = m.get(key);
        return v != null && !v.toString().isBlank();
    }

    private double getDouble(Map<String, Object> m, String key, double fallback) {
        Object v = m.get(key);
        if (v instanceof Number n) return n.doubleValue();
        if (v != null) try { return Double.parseDouble(v.toString()); } catch (Exception e) { /* ignore */ }
        return fallback;
    }

    private String getString(Map<String, Object> m, String key) {
        Object v = m.get(key);
        return v != null ? v.toString() : "";
    }
}
