// XIIGen Feed Service — Skill 46 | Rust/Axum Alternative
// Personalized feed generation with 4-tier ranking, weight decay, deduplication
// Genie DNA: DNA-1 (HashMap<String,Value>), DNA-2 (build_search_filter), DNA-5 (DataProcessResult)

use async_trait::async_trait;
use chrono::{DateTime, Duration, Utc};
use serde::{Deserialize, Serialize};
use serde_json::Value;
use sha2::{Digest, Sha256};
use std::collections::HashMap;
use tracing::{error, info};
use uuid::Uuid;

// ─── Configuration ──────────────────────────────────────────────
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct FeedConfig {
    pub feed_items_index: String,
    pub feed_config_index: String,
    pub default_page_size: usize,
    pub max_feed_size: usize,
    pub decay_half_life_hours: f64,
    pub immediate_min_score: f64,
    pub high_min_score: f64,
    pub normal_min_score: f64,
}

impl Default for FeedConfig {
    fn default() -> Self {
        Self {
            feed_items_index: "feed-items".into(),
            feed_config_index: "feed-config".into(),
            default_page_size: 20,
            max_feed_size: 500,
            decay_half_life_hours: 24.0,
            immediate_min_score: 90.0,
            high_min_score: 70.0,
            normal_min_score: 40.0,
        }
    }
}

type FeedDoc = HashMap<String, Value>;

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct FeedPage {
    pub items: Vec<FeedDoc>,
    pub cursor: Option<String>,
    pub total_count: usize,
    pub has_more: bool,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct DataProcessResult<T: Serialize> {
    pub success: bool,
    pub data: Option<T>,
    pub message: String,
}

impl<T: Serialize> DataProcessResult<T> {
    pub fn ok(data: T, msg: &str) -> Self {
        Self { success: true, data: Some(data), message: msg.to_string() }
    }
    pub fn error(msg: &str) -> Self {
        Self { success: false, data: None, message: msg.to_string() }
    }
}

// ─── Traits (Genie DNA Interfaces) ─────────────────────────────
#[async_trait]
pub trait IDatabaseService: Send + Sync {
    async fn upsert(&self, index: &str, id: &str, doc: &FeedDoc) -> anyhow::Result<()>;
    async fn get_by_id(&self, index: &str, id: &str) -> anyhow::Result<Option<FeedDoc>>;
    async fn query(&self, index: &str, filter: &FeedDoc, limit: usize, offset: usize) -> anyhow::Result<Vec<FeedDoc>>;
    async fn count(&self, index: &str, filter: &FeedDoc) -> anyhow::Result<usize>;
    async fn delete(&self, index: &str, id: &str) -> anyhow::Result<()>;
}

#[async_trait]
pub trait IQueueService: Send + Sync {
    async fn publish(&self, channel: &str, message: &FeedDoc) -> anyhow::Result<()>;
}

pub trait IObjectProcessor: Send + Sync {
    fn parse_object_alternative(&self, obj: &Value) -> FeedDoc;
    fn build_search_filter(&self, filter: &FeedDoc) -> FeedDoc;
}

// ─── Tier Calculator ────────────────────────────────────────────
pub struct TierCalculator;

impl TierCalculator {
    pub fn calculate_tier(score: f64, config: &FeedDoc) -> String {
        let immediate = get_f64(config, "immediateMinScore", 90.0);
        let high = get_f64(config, "highMinScore", 70.0);
        let normal = get_f64(config, "normalMinScore", 40.0);

        if score >= immediate { "immediate".into() }
        else if score >= high { "high".into() }
        else if score >= normal { "normal".into() }
        else { "low".into() }
    }

    pub fn apply_decay(original_score: f64, created_at: DateTime<Utc>, half_life_hours: f64) -> f64 {
        if half_life_hours <= 0.0 { return original_score; }
        let hours_elapsed = (Utc::now() - created_at).num_milliseconds() as f64 / 3_600_000.0;
        let decay_factor = (0.5_f64).powf(hours_elapsed / half_life_hours);
        original_score * decay_factor
    }
}

// ─── Deduplication ──────────────────────────────────────────────
pub struct FeedDeduplicator;

impl FeedDeduplicator {
    pub fn compute_fingerprint(item: &FeedDoc) -> String {
        let raw = format!(
            "{}:{}:{}",
            get_str(item, "userId"),
            get_str(item, "sourceType"),
            get_str(item, "sourceId"),
        );
        let hash = Sha256::digest(raw.as_bytes());
        hex::encode(&hash[..8])
    }
}

// ─── Service Implementation ─────────────────────────────────────
pub struct FeedService {
    db: Box<dyn IDatabaseService>,
    queue: Box<dyn IQueueService>,
    op: Box<dyn IObjectProcessor>,
    config: FeedConfig,
}

impl FeedService {
    pub fn new(
        db: Box<dyn IDatabaseService>,
        queue: Box<dyn IQueueService>,
        op: Box<dyn IObjectProcessor>,
        config: Option<FeedConfig>,
    ) -> Self {
        Self { db, queue, op, config: config.unwrap_or_default() }
    }

    // ─── Ingestion ──────────────────────────────────────────────

    pub async fn ingest_item(&self, item: &Value) -> DataProcessResult<FeedDoc> {
        let mut doc = self.op.parse_object_alternative(item);

        if get_str(&doc, "userId").is_empty()
            || get_str(&doc, "sourceType").is_empty()
            || get_str(&doc, "sourceId").is_empty()
        {
            return DataProcessResult::error("Missing required fields: userId, sourceType, sourceId");
        }

        if !doc.contains_key("feedItemId") {
            doc.insert("feedItemId".into(), Value::String(Uuid::new_v4().to_string()));
        }
        let fp = FeedDeduplicator::compute_fingerprint(&doc);
        doc.insert("fingerprint".into(), Value::String(fp.clone()));

        // Deduplication — DNA-2
        let mut dup_filter = HashMap::new();
        dup_filter.insert("fingerprint".into(), Value::String(fp));
        dup_filter.insert("userId".into(), doc.get("userId").cloned().unwrap_or_default());
        let dup_filter = self.op.build_search_filter(&dup_filter);

        match self.db.query(&self.config.feed_items_index, &dup_filter, 1, 0).await {
            Ok(existing) if !existing.is_empty() =>
                return DataProcessResult::error("Duplicate feed item detected"),
            Err(e) => { error!("Dedup check failed: {}", e); }
            _ => {}
        }

        let score = get_f64(&doc, "score", 50.0);
        let scope_config = self.load_config(&get_str(&doc, "scopeId")).await;
        let tier = TierCalculator::calculate_tier(score, &scope_config);

        doc.insert("tier".into(), Value::String(tier.clone()));
        doc.insert("originalScore".into(), serde_json::to_value(score).unwrap());
        doc.insert("currentScore".into(), serde_json::to_value(score).unwrap());
        doc.entry("createdAt".to_string()).or_insert(Value::String(Utc::now().to_rfc3339()));
        doc.entry("expiresAt".to_string()).or_insert(Value::String((Utc::now() + Duration::days(7)).to_rfc3339()));
        doc.insert("seen".into(), Value::Bool(false));
        doc.insert("hidden".into(), Value::Bool(false));

        let id = get_str(&doc, "feedItemId");
        if let Err(e) = self.db.upsert(&self.config.feed_items_index, &id, &doc).await {
            error!("Failed to store feed item: {}", e);
            return DataProcessResult::error(&e.to_string());
        }

        let mut event = HashMap::new();
        event.insert("eventType".into(), Value::String("FeedItemIngested".into()));
        event.insert("feedItemId".into(), doc.get("feedItemId").cloned().unwrap_or_default());
        event.insert("userId".into(), doc.get("userId").cloned().unwrap_or_default());
        event.insert("tier".into(), Value::String(tier.clone()));
        event.insert("timestamp".into(), Value::String(Utc::now().to_rfc3339()));
        let _ = self.queue.publish("feed-events", &event).await;

        info!("Feed item {} ingested at tier {}", id, tier);
        DataProcessResult::ok(doc, "Feed item ingested")
    }

    pub async fn ingest_batch(&self, items: &[Value], _target_type: &str) -> DataProcessResult<usize> {
        let mut success = 0usize;
        let mut errors = Vec::new();
        for item in items {
            let r = self.ingest_item(item).await;
            if r.success { success += 1; } else { errors.push(r.message); }
        }
        if success == 0 && !errors.is_empty() {
            return DataProcessResult::error(&format!("All {} failed: {}", errors.len(), errors[0]));
        }
        DataProcessResult::ok(success, &format!("Ingested {}/{}", success, items.len()))
    }

    pub async fn inject_high_priority(&self, item: &Value) -> DataProcessResult<FeedDoc> {
        let mut doc = self.op.parse_object_alternative(item);
        doc.insert("tier".into(), Value::String("immediate".into()));
        doc.insert("score".into(), serde_json::to_value(100.0).unwrap());
        doc.insert("originalScore".into(), serde_json::to_value(100.0).unwrap());
        doc.insert("currentScore".into(), serde_json::to_value(100.0).unwrap());
        doc.insert("highPriority".into(), Value::Bool(true));
        self.ingest_item(&serde_json::to_value(&doc).unwrap()).await
    }

    // ─── Retrieval ──────────────────────────────────────────────

    pub async fn get_feed(&self, user_id: &str, page: usize, page_size: usize) -> DataProcessResult<FeedPage> {
        let ps = page_size.clamp(1, 100);
        let mut filter = HashMap::new();
        filter.insert("userId".into(), Value::String(user_id.into()));
        filter.insert("hidden".into(), Value::Bool(false));
        let filter = self.op.build_search_filter(&filter);

        let total = self.db.count(&self.config.feed_items_index, &filter).await.unwrap_or(0);
        let items = self.db.query(&self.config.feed_items_index, &filter, ps, page * ps).await.unwrap_or_default();

        let scope_config = self.load_config("").await;
        let half_life = get_f64(&scope_config, "decayHalfLifeHours", self.config.decay_half_life_hours);

        let tier_order: HashMap<&str, i32> = [("immediate", 0), ("high", 1), ("normal", 2), ("low", 3)].into();

        let mut decayed: Vec<FeedDoc> = items.iter().map(|item| {
            let mut p = self.op.parse_object_alternative(&serde_json::to_value(item).unwrap());
            let orig = get_f64(&p, "originalScore", 50.0);
            if let Ok(created) = DateTime::parse_from_rfc3339(&get_str(&p, "createdAt")) {
                let created_utc = created.with_timezone(&Utc);
                let new_score = TierCalculator::apply_decay(orig, created_utc, half_life);
                p.insert("currentScore".into(), serde_json::to_value(new_score).unwrap());
                p.insert("tier".into(), Value::String(TierCalculator::calculate_tier(new_score, &scope_config)));
            }
            p
        }).collect();

        decayed.sort_by(|a, b| {
            let ta = *tier_order.get(get_str(a, "tier").as_str()).unwrap_or(&4);
            let tb = *tier_order.get(get_str(b, "tier").as_str()).unwrap_or(&4);
            ta.cmp(&tb).then_with(|| {
                let sa = get_f64(b, "currentScore", 0.0);
                let sb = get_f64(a, "currentScore", 0.0);
                sa.partial_cmp(&sb).unwrap_or(std::cmp::Ordering::Equal)
            })
        });

        let cursor = decayed.last().and_then(|l| l.get("feedItemId")).map(|v| get_str_val(v));
        DataProcessResult::ok(
            FeedPage { items: decayed, cursor, total_count: total, has_more: (page + 1) * ps < total },
            "Feed retrieved",
        )
    }

    pub async fn mark_seen(&self, user_id: &str, feed_item_id: &str) -> DataProcessResult<bool> {
        match self.db.get_by_id(&self.config.feed_items_index, feed_item_id).await {
            Ok(Some(item)) => {
                let mut parsed = self.op.parse_object_alternative(&serde_json::to_value(&item).unwrap());
                if get_str(&parsed, "userId") != user_id {
                    return DataProcessResult::error("Access denied — scope mismatch");
                }
                parsed.insert("seen".into(), Value::Bool(true));
                parsed.insert("seenAt".into(), Value::String(Utc::now().to_rfc3339()));
                let _ = self.db.upsert(&self.config.feed_items_index, feed_item_id, &parsed).await;
                DataProcessResult::ok(true, "Marked as seen")
            }
            Ok(None) => DataProcessResult::error("Feed item not found"),
            Err(e) => DataProcessResult::error(&e.to_string()),
        }
    }

    pub async fn hide_item(&self, user_id: &str, feed_item_id: &str) -> DataProcessResult<bool> {
        match self.db.get_by_id(&self.config.feed_items_index, feed_item_id).await {
            Ok(Some(item)) => {
                let mut parsed = self.op.parse_object_alternative(&serde_json::to_value(&item).unwrap());
                if get_str(&parsed, "userId") != user_id {
                    return DataProcessResult::error("Access denied — scope mismatch");
                }
                parsed.insert("hidden".into(), Value::Bool(true));
                parsed.insert("hiddenAt".into(), Value::String(Utc::now().to_rfc3339()));
                let _ = self.db.upsert(&self.config.feed_items_index, feed_item_id, &parsed).await;
                let mut event = HashMap::new();
                event.insert("eventType".into(), Value::String("FeedItemHidden".into()));
                event.insert("feedItemId".into(), Value::String(feed_item_id.into()));
                event.insert("userId".into(), Value::String(user_id.into()));
                let _ = self.queue.publish("feed-events", &event).await;
                DataProcessResult::ok(true, "Item hidden")
            }
            Ok(None) => DataProcessResult::error("Feed item not found"),
            Err(e) => DataProcessResult::error(&e.to_string()),
        }
    }

    pub async fn expire_items(&self) -> DataProcessResult<usize> {
        let mut filter = HashMap::new();
        filter.insert("expiresAtBefore".into(), Value::String(Utc::now().to_rfc3339()));
        let filter = self.op.build_search_filter(&filter);
        let expired = self.db.query(&self.config.feed_items_index, &filter, 1000, 0).await.unwrap_or_default();
        let mut count = 0usize;
        for item in &expired {
            let id = get_str(item, "feedItemId");
            if !id.is_empty() { let _ = self.db.delete(&self.config.feed_items_index, &id).await; count += 1; }
        }
        if count > 0 {
            let mut event = HashMap::new();
            event.insert("eventType".into(), Value::String("FeedItemsExpired".into()));
            event.insert("count".into(), serde_json::to_value(count).unwrap());
            let _ = self.queue.publish("feed-events", &event).await;
        }
        DataProcessResult::ok(count, &format!("Expired {} items", count))
    }

    // ─── Config ─────────────────────────────────────────────────

    pub async fn get_config(&self, scope_id: &str) -> DataProcessResult<FeedDoc> {
        DataProcessResult::ok(self.load_config(scope_id).await, "Config loaded")
    }

    pub async fn update_config(&self, scope_id: &str, config: &Value) -> DataProcessResult<FeedDoc> {
        let mut doc = self.op.parse_object_alternative(config);
        let config_id = format!("feed-config-{}", scope_id);
        doc.insert("configId".into(), Value::String(config_id.clone()));
        doc.insert("scopeId".into(), Value::String(scope_id.into()));
        doc.insert("updatedAt".into(), Value::String(Utc::now().to_rfc3339()));
        match self.db.upsert(&self.config.feed_config_index, &config_id, &doc).await {
            Ok(_) => DataProcessResult::ok(doc, "Config updated"),
            Err(e) => DataProcessResult::error(&e.to_string()),
        }
    }

    async fn load_config(&self, scope_id: &str) -> FeedDoc {
        let config_id = format!("feed-config-{}", scope_id);
        if let Ok(Some(c)) = self.db.get_by_id(&self.config.feed_config_index, &config_id).await {
            return self.op.parse_object_alternative(&serde_json::to_value(&c).unwrap());
        }
        let mut defaults = HashMap::new();
        defaults.insert("immediateMinScore".into(), serde_json::to_value(self.config.immediate_min_score).unwrap());
        defaults.insert("highMinScore".into(), serde_json::to_value(self.config.high_min_score).unwrap());
        defaults.insert("normalMinScore".into(), serde_json::to_value(self.config.normal_min_score).unwrap());
        defaults.insert("decayHalfLifeHours".into(), serde_json::to_value(self.config.decay_half_life_hours).unwrap());
        defaults
    }
}

// ─── Helpers ────────────────────────────────────────────────────
fn get_str(m: &FeedDoc, key: &str) -> String {
    m.get(key).map(get_str_val).unwrap_or_default()
}

fn get_str_val(v: &Value) -> String {
    match v {
        Value::String(s) => s.clone(),
        _ => v.to_string().trim_matches('"').to_string(),
    }
}

fn get_f64(m: &FeedDoc, key: &str, fallback: f64) -> f64 {
    m.get(key).and_then(|v| match v {
        Value::Number(n) => n.as_f64(),
        Value::String(s) => s.parse().ok(),
        _ => None,
    }).unwrap_or(fallback)
}
