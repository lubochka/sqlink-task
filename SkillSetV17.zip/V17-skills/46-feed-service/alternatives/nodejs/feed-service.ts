// XIIGen Feed Service — Skill 46 | Node.js/TypeScript Alternative
// Personalized feed generation with 4-tier ranking, weight decay, deduplication
// Genie DNA: DNA-1 (Record<string,any>), DNA-2 (buildSearchFilter), DNA-5 (DataProcessResult)

import { createHash } from 'crypto';
import { IDatabaseService, IQueueService, IObjectProcessor } from '../01-core-interfaces';
import { DataProcessResult } from '../01-core-interfaces';

// ─── Configuration ──────────────────────────────────────────────
export interface FeedConfig {
  feedItemsIndex: string;
  feedConfigIndex: string;
  defaultPageSize: number;
  maxFeedSize: number;
  decayHalfLifeHours: number;
  deduplicationWindow: string;
  immediateMinScore: number;
  highMinScore: number;
  normalMinScore: number;
}

const DEFAULT_CONFIG: FeedConfig = {
  feedItemsIndex: 'feed-items',
  feedConfigIndex: 'feed-config',
  defaultPageSize: 20,
  maxFeedSize: 500,
  decayHalfLifeHours: 24,
  deduplicationWindow: '7d',
  immediateMinScore: 90,
  highMinScore: 70,
  normalMinScore: 40,
};

type FeedDoc = Record<string, any>;

export interface FeedPage {
  items: FeedDoc[];
  cursor?: string;
  totalCount: number;
  hasMore: boolean;
}

// ─── Tier Calculator ────────────────────────────────────────────
export class TierCalculator {
  calculateTier(score: number, config: FeedDoc): string {
    const immediateMin = Number(config.immediateMinScore ?? 90);
    const highMin = Number(config.highMinScore ?? 70);
    const normalMin = Number(config.normalMinScore ?? 40);

    if (score >= immediateMin) return 'immediate';
    if (score >= highMin) return 'high';
    if (score >= normalMin) return 'normal';
    return 'low';
  }

  applyDecay(originalScore: number, createdAt: Date, halfLifeHours: number): number {
    if (halfLifeHours <= 0) return originalScore;
    const hoursElapsed = (Date.now() - createdAt.getTime()) / (1000 * 60 * 60);
    const decayFactor = Math.pow(0.5, hoursElapsed / halfLifeHours);
    return originalScore * decayFactor;
  }
}

// ─── Deduplication ──────────────────────────────────────────────
export class FeedDeduplicator {
  computeFingerprint(item: FeedDoc): string {
    const raw = `${item.userId ?? ''}:${item.sourceType ?? ''}:${item.sourceId ?? ''}`;
    return createHash('sha256').update(raw).digest('hex').substring(0, 16);
  }
}

// ─── Service Interface ──────────────────────────────────────────
export interface IFeedService {
  ingestItem(item: FeedDoc): Promise<DataProcessResult<FeedDoc>>;
  ingestBatch(items: FeedDoc[], targetType: string): Promise<DataProcessResult<number>>;
  injectHighPriority(item: FeedDoc): Promise<DataProcessResult<FeedDoc>>;

  getFeed(userId: string, page: number, pageSize: number): Promise<DataProcessResult<FeedPage>>;
  getFeedByType(userId: string, sourceType: string, page: number, pageSize: number): Promise<DataProcessResult<FeedPage>>;
  refreshFeed(userId: string): Promise<DataProcessResult<FeedDoc>>;

  markSeen(userId: string, feedItemId: string): Promise<DataProcessResult<boolean>>;
  hideItem(userId: string, feedItemId: string): Promise<DataProcessResult<boolean>>;
  expireItems(): Promise<DataProcessResult<number>>;
  reorderFeed(userId: string): Promise<DataProcessResult<FeedDoc>>;

  getConfig(scopeId: string): Promise<DataProcessResult<FeedDoc>>;
  updateConfig(scopeId: string, config: FeedDoc): Promise<DataProcessResult<FeedDoc>>;
}

// ─── Service Implementation ─────────────────────────────────────
export class FeedService implements IFeedService {
  private readonly tierCalc = new TierCalculator();
  private readonly dedup = new FeedDeduplicator();

  constructor(
    private readonly db: IDatabaseService,
    private readonly queue: IQueueService,
    private readonly objectProcessor: IObjectProcessor,
    private readonly config: FeedConfig = DEFAULT_CONFIG,
    private readonly logger: Console = console,
  ) {}

  // ─── Ingestion ────────────────────────────────────────────────

  async ingestItem(item: FeedDoc): Promise<DataProcessResult<FeedDoc>> {
    try {
      // DNA-1: Parse as dynamic document
      const doc = this.objectProcessor.parseObjectAlternative(item);

      if (!doc.userId || !doc.sourceType || !doc.sourceId) {
        return { success: false, data: {}, message: 'Missing required fields: userId, sourceType, sourceId' };
      }

      if (!doc.feedItemId) doc.feedItemId = crypto.randomUUID();
      doc.fingerprint = this.dedup.computeFingerprint(doc);

      // Deduplication check
      // DNA-2: BuildSearchFilter with empty-field skipping
      const dupFilter = this.objectProcessor.buildSearchFilter({
        fingerprint: doc.fingerprint,
        userId: doc.userId,
      });
      const existing = await this.db.query(this.config.feedItemsIndex, dupFilter, 1, 0);
      if (existing?.length > 0) {
        return { success: false, data: {}, message: 'Duplicate feed item detected' };
      }

      // Score and tier
      const score = Number(doc.score ?? 50);
      const scopeConfig = await this.loadConfig(doc.scopeId ?? '');
      doc.tier = this.tierCalc.calculateTier(score, scopeConfig);
      doc.originalScore = score;
      doc.currentScore = score;
      doc.createdAt = doc.createdAt ?? new Date().toISOString();
      doc.expiresAt = doc.expiresAt ?? new Date(Date.now() + 7 * 86400000).toISOString();
      doc.seen = false;
      doc.hidden = false;

      await this.db.upsert(this.config.feedItemsIndex, doc.feedItemId, doc);

      // DNA-7: Publish event
      await this.queue.publish('feed-events', {
        eventType: 'FeedItemIngested',
        feedItemId: doc.feedItemId,
        userId: doc.userId,
        sourceType: doc.sourceType,
        tier: doc.tier,
        timestamp: new Date().toISOString(),
      });

      this.logger.info(`Feed item ${doc.feedItemId} ingested for user ${doc.userId} at tier ${doc.tier}`);
      return { success: true, data: doc, message: 'Feed item ingested' };
    } catch (error: any) {
      this.logger.error('FeedService.ingestItem failed:', error);
      return { success: false, data: {}, message: error.message };
    }
  }

  async ingestBatch(items: FeedDoc[], _targetType: string): Promise<DataProcessResult<number>> {
    try {
      let successCount = 0;
      const errors: string[] = [];

      for (const item of items) {
        const result = await this.ingestItem(item);
        if (result.success) successCount++;
        else errors.push(result.message ?? 'Unknown error');
      }

      if (successCount === 0 && errors.length > 0) {
        return { success: false, data: 0, message: `All ${errors.length} items failed: ${errors[0]}` };
      }

      return {
        success: true,
        data: successCount,
        message: `Ingested ${successCount}/${items.length}` + (errors.length ? `, ${errors.length} failures` : ''),
      };
    } catch (error: any) {
      return { success: false, data: 0, message: error.message };
    }
  }

  async injectHighPriority(item: FeedDoc): Promise<DataProcessResult<FeedDoc>> {
    const doc = this.objectProcessor.parseObjectAlternative(item);
    doc.tier = 'immediate';
    doc.score = 100;
    doc.originalScore = 100;
    doc.currentScore = 100;
    doc.highPriority = true;
    return this.ingestItem(doc);
  }

  // ─── Retrieval ────────────────────────────────────────────────

  async getFeed(userId: string, page: number, pageSize: number): Promise<DataProcessResult<FeedPage>> {
    try {
      pageSize = Math.max(1, Math.min(pageSize, 100));

      // DNA-2 + DNA-SCOPE: userId always present
      const filter = this.objectProcessor.buildSearchFilter({ userId, hidden: false });
      const totalCount = await this.db.count(this.config.feedItemsIndex, filter);
      const items = await this.db.query(this.config.feedItemsIndex, filter, pageSize, page * pageSize);

      // Apply decay
      const scopeConfig = await this.loadConfig('');
      const halfLife = Number(scopeConfig.decayHalfLifeHours ?? this.config.decayHalfLifeHours);

      const decayed = (items ?? []).map((item: any) => {
        const parsed = this.objectProcessor.parseObjectAlternative(item);
        const originalScore = Number(parsed.originalScore ?? 50);
        const createdAt = new Date(parsed.createdAt);
        if (!isNaN(createdAt.getTime())) {
          parsed.currentScore = this.tierCalc.applyDecay(originalScore, createdAt, halfLife);
          parsed.tier = this.tierCalc.calculateTier(parsed.currentScore, scopeConfig);
        }
        return parsed;
      });

      // Sort: tier priority → score desc
      const tierOrder: Record<string, number> = { immediate: 0, high: 1, normal: 2, low: 3 };
      decayed.sort((a, b) => {
        const tierDiff = (tierOrder[a.tier] ?? 4) - (tierOrder[b.tier] ?? 4);
        if (tierDiff !== 0) return tierDiff;
        return (Number(b.currentScore) || 0) - (Number(a.currentScore) || 0);
      });

      return {
        success: true,
        data: {
          items: decayed,
          totalCount: totalCount ?? 0,
          hasMore: (page + 1) * pageSize < (totalCount ?? 0),
          cursor: decayed.length > 0 ? decayed[decayed.length - 1].feedItemId : undefined,
        },
        message: 'Feed retrieved',
      };
    } catch (error: any) {
      return { success: false, data: { items: [], totalCount: 0, hasMore: false }, message: error.message };
    }
  }

  async getFeedByType(userId: string, sourceType: string, page: number, pageSize: number): Promise<DataProcessResult<FeedPage>> {
    try {
      pageSize = Math.max(1, Math.min(pageSize, 100));
      const filter = this.objectProcessor.buildSearchFilter({ userId, sourceType, hidden: false });
      const items = await this.db.query(this.config.feedItemsIndex, filter, pageSize, page * pageSize);
      const totalCount = await this.db.count(this.config.feedItemsIndex, filter);

      return {
        success: true,
        data: {
          items: (items ?? []).map((i: any) => this.objectProcessor.parseObjectAlternative(i)),
          totalCount: totalCount ?? 0,
          hasMore: (page + 1) * pageSize < (totalCount ?? 0),
        },
        message: 'Feed by type retrieved',
      };
    } catch (error: any) {
      return { success: false, data: { items: [], totalCount: 0, hasMore: false }, message: error.message };
    }
  }

  async refreshFeed(userId: string): Promise<DataProcessResult<FeedDoc>> {
    try {
      const filter = this.objectProcessor.buildSearchFilter({ userId, hidden: false });
      const allItems = await this.db.query(this.config.feedItemsIndex, filter, this.config.maxFeedSize, 0);
      const scopeConfig = await this.loadConfig('');
      const halfLife = Number(scopeConfig.decayHalfLifeHours ?? this.config.decayHalfLifeHours);
      let updatedCount = 0;

      for (const item of allItems ?? []) {
        const parsed = this.objectProcessor.parseObjectAlternative(item);
        const originalScore = Number(parsed.originalScore ?? 50);
        const createdAt = new Date(parsed.createdAt);
        if (!isNaN(createdAt.getTime())) {
          parsed.currentScore = this.tierCalc.applyDecay(originalScore, createdAt, halfLife);
          parsed.tier = this.tierCalc.calculateTier(parsed.currentScore, scopeConfig);
          parsed.refreshedAt = new Date().toISOString();
          await this.db.upsert(this.config.feedItemsIndex, parsed.feedItemId, parsed);
          updatedCount++;
        }
      }

      await this.queue.publish('feed-events', {
        eventType: 'FeedUpdated', userId, itemsUpdated: updatedCount,
        timestamp: new Date().toISOString(),
      });

      return { success: true, data: { userId, itemsRefreshed: updatedCount, refreshedAt: new Date().toISOString() } };
    } catch (error: any) {
      return { success: false, data: {}, message: error.message };
    }
  }

  // ─── Management ───────────────────────────────────────────────

  async markSeen(userId: string, feedItemId: string): Promise<DataProcessResult<boolean>> {
    try {
      const item = await this.db.getById(this.config.feedItemsIndex, feedItemId);
      if (!item) return { success: false, data: false, message: 'Feed item not found' };
      const parsed = this.objectProcessor.parseObjectAlternative(item);
      if (parsed.userId !== userId) return { success: false, data: false, message: 'Access denied — scope mismatch' };
      parsed.seen = true;
      parsed.seenAt = new Date().toISOString();
      await this.db.upsert(this.config.feedItemsIndex, feedItemId, parsed);
      return { success: true, data: true, message: 'Marked as seen' };
    } catch (error: any) {
      return { success: false, data: false, message: error.message };
    }
  }

  async hideItem(userId: string, feedItemId: string): Promise<DataProcessResult<boolean>> {
    try {
      const item = await this.db.getById(this.config.feedItemsIndex, feedItemId);
      if (!item) return { success: false, data: false, message: 'Feed item not found' };
      const parsed = this.objectProcessor.parseObjectAlternative(item);
      if (parsed.userId !== userId) return { success: false, data: false, message: 'Access denied — scope mismatch' };
      parsed.hidden = true;
      parsed.hiddenAt = new Date().toISOString();
      await this.db.upsert(this.config.feedItemsIndex, feedItemId, parsed);
      await this.queue.publish('feed-events', {
        eventType: 'FeedItemHidden', feedItemId, userId, sourceType: parsed.sourceType,
        timestamp: new Date().toISOString(),
      });
      return { success: true, data: true, message: 'Item hidden' };
    } catch (error: any) {
      return { success: false, data: false, message: error.message };
    }
  }

  async expireItems(): Promise<DataProcessResult<number>> {
    try {
      const filter = this.objectProcessor.buildSearchFilter({ expiresAtBefore: new Date().toISOString() });
      const expired = await this.db.query(this.config.feedItemsIndex, filter, 1000, 0);
      let count = 0;
      for (const item of expired ?? []) {
        const parsed = this.objectProcessor.parseObjectAlternative(item);
        if (parsed.feedItemId) {
          await this.db.delete(this.config.feedItemsIndex, parsed.feedItemId);
          count++;
        }
      }
      if (count > 0) {
        await this.queue.publish('feed-events', {
          eventType: 'FeedItemsExpired', count, timestamp: new Date().toISOString(),
        });
      }
      return { success: true, data: count, message: `Expired ${count} items` };
    } catch (error: any) {
      return { success: false, data: 0, message: error.message };
    }
  }

  async reorderFeed(userId: string): Promise<DataProcessResult<FeedDoc>> {
    const result = await this.refreshFeed(userId);
    if (result.success) {
      await this.queue.publish('feed-events', {
        eventType: 'FeedReordered', userId, timestamp: new Date().toISOString(),
      });
    }
    return result;
  }

  // ─── Config (FREEDOM) ────────────────────────────────────────

  async getConfig(scopeId: string): Promise<DataProcessResult<FeedDoc>> {
    try {
      const config = await this.loadConfig(scopeId);
      return { success: true, data: config, message: 'Config loaded' };
    } catch (error: any) {
      return { success: false, data: {}, message: error.message };
    }
  }

  async updateConfig(scopeId: string, config: FeedDoc): Promise<DataProcessResult<FeedDoc>> {
    try {
      const doc = this.objectProcessor.parseObjectAlternative(config);
      doc.configId = `feed-config-${scopeId}`;
      doc.scopeId = scopeId;
      doc.updatedAt = new Date().toISOString();
      await this.db.upsert(this.config.feedConfigIndex, doc.configId, doc);
      return { success: true, data: doc, message: 'Config updated' };
    } catch (error: any) {
      return { success: false, data: {}, message: error.message };
    }
  }

  // ─── Helpers ──────────────────────────────────────────────────

  private async loadConfig(scopeId: string): Promise<FeedDoc> {
    try {
      const configId = `feed-config-${scopeId}`;
      const config = await this.db.getById(this.config.feedConfigIndex, configId);
      if (config) return this.objectProcessor.parseObjectAlternative(config);
    } catch { /* fall through */ }
    return {
      immediateMinScore: this.config.immediateMinScore,
      highMinScore: this.config.highMinScore,
      normalMinScore: this.config.normalMinScore,
      decayHalfLifeHours: this.config.decayHalfLifeHours,
      maxFeedSize: this.config.maxFeedSize,
    };
  }
}
