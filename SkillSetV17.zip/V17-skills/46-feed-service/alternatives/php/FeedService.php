<?php
// XIIGen Feed Service — Skill 46 | PHP/Laravel Alternative
// Personalized feed generation with 4-tier ranking, weight decay, deduplication
// Genie DNA: DNA-1 (array), DNA-2 (buildSearchFilter), DNA-5 (DataProcessResult)

namespace XIIGen\Services\Feed;

use Illuminate\Support\Str;
use Carbon\Carbon;

// ─── Configuration ──────────────────────────────────────────────
class FeedConfig
{
    public function __construct(
        public string $feedItemsIndex = 'feed-items',
        public string $feedConfigIndex = 'feed-config',
        public int $defaultPageSize = 20,
        public int $maxFeedSize = 500,
        public float $decayHalfLifeHours = 24.0,
        public float $immediateMinScore = 90.0,
        public float $highMinScore = 70.0,
        public float $normalMinScore = 40.0,
    ) {}
}

// ─── Data Process Result (DNA-5) ────────────────────────────────
class DataProcessResult
{
    public function __construct(
        public bool $success,
        public mixed $data = null,
        public string $message = '',
    ) {}

    public static function ok(mixed $data, string $message = ''): self
    {
        return new self(true, $data, $message);
    }

    public static function error(string $message): self
    {
        return new self(false, null, $message);
    }
}

// ─── Feed Page ──────────────────────────────────────────────────
class FeedPage
{
    public function __construct(
        public array $items = [],
        public ?string $cursor = null,
        public int $totalCount = 0,
        public bool $hasMore = false,
    ) {}
}

// ─── Interfaces (Genie DNA) ────────────────────────────────────
interface IDatabaseService
{
    public function upsert(string $index, string $id, array $doc): void;
    public function getById(string $index, string $id): ?array;
    public function query(string $index, array $filter, int $limit, int $offset): array;
    public function count(string $index, array $filter): int;
    public function delete(string $index, string $id): void;
}

interface IQueueService
{
    public function publish(string $channel, array $message): void;
}

interface IObjectProcessor
{
    public function parseObjectAlternative(mixed $obj): array;
    public function buildSearchFilter(array $filter): array;
}

// ─── Tier Calculator ────────────────────────────────────────────
class TierCalculator
{
    public function calculateTier(float $score, array $config): string
    {
        $immediateMin = (float)($config['immediateMinScore'] ?? 90);
        $highMin = (float)($config['highMinScore'] ?? 70);
        $normalMin = (float)($config['normalMinScore'] ?? 40);

        if ($score >= $immediateMin) return 'immediate';
        if ($score >= $highMin) return 'high';
        if ($score >= $normalMin) return 'normal';
        return 'low';
    }

    public function applyDecay(float $originalScore, Carbon $createdAt, float $halfLifeHours): float
    {
        if ($halfLifeHours <= 0) return $originalScore;
        $hoursElapsed = Carbon::now()->diffInMinutes($createdAt) / 60.0;
        $decayFactor = pow(0.5, $hoursElapsed / $halfLifeHours);
        return $originalScore * $decayFactor;
    }
}

// ─── Deduplication ──────────────────────────────────────────────
class FeedDeduplicator
{
    public function computeFingerprint(array $item): string
    {
        $raw = ($item['userId'] ?? '') . ':' . ($item['sourceType'] ?? '') . ':' . ($item['sourceId'] ?? '');
        return substr(hash('sha256', $raw), 0, 16);
    }
}

// ─── Service Interface ──────────────────────────────────────────
interface IFeedService
{
    public function ingestItem(array $item): DataProcessResult;
    public function ingestBatch(array $items, string $targetType): DataProcessResult;
    public function injectHighPriority(array $item): DataProcessResult;

    public function getFeed(string $userId, int $page, int $pageSize): DataProcessResult;
    public function getFeedByType(string $userId, string $sourceType, int $page, int $pageSize): DataProcessResult;
    public function refreshFeed(string $userId): DataProcessResult;

    public function markSeen(string $userId, string $feedItemId): DataProcessResult;
    public function hideItem(string $userId, string $feedItemId): DataProcessResult;
    public function expireItems(): DataProcessResult;
    public function reorderFeed(string $userId): DataProcessResult;

    public function getConfig(string $scopeId): DataProcessResult;
    public function updateConfig(string $scopeId, array $config): DataProcessResult;
}

// ─── Service Implementation ─────────────────────────────────────
class FeedService implements IFeedService
{
    private TierCalculator $tierCalc;
    private FeedDeduplicator $dedup;

    public function __construct(
        private IDatabaseService $db,
        private IQueueService $queue,
        private IObjectProcessor $objectProcessor,
        private FeedConfig $config = new FeedConfig(),
    ) {
        $this->tierCalc = new TierCalculator();
        $this->dedup = new FeedDeduplicator();
    }

    // ─── Ingestion ──────────────────────────────────────────────

    public function ingestItem(array $item): DataProcessResult
    {
        try {
            $doc = $this->objectProcessor->parseObjectAlternative($item);

            if (empty($doc['userId']) || empty($doc['sourceType']) || empty($doc['sourceId'])) {
                return DataProcessResult::error('Missing required fields: userId, sourceType, sourceId');
            }

            $doc['feedItemId'] ??= (string) Str::uuid();
            $doc['fingerprint'] = $this->dedup->computeFingerprint($doc);

            // Deduplication — DNA-2
            $dupFilter = $this->objectProcessor->buildSearchFilter([
                'fingerprint' => $doc['fingerprint'],
                'userId' => $doc['userId'],
            ]);
            $existing = $this->db->query($this->config->feedItemsIndex, $dupFilter, 1, 0);
            if (!empty($existing)) {
                return DataProcessResult::error('Duplicate feed item detected');
            }

            $score = (float)($doc['score'] ?? 50);
            $scopeConfig = $this->loadConfig($doc['scopeId'] ?? '');
            $doc['tier'] = $this->tierCalc->calculateTier($score, $scopeConfig);
            $doc['originalScore'] = $score;
            $doc['currentScore'] = $score;
            $doc['createdAt'] ??= Carbon::now()->toISOString();
            $doc['expiresAt'] ??= Carbon::now()->addDays(7)->toISOString();
            $doc['seen'] = false;
            $doc['hidden'] = false;

            $this->db->upsert($this->config->feedItemsIndex, $doc['feedItemId'], $doc);

            $this->queue->publish('feed-events', [
                'eventType' => 'FeedItemIngested',
                'feedItemId' => $doc['feedItemId'],
                'userId' => $doc['userId'],
                'sourceType' => $doc['sourceType'],
                'tier' => $doc['tier'],
                'timestamp' => Carbon::now()->toISOString(),
            ]);

            \Log::info("Feed item {$doc['feedItemId']} ingested for user {$doc['userId']} at tier {$doc['tier']}");
            return DataProcessResult::ok($doc, 'Feed item ingested');
        } catch (\Throwable $e) {
            \Log::error('FeedService.ingestItem failed: ' . $e->getMessage());
            return DataProcessResult::error($e->getMessage());
        }
    }

    public function ingestBatch(array $items, string $targetType): DataProcessResult
    {
        try {
            $successCount = 0;
            $errors = [];
            foreach ($items as $item) {
                $result = $this->ingestItem($item);
                if ($result->success) $successCount++;
                else $errors[] = $result->message;
            }
            if ($successCount === 0 && !empty($errors)) {
                return DataProcessResult::error("All " . count($errors) . " items failed: {$errors[0]}");
            }
            $msg = "Ingested {$successCount}/" . count($items);
            if (!empty($errors)) $msg .= ', ' . count($errors) . ' failures';
            return DataProcessResult::ok($successCount, $msg);
        } catch (\Throwable $e) {
            return DataProcessResult::error($e->getMessage());
        }
    }

    public function injectHighPriority(array $item): DataProcessResult
    {
        $doc = $this->objectProcessor->parseObjectAlternative($item);
        $doc['tier'] = 'immediate';
        $doc['score'] = 100;
        $doc['originalScore'] = 100;
        $doc['currentScore'] = 100;
        $doc['highPriority'] = true;
        return $this->ingestItem($doc);
    }

    // ─── Retrieval ──────────────────────────────────────────────

    public function getFeed(string $userId, int $page, int $pageSize): DataProcessResult
    {
        try {
            $pageSize = max(1, min($pageSize, 100));

            $filter = $this->objectProcessor->buildSearchFilter([
                'userId' => $userId,
                'hidden' => false,
            ]);

            $totalCount = $this->db->count($this->config->feedItemsIndex, $filter);
            $items = $this->db->query($this->config->feedItemsIndex, $filter, $pageSize, $page * $pageSize);

            $scopeConfig = $this->loadConfig('');
            $halfLife = (float)($scopeConfig['decayHalfLifeHours'] ?? $this->config->decayHalfLifeHours);

            $decayed = [];
            foreach ($items as $item) {
                $parsed = $this->objectProcessor->parseObjectAlternative($item);
                $originalScore = (float)($parsed['originalScore'] ?? 50);
                try {
                    $createdAt = Carbon::parse($parsed['createdAt'] ?? 'now');
                    $parsed['currentScore'] = $this->tierCalc->applyDecay($originalScore, $createdAt, $halfLife);
                    $parsed['tier'] = $this->tierCalc->calculateTier($parsed['currentScore'], $scopeConfig);
                } catch (\Throwable $e) { /* keep original */ }
                $decayed[] = $parsed;
            }

            $tierOrder = ['immediate' => 0, 'high' => 1, 'normal' => 2, 'low' => 3];
            usort($decayed, function ($a, $b) use ($tierOrder) {
                $tierDiff = ($tierOrder[$a['tier'] ?? 'low'] ?? 4) - ($tierOrder[$b['tier'] ?? 'low'] ?? 4);
                if ($tierDiff !== 0) return $tierDiff;
                return ($b['currentScore'] ?? 0) <=> ($a['currentScore'] ?? 0);
            });

            $cursor = !empty($decayed) ? end($decayed)['feedItemId'] ?? null : null;
            return DataProcessResult::ok(new FeedPage(
                items: $decayed,
                cursor: $cursor,
                totalCount: $totalCount,
                hasMore: ($page + 1) * $pageSize < $totalCount,
            ));
        } catch (\Throwable $e) {
            return DataProcessResult::error($e->getMessage());
        }
    }

    public function getFeedByType(string $userId, string $sourceType, int $page, int $pageSize): DataProcessResult
    {
        try {
            $pageSize = max(1, min($pageSize, 100));
            $filter = $this->objectProcessor->buildSearchFilter([
                'userId' => $userId, 'sourceType' => $sourceType, 'hidden' => false,
            ]);
            $items = $this->db->query($this->config->feedItemsIndex, $filter, $pageSize, $page * $pageSize);
            $totalCount = $this->db->count($this->config->feedItemsIndex, $filter);
            $mapped = array_map(fn($i) => $this->objectProcessor->parseObjectAlternative($i), $items);
            return DataProcessResult::ok(new FeedPage(
                items: $mapped, totalCount: $totalCount,
                hasMore: ($page + 1) * $pageSize < $totalCount,
            ));
        } catch (\Throwable $e) {
            return DataProcessResult::error($e->getMessage());
        }
    }

    public function refreshFeed(string $userId): DataProcessResult
    {
        try {
            $filter = $this->objectProcessor->buildSearchFilter(['userId' => $userId, 'hidden' => false]);
            $allItems = $this->db->query($this->config->feedItemsIndex, $filter, $this->config->maxFeedSize, 0);
            $scopeConfig = $this->loadConfig('');
            $halfLife = (float)($scopeConfig['decayHalfLifeHours'] ?? $this->config->decayHalfLifeHours);
            $updated = 0;

            foreach ($allItems as $item) {
                $parsed = $this->objectProcessor->parseObjectAlternative($item);
                try {
                    $orig = (float)($parsed['originalScore'] ?? 50);
                    $created = Carbon::parse($parsed['createdAt']);
                    $parsed['currentScore'] = $this->tierCalc->applyDecay($orig, $created, $halfLife);
                    $parsed['tier'] = $this->tierCalc->calculateTier($parsed['currentScore'], $scopeConfig);
                    $parsed['refreshedAt'] = Carbon::now()->toISOString();
                    $this->db->upsert($this->config->feedItemsIndex, $parsed['feedItemId'], $parsed);
                    $updated++;
                } catch (\Throwable $e) { continue; }
            }

            $this->queue->publish('feed-events', [
                'eventType' => 'FeedUpdated', 'userId' => $userId,
                'itemsUpdated' => $updated, 'timestamp' => Carbon::now()->toISOString(),
            ]);
            return DataProcessResult::ok(['userId' => $userId, 'itemsRefreshed' => $updated]);
        } catch (\Throwable $e) {
            return DataProcessResult::error($e->getMessage());
        }
    }

    // ─── Management ─────────────────────────────────────────────

    public function markSeen(string $userId, string $feedItemId): DataProcessResult
    {
        try {
            $item = $this->db->getById($this->config->feedItemsIndex, $feedItemId);
            if (!$item) return DataProcessResult::error('Feed item not found');
            $parsed = $this->objectProcessor->parseObjectAlternative($item);
            if (($parsed['userId'] ?? '') !== $userId) return DataProcessResult::error('Access denied — scope mismatch');
            $parsed['seen'] = true;
            $parsed['seenAt'] = Carbon::now()->toISOString();
            $this->db->upsert($this->config->feedItemsIndex, $feedItemId, $parsed);
            return DataProcessResult::ok(true, 'Marked as seen');
        } catch (\Throwable $e) {
            return DataProcessResult::error($e->getMessage());
        }
    }

    public function hideItem(string $userId, string $feedItemId): DataProcessResult
    {
        try {
            $item = $this->db->getById($this->config->feedItemsIndex, $feedItemId);
            if (!$item) return DataProcessResult::error('Feed item not found');
            $parsed = $this->objectProcessor->parseObjectAlternative($item);
            if (($parsed['userId'] ?? '') !== $userId) return DataProcessResult::error('Access denied — scope mismatch');
            $parsed['hidden'] = true;
            $parsed['hiddenAt'] = Carbon::now()->toISOString();
            $this->db->upsert($this->config->feedItemsIndex, $feedItemId, $parsed);
            $this->queue->publish('feed-events', [
                'eventType' => 'FeedItemHidden', 'feedItemId' => $feedItemId,
                'userId' => $userId, 'timestamp' => Carbon::now()->toISOString(),
            ]);
            return DataProcessResult::ok(true, 'Item hidden');
        } catch (\Throwable $e) {
            return DataProcessResult::error($e->getMessage());
        }
    }

    public function expireItems(): DataProcessResult
    {
        try {
            $filter = $this->objectProcessor->buildSearchFilter(['expiresAtBefore' => Carbon::now()->toISOString()]);
            $expired = $this->db->query($this->config->feedItemsIndex, $filter, 1000, 0);
            $count = 0;
            foreach ($expired as $item) {
                $parsed = $this->objectProcessor->parseObjectAlternative($item);
                if (!empty($parsed['feedItemId'])) {
                    $this->db->delete($this->config->feedItemsIndex, $parsed['feedItemId']);
                    $count++;
                }
            }
            if ($count > 0) {
                $this->queue->publish('feed-events', [
                    'eventType' => 'FeedItemsExpired', 'count' => $count,
                    'timestamp' => Carbon::now()->toISOString(),
                ]);
            }
            return DataProcessResult::ok($count, "Expired {$count} items");
        } catch (\Throwable $e) {
            return DataProcessResult::error($e->getMessage());
        }
    }

    public function reorderFeed(string $userId): DataProcessResult
    {
        $result = $this->refreshFeed($userId);
        if ($result->success) {
            $this->queue->publish('feed-events', [
                'eventType' => 'FeedReordered', 'userId' => $userId,
                'timestamp' => Carbon::now()->toISOString(),
            ]);
        }
        return $result;
    }

    public function getConfig(string $scopeId): DataProcessResult
    {
        return DataProcessResult::ok($this->loadConfig($scopeId));
    }

    public function updateConfig(string $scopeId, array $config): DataProcessResult
    {
        try {
            $doc = $this->objectProcessor->parseObjectAlternative($config);
            $doc['configId'] = "feed-config-{$scopeId}";
            $doc['scopeId'] = $scopeId;
            $doc['updatedAt'] = Carbon::now()->toISOString();
            $this->db->upsert($this->config->feedConfigIndex, $doc['configId'], $doc);
            return DataProcessResult::ok($doc, 'Config updated');
        } catch (\Throwable $e) {
            return DataProcessResult::error($e->getMessage());
        }
    }

    // ─── Helpers ────────────────────────────────────────────────

    private function loadConfig(string $scopeId): array
    {
        try {
            $config = $this->db->getById($this->config->feedConfigIndex, "feed-config-{$scopeId}");
            if ($config) return $this->objectProcessor->parseObjectAlternative($config);
        } catch (\Throwable $e) { /* fall through */ }

        return [
            'immediateMinScore' => $this->config->immediateMinScore,
            'highMinScore' => $this->config->highMinScore,
            'normalMinScore' => $this->config->normalMinScore,
            'decayHalfLifeHours' => $this->config->decayHalfLifeHours,
            'maxFeedSize' => $this->config->maxFeedSize,
        ];
    }
}
