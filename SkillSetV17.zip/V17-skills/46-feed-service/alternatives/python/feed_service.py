# XIIGen Feed Service — Skill 46 | Python/FastAPI Alternative
# Personalized feed generation with 4-tier ranking, weight decay, deduplication
# Genie DNA: DNA-1 (dict[str,Any]), DNA-2 (build_search_filter), DNA-5 (DataProcessResult)

from __future__ import annotations
import hashlib
import math
import uuid
from datetime import datetime, timedelta, timezone
from dataclasses import dataclass, field
from typing import Any, Optional, Protocol

# ─── Configuration ──────────────────────────────────────────────
@dataclass
class FeedConfig:
    feed_items_index: str = "feed-items"
    feed_config_index: str = "feed-config"
    default_page_size: int = 20
    max_feed_size: int = 500
    decay_half_life_hours: float = 24.0
    deduplication_window: str = "7d"
    immediate_min_score: float = 90.0
    high_min_score: float = 70.0
    normal_min_score: float = 40.0

@dataclass
class FeedPage:
    items: list[dict[str, Any]] = field(default_factory=list)
    cursor: Optional[str] = None
    total_count: int = 0
    has_more: bool = False

@dataclass
class DataProcessResult:
    success: bool
    data: Any = None
    message: str = ""

    @classmethod
    def ok(cls, data: Any, message: str = "") -> DataProcessResult:
        return cls(success=True, data=data, message=message)

    @classmethod
    def error(cls, message: str) -> DataProcessResult:
        return cls(success=False, data=None, message=message)

# ─── Protocols (interfaces) ─────────────────────────────────────
class IDatabaseService(Protocol):
    async def upsert(self, index: str, doc_id: str, doc: dict[str, Any]) -> None: ...
    async def get_by_id(self, index: str, doc_id: str) -> Optional[dict[str, Any]]: ...
    async def query(self, index: str, filter_obj: dict, limit: int, offset: int) -> list[dict[str, Any]]: ...
    async def count(self, index: str, filter_obj: dict) -> int: ...
    async def delete(self, index: str, doc_id: str) -> None: ...

class IQueueService(Protocol):
    async def publish(self, channel: str, message: dict[str, Any]) -> None: ...

class IObjectProcessor(Protocol):
    def parse_object_alternative(self, obj: Any) -> dict[str, Any]: ...
    def build_search_filter(self, obj: dict[str, Any]) -> dict[str, Any]: ...

# ─── Tier Calculator ────────────────────────────────────────────
class TierCalculator:
    @staticmethod
    def calculate_tier(score: float, config: dict[str, Any]) -> str:
        immediate_min = float(config.get("immediate_min_score", 90))
        high_min = float(config.get("high_min_score", 70))
        normal_min = float(config.get("normal_min_score", 40))

        if score >= immediate_min:
            return "immediate"
        if score >= high_min:
            return "high"
        if score >= normal_min:
            return "normal"
        return "low"

    @staticmethod
    def apply_decay(original_score: float, created_at: datetime, half_life_hours: float) -> float:
        if half_life_hours <= 0:
            return original_score
        now = datetime.now(timezone.utc)
        if created_at.tzinfo is None:
            created_at = created_at.replace(tzinfo=timezone.utc)
        hours_elapsed = (now - created_at).total_seconds() / 3600
        decay_factor = math.pow(0.5, hours_elapsed / half_life_hours)
        return original_score * decay_factor

# ─── Deduplication ──────────────────────────────────────────────
class FeedDeduplicator:
    @staticmethod
    def compute_fingerprint(item: dict[str, Any]) -> str:
        raw = f"{item.get('userId', '')}:{item.get('sourceType', '')}:{item.get('sourceId', '')}"
        return hashlib.sha256(raw.encode()).hexdigest()[:16]

# ─── Service Implementation ─────────────────────────────────────
class FeedService:
    def __init__(
        self,
        db: IDatabaseService,
        queue: IQueueService,
        object_processor: IObjectProcessor,
        config: Optional[FeedConfig] = None,
    ):
        self._db = db
        self._queue = queue
        self._op = object_processor
        self._config = config or FeedConfig()
        self._tier_calc = TierCalculator()
        self._dedup = FeedDeduplicator()

    # ─── Ingestion ──────────────────────────────────────────────

    async def ingest_item(self, item: dict[str, Any]) -> DataProcessResult:
        try:
            doc = self._op.parse_object_alternative(item)

            if not all(doc.get(k) for k in ("userId", "sourceType", "sourceId")):
                return DataProcessResult.error("Missing required fields: userId, sourceType, sourceId")

            if "feedItemId" not in doc:
                doc["feedItemId"] = str(uuid.uuid4())
            doc["fingerprint"] = self._dedup.compute_fingerprint(doc)

            # Deduplication — DNA-2: BuildSearchFilter
            dup_filter = self._op.build_search_filter({
                "fingerprint": doc["fingerprint"],
                "userId": doc["userId"],
            })
            existing = await self._db.query(self._config.feed_items_index, dup_filter, 1, 0)
            if existing:
                return DataProcessResult.error("Duplicate feed item detected")

            # Score and tier
            score = float(doc.get("score", 50))
            scope_config = await self._load_config(doc.get("scopeId", ""))
            doc["tier"] = self._tier_calc.calculate_tier(score, scope_config)
            doc["originalScore"] = score
            doc["currentScore"] = score
            doc.setdefault("createdAt", datetime.now(timezone.utc).isoformat())
            doc.setdefault("expiresAt", (datetime.now(timezone.utc) + timedelta(days=7)).isoformat())
            doc["seen"] = False
            doc["hidden"] = False

            await self._db.upsert(self._config.feed_items_index, doc["feedItemId"], doc)

            await self._queue.publish("feed-events", {
                "eventType": "FeedItemIngested",
                "feedItemId": doc["feedItemId"],
                "userId": doc["userId"],
                "sourceType": doc["sourceType"],
                "tier": doc["tier"],
                "timestamp": datetime.now(timezone.utc).isoformat(),
            })

            return DataProcessResult.ok(doc, "Feed item ingested")
        except Exception as e:
            return DataProcessResult.error(str(e))

    async def ingest_batch(self, items: list[dict[str, Any]], target_type: str) -> DataProcessResult:
        try:
            success_count = 0
            errors: list[str] = []
            for item in items:
                result = await self.ingest_item(item)
                if result.success:
                    success_count += 1
                else:
                    errors.append(result.message)

            if success_count == 0 and errors:
                return DataProcessResult.error(f"All {len(errors)} items failed: {errors[0]}")

            msg = f"Ingested {success_count}/{len(items)}"
            if errors:
                msg += f", {len(errors)} failures"
            return DataProcessResult.ok(success_count, msg)
        except Exception as e:
            return DataProcessResult.error(str(e))

    async def inject_high_priority(self, item: dict[str, Any]) -> DataProcessResult:
        doc = self._op.parse_object_alternative(item)
        doc.update(tier="immediate", score=100, originalScore=100, currentScore=100, highPriority=True)
        return await self.ingest_item(doc)

    # ─── Retrieval ──────────────────────────────────────────────

    async def get_feed(self, user_id: str, page: int, page_size: int) -> DataProcessResult:
        try:
            page_size = max(1, min(page_size, 100))
            # DNA-2 + DNA-SCOPE
            fltr = self._op.build_search_filter({"userId": user_id, "hidden": False})
            total = await self._db.count(self._config.feed_items_index, fltr)
            items = await self._db.query(self._config.feed_items_index, fltr, page_size, page * page_size)

            scope_config = await self._load_config("")
            half_life = float(scope_config.get("decay_half_life_hours", self._config.decay_half_life_hours))

            decayed = []
            for item in items or []:
                parsed = self._op.parse_object_alternative(item)
                original = float(parsed.get("originalScore", 50))
                try:
                    created = datetime.fromisoformat(str(parsed.get("createdAt", "")))
                    parsed["currentScore"] = self._tier_calc.apply_decay(original, created, half_life)
                    parsed["tier"] = self._tier_calc.calculate_tier(parsed["currentScore"], scope_config)
                except (ValueError, TypeError):
                    pass
                decayed.append(parsed)

            tier_order = {"immediate": 0, "high": 1, "normal": 2, "low": 3}
            decayed.sort(key=lambda x: (tier_order.get(x.get("tier", "low"), 4), -float(x.get("currentScore", 0))))

            feed_page = FeedPage(
                items=decayed,
                total_count=total or 0,
                has_more=(page + 1) * page_size < (total or 0),
                cursor=decayed[-1].get("feedItemId") if decayed else None,
            )
            return DataProcessResult.ok(feed_page, "Feed retrieved")
        except Exception as e:
            return DataProcessResult.error(str(e))

    async def get_feed_by_type(self, user_id: str, source_type: str, page: int, page_size: int) -> DataProcessResult:
        try:
            page_size = max(1, min(page_size, 100))
            fltr = self._op.build_search_filter({"userId": user_id, "sourceType": source_type, "hidden": False})
            items = await self._db.query(self._config.feed_items_index, fltr, page_size, page * page_size)
            total = await self._db.count(self._config.feed_items_index, fltr)
            feed_page = FeedPage(
                items=[self._op.parse_object_alternative(i) for i in (items or [])],
                total_count=total or 0,
                has_more=(page + 1) * page_size < (total or 0),
            )
            return DataProcessResult.ok(feed_page, "Feed by type retrieved")
        except Exception as e:
            return DataProcessResult.error(str(e))

    async def refresh_feed(self, user_id: str) -> DataProcessResult:
        try:
            fltr = self._op.build_search_filter({"userId": user_id, "hidden": False})
            all_items = await self._db.query(self._config.feed_items_index, fltr, self._config.max_feed_size, 0)
            scope_config = await self._load_config("")
            half_life = float(scope_config.get("decay_half_life_hours", self._config.decay_half_life_hours))
            updated = 0

            for item in all_items or []:
                parsed = self._op.parse_object_alternative(item)
                try:
                    original = float(parsed.get("originalScore", 50))
                    created = datetime.fromisoformat(str(parsed["createdAt"]))
                    parsed["currentScore"] = self._tier_calc.apply_decay(original, created, half_life)
                    parsed["tier"] = self._tier_calc.calculate_tier(parsed["currentScore"], scope_config)
                    parsed["refreshedAt"] = datetime.now(timezone.utc).isoformat()
                    await self._db.upsert(self._config.feed_items_index, parsed["feedItemId"], parsed)
                    updated += 1
                except (ValueError, TypeError, KeyError):
                    continue

            await self._queue.publish("feed-events", {
                "eventType": "FeedUpdated", "userId": user_id,
                "itemsUpdated": updated, "timestamp": datetime.now(timezone.utc).isoformat(),
            })
            return DataProcessResult.ok({"userId": user_id, "itemsRefreshed": updated})
        except Exception as e:
            return DataProcessResult.error(str(e))

    # ─── Management ─────────────────────────────────────────────

    async def mark_seen(self, user_id: str, feed_item_id: str) -> DataProcessResult:
        try:
            item = await self._db.get_by_id(self._config.feed_items_index, feed_item_id)
            if not item:
                return DataProcessResult.error("Feed item not found")
            parsed = self._op.parse_object_alternative(item)
            if parsed.get("userId") != user_id:
                return DataProcessResult.error("Access denied — scope mismatch")
            parsed["seen"] = True
            parsed["seenAt"] = datetime.now(timezone.utc).isoformat()
            await self._db.upsert(self._config.feed_items_index, feed_item_id, parsed)
            return DataProcessResult.ok(True, "Marked as seen")
        except Exception as e:
            return DataProcessResult.error(str(e))

    async def hide_item(self, user_id: str, feed_item_id: str) -> DataProcessResult:
        try:
            item = await self._db.get_by_id(self._config.feed_items_index, feed_item_id)
            if not item:
                return DataProcessResult.error("Feed item not found")
            parsed = self._op.parse_object_alternative(item)
            if parsed.get("userId") != user_id:
                return DataProcessResult.error("Access denied — scope mismatch")
            parsed["hidden"] = True
            parsed["hiddenAt"] = datetime.now(timezone.utc).isoformat()
            await self._db.upsert(self._config.feed_items_index, feed_item_id, parsed)
            await self._queue.publish("feed-events", {
                "eventType": "FeedItemHidden", "feedItemId": feed_item_id,
                "userId": user_id, "timestamp": datetime.now(timezone.utc).isoformat(),
            })
            return DataProcessResult.ok(True, "Item hidden")
        except Exception as e:
            return DataProcessResult.error(str(e))

    async def expire_items(self) -> DataProcessResult:
        try:
            fltr = self._op.build_search_filter({"expiresAtBefore": datetime.now(timezone.utc).isoformat()})
            expired = await self._db.query(self._config.feed_items_index, fltr, 1000, 0)
            count = 0
            for item in expired or []:
                parsed = self._op.parse_object_alternative(item)
                fid = parsed.get("feedItemId")
                if fid:
                    await self._db.delete(self._config.feed_items_index, fid)
                    count += 1
            if count:
                await self._queue.publish("feed-events", {
                    "eventType": "FeedItemsExpired", "count": count,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                })
            return DataProcessResult.ok(count, f"Expired {count} items")
        except Exception as e:
            return DataProcessResult.error(str(e))

    async def reorder_feed(self, user_id: str) -> DataProcessResult:
        result = await self.refresh_feed(user_id)
        if result.success:
            await self._queue.publish("feed-events", {
                "eventType": "FeedReordered", "userId": user_id,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            })
        return result

    # ─── Config ─────────────────────────────────────────────────

    async def get_config(self, scope_id: str) -> DataProcessResult:
        config = await self._load_config(scope_id)
        return DataProcessResult.ok(config)

    async def update_config(self, scope_id: str, config: dict[str, Any]) -> DataProcessResult:
        try:
            doc = self._op.parse_object_alternative(config)
            doc["configId"] = f"feed-config-{scope_id}"
            doc["scopeId"] = scope_id
            doc["updatedAt"] = datetime.now(timezone.utc).isoformat()
            await self._db.upsert(self._config.feed_config_index, doc["configId"], doc)
            return DataProcessResult.ok(doc, "Config updated")
        except Exception as e:
            return DataProcessResult.error(str(e))

    # ─── Private ────────────────────────────────────────────────

    async def _load_config(self, scope_id: str) -> dict[str, Any]:
        try:
            config = await self._db.get_by_id(self._config.feed_config_index, f"feed-config-{scope_id}")
            if config:
                return self._op.parse_object_alternative(config)
        except Exception:
            pass
        return {
            "immediate_min_score": self._config.immediate_min_score,
            "high_min_score": self._config.high_min_score,
            "normal_min_score": self._config.normal_min_score,
            "decay_half_life_hours": self._config.decay_half_life_hours,
            "max_feed_size": self._config.max_feed_size,
        }
