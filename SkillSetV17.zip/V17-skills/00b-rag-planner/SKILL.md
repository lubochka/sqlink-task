---
name: rag-planner
description: AI-driven query planning and knowledge storage for RAG. Plans what context to fetch before AI calls and where to store results after.
triggers: rag plan, query plan, context planning, knowledge storage, ai librarian, rag query, storage plan
dependencies: [01-core-interfaces, 00a-rag-interfaces, 06-ai-providers, 07-ai-dispatcher]
layer: L6-RAG
genie-dna: Plans use ParseObjectAlternative for dynamic query params. Query results filtered via BuildSearchFilter. All returns use DataProcessResult.
---

# Skill 00b: RAG Planner
## AI-Driven Query Planning and Knowledge Storage for Retrieval-Augmented Generation

**Dependencies:** 01, 00a, 06, 07
**Layer:** L6: RAG
**Phase:** 4 (Memory Library)

---

## Overview

The RAG Planner is the "AI librarian" of XIIGen. Before any AI step executes, the Planner analyzes the task and generates a structured query plan — deciding which knowledge bases to search, what queries to run, and how to rank results. After execution completes, it generates a storage plan — deciding where and how to index the new knowledge for future retrieval.

This is the critical bridge between the generic RAG interfaces (Skill 00a) and the AI Context Service (Skill 16). Without it, AI calls would either get no context or require hardcoded retrieval logic per step type.

## Key Concepts

- **Query Plan** — A structured list of RAG queries to execute before an AI call, with priorities and relevance thresholds
- **Storage Plan** — A structured list of indexing operations to execute after an AI call, with collection targets and metadata
- **Planning Prompt** — The AI call that generates query/storage plans (meta-AI: AI planning for AI)
- **Plan Caching** — Similar tasks reuse cached plans (keyed by stepType + technology + intent hash)

---

## Primary Implementation (.NET 9)

### Models

```csharp
// File: XIIGen.Rag/Models/RagPlanModels.cs
namespace XIIGen.Rag.Models;

public record RagQueryPlan(
    string PlanId,
    string TaskDescription,
    List<PlannedQuery> Queries,
    string Reasoning,
    DateTime CreatedAt = default
)
{
    public DateTime CreatedAt { get; init; } = CreatedAt == default ? DateTime.UtcNow : CreatedAt;
}

public record PlannedQuery(
    string QueryText,
    string Collection,
    QueryStrategy Strategy,       // Vector, Graph, Hybrid
    int TopK,
    double RelevanceThreshold,    // 0.0-1.0, skip results below this
    int Priority,                 // 1=highest, execute in order
    Dictionary<string, object>? Filters = null
);

public enum QueryStrategy { Vector, Graph, Hybrid }

public record RagStoragePlan(
    string PlanId,
    string TaskDescription,
    List<PlannedStorage> StorageOps,
    string Reasoning,
    DateTime CreatedAt = default
)
{
    public DateTime CreatedAt { get; init; } = CreatedAt == default ? DateTime.UtcNow : CreatedAt;
}

public record PlannedStorage(
    string Collection,
    string NodeType,              // e.g., "react-component", "api-endpoint", "test-case"
    Dictionary<string, object> Metadata,
    List<string> Tags,
    StorageAction Action          // Store, Update, Link
);

public enum StorageAction { Store, Update, Link }

public record PlanCacheKey(
    string StepType,
    string Technology,
    string IntentHash               // SHA256 of task description normalized
);

public record PlanExecutionResult(
    RagQueryPlan Plan,
    List<RagQueryResult> Results,
    TimeSpan Duration
);

public record RagQueryResult(
    string QueryText,
    List<RagSearchResult> Hits,
    double AvgScore,
    TimeSpan QueryDuration
);
```

### Service Interface

```csharp
// File: XIIGen.Rag/Interfaces/IRagPlannerService.cs
namespace XIIGen.Rag.Interfaces;

/// <summary>
/// AI-driven RAG planner: generates query plans before AI execution
/// and storage plans after AI execution.
/// </summary>
public interface IRagPlannerService
{
    /// <summary>
    /// Generate a query plan for retrieving relevant context before an AI call.
    /// </summary>
    Task<DataProcessResult<RagQueryPlan>> PlanQueriesAsync(
        PlanQueryRequest request, CancellationToken ct = default);

    /// <summary>
    /// Execute a query plan against the RAG backend, returning aggregated results.
    /// </summary>
    Task<DataProcessResult<PlanExecutionResult>> ExecutePlanAsync(
        RagQueryPlan plan, CancellationToken ct = default);

    /// <summary>
    /// Generate a storage plan for indexing new knowledge after AI execution.
    /// </summary>
    Task<DataProcessResult<RagStoragePlan>> PlanStorageAsync(
        PlanStorageRequest request, CancellationToken ct = default);

    /// <summary>
    /// Execute a storage plan, indexing results into the RAG backend.
    /// </summary>
    Task<DataProcessResult<int>> ExecuteStoragePlanAsync(
        RagStoragePlan plan, string content, CancellationToken ct = default);

    /// <summary>
    /// Invalidate cached plans for a given step type or technology.
    /// </summary>
    Task InvalidateCacheAsync(string? stepType = null, string? technology = null,
        CancellationToken ct = default);
}

public record PlanQueryRequest(
    string TaskDescription,
    string StepType,              // e.g., "figma-parse", "ai-transform", "code-gen"
    string? Technology = null,     // e.g., "react", "dotnet", "vue"
    string? FlowContext = null,    // Previous step outputs summary
    Dictionary<string, object>? Hints = null  // Caller-provided search hints
);

public record PlanStorageRequest(
    string TaskDescription,
    string StepType,
    string GeneratedContent,       // The AI output to store
    string? Technology = null,
    double? QualityScore = null,   // From review step
    FeedbackRating? UserFeedback = null
);
```

### Service Implementation

```csharp
// File: XIIGen.Rag/Services/RagPlannerService.cs
namespace XIIGen.Rag.Services;

using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using XIIGen.Core.Enums;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;
using XIIGen.Rag.Interfaces;
using XIIGen.Rag.Models;
using Microsoft.Extensions.Logging;

public class RagPlannerService : IRagPlannerService
{
    private readonly IAiProvider _ai;
    private readonly IRagService _rag;
    private readonly IDatabaseService _db;
    private readonly ICacheService _cache;
    private readonly ILogger<RagPlannerService> _logger;

    private const string PlanCachePrefix = "rag-plan:";
    private const string PlanHistoryIndex = "xiigen-rag-plans";
    private static readonly TimeSpan CacheTtl = TimeSpan.FromHours(4);

    public RagPlannerService(
        IAiProvider ai, IRagService rag, IDatabaseService db,
        ICacheService cache, ILogger<RagPlannerService> logger)
    {
        _ai = ai;
        _rag = rag;
        _db = db;
        _cache = cache;
        _logger = logger;
    }

    public async Task<DataProcessResult<RagQueryPlan>> PlanQueriesAsync(
        PlanQueryRequest request, CancellationToken ct = default)
    {
        try
        {
            // 1. Check cache for similar plans
            var cacheKey = BuildCacheKey(request.StepType, request.Technology, request.TaskDescription);
            var cached = await _cache.GetAsync<RagQueryPlan>($"{PlanCachePrefix}{cacheKey}", ct);
            if (cached is not null)
            {
                _logger.LogDebug("RAG plan cache hit for {StepType}/{Tech}", request.StepType, request.Technology);
                return DataProcessResult<RagQueryPlan>.Success(cached);
            }

            // 2. Build planning prompt
            var prompt = BuildQueryPlanningPrompt(request);

            // 3. Call AI to generate plan
            var aiRequest = new AiRequest
            {
                SystemPrompt = QueryPlanSystemPrompt,
                Prompt = prompt,
                Temperature = 0.3f,  // Low temperature for structured planning
                MaxTokens = 2000,
                OutputFormat = "json"
            };

            var aiResponse = await _ai.CompleteAsync(aiRequest, ct);
            if (string.IsNullOrWhiteSpace(aiResponse.Content))
                return DataProcessResult<RagQueryPlan>.Error("AI returned empty plan");

            // 4. Parse plan from AI response
            var plan = ParseQueryPlan(aiResponse.Content, request.TaskDescription);
            if (plan is null)
                return DataProcessResult<RagQueryPlan>.Error("Failed to parse AI-generated query plan");

            // 5. Cache and persist
            await _cache.SetAsync($"{PlanCachePrefix}{cacheKey}", plan, CacheTtl, ct);
            await _db.UpsertAsync(PlanHistoryIndex, plan.PlanId, plan, ct);

            _logger.LogInformation("Generated RAG query plan {PlanId} with {Count} queries",
                plan.PlanId, plan.Queries.Count);

            return DataProcessResult<RagQueryPlan>.Success(plan);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "RagPlannerService.PlanQueriesAsync failed for {StepType}", request.StepType);
            return DataProcessResult<RagQueryPlan>.Error(ex.Message);
        }
    }

    public async Task<DataProcessResult<PlanExecutionResult>> ExecutePlanAsync(
        RagQueryPlan plan, CancellationToken ct = default)
    {
        try
        {
            var sw = System.Diagnostics.Stopwatch.StartNew();
            var results = new List<RagQueryResult>();

            // Execute queries in priority order, parallelize same-priority queries
            var queryGroups = plan.Queries
                .OrderBy(q => q.Priority)
                .GroupBy(q => q.Priority);

            foreach (var group in queryGroups)
            {
                var tasks = group.Select(async query =>
                {
                    var qSw = System.Diagnostics.Stopwatch.StartNew();
                    var hits = query.Strategy switch
                    {
                        QueryStrategy.Vector => await _rag.SearchVectorAsync(
                            query.QueryText, query.Collection, query.TopK, query.Filters, ct),
                        QueryStrategy.Graph => (await _rag.TraverseGraphAsync(
                            query.QueryText, "RELATES_TO", 2, ct))
                            .Select(g => new RagSearchResult(g.NodeId, JsonSerializer.Serialize(g.Properties), 1.0))
                            .ToList(),
                        QueryStrategy.Hybrid => await _rag.HybridSearchAsync(
                            query.QueryText, query.Collection, query.TopK, ct: ct),
                        _ => new List<RagSearchResult>()
                    };
                    qSw.Stop();

                    // Filter by relevance threshold
                    var filtered = hits.Where(h => h.Score >= query.RelevanceThreshold).ToList();

                    return new RagQueryResult(
                        query.QueryText, filtered,
                        filtered.Any() ? filtered.Average(h => h.Score) : 0,
                        qSw.Elapsed);
                });

                var groupResults = await Task.WhenAll(tasks);
                results.AddRange(groupResults);
            }

            sw.Stop();
            var execResult = new PlanExecutionResult(plan, results, sw.Elapsed);

            _logger.LogInformation("Executed RAG plan {PlanId}: {TotalHits} hits in {Duration}ms",
                plan.PlanId, results.Sum(r => r.Hits.Count), sw.ElapsedMilliseconds);

            return DataProcessResult<PlanExecutionResult>.Success(execResult);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "RagPlannerService.ExecutePlanAsync failed for plan {PlanId}", plan.PlanId);
            return DataProcessResult<PlanExecutionResult>.Error(ex.Message);
        }
    }

    public async Task<DataProcessResult<RagStoragePlan>> PlanStorageAsync(
        PlanStorageRequest request, CancellationToken ct = default)
    {
        try
        {
            var prompt = BuildStoragePlanningPrompt(request);
            var aiRequest = new AiRequest
            {
                SystemPrompt = StoragePlanSystemPrompt,
                Prompt = prompt,
                Temperature = 0.3f,
                MaxTokens = 1500,
                OutputFormat = "json"
            };

            var aiResponse = await _ai.CompleteAsync(aiRequest, ct);
            var plan = ParseStoragePlan(aiResponse.Content, request.TaskDescription);
            if (plan is null)
                return DataProcessResult<RagStoragePlan>.Error("Failed to parse storage plan");

            await _db.UpsertAsync(PlanHistoryIndex, plan.PlanId, plan, ct);
            return DataProcessResult<RagStoragePlan>.Success(plan);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "RagPlannerService.PlanStorageAsync failed");
            return DataProcessResult<RagStoragePlan>.Error(ex.Message);
        }
    }

    public async Task<DataProcessResult<int>> ExecuteStoragePlanAsync(
        RagStoragePlan plan, string content, CancellationToken ct = default)
    {
        try
        {
            int stored = 0;
            foreach (var op in plan.StorageOps)
            {
                switch (op.Action)
                {
                    case StorageAction.Store:
                        await _rag.StoreEmbeddingAsync(
                            Guid.NewGuid().ToString(), content, op.Collection, op.Metadata, ct);
                        stored++;
                        break;

                    case StorageAction.Link:
                        await _rag.StoreGraphNodeAsync(
                            Guid.NewGuid().ToString(), op.NodeType, op.Metadata,
                            edges: null, ct: ct);
                        stored++;
                        break;

                    case StorageAction.Update:
                        // Find existing and update
                        var existing = await _rag.SearchVectorAsync(
                            content[..Math.Min(200, content.Length)], op.Collection, 1, ct: ct);
                        if (existing.Any())
                        {
                            await _rag.StoreEmbeddingAsync(
                                existing[0].Id, content, op.Collection, op.Metadata, ct);
                            stored++;
                        }
                        break;
                }
            }

            _logger.LogInformation("Executed storage plan {PlanId}: {Count} items stored", plan.PlanId, stored);
            return DataProcessResult<int>.Success(stored);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "ExecuteStoragePlanAsync failed");
            return DataProcessResult<int>.Error(ex.Message);
        }
    }

    public async Task InvalidateCacheAsync(string? stepType = null, string? technology = null,
        CancellationToken ct = default)
    {
        var pattern = stepType is not null
            ? $"{PlanCachePrefix}{stepType}:{technology ?? "*"}"
            : $"{PlanCachePrefix}*";
        await _cache.DeletePatternAsync(pattern, ct);
        _logger.LogInformation("Invalidated RAG plan cache: {Pattern}", pattern);
    }

    // --- Private helpers ---

    private static string BuildCacheKey(string stepType, string? technology, string taskDescription)
    {
        var intent = SHA256.HashData(Encoding.UTF8.GetBytes(taskDescription.ToLowerInvariant().Trim()));
        var hash = Convert.ToHexString(intent)[..16];
        return $"{stepType}:{technology ?? "any"}:{hash}";
    }

    private static string BuildQueryPlanningPrompt(PlanQueryRequest request) =>
        $"""
        Task: {request.TaskDescription}
        Step Type: {request.StepType}
        Technology: {request.Technology ?? "not specified"}
        Flow Context: {request.FlowContext ?? "none"}
        Hints: {(request.Hints is not null ? JsonSerializer.Serialize(request.Hints) : "none")}

        Generate a RAG query plan. For each query specify:
        - queryText: the search query
        - collection: which knowledge base collection to search
        - strategy: "Vector", "Graph", or "Hybrid"
        - topK: number of results (3-10)
        - relevanceThreshold: minimum score (0.0-1.0)
        - priority: execution order (1=first)

        Available collections: code-examples, design-patterns, api-specs, 
        ui-components, test-cases, architecture-docs, user-feedback, flow-templates

        Respond with JSON only.
        """;

    private static string BuildStoragePlanningPrompt(PlanStorageRequest request) =>
        $"""
        Task completed: {request.TaskDescription}
        Step Type: {request.StepType}
        Technology: {request.Technology ?? "not specified"}
        Quality Score: {request.QualityScore?.ToString("F2") ?? "not scored"}
        User Feedback: {request.UserFeedback?.ToString() ?? "none"}
        Content Preview: {request.GeneratedContent[..Math.Min(500, request.GeneratedContent.Length)]}

        Generate a storage plan. For each storage operation specify:
        - collection: target knowledge base collection
        - nodeType: category of this knowledge
        - metadata: key-value pairs for filtering
        - tags: searchable tags
        - action: "Store" (new), "Update" (replace existing), or "Link" (graph edge)

        Only store if quality score >= 0.7 or user feedback is Positive.
        Respond with JSON only.
        """;

    private static RagQueryPlan? ParseQueryPlan(string json, string taskDescription)
    {
        try
        {
            var cleaned = json.Trim().TrimStart("```json".ToCharArray()).TrimEnd("```".ToCharArray()).Trim();
            var doc = JsonDocument.Parse(cleaned);
            var queries = new List<PlannedQuery>();

            foreach (var q in doc.RootElement.GetProperty("queries").EnumerateArray())
            {
                queries.Add(new PlannedQuery(
                    QueryText: q.GetProperty("queryText").GetString()!,
                    Collection: q.GetProperty("collection").GetString()!,
                    Strategy: Enum.Parse<QueryStrategy>(q.GetProperty("strategy").GetString()!, true),
                    TopK: q.TryGetProperty("topK", out var tk) ? tk.GetInt32() : 5,
                    RelevanceThreshold: q.TryGetProperty("relevanceThreshold", out var rt) ? rt.GetDouble() : 0.5,
                    Priority: q.TryGetProperty("priority", out var p) ? p.GetInt32() : 1
                ));
            }

            var reasoning = doc.RootElement.TryGetProperty("reasoning", out var r) ? r.GetString() ?? "" : "";

            return new RagQueryPlan(
                PlanId: $"qplan-{Guid.NewGuid():N}",
                TaskDescription: taskDescription,
                Queries: queries,
                Reasoning: reasoning
            );
        }
        catch { return null; }
    }

    private static RagStoragePlan? ParseStoragePlan(string json, string taskDescription)
    {
        try
        {
            var cleaned = json.Trim().TrimStart("```json".ToCharArray()).TrimEnd("```".ToCharArray()).Trim();
            var doc = JsonDocument.Parse(cleaned);
            var ops = new List<PlannedStorage>();

            foreach (var s in doc.RootElement.GetProperty("storageOps").EnumerateArray())
            {
                var metadata = new Dictionary<string, object>();
                if (s.TryGetProperty("metadata", out var md))
                    foreach (var prop in md.EnumerateObject())
                        metadata[prop.Name] = prop.Value.ToString();

                var tags = new List<string>();
                if (s.TryGetProperty("tags", out var t))
                    foreach (var tag in t.EnumerateArray())
                        tags.Add(tag.GetString()!);

                ops.Add(new PlannedStorage(
                    Collection: s.GetProperty("collection").GetString()!,
                    NodeType: s.GetProperty("nodeType").GetString()!,
                    Metadata: metadata,
                    Tags: tags,
                    Action: Enum.Parse<StorageAction>(s.GetProperty("action").GetString()!, true)
                ));
            }

            var reasoning = doc.RootElement.TryGetProperty("reasoning", out var r) ? r.GetString() ?? "" : "";

            return new RagStoragePlan(
                PlanId: $"splan-{Guid.NewGuid():N}",
                TaskDescription: taskDescription,
                StorageOps: ops,
                Reasoning: reasoning
            );
        }
        catch { return null; }
    }

    // --- System Prompts ---

    private const string QueryPlanSystemPrompt = """
        You are a RAG Query Planner for XIIGen, an AI-powered code generation platform.
        Your job is to decide what knowledge to retrieve before an AI code generation step.
        
        Think about:
        1. What similar code examples exist? (collection: code-examples, strategy: Vector)
        2. What design patterns apply? (collection: design-patterns, strategy: Hybrid)
        3. What related components exist? (collection: ui-components, strategy: Vector)
        4. What previous feedback exists? (collection: user-feedback, strategy: Vector)
        5. Are there relevant architecture docs? (collection: architecture-docs, strategy: Graph)
        6. Are there flow templates? (collection: flow-templates, strategy: Hybrid)
        
        Prioritize: feedback > code-examples > design-patterns > architecture-docs
        Only include queries that are relevant to the specific task.
        Respond with valid JSON: { "queries": [...], "reasoning": "..." }
        """;

    private const string StoragePlanSystemPrompt = """
        You are a RAG Storage Planner for XIIGen.
        Your job is to decide how to index AI-generated content for future retrieval.
        
        Rules:
        - Only store content with quality score >= 0.7 or positive user feedback
        - Tag with technology, step type, and domain keywords
        - Use "Link" action to connect related nodes in the graph
        - Use "Update" if similar content already exists (avoid duplicates)
        - Use "Store" for genuinely new content
        
        Respond with valid JSON: { "storageOps": [...], "reasoning": "..." }
        """;
}
```

### DI Registration

```csharp
// File: XIIGen.Rag/Extensions/RagPlannerExtensions.cs
namespace XIIGen.Rag.Extensions;

using Microsoft.Extensions.DependencyInjection;
using XIIGen.Rag.Interfaces;
using XIIGen.Rag.Services;

public static class RagPlannerExtensions
{
    public static IServiceCollection AddXIIGenRagPlanner(this IServiceCollection services)
    {
        services.AddSingleton<IRagPlannerService, RagPlannerService>();
        return services;
    }
}
```

### Elasticsearch Index

```json
{
  "settings": { "number_of_shards": 1, "number_of_replicas": 0 },
  "mappings": {
    "properties": {
      "planId": { "type": "keyword" },
      "taskDescription": { "type": "text" },
      "reasoning": { "type": "text" },
      "queries": { "type": "nested", "properties": {
        "queryText": { "type": "text" },
        "collection": { "type": "keyword" },
        "strategy": { "type": "keyword" },
        "topK": { "type": "integer" },
        "priority": { "type": "integer" }
      }},
      "storageOps": { "type": "nested", "properties": {
        "collection": { "type": "keyword" },
        "nodeType": { "type": "keyword" },
        "action": { "type": "keyword" },
        "tags": { "type": "keyword" }
      }},
      "createdAt": { "type": "date" }
    }
  }
}
```

---

## Tests

```csharp
public class RagPlannerServiceTests
{
    private readonly Mock<IAiProvider> _mockAi = new();
    private readonly Mock<IRagService> _mockRag = new();
    private readonly Mock<IDatabaseService> _mockDb = new();
    private readonly Mock<ICacheService> _mockCache = new();
    private readonly RagPlannerService _svc;

    public RagPlannerServiceTests()
    {
        _mockCache.Setup(c => c.GetAsync<RagQueryPlan>(It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync((RagQueryPlan?)null);
        _svc = new RagPlannerService(
            _mockAi.Object, _mockRag.Object, _mockDb.Object,
            _mockCache.Object, Mock.Of<ILogger<RagPlannerService>>());
    }

    [Fact]
    public async Task PlanQueries_ValidTask_ReturnsQueryPlan()
    {
        // Arrange
        _mockAi.Setup(a => a.CompleteAsync(It.IsAny<AiRequest>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new AiResponse { Content = """
                { "queries": [
                    { "queryText": "React login component", "collection": "code-examples",
                      "strategy": "Vector", "topK": 5, "relevanceThreshold": 0.6, "priority": 1 },
                    { "queryText": "JWT authentication pattern", "collection": "design-patterns",
                      "strategy": "Hybrid", "topK": 3, "relevanceThreshold": 0.5, "priority": 2 }
                ], "reasoning": "Login needs component examples and auth patterns" }
                """ });

        var request = new PlanQueryRequest("Generate React login page", "ai-transform", "react");

        // Act
        var result = await _svc.PlanQueriesAsync(request);

        // Assert
        Assert.True(result.IsSuccess);
        Assert.Equal(2, result.Data!.Queries.Count);
        Assert.Equal("code-examples", result.Data.Queries[0].Collection);
        Assert.Equal(QueryStrategy.Hybrid, result.Data.Queries[1].Strategy);
    }

    [Fact]
    public async Task PlanQueries_CacheHit_ReturnsCachedPlan()
    {
        // Arrange
        var cachedPlan = new RagQueryPlan("cached-1", "test", new List<PlannedQuery>(), "cached");
        _mockCache.Setup(c => c.GetAsync<RagQueryPlan>(It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(cachedPlan);

        // Act
        var result = await _svc.PlanQueriesAsync(new PlanQueryRequest("test", "test"));

        // Assert
        Assert.True(result.IsSuccess);
        Assert.Equal("cached-1", result.Data!.PlanId);
        _mockAi.Verify(a => a.CompleteAsync(It.IsAny<AiRequest>(), It.IsAny<CancellationToken>()), Times.Never);
    }

    [Fact]
    public async Task ExecutePlan_ParallelQueries_ReturnsAggregatedResults()
    {
        // Arrange
        _mockRag.Setup(r => r.SearchVectorAsync(It.IsAny<string>(), It.IsAny<string>(),
                It.IsAny<int>(), It.IsAny<Dictionary<string, object>?>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<RagSearchResult> {
                new("hit-1", "React login example", 0.85),
                new("hit-2", "Vue login example", 0.72)
            });

        var plan = new RagQueryPlan("test-plan", "test", new List<PlannedQuery> {
            new("React login", "code-examples", QueryStrategy.Vector, 5, 0.5, 1),
            new("login patterns", "design-patterns", QueryStrategy.Vector, 3, 0.5, 1)
        }, "test");

        // Act
        var result = await _svc.ExecutePlanAsync(plan);

        // Assert
        Assert.True(result.IsSuccess);
        Assert.Equal(2, result.Data!.Results.Count);
        Assert.All(result.Data.Results, r => Assert.NotEmpty(r.Hits));
    }

    [Fact]
    public async Task PlanStorage_HighQuality_GeneratesStorageOps()
    {
        // Arrange
        _mockAi.Setup(a => a.CompleteAsync(It.IsAny<AiRequest>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new AiResponse { Content = """
                { "storageOps": [
                    { "collection": "code-examples", "nodeType": "react-component",
                      "metadata": { "technology": "react", "type": "login" },
                      "tags": ["react", "login", "jwt"], "action": "Store" }
                ], "reasoning": "High quality React login, store for future reference" }
                """ });

        var request = new PlanStorageRequest("Generated React login", "ai-transform",
            "<div>Login Form</div>", "react", 0.85, FeedbackRating.Positive);

        // Act
        var result = await _svc.PlanStorageAsync(request);

        // Assert
        Assert.True(result.IsSuccess);
        Assert.Single(result.Data!.StorageOps);
        Assert.Equal(StorageAction.Store, result.Data.StorageOps[0].Action);
    }
}
```

---

## Alternatives

| Language | File | Framework | Key Differences |
|----------|------|-----------|-----------------|
| Node.js | `alternatives/nodejs/rag-planner.ts` | Fastify + TypeScript | async/await with Promise.all for parallel queries |
| Python | `alternatives/python/rag_planner.py` | FastAPI + asyncio | asyncio.gather for parallel, Pydantic models |
| Java | `alternatives/java/RagPlannerService.java` | Spring Boot 3 | CompletableFuture for parallel, Jackson for JSON |
| Rust | `alternatives/rust/rag_planner.rs` | Axum + tokio | tokio::join! for parallel, serde for JSON |
| PHP | `alternatives/php/RagPlannerService.php` | Laravel 11 | Fiber/Promise for async, json_decode for parsing |
