# Implement Skill 00b: RAG Planner

## Context
Read `skills/00b-rag-planner/SKILL.md` for the complete specification.

**Dependencies (must exist first):**
- `skills/01-core-interfaces/SKILL.md` → DataProcessResult<T>, IAiProvider, IDatabaseService, ICacheService
- `skills/00a-rag-interfaces/SKILL.md` → IRagService, RagSearchResult, RagGraphResult
- `skills/06-ai-providers/SKILL.md` → ClaudeProvider, GptProvider (any IAiProvider implementation)
- `skills/07-ai-dispatcher/SKILL.md` → AiDispatcher (optional, for multi-model planning)

## Steps

1. **Create models** in `XIIGen.Rag/Models/RagPlanModels.cs`:
   - `RagQueryPlan`, `PlannedQuery`, `QueryStrategy` enum
   - `RagStoragePlan`, `PlannedStorage`, `StorageAction` enum
   - `PlanQueryRequest`, `PlanStorageRequest`
   - `PlanExecutionResult`, `RagQueryResult`, `PlanCacheKey`

2. **Create interface** in `XIIGen.Rag/Interfaces/IRagPlannerService.cs`:
   - `PlanQueriesAsync(PlanQueryRequest)` → Returns AI-generated query plan
   - `ExecutePlanAsync(RagQueryPlan)` → Runs queries against RAG backend
   - `PlanStorageAsync(PlanStorageRequest)` → Returns AI-generated storage plan
   - `ExecuteStoragePlanAsync(RagStoragePlan, content)` → Indexes into RAG
   - `InvalidateCacheAsync()` → Clear cached plans

3. **Create service** in `XIIGen.Rag/Services/RagPlannerService.cs`:
   - Inject `IAiProvider`, `IRagService`, `IDatabaseService`, `ICacheService`
   - Query planning: Build prompt → Call AI (temp=0.3, json format) → Parse JSON → Cache → Return
   - Plan execution: Group by priority → Parallel execute per group → Filter by threshold → Aggregate
   - Storage planning: Build prompt → Call AI → Parse JSON → Persist
   - Cache key: SHA256 hash of task + stepType + technology (4-hour TTL)

4. **Create DI extension** in `XIIGen.Rag/Extensions/RagPlannerExtensions.cs`:
   ```csharp
   services.AddSingleton<IRagPlannerService, RagPlannerService>();
   ```

5. **Add API endpoints** in `XIIGen.Api/Endpoints/RagEndpoints.cs`:
   ```
   POST /api/rag/plan-queries    → PlanQueriesAsync
   POST /api/rag/execute-plan    → ExecutePlanAsync  
   POST /api/rag/plan-storage    → PlanStorageAsync
   ```

6. **Register in `Program.cs`:**
   ```csharp
   builder.Services.AddXIIGenRagPlanner();
   ```

7. **Create tests** in `XIIGen.Tests/RagPlannerServiceTests.cs`:
   - Test query plan generation with mock AI response
   - Test cache hit returns cached plan
   - Test parallel execution with mock RAG results
   - Test storage plan generation

## Key Design Decisions

- **AI-driven planning** (not hardcoded): The planner asks AI what queries are relevant, making it adaptable to any task type
- **Priority-based parallel execution**: Same-priority queries run in parallel, different priorities run sequentially
- **Cache by intent hash**: Similar tasks reuse plans without hitting AI again
- **Quality gate for storage**: Only store high-quality outputs (score >= 0.7 or positive feedback)

## Verification Checklist

- [ ] All methods return `DataProcessResult<T>`
- [ ] AI calls use low temperature (0.3) for consistent structured output
- [ ] JSON parsing handles ```json fences from AI responses
- [ ] Cache TTL is 4 hours
- [ ] Parallel execution respects priority ordering
- [ ] Storage only indexes quality content
- [ ] Elasticsearch index `xiigen-rag-plans` created on first write
- [ ] DI registration works
- [ ] All 4 tests pass with `dotnet test`


---

## Genie DNA Compliance — MANDATORY for All Implementations

> Before writing ANY code, classify each component:
> **MACHINE** (static): Infrastructure that enables freedom. Build once, generic, interface-based.
> **FREEDOM** (dynamic): Anything users define. No fixed models, config-driven.

### DNA Checklist — Every Implementation MUST:
☐ **DNA-1 (Dynamic Documents):** Store data as `Dictionary<string, object>` / `Record<string, any>` — NOT typed model classes. User fields preserved without schema changes.
☐ **DNA-2 (BuildSearchFilter):** All queries use BuildSearchFilter/equivalent. Empty fields auto-skipped. No entity-specific query code.
☐ **DNA-3 (MicroserviceBase):** Inherit base class with DB, queue, cache, logger built in.
☐ **DNA-5 (DataProcessResult):** All public methods return `DataProcessResult<T>`. Errors return failure, not throw exceptions.
☐ **DNA-6 (Generic Interfaces):** External dependencies behind interfaces. Swap via config.
☐ **DNA-SCOPE:** Non-admin queries auto-inject userId filter. Cannot be bypassed.

### The Three Tests:
1. Can a business user change this without a developer? (YES = correct)
2. Does it work for entity types that do not exist yet? (YES = correct)
3. Can I swap the database/service/UI without changing this? (YES = correct)
