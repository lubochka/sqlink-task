<?php
// XIIGen Skill 00b — RAG Planner (PHP/Laravel 11)
namespace App\Services\Rag;

use App\Services\Ai\AiProvider;
use App\Services\Database\DatabaseService;
use App\Services\Cache\CacheService;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

// --- Models ---
class PlannedQuery {
    public function __construct(
        public string $queryText,
        public string $collection,
        public string $strategy,  // Vector, Graph, Hybrid
        public int $topK = 5,
        public float $relevanceThreshold = 0.5,
        public int $priority = 1,
        public ?array $filters = null
    ) {}
}

class RagQueryPlan {
    public function __construct(
        public string $planId,
        public string $taskDescription,
        public array $queries,      // PlannedQuery[]
        public string $reasoning,
        public string $createdAt
    ) {
        $this->createdAt = $createdAt ?: now()->toIso8601String();
    }
}

class PlannedStorage {
    public function __construct(
        public string $collection,
        public string $nodeType,
        public array $metadata,
        public array $tags,
        public string $action  // Store, Update, Link
    ) {}
}

class RagStoragePlan {
    public function __construct(
        public string $planId,
        public string $taskDescription,
        public array $storageOps,  // PlannedStorage[]
        public string $reasoning,
        public string $createdAt = ''
    ) {
        $this->createdAt = $createdAt ?: now()->toIso8601String();
    }
}

// --- Service ---
class RagPlannerService {
    private const PLAN_INDEX = 'xiigen-rag-plans';
    private const CACHE_PREFIX = 'rag-plan:';
    private const CACHE_TTL = 14400; // 4 hours

    public function __construct(
        private AiProvider $ai,
        private RagService $rag,
        private DatabaseService $db,
        private CacheService $cache
    ) {}

    public function planQueries(array $request): array
    {
        try {
            $cacheKey = $this->buildCacheKey(
                $request['stepType'], $request['technology'] ?? null, $request['taskDescription']
            );
            $cached = $this->cache->get(self::CACHE_PREFIX . $cacheKey);
            if ($cached) {
                return ['status' => 'Success', 'data' => $cached];
            }

            $prompt = $this->buildQueryPlanningPrompt($request);
            $aiResponse = $this->ai->complete([
                'systemPrompt' => self::QUERY_PLAN_SYSTEM_PROMPT,
                'prompt' => $prompt,
                'temperature' => 0.3,
                'maxTokens' => 2000,
                'outputFormat' => 'json',
            ]);

            if (empty($aiResponse['content'])) {
                return ['status' => 'Error', 'message' => 'AI returned empty plan'];
            }

            $plan = $this->parseQueryPlan($aiResponse['content'], $request['taskDescription']);
            if (!$plan) {
                return ['status' => 'Error', 'message' => 'Failed to parse query plan'];
            }

            $this->cache->set(self::CACHE_PREFIX . $cacheKey, $plan, self::CACHE_TTL);
            $this->db->upsert(self::PLAN_INDEX, $plan->planId, (array)$plan);

            Log::info("Generated RAG plan {$plan->planId} with " . count($plan->queries) . " queries");
            return ['status' => 'Success', 'data' => $plan];
        } catch (\Exception $e) {
            Log::error("planQueries failed: " . $e->getMessage());
            return ['status' => 'Error', 'message' => $e->getMessage()];
        }
    }

    public function executePlan(RagQueryPlan $plan): array
    {
        try {
            $start = microtime(true);
            $results = [];

            $groups = [];
            foreach ($plan->queries as $q) {
                $groups[$q->priority][] = $q;
            }
            ksort($groups);

            foreach ($groups as $queries) {
                // PHP doesn't have true parallel async, but we can use Fiber or process sequentially
                foreach ($queries as $query) {
                    $qStart = microtime(true);
                    $hits = match ($query->strategy) {
                        'Vector' => $this->rag->searchVector($query->queryText, $query->collection, $query->topK, $query->filters),
                        'Graph' => array_map(fn($g) => [
                            'id' => $g['nodeId'], 'text' => json_encode($g['properties']), 'score' => 1.0
                        ], $this->rag->traverseGraph($query->queryText, 'RELATES_TO', 2)),
                        'Hybrid' => $this->rag->hybridSearch($query->queryText, $query->collection, $query->topK),
                        default => [],
                    };

                    $filtered = array_filter($hits, fn($h) => ($h['score'] ?? 0) >= $query->relevanceThreshold);
                    $filtered = array_values($filtered);
                    $avgScore = count($filtered) > 0
                        ? array_sum(array_column($filtered, 'score')) / count($filtered) : 0;

                    $results[] = [
                        'queryText' => $query->queryText,
                        'hits' => $filtered,
                        'avgScore' => $avgScore,
                        'queryDurationMs' => (microtime(true) - $qStart) * 1000,
                    ];
                }
            }

            return [
                'status' => 'Success',
                'data' => [
                    'plan' => $plan,
                    'results' => $results,
                    'durationMs' => (microtime(true) - $start) * 1000,
                ],
            ];
        } catch (\Exception $e) {
            return ['status' => 'Error', 'message' => $e->getMessage()];
        }
    }

    public function planStorage(array $request): array
    {
        try {
            $prompt = $this->buildStoragePlanningPrompt($request);
            $aiResponse = $this->ai->complete([
                'systemPrompt' => self::STORAGE_PLAN_SYSTEM_PROMPT,
                'prompt' => $prompt,
                'temperature' => 0.3,
                'maxTokens' => 1500,
                'outputFormat' => 'json',
            ]);

            $plan = $this->parseStoragePlan($aiResponse['content'], $request['taskDescription']);
            if (!$plan) {
                return ['status' => 'Error', 'message' => 'Failed to parse storage plan'];
            }

            $this->db->upsert(self::PLAN_INDEX, $plan->planId, (array)$plan);
            return ['status' => 'Success', 'data' => $plan];
        } catch (\Exception $e) {
            return ['status' => 'Error', 'message' => $e->getMessage()];
        }
    }

    public function executeStoragePlan(RagStoragePlan $plan, string $content): array
    {
        try {
            $stored = 0;
            foreach ($plan->storageOps as $op) {
                match ($op->action) {
                    'Store' => (function() use ($op, $content, &$stored) {
                        $this->rag->storeEmbedding(Str::uuid(), $content, $op->collection, $op->metadata);
                        $stored++;
                    })(),
                    'Link' => (function() use ($op, &$stored) {
                        $this->rag->storeGraphNode(Str::uuid(), $op->nodeType, $op->metadata);
                        $stored++;
                    })(),
                    'Update' => (function() use ($op, $content, &$stored) {
                        $existing = $this->rag->searchVector(substr($content, 0, 200), $op->collection, 1);
                        if (!empty($existing)) {
                            $this->rag->storeEmbedding($existing[0]['id'], $content, $op->collection, $op->metadata);
                            $stored++;
                        }
                    })(),
                };
            }
            return ['status' => 'Success', 'data' => $stored];
        } catch (\Exception $e) {
            return ['status' => 'Error', 'message' => $e->getMessage()];
        }
    }

    // --- Helpers ---
    private function buildCacheKey(string $stepType, ?string $tech, string $task): string
    {
        $hash = substr(hash('sha256', strtolower(trim($task))), 0, 16);
        return "{$stepType}:" . ($tech ?? 'any') . ":{$hash}";
    }

    private function buildQueryPlanningPrompt(array $req): string
    {
        return "Task: {$req['taskDescription']}\nStep: {$req['stepType']}\nTech: " .
            ($req['technology'] ?? 'any') . "\nContext: " . ($req['flowContext'] ?? 'none') .
            "\n\nGenerate RAG query plan as JSON.";
    }

    private function buildStoragePlanningPrompt(array $req): string
    {
        return "Task: {$req['taskDescription']}\nStep: {$req['stepType']}\nQuality: " .
            ($req['qualityScore'] ?? 'unscored') . "\nContent: " .
            substr($req['generatedContent'], 0, 500) . "\n\nGenerate storage plan as JSON.";
    }

    private function parseQueryPlan(string $json, string $task): ?RagQueryPlan
    {
        try {
            $cleaned = trim(str_replace(['```json', '```'], '', $json));
            $parsed = json_decode($cleaned, true, 512, JSON_THROW_ON_ERROR);
            $queries = array_map(fn($q) => new PlannedQuery(
                queryText: $q['queryText'],
                collection: $q['collection'],
                strategy: $q['strategy'] ?? 'Vector',
                topK: $q['topK'] ?? 5,
                relevanceThreshold: $q['relevanceThreshold'] ?? 0.5,
                priority: $q['priority'] ?? 1,
            ), $parsed['queries']);

            return new RagQueryPlan(
                planId: 'qplan-' . Str::uuid()->toString(),
                taskDescription: $task,
                queries: $queries,
                reasoning: $parsed['reasoning'] ?? '',
            );
        } catch (\Exception) {
            return null;
        }
    }

    private function parseStoragePlan(string $json, string $task): ?RagStoragePlan
    {
        try {
            $cleaned = trim(str_replace(['```json', '```'], '', $json));
            $parsed = json_decode($cleaned, true, 512, JSON_THROW_ON_ERROR);
            $ops = array_map(fn($s) => new PlannedStorage(
                collection: $s['collection'],
                nodeType: $s['nodeType'],
                metadata: $s['metadata'] ?? [],
                tags: $s['tags'] ?? [],
                action: $s['action'] ?? 'Store',
            ), $parsed['storageOps']);

            return new RagStoragePlan(
                planId: 'splan-' . Str::uuid()->toString(),
                taskDescription: $task,
                storageOps: $ops,
                reasoning: $parsed['reasoning'] ?? '',
            );
        } catch (\Exception) {
            return null;
        }
    }

    private const QUERY_PLAN_SYSTEM_PROMPT = "You are a RAG Query Planner for XIIGen. Generate JSON with 'queries' array. Collections: code-examples, design-patterns, api-specs, ui-components, test-cases, architecture-docs, user-feedback, flow-templates.";
    private const STORAGE_PLAN_SYSTEM_PROMPT = "You are a RAG Storage Planner. Generate JSON with 'storageOps'. Only store quality >= 0.7 or positive feedback.";
}

// --- Routes (routes/api.php) ---
// Route::prefix('api/rag')->group(function () {
//     Route::post('/plan-queries', [RagPlannerController::class, 'planQueries']);
//     Route::post('/execute-plan', [RagPlannerController::class, 'executePlan']);
//     Route::post('/plan-storage', [RagPlannerController::class, 'planStorage']);
// });
