// XIIGen Skill 00b — RAG Planner (Node.js/Fastify)
import { FastifyInstance } from 'fastify';
import { createHash } from 'crypto';

// --- Models ---
interface PlannedQuery {
  queryText: string;
  collection: string;
  strategy: 'Vector' | 'Graph' | 'Hybrid';
  topK: number;
  relevanceThreshold: number;
  priority: number;
  filters?: Record<string, any>;
}

interface RagQueryPlan {
  planId: string;
  taskDescription: string;
  queries: PlannedQuery[];
  reasoning: string;
  createdAt: Date;
}

interface PlannedStorage {
  collection: string;
  nodeType: string;
  metadata: Record<string, any>;
  tags: string[];
  action: 'Store' | 'Update' | 'Link';
}

interface RagStoragePlan {
  planId: string;
  taskDescription: string;
  storageOps: PlannedStorage[];
  reasoning: string;
  createdAt: Date;
}

interface PlanQueryRequest {
  taskDescription: string;
  stepType: string;
  technology?: string;
  flowContext?: string;
  hints?: Record<string, any>;
}

interface PlanStorageRequest {
  taskDescription: string;
  stepType: string;
  generatedContent: string;
  technology?: string;
  qualityScore?: number;
  userFeedback?: 'Positive' | 'Neutral' | 'Negative';
}

interface PlanExecutionResult {
  plan: RagQueryPlan;
  results: { queryText: string; hits: any[]; avgScore: number; queryDurationMs: number }[];
  durationMs: number;
}

// --- Service ---
class RagPlannerService {
  constructor(
    private ai: IAiProvider,
    private rag: IRagService,
    private db: IDatabaseService,
    private cache: ICacheService,
    private logger: any
  ) {}

  async planQueries(request: PlanQueryRequest): Promise<DataProcessResult<RagQueryPlan>> {
    try {
      const cacheKey = this.buildCacheKey(request.stepType, request.technology, request.taskDescription);
      const cached = await this.cache.get<RagQueryPlan>(`rag-plan:${cacheKey}`);
      if (cached) return { status: 'Success', data: cached };

      const prompt = this.buildQueryPlanningPrompt(request);
      const aiResponse = await this.ai.complete({
        systemPrompt: QUERY_PLAN_SYSTEM_PROMPT,
        prompt,
        temperature: 0.3,
        maxTokens: 2000,
        outputFormat: 'json'
      });

      if (!aiResponse.content) return { status: 'Error', message: 'AI returned empty plan' };

      const plan = this.parseQueryPlan(aiResponse.content, request.taskDescription);
      if (!plan) return { status: 'Error', message: 'Failed to parse query plan' };

      await this.cache.set(`rag-plan:${cacheKey}`, plan, 4 * 3600);
      await this.db.upsert('xiigen-rag-plans', plan.planId, plan);

      this.logger.info(`Generated RAG query plan ${plan.planId} with ${plan.queries.length} queries`);
      return { status: 'Success', data: plan };
    } catch (error: any) {
      this.logger.error(`PlanQueries failed: ${error.message}`);
      return { status: 'Error', message: error.message };
    }
  }

  async executePlan(plan: RagQueryPlan): Promise<DataProcessResult<PlanExecutionResult>> {
    try {
      const start = Date.now();
      const results: PlanExecutionResult['results'] = [];

      const groups = new Map<number, PlannedQuery[]>();
      for (const q of plan.queries.sort((a, b) => a.priority - b.priority)) {
        const group = groups.get(q.priority) ?? [];
        group.push(q);
        groups.set(q.priority, group);
      }

      for (const [, queries] of [...groups].sort(([a], [b]) => a - b)) {
        const groupResults = await Promise.all(queries.map(async (query) => {
          const qStart = Date.now();
          let hits: any[];

          switch (query.strategy) {
            case 'Vector':
              hits = await this.rag.searchVector(query.queryText, query.collection, query.topK, query.filters);
              break;
            case 'Graph':
              const graphHits = await this.rag.traverseGraph(query.queryText, 'RELATES_TO', 2);
              hits = graphHits.map(g => ({ id: g.nodeId, text: JSON.stringify(g.properties), score: 1.0 }));
              break;
            case 'Hybrid':
              hits = await this.rag.hybridSearch(query.queryText, query.collection, query.topK);
              break;
            default:
              hits = [];
          }

          const filtered = hits.filter(h => h.score >= query.relevanceThreshold);
          return {
            queryText: query.queryText,
            hits: filtered,
            avgScore: filtered.length > 0 ? filtered.reduce((s, h) => s + h.score, 0) / filtered.length : 0,
            queryDurationMs: Date.now() - qStart
          };
        }));
        results.push(...groupResults);
      }

      return {
        status: 'Success',
        data: { plan, results, durationMs: Date.now() - start }
      };
    } catch (error: any) {
      return { status: 'Error', message: error.message };
    }
  }

  async planStorage(request: PlanStorageRequest): Promise<DataProcessResult<RagStoragePlan>> {
    try {
      const prompt = this.buildStoragePlanningPrompt(request);
      const aiResponse = await this.ai.complete({
        systemPrompt: STORAGE_PLAN_SYSTEM_PROMPT,
        prompt,
        temperature: 0.3,
        maxTokens: 1500,
        outputFormat: 'json'
      });

      const plan = this.parseStoragePlan(aiResponse.content, request.taskDescription);
      if (!plan) return { status: 'Error', message: 'Failed to parse storage plan' };

      await this.db.upsert('xiigen-rag-plans', plan.planId, plan);
      return { status: 'Success', data: plan };
    } catch (error: any) {
      return { status: 'Error', message: error.message };
    }
  }

  async executeStoragePlan(plan: RagStoragePlan, content: string): Promise<DataProcessResult<number>> {
    try {
      let stored = 0;
      for (const op of plan.storageOps) {
        if (op.action === 'Store') {
          await this.rag.storeEmbedding(crypto.randomUUID(), content, op.collection, op.metadata);
          stored++;
        } else if (op.action === 'Link') {
          await this.rag.storeGraphNode(crypto.randomUUID(), op.nodeType, op.metadata);
          stored++;
        } else if (op.action === 'Update') {
          const existing = await this.rag.searchVector(content.slice(0, 200), op.collection, 1);
          if (existing.length > 0) {
            await this.rag.storeEmbedding(existing[0].id, content, op.collection, op.metadata);
            stored++;
          }
        }
      }
      return { status: 'Success', data: stored };
    } catch (error: any) {
      return { status: 'Error', message: error.message };
    }
  }

  private buildCacheKey(stepType: string, technology: string | undefined, task: string): string {
    const hash = createHash('sha256').update(task.toLowerCase().trim()).digest('hex').slice(0, 16);
    return `${stepType}:${technology ?? 'any'}:${hash}`;
  }

  private buildQueryPlanningPrompt(req: PlanQueryRequest): string {
    return `Task: ${req.taskDescription}\nStep Type: ${req.stepType}\nTechnology: ${req.technology ?? 'not specified'}\nFlow Context: ${req.flowContext ?? 'none'}\n\nGenerate a RAG query plan as JSON with "queries" array and "reasoning".`;
  }

  private buildStoragePlanningPrompt(req: PlanStorageRequest): string {
    return `Task: ${req.taskDescription}\nStep: ${req.stepType}\nQuality: ${req.qualityScore ?? 'unscored'}\nFeedback: ${req.userFeedback ?? 'none'}\nContent: ${req.generatedContent.slice(0, 500)}\n\nGenerate storage plan as JSON with "storageOps" array and "reasoning".`;
  }

  private parseQueryPlan(json: string, task: string): RagQueryPlan | null {
    try {
      const cleaned = json.replace(/```json|```/g, '').trim();
      const parsed = JSON.parse(cleaned);
      return {
        planId: `qplan-${crypto.randomUUID().replace(/-/g, '')}`,
        taskDescription: task,
        queries: parsed.queries,
        reasoning: parsed.reasoning ?? '',
        createdAt: new Date()
      };
    } catch { return null; }
  }

  private parseStoragePlan(json: string, task: string): RagStoragePlan | null {
    try {
      const cleaned = json.replace(/```json|```/g, '').trim();
      const parsed = JSON.parse(cleaned);
      return {
        planId: `splan-${crypto.randomUUID().replace(/-/g, '')}`,
        taskDescription: task,
        storageOps: parsed.storageOps,
        reasoning: parsed.reasoning ?? '',
        createdAt: new Date()
      };
    } catch { return null; }
  }
}

// --- Fastify Plugin ---
export default async function ragPlannerPlugin(app: FastifyInstance) {
  const svc = new RagPlannerService(app.ai, app.rag, app.db, app.cache, app.log);

  app.post<{ Body: PlanQueryRequest }>('/api/rag/plan-queries', async (req) => {
    return svc.planQueries(req.body);
  });

  app.post<{ Body: { plan: RagQueryPlan } }>('/api/rag/execute-plan', async (req) => {
    return svc.executePlan(req.body.plan);
  });

  app.post<{ Body: PlanStorageRequest }>('/api/rag/plan-storage', async (req) => {
    return svc.planStorage(req.body);
  });
}

const QUERY_PLAN_SYSTEM_PROMPT = `You are a RAG Query Planner for XIIGen. Generate JSON query plans with "queries" array. Available collections: code-examples, design-patterns, api-specs, ui-components, test-cases, architecture-docs, user-feedback, flow-templates.`;

const STORAGE_PLAN_SYSTEM_PROMPT = `You are a RAG Storage Planner for XIIGen. Generate JSON storage plans with "storageOps" array. Only store content with quality >= 0.7 or positive feedback.`;
