// XIIGen Skill 00b — RAG Planner (Java/Spring Boot 3)
package com.xiigen.rag;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

// --- Models ---
record PlannedQuery(String queryText, String collection, String strategy,
                    int topK, double relevanceThreshold, int priority,
                    Map<String, Object> filters) {}

record RagQueryPlan(String planId, String taskDescription, List<PlannedQuery> queries,
                    String reasoning, Instant createdAt) {}

record PlannedStorage(String collection, String nodeType, Map<String, Object> metadata,
                      List<String> tags, String action) {}

record RagStoragePlan(String planId, String taskDescription, List<PlannedStorage> storageOps,
                      String reasoning, Instant createdAt) {}

record PlanQueryRequest(String taskDescription, String stepType, String technology,
                        String flowContext, Map<String, Object> hints) {}

record PlanStorageRequest(String taskDescription, String stepType, String generatedContent,
                          String technology, Double qualityScore, String userFeedback) {}

record RagQueryResult(String queryText, List<Map<String, Object>> hits,
                      double avgScore, long queryDurationMs) {}

record PlanExecutionResult(RagQueryPlan plan, List<RagQueryResult> results, long durationMs) {}

// --- Service ---
@Service
public class RagPlannerService {
    private static final Logger log = LoggerFactory.getLogger(RagPlannerService.class);
    private static final String PLAN_INDEX = "xiigen-rag-plans";
    private static final String CACHE_PREFIX = "rag-plan:";
    private static final ObjectMapper mapper = new ObjectMapper();

    private final AiProvider ai;
    private final RagService rag;
    private final DatabaseService db;
    private final CacheService cache;

    public RagPlannerService(AiProvider ai, RagService rag, DatabaseService db, CacheService cache) {
        this.ai = ai;
        this.rag = rag;
        this.db = db;
        this.cache = cache;
    }

    public DataProcessResult<RagQueryPlan> planQueries(PlanQueryRequest request) {
        try {
            String cacheKey = buildCacheKey(request.stepType(), request.technology(), request.taskDescription());
            var cached = cache.get(CACHE_PREFIX + cacheKey, RagQueryPlan.class);
            if (cached != null) return DataProcessResult.success(cached);

            String prompt = buildQueryPlanningPrompt(request);
            var aiResponse = ai.complete(Map.of(
                "systemPrompt", QUERY_PLAN_SYSTEM_PROMPT,
                "prompt", prompt,
                "temperature", 0.3,
                "maxTokens", 2000,
                "outputFormat", "json"
            ));

            if (aiResponse.content() == null || aiResponse.content().isBlank())
                return DataProcessResult.error("AI returned empty plan");

            var plan = parseQueryPlan(aiResponse.content(), request.taskDescription());
            if (plan == null) return DataProcessResult.error("Failed to parse query plan");

            cache.set(CACHE_PREFIX + cacheKey, plan, 4 * 3600);
            db.upsert(PLAN_INDEX, plan.planId(), plan);

            log.info("Generated RAG plan {} with {} queries", plan.planId(), plan.queries().size());
            return DataProcessResult.success(plan);
        } catch (Exception e) {
            log.error("planQueries failed", e);
            return DataProcessResult.error(e.getMessage());
        }
    }

    public DataProcessResult<PlanExecutionResult> executePlan(RagQueryPlan plan) {
        try {
            long start = System.currentTimeMillis();
            var results = new ArrayList<RagQueryResult>();

            var groups = plan.queries().stream()
                .sorted(Comparator.comparingInt(PlannedQuery::priority))
                .collect(Collectors.groupingBy(PlannedQuery::priority, TreeMap::new, Collectors.toList()));

            for (var entry : groups.entrySet()) {
                var futures = entry.getValue().stream()
                    .map(q -> CompletableFuture.supplyAsync(() -> executeSingleQuery(q)))
                    .toList();
                var groupResults = futures.stream()
                    .map(CompletableFuture::join)
                    .toList();
                results.addAll(groupResults);
            }

            long durationMs = System.currentTimeMillis() - start;
            return DataProcessResult.success(new PlanExecutionResult(plan, results, durationMs));
        } catch (Exception e) {
            return DataProcessResult.error(e.getMessage());
        }
    }

    private RagQueryResult executeSingleQuery(PlannedQuery query) {
        long start = System.currentTimeMillis();
        List<Map<String, Object>> hits;

        switch (query.strategy()) {
            case "Vector" -> hits = rag.searchVector(query.queryText(), query.collection(), query.topK(), query.filters());
            case "Graph" -> {
                var graphHits = rag.traverseGraph(query.queryText(), "RELATES_TO", 2);
                hits = graphHits.stream().map(g -> Map.<String, Object>of(
                    "id", g.get("nodeId"), "text", g.get("properties").toString(), "score", 1.0
                )).toList();
            }
            case "Hybrid" -> hits = rag.hybridSearch(query.queryText(), query.collection(), query.topK());
            default -> hits = List.of();
        }

        var filtered = hits.stream()
            .filter(h -> ((Number) h.getOrDefault("score", 0.0)).doubleValue() >= query.relevanceThreshold())
            .toList();
        double avgScore = filtered.isEmpty() ? 0 :
            filtered.stream().mapToDouble(h -> ((Number) h.get("score")).doubleValue()).average().orElse(0);

        return new RagQueryResult(query.queryText(), filtered, avgScore, System.currentTimeMillis() - start);
    }

    public DataProcessResult<RagStoragePlan> planStorage(PlanStorageRequest request) {
        try {
            String prompt = buildStoragePlanningPrompt(request);
            var aiResponse = ai.complete(Map.of(
                "systemPrompt", STORAGE_PLAN_SYSTEM_PROMPT,
                "prompt", prompt, "temperature", 0.3, "maxTokens", 1500, "outputFormat", "json"
            ));

            var plan = parseStoragePlan(aiResponse.content(), request.taskDescription());
            if (plan == null) return DataProcessResult.error("Failed to parse storage plan");

            db.upsert(PLAN_INDEX, plan.planId(), plan);
            return DataProcessResult.success(plan);
        } catch (Exception e) {
            return DataProcessResult.error(e.getMessage());
        }
    }

    public DataProcessResult<Integer> executeStoragePlan(RagStoragePlan plan, String content) {
        try {
            int stored = 0;
            for (var op : plan.storageOps()) {
                switch (op.action()) {
                    case "Store" -> { rag.storeEmbedding(UUID.randomUUID().toString(), content, op.collection(), op.metadata()); stored++; }
                    case "Link" -> { rag.storeGraphNode(UUID.randomUUID().toString(), op.nodeType(), op.metadata()); stored++; }
                    case "Update" -> {
                        var existing = rag.searchVector(content.substring(0, Math.min(200, content.length())), op.collection(), 1, null);
                        if (!existing.isEmpty()) { rag.storeEmbedding(existing.get(0).get("id").toString(), content, op.collection(), op.metadata()); stored++; }
                    }
                }
            }
            return DataProcessResult.success(stored);
        } catch (Exception e) {
            return DataProcessResult.error(e.getMessage());
        }
    }

    // --- Helpers ---
    private String buildCacheKey(String stepType, String tech, String task) {
        try {
            var digest = MessageDigest.getInstance("SHA-256");
            var hash = digest.digest(task.toLowerCase().trim().getBytes(StandardCharsets.UTF_8));
            var hex = bytesToHex(hash).substring(0, 16);
            return stepType + ":" + (tech != null ? tech : "any") + ":" + hex;
        } catch (Exception e) { return stepType + ":any:fallback"; }
    }

    private static String bytesToHex(byte[] bytes) {
        var sb = new StringBuilder();
        for (byte b : bytes) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    private String buildQueryPlanningPrompt(PlanQueryRequest req) {
        return "Task: " + req.taskDescription() + "\nStep: " + req.stepType() +
            "\nTech: " + (req.technology() != null ? req.technology() : "any") +
            "\nContext: " + (req.flowContext() != null ? req.flowContext() : "none") +
            "\n\nGenerate RAG query plan as JSON.";
    }

    private String buildStoragePlanningPrompt(PlanStorageRequest req) {
        return "Task: " + req.taskDescription() + "\nStep: " + req.stepType() +
            "\nQuality: " + (req.qualityScore() != null ? req.qualityScore() : "unscored") +
            "\nContent: " + req.generatedContent().substring(0, Math.min(500, req.generatedContent().length())) +
            "\n\nGenerate storage plan as JSON.";
    }

    private RagQueryPlan parseQueryPlan(String json, String task) {
        try {
            var cleaned = json.replaceAll("```json|```", "").trim();
            var root = mapper.readTree(cleaned);
            var queries = new ArrayList<PlannedQuery>();
            for (var q : root.get("queries")) {
                queries.add(new PlannedQuery(
                    q.get("queryText").asText(), q.get("collection").asText(),
                    q.has("strategy") ? q.get("strategy").asText() : "Vector",
                    q.has("topK") ? q.get("topK").asInt() : 5,
                    q.has("relevanceThreshold") ? q.get("relevanceThreshold").asDouble() : 0.5,
                    q.has("priority") ? q.get("priority").asInt() : 1, null
                ));
            }
            return new RagQueryPlan("qplan-" + UUID.randomUUID().toString().replace("-", ""),
                task, queries, root.has("reasoning") ? root.get("reasoning").asText() : "", Instant.now());
        } catch (Exception e) { return null; }
    }

    private RagStoragePlan parseStoragePlan(String json, String task) {
        try {
            var cleaned = json.replaceAll("```json|```", "").trim();
            var root = mapper.readTree(cleaned);
            var ops = new ArrayList<PlannedStorage>();
            for (var s : root.get("storageOps")) {
                var meta = new HashMap<String, Object>();
                if (s.has("metadata")) s.get("metadata").fields().forEachRemaining(f -> meta.put(f.getKey(), f.getValue().asText()));
                var tags = new ArrayList<String>();
                if (s.has("tags")) s.get("tags").forEach(t -> tags.add(t.asText()));
                ops.add(new PlannedStorage(s.get("collection").asText(), s.get("nodeType").asText(), meta, tags, s.get("action").asText()));
            }
            return new RagStoragePlan("splan-" + UUID.randomUUID().toString().replace("-", ""),
                task, ops, root.has("reasoning") ? root.get("reasoning").asText() : "", Instant.now());
        } catch (Exception e) { return null; }
    }

    private static final String QUERY_PLAN_SYSTEM_PROMPT = "You are a RAG Query Planner for XIIGen. Generate JSON with 'queries' array. Collections: code-examples, design-patterns, api-specs, ui-components, test-cases, architecture-docs, user-feedback, flow-templates.";
    private static final String STORAGE_PLAN_SYSTEM_PROMPT = "You are a RAG Storage Planner. Generate JSON with 'storageOps'. Only store quality >= 0.7 or positive feedback.";
}

// --- Controller ---
@RestController
@RequestMapping("/api/rag")
class RagPlannerController {
    private final RagPlannerService svc;
    RagPlannerController(RagPlannerService svc) { this.svc = svc; }

    @PostMapping("/plan-queries")
    public DataProcessResult<RagQueryPlan> planQueries(@RequestBody PlanQueryRequest request) { return svc.planQueries(request); }

    @PostMapping("/execute-plan")
    public DataProcessResult<PlanExecutionResult> executePlan(@RequestBody RagQueryPlan plan) { return svc.executePlan(plan); }

    @PostMapping("/plan-storage")
    public DataProcessResult<RagStoragePlan> planStorage(@RequestBody PlanStorageRequest request) { return svc.planStorage(request); }
}
