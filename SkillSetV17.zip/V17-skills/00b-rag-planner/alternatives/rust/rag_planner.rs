// XIIGen Skill 00b — RAG Planner (Rust/Axum)
use axum::{Router, routing::post, Json, extract::State};
use serde::{Serialize, Deserialize};
use sha2::{Sha256, Digest};
use std::sync::Arc;
use tokio::time::Instant;
use uuid::Uuid;

// --- Models ---
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum QueryStrategy { Vector, Graph, Hybrid }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum StorageAction { Store, Update, Link }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PlannedQuery {
    pub query_text: String,
    pub collection: String,
    pub strategy: QueryStrategy,
    pub top_k: usize,
    pub relevance_threshold: f64,
    pub priority: u32,
    pub filters: Option<serde_json::Value>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RagQueryPlan {
    pub plan_id: String,
    pub task_description: String,
    pub queries: Vec<PlannedQuery>,
    pub reasoning: String,
    pub created_at: chrono::DateTime<chrono::Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PlannedStorage {
    pub collection: String,
    pub node_type: String,
    pub metadata: serde_json::Value,
    pub tags: Vec<String>,
    pub action: StorageAction,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RagStoragePlan {
    pub plan_id: String,
    pub task_description: String,
    pub storage_ops: Vec<PlannedStorage>,
    pub reasoning: String,
    pub created_at: chrono::DateTime<chrono::Utc>,
}

#[derive(Debug, Deserialize)]
pub struct PlanQueryRequest {
    pub task_description: String,
    pub step_type: String,
    pub technology: Option<String>,
    pub flow_context: Option<String>,
    pub hints: Option<serde_json::Value>,
}

#[derive(Debug, Deserialize)]
pub struct PlanStorageRequest {
    pub task_description: String,
    pub step_type: String,
    pub generated_content: String,
    pub technology: Option<String>,
    pub quality_score: Option<f64>,
    pub user_feedback: Option<String>,
}

#[derive(Debug, Serialize)]
pub struct RagQueryResult {
    pub query_text: String,
    pub hits: Vec<serde_json::Value>,
    pub avg_score: f64,
    pub query_duration_ms: u64,
}

#[derive(Debug, Serialize)]
pub struct PlanExecutionResult {
    pub plan: RagQueryPlan,
    pub results: Vec<RagQueryResult>,
    pub duration_ms: u64,
}

#[derive(Debug, Serialize)]
pub struct DataProcessResult<T: Serialize> {
    pub status: String,
    pub data: Option<T>,
    pub message: Option<String>,
}

impl<T: Serialize> DataProcessResult<T> {
    pub fn success(data: T) -> Self {
        Self { status: "Success".into(), data: Some(data), message: None }
    }
    pub fn error(msg: impl Into<String>) -> Self {
        Self { status: "Error".into(), data: None, message: Some(msg.into()) }
    }
}

// --- Service ---
pub struct RagPlannerService {
    ai: Arc<dyn AiProvider>,
    rag: Arc<dyn RagService>,
    db: Arc<dyn DatabaseService>,
    cache: Arc<dyn CacheService>,
}

impl RagPlannerService {
    pub fn new(
        ai: Arc<dyn AiProvider>, rag: Arc<dyn RagService>,
        db: Arc<dyn DatabaseService>, cache: Arc<dyn CacheService>,
    ) -> Self {
        Self { ai, rag, db, cache }
    }

    pub async fn plan_queries(&self, request: PlanQueryRequest) -> DataProcessResult<RagQueryPlan> {
        let cache_key = self.build_cache_key(&request.step_type, request.technology.as_deref(), &request.task_description);
        if let Ok(Some(cached)) = self.cache.get::<RagQueryPlan>(&format!("rag-plan:{}", cache_key)).await {
            return DataProcessResult::success(cached);
        }

        let prompt = format!(
            "Task: {}\nStep: {}\nTech: {}\nContext: {}\n\nGenerate RAG query plan as JSON.",
            request.task_description, request.step_type,
            request.technology.as_deref().unwrap_or("any"),
            request.flow_context.as_deref().unwrap_or("none")
        );

        match self.ai.complete(QUERY_PLAN_SYSTEM_PROMPT, &prompt, 0.3, 2000).await {
            Ok(response) => {
                match self.parse_query_plan(&response.content, &request.task_description) {
                    Some(plan) => {
                        let _ = self.cache.set(&format!("rag-plan:{}", cache_key), &plan, 14400).await;
                        let _ = self.db.upsert("xiigen-rag-plans", &plan.plan_id, &plan).await;
                        tracing::info!("Generated RAG plan {} with {} queries", plan.plan_id, plan.queries.len());
                        DataProcessResult::success(plan)
                    }
                    None => DataProcessResult::error("Failed to parse query plan"),
                }
            }
            Err(e) => DataProcessResult::error(format!("AI call failed: {}", e)),
        }
    }

    pub async fn execute_plan(&self, plan: RagQueryPlan) -> DataProcessResult<PlanExecutionResult> {
        let start = Instant::now();
        let mut results = Vec::new();

        let mut groups: std::collections::BTreeMap<u32, Vec<&PlannedQuery>> = std::collections::BTreeMap::new();
        for q in &plan.queries {
            groups.entry(q.priority).or_default().push(q);
        }

        for (_, queries) in &groups {
            let handles: Vec<_> = queries.iter().map(|q| {
                let rag = self.rag.clone();
                let q = (*q).clone();
                tokio::spawn(async move {
                    let q_start = Instant::now();
                    let hits = match q.strategy {
                        QueryStrategy::Vector => rag.search_vector(&q.query_text, &q.collection, q.top_k).await.unwrap_or_default(),
                        QueryStrategy::Graph => rag.traverse_graph(&q.query_text, "RELATES_TO", 2).await.unwrap_or_default(),
                        QueryStrategy::Hybrid => rag.hybrid_search(&q.query_text, &q.collection, q.top_k).await.unwrap_or_default(),
                    };
                    let filtered: Vec<_> = hits.into_iter()
                        .filter(|h| h.get("score").and_then(|s| s.as_f64()).unwrap_or(0.0) >= q.relevance_threshold)
                        .collect();
                    let avg = if filtered.is_empty() { 0.0 } else {
                        filtered.iter().map(|h| h.get("score").and_then(|s| s.as_f64()).unwrap_or(0.0)).sum::<f64>() / filtered.len() as f64
                    };
                    RagQueryResult {
                        query_text: q.query_text, hits: filtered, avg_score: avg,
                        query_duration_ms: q_start.elapsed().as_millis() as u64,
                    }
                })
            }).collect();

            for handle in handles {
                if let Ok(result) = handle.await {
                    results.push(result);
                }
            }
        }

        DataProcessResult::success(PlanExecutionResult {
            plan, results, duration_ms: start.elapsed().as_millis() as u64,
        })
    }

    pub async fn plan_storage(&self, request: PlanStorageRequest) -> DataProcessResult<RagStoragePlan> {
        let prompt = format!(
            "Task: {}\nStep: {}\nQuality: {}\nContent: {}\n\nGenerate storage plan as JSON.",
            request.task_description, request.step_type,
            request.quality_score.map_or("unscored".to_string(), |s| format!("{:.2}", s)),
            &request.generated_content[..request.generated_content.len().min(500)]
        );

        match self.ai.complete(STORAGE_PLAN_SYSTEM_PROMPT, &prompt, 0.3, 1500).await {
            Ok(response) => {
                match self.parse_storage_plan(&response.content, &request.task_description) {
                    Some(plan) => {
                        let _ = self.db.upsert("xiigen-rag-plans", &plan.plan_id, &plan).await;
                        DataProcessResult::success(plan)
                    }
                    None => DataProcessResult::error("Failed to parse storage plan"),
                }
            }
            Err(e) => DataProcessResult::error(format!("AI failed: {}", e)),
        }
    }

    fn build_cache_key(&self, step_type: &str, tech: Option<&str>, task: &str) -> String {
        let mut hasher = Sha256::new();
        hasher.update(task.to_lowercase().trim().as_bytes());
        let hash = format!("{:x}", hasher.finalize());
        format!("{}:{}:{}", step_type, tech.unwrap_or("any"), &hash[..16])
    }

    fn parse_query_plan(&self, json: &str, task: &str) -> Option<RagQueryPlan> {
        let cleaned = json.trim().trim_start_matches("```json").trim_end_matches("```").trim();
        let parsed: serde_json::Value = serde_json::from_str(cleaned).ok()?;
        let queries = parsed.get("queries")?.as_array()?.iter().filter_map(|q| {
            Some(PlannedQuery {
                query_text: q.get("queryText")?.as_str()?.to_string(),
                collection: q.get("collection")?.as_str()?.to_string(),
                strategy: match q.get("strategy")?.as_str()? {
                    "Graph" => QueryStrategy::Graph, "Hybrid" => QueryStrategy::Hybrid, _ => QueryStrategy::Vector,
                },
                top_k: q.get("topK").and_then(|v| v.as_u64()).unwrap_or(5) as usize,
                relevance_threshold: q.get("relevanceThreshold").and_then(|v| v.as_f64()).unwrap_or(0.5),
                priority: q.get("priority").and_then(|v| v.as_u64()).unwrap_or(1) as u32,
                filters: None,
            })
        }).collect();
        Some(RagQueryPlan {
            plan_id: format!("qplan-{}", Uuid::new_v4().to_string().replace('-', "")),
            task_description: task.to_string(), queries,
            reasoning: parsed.get("reasoning").and_then(|r| r.as_str()).unwrap_or("").to_string(),
            created_at: chrono::Utc::now(),
        })
    }

    fn parse_storage_plan(&self, json: &str, task: &str) -> Option<RagStoragePlan> {
        let cleaned = json.trim().trim_start_matches("```json").trim_end_matches("```").trim();
        let parsed: serde_json::Value = serde_json::from_str(cleaned).ok()?;
        let ops = parsed.get("storageOps")?.as_array()?.iter().filter_map(|s| {
            Some(PlannedStorage {
                collection: s.get("collection")?.as_str()?.to_string(),
                node_type: s.get("nodeType")?.as_str()?.to_string(),
                metadata: s.get("metadata").cloned().unwrap_or(serde_json::Value::Object(Default::default())),
                tags: s.get("tags").and_then(|t| t.as_array()).map(|a| a.iter().filter_map(|v| v.as_str().map(String::from)).collect()).unwrap_or_default(),
                action: match s.get("action")?.as_str()? { "Update" => StorageAction::Update, "Link" => StorageAction::Link, _ => StorageAction::Store },
            })
        }).collect();
        Some(RagStoragePlan {
            plan_id: format!("splan-{}", Uuid::new_v4().to_string().replace('-', "")),
            task_description: task.to_string(), storage_ops: ops,
            reasoning: parsed.get("reasoning").and_then(|r| r.as_str()).unwrap_or("").to_string(),
            created_at: chrono::Utc::now(),
        })
    }
}

// --- Axum Routes ---
pub fn routes() -> Router<AppState> {
    Router::new()
        .route("/api/rag/plan-queries", post(plan_queries_handler))
        .route("/api/rag/execute-plan", post(execute_plan_handler))
        .route("/api/rag/plan-storage", post(plan_storage_handler))
}

async fn plan_queries_handler(State(state): State<AppState>, Json(req): Json<PlanQueryRequest>) -> Json<DataProcessResult<RagQueryPlan>> {
    Json(state.rag_planner.plan_queries(req).await)
}
async fn execute_plan_handler(State(state): State<AppState>, Json(plan): Json<RagQueryPlan>) -> Json<DataProcessResult<PlanExecutionResult>> {
    Json(state.rag_planner.execute_plan(plan).await)
}
async fn plan_storage_handler(State(state): State<AppState>, Json(req): Json<PlanStorageRequest>) -> Json<DataProcessResult<RagStoragePlan>> {
    Json(state.rag_planner.plan_storage(req).await)
}

const QUERY_PLAN_SYSTEM_PROMPT: &str = "You are a RAG Query Planner for XIIGen. Generate JSON with 'queries' array. Collections: code-examples, design-patterns, api-specs, ui-components, test-cases, architecture-docs, user-feedback, flow-templates.";
const STORAGE_PLAN_SYSTEM_PROMPT: &str = "You are a RAG Storage Planner. Generate JSON with 'storageOps'. Only store quality >= 0.7 or positive feedback.";
