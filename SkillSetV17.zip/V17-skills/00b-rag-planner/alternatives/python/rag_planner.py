# XIIGen Skill 00b — RAG Planner (Python/FastAPI)
import asyncio
import hashlib
import json
import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional
from pydantic import BaseModel
from fastapi import APIRouter, Depends

# --- Models ---
class QueryStrategy(str, Enum):
    VECTOR = "Vector"
    GRAPH = "Graph"
    HYBRID = "Hybrid"

class StorageAction(str, Enum):
    STORE = "Store"
    UPDATE = "Update"
    LINK = "Link"

class PlannedQuery(BaseModel):
    query_text: str
    collection: str
    strategy: QueryStrategy
    top_k: int = 5
    relevance_threshold: float = 0.5
    priority: int = 1
    filters: Optional[dict[str, Any]] = None

class RagQueryPlan(BaseModel):
    plan_id: str
    task_description: str
    queries: list[PlannedQuery]
    reasoning: str
    created_at: datetime = datetime.now(timezone.utc)

class PlannedStorage(BaseModel):
    collection: str
    node_type: str
    metadata: dict[str, Any]
    tags: list[str]
    action: StorageAction

class RagStoragePlan(BaseModel):
    plan_id: str
    task_description: str
    storage_ops: list[PlannedStorage]
    reasoning: str
    created_at: datetime = datetime.now(timezone.utc)

class PlanQueryRequest(BaseModel):
    task_description: str
    step_type: str
    technology: Optional[str] = None
    flow_context: Optional[str] = None
    hints: Optional[dict[str, Any]] = None

class PlanStorageRequest(BaseModel):
    task_description: str
    step_type: str
    generated_content: str
    technology: Optional[str] = None
    quality_score: Optional[float] = None
    user_feedback: Optional[str] = None

class RagQueryResult(BaseModel):
    query_text: str
    hits: list[dict]
    avg_score: float
    query_duration_ms: float

class PlanExecutionResult(BaseModel):
    plan: RagQueryPlan
    results: list[RagQueryResult]
    duration_ms: float

# --- Service ---
class RagPlannerService:
    PLAN_CACHE_PREFIX = "rag-plan:"
    PLAN_INDEX = "xiigen-rag-plans"
    CACHE_TTL = 4 * 3600  # 4 hours

    def __init__(self, ai, rag, db, cache, logger):
        self.ai = ai
        self.rag = rag
        self.db = db
        self.cache = cache
        self.logger = logger

    async def plan_queries(self, request: PlanQueryRequest) -> dict:
        try:
            cache_key = self._build_cache_key(request.step_type, request.technology, request.task_description)
            cached = await self.cache.get(f"{self.PLAN_CACHE_PREFIX}{cache_key}")
            if cached:
                return {"status": "Success", "data": cached}

            prompt = self._build_query_planning_prompt(request)
            ai_response = await self.ai.complete({
                "system_prompt": QUERY_PLAN_SYSTEM_PROMPT,
                "prompt": prompt,
                "temperature": 0.3,
                "max_tokens": 2000,
                "output_format": "json"
            })

            if not ai_response.get("content"):
                return {"status": "Error", "message": "AI returned empty plan"}

            plan = self._parse_query_plan(ai_response["content"], request.task_description)
            if not plan:
                return {"status": "Error", "message": "Failed to parse query plan"}

            await self.cache.set(f"{self.PLAN_CACHE_PREFIX}{cache_key}", plan.model_dump(), self.CACHE_TTL)
            await self.db.upsert(self.PLAN_INDEX, plan.plan_id, plan.model_dump())

            self.logger.info(f"Generated RAG plan {plan.plan_id} with {len(plan.queries)} queries")
            return {"status": "Success", "data": plan.model_dump()}
        except Exception as e:
            self.logger.error(f"plan_queries failed: {e}")
            return {"status": "Error", "message": str(e)}

    async def execute_plan(self, plan: RagQueryPlan) -> dict:
        try:
            import time
            start = time.monotonic()
            results: list[RagQueryResult] = []

            groups: dict[int, list[PlannedQuery]] = {}
            for q in sorted(plan.queries, key=lambda x: x.priority):
                groups.setdefault(q.priority, []).append(q)

            for _, queries in sorted(groups.items()):
                tasks = [self._execute_single_query(q) for q in queries]
                group_results = await asyncio.gather(*tasks)
                results.extend(group_results)

            duration_ms = (time.monotonic() - start) * 1000
            exec_result = PlanExecutionResult(plan=plan, results=results, duration_ms=duration_ms)
            return {"status": "Success", "data": exec_result.model_dump()}
        except Exception as e:
            return {"status": "Error", "message": str(e)}

    async def _execute_single_query(self, query: PlannedQuery) -> RagQueryResult:
        import time
        start = time.monotonic()

        if query.strategy == QueryStrategy.VECTOR:
            hits = await self.rag.search_vector(query.query_text, query.collection, query.top_k, query.filters)
        elif query.strategy == QueryStrategy.GRAPH:
            graph_hits = await self.rag.traverse_graph(query.query_text, "RELATES_TO", 2)
            hits = [{"id": g["node_id"], "text": json.dumps(g["properties"]), "score": 1.0} for g in graph_hits]
        elif query.strategy == QueryStrategy.HYBRID:
            hits = await self.rag.hybrid_search(query.query_text, query.collection, query.top_k)
        else:
            hits = []

        filtered = [h for h in hits if h.get("score", 0) >= query.relevance_threshold]
        avg_score = sum(h["score"] for h in filtered) / len(filtered) if filtered else 0

        return RagQueryResult(
            query_text=query.query_text,
            hits=filtered,
            avg_score=avg_score,
            query_duration_ms=(time.monotonic() - start) * 1000
        )

    async def plan_storage(self, request: PlanStorageRequest) -> dict:
        try:
            prompt = self._build_storage_planning_prompt(request)
            ai_response = await self.ai.complete({
                "system_prompt": STORAGE_PLAN_SYSTEM_PROMPT,
                "prompt": prompt,
                "temperature": 0.3,
                "max_tokens": 1500,
                "output_format": "json"
            })

            plan = self._parse_storage_plan(ai_response["content"], request.task_description)
            if not plan:
                return {"status": "Error", "message": "Failed to parse storage plan"}

            await self.db.upsert(self.PLAN_INDEX, plan.plan_id, plan.model_dump())
            return {"status": "Success", "data": plan.model_dump()}
        except Exception as e:
            return {"status": "Error", "message": str(e)}

    async def execute_storage_plan(self, plan: RagStoragePlan, content: str) -> dict:
        try:
            stored = 0
            for op in plan.storage_ops:
                if op.action == StorageAction.STORE:
                    await self.rag.store_embedding(str(uuid.uuid4()), content, op.collection, op.metadata)
                    stored += 1
                elif op.action == StorageAction.LINK:
                    await self.rag.store_graph_node(str(uuid.uuid4()), op.node_type, op.metadata)
                    stored += 1
                elif op.action == StorageAction.UPDATE:
                    existing = await self.rag.search_vector(content[:200], op.collection, 1)
                    if existing:
                        await self.rag.store_embedding(existing[0]["id"], content, op.collection, op.metadata)
                        stored += 1
            return {"status": "Success", "data": stored}
        except Exception as e:
            return {"status": "Error", "message": str(e)}

    def _build_cache_key(self, step_type: str, technology: str | None, task: str) -> str:
        intent_hash = hashlib.sha256(task.lower().strip().encode()).hexdigest()[:16]
        return f"{step_type}:{technology or 'any'}:{intent_hash}"

    def _build_query_planning_prompt(self, req: PlanQueryRequest) -> str:
        return f"Task: {req.task_description}\nStep: {req.step_type}\nTech: {req.technology or 'any'}\nContext: {req.flow_context or 'none'}\n\nGenerate RAG query plan as JSON."

    def _build_storage_planning_prompt(self, req: PlanStorageRequest) -> str:
        return f"Task: {req.task_description}\nStep: {req.step_type}\nQuality: {req.quality_score or 'unscored'}\nFeedback: {req.user_feedback or 'none'}\nContent: {req.generated_content[:500]}\n\nGenerate storage plan as JSON."

    def _parse_query_plan(self, raw: str, task: str) -> RagQueryPlan | None:
        try:
            cleaned = raw.strip().removeprefix("```json").removesuffix("```").strip()
            parsed = json.loads(cleaned)
            return RagQueryPlan(
                plan_id=f"qplan-{uuid.uuid4().hex}",
                task_description=task,
                queries=[PlannedQuery(**q) for q in parsed["queries"]],
                reasoning=parsed.get("reasoning", "")
            )
        except Exception:
            return None

    def _parse_storage_plan(self, raw: str, task: str) -> RagStoragePlan | None:
        try:
            cleaned = raw.strip().removeprefix("```json").removesuffix("```").strip()
            parsed = json.loads(cleaned)
            return RagStoragePlan(
                plan_id=f"splan-{uuid.uuid4().hex}",
                task_description=task,
                storage_ops=[PlannedStorage(**s) for s in parsed["storageOps"]],
                reasoning=parsed.get("reasoning", "")
            )
        except Exception:
            return None

# --- FastAPI Router ---
router = APIRouter(prefix="/api/rag")

@router.post("/plan-queries")
async def plan_queries(request: PlanQueryRequest, svc: RagPlannerService = Depends()):
    return await svc.plan_queries(request)

@router.post("/execute-plan")
async def execute_plan(plan: RagQueryPlan, svc: RagPlannerService = Depends()):
    return await svc.execute_plan(plan)

@router.post("/plan-storage")
async def plan_storage(request: PlanStorageRequest, svc: RagPlannerService = Depends()):
    return await svc.plan_storage(request)

# --- Prompts ---
QUERY_PLAN_SYSTEM_PROMPT = "You are a RAG Query Planner for XIIGen. Generate JSON query plans with 'queries' array. Collections: code-examples, design-patterns, api-specs, ui-components, test-cases, architecture-docs, user-feedback, flow-templates."
STORAGE_PLAN_SYSTEM_PROMPT = "You are a RAG Storage Planner for XIIGen. Generate JSON storage plans with 'storageOps' array. Only store quality >= 0.7 or positive feedback."
