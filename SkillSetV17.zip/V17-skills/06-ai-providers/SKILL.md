---
name: ai-providers
description: Unified IAiProvider implementations for Claude, OpenAI, Gemini, Deepseek with retry, rate-limiting, streaming, and cost tracking.
triggers: ai provider, call ai, claude api, openai api, gemini api, deepseek, ai model, llm call
dependencies: [01-core-interfaces]
layer: L3-AI
genie-dna: Returns DataProcessResult for all operations. Provider factory pattern matches DatabaseFabric approach.
---

# Skill 06: AI Providers
## Unified Interface to Multiple AI Models

**Dependencies:** 01-core-interfaces
**Layer:** L3: AI
**Existing .NET:** AiProviders.cs (12KB — good, 4 providers implemented)

---

## Overview

AI Providers gives XIIGen a single `IAiProvider` interface that works identically across Claude (Anthropic), GPT (OpenAI), Gemini (Google), and Deepseek. Each provider handles its own API format, authentication, and response parsing. The `AiProviderFactory` manages registration and resolution by name.

All providers share a `BaseAiProvider` base class with exponential-backoff retry logic, token estimation, and streaming support (with fallback to non-streaming).

## When to Use

- Any time the system needs to call an AI model for generation, analysis, or review
- When the AI Dispatcher (skill 07) needs to fan out to multiple providers
- When adding a new AI provider to the system
- For direct AI calls without orchestration overhead

## Provider Comparison

| Provider | Models | Max Context | Streaming | Vision | Cost (approx) |
|---|---|---|---|---|---|
| Claude (Anthropic) | claude-sonnet-4, claude-opus-4 | 200K tokens | ✅ | ✅ | $3-15/MTok |
| GPT (OpenAI) | gpt-4o, o3-mini | 128K tokens | ✅ | ✅ | $2.50-15/MTok |
| Gemini (Google) | gemini-2.0-flash, gemini-2.5-pro | 1M tokens | ✅ | ✅ | $0.15-7/MTok |
| Deepseek | deepseek-coder, deepseek-chat | 64K tokens | ✅ | ❌ | $0.14-2.19/MTok |

## API Reference

### IAiProvider Interface

```csharp
public interface IAiProvider
{
    string ProviderName { get; }
    AiModelType ModelType { get; }
    Task<AiResponse> ExecuteAsync(AiRequest request, CancellationToken ct = default);
    IAsyncEnumerable<AiStreamChunk> StreamAsync(AiRequest request, CancellationToken ct = default);
    Task<AiModelInfo> GetModelInfoAsync(CancellationToken ct = default);
    Task<int> EstimateTokensAsync(string text, CancellationToken ct = default);
}
```

### AiRequest Model

```csharp
public record AiRequest
{
    public string RequestId { get; init; } = Guid.NewGuid().ToString();
    public string TraceId { get; init; }
    public string StepId { get; init; }
    public string Model { get; init; }
    public string SystemPrompt { get; init; }
    public string UserPrompt { get; init; }
    public int MaxTokens { get; init; } = 4096;
    public double Temperature { get; init; } = 0.7;
    public Dictionary<string, object> Metadata { get; init; } = new();
}
```

### AiProviderFactory

```csharp
var factory = AiProviderFactory.CreateDefault(
    claudeKey: config["AI:Claude:ApiKey"],
    openAiKey: config["AI:OpenAI:ApiKey"],
    geminiKey: config["AI:Gemini:ApiKey"]
);
var claude = factory.Resolve("claude");
var response = await claude.ExecuteAsync(new AiRequest { UserPrompt = "Hello" });
```

## Configuration

```json
{
  "AI": {
    "Claude": { "ApiKey": "sk-ant-...", "Model": "claude-sonnet-4-20250514" },
    "OpenAI": { "ApiKey": "sk-...", "Model": "gpt-4o" },
    "Gemini": { "ApiKey": "AIza...", "Model": "gemini-2.0-flash" },
    "Deepseek": { "ApiKey": "sk-...", "Model": "deepseek-coder" }
  }
}
```

## DI Registration

```csharp
services.AddXIIGenAiProviders(config); // Auto-registers all configured providers
```

## Retry Strategy

All providers use exponential backoff: delay = 2^attempt seconds, max 3 retries. Rate-limit (429) responses trigger longer delays. Timeout defaults to 120s per request.

## Streaming

All providers implement `StreamAsync` which yields `AiStreamChunk` objects. For providers that don't natively support streaming, the base class falls back to a single chunk containing the full response.

## Test Scenarios

1. Execute request against each provider and verify response structure
2. Verify retry logic triggers on 5xx errors
3. Verify streaming yields incremental chunks
4. Verify token estimation is within 20% of actual usage
5. Verify factory resolves providers by name (case-insensitive)
6. Verify timeout cancellation works correctly
