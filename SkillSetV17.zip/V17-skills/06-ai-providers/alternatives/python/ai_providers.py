# Skill 06: AI Providers — Python 3.12+ / httpx
# Unified IAiProvider for Claude, OpenAI, Gemini, Deepseek
# Same interface as .NET — see SKILL.md
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import AsyncIterator, Optional
import httpx, time, asyncio, logging

logger = logging.getLogger(__name__)

@dataclass
class AiRequest:
    user_prompt: str
    system_prompt: str = ""
    request_id: str = ""
    trace_id: str = ""
    step_id: str = ""
    model: str = ""
    max_tokens: int = 4096
    temperature: float = 0.7

@dataclass
class AiResponse:
    success: bool
    content: str = ""
    model: str = ""
    request_id: str = ""
    error: str = ""
    duration_ms: float = 0
    input_tokens: int = 0
    output_tokens: int = 0

@dataclass
class AiStreamChunk:
    content: str = ""
    is_complete: bool = False

class IAiProvider(ABC):
    @property
    @abstractmethod
    def provider_name(self) -> str: ...
    @abstractmethod
    async def execute(self, request: AiRequest) -> AiResponse: ...
    def estimate_tokens(self, text: str) -> int: return len(text) // 4

class BaseAiProvider(IAiProvider):
    def __init__(self, api_key: str, model_id: str):
        self.api_key = api_key
        self.model_id = model_id
        self.client = httpx.AsyncClient(timeout=120.0)

    async def _with_retry(self, fn, max_retries=3) -> AiResponse:
        for i in range(max_retries + 1):
            try: return await fn()
            except Exception as e:
                if i == max_retries: return AiResponse(success=False, error=str(e))
                await asyncio.sleep(2 ** i)
        return AiResponse(success=False, error="Max retries exceeded")

# ─── Claude Provider ────────────────────────────────────
class ClaudeProvider(BaseAiProvider):
    @property
    def provider_name(self) -> str: return "Anthropic"

    def __init__(self, api_key: str, model_id: str = "claude-sonnet-4-20250514"):
        super().__init__(api_key, model_id)

    async def execute(self, request: AiRequest) -> AiResponse:
        async def _call():
            start = time.monotonic()
            resp = await self.client.post("https://api.anthropic.com/v1/messages",
                headers={"x-api-key": self.api_key, "anthropic-version": "2023-06-01", "content-type": "application/json"},
                json={"model": self.model_id, "max_tokens": request.max_tokens, "temperature": request.temperature,
                      "system": request.system_prompt, "messages": [{"role": "user", "content": request.user_prompt}]})
            data = resp.json()
            elapsed = (time.monotonic() - start) * 1000
            if resp.status_code != 200: return AiResponse(success=False, model=self.model_id, error=str(data))
            return AiResponse(success=True, model=self.model_id, content=data["content"][0]["text"],
                request_id=request.request_id, duration_ms=elapsed,
                input_tokens=data["usage"]["input_tokens"], output_tokens=data["usage"]["output_tokens"])
        return await self._with_retry(_call)

# ─── OpenAI Provider ───────────────────────────────────
class OpenAiProvider(BaseAiProvider):
    @property
    def provider_name(self) -> str: return "OpenAI"

    def __init__(self, api_key: str, model_id: str = "gpt-4o"):
        super().__init__(api_key, model_id)

    async def execute(self, request: AiRequest) -> AiResponse:
        async def _call():
            start = time.monotonic()
            messages = []
            if request.system_prompt: messages.append({"role": "system", "content": request.system_prompt})
            messages.append({"role": "user", "content": request.user_prompt})
            resp = await self.client.post("https://api.openai.com/v1/chat/completions",
                headers={"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"},
                json={"model": self.model_id, "messages": messages, "max_tokens": request.max_tokens, "temperature": request.temperature})
            data = resp.json()
            elapsed = (time.monotonic() - start) * 1000
            if resp.status_code != 200: return AiResponse(success=False, model=self.model_id, error=str(data))
            return AiResponse(success=True, model=self.model_id, content=data["choices"][0]["message"]["content"],
                request_id=request.request_id, duration_ms=elapsed,
                input_tokens=data["usage"]["prompt_tokens"], output_tokens=data["usage"]["completion_tokens"])
        return await self._with_retry(_call)

# ─── Gemini Provider ───────────────────────────────────
class GeminiProvider(BaseAiProvider):
    @property
    def provider_name(self) -> str: return "Google"

    def __init__(self, api_key: str, model_id: str = "gemini-2.0-flash"):
        super().__init__(api_key, model_id)

    async def execute(self, request: AiRequest) -> AiResponse:
        async def _call():
            start = time.monotonic()
            url = f"https://generativelanguage.googleapis.com/v1/models/{self.model_id}:generateContent?key={self.api_key}"
            resp = await self.client.post(url, json={
                "contents": [{"parts": [{"text": f"{request.system_prompt}\n\n{request.user_prompt}"}]}],
                "generationConfig": {"maxOutputTokens": request.max_tokens, "temperature": request.temperature}})
            data = resp.json()
            elapsed = (time.monotonic() - start) * 1000
            if resp.status_code != 200: return AiResponse(success=False, model=self.model_id, error=str(data))
            return AiResponse(success=True, model=self.model_id, duration_ms=elapsed,
                content=data["candidates"][0]["content"]["parts"][0]["text"], request_id=request.request_id)
        return await self._with_retry(_call)

# ─── Provider Factory ──────────────────────────────────
class AiProviderFactory:
    def __init__(self):
        self._providers: dict[str, IAiProvider] = {}

    def register(self, name: str, provider: IAiProvider): self._providers[name.lower()] = provider
    def resolve(self, name: str) -> IAiProvider:
        p = self._providers.get(name.lower())
        if not p: raise KeyError(f"AI provider '{name}' not registered. Available: {list(self._providers.keys())}")
        return p
    @property
    def all(self) -> list[IAiProvider]: return list(self._providers.values())
    @property
    def registered_names(self) -> list[str]: return list(self._providers.keys())

    @staticmethod
    def create_default(claude_key: str = "", openai_key: str = "", gemini_key: str = "") -> "AiProviderFactory":
        f = AiProviderFactory()
        if claude_key: f.register("claude", ClaudeProvider(claude_key))
        if openai_key: f.register("openai", OpenAiProvider(openai_key))
        if gemini_key: f.register("gemini", GeminiProvider(gemini_key))
        return f
