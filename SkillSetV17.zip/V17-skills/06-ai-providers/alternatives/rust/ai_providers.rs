// Skill 06: AI Providers — Rust / reqwest + tokio
// Unified IAiProvider for Claude, OpenAI, Gemini
use reqwest::Client;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::collections::HashMap;
use std::time::Instant;

#[derive(Clone, Debug)]
pub struct AiRequest {
    pub request_id: String, pub trace_id: String, pub system_prompt: String,
    pub user_prompt: String, pub max_tokens: u32, pub temperature: f64,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct AiResponse {
    pub success: bool, pub model: String, pub content: String, pub error: String,
    pub duration_ms: u64, pub input_tokens: u32, pub output_tokens: u32,
}

impl AiResponse {
    pub fn fail(model: &str, error: &str) -> Self {
        Self { success: false, model: model.to_string(), content: String::new(), error: error.to_string(), duration_ms: 0, input_tokens: 0, output_tokens: 0 }
    }
}

#[async_trait::async_trait]
pub trait IAiProvider: Send + Sync {
    fn provider_name(&self) -> &str;
    async fn execute(&self, request: &AiRequest) -> AiResponse;
    fn estimate_tokens(&self, text: &str) -> usize { text.len() / 4 }
}

// ─── Claude Provider ───────────────────────────────────
pub struct ClaudeProvider { api_key: String, model_id: String, client: Client }

impl ClaudeProvider {
    pub fn new(api_key: &str, model_id: Option<&str>) -> Self {
        Self { api_key: api_key.to_string(), model_id: model_id.unwrap_or("claude-sonnet-4-20250514").to_string(), client: Client::new() }
    }
}

#[async_trait::async_trait]
impl IAiProvider for ClaudeProvider {
    fn provider_name(&self) -> &str { "Anthropic" }

    async fn execute(&self, request: &AiRequest) -> AiResponse {
        let start = Instant::now();
        let body = json!({
            "model": self.model_id, "max_tokens": request.max_tokens, "temperature": request.temperature,
            "system": &request.system_prompt, "messages": [{"role": "user", "content": &request.user_prompt}]
        });
        let result = self.client.post("https://api.anthropic.com/v1/messages")
            .header("x-api-key", &self.api_key).header("anthropic-version", "2023-06-01")
            .json(&body).send().await;
        match result {
            Ok(resp) => {
                let json: Value = resp.json().await.unwrap_or(json!({}));
                let elapsed = start.elapsed().as_millis() as u64;
                if json.get("error").is_some() { return AiResponse::fail(&self.model_id, &json.to_string()); }
                AiResponse {
                    success: true, model: self.model_id.clone(), error: String::new(), duration_ms: elapsed,
                    content: json["content"][0]["text"].as_str().unwrap_or("").to_string(),
                    input_tokens: json["usage"]["input_tokens"].as_u64().unwrap_or(0) as u32,
                    output_tokens: json["usage"]["output_tokens"].as_u64().unwrap_or(0) as u32,
                }
            }
            Err(e) => AiResponse::fail(&self.model_id, &e.to_string()),
        }
    }
}

// ─── OpenAI Provider ───────────────────────────────────
pub struct OpenAiProvider { api_key: String, model_id: String, client: Client }

impl OpenAiProvider {
    pub fn new(api_key: &str, model_id: Option<&str>) -> Self {
        Self { api_key: api_key.to_string(), model_id: model_id.unwrap_or("gpt-4o").to_string(), client: Client::new() }
    }
}

#[async_trait::async_trait]
impl IAiProvider for OpenAiProvider {
    fn provider_name(&self) -> &str { "OpenAI" }

    async fn execute(&self, request: &AiRequest) -> AiResponse {
        let start = Instant::now();
        let mut messages = vec![];
        if !request.system_prompt.is_empty() { messages.push(json!({"role": "system", "content": &request.system_prompt})); }
        messages.push(json!({"role": "user", "content": &request.user_prompt}));
        let body = json!({"model": self.model_id, "messages": messages, "max_tokens": request.max_tokens, "temperature": request.temperature});
        let result = self.client.post("https://api.openai.com/v1/chat/completions")
            .header("Authorization", format!("Bearer {}", self.api_key)).json(&body).send().await;
        match result {
            Ok(resp) => {
                let json: Value = resp.json().await.unwrap_or(json!({}));
                let elapsed = start.elapsed().as_millis() as u64;
                if json.get("error").is_some() { return AiResponse::fail(&self.model_id, &json.to_string()); }
                AiResponse {
                    success: true, model: self.model_id.clone(), error: String::new(), duration_ms: elapsed,
                    content: json["choices"][0]["message"]["content"].as_str().unwrap_or("").to_string(),
                    input_tokens: json["usage"]["prompt_tokens"].as_u64().unwrap_or(0) as u32,
                    output_tokens: json["usage"]["completion_tokens"].as_u64().unwrap_or(0) as u32,
                }
            }
            Err(e) => AiResponse::fail(&self.model_id, &e.to_string()),
        }
    }
}

// ─── Provider Factory ──────────────────────────────────
pub struct AiProviderFactory {
    providers: HashMap<String, Box<dyn IAiProvider>>,
}

impl AiProviderFactory {
    pub fn new() -> Self { Self { providers: HashMap::new() } }
    pub fn register(&mut self, name: &str, provider: Box<dyn IAiProvider>) { self.providers.insert(name.to_lowercase(), provider); }
    pub fn resolve(&self, name: &str) -> Result<&dyn IAiProvider, String> {
        self.providers.get(&name.to_lowercase()).map(|p| p.as_ref())
            .ok_or(format!("AI provider '{}' not registered", name))
    }
    pub fn all(&self) -> Vec<&dyn IAiProvider> { self.providers.values().map(|p| p.as_ref()).collect() }
}
