// Skill 06: AI Providers — Node.js/TypeScript
// Unified IAiProvider for Claude, OpenAI, Gemini, Deepseek
// Same interface as .NET — see SKILL.md
import { DataProcessResult, ok, fail, AiModelType } from "./core-interfaces";

export interface AiRequest {
  requestId?: string; traceId?: string; stepId?: string; model?: string;
  systemPrompt?: string; userPrompt: string; maxTokens?: number; temperature?: number;
}

export interface AiResponse {
  requestId?: string; model?: string; content?: string; success: boolean;
  error?: string; duration?: number;
  usage?: { inputTokens: number; outputTokens: number };
}

export interface AiStreamChunk { content?: string; isComplete: boolean; usage?: AiResponse["usage"]; }

export interface IAiProvider {
  readonly providerName: string;
  readonly modelType: AiModelType;
  execute(request: AiRequest): Promise<AiResponse>;
  stream?(request: AiRequest): AsyncGenerator<AiStreamChunk>;
  estimateTokens(text: string): number;
}

// ─── Base Provider with retry ──────────────────────────
abstract class BaseAiProvider implements IAiProvider {
  abstract readonly providerName: string;
  abstract readonly modelType: AiModelType;

  constructor(protected apiKey: string, protected modelId: string) {}

  abstract execute(request: AiRequest): Promise<AiResponse>;

  estimateTokens(text: string): number { return Math.ceil(text.length / 4); }

  protected async withRetry(fn: () => Promise<AiResponse>, maxRetries = 3): Promise<AiResponse> {
    for (let i = 0; i <= maxRetries; i++) {
      try { return await fn(); }
      catch (e) { if (i === maxRetries) return { success: false, error: String(e) }; await this.delay(2 ** i * 1000); }
    }
    return { success: false, error: "Max retries exceeded" };
  }

  private delay(ms: number) { return new Promise(r => setTimeout(r, ms)); }
}

// ─── Claude Provider ───────────────────────────────────
export class ClaudeProvider extends BaseAiProvider {
  readonly providerName = "Anthropic";
  readonly modelType = AiModelType.Claude;

  constructor(apiKey: string, modelId = "claude-sonnet-4-20250514") { super(apiKey, modelId); }

  async execute(request: AiRequest): Promise<AiResponse> {
    return this.withRetry(async () => {
      const start = Date.now();
      const resp = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-api-key": this.apiKey, "anthropic-version": "2023-06-01" },
        body: JSON.stringify({
          model: this.modelId, max_tokens: request.maxTokens ?? 4096, temperature: request.temperature ?? 0.7,
          system: request.systemPrompt ?? "", messages: [{ role: "user", content: request.userPrompt }]
        })
      });
      const json = await resp.json();
      if (!resp.ok) return { success: false, model: this.modelId, error: JSON.stringify(json) };
      return {
        requestId: request.requestId, model: this.modelId, success: true, duration: Date.now() - start,
        content: json.content[0].text,
        usage: { inputTokens: json.usage.input_tokens, outputTokens: json.usage.output_tokens }
      };
    });
  }
}

// ─── OpenAI Provider ───────────────────────────────────
export class OpenAiProvider extends BaseAiProvider {
  readonly providerName = "OpenAI";
  readonly modelType = AiModelType.OpenAI;

  constructor(apiKey: string, modelId = "gpt-4o") { super(apiKey, modelId); }

  async execute(request: AiRequest): Promise<AiResponse> {
    return this.withRetry(async () => {
      const start = Date.now();
      const messages: any[] = [];
      if (request.systemPrompt) messages.push({ role: "system", content: request.systemPrompt });
      messages.push({ role: "user", content: request.userPrompt });
      const resp = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${this.apiKey}` },
        body: JSON.stringify({ model: this.modelId, messages, max_tokens: request.maxTokens ?? 4096, temperature: request.temperature ?? 0.7 })
      });
      const json = await resp.json();
      if (!resp.ok) return { success: false, model: this.modelId, error: JSON.stringify(json) };
      return {
        requestId: request.requestId, model: this.modelId, success: true, duration: Date.now() - start,
        content: json.choices[0].message.content,
        usage: { inputTokens: json.usage.prompt_tokens, outputTokens: json.usage.completion_tokens }
      };
    });
  }
}

// ─── Gemini Provider ───────────────────────────────────
export class GeminiProvider extends BaseAiProvider {
  readonly providerName = "Google";
  readonly modelType = AiModelType.Gemini;

  constructor(apiKey: string, modelId = "gemini-2.0-flash") { super(apiKey, modelId); }

  async execute(request: AiRequest): Promise<AiResponse> {
    return this.withRetry(async () => {
      const start = Date.now();
      const url = `https://generativelanguage.googleapis.com/v1/models/${this.modelId}:generateContent?key=${this.apiKey}`;
      const resp = await fetch(url, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [{ text: `${request.systemPrompt ?? ""}\n\n${request.userPrompt}` }] }],
          generationConfig: { maxOutputTokens: request.maxTokens ?? 4096, temperature: request.temperature ?? 0.7 }
        })
      });
      const json = await resp.json();
      if (!resp.ok) return { success: false, model: this.modelId, error: JSON.stringify(json) };
      return {
        requestId: request.requestId, model: this.modelId, success: true, duration: Date.now() - start,
        content: json.candidates[0].content.parts[0].text,
        usage: { inputTokens: 0, outputTokens: 0 }
      };
    });
  }
}

// ─── Provider Factory ──────────────────────────────────
export class AiProviderFactory {
  private providers = new Map<string, IAiProvider>();

  register(name: string, provider: IAiProvider) { this.providers.set(name.toLowerCase(), provider); }
  resolve(name: string): IAiProvider {
    const p = this.providers.get(name.toLowerCase());
    if (!p) throw new Error(`AI provider '${name}' not registered. Available: ${[...this.providers.keys()]}`);
    return p;
  }
  get all(): IAiProvider[] { return [...this.providers.values()]; }
  get registeredNames(): string[] { return [...this.providers.keys()]; }

  static createDefault(keys: { claude?: string; openai?: string; gemini?: string }): AiProviderFactory {
    const f = new AiProviderFactory();
    if (keys.claude) f.register("claude", new ClaudeProvider(keys.claude));
    if (keys.openai) f.register("openai", new OpenAiProvider(keys.openai));
    if (keys.gemini) f.register("gemini", new GeminiProvider(keys.gemini));
    return f;
  }
}
