// Skill 06: AI Providers — Java 21+ / java.net.http
// Unified IAiProvider for Claude, OpenAI, Gemini, Deepseek
package com.xiigen.ai.providers;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.net.URI;
import java.net.http.*;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public interface IAiProvider {
    String getProviderName();
    AiModelType getModelType();
    AiResponse execute(AiRequest request) throws Exception;
    default int estimateTokens(String text) { return text.length() / 4; }
}

public record AiRequest(String requestId, String traceId, String systemPrompt, String userPrompt, int maxTokens, double temperature) {
    public AiRequest(String userPrompt) { this(UUID.randomUUID().toString(), "", "", userPrompt, 4096, 0.7); }
}

public record AiResponse(boolean success, String model, String content, String error, long durationMs, int inputTokens, int outputTokens) {
    public static AiResponse fail(String model, String error) { return new AiResponse(false, model, "", error, 0, 0, 0); }
}

// ─── Base Provider with retry ──────────────────────────
abstract class BaseAiProvider implements IAiProvider {
    protected final String apiKey;
    protected final String modelId;
    protected final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(30)).build();
    protected final ObjectMapper mapper = new ObjectMapper();

    protected BaseAiProvider(String apiKey, String modelId) { this.apiKey = apiKey; this.modelId = modelId; }

    protected AiResponse withRetry(ThrowingSupplier<AiResponse> fn, int maxRetries) {
        for (int i = 0; i <= maxRetries; i++) {
            try { return fn.get(); }
            catch (Exception e) { if (i == maxRetries) return AiResponse.fail(modelId, e.getMessage()); sleep(1000L * (1 << i)); }
        }
        return AiResponse.fail(modelId, "Max retries exceeded");
    }

    private void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); } }

    @FunctionalInterface
    interface ThrowingSupplier<T> { T get() throws Exception; }
}

// ─── Claude Provider ───────────────────────────────────
public class ClaudeProvider extends BaseAiProvider {
    public ClaudeProvider(String apiKey) { this(apiKey, "claude-sonnet-4-20250514"); }
    public ClaudeProvider(String apiKey, String modelId) { super(apiKey, modelId); }

    @Override public String getProviderName() { return "Anthropic"; }
    @Override public AiModelType getModelType() { return AiModelType.CLAUDE; }

    @Override public AiResponse execute(AiRequest request) {
        return withRetry(() -> {
            long start = System.currentTimeMillis();
            var body = mapper.writeValueAsString(Map.of("model", modelId, "max_tokens", request.maxTokens(),
                "temperature", request.temperature(), "system", request.systemPrompt() != null ? request.systemPrompt() : "",
                "messages", List.of(Map.of("role", "user", "content", request.userPrompt()))));
            var req = HttpRequest.newBuilder(URI.create("https://api.anthropic.com/v1/messages"))
                .header("Content-Type", "application/json").header("x-api-key", apiKey).header("anthropic-version", "2023-06-01")
                .POST(HttpRequest.BodyPublishers.ofString(body)).build();
            var resp = http.send(req, HttpResponse.BodyHandlers.ofString());
            var json = mapper.readTree(resp.body());
            long elapsed = System.currentTimeMillis() - start;
            if (resp.statusCode() != 200) return AiResponse.fail(modelId, resp.body());
            return new AiResponse(true, modelId, json.at("/content/0/text").asText(), "",
                elapsed, json.at("/usage/input_tokens").asInt(), json.at("/usage/output_tokens").asInt());
        }, 3);
    }
}

// ─── OpenAI Provider ───────────────────────────────────
public class OpenAiProvider extends BaseAiProvider {
    public OpenAiProvider(String apiKey) { this(apiKey, "gpt-4o"); }
    public OpenAiProvider(String apiKey, String modelId) { super(apiKey, modelId); }
    @Override public String getProviderName() { return "OpenAI"; }
    @Override public AiModelType getModelType() { return AiModelType.OPENAI; }

    @Override public AiResponse execute(AiRequest request) {
        return withRetry(() -> {
            long start = System.currentTimeMillis();
            var messages = new ArrayList<Map<String, String>>();
            if (request.systemPrompt() != null && !request.systemPrompt().isEmpty())
                messages.add(Map.of("role", "system", "content", request.systemPrompt()));
            messages.add(Map.of("role", "user", "content", request.userPrompt()));
            var body = mapper.writeValueAsString(Map.of("model", modelId, "messages", messages,
                "max_tokens", request.maxTokens(), "temperature", request.temperature()));
            var req = HttpRequest.newBuilder(URI.create("https://api.openai.com/v1/chat/completions"))
                .header("Content-Type", "application/json").header("Authorization", "Bearer " + apiKey)
                .POST(HttpRequest.BodyPublishers.ofString(body)).build();
            var resp = http.send(req, HttpResponse.BodyHandlers.ofString());
            var json = mapper.readTree(resp.body());
            long elapsed = System.currentTimeMillis() - start;
            if (resp.statusCode() != 200) return AiResponse.fail(modelId, resp.body());
            return new AiResponse(true, modelId, json.at("/choices/0/message/content").asText(), "",
                elapsed, json.at("/usage/prompt_tokens").asInt(), json.at("/usage/completion_tokens").asInt());
        }, 3);
    }
}

// ─── Provider Factory ──────────────────────────────────
public class AiProviderFactory {
    private final ConcurrentHashMap<String, IAiProvider> providers = new ConcurrentHashMap<>();

    public void register(String name, IAiProvider provider) { providers.put(name.toLowerCase(), provider); }
    public IAiProvider resolve(String name) {
        var p = providers.get(name.toLowerCase());
        if (p == null) throw new IllegalArgumentException("AI provider '" + name + "' not registered. Available: " + providers.keySet());
        return p;
    }
    public Collection<IAiProvider> getAll() { return providers.values(); }
    public Set<String> getRegisteredNames() { return providers.keySet(); }

    public static AiProviderFactory createDefault(String claudeKey, String openAiKey, String geminiKey) {
        var f = new AiProviderFactory();
        if (claudeKey != null && !claudeKey.isEmpty()) f.register("claude", new ClaudeProvider(claudeKey));
        if (openAiKey != null && !openAiKey.isEmpty()) f.register("openai", new OpenAiProvider(openAiKey));
        return f;
    }
}
