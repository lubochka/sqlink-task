<?php
// Skill 06: AI Providers — PHP 8.3 / Guzzle
// Unified IAiProvider for Claude, OpenAI, Gemini
declare(strict_types=1);
namespace XIIGen\AI\Providers;

use GuzzleHttp\Client;

interface IAiProvider {
    public function getProviderName(): string;
    public function execute(AiRequest $request): AiResponse;
    public function estimateTokens(string $text): int;
}

final class AiRequest {
    public function __construct(
        public readonly string $userPrompt,
        public readonly string $systemPrompt = '',
        public readonly string $requestId = '',
        public readonly int $maxTokens = 4096,
        public readonly float $temperature = 0.7,
    ) {}
}

final class AiResponse {
    public function __construct(
        public readonly bool $success,
        public readonly string $model = '',
        public readonly string $content = '',
        public readonly string $error = '',
        public readonly float $durationMs = 0,
        public readonly int $inputTokens = 0,
        public readonly int $outputTokens = 0,
    ) {}

    public static function fail(string $model, string $error): self { return new self(false, $model, error: $error); }
}

abstract class BaseAiProvider implements IAiProvider {
    protected Client $http;
    public function __construct(protected readonly string $apiKey, protected readonly string $modelId) {
        $this->http = new Client(['timeout' => 120]);
    }
    public function estimateTokens(string $text): int { return (int)ceil(strlen($text) / 4); }

    protected function withRetry(callable $fn, int $maxRetries = 3): AiResponse {
        for ($i = 0; $i <= $maxRetries; $i++) {
            try { return $fn(); }
            catch (\Throwable $e) { if ($i === $maxRetries) return AiResponse::fail($this->modelId, $e->getMessage()); usleep((2 ** $i) * 1_000_000); }
        }
        return AiResponse::fail($this->modelId, 'Max retries exceeded');
    }
}

// ─── Claude Provider ───────────────────────────────────
final class ClaudeProvider extends BaseAiProvider {
    public function __construct(string $apiKey, string $modelId = 'claude-sonnet-4-20250514') { parent::__construct($apiKey, $modelId); }
    public function getProviderName(): string { return 'Anthropic'; }

    public function execute(AiRequest $request): AiResponse {
        return $this->withRetry(function () use ($request) {
            $start = microtime(true);
            $resp = $this->http->post('https://api.anthropic.com/v1/messages', [
                'headers' => ['x-api-key' => $this->apiKey, 'anthropic-version' => '2023-06-01', 'Content-Type' => 'application/json'],
                'json' => ['model' => $this->modelId, 'max_tokens' => $request->maxTokens, 'temperature' => $request->temperature,
                    'system' => $request->systemPrompt, 'messages' => [['role' => 'user', 'content' => $request->userPrompt]]]
            ]);
            $data = json_decode($resp->getBody()->getContents(), true);
            $elapsed = (microtime(true) - $start) * 1000;
            return new AiResponse(true, $this->modelId, $data['content'][0]['text'] ?? '', '', $elapsed,
                $data['usage']['input_tokens'] ?? 0, $data['usage']['output_tokens'] ?? 0);
        });
    }
}

// ─── OpenAI Provider ───────────────────────────────────
final class OpenAiProvider extends BaseAiProvider {
    public function __construct(string $apiKey, string $modelId = 'gpt-4o') { parent::__construct($apiKey, $modelId); }
    public function getProviderName(): string { return 'OpenAI'; }

    public function execute(AiRequest $request): AiResponse {
        return $this->withRetry(function () use ($request) {
            $start = microtime(true);
            $messages = [];
            if ($request->systemPrompt) $messages[] = ['role' => 'system', 'content' => $request->systemPrompt];
            $messages[] = ['role' => 'user', 'content' => $request->userPrompt];
            $resp = $this->http->post('https://api.openai.com/v1/chat/completions', [
                'headers' => ['Authorization' => "Bearer {$this->apiKey}", 'Content-Type' => 'application/json'],
                'json' => ['model' => $this->modelId, 'messages' => $messages, 'max_tokens' => $request->maxTokens, 'temperature' => $request->temperature]
            ]);
            $data = json_decode($resp->getBody()->getContents(), true);
            $elapsed = (microtime(true) - $start) * 1000;
            return new AiResponse(true, $this->modelId, $data['choices'][0]['message']['content'] ?? '', '', $elapsed,
                $data['usage']['prompt_tokens'] ?? 0, $data['usage']['completion_tokens'] ?? 0);
        });
    }
}

// ─── Provider Factory ──────────────────────────────────
final class AiProviderFactory {
    /** @var array<string, IAiProvider> */
    private array $providers = [];

    public function register(string $name, IAiProvider $provider): void { $this->providers[strtolower($name)] = $provider; }
    public function resolve(string $name): IAiProvider {
        $p = $this->providers[strtolower($name)] ?? null;
        if (!$p) throw new \InvalidArgumentException("AI provider '$name' not registered. Available: " . implode(', ', array_keys($this->providers)));
        return $p;
    }
    /** @return IAiProvider[] */ public function getAll(): array { return array_values($this->providers); }
    /** @return string[] */ public function getRegisteredNames(): array { return array_keys($this->providers); }

    public static function createDefault(?string $claudeKey = null, ?string $openAiKey = null): self {
        $f = new self();
        if ($claudeKey) $f->register('claude', new ClaudeProvider($claudeKey));
        if ($openAiKey) $f->register('openai', new OpenAiProvider($openAiKey));
        return $f;
    }
}
