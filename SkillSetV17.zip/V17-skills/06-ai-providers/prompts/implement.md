# Skill 06: AI Providers — Implementation Prompts

## Step 1: Create Base Provider
```
Create BaseAiProvider abstract class implementing IAiProvider.
Include: HttpClient, apiKey, modelId, exponential backoff retry (2^attempt seconds, max 3).
Default streaming: falls back to single-chunk non-streaming response.
Token estimation: text.Length / 4 as rough estimate.
```

## Step 2: Implement Claude Provider
```
Implement ClaudeProvider extending BaseAiProvider.
Endpoint: POST https://api.anthropic.com/v1/messages
Headers: x-api-key, anthropic-version: 2023-06-01
Body: { model, max_tokens, temperature, system, messages: [{ role: "user", content }] }
Response: content[0].text, usage.input_tokens, usage.output_tokens
```

## Step 3: Implement OpenAI Provider
```
Implement OpenAiProvider. Endpoint: POST https://api.openai.com/v1/chat/completions
Headers: Authorization: Bearer {key}. Body: { model, messages, max_tokens, temperature }
Response: choices[0].message.content, usage.prompt_tokens, usage.completion_tokens
```

## Step 4: Implement Gemini Provider
```
Implement GeminiProvider. Endpoint: POST https://.../{model}:generateContent?key={key}
Body: { contents: [{ parts: [{ text }] }], generationConfig: { maxOutputTokens, temperature } }
Response: candidates[0].content.parts[0].text
```

## Step 5: Create AiProviderFactory
```
Create factory with Register(name, provider), Resolve(name), All, RegisteredProviders.
CreateDefault(claudeKey, openAiKey, geminiKey) auto-registers non-null keys.
DI: services.AddXIIGenAiProviders(config) reads AI:{Provider}:ApiKey from config.
```


---

## Genie DNA Compliance — MANDATORY for All Implementations

> Before writing ANY code, classify each component:
> **MACHINE** (static): Infrastructure that enables freedom. Build once, generic, interface-based.
> **FREEDOM** (dynamic): Anything users define. No fixed models, config-driven.

### DNA Checklist — Every Implementation MUST:
☐ **DNA-1 (Dynamic Documents):** Store data as `Dictionary<string, object>` / `Record<string, any>` — NOT typed model classes. User fields preserved without schema changes.
☐ **DNA-2 (BuildSearchFilter):** All queries use BuildSearchFilter/equivalent. Empty fields auto-skipped. No entity-specific query code.
☐ **DNA-3 (MicroserviceBase):** Inherit base class with DB, queue, cache, logger built in.
☐ **DNA-5 (DataProcessResult):** All public methods return `DataProcessResult<T>`. Errors return failure, not throw exceptions.
☐ **DNA-6 (Generic Interfaces):** External dependencies behind interfaces. Swap via config.
☐ **DNA-SCOPE:** Non-admin queries auto-inject userId filter. Cannot be bypassed.

### The Three Tests:
1. Can a business user change this without a developer? (YES = correct)
2. Does it work for entity types that do not exist yet? (YES = correct)
3. Can I swap the database/service/UI without changing this? (YES = correct)
