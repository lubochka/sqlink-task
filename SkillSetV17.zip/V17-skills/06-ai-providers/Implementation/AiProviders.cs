// XIIGen.AI/Providers/AiProviders.cs - Skill 06 | .NET 9
using System.Net.Http.Json;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using XIIGen.Core.Enums;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.AI.Providers;

// ─── Base Provider with shared HTTP + retry logic ────
public abstract class BaseAiProvider : IAiProvider
{
    protected readonly HttpClient Http;
    protected readonly string ApiKey;
    protected readonly string ModelId;

    public abstract string ProviderName { get; }
    public abstract AiModelType ModelType { get; }

    protected BaseAiProvider(HttpClient http, string apiKey, string modelId)
    { Http = http; ApiKey = apiKey; ModelId = modelId; }

    public abstract Task<AiResponse> ExecuteAsync(AiRequest request, CancellationToken ct = default);

    public virtual async IAsyncEnumerable<AiStreamChunk> StreamAsync(AiRequest request, [EnumeratorCancellation] CancellationToken ct = default)
    {
        var response = await ExecuteAsync(request, ct);
        yield return new AiStreamChunk { Content = response.Content, IsComplete = true, Usage = response.Usage };
    }

    public abstract Task<AiModelInfo> GetModelInfoAsync(CancellationToken ct = default);
    public virtual Task<int> EstimateTokensAsync(string text, CancellationToken ct = default)
        => Task.FromResult(text.Length / 4); // rough estimate

    protected async Task<AiResponse> ExecuteWithRetryAsync(Func<Task<AiResponse>> action, int maxRetries = 3)
    {
        for (int i = 0; i <= maxRetries; i++)
        {
            try { return await action(); }
            catch (HttpRequestException) when (i < maxRetries)
            { await Task.Delay(TimeSpan.FromSeconds(Math.Pow(2, i))); }
        }
        return new AiResponse { Success = false, Error = "Max retries exceeded" };
    }
}

// ─── Claude Provider ────────────────────────────────
public class ClaudeProvider : BaseAiProvider
{
    public override string ProviderName => "Anthropic";
    public override AiModelType ModelType => AiModelType.Claude;

    public ClaudeProvider(HttpClient http, string apiKey, string modelId = "claude-sonnet-4-20250514")
        : base(http, apiKey, modelId) { }

    public override Task<AiResponse> ExecuteAsync(AiRequest request, CancellationToken ct = default)
        => ExecuteWithRetryAsync(async () =>
        {
            var sw = System.Diagnostics.Stopwatch.StartNew();
            var body = new
            {
                model = ModelId,
                max_tokens = request.MaxTokens,
                temperature = request.Temperature,
                system = request.SystemPrompt ?? "",
                messages = new[] { new { role = "user", content = request.UserPrompt } }
            };
            var msg = new HttpRequestMessage(HttpMethod.Post, "https://api.anthropic.com/v1/messages");
            msg.Headers.Add("x-api-key", ApiKey);
            msg.Headers.Add("anthropic-version", "2023-06-01");
            msg.Content = new StringContent(JsonSerializer.Serialize(body), Encoding.UTF8, "application/json");

            var resp = await Http.SendAsync(msg, ct);
            var json = await resp.Content.ReadFromJsonAsync<JsonElement>(ct);
            sw.Stop();

            if (!resp.IsSuccessStatusCode)
                return new AiResponse { RequestId = request.RequestId, Model = ModelId, Success = false, Error = json.ToString() };

            var content = json.GetProperty("content")[0].GetProperty("text").GetString();
            var usage = json.GetProperty("usage");
            return new AiResponse
            {
                RequestId = request.RequestId, Model = ModelId, Content = content, Success = true, Duration = sw.Elapsed,
                Usage = new AiUsage
                {
                    InputTokens = usage.GetProperty("input_tokens").GetInt32(),
                    OutputTokens = usage.GetProperty("output_tokens").GetInt32()
                }
            };
        });

    public override Task<AiModelInfo> GetModelInfoAsync(CancellationToken ct = default)
        => Task.FromResult(new AiModelInfo { ModelId = ModelId, Provider = "Anthropic", MaxTokens = 200000, SupportsStreaming = true, SupportsVision = true });
}

// ─── OpenAI Provider ────────────────────────────────
public class OpenAiProvider : BaseAiProvider
{
    public override string ProviderName => "OpenAI";
    public override AiModelType ModelType => AiModelType.OpenAI;

    public OpenAiProvider(HttpClient http, string apiKey, string modelId = "gpt-4o")
        : base(http, apiKey, modelId) { }

    public override Task<AiResponse> ExecuteAsync(AiRequest request, CancellationToken ct = default)
        => ExecuteWithRetryAsync(async () =>
        {
            var sw = System.Diagnostics.Stopwatch.StartNew();
            var messages = new List<object>();
            if (!string.IsNullOrEmpty(request.SystemPrompt))
                messages.Add(new { role = "system", content = request.SystemPrompt });
            messages.Add(new { role = "user", content = request.UserPrompt });

            var body = new { model = ModelId, messages, max_tokens = request.MaxTokens, temperature = request.Temperature };
            var msg = new HttpRequestMessage(HttpMethod.Post, "https://api.openai.com/v1/chat/completions");
            msg.Headers.Add("Authorization", $"Bearer {ApiKey}");
            msg.Content = new StringContent(JsonSerializer.Serialize(body), Encoding.UTF8, "application/json");

            var resp = await Http.SendAsync(msg, ct);
            var json = await resp.Content.ReadFromJsonAsync<JsonElement>(ct);
            sw.Stop();

            if (!resp.IsSuccessStatusCode)
                return new AiResponse { RequestId = request.RequestId, Model = ModelId, Success = false, Error = json.ToString() };

            var content = json.GetProperty("choices")[0].GetProperty("message").GetProperty("content").GetString();
            var usage = json.GetProperty("usage");
            return new AiResponse
            {
                RequestId = request.RequestId, Model = ModelId, Content = content, Success = true, Duration = sw.Elapsed,
                Usage = new AiUsage { InputTokens = usage.GetProperty("prompt_tokens").GetInt32(), OutputTokens = usage.GetProperty("completion_tokens").GetInt32() }
            };
        });

    public override Task<AiModelInfo> GetModelInfoAsync(CancellationToken ct = default)
        => Task.FromResult(new AiModelInfo { ModelId = ModelId, Provider = "OpenAI", MaxTokens = 128000, SupportsStreaming = true, SupportsVision = true });
}

// ─── Gemini Provider ────────────────────────────────
public class GeminiProvider : BaseAiProvider
{
    public override string ProviderName => "Google";
    public override AiModelType ModelType => AiModelType.Gemini;

    public GeminiProvider(HttpClient http, string apiKey, string modelId = "gemini-2.0-flash")
        : base(http, apiKey, modelId) { }

    public override Task<AiResponse> ExecuteAsync(AiRequest request, CancellationToken ct = default)
        => ExecuteWithRetryAsync(async () =>
        {
            var sw = System.Diagnostics.Stopwatch.StartNew();
            var body = new
            {
                contents = new[] { new { parts = new[] { new { text = $"{request.SystemPrompt}\n\n{request.UserPrompt}" } } } },
                generationConfig = new { maxOutputTokens = request.MaxTokens, temperature = request.Temperature }
            };
            var url = $"https://generativelanguage.googleapis.com/v1/models/{ModelId}:generateContent?key={ApiKey}";
            var resp = await Http.PostAsJsonAsync(url, body, ct);
            var json = await resp.Content.ReadFromJsonAsync<JsonElement>(ct);
            sw.Stop();

            if (!resp.IsSuccessStatusCode)
                return new AiResponse { RequestId = request.RequestId, Model = ModelId, Success = false, Error = json.ToString() };

            var content = json.GetProperty("candidates")[0].GetProperty("content").GetProperty("parts")[0].GetProperty("text").GetString();
            return new AiResponse { RequestId = request.RequestId, Model = ModelId, Content = content, Success = true, Duration = sw.Elapsed, Usage = new AiUsage() };
        });

    public override Task<AiModelInfo> GetModelInfoAsync(CancellationToken ct = default)
        => Task.FromResult(new AiModelInfo { ModelId = ModelId, Provider = "Google", MaxTokens = 1000000, SupportsStreaming = true, SupportsVision = true });
}

// ─── Deepseek Provider ──────────────────────────────
public class DeepseekProvider : BaseAiProvider
{
    public override string ProviderName => "Deepseek";
    public override AiModelType ModelType => AiModelType.Deepseek;

    public DeepseekProvider(HttpClient http, string apiKey, string modelId = "deepseek-coder")
        : base(http, apiKey, modelId) { }

    public override Task<AiResponse> ExecuteAsync(AiRequest request, CancellationToken ct = default)
        => ExecuteWithRetryAsync(async () =>
        {
            var sw = System.Diagnostics.Stopwatch.StartNew();
            var messages = new List<object>();
            if (!string.IsNullOrEmpty(request.SystemPrompt)) messages.Add(new { role = "system", content = request.SystemPrompt });
            messages.Add(new { role = "user", content = request.UserPrompt });

            var body = new { model = ModelId, messages, max_tokens = request.MaxTokens, temperature = request.Temperature };
            var msg = new HttpRequestMessage(HttpMethod.Post, "https://api.deepseek.com/v1/chat/completions");
            msg.Headers.Add("Authorization", $"Bearer {ApiKey}");
            msg.Content = new StringContent(JsonSerializer.Serialize(body), Encoding.UTF8, "application/json");

            var resp = await Http.SendAsync(msg, ct);
            var json = await resp.Content.ReadFromJsonAsync<JsonElement>(ct);
            sw.Stop();

            if (!resp.IsSuccessStatusCode) return new AiResponse { RequestId = request.RequestId, Model = ModelId, Success = false, Error = json.ToString() };
            var content = json.GetProperty("choices")[0].GetProperty("message").GetProperty("content").GetString();
            return new AiResponse { RequestId = request.RequestId, Model = ModelId, Content = content, Success = true, Duration = sw.Elapsed, Usage = new AiUsage() };
        });

    public override Task<AiModelInfo> GetModelInfoAsync(CancellationToken ct = default)
        => Task.FromResult(new AiModelInfo { ModelId = ModelId, Provider = "Deepseek", MaxTokens = 64000, SupportsStreaming = true });
}

// ─── Provider Factory ───────────────────────────────
public class AiProviderFactory
{
    private readonly Dictionary<string, IAiProvider> _providers = [];

    public void Register(string name, IAiProvider provider) => _providers[name.ToLower()] = provider;
    public IAiProvider Resolve(string name) => _providers.TryGetValue(name.ToLower(), out var p) ? p : throw new KeyNotFoundException($"AI provider '{name}' not registered");
    public IEnumerable<string> RegisteredProviders => _providers.Keys;
    public IEnumerable<IAiProvider> All => _providers.Values;

    public static AiProviderFactory CreateDefault(string claudeKey = null, string openAiKey = null, string geminiKey = null, string deepseekKey = null)
    {
        var factory = new AiProviderFactory();
        var http = new HttpClient();
        if (!string.IsNullOrEmpty(claudeKey)) factory.Register("claude", new ClaudeProvider(http, claudeKey));
        if (!string.IsNullOrEmpty(openAiKey)) factory.Register("openai", new OpenAiProvider(http, openAiKey));
        if (!string.IsNullOrEmpty(geminiKey)) factory.Register("gemini", new GeminiProvider(http, geminiKey));
        if (!string.IsNullOrEmpty(deepseekKey)) factory.Register("deepseek", new DeepseekProvider(http, deepseekKey));
        return factory;
    }
}
