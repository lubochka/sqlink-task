# Implement Skill 18: Documentation Service

## Context
You are implementing the Documentation Service for XIIGen. This service auto-generates README, API docs, architecture docs with Mermaid diagrams, and deployment guides.

## Steps

1. **Read** `skills/18-documentation-service/SKILL.md` completely
2. **Create Models** — `DocType` enum, `DiagramType` enum, `GeneratedDoc`, `MermaidDiagram`, `DocGenerationRequest`
3. **Create Interface** — `IDocumentationService` with `GenerateAsync`, `GenerateReadmeAsync`, `GenerateArchitectureDocAsync`, `GenerateDiagram`, `GenerateFullDocSetAsync`
4. **Implement Service** — `DocumentationService` extending `MicroserviceBase`
   - Markdown templates with `{{variable}}` placeholders for each DocType
   - Mermaid flowchart generation from flow definitions (steps + edges)
   - Optional AI enhancement via `IAiProvider`
   - Full doc set generation (README + Architecture + API + Deployment)
5. **Register DI** — `services.AddSingleton<IDocumentationService, DocumentationService>()`
6. **Add API Routes** — `POST /api/docs/generate`, `POST /api/docs/full-set`
7. **Write Tests** — README contains project name, diagram returns valid Mermaid, full set returns 4 docs

## Verification Checklist
- [ ] Templates defined for all DocTypes (readme, api, architecture, deployment, changelog)
- [ ] Variable substitution works in templates
- [ ] Mermaid flowchart generated from flow steps (id + name → nodes + edges)
- [ ] AI enhancement optional (works with or without IAiProvider)
- [ ] Full doc set returns README + Architecture + API + Deployment
- [ ] Results stored in Elasticsearch index `xiigen-docs`

## Key Files
- SKILL.md: `skills/18-documentation-service/SKILL.md`
- Existing .cs: `skills/18-documentation-service/Implementation/DocumentationService.cs`
- Alternatives: `skills/18-documentation-service/alternatives/{nodejs,python,java,rust,php}/`


---

## Genie DNA Compliance — MANDATORY for All Implementations

> Before writing ANY code, classify each component:
> **MACHINE** (static): Infrastructure that enables freedom. Build once, generic, interface-based.
> **FREEDOM** (dynamic): Anything users define. No fixed models, config-driven.

### DNA Checklist — Every Implementation MUST:
☐ **DNA-1 (Dynamic Documents):** Store data as `Dictionary<string, object>` / `Record<string, any>` — NOT typed model classes. User fields preserved without schema changes.
☐ **DNA-2 (BuildSearchFilter):** All queries use BuildSearchFilter/equivalent. Empty fields auto-skipped. No entity-specific query code.
☐ **DNA-3 (MicroserviceBase):** Inherit base class with DB, queue, cache, logger built in.
☐ **DNA-5 (DataProcessResult):** All public methods return `DataProcessResult<T>`. Errors return failure, not throw exceptions.
☐ **DNA-6 (Generic Interfaces):** External dependencies behind interfaces. Swap via config.
☐ **DNA-SCOPE:** Non-admin queries auto-inject userId filter. Cannot be bypassed.

### The Three Tests:
1. Can a business user change this without a developer? (YES = correct)
2. Does it work for entity types that do not exist yet? (YES = correct)
3. Can I swap the database/service/UI without changing this? (YES = correct)
