// XIIGen.Services.Docs/DocumentationService.cs - Skill 18 | .NET 9
using Microsoft.Extensions.Logging;
using XIIGen.Core.Base;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Services.Docs;

public class DocumentationService : MicroserviceBase
{
    public DocumentationService(IDatabaseService db, IQueueService queue, ILogger<DocumentationService> logger)
        : base(db, queue, logger) { ServiceName = "documentation-service"; }

    public async Task<DataProcessResult<object>> GenerateArchitectureDocAsync(string systemId, IAiProvider aiProvider, CancellationToken ct = default)
    {
        var flows = await SearchDocumentsAsync("flow-definitions", new { }, 100, ct);
        var prompt = $"Generate comprehensive architecture documentation for a system with the following flows:\n\n{System.Text.Json.JsonSerializer.Serialize(flows.Data)}";
        var response = await aiProvider.ExecuteAsync(new AiRequest { SystemPrompt = "You are a technical writer. Generate clear, comprehensive architecture documentation.", UserPrompt = prompt }, ct);
        var doc = new { SystemId = systemId, Type = "architecture", Content = response.Content, GeneratedAt = DateTime.UtcNow };
        await StoreDocumentAsync("generated-docs", $"arch-{systemId}", doc, ct: ct);
        return DataProcessResult<object>.Success(doc);
    }

    public async Task<DataProcessResult<object>> GenerateApiDocAsync(string serviceId, IAiProvider aiProvider, CancellationToken ct = default)
    {
        var doc = new { ServiceId = serviceId, Type = "api", GeneratedAt = DateTime.UtcNow };
        await StoreDocumentAsync("generated-docs", $"api-{serviceId}", doc, ct: ct);
        return DataProcessResult<object>.Success(doc);
    }
}
