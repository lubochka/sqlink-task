// Skill 18: Documentation Service — Node.js/TypeScript | marked + Mermaid
import { marked } from "marked";

type DocType = "readme" | "api" | "architecture" | "component" | "deployment" | "changelog";
type DiagramType = "flowchart" | "sequence" | "class" | "er";
interface GeneratedDoc { docId: string; type: DocType; title: string; content: string; mermaidDiagram?: string; }
interface MermaidDiagram { type: DiagramType; title: string; source: string; }
interface DocRequest { projectName: string; type: DocType; variables: Record<string, string>; codeUnits?: string[]; flowDef?: any; aiEnhance?: boolean; }

const TEMPLATES: Record<DocType, string> = {
  readme: "# {{ProjectName}}\n\n## Overview\n\n{{Description}}\n\n## Getting Started\n\n```bash\n{{InstallCommand}}\n{{RunCommand}}\n```\n\n## Structure\n\n{{Structure}}",
  api: "# {{ProjectName}} API\n\n## Base URL\n\n`{{BaseUrl}}`\n\n## Endpoints\n\n{{Endpoints}}\n\n## Models\n\n{{Models}}",
  architecture: "# {{ProjectName}} Architecture\n\n## Overview\n\n{{Overview}}\n\n## Diagram\n\n```mermaid\n{{Diagram}}\n```\n\n## Components\n\n{{Components}}",
  deployment: "# {{ProjectName}} Deployment\n\n## Prerequisites\n\n{{Prerequisites}}\n\n## Docker\n\n```bash\ndocker build -t {{projectName}} .\n```",
  component: "# {{ProjectName}} Components\n\n{{Components}}",
  changelog: "# Changelog\n\n## [{{Version}}] - {{Date}}\n\n### Added\n\n{{Changes}}",
};

function subVars(text: string, vars: Record<string, string>): string {
  return Object.entries(vars).reduce((t, [k, v]) => t.replaceAll(`{{${k}}}`, v), text);
}

function generateFlowchart(title: string, flowDef: any): string {
  let mermaid = `flowchart TD\n    START[${title}]\n`;
  let prev = "START";
  if (flowDef?.steps) {
    for (const step of flowDef.steps) {
      const id = step.id || "step"; const name = step.name || id;
      mermaid += `    ${id}[${name}]\n    ${prev} --> ${id}\n`;
      prev = id;
    }
  }
  return mermaid;
}

export function generateDiagram(type: DiagramType, title: string, flowDef: any): MermaidDiagram {
  const source = type === "flowchart" ? generateFlowchart(title, flowDef)
    : type === "sequence" ? `sequenceDiagram\n    participant C as Client\n    participant S as Server\n    C->>S: Request\n    S-->>C: Response`
    : `classDiagram\n    class ${title} {\n        +execute()\n    }`;
  return { type, title, source };
}

export async function generate(request: DocRequest): Promise<GeneratedDoc> {
  const template = TEMPLATES[request.type] || "# {{ProjectName}}\n\n{{Content}}";
  let content = subVars(template, request.variables);
  let diagram: string | undefined;
  if (request.type === "architecture" && request.flowDef) {
    const m = generateDiagram("flowchart", request.projectName, request.flowDef);
    diagram = m.source; content = content.replace("{{Diagram}}", diagram);
  }
  return { docId: crypto.randomUUID(), type: request.type, title: `${request.projectName} - ${request.type}`, content, mermaidDiagram: diagram };
}

export async function generateReadme(projectName: string, codeUnits: string[]): Promise<GeneratedDoc> {
  return generate({ projectName, type: "readme", variables: { ProjectName: projectName, Description: `Generated: ${projectName}`,
    InstallCommand: "npm install", RunCommand: "npm start", Structure: codeUnits.map(u => `- ${u}`).join("\n") } });
}

export async function generateFullDocSet(projectName: string, codeUnits: string[], flowDef: any): Promise<GeneratedDoc[]> {
  return Promise.all([
    generateReadme(projectName, codeUnits),
    generate({ projectName, type: "architecture", variables: { ProjectName: projectName, Overview: `Architecture for ${projectName}`, Diagram: "", Components: "See docs" }, flowDef }),
    generate({ projectName, type: "api", variables: { ProjectName: projectName, BaseUrl: "/api", Endpoints: "Auto-generated", Models: "See source" } }),
    generate({ projectName, type: "deployment", variables: { ProjectName: projectName, projectName: projectName.toLowerCase(), Prerequisites: "Docker, kubectl" } }),
  ]);
}

export function registerRoutes(app: any) {
  app.post("/api/docs/generate", async (req: any) => generate(req.body));
  app.post("/api/docs/full-set", async (req: any) => generateFullDocSet(req.body.projectName, req.body.codeUnits, req.body.flowDef));
}
