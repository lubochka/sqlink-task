// Skill 18: Documentation Service — Java 21 | FreeMarker + flexmark + records
package com.xiigen.docs;

import java.util.*;
import java.util.stream.*;

public class DocumentationService {

    public enum DocType { README, API, ARCHITECTURE, COMPONENT, DEPLOYMENT, CHANGELOG }
    public enum DiagramType { FLOWCHART, SEQUENCE, CLASS, ER }

    public record GeneratedDoc(String docId, DocType type, String title, String content, String mermaidDiagram) {}
    public record MermaidDiagram(DiagramType type, String title, String source) {}

    private static final Map<DocType, String> TEMPLATES = Map.of(
        DocType.README, "# {{ProjectName}}\n\n## Overview\n\n{{Description}}\n\n## Getting Started\n\n```bash\n{{InstallCommand}}\n```\n\n## Structure\n\n{{Structure}}",
        DocType.API, "# {{ProjectName}} API\n\n## Base URL\n\n`{{BaseUrl}}`\n\n## Endpoints\n\n{{Endpoints}}",
        DocType.ARCHITECTURE, "# {{ProjectName}} Architecture\n\n## Overview\n\n{{Overview}}\n\n```mermaid\n{{Diagram}}\n```",
        DocType.DEPLOYMENT, "# {{ProjectName}} Deployment\n\n## Docker\n\n```bash\ndocker build -t {{projectName}} .\n```"
    );

    private static String subVars(String text, Map<String, String> vars) {
        for (var e : vars.entrySet()) text = text.replace("{{" + e.getKey() + "}}", e.getValue());
        return text;
    }

    public MermaidDiagram generateDiagram(DiagramType type, String title, Map<String, Object> flowDef) {
        if (type == DiagramType.FLOWCHART && flowDef != null && flowDef.containsKey("steps")) {
            var sb = new StringBuilder("flowchart TD\n    START[" + title + "]\n");
            String prev = "START";
            var steps = (List<Map<String, String>>) flowDef.get("steps");
            for (var step : steps) {
                String id = step.getOrDefault("id", "s"), name = step.getOrDefault("name", id);
                sb.append("    ").append(id).append("[").append(name).append("]\n    ").append(prev).append(" --> ").append(id).append("\n");
                prev = id;
            }
            return new MermaidDiagram(type, title, sb.toString());
        }
        return new MermaidDiagram(type, title, "sequenceDiagram\n    participant C as Client\n    C->>S: Request");
    }

    public GeneratedDoc generate(String projectName, DocType type, Map<String, String> variables, Map<String, Object> flowDef) {
        String template = TEMPLATES.getOrDefault(type, "# {{ProjectName}}");
        String content = subVars(template, variables);
        String diagram = null;
        if (type == DocType.ARCHITECTURE && flowDef != null) {
            var m = generateDiagram(DiagramType.FLOWCHART, projectName, flowDef);
            diagram = m.source(); content = content.replace("{{Diagram}}", diagram);
        }
        return new GeneratedDoc(UUID.randomUUID().toString(), type, projectName + " - " + type, content, diagram);
    }

    public GeneratedDoc generateReadme(String projectName, List<String> codeUnits) {
        String structure = codeUnits.stream().map(u -> "- " + u).collect(Collectors.joining("\n"));
        return generate(projectName, DocType.README, Map.of("ProjectName", projectName, "Description", "Generated: " + projectName,
            "InstallCommand", "npm install", "Structure", structure), null);
    }

    public List<GeneratedDoc> generateFullDocSet(String projectName, List<String> codeUnits, Map<String, Object> flowDef) {
        return List.of(
            generateReadme(projectName, codeUnits),
            generate(projectName, DocType.ARCHITECTURE, Map.of("ProjectName", projectName, "Overview", "Architecture for " + projectName, "Diagram", ""), flowDef),
            generate(projectName, DocType.API, Map.of("ProjectName", projectName, "BaseUrl", "/api", "Endpoints", "Auto-generated"), null),
            generate(projectName, DocType.DEPLOYMENT, Map.of("ProjectName", projectName, "projectName", projectName.toLowerCase()), null)
        );
    }
}
