// Skill 18: Documentation Service — Rust | pulldown-cmark + tera
use std::collections::HashMap;
use serde::{Deserialize, Serialize};
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum DocType { Readme, Api, Architecture, Component, Deployment, Changelog }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum DiagramType { Flowchart, Sequence, Class, Er }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GeneratedDoc { pub doc_id: String, pub doc_type: DocType, pub title: String, pub content: String, pub mermaid_diagram: Option<String> }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MermaidDiagram { pub diagram_type: DiagramType, pub title: String, pub source: String }

fn get_templates() -> HashMap<String, String> {
    HashMap::from([
        ("readme".into(), "# {{ProjectName}}\n\n## Overview\n\n{{Description}}\n\n## Getting Started\n\n```bash\n{{InstallCommand}}\n```\n\n## Structure\n\n{{Structure}}".into()),
        ("api".into(), "# {{ProjectName}} API\n\n## Base URL\n\n`{{BaseUrl}}`\n\n## Endpoints\n\n{{Endpoints}}".into()),
        ("architecture".into(), "# {{ProjectName}} Architecture\n\n## Overview\n\n{{Overview}}\n\n```mermaid\n{{Diagram}}\n```".into()),
        ("deployment".into(), "# {{ProjectName}} Deployment\n\n## Docker\n\n```bash\ndocker build -t {{projectName}} .\n```".into()),
    ])
}

fn sub_vars(text: &str, vars: &HashMap<String, String>) -> String {
    let mut result = text.to_string();
    for (k, v) in vars { result = result.replace(&format!("{{{{{}}}}}", k), v); }
    result
}

pub fn generate_diagram(dtype: DiagramType, title: &str, flow_def: &Option<serde_json::Value>) -> MermaidDiagram {
    if let (DiagramType::Flowchart, Some(fd)) = (&dtype, flow_def) {
        let mut lines = vec![format!("flowchart TD\n    START[{}]", title)];
        let mut prev = "START".to_string();
        if let Some(steps) = fd.get("steps").and_then(|s| s.as_array()) {
            for step in steps {
                let id = step.get("id").and_then(|v| v.as_str()).unwrap_or("s");
                let name = step.get("name").and_then(|v| v.as_str()).unwrap_or(id);
                lines.push(format!("    {}[{}]\n    {} --> {}", id, name, prev, id));
                prev = id.to_string();
            }
        }
        return MermaidDiagram { diagram_type: dtype, title: title.into(), source: lines.join("\n") };
    }
    MermaidDiagram { diagram_type: dtype, title: title.into(),
        source: "sequenceDiagram\n    participant C as Client\n    C->>S: Request\n    S-->>C: Response".into() }
}

pub fn generate(project_name: &str, doc_type: DocType, variables: &HashMap<String, String>, flow_def: &Option<serde_json::Value>) -> GeneratedDoc {
    let templates = get_templates();
    let type_key = format!("{:?}", doc_type).to_lowercase();
    let template = templates.get(&type_key).cloned().unwrap_or_else(|| format!("# {}", project_name));
    let mut content = sub_vars(&template, variables);
    let mut diagram = None;
    if matches!(doc_type, DocType::Architecture) && flow_def.is_some() {
        let m = generate_diagram(DiagramType::Flowchart, project_name, flow_def);
        content = content.replace("{{Diagram}}", &m.source);
        diagram = Some(m.source);
    }
    GeneratedDoc { doc_id: Uuid::new_v4().to_string(), doc_type, title: format!("{} - {:?}", project_name, doc_type), content, mermaid_diagram: diagram }
}

pub fn generate_readme(project_name: &str, code_units: &[String]) -> GeneratedDoc {
    let structure = code_units.iter().map(|u| format!("- {}", u)).collect::<Vec<_>>().join("\n");
    let vars = HashMap::from([("ProjectName".into(), project_name.into()), ("Description".into(), format!("Generated: {}", project_name)),
        ("InstallCommand".into(), "npm install".into()), ("Structure".into(), structure)]);
    generate(project_name, DocType::Readme, &vars, &None)
}

pub fn generate_full_doc_set(project_name: &str, code_units: &[String], flow_def: serde_json::Value) -> Vec<GeneratedDoc> {
    vec![
        generate_readme(project_name, code_units),
        generate(project_name, DocType::Architecture, &HashMap::from([("ProjectName".into(), project_name.into()), ("Overview".into(), format!("Architecture for {}", project_name)), ("Diagram".into(), String::new())]), &Some(flow_def.clone())),
        generate(project_name, DocType::Api, &HashMap::from([("ProjectName".into(), project_name.into()), ("BaseUrl".into(), "/api".into()), ("Endpoints".into(), "Auto-generated".into())]), &None),
        generate(project_name, DocType::Deployment, &HashMap::from([("ProjectName".into(), project_name.into()), ("projectName".into(), project_name.to_lowercase())]), &None),
    ]
}
