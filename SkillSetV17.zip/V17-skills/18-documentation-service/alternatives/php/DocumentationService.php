<?php
// Skill 18: Documentation Service — PHP 8.3 | Blade + league/commonmark
declare(strict_types=1);
namespace App\Services\Docs;

enum DocType: string { case Readme = 'readme'; case Api = 'api'; case Architecture = 'architecture'; case Deployment = 'deployment'; case Changelog = 'changelog'; }
enum DiagramType: string { case Flowchart = 'flowchart'; case Sequence = 'sequence'; case ClassDiag = 'class'; case Er = 'er'; }

readonly class GeneratedDoc { public function __construct(public string $docId, public DocType $type, public string $title, public string $content, public ?string $mermaidDiagram = null) {} }
readonly class MermaidDiagram { public function __construct(public DiagramType $type, public string $title, public string $source) {} }

class DocumentationService
{
    private const TEMPLATES = [
        'readme' => "# {{ProjectName}}\n\n## Overview\n\n{{Description}}\n\n## Getting Started\n\n```bash\n{{InstallCommand}}\n```\n\n## Structure\n\n{{Structure}}",
        'api' => "# {{ProjectName}} API\n\n## Base URL\n\n`{{BaseUrl}}`\n\n## Endpoints\n\n{{Endpoints}}",
        'architecture' => "# {{ProjectName}} Architecture\n\n## Overview\n\n{{Overview}}\n\n```mermaid\n{{Diagram}}\n```",
        'deployment' => "# {{ProjectName}} Deployment\n\n## Docker\n\n```bash\ndocker build -t {{projectName}} .\n```",
    ];

    public function generateDiagram(DiagramType $type, string $title, ?array $flowDef = null): MermaidDiagram
    {
        if ($type === DiagramType::Flowchart && $flowDef && isset($flowDef['steps'])) {
            $lines = ["flowchart TD\n    START[$title]"]; $prev = 'START';
            foreach ($flowDef['steps'] as $step) {
                $id = $step['id'] ?? 's'; $name = $step['name'] ?? $id;
                $lines[] = "    {$id}[{$name}]\n    {$prev} --> {$id}"; $prev = $id;
            }
            return new MermaidDiagram($type, $title, implode("\n", $lines));
        }
        return new MermaidDiagram($type, $title, "sequenceDiagram\n    participant C as Client\n    C->>S: Request");
    }

    public function generate(string $projectName, DocType $type, array $variables, ?array $flowDef = null): GeneratedDoc
    {
        $template = self::TEMPLATES[$type->value] ?? "# {{ProjectName}}";
        $content = $this->subVars($template, $variables);
        $diagram = null;
        if ($type === DocType::Architecture && $flowDef) {
            $m = $this->generateDiagram(DiagramType::Flowchart, $projectName, $flowDef);
            $diagram = $m->source; $content = str_replace('{{Diagram}}', $diagram, $content);
        }
        return new GeneratedDoc(uniqid('doc-'), $type, "$projectName - {$type->value}", $content, $diagram);
    }

    public function generateReadme(string $projectName, array $codeUnits): GeneratedDoc
    {
        $structure = implode("\n", array_map(fn($u) => "- $u", $codeUnits));
        return $this->generate($projectName, DocType::Readme, ['ProjectName' => $projectName, 'Description' => "Generated: $projectName",
            'InstallCommand' => 'npm install', 'Structure' => $structure]);
    }

    public function generateFullDocSet(string $projectName, array $codeUnits, array $flowDef): array
    {
        return [
            $this->generateReadme($projectName, $codeUnits),
            $this->generate($projectName, DocType::Architecture, ['ProjectName' => $projectName, 'Overview' => "Architecture for $projectName", 'Diagram' => ''], $flowDef),
            $this->generate($projectName, DocType::Api, ['ProjectName' => $projectName, 'BaseUrl' => '/api', 'Endpoints' => 'Auto-generated']),
            $this->generate($projectName, DocType::Deployment, ['ProjectName' => $projectName, 'projectName' => strtolower($projectName)]),
        ];
    }

    private function subVars(string $text, array $vars): string
    { foreach ($vars as $k => $v) { $text = str_replace("{{{$k}}}", $v, $text); } return $text; }
}
