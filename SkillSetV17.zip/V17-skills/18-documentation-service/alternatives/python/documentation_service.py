# Skill 18: Documentation Service — Python 3.12 | Jinja2 + mdformat
from dataclasses import dataclass
from enum import Enum
from uuid import uuid4
import json

class DocType(Enum):
    README = "readme"; API = "api"; ARCHITECTURE = "architecture"; COMPONENT = "component"; DEPLOYMENT = "deployment"; CHANGELOG = "changelog"

class DiagramType(Enum):
    FLOWCHART = "flowchart"; SEQUENCE = "sequence"; CLASS = "class"; ER = "er"

@dataclass
class GeneratedDoc:
    doc_id: str; type: DocType; title: str; content: str; mermaid_diagram: str | None = None

@dataclass
class MermaidDiagram:
    type: DiagramType; title: str; source: str

TEMPLATES = {
    DocType.README: "# {{ProjectName}}\n\n## Overview\n\n{{Description}}\n\n## Getting Started\n\n```bash\n{{InstallCommand}}\n{{RunCommand}}\n```\n\n## Structure\n\n{{Structure}}",
    DocType.API: "# {{ProjectName}} API\n\n## Base URL\n\n`{{BaseUrl}}`\n\n## Endpoints\n\n{{Endpoints}}",
    DocType.ARCHITECTURE: "# {{ProjectName}} Architecture\n\n## Overview\n\n{{Overview}}\n\n```mermaid\n{{Diagram}}\n```",
    DocType.DEPLOYMENT: "# {{ProjectName}} Deployment\n\n## Docker\n\n```bash\ndocker build -t {{projectName}} .\n```",
    DocType.CHANGELOG: "# Changelog\n\n## [{{Version}}] - {{Date}}\n\n{{Changes}}",
}

def _sub_vars(text: str, variables: dict[str, str]) -> str:
    for k, v in variables.items(): text = text.replace(f"{{{{{k}}}}}", v)
    return text

def generate_diagram(dtype: DiagramType, title: str, flow_def: dict | None = None) -> MermaidDiagram:
    if dtype == DiagramType.FLOWCHART and flow_def:
        lines = [f"flowchart TD\n    START[{title}]"]; prev = "START"
        for step in flow_def.get("steps", []):
            sid, name = step.get("id", "s"), step.get("name", step.get("id", "s"))
            lines.append(f"    {sid}[{name}]\n    {prev} --> {sid}"); prev = sid
        return MermaidDiagram(dtype, title, "\n".join(lines))
    return MermaidDiagram(dtype, title, f"sequenceDiagram\n    participant C as Client\n    participant S as Server\n    C->>S: Request\n    S-->>C: Response")

async def generate(project_name: str, doc_type: DocType, variables: dict[str, str], flow_def: dict | None = None) -> GeneratedDoc:
    template = TEMPLATES.get(doc_type, "# {{ProjectName}}\n\n{{Content}}")
    content = _sub_vars(template, variables)
    diagram = None
    if doc_type == DocType.ARCHITECTURE and flow_def:
        m = generate_diagram(DiagramType.FLOWCHART, project_name, flow_def)
        diagram = m.source; content = content.replace("{{Diagram}}", diagram)
    return GeneratedDoc(str(uuid4()), doc_type, f"{project_name} - {doc_type.value}", content, diagram)

async def generate_readme(project_name: str, code_units: list[str]) -> GeneratedDoc:
    return await generate(project_name, DocType.README, {"ProjectName": project_name, "Description": f"Generated: {project_name}",
        "InstallCommand": "npm install", "RunCommand": "npm start", "Structure": "\n".join(f"- {u}" for u in code_units)})

async def generate_full_doc_set(project_name: str, code_units: list[str], flow_def: dict) -> list[GeneratedDoc]:
    return [
        await generate_readme(project_name, code_units),
        await generate(project_name, DocType.ARCHITECTURE, {"ProjectName": project_name, "Overview": f"Architecture for {project_name}", "Diagram": ""}, flow_def),
        await generate(project_name, DocType.API, {"ProjectName": project_name, "BaseUrl": "/api", "Endpoints": "Auto-generated"}),
        await generate(project_name, DocType.DEPLOYMENT, {"ProjectName": project_name, "projectName": project_name.lower(), "Prerequisites": "Docker"}),
    ]

def register_routes(app):
    from fastapi import APIRouter
    router = APIRouter(prefix="/api/docs")
    @router.post("/generate")
    async def gen(req: dict): return await generate(req["projectName"], DocType(req["type"]), req.get("variables", {}), req.get("flowDef"))
    @router.post("/full-set")
    async def full(req: dict): return await generate_full_doc_set(req["projectName"], req.get("codeUnits", []), req.get("flowDef", {}))
    app.include_router(router)
