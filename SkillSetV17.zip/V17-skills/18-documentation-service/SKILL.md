---
name: documentation-service
description: Auto-generate README, API docs, architecture docs, and Mermaid diagrams
triggers: generate docs, readme, api documentation, mermaid diagram, architecture docs
dependencies: [01-core-interfaces, 02-object-processor, 03-elasticsearch-datastore, 06-ai-providers]
layer: L5-Application
genie-dna: "Documentation metadata stored as dynamic documents. Template vars resolved via ParseObjectAlternative. All queries use BuildSearchFilter."
---

# Skill 18: Documentation Service
## Auto-generate README, API docs, architecture docs, and Mermaid diagrams from code and flows

**Status:** Ready to Generate  
**Priority:** P1 — Every generated project needs documentation  
**Dependencies:** Skill 01 (Core Interfaces), Skill 03 (Database Fabric), Skill 06 (AI Providers)  
**Layer:** L5: Application  
**Phase:** 7  
**Estimated LOC:** ~400  

---

## Overview

The Documentation Service is XIIGen's "technical writer." It auto-generates README files, API documentation, architecture overviews with Mermaid diagrams, and deployment guides. Uses markdown templates with variable substitution, optionally enhanced by AI for clarity. It can produce a full doc set from a single flow execution.

## Key Concepts

- **DocType** — Enum: readme, api, architecture, component, deployment, changelog
- **GeneratedDoc** — A single document with type, content, and metadata
- **MermaidDiagram** — Auto-generated diagrams from flow definitions (flowchart, sequence, class, ER)
- **Template System** — Markdown templates with `{{variable}}` placeholders
- **AI Enhancement** — Optional AI pass for improving clarity and completeness

---

## Primary Implementation (.NET 9)

### Models

```csharp
// File: XIIGen.Docs/Models/DocModels.cs
namespace XIIGen.Docs.Models;

public enum DocType { Readme, Api, Architecture, Component, Deployment, Changelog }
public enum DiagramType { Flowchart, Sequence, Class, Er }

public record GeneratedDoc(
    string DocId, DocType Type, string Title, string Content,
    string? MermaidDiagram = null, DateTime CreatedAt = default
) { public DateTime CreatedAt { get; init; } = CreatedAt == default ? DateTime.UtcNow : CreatedAt; }

public record MermaidDiagram(DiagramType Type, string Title, string Source);

public record DocGenerationRequest(
    string ProjectName, DocType Type,
    Dictionary<string, string> Variables,
    List<string>? CodeUnits = null,
    object? FlowDefinition = null,
    bool AiEnhance = false
);
```

### Service Interface

```csharp
// File: XIIGen.Docs/IDocumentationService.cs
namespace XIIGen.Docs;

public interface IDocumentationService
{
    Task<GeneratedDoc> GenerateAsync(DocGenerationRequest request, CancellationToken ct = default);
    Task<GeneratedDoc> GenerateReadmeAsync(string projectName, List<string> codeUnits, CancellationToken ct = default);
    Task<GeneratedDoc> GenerateArchitectureDocAsync(string projectName, object flowDef, CancellationToken ct = default);
    MermaidDiagram GenerateDiagram(DiagramType type, string title, object flowDefinition);
    Task<List<GeneratedDoc>> GenerateFullDocSetAsync(string projectName,
        List<string> codeUnits, object flowDef, CancellationToken ct = default);
}
```

### Service Implementation

```csharp
// File: XIIGen.Docs/DocumentationService.cs
using Microsoft.Extensions.Logging;
using XIIGen.Core.Base;
using XIIGen.Core.Interfaces;
using System.Text.Json;

namespace XIIGen.Docs;

public class DocumentationService : MicroserviceBase, IDocumentationService
{
    private readonly IAiProvider? _aiProvider;
    private readonly Dictionary<DocType, string> _templates = new();

    public DocumentationService(IDatabaseService db, IQueueService queue,
        ILogger<DocumentationService> logger, IAiProvider? aiProvider = null)
        : base(db, queue, logger) { ServiceName = "documentation-service"; _aiProvider = aiProvider; InitTemplates(); }

    private void InitTemplates()
    {
        _templates[DocType.Readme] = "# {{ProjectName}}\n\n## Overview\n\n{{Description}}\n\n## Getting Started\n\n```bash\n{{InstallCommand}}\n{{RunCommand}}\n```\n\n## Project Structure\n\n{{Structure}}\n\n## API Endpoints\n\n{{Endpoints}}";
        _templates[DocType.Api] = "# {{ProjectName}} API Reference\n\n## Base URL\n\n`{{BaseUrl}}`\n\n## Endpoints\n\n{{Endpoints}}\n\n## Models\n\n{{Models}}";
        _templates[DocType.Architecture] = "# {{ProjectName}} Architecture\n\n## System Overview\n\n{{Overview}}\n\n## Diagram\n\n```mermaid\n{{Diagram}}\n```\n\n## Components\n\n{{Components}}";
        _templates[DocType.Deployment] = "# {{ProjectName}} Deployment Guide\n\n## Prerequisites\n\n{{Prerequisites}}\n\n## Docker\n\n```bash\ndocker build -t {{projectName}} .\ndocker run -p 8080:8080 {{projectName}}\n```\n\n## Kubernetes\n\n```bash\nkubectl apply -f k8s/\n```";
        _templates[DocType.Changelog] = "# {{ProjectName}} Changelog\n\n## [{{Version}}] - {{Date}}\n\n### Added\n\n{{Changes}}";
    }

    public async Task<GeneratedDoc> GenerateAsync(DocGenerationRequest request, CancellationToken ct = default)
    {
        var template = _templates.TryGetValue(request.Type, out var t) ? t : "# {{ProjectName}}\n\n{{Content}}";
        var content = SubstituteVars(template, request.Variables);

        if (request.AiEnhance && _aiProvider != null)
        {
            var enhanced = await _aiProvider.ExecuteAsync(new AiRequest
            {
                SystemPrompt = "You are a technical writer. Improve this documentation for clarity. Return markdown only.",
                UserPrompt = content
            }, ct);
            content = enhanced.Content ?? content;
        }

        string? diagram = null;
        if (request.Type == DocType.Architecture && request.FlowDefinition != null)
        {
            var mermaid = GenerateDiagram(DiagramType.Flowchart, request.ProjectName, request.FlowDefinition);
            diagram = mermaid.Source;
            content = content.Replace("{{Diagram}}", diagram);
        }

        var doc = new GeneratedDoc(Guid.NewGuid().ToString(), request.Type, $"{request.ProjectName} - {request.Type}", content, diagram);
        await StoreDocumentAsync("xiigen-docs", doc.DocId, doc, ct: ct);
        return doc;
    }

    public async Task<GeneratedDoc> GenerateReadmeAsync(string projectName, List<string> codeUnits, CancellationToken ct = default)
    {
        var structure = string.Join("\n", codeUnits.Select(u => $"- {u}"));
        return await GenerateAsync(new DocGenerationRequest(projectName, DocType.Readme,
            new() { ["ProjectName"] = projectName, ["Description"] = $"Generated project: {projectName}",
                    ["InstallCommand"] = "npm install", ["RunCommand"] = "npm start",
                    ["Structure"] = structure, ["Endpoints"] = "See API docs" }), ct);
    }

    public async Task<GeneratedDoc> GenerateArchitectureDocAsync(string projectName, object flowDef, CancellationToken ct = default)
    {
        var diagram = GenerateDiagram(DiagramType.Flowchart, projectName, flowDef);
        return await GenerateAsync(new DocGenerationRequest(projectName, DocType.Architecture,
            new() { ["ProjectName"] = projectName, ["Overview"] = $"Architecture for {projectName}",
                    ["Diagram"] = diagram.Source, ["Components"] = "See component docs" },
            FlowDefinition: flowDef), ct);
    }

    public MermaidDiagram GenerateDiagram(DiagramType type, string title, object flowDefinition)
    {
        var source = type switch
        {
            DiagramType.Flowchart => GenerateFlowchart(title, flowDefinition),
            DiagramType.Sequence => $"sequenceDiagram\n    participant C as Client\n    participant S as Server\n    C->>S: Request\n    S-->>C: Response",
            DiagramType.Class => $"classDiagram\n    class {title} {{\n        +execute()\n        +validate()\n    }}",
            DiagramType.Er => $"erDiagram\n    {title} ||--o{{ COMPONENT : contains",
            _ => $"flowchart TD\n    A[{title}]"
        };
        return new MermaidDiagram(type, title, source);
    }

    public async Task<List<GeneratedDoc>> GenerateFullDocSetAsync(string projectName,
        List<string> codeUnits, object flowDef, CancellationToken ct = default)
    {
        var docs = new List<GeneratedDoc>
        {
            await GenerateReadmeAsync(projectName, codeUnits, ct),
            await GenerateArchitectureDocAsync(projectName, flowDef, ct),
            await GenerateAsync(new DocGenerationRequest(projectName, DocType.Api,
                new() { ["ProjectName"] = projectName, ["BaseUrl"] = "/api", ["Endpoints"] = "Auto-generated", ["Models"] = "See source" }), ct),
            await GenerateAsync(new DocGenerationRequest(projectName, DocType.Deployment,
                new() { ["ProjectName"] = projectName, ["projectName"] = projectName.ToLower(), ["Prerequisites"] = "Docker, kubectl" }), ct)
        };
        return docs;
    }

    private static string GenerateFlowchart(string title, object flowDef)
    {
        try
        {
            var json = JsonSerializer.Serialize(flowDef);
            var doc = JsonDocument.Parse(json);
            var sb = new System.Text.StringBuilder($"flowchart TD\n    START[{title}]\n");
            if (doc.RootElement.TryGetProperty("steps", out var steps))
            {
                string? prev = "START";
                foreach (var step in steps.EnumerateArray())
                {
                    var id = step.GetProperty("id").GetString() ?? "step";
                    var name = step.TryGetProperty("name", out var n) ? n.GetString() : id;
                    sb.AppendLine($"    {id}[{name}]");
                    if (prev != null) sb.AppendLine($"    {prev} --> {id}");
                    prev = id;
                }
            }
            return sb.ToString();
        }
        catch { return $"flowchart TD\n    A[{title}] --> B[Processing] --> C[Output]"; }
    }

    private static string SubstituteVars(string text, Dictionary<string, string> vars)
    { foreach (var (k, v) in vars) text = text.Replace($"{{{{{k}}}}}", v); return text; }
}
```

### DI & API

```csharp
services.AddSingleton<IDocumentationService, DocumentationService>();

app.MapPost("/api/docs/generate", async (IDocumentationService svc, DocGenerationRequest req, CancellationToken ct) =>
    Results.Ok(await svc.GenerateAsync(req, ct)));
app.MapPost("/api/docs/full-set", async (IDocumentationService svc, FullDocSetRequest req, CancellationToken ct) =>
    Results.Ok(await svc.GenerateFullDocSetAsync(req.ProjectName, req.CodeUnits, req.FlowDef, ct)));
```

### Elasticsearch Index: `xiigen-docs`

---

## Tests

```csharp
[Fact] public async Task GenerateReadme_IncludesProjectName()
{
    var doc = await _svc.GenerateReadmeAsync("MyApp", ["src/index.ts", "src/models/User.ts"]);
    Assert.Contains("MyApp", doc.Content);
    Assert.Equal(DocType.Readme, doc.Type);
}

[Fact] public void GenerateDiagram_ReturnsValidMermaid()
{
    var flow = new { steps = new[] { new { id = "s1", name = "Parse" }, new { id = "s2", name = "Generate" } } };
    var diagram = _svc.GenerateDiagram(DiagramType.Flowchart, "Pipeline", flow);
    Assert.Contains("flowchart TD", diagram.Source);
    Assert.Contains("s1[Parse]", diagram.Source);
}

[Fact] public async Task GenerateFullDocSet_Returns4Docs()
{
    var docs = await _svc.GenerateFullDocSetAsync("App", ["file.ts"], new { steps = Array.Empty<object>() });
    Assert.Equal(4, docs.Count);
}
```

---

## Alternatives

| Stack | File | Key Libraries |
|-------|------|--------------|
| Node.js/TypeScript | `alternatives/nodejs/documentation-service.ts` | marked, Mermaid.js |
| Python 3.12 | `alternatives/python/documentation_service.py` | Jinja2, mdformat, dataclasses |
| Java 21 | `alternatives/java/DocumentationService.java` | FreeMarker, flexmark, records |
| Rust | `alternatives/rust/documentation_service.rs` | pulldown-cmark, tera |
| PHP 8.3 | `alternatives/php/DocumentationService.php` | Blade, league/commonmark, enums |

## Implementation Prompt → `prompts/implement.md`
