# Skill: RAG Context Planning & Multi-Backend RAG Services

## Overview

This skill provides AI-driven RAG (Retrieval-Augmented Generation) capabilities for the XIIGen platform. 
The key innovation: **before each AI call, an AI planner decides what context to retrieve** from your knowledge base. 
**After each execution and feedback, an AI planner decides what knowledge to store** for future use.

**Status:** Production Ready  
**Dependencies:** Skill 01 (Core Interfaces), Skill 06 (AI Providers)

---

## Architecture

```
AI Step About to Execute
         │
         ▼
┌─────────────────────┐
│ RAG Context Planner  │◄── Uses planning AI (Claude/GPT)
│ PlanRetrievalAsync() │
└────────┬────────────┘
         │ Returns: RagRetrievalPlan (vector searches, graph traversals, etc.)
         ▼
┌─────────────────────┐
│ ExecuteRetrievalPlan │──► Queries multiple RAG backends in parallel
└────────┬────────────┘
         │ Returns: RagContext (formatted XML for prompt injection)
         ▼
┌─────────────────────┐
│ AI Step Executes     │◄── Context injected into system prompt
│ (Transform/Review)   │
└────────┬────────────┘
         │ Step completes + user gives feedback
         ▼
┌─────────────────────┐
│ RAG Context Planner  │◄── Uses planning AI
│ PlanStorageAsync()   │
└────────┬────────────┘
         │ Returns: RagStoragePlan (embeddings, graph nodes/edges, metadata)
         ▼
┌─────────────────────┐
│ ExecuteStoragePlan   │──► Stores knowledge across RAG backends
└─────────────────────┘
```

## Supported RAG Backends

| Backend | Vector | Hybrid | Graph | Best For |
|---------|--------|--------|-------|----------|
| Azure AI Search | ✅ | ✅ (RRF + Semantic) | ❌ | Enterprise, hybrid search, semantic ranking |
| Neo4j | ✅ (5.11+) | ✅ | ✅ Full Cypher | Component relationships, architecture knowledge |
| Pinecone | ✅ | ✅ (sparse+dense) | ❌ | Pure vector search, massive scale |
| CosmosDB Graph | ✅ (DiskANN) | ❌ | ✅ Gremlin | Global distribution, multi-model |
| Elasticsearch kNN | ✅ | ✅ (RRF) | ❌ | Integrated with existing ES data store |

## Configuration

```json
{
  "Rag": {
    "Backends": [
      { "Type": "neo4j", "Uri": "bolt://localhost:7687", "User": "neo4j", "Password": "secret" },
      { "Type": "azure-ai-search", "Endpoint": "https://myservice.search.windows.net", "ApiKey": "..." },
      { "Type": "pinecone", "Host": "https://index-xxx.svc.pinecone.io", "ApiKey": "..." }
    ],
    "Embeddings": { "Provider": "openai", "Model": "text-embedding-3-small" }
  }
}
```

## DI Registration

```csharp
builder.Services.AddXIIGenRag(builder.Configuration);    // RAG backends + planner
builder.Services.AddXIIGenQueue(builder.Configuration);   // Queue (Redis/Kafka/SQS/...)
builder.Services.AddXIIGenDatabase(builder.Configuration); // Database (ES/Mongo/...)
```

## Integration with Flow Orchestrator

In the Flow Orchestrator, wrap each AI step with RAG planning:

```csharp
// Before AI step
var retrievalPlan = await _ragPlanner.PlanRetrievalAsync(new RagPlanningInput
{
    TraceId = traceId, StepId = stepId, StepType = "ai-transform",
    StepInput = figmaNodes, AvailableCollections = ["components", "feedback", "patterns"]
});
var context = await _ragPlanner.ExecuteRetrievalPlanAsync(retrievalPlan);

// Inject context into AI prompt
aiRequest.SystemPrompt += context.FormattedForPrompt;

// Execute AI step...
var result = await aiProvider.ExecuteAsync(aiRequest);

// After AI step + feedback
await _ragPlanner.PlanStorageAsync(new RagStoragePlanningInput
{
    TraceId = traceId, StepId = stepId, StepOutput = result,
    FeedbackRating = "Good", FeedbackText = "Clean flexbox layout"
});
```
