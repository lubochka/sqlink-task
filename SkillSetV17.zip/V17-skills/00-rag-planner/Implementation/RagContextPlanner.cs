// XIIGen.Services.RagPlanner/RagContextPlanner.cs | .NET 9
// Skill: RAG Context Planner
// Uses AI to plan context retrieval before each AI stage,
// and storage planning after each execution + feedback.

using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using XIIGen.Core.Base;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Services.RagPlanner;

public class RagContextPlanner : MicroserviceBase, IRagContextPlanner
{
    private readonly IAiProvider _planningAi;
    private readonly IEmbeddingService _embeddings;
    private readonly Dictionary<string, IRagService> _ragBackends;

    public RagContextPlanner(
        IDatabaseService db, IQueueService queue, ILogger<RagContextPlanner> logger,
        IAiProvider planningAi, IEmbeddingService embeddings,
        IEnumerable<IRagService> ragServices, ICacheService cache = null)
        : base(db, queue, logger, cache)
    {
        ServiceName = "rag-context-planner";
        _planningAi = planningAi;
        _embeddings = embeddings;
        _ragBackends = ragServices.ToDictionary(r => r.ProviderName, r => r);
    }

    // ═══════════════════════════════════════════════════════
    // PRE-EXECUTION: Plan what context to retrieve
    // ═══════════════════════════════════════════════════════

    public async Task<RagRetrievalPlan> PlanRetrievalAsync(
        RagPlanningInput input, CancellationToken ct = default)
    {
        await LogInfoAsync($"Planning retrieval for trace={input.TraceId} step={input.StepId}");

        // Ask AI: "Given this step and input, what context would help?"
        var planningPrompt = BuildRetrievalPlanningPrompt(input);
        var response = await _planningAi.ExecuteAsync(new AiRequest
        {
            Prompt = planningPrompt,
            SystemPrompt = RETRIEVAL_PLANNER_SYSTEM_PROMPT,
            MaxTokens = 2000,
            Temperature = 0.2f // Low temperature for structured planning
        }, ct);

        var plan = ParseRetrievalPlan(response.Content);
        plan.PlanId = $"rp-{input.TraceId}-{input.StepId}";

        // Store the plan for debugging/auditing
        await StoreDocumentAsync("rag-plans", plan.PlanId, new
        {
            plan.PlanId, input.TraceId, input.StepId, Type = "retrieval",
            plan.Steps, plan.Reasoning, CreatedAt = DateTime.UtcNow
        }, ct: ct);

        return plan;
    }

    public async Task<RagContext> ExecuteRetrievalPlanAsync(
        RagRetrievalPlan plan, CancellationToken ct = default)
    {
        await LogInfoAsync($"Executing retrieval plan {plan.PlanId} with {plan.Steps.Count} steps");

        var context = new RagContext { PlanId = plan.PlanId, Items = [] };
        var tasks = new List<Task<List<RagContextItem>>>();

        // Execute retrieval steps in parallel, grouped by priority
        foreach (var group in plan.Steps.GroupBy(s => s.Priority).OrderBy(g => g.Key))
        {
            var groupTasks = group.Select(step => ExecuteRetrievalStepAsync(step, ct));
            var results = await Task.WhenAll(groupTasks);
            foreach (var items in results)
                context.Items.AddRange(items);
        }

        // Sort by relevance, deduplicate
        context.Items = context.Items
            .GroupBy(i => i.Content?.GetHashCode() ?? 0)
            .Select(g => g.OrderByDescending(i => i.Relevance).First())
            .OrderByDescending(i => i.Relevance)
            .Take(20) // Cap context items to manage token budget
            .ToList();

        // Estimate tokens and format for prompt
        context.TotalTokensEstimate = context.Items.Sum(i => (i.Content?.Length ?? 0) / 4);
        context.FormattedForPrompt = FormatContextAsXml(context);

        await LogInfoAsync($"Retrieved {context.Items.Count} context items (~{context.TotalTokensEstimate} tokens)");
        return context;
    }

    private async Task<List<RagContextItem>> ExecuteRetrievalStepAsync(
        RagRetrievalStep step, CancellationToken ct)
    {
        var items = new List<RagContextItem>();

        try
        {
            // Find the right RAG backend for this collection
            var backend = ResolveBackend(step.Collection);
            if (backend is null)
            {
                await LogWarnAsync($"No RAG backend found for collection '{step.Collection}'");
                return items;
            }

            switch (step.Type)
            {
                case RagRetrievalType.VectorSearch:
                    var embedding = await _embeddings.GenerateEmbeddingAsync(step.Query, ct);
                    var vecResults = await backend.VectorSearchAsync(
                        step.Collection, embedding, step.TopK, step.MinScore, step.Filters, ct);
                    if (vecResults.IsSuccess)
                        items.AddRange(vecResults.Data.Select(r => new RagContextItem
                        {
                            Source = step.StepId, Collection = step.Collection,
                            Relevance = r.Score, Content = r.Content, Metadata = r.Metadata
                        }));
                    break;

                case RagRetrievalType.HybridSearch:
                    var hybridEmb = await _embeddings.GenerateEmbeddingAsync(step.Query, ct);
                    var hybResults = await backend.HybridSearchAsync(
                        step.Collection, step.Query, hybridEmb, step.TopK, step.Filters, ct);
                    if (hybResults.IsSuccess)
                        items.AddRange(hybResults.Data.Select(r => new RagContextItem
                        {
                            Source = step.StepId, Collection = step.Collection,
                            Relevance = r.Score, Content = r.Content, Metadata = r.Metadata
                        }));
                    break;

                case RagRetrievalType.GraphTraversal:
                    if (backend.Capabilities.SupportsGraphTraversal)
                    {
                        var graphResults = await backend.TraverseAsync(
                            step.StartNodeId, step.EdgeType, maxDepth: 3,
                            TraversalDirection.Both, ct);
                        if (graphResults.IsSuccess)
                            items.AddRange(graphResults.Data.Select(r => new RagContextItem
                            {
                                Source = step.StepId, Collection = step.Collection,
                                Relevance = 1.0f / (r.Depth + 1), // Closer nodes are more relevant
                                Content = JsonSerializer.Serialize(r.Properties),
                                Metadata = new Dictionary<string, object>
                                {
                                    ["nodeId"] = r.NodeId, ["label"] = r.Label, ["depth"] = r.Depth
                                }
                            }));
                    }
                    break;

                case RagRetrievalType.GraphQuery:
                    if (backend.Capabilities.SupportsGraphQuery)
                    {
                        var queryResults = await backend.GraphQueryAsync(
                            step.GraphQuery, step.Filters?.ToDictionary(k => k.Key, v => v.Value), ct);
                        if (queryResults.IsSuccess)
                            items.AddRange(queryResults.Data.Select(r => new RagContextItem
                            {
                                Source = step.StepId, Collection = step.Collection,
                                Relevance = 0.9f,
                                Content = JsonSerializer.Serialize(r.Properties),
                                Metadata = new Dictionary<string, object> { ["nodeId"] = r.NodeId, ["label"] = r.Label }
                            }));
                    }
                    break;

                case RagRetrievalType.KeywordSearch:
                    var kwResults = await backend.HybridSearchAsync(
                        step.Collection, step.Query, null, step.TopK, step.Filters, ct);
                    if (kwResults.IsSuccess)
                        items.AddRange(kwResults.Data.Select(r => new RagContextItem
                        {
                            Source = step.StepId, Collection = step.Collection,
                            Relevance = r.Score, Content = r.Content, Metadata = r.Metadata
                        }));
                    break;
            }
        }
        catch (Exception ex)
        {
            await LogErrorAsync($"Retrieval step {step.StepId} failed: {step.Type} on {step.Collection}", ex);
        }

        return items;
    }

    // ═══════════════════════════════════════════════════════
    // POST-EXECUTION: Plan what to store in RAG
    // ═══════════════════════════════════════════════════════

    public async Task<RagStoragePlan> PlanStorageAsync(
        RagStoragePlanningInput input, CancellationToken ct = default)
    {
        await LogInfoAsync($"Planning storage for trace={input.TraceId} step={input.StepId}");

        var planningPrompt = BuildStoragePlanningPrompt(input);
        var response = await _planningAi.ExecuteAsync(new AiRequest
        {
            Prompt = planningPrompt,
            SystemPrompt = STORAGE_PLANNER_SYSTEM_PROMPT,
            MaxTokens = 2000,
            Temperature = 0.2f
        }, ct);

        var plan = ParseStoragePlan(response.Content);
        plan.PlanId = $"sp-{input.TraceId}-{input.StepId}";

        await StoreDocumentAsync("rag-plans", plan.PlanId, new
        {
            plan.PlanId, input.TraceId, input.StepId, Type = "storage",
            plan.Steps, plan.Reasoning, CreatedAt = DateTime.UtcNow
        }, ct: ct);

        return plan;
    }

    public async Task<DataProcessResult<bool>> ExecuteStoragePlanAsync(
        RagStoragePlan plan, CancellationToken ct = default)
    {
        await LogInfoAsync($"Executing storage plan {plan.PlanId} with {plan.Steps.Count} steps");
        var errors = new List<string>();

        foreach (var step in plan.Steps)
        {
            try
            {
                var backend = ResolveBackend(step.Collection ?? "default");
                if (backend is null) { errors.Add($"No backend for {step.Collection}"); continue; }

                switch (step.Type)
                {
                    case RagStorageType.Embedding:
                        var embedding = await _embeddings.GenerateEmbeddingAsync(step.Content, ct);
                        await backend.StoreEmbeddingAsync(
                            step.Collection, step.DocumentId ?? Guid.NewGuid().ToString(),
                            embedding, step.Metadata, ct);
                        break;

                    case RagStorageType.GraphNode:
                        await backend.StoreNodeAsync(
                            step.NodeLabel, step.DocumentId ?? Guid.NewGuid().ToString(),
                            step.Metadata ?? [], ct);
                        break;

                    case RagStorageType.GraphEdge:
                        await backend.StoreEdgeAsync(
                            step.FromNodeId, step.ToNodeId, step.EdgeType,
                            step.Metadata, ct);
                        break;

                    case RagStorageType.DocumentChunks:
                        await backend.StoreDocumentChunksAsync(
                            step.Collection, step.DocumentId ?? Guid.NewGuid().ToString(),
                            step.Content, step.ChunkingOptions, ct);
                        break;

                    case RagStorageType.Metadata:
                        await backend.StoreEmbeddingAsync(
                            step.Collection, step.DocumentId ?? Guid.NewGuid().ToString(),
                            [], step.Metadata, ct); // Store metadata without embedding
                        break;
                }
            }
            catch (Exception ex)
            {
                errors.Add($"Storage step failed: {step.Type} - {ex.Message}");
                await LogErrorAsync($"Storage step failed for {step.Type}", ex);
            }
        }

        return errors.Count == 0
            ? DataProcessResult<bool>.Success(true)
            : DataProcessResult<bool>.Error($"{errors.Count} storage steps failed: {string.Join("; ", errors)}");
    }

    // ═══════════════════════════════════════════════════════
    // Prompt Construction
    // ═══════════════════════════════════════════════════════

    private string BuildRetrievalPlanningPrompt(RagPlanningInput input) =>
        $"""
        I need context for the following AI processing step.

        <step_info>
          <trace_id>{input.TraceId}</trace_id>
          <step_id>{input.StepId}</step_id>
          <step_type>{input.StepType}</step_type>
          <input_summary>{JsonSerializer.Serialize(input.StepInput).Truncate(2000)}</input_summary>
        </step_info>

        <available_collections>{string.Join(", ", input.AvailableCollections)}</available_collections>
        <available_graph_labels>{string.Join(", ", input.AvailableGraphLabels)}</available_graph_labels>

        <flow_context>
        {JsonSerializer.Serialize(input.FlowContext)}
        </flow_context>

        Based on the step type and input, plan which RAG queries to execute.
        Return a JSON array of retrieval steps.
        """;

    private string BuildStoragePlanningPrompt(RagStoragePlanningInput input) =>
        $"""
        An AI processing step has completed. Plan what to store in RAG.

        <step_info>
          <trace_id>{input.TraceId}</trace_id>
          <step_id>{input.StepId}</step_id>
          <step_type>{input.StepType}</step_type>
        </step_info>

        <input_summary>{JsonSerializer.Serialize(input.StepInput).Truncate(1000)}</input_summary>
        <output_summary>{JsonSerializer.Serialize(input.StepOutput).Truncate(2000)}</output_summary>

        <feedback>
          <rating>{input.FeedbackRating ?? "none"}</rating>
          <text>{input.FeedbackText ?? "none"}</text>
        </feedback>

        <retrieved_context_count>{input.RetrievedContext?.Items.Count ?? 0}</retrieved_context_count>

        Plan what knowledge to store: embeddings for vector search, graph nodes/edges for relationships, metadata.
        Return a JSON array of storage steps.
        """;

    private string FormatContextAsXml(RagContext context)
    {
        var sb = new StringBuilder();
        sb.AppendLine("<rag_context>");
        foreach (var item in context.Items)
        {
            sb.AppendLine($"  <context source=\"{item.Source}\" collection=\"{item.Collection}\" relevance=\"{item.Relevance:F2}\">");
            sb.AppendLine($"    {item.Content}");
            sb.AppendLine("  </context>");
        }
        sb.AppendLine("</rag_context>");
        return sb.ToString();
    }

    private IRagService ResolveBackend(string collection)
    {
        // Collection naming convention: "backend:collection" or just "collection" (uses default)
        if (collection.Contains(':'))
        {
            var parts = collection.Split(':', 2);
            return _ragBackends.GetValueOrDefault(parts[0]);
        }
        return _ragBackends.Values.FirstOrDefault();
    }

    private RagRetrievalPlan ParseRetrievalPlan(string aiResponse)
    {
        try
        {
            var jsonStart = aiResponse.IndexOf('[');
            var jsonEnd = aiResponse.LastIndexOf(']');
            if (jsonStart >= 0 && jsonEnd > jsonStart)
            {
                var json = aiResponse[jsonStart..(jsonEnd + 1)];
                var steps = JsonSerializer.Deserialize<List<RagRetrievalStep>>(json,
                    new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                return new RagRetrievalPlan { Steps = steps ?? [], Reasoning = aiResponse };
            }
        }
        catch { /* Fall through to default */ }

        return new RagRetrievalPlan
        {
            Reasoning = "Could not parse AI plan, using default retrieval",
            Steps = [new RagRetrievalStep
            {
                Type = RagRetrievalType.HybridSearch,
                Collection = "default",
                Query = "recent relevant context",
                TopK = 5
            }]
        };
    }

    private RagStoragePlan ParseStoragePlan(string aiResponse)
    {
        try
        {
            var jsonStart = aiResponse.IndexOf('[');
            var jsonEnd = aiResponse.LastIndexOf(']');
            if (jsonStart >= 0 && jsonEnd > jsonStart)
            {
                var json = aiResponse[jsonStart..(jsonEnd + 1)];
                var steps = JsonSerializer.Deserialize<List<RagStorageStep>>(json,
                    new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                return new RagStoragePlan { Steps = steps ?? [], Reasoning = aiResponse };
            }
        }
        catch { /* Fall through */ }

        return new RagStoragePlan { Reasoning = "Could not parse AI plan", Steps = [] };
    }

    // ═══════════════════════════════════════════════════════
    // System Prompts for Planning AI
    // ═══════════════════════════════════════════════════════

    private const string RETRIEVAL_PLANNER_SYSTEM_PROMPT = """
        You are a RAG retrieval planner for an AI pipeline orchestrator.
        Your job: given a processing step about to execute, decide which RAG queries will provide the best context.

        Return ONLY a JSON array of retrieval steps. Each step:
        {
          "type": "VectorSearch" | "HybridSearch" | "GraphTraversal" | "GraphQuery" | "KeywordSearch",
          "collection": "collection-name",
          "query": "search query text",
          "graphQuery": "MATCH (n)-[r]->(m) WHERE ... RETURN n,r,m",  // only for GraphQuery type
          "startNodeId": "node-id",  // only for GraphTraversal type
          "edgeType": "RELATES_TO",  // only for GraphTraversal type
          "topK": 5,
          "minScore": 0.7,
          "filters": {},
          "priority": 1
        }

        Guidelines:
        - Use VectorSearch for semantic similarity (e.g., find similar past results)
        - Use HybridSearch for combined keyword + semantic (e.g., find code by description)
        - Use GraphTraversal to find related entities (e.g., components used together)
        - Use GraphQuery for complex relationship patterns
        - Use KeywordSearch for exact matches (e.g., error codes, specific IDs)
        - Keep total retrievals under 5 to manage latency
        - Higher priority = more important = executed first
        """;

    private const string STORAGE_PLANNER_SYSTEM_PROMPT = """
        You are a RAG storage planner for an AI pipeline orchestrator.
        Your job: after a processing step completes, decide what knowledge to store and where.

        Return ONLY a JSON array of storage steps. Each step:
        {
          "type": "Embedding" | "GraphNode" | "GraphEdge" | "DocumentChunks" | "Metadata",
          "collection": "collection-name",
          "documentId": "unique-id",
          "content": "text to embed or store",
          "metadata": { "key": "value" },
          "nodeLabel": "Component",        // for GraphNode
          "fromNodeId": "node-1",          // for GraphEdge
          "toNodeId": "node-2",            // for GraphEdge
          "edgeType": "USES",              // for GraphEdge
          "chunkingOptions": { "chunkSize": 512, "strategy": "sentence" }  // for DocumentChunks
        }

        Guidelines:
        - Store embeddings of successful outputs for future similarity search
        - Create graph nodes for components, screens, patterns discovered
        - Create graph edges for relationships between components
        - Store document chunks for long outputs (code, documentation)
        - Add rich metadata (step type, feedback rating, quality score, tags)
        - If feedback is negative, store it prominently so future retrievals surface it
        - If feedback is positive, boost the stored knowledge weight via metadata
        """;

    protected override async Task ProcessAsync(CancellationToken ct)
    {
        // Listen for planning requests on the queue
        await foreach (var msg in ConsumeAsync<RagPlanRequest>("xiigen.rag.plan-requests", "rag-planner", ct))
        {
            try
            {
                if (msg.Data.RequestType == "retrieval")
                {
                    var plan = await PlanRetrievalAsync(msg.Data.RetrievalInput, ct);
                    var context = await ExecuteRetrievalPlanAsync(plan, ct);
                    await EnqueueAsync($"xiigen.rag.plan-results.{msg.Data.ReplyTo}", context, ct: ct);
                }
                else if (msg.Data.RequestType == "storage")
                {
                    var plan = await PlanStorageAsync(msg.Data.StorageInput, ct);
                    await ExecuteStoragePlanAsync(plan, ct);
                }

                await Queue.AcknowledgeAsync("xiigen.rag.plan-requests", "rag-planner", msg.MessageId, ct);
            }
            catch (Exception ex)
            {
                await LogErrorAsync($"RAG plan request failed", ex);
            }
        }
    }
}

// Helper request envelope
public class RagPlanRequest
{
    public string RequestType { get; set; } // "retrieval" or "storage"
    public RagPlanningInput RetrievalInput { get; set; }
    public RagStoragePlanningInput StorageInput { get; set; }
    public string ReplyTo { get; set; } // Queue to send results back to
}

// Extension method for string truncation
public static class StringExtensions
{
    public static string Truncate(this string s, int maxLength) =>
        s.Length <= maxLength ? s : s[..maxLength] + "...";
}
