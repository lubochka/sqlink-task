# WhatsApp Diet Flow — Implementation Prompt | Skill 41
## Phase 1: User Registration
1. Register with phone, name, goals, calorie targets
2. Store as dynamic doc via ParseObjectAlternative; DataProcessResult returns

## Phase 2: Message Processing + Meal Logging
1. Route: /summary, /plan, or free-text (meal logging)
2. AI-powered food parsing (text→structured FoodItem array)
3. Low confidence items trigger clarification questions

## Phase 3: Daily Summary + Diet Plan
1. Aggregate daily meals, compare vs targets
2. AI-generated 7-day personalized diet plans
3. Store all data as dynamic docs; BuildSearchFilter for queries

## Phase 4: WhatsApp Integration & Testing
1. Webhook handler for incoming WhatsApp messages
2. Integration with Skill 24 Notification for outbound messages
3. **Genie DNA Checklist:** ☐ DataProcessResult ☐ BuildSearchFilter ☐ ParseObjectAlternative ☐ IAiProvider
