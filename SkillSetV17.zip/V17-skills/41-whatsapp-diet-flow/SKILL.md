---
skill_id: "41"
name: whatsapp-diet-flow
title: "WhatsApp Diet Flow"
layer: "L8: Specialty"
version: "17.0"
status: "active"
dependencies:
  - "01-core-interfaces"
  - "02-object-processor"
  - "03-elasticsearch-datastore"
  - "06-ai-providers"
  - "24-notification-service"
dotnet_namespace: "XIIGen.Services.WhatsAppDiet"
di_registration: "services.AddXIIGenWhatsAppDiet()"
es_index: "xiigen-diet"
genie_dna:
  - "DNA-1: Diet records (meals, foods, plans) as dynamic documents — users add custom fields"
  - "DNA-2: BuildSearchFilter for meal search (userId, date, mealType — skip empty)"
  - "DNA-3: Inherits MicroserviceBase"
  - "DNA-5: DataProcessResult for all operations"
  - "DNA-6: IAiProvider for food parsing (swap Claude/GPT for food recognition)"
  - "DNA-SCOPE: User diet data auto-scoped — users only see their own meals"
  - "DNA-FREEDOM: Food categories and meal types are dynamic — admins add without code"
triggers: WhatsApp, diet tracking, food logging, meal tracker, nutrition, calorie, diet plan, food AI
---

# Skill 41: WhatsApp Diet Flow
## AI-Powered Diet Tracking via WhatsApp Messages

**Classification: HYBRID — MACHINE message processing, FREEDOM diet definitions**

---

## Genie DNA Integration

### Meal Records as Dynamic Documents (DNA-1)
Users can track ANY nutrition data — not limited to predefined fields:
```json
{
  "userId": "user_123",
  "mealType": "lunch",
  "timestamp": "2026-02-08T12:30:00Z",
  "foods": [
    { "name": "Hummus", "calories": 180, "protein": 8, "fiber": 4 },
    { "name": "Pita bread", "calories": 165, "carbs": 33 }
  ],
  "totalCalories": 345,
  "notes": "ate at office cafeteria",
  "mood": "good",
  "customTag": "Mediterranean"
}
```
`mood`, `customTag`, any field the user mentions — stored dynamically. No schema changes.

### Automatic Scope Isolation (DNA-SCOPE)
Diet data is deeply personal. BuildSearchFilter ALWAYS injects userId:
```csharp
// User A can NEVER see User B's diet data
var conditions = ObjectProcessor.BuildSearchFilter(filter, userScope);
// userScope.UserId auto-injected into every query
```

### AI Food Parsing (DNA-6)
User sends: "ate hummus with pita and a small salad"
AI (via IAiProvider) parses into structured FoodItem array — stored as dynamic document.
Swap AI provider without changing parsing logic.

## Interface
```csharp
public interface IWhatsAppDietService
{
    Task<DataProcessResult<string>> ProcessMessageAsync(string userId, string message);
    Task<DataProcessResult<Dictionary<string, object>>> GetDailySummaryAsync(
        string userId, DateTime date);
    Task<DataProcessResult<Dictionary<string, object>>> GeneratePlanAsync(
        string userId, Dictionary<string, object> preferences);
}
```

## Commands
| Command | Action |
|---|---|
| Free text | AI parses food items, logs meal |
| `/summary` | Daily calorie/nutrition totals |
| `/plan` | AI-generated 7-day meal plan |

## Alternatives
All alternatives MUST: store meals as dynamic documents, use IAiProvider for food parsing, enforce scope isolation on all queries, return DataProcessResult.
