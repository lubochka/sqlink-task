// XIIGen.Pipeline.WhatsAppDiet/WhatsAppDietExecutor.cs - Skill 41 | .NET 9
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using XIIGen.Core.Base;
using XIIGen.Core.Enums;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Pipeline.WhatsAppDiet;

// ─── Models ─────────────────────────────────────────
public class DietUser
{
    public string UserId { get; set; } = Guid.NewGuid().ToString();
    public string Phone { get; set; } = "";
    public string Name { get; set; } = "";
    public double TargetCalories { get; set; } = 2000;
    public double TargetProteinG { get; set; } = 120;
    public double TargetCarbsG { get; set; } = 250;
    public double TargetFatG { get; set; } = 65;
    public string Goal { get; set; } = "maintain";   // lose, gain, maintain
    public string? DietPlan { get; set; }
    public DateTime RegisteredAt { get; set; } = DateTime.UtcNow;
}

public class FoodItem
{
    public string Name { get; set; } = "";
    public double Quantity { get; set; } = 1;
    public string Unit { get; set; } = "serving";
    public double Calories { get; set; }
    public double ProteinG { get; set; }
    public double CarbsG { get; set; }
    public double FatG { get; set; }
    public double Confidence { get; set; } = 1.0;   // 0-1, low = needs clarification
}

public class DietMeal
{
    public string MealId { get; set; } = Guid.NewGuid().ToString();
    public string UserId { get; set; } = "";
    public string RawInput { get; set; } = "";
    public List<FoodItem> Items { get; set; } = [];
    public double TotalCalories => Items.Sum(i => i.Calories);
    public string MealType { get; set; } = "snack";  // breakfast, lunch, dinner, snack
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
    public bool NeedsClarification { get; set; }
    public string? ClarificationQuestion { get; set; }
}

public class DietDailySummary
{
    public string UserId { get; set; } = "";
    public string Date { get; set; } = DateTime.UtcNow.ToString("yyyy-MM-dd");
    public double TotalCalories { get; set; }
    public double TotalProteinG { get; set; }
    public double TotalCarbsG { get; set; }
    public double TotalFatG { get; set; }
    public int MealCount { get; set; }
    public string? AiFeedback { get; set; }
    public DateTime GeneratedAt { get; set; } = DateTime.UtcNow;
}

// ─── Executor ───────────────────────────────────────
public class WhatsAppDietExecutor : IStepExecutor
{
    private readonly IEnumerable<IAiProvider> _aiProviders;
    private readonly IDatabaseService _db;
    private readonly ILogger<WhatsAppDietExecutor> _logger;

    public NodeType StepType => NodeType.WhatsAppDiet;

    public WhatsAppDietExecutor(IEnumerable<IAiProvider> aiProviders, IDatabaseService db, ILogger<WhatsAppDietExecutor> logger)
    { _aiProviders = aiProviders; _db = db; _logger = logger; }

    public async Task<DataProcessResult<Dictionary<string, object>>> ExecuteAsync(
        FlowStep step, Dictionary<string, object> inputs, CancellationToken ct = default)
    {
        try
        {
            var action = step.Config.GetValueOrDefault("action")?.ToString() ?? "parse-meal";
            return action switch
            {
                "register"        => await RegisterUserAsync(inputs, ct),
                "generate-plan"   => await GenerateDietPlanAsync(inputs, ct),
                "parse-meal"      => await ParseMealAsync(inputs, ct),
                "clarify"         => await ClarifyMealAsync(inputs, ct),
                "daily-summary"   => await GenerateDailySummaryAsync(inputs, ct),
                "weekly-summary"  => await GenerateWeeklySummaryAsync(inputs, ct),
                _ => DataProcessResult<Dictionary<string, object>>.Error($"Unknown action: {action}")
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "WhatsApp diet failed at step {StepId}", step.Id);
            return DataProcessResult<Dictionary<string, object>>.Error(ex.Message);
        }
    }

    private async Task<DataProcessResult<Dictionary<string, object>>> RegisterUserAsync(
        Dictionary<string, object> inputs, CancellationToken ct)
    {
        var user = new DietUser
        {
            Phone = inputs.GetValueOrDefault("phone")?.ToString() ?? "",
            Name = inputs.GetValueOrDefault("name")?.ToString() ?? "",
            Goal = inputs.GetValueOrDefault("goal")?.ToString() ?? "maintain",
            TargetCalories = Convert.ToDouble(inputs.GetValueOrDefault("targetCalories", 2000))
        };
        await _db.StoreDocumentAsync("diet-users", "du", user.UserId, user, ct);
        _logger.LogInformation("Diet user registered: {UserId} ({Phone})", user.UserId, user.Phone);
        return DataProcessResult<Dictionary<string, object>>.Success(new() { ["userId"] = user.UserId, ["status"] = "registered" });
    }

    private async Task<DataProcessResult<Dictionary<string, object>>> GenerateDietPlanAsync(
        Dictionary<string, object> inputs, CancellationToken ct)
    {
        var userId = inputs.GetValueOrDefault("userId")?.ToString() ?? "";
        var userResult = await _db.GetDocumentAsync("diet-users", "du", userId, ct);
        if (!userResult.IsSuccess) return DataProcessResult<Dictionary<string, object>>.Error("User not found");

        var provider = GetProvider("claude");
        var req = new AiRequest
        {
            SystemPrompt = "You are a certified nutritionist. Create a personalized diet plan. Return JSON: {\"dailyPlan\": {\"breakfast\": \"...\", \"lunch\": \"...\", \"dinner\": \"...\", \"snacks\": \"...\"}, \"tips\": [...], \"warnings\": [...]}",
            Prompt = $"Goal: {inputs.GetValueOrDefault("goal", "maintain")}, Target calories: {inputs.GetValueOrDefault("targetCalories", 2000)}, Restrictions: {inputs.GetValueOrDefault("restrictions", "none")}",
            MaxTokens = 3000, OutputFormat = "json"
        };
        var r = await provider.ExecuteAsync(req, ct);
        if (!r.IsSuccess) return DataProcessResult<Dictionary<string, object>>.Error(r.Message);
        return DataProcessResult<Dictionary<string, object>>.Success(new() { ["dietPlan"] = r.Data!.Content, ["userId"] = userId });
    }

    private async Task<DataProcessResult<Dictionary<string, object>>> ParseMealAsync(
        Dictionary<string, object> inputs, CancellationToken ct)
    {
        var rawInput = inputs.GetValueOrDefault("message")?.ToString() ?? "";
        var userId = inputs.GetValueOrDefault("userId")?.ToString() ?? "";

        var provider = GetProvider("claude");
        var req = new AiRequest
        {
            SystemPrompt = @"Parse this food list into items with calories/macros. Be accurate with portion sizes.
Return JSON: {""items"": [{""name"": ""..."", ""quantity"": 1, ""unit"": ""serving"", ""calories"": 0, ""proteinG"": 0, ""carbsG"": 0, ""fatG"": 0, ""confidence"": 0.9}], ""needsClarification"": false, ""clarificationQuestion"": null}
Set confidence < 0.7 and needsClarification=true if any item is ambiguous.",
            Prompt = rawInput,
            MaxTokens = 2000, OutputFormat = "json"
        };
        var r = await provider.ExecuteAsync(req, ct);
        if (!r.IsSuccess) return DataProcessResult<Dictionary<string, object>>.Error(r.Message);

        var meal = new DietMeal
        {
            UserId = userId,
            RawInput = rawInput,
            MealType = GuessMealType(DateTime.UtcNow)
        };
        // Store raw AI response — actual JSON parsing in production
        await _db.StoreDocumentAsync("diet-meals", "dm", meal.MealId, new { meal, aiResponse = r.Data!.Content }, ct);

        _logger.LogInformation("Parsed meal for {UserId}: {MealId}", userId, meal.MealId);
        return DataProcessResult<Dictionary<string, object>>.Success(
            new() { ["mealId"] = meal.MealId, ["parsed"] = r.Data!.Content, ["userId"] = userId });
    }

    private async Task<DataProcessResult<Dictionary<string, object>>> ClarifyMealAsync(
        Dictionary<string, object> inputs, CancellationToken ct)
    {
        var mealId = inputs.GetValueOrDefault("mealId")?.ToString() ?? "";
        var clarification = inputs.GetValueOrDefault("clarification")?.ToString() ?? "";

        var provider = GetProvider("claude");
        var req = new AiRequest
        {
            SystemPrompt = "The user is clarifying a food item. Update the calorie/macro estimate. Return same JSON format as before.",
            Prompt = $"Original meal ID: {mealId}. Clarification: {clarification}",
            MaxTokens = 1000, OutputFormat = "json"
        };
        var r = await provider.ExecuteAsync(req, ct);
        return r.IsSuccess
            ? DataProcessResult<Dictionary<string, object>>.Success(new() { ["mealId"] = mealId, ["updated"] = r.Data!.Content })
            : DataProcessResult<Dictionary<string, object>>.Error(r.Message);
    }

    private async Task<DataProcessResult<Dictionary<string, object>>> GenerateDailySummaryAsync(
        Dictionary<string, object> inputs, CancellationToken ct)
    {
        var userId = inputs.GetValueOrDefault("userId")?.ToString() ?? "";
        var date = inputs.GetValueOrDefault("date")?.ToString() ?? DateTime.UtcNow.ToString("yyyy-MM-dd");

        // Fetch all meals for user+date
        var meals = await _db.SearchDocumentsAsync("diet-meals", "dm", new { userId, date }, 50, 0, ct);

        var provider = GetProvider("claude");
        var req = new AiRequest
        {
            SystemPrompt = @"Summarize today's nutrition and give encouraging feedback.
Return JSON: {""totalCalories"": 0, ""totalProteinG"": 0, ""totalCarbsG"": 0, ""totalFatG"": 0, ""mealCount"": 0, ""feedback"": ""..."", ""emoji"": ""..."", ""tip"": ""...""}",
            Prompt = $"User meals for {date}: {System.Text.Json.JsonSerializer.Serialize(meals.Data)}. Target: {inputs.GetValueOrDefault("targetCalories", 2000)} cal.",
            MaxTokens = 1500, OutputFormat = "json"
        };
        var r = await provider.ExecuteAsync(req, ct);
        if (!r.IsSuccess) return DataProcessResult<Dictionary<string, object>>.Error(r.Message);

        var summary = new DietDailySummary { UserId = userId, Date = date, AiFeedback = r.Data!.Content };
        await _db.StoreDocumentAsync("diet-daily-summary", "ds", $"{userId}-{date}", summary, ct);

        return DataProcessResult<Dictionary<string, object>>.Success(
            new() { ["summary"] = r.Data!.Content, ["userId"] = userId, ["date"] = date });
    }

    private async Task<DataProcessResult<Dictionary<string, object>>> GenerateWeeklySummaryAsync(
        Dictionary<string, object> inputs, CancellationToken ct)
    {
        var userId = inputs.GetValueOrDefault("userId")?.ToString() ?? "";
        var summaries = await _db.SearchDocumentsAsync("diet-daily-summary", "ds", new { userId }, 7, 0, ct);

        var provider = GetProvider("claude");
        var req = new AiRequest
        {
            SystemPrompt = @"Create a weekly diet summary with trends and recommendations.
Return JSON: {""avgCalories"": 0, ""trend"": ""improving|stable|declining"", ""highlights"": [...], ""recommendations"": [...], ""motivationalMessage"": ""...""}",
            Prompt = $"Weekly data: {System.Text.Json.JsonSerializer.Serialize(summaries.Data)}",
            MaxTokens = 2000, OutputFormat = "json"
        };
        var r = await provider.ExecuteAsync(req, ct);
        return r.IsSuccess
            ? DataProcessResult<Dictionary<string, object>>.Success(new() { ["weeklySummary"] = r.Data!.Content, ["userId"] = userId })
            : DataProcessResult<Dictionary<string, object>>.Error(r.Message);
    }

    private static string GuessMealType(DateTime now) => now.Hour switch
    {
        >= 5 and < 11 => "breakfast",
        >= 11 and < 15 => "lunch",
        >= 15 and < 18 => "snack",
        >= 18 and < 22 => "dinner",
        _ => "snack"
    };

    private IAiProvider GetProvider(string preferred) =>
        _aiProviders.FirstOrDefault(p => p.ProviderName == preferred) ?? _aiProviders.First();
}

// ─── DI Extension ───────────────────────────────────
public static class WhatsAppDietExtensions
{
    public static IServiceCollection AddXIIGenWhatsAppDiet(this IServiceCollection services)
    {
        services.AddSingleton<IStepExecutor, WhatsAppDietExecutor>();
        return services;
    }
}
