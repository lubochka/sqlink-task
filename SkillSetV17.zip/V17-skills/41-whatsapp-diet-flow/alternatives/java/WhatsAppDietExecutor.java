// XIIGen WhatsApp Diet Flow — Java | Skill 41
package com.xiigen.pipeline.diet;
import com.xiigen.core.*;
import java.time.*;
import java.util.*;

public class WhatsAppDietExecutor extends MicroserviceBase {
    private final IAiProvider aiProvider;
    public WhatsAppDietExecutor(IDatabaseService db, IQueueService queue, IAiProvider ai) { super(db, queue, "whatsapp-diet"); this.aiProvider = ai; }

    public DataProcessResult<Map<String, Object>> registerUser(String phone, String name, String goal, int targetCalories) throws Exception {
        var user = Map.of("userId", UUID.randomUUID().toString(), "phone", phone, "name", name, "targetCalories", targetCalories, "goal", goal != null ? goal : "maintain");
        storeDocument("diet-users", (String) user.get("userId"), user);
        return DataProcessResult.success(user);
    }

    public DataProcessResult<Map<String, Object>> processMessage(String userId, String message) throws Exception {
        var user = getDocument("diet-users", userId);
        if (user == null) return DataProcessResult.failure("User not registered");
        if (message.toLowerCase().startsWith("/summary")) return getDailySummary(userId);
        if (message.toLowerCase().startsWith("/plan")) return generateDietPlan(userId);
        return logMeal(userId, message);
    }

    public DataProcessResult<Map<String, Object>> logMeal(String userId, String rawInput) throws Exception {
        String prompt = "Parse this food: \"" + rawInput + "\". Return JSON array of {name, calories, proteinG, carbsG, fatG}";
        String aiResult = aiProvider.complete(prompt);
        String mealId = UUID.randomUUID().toString();
        var meal = Map.of("mealId", mealId, "userId", userId, "rawInput", rawInput, "aiParsed", aiResult, "timestamp", Instant.now().toString());
        storeDocument("diet-meals", mealId, meal);
        return DataProcessResult.success(meal);
    }

    private DataProcessResult<Map<String, Object>> getDailySummary(String userId) throws Exception {
        var result = searchDocuments("diet-meals", Map.of("userId", userId), 50);
        return DataProcessResult.success(Map.of("meals", result.isSuccess() ? result.getData().size() : 0, "userId", userId));
    }

    private DataProcessResult<Map<String, Object>> generateDietPlan(String userId) throws Exception {
        var user = (Map<String, Object>) getDocument("diet-users", userId);
        String plan = aiProvider.complete("Create 7-day diet plan. Goal=" + user.getOrDefault("goal", "maintain") + ", Cal=" + user.getOrDefault("targetCalories", 2000));
        return DataProcessResult.success(Map.of("plan", plan));
    }
}
