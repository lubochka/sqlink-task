// XIIGen WhatsApp Diet Flow — Rust | Skill 41
use serde_json::{json, Value};
use uuid::Uuid;
use chrono::Utc;
use crate::core::{DataProcessResult, IAiProvider, IDatabaseService, IQueueService, MicroserviceBase};

pub struct WhatsAppDietExecutor {
    base: MicroserviceBase,
    ai: Option<Box<dyn IAiProvider>>,
}

impl WhatsAppDietExecutor {
    pub fn new(db: Box<dyn IDatabaseService>, queue: Box<dyn IQueueService>, ai: Option<Box<dyn IAiProvider>>) -> Self {
        Self { base: MicroserviceBase::new(db, queue, "whatsapp-diet"), ai }
    }

    pub async fn register_user(&self, phone: &str, name: &str, goal: &str, target_cal: u32) -> DataProcessResult<Value> {
        let uid = Uuid::new_v4().to_string();
        let user = json!({"userId": uid, "phone": phone, "name": name, "targetCalories": target_cal, "goal": goal});
        self.base.store_document("diet-users", &uid, &user).await;
        DataProcessResult::success(user)
    }

    pub async fn process_message(&self, user_id: &str, message: &str) -> DataProcessResult<Value> {
        let user = self.base.get_document("diet-users", user_id).await;
        if user.is_none() { return DataProcessResult::failure("User not registered"); }
        let msg = message.to_lowercase();
        if msg.starts_with("/summary") { return self.get_daily_summary(user_id).await; }
        if msg.starts_with("/plan") { return self.generate_diet_plan(user_id).await; }
        self.log_meal(user_id, message).await
    }

    pub async fn log_meal(&self, user_id: &str, raw_input: &str) -> DataProcessResult<Value> {
        let ai = match &self.ai { Some(a) => a, None => return DataProcessResult::failure("No AI provider") };
        let prompt = format!("Parse food: \"{}\". Return JSON array of {{name, calories, proteinG}}", raw_input);
        let parsed = ai.complete(&prompt).await;
        let meal_id = Uuid::new_v4().to_string();
        let meal = json!({"mealId": meal_id, "userId": user_id, "rawInput": raw_input, "aiParsed": parsed, "timestamp": Utc::now().to_rfc3339()});
        self.base.store_document("diet-meals", &meal_id, &meal).await;
        DataProcessResult::success(meal)
    }

    async fn get_daily_summary(&self, user_id: &str) -> DataProcessResult<Value> {
        let result = self.base.search_documents("diet-meals", &json!({"userId": user_id}), 50).await;
        DataProcessResult::success(json!({"meals": result.data.len(), "userId": user_id}))
    }

    async fn generate_diet_plan(&self, user_id: &str) -> DataProcessResult<Value> {
        let ai = match &self.ai { Some(a) => a, None => return DataProcessResult::failure("No AI") };
        let plan = ai.complete(&format!("Create 7-day diet plan for user {}", user_id)).await;
        DataProcessResult::success(json!({"plan": plan}))
    }
}
