// XIIGen WhatsApp Diet Flow — Node.js/TypeScript | Skill 41
import { IDatabaseService, IQueueService, IAiProvider, DataProcessResult, MicroserviceBase } from '../../01-core-interfaces';

interface DietUser { userId: string; phone: string; name: string; targetCalories: number; targetProteinG: number; targetCarbsG: number; targetFatG: number; goal: string; dietPlan?: string; }
interface FoodItem { name: string; quantity: number; unit: string; calories: number; proteinG: number; carbsG: number; fatG: number; confidence: number; }
interface DietMeal { mealId: string; userId: string; rawInput: string; items: FoodItem[]; totalCalories: number; mealType: string; timestamp: Date; }

export class WhatsAppDietExecutor extends MicroserviceBase {
  private aiProvider?: IAiProvider;
  protected serviceName = 'whatsapp-diet';

  constructor(db: IDatabaseService, queue: IQueueService, ai?: IAiProvider) { super(db, queue); this.aiProvider = ai; }

  async registerUser(phone: string, name: string, goal = 'maintain', targetCalories = 2000): Promise<DataProcessResult<DietUser>> {
    const user: DietUser = { userId: crypto.randomUUID(), phone, name, targetCalories, targetProteinG: 120, targetCarbsG: 250, targetFatG: 65, goal };
    await this.storeDocument('diet-users', user.userId, user);
    return DataProcessResult.success(user);
  }

  async processMessage(userId: string, message: string): Promise<DataProcessResult<any>> {
    const user = await this.getDocument('diet-users', userId) as any;
    if (!user) return DataProcessResult.failure('User not registered');
    if (message.toLowerCase().startsWith('/summary')) return this.getDailySummary(userId);
    if (message.toLowerCase().startsWith('/plan')) return this.generateDietPlan(userId);
    return this.logMeal(userId, message);
  }

  async logMeal(userId: string, rawInput: string): Promise<DataProcessResult<DietMeal>> {
    if (!this.aiProvider) return DataProcessResult.failure('No AI provider');
    const prompt = `Parse this food intake and return JSON array of {name, quantity, unit, calories, proteinG, carbsG, fatG, confidence}: "${rawInput}"`;
    const aiResult = await this.aiProvider.complete(prompt);
    let items: FoodItem[];
    try { items = JSON.parse(aiResult); } catch { items = [{ name: rawInput, quantity: 1, unit: 'serving', calories: 0, proteinG: 0, carbsG: 0, fatG: 0, confidence: 0.3 }]; }
    const meal: DietMeal = { mealId: crypto.randomUUID(), userId, rawInput, items, totalCalories: items.reduce((s, i) => s + i.calories, 0), mealType: 'snack', timestamp: new Date() };
    await this.storeDocument('diet-meals', meal.mealId, meal);
    return DataProcessResult.success(meal);
  }

  async getDailySummary(userId: string): Promise<DataProcessResult<any>> {
    const today = new Date().toISOString().split('T')[0];
    const result = await this.searchDocuments('diet-meals', { userId }, 50);
    const meals = (result.data || []).filter((m: any) => m.timestamp?.startsWith(today));
    const totals = { calories: 0, proteinG: 0, carbsG: 0, fatG: 0, mealCount: meals.length };
    meals.forEach((m: any) => { totals.calories += m.totalCalories || 0; });
    return DataProcessResult.success(totals);
  }

  async generateDietPlan(userId: string): Promise<DataProcessResult<string>> {
    const user = await this.getDocument('diet-users', userId) as any;
    if (!user || !this.aiProvider) return DataProcessResult.failure('Cannot generate plan');
    const prompt = `Create a 7-day diet plan for: Goal=${user.goal}, Calories=${user.targetCalories}, Protein=${user.targetProteinG}g`;
    const plan = await this.aiProvider.complete(prompt);
    await this.storeDocument('diet-users', userId, { ...user, dietPlan: plan });
    return DataProcessResult.success(plan);
  }
}
