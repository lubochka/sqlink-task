<?php
// XIIGen WhatsApp Diet Flow — PHP | Skill 41
namespace XIIGen\Pipeline\Diet;
use XIIGen\Core\{MicroserviceBase, DataProcessResult, IDatabaseService, IQueueService, IAiProvider};

class WhatsAppDietExecutor extends MicroserviceBase {
    protected string $serviceName = 'whatsapp-diet';
    private ?IAiProvider $ai;

    public function __construct(IDatabaseService $db, IQueueService $queue, ?IAiProvider $ai = null) {
        parent::__construct($db, $queue); $this->ai = $ai;
    }

    public function registerUser(string $phone, string $name, string $goal = 'maintain', int $targetCalories = 2000): DataProcessResult {
        $userId = \Ramsey\Uuid\Uuid::uuid4()->toString();
        $user = ['userId' => $userId, 'phone' => $phone, 'name' => $name, 'targetCalories' => $targetCalories, 'goal' => $goal];
        $this->storeDocument('diet-users', $userId, $user);
        return DataProcessResult::success($user);
    }

    public function processMessage(string $userId, string $message): DataProcessResult {
        $user = $this->getDocument('diet-users', $userId);
        if (!$user) return DataProcessResult::failure('User not registered');
        $msg = strtolower(trim($message));
        if (str_starts_with($msg, '/summary')) return $this->getDailySummary($userId);
        if (str_starts_with($msg, '/plan')) return $this->generateDietPlan($userId);
        return $this->logMeal($userId, $message);
    }

    public function logMeal(string $userId, string $rawInput): DataProcessResult {
        if (!$this->ai) return DataProcessResult::failure('No AI provider');
        $prompt = "Parse food: \"$rawInput\". Return JSON array of {name, calories, proteinG, carbsG, fatG}";
        $parsed = $this->ai->complete($prompt);
        $mealId = \Ramsey\Uuid\Uuid::uuid4()->toString();
        $meal = ['mealId' => $mealId, 'userId' => $userId, 'rawInput' => $rawInput, 'aiParsed' => $parsed, 'timestamp' => date('c')];
        $this->storeDocument('diet-meals', $mealId, $meal);
        return DataProcessResult::success($meal);
    }

    private function getDailySummary(string $userId): DataProcessResult {
        $result = $this->searchDocuments('diet-meals', ['userId' => $userId], 50);
        return DataProcessResult::success(['meals' => count($result->data ?? []), 'userId' => $userId]);
    }

    private function generateDietPlan(string $userId): DataProcessResult {
        if (!$this->ai) return DataProcessResult::failure('No AI');
        $plan = $this->ai->complete("Create 7-day diet plan for user $userId");
        return DataProcessResult::success(['plan' => $plan]);
    }
}
