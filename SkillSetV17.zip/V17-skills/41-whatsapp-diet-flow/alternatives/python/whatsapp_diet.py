# XIIGen WhatsApp Diet Flow — Python | Skill 41
import json, uuid
from datetime import datetime, timezone
from core_interfaces import IDatabaseService, IQueueService, IAiProvider, DataProcessResult, MicroserviceBase

class WhatsAppDietExecutor(MicroserviceBase):
    service_name = "whatsapp-diet"

    def __init__(self, db: IDatabaseService, queue: IQueueService, ai: IAiProvider = None):
        super().__init__(db, queue)
        self._ai = ai

    async def register_user(self, phone: str, name: str, goal: str = "maintain", target_calories: int = 2000) -> DataProcessResult:
        user = {"userId": str(uuid.uuid4()), "phone": phone, "name": name, "targetCalories": target_calories, "targetProteinG": 120, "targetCarbsG": 250, "targetFatG": 65, "goal": goal}
        await self.store_document("diet-users", user["userId"], user)
        return DataProcessResult.success(user)

    async def process_message(self, user_id: str, message: str) -> DataProcessResult:
        user = await self.get_document("diet-users", user_id)
        if not user: return DataProcessResult.failure("User not registered")
        msg_lower = message.lower().strip()
        if msg_lower.startswith("/summary"): return await self.get_daily_summary(user_id)
        if msg_lower.startswith("/plan"): return await self.generate_diet_plan(user_id)
        return await self.log_meal(user_id, message)

    async def log_meal(self, user_id: str, raw_input: str) -> DataProcessResult:
        if not self._ai: return DataProcessResult.failure("No AI provider")
        prompt = f'Parse this food: "{raw_input}". Return JSON array of {{name, quantity, unit, calories, proteinG, carbsG, fatG, confidence}}'
        ai_result = await self._ai.complete(prompt)
        try: items = json.loads(ai_result)
        except: items = [{"name": raw_input, "quantity": 1, "calories": 0, "proteinG": 0, "carbsG": 0, "fatG": 0, "confidence": 0.3}]
        meal = {"mealId": str(uuid.uuid4()), "userId": user_id, "rawInput": raw_input, "items": items, "totalCalories": sum(i.get("calories", 0) for i in items), "timestamp": datetime.now(timezone.utc).isoformat()}
        await self.store_document("diet-meals", meal["mealId"], meal)
        return DataProcessResult.success(meal)

    async def get_daily_summary(self, user_id: str) -> DataProcessResult:
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        result = await self.search_documents("diet-meals", {"userId": user_id}, 50)
        meals = [m for m in (result.data or []) if m.get("timestamp", "").startswith(today)]
        totals = {"calories": sum(m.get("totalCalories", 0) for m in meals), "mealCount": len(meals), "date": today}
        return DataProcessResult.success(totals)
