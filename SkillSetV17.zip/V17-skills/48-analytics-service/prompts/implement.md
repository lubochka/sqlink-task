# Skill 48 — Analytics Service: Implementation Prompt

## Overview
Implement a comprehensive analytics service with event tracking, time-windowed metric aggregation, engagement scoring, funnel analysis, campaign metrics, and real-time counters. The service observes all platform activity and produces insights that other services consume (e.g., Ranking Engine uses engagement scores from Analytics). It appears in 7 of 8 UML diagrams.

## Phase 1: Configuration & Models
1. Create `AnalyticsConfig`: eventsIndex ("analytics-events"), metricsIndex ("analytics-metrics"), funnelsIndex ("analytics-funnels"), configIndex ("analytics-config"), counterPrefix ("analytics:counter:"), defaultPageSize (100), maxBatchSize (1000), retentionDays (raw: 30, hourly: 90, daily: 365)
2. Create `EngagementWeights`: view (1.0), click (2.0), like (3.0), comment (5.0), share (7.0), create (10.0), purchase (15.0) — these are defaults, overridden by FREEDOM config
3. Create `TimeWindowParser`: parse window strings ("1h", "1d", "7d", "30d") into time spans, generate window keys for grouping
4. All returns use `DataProcessResult<T>` (Genie DNA-5)
5. **DNA-1**: All events, metrics, funnels are dynamic documents (Dictionary<string,object> or language equivalent), NOT typed models

## Phase 2: Event Collection (Core)
1. **TrackEvent**: parse via `parseObjectAlternative()`, validate required fields (scopeId, eventType), generate eventId if missing, set timestamps, store in ES, publish AnalyticsEventTracked event, check alerts
2. **TrackBatch**: iterate events with individual validation, track success/failure count, respect maxBatchSize limit
3. **IncrementCounter**: atomic Redis counter increment using counterPrefix + scopeId + counterName
4. **GetCounter**: read current counter value from Redis

## Phase 3: Metric Aggregation (MACHINE)
1. **AggregateWindow**: query raw events in time window using BuildSearchFilter, group by eventType, compute counts and sums, track custom dimension breakdowns, store aggregated metric document, publish MetricAggregated event
2. **GetMetrics**: BuildSearchFilter with scopeId + optional eventType, dateRange, dimension — null fields skipped. Paginated query on metrics index
3. **GetTimeSeries**: query metrics by window size and date range, sort by windowStart ascending, extract specific metric values for charting
4. **CompactMetrics**: delete raw events older than rawRetentionDays, delete hourly metrics older than hourlyRetentionDays. Retention periods come from config (FREEDOM)

## Phase 4: Engagement Scoring
1. **CalculateEngagement**: load weights from config (FREEDOM), query last 30 days of events for entity, compute weighted sum using signal-to-weight mapping, normalize by days in period, store score as dynamic document, publish EngagementScoreUpdated
2. **GetEngagementScore**: retrieve cached score from metrics index by composite key
3. **RecalculateAllScores**: get all unique entityIds from recent events, call CalculateEngagement for each, return count of recalculated

## Phase 5: Funnel Analysis
1. **DefineFunnel** (FREEDOM): admin defines funnel with ordered step names and timeout window — stored as dynamic config document
2. **TrackFunnelStep**: load funnel definition, validate step exists, load entity's current progress, check timeout (start new session if expired), update completed steps and timestamps, publish FunnelStepCompleted/FunnelCompleted events
3. **GetFunnelAnalysis**: load all progress records for funnel, compute per-step entered/completed/dropoff rates, compute overall completion rate
4. **GetEntityFunnelProgress**: retrieve specific entity's funnel state

## Phase 6: Campaign Metrics
1. **TrackCampaignEvent**: parse event with campaignId and action (sent/delivered/opened/clicked/converted/unsubscribed), store as analytics event, update campaign aggregate document with incremented counters, calculate rates (openRate, clickRate, conversionRate)
2. **GetCampaignMetrics**: retrieve campaign aggregate document by composite key

## Phase 7: Configuration (FREEDOM)
1. **GetConfig**: load from analytics-config index by scopeId, fall back to defaults
2. **UpdateConfig**: store config as dynamic document — includes aggregation windows, engagement weights, retention policies, custom dimensions, alerts
3. **DefineFunnel**: create/update funnel definition (ordered steps + timeout)
4. **DefineAlert**: create/update alert threshold (metric, operator, threshold, window)

## Phase 8: Integration
1. Wire into DI container with IDatabaseService, IQueueService, IObjectProcessor
2. Subscribe to events from ALL services: PostCreated, FeedItemIngested, MatchScoreUpdated, UserRegistered, EventRegistered, PaymentCompleted, NotificationClicked, etc.
3. API endpoints: POST /analytics/track, GET /analytics/metrics, GET /analytics/timeseries, GET /analytics/engagement/{entityId}, POST /analytics/funnel/step, GET /analytics/funnel/{funnelId}, GET /analytics/campaign/{campaignId}, PUT /analytics/config/{scopeId}

## DNA Compliance Checklist
- [ ] All data stored as `Dictionary<string, object>` (DNA-1)
- [ ] All queries use `BuildSearchFilter` with empty-field skipping (DNA-2)
- [ ] All operations return `DataProcessResult<T>` (DNA-5)
- [ ] scopeId always included in queries (DNA-SCOPE)
- [ ] Aggregation windows, weights, funnels, alerts stored as dynamic config (DNA-FREEDOM)
- [ ] Events published for all state changes (DNA-7)
- [ ] No typed model classes for events or metrics

## Test Scenarios
1. Track 100 events of various types → GetMetrics returns correct counts per type
2. AggregateWindow("1h") over 3 hours of data → produces 3 hourly rollups with correct counts
3. CalculateEngagement with known signals → score matches expected weighted formula
4. Define 5-step funnel → track steps in order → GetFunnelAnalysis shows 100% completion
5. Track steps 1-3 only → GetFunnelAnalysis shows correct dropoff at step 4
6. Wait past funnel timeout → next step starts new session
7. Scope isolation: tenant A events never visible in tenant B queries
8. 1000 concurrent IncrementCounter calls → final value is exactly 1000
9. Set alert threshold at 5% → push metric to 6% → AlertTriggered event published
10. Update engagement weights → next CalculateEngagement uses new weights
11. Track campaign send/open/click → GetCampaignMetrics returns correct CTR
12. CompactMetrics removes data older than retention policy

## Abstraction Prompt (for AI agents)
> Given an analytics service that tracks platform activity across multiple services with
> time-windowed aggregation, engagement scoring, and funnel analysis, extract the following
> patterns: (1) Universal event collection with dynamic schema — any service can emit any
> event type, (2) Configurable time-window aggregation with dimension grouping for flexible
> reporting, (3) Weighted multi-signal scoring for entity engagement measurement, (4) Ordered
> step funnel tracking with timeout and session management, (5) Real-time counter patterns
> for high-frequency metrics. These patterns can be applied to any observability system:
> product analytics, A/B testing platforms, marketing automation, user behavior tracking,
> or system performance monitoring.
