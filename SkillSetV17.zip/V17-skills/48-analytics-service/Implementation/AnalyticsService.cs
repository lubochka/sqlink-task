// XIIGen.Services.Analytics/AnalyticsService.cs — Skill 48 | .NET 9
// Event tracking, metric aggregation, engagement scoring, funnel analysis, campaign metrics
// Genie DNA: DNA-1 (Dictionary<string,object>), DNA-2 (BuildSearchFilter), DNA-5 (DataProcessResult)

using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System.Collections.Concurrent;
using System.Text.Json;
using XIIGen.Core.Base;
using XIIGen.Core.Interfaces;
using XIIGen.Core.Models;

namespace XIIGen.Services.Analytics;

// ─── Configuration ──────────────────────────────────────────────
public class AnalyticsConfig
{
    public string EventsIndex { get; set; } = "analytics-events";
    public string MetricsIndex { get; set; } = "analytics-metrics";
    public string FunnelsIndex { get; set; } = "analytics-funnels";
    public string ConfigIndex { get; set; } = "analytics-config";
    public string CounterPrefix { get; set; } = "analytics:counter:";
    public int DefaultPageSize { get; set; } = 100;
    public int MaxBatchSize { get; set; } = 1000;
    public int RawRetentionDays { get; set; } = 30;
    public int HourlyRetentionDays { get; set; } = 90;
    public int DailyRetentionDays { get; set; } = 365;
    public List<string> DefaultAggregationWindows { get; set; } = ["1h", "1d", "7d", "30d"];
}

// ─── Engagement Weights (default, overridden by FREEDOM config) ──
public class EngagementWeights
{
    public double View { get; set; } = 1.0;
    public double Click { get; set; } = 2.0;
    public double Like { get; set; } = 3.0;
    public double Comment { get; set; } = 5.0;
    public double Share { get; set; } = 7.0;
    public double Create { get; set; } = 10.0;
    public double Purchase { get; set; } = 15.0;
}

// ─── Aggregation Result ─────────────────────────────────────────
public class AggregationBucket
{
    public string WindowStart { get; set; } = "";
    public string WindowEnd { get; set; } = "";
    public string WindowSize { get; set; } = "";
    public Dictionary<string, long> Counts { get; set; } = new();
    public Dictionary<string, double> Sums { get; set; } = new();
    public Dictionary<string, Dictionary<string, long>> DimensionBreakdowns { get; set; } = new();
}

// ─── Funnel Step Result ─────────────────────────────────────────
public class FunnelStepResult
{
    public string StepName { get; set; } = "";
    public int StepIndex { get; set; }
    public long EnteredCount { get; set; }
    public long CompletedCount { get; set; }
    public double CompletionRate { get; set; }
    public double DropOffRate { get; set; }
}

// ─── Time Window Parser ─────────────────────────────────────────
public static class TimeWindowParser
{
    public static TimeSpan Parse(string window)
    {
        if (string.IsNullOrEmpty(window)) return TimeSpan.FromHours(1);
        var value = int.TryParse(window[..^1], out var v) ? v : 1;
        return window[^1] switch
        {
            'h' => TimeSpan.FromHours(value),
            'd' => TimeSpan.FromDays(value),
            'w' => TimeSpan.FromDays(value * 7),
            'm' => TimeSpan.FromDays(value * 30),
            _ => TimeSpan.FromHours(value)
        };
    }

    public static string GetWindowKey(DateTime timestamp, string window)
    {
        var span = Parse(window);
        if (span.TotalHours <= 1)
            return timestamp.ToString("yyyy-MM-dd-HH");
        if (span.TotalDays <= 1)
            return timestamp.ToString("yyyy-MM-dd");
        if (span.TotalDays <= 7)
        {
            var weekStart = timestamp.AddDays(-(int)timestamp.DayOfWeek);
            return $"W-{weekStart:yyyy-MM-dd}";
        }
        return timestamp.ToString("yyyy-MM");
    }
}

// ─── Service Interface ──────────────────────────────────────────
public interface IAnalyticsService
{
    // Event Collection
    Task<DataProcessResult<Dictionary<string, object>>> TrackEventAsync(
        Dictionary<string, object> eventData, CancellationToken ct = default);
    Task<DataProcessResult<int>> TrackBatchAsync(
        List<Dictionary<string, object>> events, CancellationToken ct = default);
    Task<DataProcessResult<long>> IncrementCounterAsync(
        string scopeId, string counterName, long delta = 1, CancellationToken ct = default);
    Task<DataProcessResult<long>> GetCounterAsync(
        string scopeId, string counterName, CancellationToken ct = default);

    // Metric Aggregation
    Task<DataProcessResult<Dictionary<string, object>>> AggregateWindowAsync(
        string scopeId, string window, DateTime windowStart, CancellationToken ct = default);
    Task<DataProcessResult<List<Dictionary<string, object>>>> GetMetricsAsync(
        string scopeId, string? eventType, DateTime? startDate, DateTime? endDate,
        string? dimension, int page, int pageSize, CancellationToken ct = default);
    Task<DataProcessResult<List<Dictionary<string, object>>>> GetTimeSeriesAsync(
        string scopeId, string metricName, string window, DateTime startDate,
        DateTime endDate, CancellationToken ct = default);
    Task<DataProcessResult<int>> CompactMetricsAsync(
        string scopeId, CancellationToken ct = default);

    // Engagement Scoring
    Task<DataProcessResult<Dictionary<string, object>>> CalculateEngagementAsync(
        string scopeId, string entityId, CancellationToken ct = default);
    Task<DataProcessResult<double>> GetEngagementScoreAsync(
        string scopeId, string entityId, CancellationToken ct = default);
    Task<DataProcessResult<int>> RecalculateAllScoresAsync(
        string scopeId, CancellationToken ct = default);

    // Funnel Analysis
    Task<DataProcessResult<Dictionary<string, object>>> TrackFunnelStepAsync(
        string scopeId, string funnelId, string entityId, string stepName,
        CancellationToken ct = default);
    Task<DataProcessResult<Dictionary<string, object>>> GetFunnelAnalysisAsync(
        string scopeId, string funnelId, DateTime? startDate, DateTime? endDate,
        CancellationToken ct = default);
    Task<DataProcessResult<Dictionary<string, object>>> GetEntityFunnelProgressAsync(
        string scopeId, string funnelId, string entityId, CancellationToken ct = default);

    // Campaign Metrics
    Task<DataProcessResult<Dictionary<string, object>>> TrackCampaignEventAsync(
        Dictionary<string, object> campaignEvent, CancellationToken ct = default);
    Task<DataProcessResult<Dictionary<string, object>>> GetCampaignMetricsAsync(
        string scopeId, string campaignId, CancellationToken ct = default);

    // Configuration (FREEDOM)
    Task<DataProcessResult<Dictionary<string, object>>> GetConfigAsync(
        string scopeId, CancellationToken ct = default);
    Task<DataProcessResult<Dictionary<string, object>>> UpdateConfigAsync(
        string scopeId, Dictionary<string, object> config, CancellationToken ct = default);
    Task<DataProcessResult<Dictionary<string, object>>> DefineFunnelAsync(
        string scopeId, Dictionary<string, object> funnelDef, CancellationToken ct = default);
    Task<DataProcessResult<Dictionary<string, object>>> DefineAlertAsync(
        string scopeId, Dictionary<string, object> alertDef, CancellationToken ct = default);
}

// ─── Service Implementation ─────────────────────────────────────
public class AnalyticsService : IAnalyticsService
{
    private readonly IDatabaseService _db;
    private readonly IQueueService _queue;
    private readonly IObjectProcessor _objectProcessor;
    private readonly ILogger<AnalyticsService> _logger;
    private readonly AnalyticsConfig _config;

    public AnalyticsService(
        IDatabaseService db,
        IQueueService queue,
        IObjectProcessor objectProcessor,
        ILogger<AnalyticsService> logger,
        AnalyticsConfig? config = null)
    {
        _db = db;
        _queue = queue;
        _objectProcessor = objectProcessor;
        _logger = logger;
        _config = config ?? new AnalyticsConfig();
    }

    // ═══════════════════════════════════════════════════════════════
    // EVENT COLLECTION
    // ═══════════════════════════════════════════════════════════════

    public async Task<DataProcessResult<Dictionary<string, object>>> TrackEventAsync(
        Dictionary<string, object> eventData, CancellationToken ct = default)
    {
        try
        {
            // DNA-1: Parse as dynamic document
            var doc = _objectProcessor.ParseObjectAlternative(eventData);

            // Validate required fields
            if (!doc.ContainsKey("scopeId"))
                return DataProcessResult<Dictionary<string, object>>.Error(
                    "Missing required field: scopeId (DNA-SCOPE)");
            if (!doc.ContainsKey("eventType"))
                return DataProcessResult<Dictionary<string, object>>.Error(
                    "Missing required field: eventType");

            // Generate event ID and enrich
            if (!doc.ContainsKey("eventId"))
                doc["eventId"] = Guid.NewGuid().ToString();
            if (!doc.ContainsKey("timestamp"))
                doc["timestamp"] = DateTime.UtcNow.ToString("o");
            doc["trackedAt"] = DateTime.UtcNow.ToString("o");

            // Store in Elasticsearch
            var eventId = GetString(doc, "eventId");
            await _db.UpsertAsync(_config.EventsIndex, eventId, doc, ct);

            _logger.LogDebug("Tracked analytics event {EventId} type={EventType} scope={ScopeId}",
                eventId, GetString(doc, "eventType"), GetString(doc, "scopeId"));

            // Publish event
            await PublishEventAsync("AnalyticsEventTracked", doc, ct);

            // Check alerts
            await CheckAlertsAsync(doc, ct);

            return DataProcessResult<Dictionary<string, object>>.Success(doc);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to track analytics event");
            return DataProcessResult<Dictionary<string, object>>.Error(ex.Message);
        }
    }

    public async Task<DataProcessResult<int>> TrackBatchAsync(
        List<Dictionary<string, object>> events, CancellationToken ct = default)
    {
        try
        {
            if (events.Count > _config.MaxBatchSize)
                return DataProcessResult<int>.Error(
                    $"Batch size {events.Count} exceeds maximum {_config.MaxBatchSize}");

            var successCount = 0;
            var errors = new List<string>();

            foreach (var evt in events)
            {
                var result = await TrackEventAsync(evt, ct);
                if (result.IsSuccess)
                    successCount++;
                else
                    errors.Add(result.ErrorMessage ?? "Unknown error");
            }

            if (errors.Count > 0)
                _logger.LogWarning("Batch tracking: {Success}/{Total} succeeded, {Errors} errors",
                    successCount, events.Count, errors.Count);

            return DataProcessResult<int>.Success(successCount);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to track batch events");
            return DataProcessResult<int>.Error(ex.Message);
        }
    }

    public async Task<DataProcessResult<long>> IncrementCounterAsync(
        string scopeId, string counterName, long delta = 1, CancellationToken ct = default)
    {
        try
        {
            var key = $"{_config.CounterPrefix}{scopeId}:{counterName}";
            var newValue = await _queue.IncrementAsync(key, delta, ct);
            return DataProcessResult<long>.Success(newValue);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to increment counter {CounterName}", counterName);
            return DataProcessResult<long>.Error(ex.Message);
        }
    }

    public async Task<DataProcessResult<long>> GetCounterAsync(
        string scopeId, string counterName, CancellationToken ct = default)
    {
        try
        {
            var key = $"{_config.CounterPrefix}{scopeId}:{counterName}";
            var value = await _queue.GetCounterAsync(key, ct);
            return DataProcessResult<long>.Success(value);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to get counter {CounterName}", counterName);
            return DataProcessResult<long>.Error(ex.Message);
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // METRIC AGGREGATION
    // ═══════════════════════════════════════════════════════════════

    public async Task<DataProcessResult<Dictionary<string, object>>> AggregateWindowAsync(
        string scopeId, string window, DateTime windowStart, CancellationToken ct = default)
    {
        try
        {
            var windowSpan = TimeWindowParser.Parse(window);
            var windowEnd = windowStart.Add(windowSpan);
            var windowKey = TimeWindowParser.GetWindowKey(windowStart, window);

            // DNA-2: BuildSearchFilter with empty-field skipping
            var eventFilter = _objectProcessor.BuildSearchFilter(new Dictionary<string, object>
            {
                ["scopeId"] = scopeId,
                ["timestampGte"] = windowStart.ToString("o"),
                ["timestampLte"] = windowEnd.ToString("o")
            });

            // Query raw events in the window
            var events = await _db.QueryAsync(_config.EventsIndex, eventFilter,
                _config.MaxBatchSize, 0, ct) ?? [];

            // Aggregate by eventType
            var countsByType = new Dictionary<string, long>();
            var sumsByType = new Dictionary<string, double>();
            var dimensionBreakdowns = new Dictionary<string, Dictionary<string, long>>();

            // Load config for custom dimensions
            var analyticsConfig = await LoadConfigAsync(scopeId, ct);
            var customDimensions = GetStringList(analyticsConfig, "customDimensions");

            foreach (var evt in events)
            {
                var eventType = GetString(evt, "eventType");
                if (string.IsNullOrEmpty(eventType)) continue;

                // Count by type
                countsByType[eventType] = countsByType.GetValueOrDefault(eventType, 0) + 1;

                // Sum numeric values if present
                if (evt.TryGetValue("value", out var valObj))
                {
                    var val = ToDouble(valObj);
                    sumsByType[eventType] = sumsByType.GetValueOrDefault(eventType, 0.0) + val;
                }

                // Dimension breakdowns
                foreach (var dim in customDimensions)
                {
                    if (evt.TryGetValue(dim, out var dimVal) && dimVal != null)
                    {
                        var dimStr = dimVal.ToString() ?? "";
                        var dimKey = $"{eventType}:{dim}";
                        if (!dimensionBreakdowns.ContainsKey(dimKey))
                            dimensionBreakdowns[dimKey] = new Dictionary<string, long>();
                        dimensionBreakdowns[dimKey][dimStr] =
                            dimensionBreakdowns[dimKey].GetValueOrDefault(dimStr, 0) + 1;
                    }
                }
            }

            // DNA-1: Store aggregation as dynamic document
            var metric = _objectProcessor.ParseObjectAlternative(new Dictionary<string, object>
            {
                ["metricId"] = $"{scopeId}:{window}:{windowKey}",
                ["scopeId"] = scopeId,
                ["windowSize"] = window,
                ["windowStart"] = windowStart.ToString("o"),
                ["windowEnd"] = windowEnd.ToString("o"),
                ["windowKey"] = windowKey,
                ["totalEvents"] = events.Count,
                ["countsByType"] = countsByType,
                ["sumsByType"] = sumsByType,
                ["dimensionBreakdowns"] = dimensionBreakdowns,
                ["aggregatedAt"] = DateTime.UtcNow.ToString("o")
            });

            var metricId = GetString(metric, "metricId");
            await _db.UpsertAsync(_config.MetricsIndex, metricId, metric, ct);

            _logger.LogDebug("Aggregated {Window} window for scope {ScopeId}: {Count} events",
                window, scopeId, events.Count);

            await PublishEventAsync("MetricAggregated", metric, ct);

            return DataProcessResult<Dictionary<string, object>>.Success(metric);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to aggregate window {Window} for scope {ScopeId}",
                window, scopeId);
            return DataProcessResult<Dictionary<string, object>>.Error(ex.Message);
        }
    }

    public async Task<DataProcessResult<List<Dictionary<string, object>>>> GetMetricsAsync(
        string scopeId, string? eventType, DateTime? startDate, DateTime? endDate,
        string? dimension, int page, int pageSize, CancellationToken ct = default)
    {
        try
        {
            // DNA-2: BuildSearchFilter — null fields are skipped
            var filter = _objectProcessor.BuildSearchFilter(new Dictionary<string, object>
            {
                ["scopeId"] = scopeId,
                ["eventType"] = eventType ?? (object)DBNull.Value,
                ["timestampGte"] = startDate?.ToString("o") ?? (object)DBNull.Value,
                ["timestampLte"] = endDate?.ToString("o") ?? (object)DBNull.Value,
                ["dimension"] = dimension ?? (object)DBNull.Value
            });

            var offset = page * pageSize;
            var results = await _db.QueryAsync(_config.MetricsIndex, filter, pageSize, offset, ct)
                ?? [];

            return DataProcessResult<List<Dictionary<string, object>>>.Success(results);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to get metrics for scope {ScopeId}", scopeId);
            return DataProcessResult<List<Dictionary<string, object>>>.Error(ex.Message);
        }
    }

    public async Task<DataProcessResult<List<Dictionary<string, object>>>> GetTimeSeriesAsync(
        string scopeId, string metricName, string window, DateTime startDate,
        DateTime endDate, CancellationToken ct = default)
    {
        try
        {
            var filter = _objectProcessor.BuildSearchFilter(new Dictionary<string, object>
            {
                ["scopeId"] = scopeId,
                ["windowSize"] = window,
                ["windowStartGte"] = startDate.ToString("o"),
                ["windowStartLte"] = endDate.ToString("o")
            });

            var results = await _db.QueryAsync(_config.MetricsIndex, filter, 1000, 0, ct) ?? [];

            // Sort by windowStart ascending for time series
            results.Sort((a, b) =>
            {
                var aTime = GetString(a, "windowStart");
                var bTime = GetString(b, "windowStart");
                return string.Compare(aTime, bTime, StringComparison.Ordinal);
            });

            // Extract specific metric from each window
            var series = new List<Dictionary<string, object>>();
            foreach (var r in results)
            {
                var point = new Dictionary<string, object>
                {
                    ["windowStart"] = r.GetValueOrDefault("windowStart", ""),
                    ["windowEnd"] = r.GetValueOrDefault("windowEnd", ""),
                    ["totalEvents"] = r.GetValueOrDefault("totalEvents", 0)
                };

                // Extract specific metric count if available
                if (r.TryGetValue("countsByType", out var counts) &&
                    counts is Dictionary<string, long> countsDict &&
                    countsDict.TryGetValue(metricName, out var count))
                {
                    point["value"] = count;
                }
                else if (r.TryGetValue("countsByType", out var countsObj))
                {
                    point["countsByType"] = countsObj;
                }

                series.Add(point);
            }

            return DataProcessResult<List<Dictionary<string, object>>>.Success(series);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to get time series for {MetricName}", metricName);
            return DataProcessResult<List<Dictionary<string, object>>>.Error(ex.Message);
        }
    }

    public async Task<DataProcessResult<int>> CompactMetricsAsync(
        string scopeId, CancellationToken ct = default)
    {
        try
        {
            var analyticsConfig = await LoadConfigAsync(scopeId, ct);
            var rawRetention = GetInt(analyticsConfig, "rawRetentionDays", _config.RawRetentionDays);
            var hourlyRetention = GetInt(analyticsConfig, "hourlyRetentionDays", _config.HourlyRetentionDays);

            var compactedCount = 0;

            // Delete raw events older than retention
            var rawCutoff = DateTime.UtcNow.AddDays(-rawRetention);
            var rawFilter = _objectProcessor.BuildSearchFilter(new Dictionary<string, object>
            {
                ["scopeId"] = scopeId,
                ["timestampLte"] = rawCutoff.ToString("o")
            });
            var oldRaw = await _db.QueryAsync(_config.EventsIndex, rawFilter, 1000, 0, ct) ?? [];
            foreach (var evt in oldRaw)
            {
                var id = GetString(evt, "eventId");
                if (!string.IsNullOrEmpty(id))
                {
                    await _db.DeleteAsync(_config.EventsIndex, id, ct);
                    compactedCount++;
                }
            }

            // Delete hourly metrics older than hourly retention
            var hourlyCutoff = DateTime.UtcNow.AddDays(-hourlyRetention);
            var hourlyFilter = _objectProcessor.BuildSearchFilter(new Dictionary<string, object>
            {
                ["scopeId"] = scopeId,
                ["windowSize"] = "1h",
                ["windowStartLte"] = hourlyCutoff.ToString("o")
            });
            var oldHourly = await _db.QueryAsync(_config.MetricsIndex, hourlyFilter, 1000, 0, ct) ?? [];
            foreach (var metric in oldHourly)
            {
                var id = GetString(metric, "metricId");
                if (!string.IsNullOrEmpty(id))
                {
                    await _db.DeleteAsync(_config.MetricsIndex, id, ct);
                    compactedCount++;
                }
            }

            _logger.LogInformation("Compacted {Count} records for scope {ScopeId}", compactedCount, scopeId);
            return DataProcessResult<int>.Success(compactedCount);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to compact metrics for scope {ScopeId}", scopeId);
            return DataProcessResult<int>.Error(ex.Message);
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // ENGAGEMENT SCORING
    // ═══════════════════════════════════════════════════════════════

    public async Task<DataProcessResult<Dictionary<string, object>>> CalculateEngagementAsync(
        string scopeId, string entityId, CancellationToken ct = default)
    {
        try
        {
            // Load engagement weights from config (FREEDOM)
            var analyticsConfig = await LoadConfigAsync(scopeId, ct);
            var weights = LoadEngagementWeights(analyticsConfig);

            // Query recent events for this entity (last 30 days)
            var since = DateTime.UtcNow.AddDays(-30);
            var filter = _objectProcessor.BuildSearchFilter(new Dictionary<string, object>
            {
                ["scopeId"] = scopeId,
                ["entityId"] = entityId,
                ["timestampGte"] = since.ToString("o")
            });
            var events = await _db.QueryAsync(_config.EventsIndex, filter, 10000, 0, ct) ?? [];

            // Compute weighted score
            var signalCounts = new Dictionary<string, long>();
            double totalScore = 0;

            foreach (var evt in events)
            {
                var eventType = GetString(evt, "eventType");
                var action = GetString(evt, "action");
                var signal = !string.IsNullOrEmpty(action) ? action : eventType;

                signalCounts[signal] = signalCounts.GetValueOrDefault(signal, 0) + 1;

                // Look up weight for this signal
                var weight = signal.ToLowerInvariant() switch
                {
                    "view" or "page_view" => weights.View,
                    "click" => weights.Click,
                    "like" => weights.Like,
                    "comment" => weights.Comment,
                    "share" => weights.Share,
                    "create" or "post_create" => weights.Create,
                    "purchase" or "payment" => weights.Purchase,
                    _ => weights.View // default to view weight for unknown signals
                };

                totalScore += weight;
            }

            // Normalize: score per day over the period
            var daysInPeriod = Math.Max(1, (DateTime.UtcNow - since).TotalDays);
            var normalizedScore = totalScore / daysInPeriod;

            // DNA-1: Store as dynamic document
            var engagement = _objectProcessor.ParseObjectAlternative(new Dictionary<string, object>
            {
                ["engagementId"] = $"{scopeId}:{entityId}",
                ["scopeId"] = scopeId,
                ["entityId"] = entityId,
                ["totalScore"] = Math.Round(totalScore, 2),
                ["normalizedScore"] = Math.Round(normalizedScore, 2),
                ["totalEvents"] = events.Count,
                ["signalCounts"] = signalCounts,
                ["periodDays"] = 30,
                ["calculatedAt"] = DateTime.UtcNow.ToString("o")
            });

            await _db.UpsertAsync(_config.MetricsIndex,
                $"engagement:{scopeId}:{entityId}", engagement, ct);

            _logger.LogDebug("Calculated engagement for {EntityId}: score={Score}",
                entityId, Math.Round(normalizedScore, 2));

            await PublishEventAsync("EngagementScoreUpdated", engagement, ct);

            return DataProcessResult<Dictionary<string, object>>.Success(engagement);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to calculate engagement for {EntityId}", entityId);
            return DataProcessResult<Dictionary<string, object>>.Error(ex.Message);
        }
    }

    public async Task<DataProcessResult<double>> GetEngagementScoreAsync(
        string scopeId, string entityId, CancellationToken ct = default)
    {
        try
        {
            var doc = await _db.GetByIdAsync(_config.MetricsIndex,
                $"engagement:{scopeId}:{entityId}", ct);

            if (doc == null)
                return DataProcessResult<double>.Success(0.0);

            return DataProcessResult<double>.Success(
                ToDouble(doc.GetValueOrDefault("normalizedScore", 0.0)));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to get engagement score for {EntityId}", entityId);
            return DataProcessResult<double>.Error(ex.Message);
        }
    }

    public async Task<DataProcessResult<int>> RecalculateAllScoresAsync(
        string scopeId, CancellationToken ct = default)
    {
        try
        {
            // Get all unique entity IDs from recent events
            var since = DateTime.UtcNow.AddDays(-30);
            var filter = _objectProcessor.BuildSearchFilter(new Dictionary<string, object>
            {
                ["scopeId"] = scopeId,
                ["timestampGte"] = since.ToString("o")
            });
            var allEvents = await _db.QueryAsync(_config.EventsIndex, filter, 10000, 0, ct) ?? [];

            var entityIds = allEvents
                .Select(e => GetString(e, "entityId"))
                .Where(id => !string.IsNullOrEmpty(id))
                .Distinct()
                .ToList();

            var recalculated = 0;
            foreach (var entityId in entityIds)
            {
                var result = await CalculateEngagementAsync(scopeId, entityId, ct);
                if (result.IsSuccess) recalculated++;
            }

            _logger.LogInformation("Recalculated {Count} engagement scores for scope {ScopeId}",
                recalculated, scopeId);
            return DataProcessResult<int>.Success(recalculated);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to recalculate all scores for scope {ScopeId}", scopeId);
            return DataProcessResult<int>.Error(ex.Message);
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // FUNNEL ANALYSIS
    // ═══════════════════════════════════════════════════════════════

    public async Task<DataProcessResult<Dictionary<string, object>>> TrackFunnelStepAsync(
        string scopeId, string funnelId, string entityId, string stepName,
        CancellationToken ct = default)
    {
        try
        {
            // Load funnel definition (FREEDOM config)
            var funnelDef = await LoadFunnelDefinitionAsync(scopeId, funnelId, ct);
            if (funnelDef == null)
                return DataProcessResult<Dictionary<string, object>>.Error(
                    $"Funnel {funnelId} not defined for scope {scopeId}");

            var steps = GetStringList(funnelDef, "steps");
            var stepIndex = steps.IndexOf(stepName);
            if (stepIndex < 0)
                return DataProcessResult<Dictionary<string, object>>.Error(
                    $"Step '{stepName}' not found in funnel '{funnelId}'");

            var windowHours = GetInt(funnelDef, "windowHours", 72);

            // Get entity's current funnel progress
            var progressId = $"funnel:{scopeId}:{funnelId}:{entityId}";
            var progress = await _db.GetByIdAsync(_config.FunnelsIndex, progressId, ct);

            if (progress == null)
            {
                // First step — start new funnel session
                progress = _objectProcessor.ParseObjectAlternative(new Dictionary<string, object>
                {
                    ["progressId"] = progressId,
                    ["scopeId"] = scopeId,
                    ["funnelId"] = funnelId,
                    ["entityId"] = entityId,
                    ["sessionId"] = Guid.NewGuid().ToString(),
                    ["currentStepIndex"] = stepIndex,
                    ["currentStepName"] = stepName,
                    ["completedSteps"] = new List<string> { stepName },
                    ["stepTimestamps"] = new Dictionary<string, string>
                    {
                        [stepName] = DateTime.UtcNow.ToString("o")
                    },
                    ["startedAt"] = DateTime.UtcNow.ToString("o"),
                    ["updatedAt"] = DateTime.UtcNow.ToString("o"),
                    ["completed"] = stepIndex == steps.Count - 1,
                    ["timedOut"] = false
                });
            }
            else
            {
                // Check if session timed out
                var startedAt = DateTime.TryParse(GetString(progress, "startedAt"), out var sa)
                    ? sa : DateTime.UtcNow;
                var hoursSinceStart = (DateTime.UtcNow - startedAt).TotalHours;

                if (hoursSinceStart > windowHours)
                {
                    // Timeout — start new session
                    progress["sessionId"] = Guid.NewGuid().ToString();
                    progress["currentStepIndex"] = stepIndex;
                    progress["currentStepName"] = stepName;
                    progress["completedSteps"] = new List<string> { stepName };
                    progress["stepTimestamps"] = new Dictionary<string, string>
                    {
                        [stepName] = DateTime.UtcNow.ToString("o")
                    };
                    progress["startedAt"] = DateTime.UtcNow.ToString("o");
                    progress["timedOut"] = false;
                }
                else
                {
                    // Update progress
                    var completedSteps = GetStringList(progress, "completedSteps");
                    if (!completedSteps.Contains(stepName))
                        completedSteps.Add(stepName);
                    progress["completedSteps"] = completedSteps;
                    progress["currentStepIndex"] = stepIndex;
                    progress["currentStepName"] = stepName;

                    var timestamps = progress.GetValueOrDefault("stepTimestamps",
                        new Dictionary<string, string>()) as Dictionary<string, string> ?? new();
                    timestamps[stepName] = DateTime.UtcNow.ToString("o");
                    progress["stepTimestamps"] = timestamps;
                }

                progress["updatedAt"] = DateTime.UtcNow.ToString("o");
                progress["completed"] = stepIndex == steps.Count - 1;
            }

            await _db.UpsertAsync(_config.FunnelsIndex, progressId, progress, ct);

            // Publish events
            await PublishEventAsync("FunnelStepCompleted", progress, ct);
            if (stepIndex == steps.Count - 1)
                await PublishEventAsync("FunnelCompleted", progress, ct);

            _logger.LogDebug("Funnel {FunnelId} step {StepName} tracked for {EntityId}",
                funnelId, stepName, entityId);

            return DataProcessResult<Dictionary<string, object>>.Success(progress);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to track funnel step {StepName} for {EntityId}",
                stepName, entityId);
            return DataProcessResult<Dictionary<string, object>>.Error(ex.Message);
        }
    }

    public async Task<DataProcessResult<Dictionary<string, object>>> GetFunnelAnalysisAsync(
        string scopeId, string funnelId, DateTime? startDate, DateTime? endDate,
        CancellationToken ct = default)
    {
        try
        {
            // Load funnel definition
            var funnelDef = await LoadFunnelDefinitionAsync(scopeId, funnelId, ct);
            if (funnelDef == null)
                return DataProcessResult<Dictionary<string, object>>.Error(
                    $"Funnel {funnelId} not defined");

            var steps = GetStringList(funnelDef, "steps");

            // DNA-2: BuildSearchFilter
            var filter = _objectProcessor.BuildSearchFilter(new Dictionary<string, object>
            {
                ["scopeId"] = scopeId,
                ["funnelId"] = funnelId,
                ["startedAtGte"] = startDate?.ToString("o") ?? (object)DBNull.Value,
                ["startedAtLte"] = endDate?.ToString("o") ?? (object)DBNull.Value
            });

            var allProgress = await _db.QueryAsync(_config.FunnelsIndex, filter, 10000, 0, ct) ?? [];

            // Compute per-step statistics
            var stepResults = new List<Dictionary<string, object>>();
            for (int i = 0; i < steps.Count; i++)
            {
                var stepName = steps[i];
                var reachedCount = allProgress.Count(p =>
                {
                    var completed = GetStringList(p, "completedSteps");
                    return completed.Contains(stepName);
                });

                var previousCount = i == 0 ? allProgress.Count :
                    allProgress.Count(p =>
                    {
                        var completed = GetStringList(p, "completedSteps");
                        return completed.Contains(steps[i - 1]);
                    });

                var completionRate = previousCount > 0
                    ? Math.Round((double)reachedCount / previousCount * 100, 1) : 0;
                var dropOffRate = 100.0 - completionRate;

                stepResults.Add(new Dictionary<string, object>
                {
                    ["stepName"] = stepName,
                    ["stepIndex"] = i,
                    ["enteredCount"] = previousCount,
                    ["completedCount"] = reachedCount,
                    ["completionRate"] = completionRate,
                    ["dropOffRate"] = Math.Round(dropOffRate, 1)
                });
            }

            var totalCompleted = allProgress.Count(p =>
                GetBool(p, "completed"));
            var overallRate = allProgress.Count > 0
                ? Math.Round((double)totalCompleted / allProgress.Count * 100, 1) : 0;

            var analysis = _objectProcessor.ParseObjectAlternative(new Dictionary<string, object>
            {
                ["funnelId"] = funnelId,
                ["scopeId"] = scopeId,
                ["totalSessions"] = allProgress.Count,
                ["totalCompleted"] = totalCompleted,
                ["overallCompletionRate"] = overallRate,
                ["steps"] = stepResults,
                ["analyzedAt"] = DateTime.UtcNow.ToString("o")
            });

            return DataProcessResult<Dictionary<string, object>>.Success(analysis);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to get funnel analysis for {FunnelId}", funnelId);
            return DataProcessResult<Dictionary<string, object>>.Error(ex.Message);
        }
    }

    public async Task<DataProcessResult<Dictionary<string, object>>> GetEntityFunnelProgressAsync(
        string scopeId, string funnelId, string entityId, CancellationToken ct = default)
    {
        try
        {
            var progressId = $"funnel:{scopeId}:{funnelId}:{entityId}";
            var progress = await _db.GetByIdAsync(_config.FunnelsIndex, progressId, ct);

            if (progress == null)
                return DataProcessResult<Dictionary<string, object>>.Success(
                    new Dictionary<string, object>
                    {
                        ["funnelId"] = funnelId,
                        ["entityId"] = entityId,
                        ["status"] = "not_started",
                        ["completedSteps"] = new List<string>()
                    });

            return DataProcessResult<Dictionary<string, object>>.Success(progress);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to get funnel progress for {EntityId}", entityId);
            return DataProcessResult<Dictionary<string, object>>.Error(ex.Message);
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // CAMPAIGN METRICS
    // ═══════════════════════════════════════════════════════════════

    public async Task<DataProcessResult<Dictionary<string, object>>> TrackCampaignEventAsync(
        Dictionary<string, object> campaignEvent, CancellationToken ct = default)
    {
        try
        {
            var doc = _objectProcessor.ParseObjectAlternative(campaignEvent);

            if (!doc.ContainsKey("campaignId") || !doc.ContainsKey("scopeId"))
                return DataProcessResult<Dictionary<string, object>>.Error(
                    "Missing required fields: campaignId, scopeId");

            // Enrich with campaign-specific fields
            if (!doc.ContainsKey("eventId"))
                doc["eventId"] = Guid.NewGuid().ToString();
            doc["eventType"] = $"campaign_{GetString(doc, "action")}";
            if (!doc.ContainsKey("timestamp"))
                doc["timestamp"] = DateTime.UtcNow.ToString("o");

            // Store as regular analytics event
            await _db.UpsertAsync(_config.EventsIndex, GetString(doc, "eventId"), doc, ct);

            // Update campaign aggregate metrics in real-time
            var campaignMetricId = $"campaign:{GetString(doc, "scopeId")}:{GetString(doc, "campaignId")}";
            var existing = await _db.GetByIdAsync(_config.MetricsIndex, campaignMetricId, ct);

            if (existing == null)
            {
                existing = new Dictionary<string, object>
                {
                    ["metricId"] = campaignMetricId,
                    ["scopeId"] = GetString(doc, "scopeId"),
                    ["campaignId"] = GetString(doc, "campaignId"),
                    ["sent"] = 0L,
                    ["delivered"] = 0L,
                    ["opened"] = 0L,
                    ["clicked"] = 0L,
                    ["converted"] = 0L,
                    ["unsubscribed"] = 0L,
                    ["updatedAt"] = DateTime.UtcNow.ToString("o")
                };
            }

            // Increment the appropriate counter
            var action = GetString(doc, "action").ToLowerInvariant();
            if (existing.ContainsKey(action))
            {
                existing[action] = GetLong(existing, action) + 1;
            }
            existing["updatedAt"] = DateTime.UtcNow.ToString("o");

            // Calculate rates
            var sent = GetLong(existing, "sent");
            if (sent > 0)
            {
                existing["openRate"] = Math.Round((double)GetLong(existing, "opened") / sent * 100, 2);
                existing["clickRate"] = Math.Round((double)GetLong(existing, "clicked") / sent * 100, 2);
                existing["conversionRate"] = Math.Round((double)GetLong(existing, "converted") / sent * 100, 2);
            }

            await _db.UpsertAsync(_config.MetricsIndex, campaignMetricId, existing, ct);

            await PublishEventAsync("CampaignMetricsUpdated", existing, ct);

            return DataProcessResult<Dictionary<string, object>>.Success(existing);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to track campaign event");
            return DataProcessResult<Dictionary<string, object>>.Error(ex.Message);
        }
    }

    public async Task<DataProcessResult<Dictionary<string, object>>> GetCampaignMetricsAsync(
        string scopeId, string campaignId, CancellationToken ct = default)
    {
        try
        {
            var metricId = $"campaign:{scopeId}:{campaignId}";
            var metrics = await _db.GetByIdAsync(_config.MetricsIndex, metricId, ct);

            if (metrics == null)
                return DataProcessResult<Dictionary<string, object>>.Success(
                    new Dictionary<string, object>
                    {
                        ["campaignId"] = campaignId,
                        ["scopeId"] = scopeId,
                        ["status"] = "no_data"
                    });

            return DataProcessResult<Dictionary<string, object>>.Success(metrics);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to get campaign metrics for {CampaignId}", campaignId);
            return DataProcessResult<Dictionary<string, object>>.Error(ex.Message);
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // CONFIGURATION (FREEDOM)
    // ═══════════════════════════════════════════════════════════════

    public async Task<DataProcessResult<Dictionary<string, object>>> GetConfigAsync(
        string scopeId, CancellationToken ct = default)
    {
        try
        {
            var config = await LoadConfigAsync(scopeId, ct);
            return DataProcessResult<Dictionary<string, object>>.Success(config);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to get analytics config for scope {ScopeId}", scopeId);
            return DataProcessResult<Dictionary<string, object>>.Error(ex.Message);
        }
    }

    public async Task<DataProcessResult<Dictionary<string, object>>> UpdateConfigAsync(
        string scopeId, Dictionary<string, object> config, CancellationToken ct = default)
    {
        try
        {
            var doc = _objectProcessor.ParseObjectAlternative(config);
            doc["configId"] = $"analytics-config:{scopeId}";
            doc["scopeId"] = scopeId;
            doc["updatedAt"] = DateTime.UtcNow.ToString("o");

            await _db.UpsertAsync(_config.ConfigIndex, GetString(doc, "configId"), doc, ct);

            _logger.LogInformation("Updated analytics config for scope {ScopeId}", scopeId);
            return DataProcessResult<Dictionary<string, object>>.Success(doc);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to update analytics config for scope {ScopeId}", scopeId);
            return DataProcessResult<Dictionary<string, object>>.Error(ex.Message);
        }
    }

    public async Task<DataProcessResult<Dictionary<string, object>>> DefineFunnelAsync(
        string scopeId, Dictionary<string, object> funnelDef, CancellationToken ct = default)
    {
        try
        {
            var doc = _objectProcessor.ParseObjectAlternative(funnelDef);

            if (!doc.ContainsKey("funnelId") || !doc.ContainsKey("steps"))
                return DataProcessResult<Dictionary<string, object>>.Error(
                    "Missing required fields: funnelId, steps");

            doc["scopeId"] = scopeId;
            doc["type"] = "funnel_definition";
            doc["updatedAt"] = DateTime.UtcNow.ToString("o");

            var funnelId = GetString(doc, "funnelId");
            await _db.UpsertAsync(_config.ConfigIndex,
                $"funnel-def:{scopeId}:{funnelId}", doc, ct);

            _logger.LogInformation("Defined funnel {FunnelId} for scope {ScopeId}",
                funnelId, scopeId);
            return DataProcessResult<Dictionary<string, object>>.Success(doc);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to define funnel for scope {ScopeId}", scopeId);
            return DataProcessResult<Dictionary<string, object>>.Error(ex.Message);
        }
    }

    public async Task<DataProcessResult<Dictionary<string, object>>> DefineAlertAsync(
        string scopeId, Dictionary<string, object> alertDef, CancellationToken ct = default)
    {
        try
        {
            var doc = _objectProcessor.ParseObjectAlternative(alertDef);

            if (!doc.ContainsKey("alertId") || !doc.ContainsKey("metric") ||
                !doc.ContainsKey("threshold"))
                return DataProcessResult<Dictionary<string, object>>.Error(
                    "Missing required fields: alertId, metric, threshold");

            doc["scopeId"] = scopeId;
            doc["type"] = "alert_definition";
            doc["updatedAt"] = DateTime.UtcNow.ToString("o");

            var alertId = GetString(doc, "alertId");
            await _db.UpsertAsync(_config.ConfigIndex,
                $"alert-def:{scopeId}:{alertId}", doc, ct);

            _logger.LogInformation("Defined alert {AlertId} for scope {ScopeId}", alertId, scopeId);
            return DataProcessResult<Dictionary<string, object>>.Success(doc);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to define alert for scope {ScopeId}", scopeId);
            return DataProcessResult<Dictionary<string, object>>.Error(ex.Message);
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // PRIVATE HELPERS
    // ═══════════════════════════════════════════════════════════════

    private async Task<Dictionary<string, object>> LoadConfigAsync(
        string scopeId, CancellationToken ct)
    {
        try
        {
            var doc = await _db.GetByIdAsync(_config.ConfigIndex,
                $"analytics-config:{scopeId}", ct);
            return doc ?? GetDefaultConfig(scopeId);
        }
        catch
        {
            return GetDefaultConfig(scopeId);
        }
    }

    private Dictionary<string, object> GetDefaultConfig(string scopeId) =>
        new()
        {
            ["configId"] = $"analytics-config:{scopeId}",
            ["scopeId"] = scopeId,
            ["aggregationWindows"] = _config.DefaultAggregationWindows,
            ["rawRetentionDays"] = _config.RawRetentionDays,
            ["hourlyRetentionDays"] = _config.HourlyRetentionDays,
            ["dailyRetentionDays"] = _config.DailyRetentionDays,
            ["engagementWeights"] = new Dictionary<string, double>
            {
                ["view"] = 1.0, ["click"] = 2.0, ["like"] = 3.0, ["comment"] = 5.0,
                ["share"] = 7.0, ["create"] = 10.0, ["purchase"] = 15.0
            },
            ["customDimensions"] = new List<string> { "platform", "region", "userTier" },
            ["alerts"] = new List<Dictionary<string, object>>()
        };

    private async Task<Dictionary<string, object>?> LoadFunnelDefinitionAsync(
        string scopeId, string funnelId, CancellationToken ct)
    {
        try
        {
            return await _db.GetByIdAsync(_config.ConfigIndex,
                $"funnel-def:{scopeId}:{funnelId}", ct);
        }
        catch
        {
            return null;
        }
    }

    private EngagementWeights LoadEngagementWeights(Dictionary<string, object> config)
    {
        var weights = new EngagementWeights();
        if (config.TryGetValue("engagementWeights", out var wObj))
        {
            if (wObj is Dictionary<string, double> wDict)
            {
                weights.View = wDict.GetValueOrDefault("view", weights.View);
                weights.Click = wDict.GetValueOrDefault("click", weights.Click);
                weights.Like = wDict.GetValueOrDefault("like", weights.Like);
                weights.Comment = wDict.GetValueOrDefault("comment", weights.Comment);
                weights.Share = wDict.GetValueOrDefault("share", weights.Share);
                weights.Create = wDict.GetValueOrDefault("create", weights.Create);
                weights.Purchase = wDict.GetValueOrDefault("purchase", weights.Purchase);
            }
            else if (wObj is Dictionary<string, object> wObjDict)
            {
                weights.View = ToDouble(wObjDict.GetValueOrDefault("view", weights.View));
                weights.Click = ToDouble(wObjDict.GetValueOrDefault("click", weights.Click));
                weights.Like = ToDouble(wObjDict.GetValueOrDefault("like", weights.Like));
                weights.Comment = ToDouble(wObjDict.GetValueOrDefault("comment", weights.Comment));
                weights.Share = ToDouble(wObjDict.GetValueOrDefault("share", weights.Share));
                weights.Create = ToDouble(wObjDict.GetValueOrDefault("create", weights.Create));
                weights.Purchase = ToDouble(wObjDict.GetValueOrDefault("purchase", weights.Purchase));
            }
        }
        return weights;
    }

    private async Task CheckAlertsAsync(Dictionary<string, object> eventDoc, CancellationToken ct)
    {
        try
        {
            var scopeId = GetString(eventDoc, "scopeId");
            var config = await LoadConfigAsync(scopeId, ct);

            if (!config.TryGetValue("alerts", out var alertsObj)) return;
            // Alert checking is typically done in background aggregation, not per-event
            // This is a placeholder for the alert engine integration
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Alert check failed (non-critical)");
        }
    }

    private async Task PublishEventAsync(string eventType,
        Dictionary<string, object> data, CancellationToken ct)
    {
        try
        {
            var envelope = new Dictionary<string, object>
            {
                ["eventType"] = eventType,
                ["data"] = data,
                ["publishedAt"] = DateTime.UtcNow.ToString("o")
            };
            await _queue.PublishAsync("analytics-events", envelope, ct);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to publish {EventType} event (non-critical)", eventType);
        }
    }

    // ─── Value Extraction Helpers ─────────────────────────────────
    private static string GetString(Dictionary<string, object> doc, string key)
    {
        if (doc.TryGetValue(key, out var val))
        {
            if (val is JsonElement je) return je.GetString() ?? "";
            return val?.ToString() ?? "";
        }
        return "";
    }

    private static bool GetBool(Dictionary<string, object> doc, string key, bool fallback = false)
    {
        if (doc.TryGetValue(key, out var val))
        {
            if (val is bool b) return b;
            if (val is JsonElement je && je.ValueKind == JsonValueKind.True) return true;
            if (val is JsonElement jf && jf.ValueKind == JsonValueKind.False) return false;
            if (bool.TryParse(val?.ToString(), out var parsed)) return parsed;
        }
        return fallback;
    }

    private static int GetInt(Dictionary<string, object> doc, string key, int fallback = 0)
    {
        if (doc.TryGetValue(key, out var val))
        {
            if (val is int i) return i;
            if (val is long l) return (int)l;
            if (val is JsonElement je && je.TryGetInt32(out var ji)) return ji;
            if (int.TryParse(val?.ToString(), out var parsed)) return parsed;
        }
        return fallback;
    }

    private static long GetLong(Dictionary<string, object> doc, string key, long fallback = 0)
    {
        if (doc.TryGetValue(key, out var val))
        {
            if (val is long l) return l;
            if (val is int i) return i;
            if (val is JsonElement je && je.TryGetInt64(out var jl)) return jl;
            if (long.TryParse(val?.ToString(), out var parsed)) return parsed;
        }
        return fallback;
    }

    private static double ToDouble(object? val)
    {
        if (val is double d) return d;
        if (val is int i) return i;
        if (val is long l) return l;
        if (val is float f) return f;
        if (val is decimal dec) return (double)dec;
        if (val is JsonElement je && je.TryGetDouble(out var jd)) return jd;
        if (double.TryParse(val?.ToString(), out var parsed)) return parsed;
        return 0.0;
    }

    private static List<string> GetStringList(Dictionary<string, object> doc, string key)
    {
        if (doc.TryGetValue(key, out var val))
        {
            if (val is List<string> list) return list;
            if (val is JsonElement je && je.ValueKind == JsonValueKind.Array)
                return je.EnumerateArray().Select(e => e.GetString() ?? "").ToList();
            if (val is IEnumerable<object> objs)
                return objs.Select(o => o?.ToString() ?? "").ToList();
        }
        return [];
    }
}

// ─── DI Registration ────────────────────────────────────────────
public static class AnalyticsServiceExtensions
{
    public static IServiceCollection AddXIIGenAnalyticsService(
        this IServiceCollection services, AnalyticsConfig? config = null)
    {
        services.AddSingleton(config ?? new AnalyticsConfig());
        services.AddScoped<IAnalyticsService, AnalyticsService>();
        return services;
    }
}
