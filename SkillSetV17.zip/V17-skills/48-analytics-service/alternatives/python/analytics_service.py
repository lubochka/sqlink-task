# XIIGen Analytics Service — Skill 48 | Python Alternative
# Event tracking, metric aggregation, engagement scoring, funnel analysis, campaign metrics
# Genie DNA: DNA-1 (dict[str,Any]), DNA-2 (build_search_filter), DNA-5 (DataProcessResult)

from __future__ import annotations
import uuid
import math
import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Optional
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)

# ─── Configuration ──────────────────────────────────────────────
@dataclass
class AnalyticsConfig:
    events_index: str = "analytics-events"
    metrics_index: str = "analytics-metrics"
    funnels_index: str = "analytics-funnels"
    config_index: str = "analytics-config"
    counter_prefix: str = "analytics:counter:"
    default_page_size: int = 100
    max_batch_size: int = 1000
    raw_retention_days: int = 30
    hourly_retention_days: int = 90
    daily_retention_days: int = 365
    default_aggregation_windows: list[str] = field(default_factory=lambda: ["1h", "1d", "7d", "30d"])

DEFAULT_WEIGHTS: dict[str, float] = {
    "view": 1.0, "click": 2.0, "like": 3.0, "comment": 5.0,
    "share": 7.0, "create": 10.0, "purchase": 15.0,
}

# ─── Data Process Result ────────────────────────────────────────
@dataclass
class DataProcessResult:
    is_success: bool
    data: Any = None
    error_message: str | None = None

    @staticmethod
    def success(data: Any) -> DataProcessResult:
        return DataProcessResult(is_success=True, data=data)

    @staticmethod
    def error(message: str) -> DataProcessResult:
        return DataProcessResult(is_success=False, error_message=message)

# ─── Time Window Parser ─────────────────────────────────────────
class TimeWindowParser:
    @staticmethod
    def parse_seconds(window: str) -> int:
        if not window:
            return 3600
        value = int(window[:-1]) if window[:-1].isdigit() else 1
        unit = window[-1]
        return {"h": 3600, "d": 86400, "w": 604800, "m": 2592000}.get(unit, 3600) * value

    @staticmethod
    def get_window_key(timestamp: datetime, window: str) -> str:
        secs = TimeWindowParser.parse_seconds(window)
        if secs <= 3600:
            return timestamp.strftime("%Y-%m-%d-%H")
        if secs <= 86400:
            return timestamp.strftime("%Y-%m-%d")
        if secs <= 604800:
            start = timestamp - timedelta(days=timestamp.weekday())
            return f"W-{start.strftime('%Y-%m-%d')}"
        return timestamp.strftime("%Y-%m")

# ─── Protocol Interfaces (duck typing) ──────────────────────────
class IDatabaseService:
    async def upsert(self, index: str, doc_id: str, doc: dict) -> None: ...
    async def get_by_id(self, index: str, doc_id: str) -> dict | None: ...
    async def query(self, index: str, filter_: dict, size: int, offset: int) -> list[dict]: ...
    async def delete(self, index: str, doc_id: str) -> None: ...

class IQueueService:
    async def publish(self, channel: str, data: dict) -> None: ...
    async def increment(self, key: str, delta: int) -> int: ...
    async def get_counter(self, key: str) -> int: ...

class IObjectProcessor:
    def parse_object_alternative(self, obj: Any) -> dict[str, Any]: ...
    def build_search_filter(self, criteria: dict) -> dict: ...

# ─── Analytics Service ──────────────────────────────────────────
class AnalyticsService:
    def __init__(
        self,
        db: IDatabaseService,
        queue: IQueueService,
        object_processor: IObjectProcessor,
        config: AnalyticsConfig | None = None,
    ):
        self._db = db
        self._queue = queue
        self._op = object_processor
        self._config = config or AnalyticsConfig()

    # ═══ EVENT COLLECTION ═════════════════════════════════════════

    async def track_event(self, event_data: dict[str, Any]) -> DataProcessResult:
        try:
            doc = self._op.parse_object_alternative(event_data)
            if not doc.get("scopeId"):
                return DataProcessResult.error("Missing required field: scopeId (DNA-SCOPE)")
            if not doc.get("eventType"):
                return DataProcessResult.error("Missing required field: eventType")

            doc.setdefault("eventId", str(uuid.uuid4()))
            doc.setdefault("timestamp", datetime.now(timezone.utc).isoformat())
            doc["trackedAt"] = datetime.now(timezone.utc).isoformat()

            await self._db.upsert(self._config.events_index, doc["eventId"], doc)
            await self._publish_event("AnalyticsEventTracked", doc)
            return DataProcessResult.success(doc)
        except Exception as ex:
            logger.error("Failed to track event: %s", ex)
            return DataProcessResult.error(str(ex))

    async def track_batch(self, events: list[dict[str, Any]]) -> DataProcessResult:
        try:
            if len(events) > self._config.max_batch_size:
                return DataProcessResult.error(
                    f"Batch size {len(events)} exceeds max {self._config.max_batch_size}")
            success = 0
            for evt in events:
                r = await self.track_event(evt)
                if r.is_success:
                    success += 1
            return DataProcessResult.success(success)
        except Exception as ex:
            return DataProcessResult.error(str(ex))

    async def increment_counter(self, scope_id: str, counter_name: str, delta: int = 1) -> DataProcessResult:
        try:
            key = f"{self._config.counter_prefix}{scope_id}:{counter_name}"
            val = await self._queue.increment(key, delta)
            return DataProcessResult.success(val)
        except Exception as ex:
            return DataProcessResult.error(str(ex))

    async def get_counter(self, scope_id: str, counter_name: str) -> DataProcessResult:
        try:
            key = f"{self._config.counter_prefix}{scope_id}:{counter_name}"
            val = await self._queue.get_counter(key)
            return DataProcessResult.success(val)
        except Exception as ex:
            return DataProcessResult.error(str(ex))

    # ═══ METRIC AGGREGATION ═══════════════════════════════════════

    async def aggregate_window(self, scope_id: str, window: str, window_start: datetime) -> DataProcessResult:
        try:
            window_secs = TimeWindowParser.parse_seconds(window)
            window_end = window_start + timedelta(seconds=window_secs)
            window_key = TimeWindowParser.get_window_key(window_start, window)

            event_filter = self._op.build_search_filter({
                "scopeId": scope_id,
                "timestampGte": window_start.isoformat(),
                "timestampLte": window_end.isoformat(),
            })
            events = await self._db.query(self._config.events_index, event_filter, self._config.max_batch_size, 0) or []

            counts_by_type: dict[str, int] = {}
            sums_by_type: dict[str, float] = {}
            dim_breakdowns: dict[str, dict[str, int]] = {}

            cfg = await self._load_config(scope_id)
            custom_dims: list[str] = cfg.get("customDimensions", [])

            for evt in events:
                et = evt.get("eventType", "")
                if not et:
                    continue
                counts_by_type[et] = counts_by_type.get(et, 0) + 1
                if "value" in evt and evt["value"] is not None:
                    sums_by_type[et] = sums_by_type.get(et, 0.0) + float(evt["value"])
                for dim in custom_dims:
                    if dim in evt and evt[dim] is not None:
                        dk = f"{et}:{dim}"
                        if dk not in dim_breakdowns:
                            dim_breakdowns[dk] = {}
                        dv = str(evt[dim])
                        dim_breakdowns[dk][dv] = dim_breakdowns[dk].get(dv, 0) + 1

            metric: dict[str, Any] = {
                "metricId": f"{scope_id}:{window}:{window_key}",
                "scopeId": scope_id,
                "windowSize": window,
                "windowStart": window_start.isoformat(),
                "windowEnd": window_end.isoformat(),
                "windowKey": window_key,
                "totalEvents": len(events),
                "countsByType": counts_by_type,
                "sumsByType": sums_by_type,
                "dimensionBreakdowns": dim_breakdowns,
                "aggregatedAt": datetime.now(timezone.utc).isoformat(),
            }
            await self._db.upsert(self._config.metrics_index, metric["metricId"], metric)
            await self._publish_event("MetricAggregated", metric)
            return DataProcessResult.success(metric)
        except Exception as ex:
            return DataProcessResult.error(str(ex))

    async def get_metrics(
        self, scope_id: str, event_type: str | None = None,
        start_date: datetime | None = None, end_date: datetime | None = None,
        dimension: str | None = None, page: int = 0, page_size: int = 100,
    ) -> DataProcessResult:
        try:
            f = self._op.build_search_filter({
                "scopeId": scope_id,
                "eventType": event_type,
                "timestampGte": start_date.isoformat() if start_date else None,
                "timestampLte": end_date.isoformat() if end_date else None,
                "dimension": dimension,
            })
            results = await self._db.query(self._config.metrics_index, f, page_size, page * page_size) or []
            return DataProcessResult.success(results)
        except Exception as ex:
            return DataProcessResult.error(str(ex))

    async def get_time_series(
        self, scope_id: str, metric_name: str, window: str,
        start_date: datetime, end_date: datetime,
    ) -> DataProcessResult:
        try:
            f = self._op.build_search_filter({
                "scopeId": scope_id, "windowSize": window,
                "windowStartGte": start_date.isoformat(),
                "windowStartLte": end_date.isoformat(),
            })
            results = await self._db.query(self._config.metrics_index, f, 1000, 0) or []
            results.sort(key=lambda r: r.get("windowStart", ""))
            series = [
                {
                    "windowStart": r.get("windowStart"),
                    "windowEnd": r.get("windowEnd"),
                    "totalEvents": r.get("totalEvents"),
                    "value": (r.get("countsByType") or {}).get(metric_name),
                    "countsByType": r.get("countsByType"),
                }
                for r in results
            ]
            return DataProcessResult.success(series)
        except Exception as ex:
            return DataProcessResult.error(str(ex))

    async def compact_metrics(self, scope_id: str) -> DataProcessResult:
        try:
            cfg = await self._load_config(scope_id)
            raw_ret = cfg.get("rawRetentionDays", self._config.raw_retention_days)
            hourly_ret = cfg.get("hourlyRetentionDays", self._config.hourly_retention_days)
            compacted = 0

            raw_cutoff = datetime.now(timezone.utc) - timedelta(days=raw_ret)
            rf = self._op.build_search_filter({"scopeId": scope_id, "timestampLte": raw_cutoff.isoformat()})
            old_raw = await self._db.query(self._config.events_index, rf, 1000, 0) or []
            for evt in old_raw:
                if evt.get("eventId"):
                    await self._db.delete(self._config.events_index, evt["eventId"])
                    compacted += 1

            hourly_cutoff = datetime.now(timezone.utc) - timedelta(days=hourly_ret)
            hf = self._op.build_search_filter({"scopeId": scope_id, "windowSize": "1h", "windowStartLte": hourly_cutoff.isoformat()})
            old_h = await self._db.query(self._config.metrics_index, hf, 1000, 0) or []
            for m in old_h:
                if m.get("metricId"):
                    await self._db.delete(self._config.metrics_index, m["metricId"])
                    compacted += 1

            return DataProcessResult.success(compacted)
        except Exception as ex:
            return DataProcessResult.error(str(ex))

    # ═══ ENGAGEMENT SCORING ═══════════════════════════════════════

    async def calculate_engagement(self, scope_id: str, entity_id: str) -> DataProcessResult:
        try:
            cfg = await self._load_config(scope_id)
            weights = {**DEFAULT_WEIGHTS, **(cfg.get("engagementWeights") or {})}

            since = datetime.now(timezone.utc) - timedelta(days=30)
            f = self._op.build_search_filter({
                "scopeId": scope_id, "entityId": entity_id,
                "timestampGte": since.isoformat(),
            })
            events = await self._db.query(self._config.events_index, f, 10000, 0) or []

            signal_counts: dict[str, int] = {}
            total_score = 0.0
            for evt in events:
                signal = (evt.get("action") or evt.get("eventType") or "").lower()
                signal_counts[signal] = signal_counts.get(signal, 0) + 1
                w = weights.get(signal, weights.get("view", 1.0))
                total_score += w

            days = max(1.0, (datetime.now(timezone.utc) - since).total_seconds() / 86400)
            norm = round(total_score / days, 2)

            engagement: dict[str, Any] = {
                "engagementId": f"{scope_id}:{entity_id}",
                "scopeId": scope_id, "entityId": entity_id,
                "totalScore": round(total_score, 2), "normalizedScore": norm,
                "totalEvents": len(events), "signalCounts": signal_counts,
                "periodDays": 30, "calculatedAt": datetime.now(timezone.utc).isoformat(),
            }
            await self._db.upsert(self._config.metrics_index, f"engagement:{scope_id}:{entity_id}", engagement)
            await self._publish_event("EngagementScoreUpdated", engagement)
            return DataProcessResult.success(engagement)
        except Exception as ex:
            return DataProcessResult.error(str(ex))

    async def get_engagement_score(self, scope_id: str, entity_id: str) -> DataProcessResult:
        try:
            doc = await self._db.get_by_id(self._config.metrics_index, f"engagement:{scope_id}:{entity_id}")
            return DataProcessResult.success(doc.get("normalizedScore", 0.0) if doc else 0.0)
        except Exception as ex:
            return DataProcessResult.error(str(ex))

    async def recalculate_all_scores(self, scope_id: str) -> DataProcessResult:
        try:
            since = datetime.now(timezone.utc) - timedelta(days=30)
            f = self._op.build_search_filter({"scopeId": scope_id, "timestampGte": since.isoformat()})
            events = await self._db.query(self._config.events_index, f, 10000, 0) or []
            entity_ids = list({e.get("entityId") for e in events if e.get("entityId")})
            recalc = 0
            for eid in entity_ids:
                r = await self.calculate_engagement(scope_id, eid)
                if r.is_success:
                    recalc += 1
            return DataProcessResult.success(recalc)
        except Exception as ex:
            return DataProcessResult.error(str(ex))

    # ═══ FUNNEL ANALYSIS ══════════════════════════════════════════

    async def track_funnel_step(self, scope_id: str, funnel_id: str, entity_id: str, step_name: str) -> DataProcessResult:
        try:
            fdef = await self._load_funnel_def(scope_id, funnel_id)
            if not fdef:
                return DataProcessResult.error(f"Funnel {funnel_id} not defined for scope {scope_id}")

            steps: list[str] = fdef.get("steps", [])
            if step_name not in steps:
                return DataProcessResult.error(f"Step '{step_name}' not in funnel '{funnel_id}'")
            step_index = steps.index(step_name)
            window_hours = fdef.get("windowHours", 72)

            pid = f"funnel:{scope_id}:{funnel_id}:{entity_id}"
            progress = await self._db.get_by_id(self._config.funnels_index, pid)

            now_iso = datetime.now(timezone.utc).isoformat()
            if not progress:
                progress = {
                    "progressId": pid, "scopeId": scope_id, "funnelId": funnel_id,
                    "entityId": entity_id, "sessionId": str(uuid.uuid4()),
                    "currentStepIndex": step_index, "currentStepName": step_name,
                    "completedSteps": [step_name],
                    "stepTimestamps": {step_name: now_iso},
                    "startedAt": now_iso, "updatedAt": now_iso,
                    "completed": step_index == len(steps) - 1, "timedOut": False,
                }
            else:
                started = datetime.fromisoformat(progress.get("startedAt", now_iso).replace("Z", "+00:00"))
                hours_since = (datetime.now(timezone.utc) - started).total_seconds() / 3600
                if hours_since > window_hours:
                    progress["sessionId"] = str(uuid.uuid4())
                    progress["completedSteps"] = [step_name]
                    progress["stepTimestamps"] = {step_name: now_iso}
                    progress["startedAt"] = now_iso
                else:
                    cs = progress.get("completedSteps", [])
                    if step_name not in cs:
                        cs.append(step_name)
                    progress["completedSteps"] = cs
                    ts = progress.get("stepTimestamps", {})
                    ts[step_name] = now_iso
                    progress["stepTimestamps"] = ts

                progress["currentStepIndex"] = step_index
                progress["currentStepName"] = step_name
                progress["updatedAt"] = now_iso
                progress["completed"] = step_index == len(steps) - 1

            await self._db.upsert(self._config.funnels_index, pid, progress)
            await self._publish_event("FunnelStepCompleted", progress)
            if progress.get("completed"):
                await self._publish_event("FunnelCompleted", progress)
            return DataProcessResult.success(progress)
        except Exception as ex:
            return DataProcessResult.error(str(ex))

    async def get_funnel_analysis(
        self, scope_id: str, funnel_id: str,
        start_date: datetime | None = None, end_date: datetime | None = None,
    ) -> DataProcessResult:
        try:
            fdef = await self._load_funnel_def(scope_id, funnel_id)
            if not fdef:
                return DataProcessResult.error(f"Funnel {funnel_id} not defined")
            steps: list[str] = fdef.get("steps", [])

            f = self._op.build_search_filter({
                "scopeId": scope_id, "funnelId": funnel_id,
                "startedAtGte": start_date.isoformat() if start_date else None,
                "startedAtLte": end_date.isoformat() if end_date else None,
            })
            all_p = await self._db.query(self._config.funnels_index, f, 10000, 0) or []

            step_results = []
            for i, sn in enumerate(steps):
                reached = sum(1 for p in all_p if sn in (p.get("completedSteps") or []))
                prev = len(all_p) if i == 0 else sum(
                    1 for p in all_p if steps[i-1] in (p.get("completedSteps") or []))
                rate = round(reached / prev * 100, 1) if prev > 0 else 0.0
                step_results.append({
                    "stepName": sn, "stepIndex": i, "enteredCount": prev,
                    "completedCount": reached, "completionRate": rate,
                    "dropOffRate": round(100 - rate, 1),
                })

            total_completed = sum(1 for p in all_p if p.get("completed"))
            overall = round(total_completed / len(all_p) * 100, 1) if all_p else 0.0

            return DataProcessResult.success({
                "funnelId": funnel_id, "scopeId": scope_id,
                "totalSessions": len(all_p), "totalCompleted": total_completed,
                "overallCompletionRate": overall, "steps": step_results,
                "analyzedAt": datetime.now(timezone.utc).isoformat(),
            })
        except Exception as ex:
            return DataProcessResult.error(str(ex))

    async def get_entity_funnel_progress(self, scope_id: str, funnel_id: str, entity_id: str) -> DataProcessResult:
        try:
            doc = await self._db.get_by_id(
                self._config.funnels_index, f"funnel:{scope_id}:{funnel_id}:{entity_id}")
            return DataProcessResult.success(
                doc or {"funnelId": funnel_id, "entityId": entity_id, "status": "not_started", "completedSteps": []})
        except Exception as ex:
            return DataProcessResult.error(str(ex))

    # ═══ CAMPAIGN METRICS ═════════════════════════════════════════

    async def track_campaign_event(self, campaign_event: dict[str, Any]) -> DataProcessResult:
        try:
            doc = self._op.parse_object_alternative(campaign_event)
            if not doc.get("campaignId") or not doc.get("scopeId"):
                return DataProcessResult.error("Missing: campaignId, scopeId")
            doc.setdefault("eventId", str(uuid.uuid4()))
            doc["eventType"] = f"campaign_{doc.get('action', 'unknown')}"
            doc.setdefault("timestamp", datetime.now(timezone.utc).isoformat())

            await self._db.upsert(self._config.events_index, doc["eventId"], doc)

            mid = f"campaign:{doc['scopeId']}:{doc['campaignId']}"
            existing = await self._db.get_by_id(self._config.metrics_index, mid)
            if not existing:
                existing = {"metricId": mid, "scopeId": doc["scopeId"], "campaignId": doc["campaignId"],
                            "sent": 0, "delivered": 0, "opened": 0, "clicked": 0, "converted": 0, "unsubscribed": 0}

            action = (doc.get("action") or "").lower()
            if action in existing:
                existing[action] = existing.get(action, 0) + 1
            existing["updatedAt"] = datetime.now(timezone.utc).isoformat()

            sent = existing.get("sent", 0)
            if sent > 0:
                existing["openRate"] = round(existing.get("opened", 0) / sent * 100, 2)
                existing["clickRate"] = round(existing.get("clicked", 0) / sent * 100, 2)
                existing["conversionRate"] = round(existing.get("converted", 0) / sent * 100, 2)

            await self._db.upsert(self._config.metrics_index, mid, existing)
            await self._publish_event("CampaignMetricsUpdated", existing)
            return DataProcessResult.success(existing)
        except Exception as ex:
            return DataProcessResult.error(str(ex))

    async def get_campaign_metrics(self, scope_id: str, campaign_id: str) -> DataProcessResult:
        try:
            doc = await self._db.get_by_id(self._config.metrics_index, f"campaign:{scope_id}:{campaign_id}")
            return DataProcessResult.success(doc or {"campaignId": campaign_id, "scopeId": scope_id, "status": "no_data"})
        except Exception as ex:
            return DataProcessResult.error(str(ex))

    # ═══ CONFIGURATION (FREEDOM) ══════════════════════════════════

    async def get_config(self, scope_id: str) -> DataProcessResult:
        try:
            return DataProcessResult.success(await self._load_config(scope_id))
        except Exception as ex:
            return DataProcessResult.error(str(ex))

    async def update_config(self, scope_id: str, config: dict[str, Any]) -> DataProcessResult:
        try:
            doc = self._op.parse_object_alternative(config)
            doc["configId"] = f"analytics-config:{scope_id}"
            doc["scopeId"] = scope_id
            doc["updatedAt"] = datetime.now(timezone.utc).isoformat()
            await self._db.upsert(self._config.config_index, doc["configId"], doc)
            return DataProcessResult.success(doc)
        except Exception as ex:
            return DataProcessResult.error(str(ex))

    async def define_funnel(self, scope_id: str, funnel_def: dict[str, Any]) -> DataProcessResult:
        try:
            doc = self._op.parse_object_alternative(funnel_def)
            if not doc.get("funnelId") or not doc.get("steps"):
                return DataProcessResult.error("Missing: funnelId, steps")
            doc["scopeId"] = scope_id
            doc["type"] = "funnel_definition"
            doc["updatedAt"] = datetime.now(timezone.utc).isoformat()
            await self._db.upsert(self._config.config_index, f"funnel-def:{scope_id}:{doc['funnelId']}", doc)
            return DataProcessResult.success(doc)
        except Exception as ex:
            return DataProcessResult.error(str(ex))

    async def define_alert(self, scope_id: str, alert_def: dict[str, Any]) -> DataProcessResult:
        try:
            doc = self._op.parse_object_alternative(alert_def)
            if not doc.get("alertId") or not doc.get("metric") or "threshold" not in doc:
                return DataProcessResult.error("Missing: alertId, metric, threshold")
            doc["scopeId"] = scope_id
            doc["type"] = "alert_definition"
            doc["updatedAt"] = datetime.now(timezone.utc).isoformat()
            await self._db.upsert(self._config.config_index, f"alert-def:{scope_id}:{doc['alertId']}", doc)
            return DataProcessResult.success(doc)
        except Exception as ex:
            return DataProcessResult.error(str(ex))

    # ═══ PRIVATE HELPERS ══════════════════════════════════════════

    async def _load_config(self, scope_id: str) -> dict[str, Any]:
        try:
            doc = await self._db.get_by_id(self._config.config_index, f"analytics-config:{scope_id}")
            return doc or self._default_config(scope_id)
        except Exception:
            return self._default_config(scope_id)

    def _default_config(self, scope_id: str) -> dict[str, Any]:
        return {
            "configId": f"analytics-config:{scope_id}", "scopeId": scope_id,
            "aggregationWindows": self._config.default_aggregation_windows,
            "rawRetentionDays": self._config.raw_retention_days,
            "hourlyRetentionDays": self._config.hourly_retention_days,
            "dailyRetentionDays": self._config.daily_retention_days,
            "engagementWeights": {**DEFAULT_WEIGHTS},
            "customDimensions": ["platform", "region", "userTier"],
            "alerts": [],
        }

    async def _load_funnel_def(self, scope_id: str, funnel_id: str) -> dict[str, Any] | None:
        try:
            return await self._db.get_by_id(self._config.config_index, f"funnel-def:{scope_id}:{funnel_id}")
        except Exception:
            return None

    async def _publish_event(self, event_type: str, data: dict) -> None:
        try:
            await self._queue.publish("analytics-events", {
                "eventType": event_type, "data": data,
                "publishedAt": datetime.now(timezone.utc).isoformat(),
            })
        except Exception:
            pass  # non-critical
