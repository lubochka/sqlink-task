// XIIGen Analytics Service — Skill 48 | Rust Alternative
// Event tracking, metric aggregation, engagement scoring, funnel analysis, campaign metrics
// Genie DNA: DNA-1 (HashMap<String,Value>), DNA-2 (build_search_filter), DNA-5 (DataProcessResult)

use std::collections::HashMap;
use std::time::{Duration, SystemTime, UNIX_EPOCH};
use serde_json::Value;
use uuid::Uuid;

// ─── Configuration ──────────────────────────────────────────────────────────
#[derive(Clone)]
pub struct AnalyticsConfig {
    pub events_index: String,
    pub metrics_index: String,
    pub funnels_index: String,
    pub config_index: String,
    pub counter_prefix: String,
    pub default_page_size: usize,
    pub max_batch_size: usize,
    pub raw_retention_days: u64,
    pub hourly_retention_days: u64,
    pub daily_retention_days: u64,
    pub default_aggregation_windows: Vec<String>,
}

impl Default for AnalyticsConfig {
    fn default() -> Self {
        Self {
            events_index: "analytics-events".into(),
            metrics_index: "analytics-metrics".into(),
            funnels_index: "analytics-funnels".into(),
            config_index: "analytics-config".into(),
            counter_prefix: "analytics:counter:".into(),
            default_page_size: 100,
            max_batch_size: 1000,
            raw_retention_days: 30,
            hourly_retention_days: 90,
            daily_retention_days: 365,
            default_aggregation_windows: vec!["1h".into(), "1d".into(), "7d".into(), "30d".into()],
        }
    }
}

// ─── DataProcessResult ──────────────────────────────────────────────────────
#[derive(Debug, Clone)]
pub struct DataProcessResult<T> {
    pub is_success: bool,
    pub data: Option<T>,
    pub error_message: Option<String>,
}

impl<T> DataProcessResult<T> {
    pub fn success(data: T) -> Self {
        Self { is_success: true, data: Some(data), error_message: None }
    }
    pub fn error(msg: &str) -> Self {
        Self { is_success: false, data: None, error_message: Some(msg.to_string()) }
    }
}

// ─── Engagement Weights ─────────────────────────────────────────────────────
pub struct EngagementWeights {
    pub view: f64,
    pub click: f64,
    pub like: f64,
    pub comment: f64,
    pub share: f64,
    pub create: f64,
    pub purchase: f64,
}

impl Default for EngagementWeights {
    fn default() -> Self {
        Self { view: 1.0, click: 2.0, like: 3.0, comment: 5.0, share: 7.0, create: 10.0, purchase: 15.0 }
    }
}

impl EngagementWeights {
    pub fn get_weight(&self, signal: &str) -> f64 {
        match signal.to_lowercase().as_str() {
            "view" | "page_view" => self.view,
            "click" => self.click,
            "like" => self.like,
            "comment" => self.comment,
            "share" => self.share,
            "create" | "post_create" => self.create,
            "purchase" | "payment" => self.purchase,
            _ => self.view,
        }
    }
}

// ─── Time Window Parser ─────────────────────────────────────────────────────
pub struct TimeWindowParser;

impl TimeWindowParser {
    pub fn parse_seconds(window: &str) -> u64 {
        if window.is_empty() { return 3600; }
        let (num_str, unit) = window.split_at(window.len() - 1);
        let value: u64 = num_str.parse().unwrap_or(1);
        match unit {
            "h" => value * 3600,
            "d" => value * 86400,
            "w" => value * 604800,
            "m" => value * 2592000,
            _ => value * 3600,
        }
    }

    pub fn get_window_key(timestamp_iso: &str, window: &str) -> String {
        // Simplified: extract date parts from ISO string "2025-01-15T10:30:00Z"
        let secs = Self::parse_seconds(window);
        if timestamp_iso.len() < 10 { return "unknown".into(); }
        if secs <= 3600 {
            // YYYY-MM-DD-HH
            let date = &timestamp_iso[..10];
            let hour = if timestamp_iso.len() >= 13 { &timestamp_iso[11..13] } else { "00" };
            format!("{}-{}", date, hour)
        } else if secs <= 86400 {
            timestamp_iso[..10].to_string()
        } else if secs <= 604800 {
            format!("W-{}", &timestamp_iso[..10])
        } else {
            timestamp_iso[..7].to_string()
        }
    }
}

// ─── Service Traits ─────────────────────────────────────────────────────────
type Doc = HashMap<String, Value>;

pub trait IDatabaseService: Send + Sync {
    fn upsert(&self, index: &str, id: &str, doc: &Doc) -> Result<(), String>;
    fn get_by_id(&self, index: &str, id: &str) -> Result<Option<Doc>, String>;
    fn query(&self, index: &str, filter: &Doc, size: usize, offset: usize) -> Result<Vec<Doc>, String>;
    fn delete(&self, index: &str, id: &str) -> Result<(), String>;
}

pub trait IQueueService: Send + Sync {
    fn publish(&self, channel: &str, data: &Doc) -> Result<(), String>;
    fn increment(&self, key: &str, delta: i64) -> Result<i64, String>;
    fn get_counter(&self, key: &str) -> Result<i64, String>;
}

pub trait IObjectProcessor: Send + Sync {
    fn parse_object_alternative(&self, obj: &Value) -> Doc;
    fn build_search_filter(&self, criteria: &Doc) -> Doc;
}

// ─── Helper Functions ───────────────────────────────────────────────────────
fn now_iso() -> String {
    let dur = SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default();
    let secs = dur.as_secs();
    let days = secs / 86400;
    let rem = secs % 86400;
    let hours = rem / 3600;
    let mins = (rem % 3600) / 60;
    let s = rem % 60;
    // Approximate date calculation (not accounting for leap years precisely)
    let year = 1970 + (days / 365);
    format!("{:04}-01-01T{:02}:{:02}:{:02}Z", year, hours, mins, s)
}

fn str_val(doc: &Doc, key: &str) -> String {
    doc.get(key)
        .and_then(|v| v.as_str().map(|s| s.to_string()).or_else(|| Some(v.to_string())))
        .unwrap_or_default()
        .trim_matches('"')
        .to_string()
}

fn f64_val(doc: &Doc, key: &str) -> f64 {
    doc.get(key).and_then(|v| v.as_f64()).unwrap_or(0.0)
}

fn i64_val(doc: &Doc, key: &str) -> i64 {
    doc.get(key).and_then(|v| v.as_i64()).unwrap_or(0)
}

fn string_list(doc: &Doc, key: &str) -> Vec<String> {
    doc.get(key)
        .and_then(|v| v.as_array())
        .map(|arr| arr.iter().filter_map(|v| v.as_str().map(String::from)).collect())
        .unwrap_or_default()
}

fn to_value(s: &str) -> Value { Value::String(s.to_string()) }
fn to_num(n: f64) -> Value { serde_json::Number::from_f64(n).map(Value::Number).unwrap_or(Value::Null) }
fn to_int(n: i64) -> Value { Value::Number(serde_json::Number::from(n)) }

// ─── Analytics Service ──────────────────────────────────────────────────────
pub struct AnalyticsService<D: IDatabaseService, Q: IQueueService, O: IObjectProcessor> {
    db: D,
    queue: Q,
    op: O,
    config: AnalyticsConfig,
}

impl<D: IDatabaseService, Q: IQueueService, O: IObjectProcessor> AnalyticsService<D, Q, O> {
    pub fn new(db: D, queue: Q, op: O) -> Self {
        Self { db, queue, op, config: AnalyticsConfig::default() }
    }

    pub fn with_config(db: D, queue: Q, op: O, config: AnalyticsConfig) -> Self {
        Self { db, queue, op, config }
    }

    // ═══ EVENT COLLECTION ═══════════════════════════════════════════════════

    pub fn track_event(&self, event_data: &Value) -> DataProcessResult<Doc> {
        let mut doc = self.op.parse_object_alternative(event_data);
        if str_val(&doc, "scopeId").is_empty() {
            return DataProcessResult::error("Missing required field: scopeId (DNA-SCOPE)");
        }
        if str_val(&doc, "eventType").is_empty() {
            return DataProcessResult::error("Missing required field: eventType");
        }

        let event_id = doc.entry("eventId".into())
            .or_insert_with(|| to_value(&Uuid::new_v4().to_string()))
            .clone();
        let now = now_iso();
        doc.entry("timestamp".into()).or_insert_with(|| to_value(&now));
        doc.insert("trackedAt".into(), to_value(&now));

        let id_str = event_id.as_str().unwrap_or("").to_string();
        match self.db.upsert(&self.config.events_index, &id_str, &doc) {
            Ok(_) => {
                self.publish_event("AnalyticsEventTracked", &doc);
                DataProcessResult::success(doc)
            }
            Err(e) => DataProcessResult::error(&e),
        }
    }

    pub fn track_batch(&self, events: &[Value]) -> DataProcessResult<usize> {
        if events.len() > self.config.max_batch_size {
            return DataProcessResult::error(&format!(
                "Batch size {} exceeds max {}", events.len(), self.config.max_batch_size
            ));
        }
        let mut ok = 0usize;
        for evt in events {
            if self.track_event(evt).is_success { ok += 1; }
        }
        DataProcessResult::success(ok)
    }

    pub fn increment_counter(&self, scope_id: &str, name: &str, delta: i64) -> DataProcessResult<i64> {
        let key = format!("{}{}:{}", self.config.counter_prefix, scope_id, name);
        match self.queue.increment(&key, delta) {
            Ok(val) => DataProcessResult::success(val),
            Err(e) => DataProcessResult::error(&e),
        }
    }

    pub fn get_counter(&self, scope_id: &str, name: &str) -> DataProcessResult<i64> {
        let key = format!("{}{}:{}", self.config.counter_prefix, scope_id, name);
        match self.queue.get_counter(&key) {
            Ok(val) => DataProcessResult::success(val),
            Err(e) => DataProcessResult::error(&e),
        }
    }

    // ═══ METRIC AGGREGATION ═════════════════════════════════════════════════

    pub fn aggregate_window(&self, scope_id: &str, window: &str, window_start: &str) -> DataProcessResult<Doc> {
        let window_secs = TimeWindowParser::parse_seconds(window);
        let window_key = TimeWindowParser::get_window_key(window_start, window);

        let mut criteria: Doc = HashMap::new();
        criteria.insert("scopeId".into(), to_value(scope_id));
        criteria.insert("timestampGte".into(), to_value(window_start));
        // window_end approximation — in production, add window_secs to window_start
        criteria.insert("timestampLte".into(), to_value(window_start)); // simplified

        let filter = self.op.build_search_filter(&criteria);
        let events = self.db.query(&self.config.events_index, &filter, self.config.max_batch_size, 0)
            .unwrap_or_default();

        let cfg = self.load_config(scope_id);
        let custom_dims = string_list(&cfg, "customDimensions");

        let mut counts_by_type: HashMap<String, i64> = HashMap::new();
        let mut sums_by_type: HashMap<String, f64> = HashMap::new();
        let mut dim_breakdowns: HashMap<String, HashMap<String, i64>> = HashMap::new();

        for evt in &events {
            let et = str_val(evt, "eventType");
            if et.is_empty() { continue; }
            *counts_by_type.entry(et.clone()).or_insert(0) += 1;
            if let Some(v) = evt.get("value").and_then(|v| v.as_f64()) {
                *sums_by_type.entry(et.clone()).or_insert(0.0) += v;
            }
            for dim in &custom_dims {
                if let Some(dv) = evt.get(dim.as_str()).and_then(|v| v.as_str()) {
                    let dk = format!("{}:{}", et, dim);
                    *dim_breakdowns.entry(dk).or_default().entry(dv.to_string()).or_insert(0) += 1;
                }
            }
        }

        let metric_id = format!("{}:{}:{}", scope_id, window, window_key);
        let now = now_iso();
        let mut metric: Doc = HashMap::new();
        metric.insert("metricId".into(), to_value(&metric_id));
        metric.insert("scopeId".into(), to_value(scope_id));
        metric.insert("windowSize".into(), to_value(window));
        metric.insert("windowStart".into(), to_value(window_start));
        metric.insert("windowKey".into(), to_value(&window_key));
        metric.insert("totalEvents".into(), to_int(events.len() as i64));
        metric.insert("countsByType".into(), serde_json::to_value(&counts_by_type).unwrap_or(Value::Null));
        metric.insert("sumsByType".into(), serde_json::to_value(&sums_by_type).unwrap_or(Value::Null));
        metric.insert("dimensionBreakdowns".into(), serde_json::to_value(&dim_breakdowns).unwrap_or(Value::Null));
        metric.insert("aggregatedAt".into(), to_value(&now));

        match self.db.upsert(&self.config.metrics_index, &metric_id, &metric) {
            Ok(_) => {
                self.publish_event("MetricAggregated", &metric);
                DataProcessResult::success(metric)
            }
            Err(e) => DataProcessResult::error(&e),
        }
    }

    pub fn get_metrics(
        &self, scope_id: &str, event_type: Option<&str>,
        start_date: Option<&str>, end_date: Option<&str>,
        dimension: Option<&str>, page: usize, page_size: usize,
    ) -> DataProcessResult<Vec<Doc>> {
        let mut criteria: Doc = HashMap::new();
        criteria.insert("scopeId".into(), to_value(scope_id));
        if let Some(et) = event_type { criteria.insert("eventType".into(), to_value(et)); }
        if let Some(s) = start_date { criteria.insert("timestampGte".into(), to_value(s)); }
        if let Some(e) = end_date { criteria.insert("timestampLte".into(), to_value(e)); }
        if let Some(d) = dimension { criteria.insert("dimension".into(), to_value(d)); }

        let filter = self.op.build_search_filter(&criteria);
        match self.db.query(&self.config.metrics_index, &filter, page_size, page * page_size) {
            Ok(results) => DataProcessResult::success(results),
            Err(e) => DataProcessResult::error(&e),
        }
    }

    pub fn get_time_series(
        &self, scope_id: &str, metric_name: &str, window: &str,
        start_date: &str, end_date: &str,
    ) -> DataProcessResult<Vec<Doc>> {
        let mut criteria: Doc = HashMap::new();
        criteria.insert("scopeId".into(), to_value(scope_id));
        criteria.insert("windowSize".into(), to_value(window));
        criteria.insert("windowStartGte".into(), to_value(start_date));
        criteria.insert("windowStartLte".into(), to_value(end_date));

        let filter = self.op.build_search_filter(&criteria);
        match self.db.query(&self.config.metrics_index, &filter, 1000, 0) {
            Ok(mut results) => {
                results.sort_by(|a, b| str_val(a, "windowStart").cmp(&str_val(b, "windowStart")));
                let series: Vec<Doc> = results.iter().map(|r| {
                    let mut point: Doc = HashMap::new();
                    point.insert("windowStart".into(), r.get("windowStart").cloned().unwrap_or(Value::Null));
                    point.insert("windowEnd".into(), r.get("windowEnd").cloned().unwrap_or(Value::Null));
                    point.insert("totalEvents".into(), r.get("totalEvents").cloned().unwrap_or(Value::Null));
                    point.insert("countsByType".into(), r.get("countsByType").cloned().unwrap_or(Value::Null));
                    point
                }).collect();
                DataProcessResult::success(series)
            }
            Err(e) => DataProcessResult::error(&e),
        }
    }

    // ═══ ENGAGEMENT SCORING ═════════════════════════════════════════════════

    pub fn calculate_engagement(&self, scope_id: &str, entity_id: &str) -> DataProcessResult<Doc> {
        let cfg = self.load_config(scope_id);
        let weights = self.load_weights(&cfg);

        let mut criteria: Doc = HashMap::new();
        criteria.insert("scopeId".into(), to_value(scope_id));
        criteria.insert("entityId".into(), to_value(entity_id));
        // 30-day window — in production, compute actual ISO date
        let filter = self.op.build_search_filter(&criteria);
        let events = self.db.query(&self.config.events_index, &filter, 10000, 0)
            .unwrap_or_default();

        let mut signal_counts: HashMap<String, i64> = HashMap::new();
        let mut total_score: f64 = 0.0;

        for evt in &events {
            let action = str_val(evt, "action");
            let signal = if action.is_empty() { str_val(evt, "eventType") } else { action };
            *signal_counts.entry(signal.to_lowercase()).or_insert(0) += 1;
            total_score += weights.get_weight(&signal);
        }

        let days: f64 = 30.0_f64.max(1.0);
        let norm = (total_score / days * 100.0).round() / 100.0;

        let engagement_id = format!("{}:{}", scope_id, entity_id);
        let now = now_iso();
        let mut engagement: Doc = HashMap::new();
        engagement.insert("engagementId".into(), to_value(&engagement_id));
        engagement.insert("scopeId".into(), to_value(scope_id));
        engagement.insert("entityId".into(), to_value(entity_id));
        engagement.insert("totalScore".into(), to_num((total_score * 100.0).round() / 100.0));
        engagement.insert("normalizedScore".into(), to_num(norm));
        engagement.insert("totalEvents".into(), to_int(events.len() as i64));
        engagement.insert("signalCounts".into(), serde_json::to_value(&signal_counts).unwrap_or(Value::Null));
        engagement.insert("periodDays".into(), to_int(30));
        engagement.insert("calculatedAt".into(), to_value(&now));

        let store_id = format!("engagement:{}:{}", scope_id, entity_id);
        let _ = self.db.upsert(&self.config.metrics_index, &store_id, &engagement);
        self.publish_event("EngagementScoreUpdated", &engagement);
        DataProcessResult::success(engagement)
    }

    pub fn get_engagement_score(&self, scope_id: &str, entity_id: &str) -> DataProcessResult<f64> {
        let id = format!("engagement:{}:{}", scope_id, entity_id);
        match self.db.get_by_id(&self.config.metrics_index, &id) {
            Ok(Some(doc)) => DataProcessResult::success(f64_val(&doc, "normalizedScore")),
            Ok(None) => DataProcessResult::success(0.0),
            Err(e) => DataProcessResult::error(&e),
        }
    }

    pub fn recalculate_all_scores(&self, scope_id: &str) -> DataProcessResult<usize> {
        let mut criteria: Doc = HashMap::new();
        criteria.insert("scopeId".into(), to_value(scope_id));
        let filter = self.op.build_search_filter(&criteria);
        let events = self.db.query(&self.config.events_index, &filter, 10000, 0)
            .unwrap_or_default();

        let mut entity_ids: Vec<String> = events.iter()
            .map(|e| str_val(e, "entityId"))
            .filter(|s| !s.is_empty())
            .collect();
        entity_ids.sort();
        entity_ids.dedup();

        let mut count = 0usize;
        for eid in &entity_ids {
            if self.calculate_engagement(scope_id, eid).is_success { count += 1; }
        }
        DataProcessResult::success(count)
    }

    // ═══ FUNNEL ANALYSIS ════════════════════════════════════════════════════

    pub fn track_funnel_step(
        &self, scope_id: &str, funnel_id: &str, entity_id: &str, step_name: &str,
    ) -> DataProcessResult<Doc> {
        let fdef = match self.load_funnel_def(scope_id, funnel_id) {
            Some(f) => f,
            None => return DataProcessResult::error(&format!("Funnel {} not defined for scope {}", funnel_id, scope_id)),
        };

        let steps = string_list(&fdef, "steps");
        let step_index = match steps.iter().position(|s| s == step_name) {
            Some(i) => i,
            None => return DataProcessResult::error(&format!("Step '{}' not in funnel '{}'", step_name, funnel_id)),
        };
        let _window_hours = i64_val(&fdef, "windowHours").max(72);

        let pid = format!("funnel:{}:{}:{}", scope_id, funnel_id, entity_id);
        let now = now_iso();

        let mut progress = match self.db.get_by_id(&self.config.funnels_index, &pid) {
            Ok(Some(existing)) => {
                let mut p = existing;
                // Simplified: always update steps (timeout check omitted for brevity)
                let mut cs = string_list(&p, "completedSteps");
                if !cs.contains(&step_name.to_string()) { cs.push(step_name.to_string()); }
                p.insert("completedSteps".into(), serde_json::to_value(&cs).unwrap_or(Value::Null));
                p.insert("currentStepIndex".into(), to_int(step_index as i64));
                p.insert("currentStepName".into(), to_value(step_name));
                p.insert("updatedAt".into(), to_value(&now));
                p.insert("completed".into(), Value::Bool(step_index == steps.len() - 1));
                p
            }
            _ => {
                let mut p: Doc = HashMap::new();
                p.insert("progressId".into(), to_value(&pid));
                p.insert("scopeId".into(), to_value(scope_id));
                p.insert("funnelId".into(), to_value(funnel_id));
                p.insert("entityId".into(), to_value(entity_id));
                p.insert("sessionId".into(), to_value(&Uuid::new_v4().to_string()));
                p.insert("currentStepIndex".into(), to_int(step_index as i64));
                p.insert("currentStepName".into(), to_value(step_name));
                p.insert("completedSteps".into(), serde_json::to_value(vec![step_name]).unwrap_or(Value::Null));
                let mut ts: HashMap<String, String> = HashMap::new();
                ts.insert(step_name.to_string(), now.clone());
                p.insert("stepTimestamps".into(), serde_json::to_value(&ts).unwrap_or(Value::Null));
                p.insert("startedAt".into(), to_value(&now));
                p.insert("updatedAt".into(), to_value(&now));
                p.insert("completed".into(), Value::Bool(step_index == steps.len() - 1));
                p.insert("timedOut".into(), Value::Bool(false));
                p
            }
        };

        let _ = self.db.upsert(&self.config.funnels_index, &pid, &progress);
        self.publish_event("FunnelStepCompleted", &progress);
        if progress.get("completed") == Some(&Value::Bool(true)) {
            self.publish_event("FunnelCompleted", &progress);
        }
        DataProcessResult::success(progress)
    }

    pub fn get_funnel_analysis(
        &self, scope_id: &str, funnel_id: &str,
        start_date: Option<&str>, end_date: Option<&str>,
    ) -> DataProcessResult<Doc> {
        let fdef = match self.load_funnel_def(scope_id, funnel_id) {
            Some(f) => f,
            None => return DataProcessResult::error(&format!("Funnel {} not defined", funnel_id)),
        };
        let steps = string_list(&fdef, "steps");

        let mut criteria: Doc = HashMap::new();
        criteria.insert("scopeId".into(), to_value(scope_id));
        criteria.insert("funnelId".into(), to_value(funnel_id));
        if let Some(s) = start_date { criteria.insert("startedAtGte".into(), to_value(s)); }
        if let Some(e) = end_date { criteria.insert("startedAtLte".into(), to_value(e)); }

        let filter = self.op.build_search_filter(&criteria);
        let all_p = self.db.query(&self.config.funnels_index, &filter, 10000, 0).unwrap_or_default();

        let mut step_results: Vec<Value> = Vec::new();
        for (i, sn) in steps.iter().enumerate() {
            let reached = all_p.iter().filter(|p| string_list(p, "completedSteps").contains(sn)).count();
            let prev = if i == 0 { all_p.len() } else {
                all_p.iter().filter(|p| string_list(p, "completedSteps").contains(&steps[i - 1])).count()
            };
            let rate = if prev > 0 { (reached as f64 / prev as f64 * 1000.0).round() / 10.0 } else { 0.0 };
            let mut step: Doc = HashMap::new();
            step.insert("stepName".into(), to_value(sn));
            step.insert("stepIndex".into(), to_int(i as i64));
            step.insert("enteredCount".into(), to_int(prev as i64));
            step.insert("completedCount".into(), to_int(reached as i64));
            step.insert("completionRate".into(), to_num(rate));
            step.insert("dropOffRate".into(), to_num(((100.0 - rate) * 10.0).round() / 10.0));
            step_results.push(serde_json::to_value(step).unwrap_or(Value::Null));
        }

        let total_completed = all_p.iter().filter(|p| p.get("completed") == Some(&Value::Bool(true))).count();
        let overall = if !all_p.is_empty() {
            (total_completed as f64 / all_p.len() as f64 * 1000.0).round() / 10.0
        } else { 0.0 };

        let mut result: Doc = HashMap::new();
        result.insert("funnelId".into(), to_value(funnel_id));
        result.insert("scopeId".into(), to_value(scope_id));
        result.insert("totalSessions".into(), to_int(all_p.len() as i64));
        result.insert("totalCompleted".into(), to_int(total_completed as i64));
        result.insert("overallCompletionRate".into(), to_num(overall));
        result.insert("steps".into(), Value::Array(step_results));
        result.insert("analyzedAt".into(), to_value(&now_iso()));
        DataProcessResult::success(result)
    }

    pub fn get_entity_funnel_progress(
        &self, scope_id: &str, funnel_id: &str, entity_id: &str,
    ) -> DataProcessResult<Doc> {
        let id = format!("funnel:{}:{}:{}", scope_id, funnel_id, entity_id);
        match self.db.get_by_id(&self.config.funnels_index, &id) {
            Ok(Some(doc)) => DataProcessResult::success(doc),
            Ok(None) => {
                let mut r: Doc = HashMap::new();
                r.insert("funnelId".into(), to_value(funnel_id));
                r.insert("entityId".into(), to_value(entity_id));
                r.insert("status".into(), to_value("not_started"));
                r.insert("completedSteps".into(), Value::Array(vec![]));
                DataProcessResult::success(r)
            }
            Err(e) => DataProcessResult::error(&e),
        }
    }

    // ═══ CAMPAIGN METRICS ═══════════════════════════════════════════════════

    pub fn track_campaign_event(&self, campaign_event: &Value) -> DataProcessResult<Doc> {
        let mut doc = self.op.parse_object_alternative(campaign_event);
        let scope_id = str_val(&doc, "scopeId");
        let campaign_id = str_val(&doc, "campaignId");
        if scope_id.is_empty() || campaign_id.is_empty() {
            return DataProcessResult::error("Missing: campaignId, scopeId");
        }

        let event_id = Uuid::new_v4().to_string();
        doc.entry("eventId".into()).or_insert_with(|| to_value(&event_id));
        let action = str_val(&doc, "action");
        doc.insert("eventType".into(), to_value(&format!("campaign_{}", action)));
        doc.entry("timestamp".into()).or_insert_with(|| to_value(&now_iso()));
        let eid = str_val(&doc, "eventId");
        let _ = self.db.upsert(&self.config.events_index, &eid, &doc);

        let mid = format!("campaign:{}:{}", scope_id, campaign_id);
        let mut existing = self.db.get_by_id(&self.config.metrics_index, &mid)
            .ok().flatten()
            .unwrap_or_else(|| {
                let mut m: Doc = HashMap::new();
                m.insert("metricId".into(), to_value(&mid));
                m.insert("scopeId".into(), to_value(&scope_id));
                m.insert("campaignId".into(), to_value(&campaign_id));
                for k in &["sent", "delivered", "opened", "clicked", "converted", "unsubscribed"] {
                    m.insert(k.to_string(), to_int(0));
                }
                m
            });

        let act = action.to_lowercase();
        if existing.contains_key(&act) {
            let prev = i64_val(&existing, &act);
            existing.insert(act.clone(), to_int(prev + 1));
        }
        existing.insert("updatedAt".into(), to_value(&now_iso()));

        let sent = i64_val(&existing, "sent");
        if sent > 0 {
            let opened = i64_val(&existing, "opened");
            let clicked = i64_val(&existing, "clicked");
            let converted = i64_val(&existing, "converted");
            existing.insert("openRate".into(), to_num((opened as f64 / sent as f64 * 10000.0).round() / 100.0));
            existing.insert("clickRate".into(), to_num((clicked as f64 / sent as f64 * 10000.0).round() / 100.0));
            existing.insert("conversionRate".into(), to_num((converted as f64 / sent as f64 * 10000.0).round() / 100.0));
        }

        let _ = self.db.upsert(&self.config.metrics_index, &mid, &existing);
        self.publish_event("CampaignMetricsUpdated", &existing);
        DataProcessResult::success(existing)
    }

    pub fn get_campaign_metrics(&self, scope_id: &str, campaign_id: &str) -> DataProcessResult<Doc> {
        let mid = format!("campaign:{}:{}", scope_id, campaign_id);
        match self.db.get_by_id(&self.config.metrics_index, &mid) {
            Ok(Some(doc)) => DataProcessResult::success(doc),
            Ok(None) => {
                let mut r: Doc = HashMap::new();
                r.insert("campaignId".into(), to_value(campaign_id));
                r.insert("scopeId".into(), to_value(scope_id));
                r.insert("status".into(), to_value("no_data"));
                DataProcessResult::success(r)
            }
            Err(e) => DataProcessResult::error(&e),
        }
    }

    // ═══ CONFIGURATION (FREEDOM) ════════════════════════════════════════════

    pub fn get_config(&self, scope_id: &str) -> DataProcessResult<Doc> {
        DataProcessResult::success(self.load_config(scope_id))
    }

    pub fn update_config(&self, scope_id: &str, config_data: &Value) -> DataProcessResult<Doc> {
        let mut doc = self.op.parse_object_alternative(config_data);
        let config_id = format!("analytics-config:{}", scope_id);
        doc.insert("configId".into(), to_value(&config_id));
        doc.insert("scopeId".into(), to_value(scope_id));
        doc.insert("updatedAt".into(), to_value(&now_iso()));
        match self.db.upsert(&self.config.config_index, &config_id, &doc) {
            Ok(_) => DataProcessResult::success(doc),
            Err(e) => DataProcessResult::error(&e),
        }
    }

    pub fn define_funnel(&self, scope_id: &str, funnel_def: &Value) -> DataProcessResult<Doc> {
        let mut doc = self.op.parse_object_alternative(funnel_def);
        let fid = str_val(&doc, "funnelId");
        if fid.is_empty() || !doc.contains_key("steps") {
            return DataProcessResult::error("Missing: funnelId, steps");
        }
        doc.insert("scopeId".into(), to_value(scope_id));
        doc.insert("type".into(), to_value("funnel_definition"));
        doc.insert("updatedAt".into(), to_value(&now_iso()));
        let store_id = format!("funnel-def:{}:{}", scope_id, fid);
        match self.db.upsert(&self.config.config_index, &store_id, &doc) {
            Ok(_) => DataProcessResult::success(doc),
            Err(e) => DataProcessResult::error(&e),
        }
    }

    pub fn define_alert(&self, scope_id: &str, alert_def: &Value) -> DataProcessResult<Doc> {
        let mut doc = self.op.parse_object_alternative(alert_def);
        let aid = str_val(&doc, "alertId");
        if aid.is_empty() || !doc.contains_key("metric") || !doc.contains_key("threshold") {
            return DataProcessResult::error("Missing: alertId, metric, threshold");
        }
        doc.insert("scopeId".into(), to_value(scope_id));
        doc.insert("type".into(), to_value("alert_definition"));
        doc.insert("updatedAt".into(), to_value(&now_iso()));
        let store_id = format!("alert-def:{}:{}", scope_id, aid);
        match self.db.upsert(&self.config.config_index, &store_id, &doc) {
            Ok(_) => DataProcessResult::success(doc),
            Err(e) => DataProcessResult::error(&e),
        }
    }

    // ═══ PRIVATE HELPERS ════════════════════════════════════════════════════

    fn load_config(&self, scope_id: &str) -> Doc {
        let id = format!("analytics-config:{}", scope_id);
        self.db.get_by_id(&self.config.config_index, &id)
            .ok()
            .flatten()
            .unwrap_or_else(|| self.default_config(scope_id))
    }

    fn default_config(&self, scope_id: &str) -> Doc {
        let mut m: Doc = HashMap::new();
        m.insert("configId".into(), to_value(&format!("analytics-config:{}", scope_id)));
        m.insert("scopeId".into(), to_value(scope_id));
        m.insert("aggregationWindows".into(), serde_json::to_value(&self.config.default_aggregation_windows).unwrap_or(Value::Null));
        m.insert("rawRetentionDays".into(), to_int(self.config.raw_retention_days as i64));
        m.insert("hourlyRetentionDays".into(), to_int(self.config.hourly_retention_days as i64));
        m.insert("dailyRetentionDays".into(), to_int(self.config.daily_retention_days as i64));
        let weights: HashMap<&str, f64> = [
            ("view", 1.0), ("click", 2.0), ("like", 3.0), ("comment", 5.0),
            ("share", 7.0), ("create", 10.0), ("purchase", 15.0),
        ].into_iter().collect();
        m.insert("engagementWeights".into(), serde_json::to_value(&weights).unwrap_or(Value::Null));
        m.insert("customDimensions".into(), serde_json::to_value(vec!["platform", "region", "userTier"]).unwrap_or(Value::Null));
        m.insert("alerts".into(), Value::Array(vec![]));
        m
    }

    fn load_funnel_def(&self, scope_id: &str, funnel_id: &str) -> Option<Doc> {
        let id = format!("funnel-def:{}:{}", scope_id, funnel_id);
        self.db.get_by_id(&self.config.config_index, &id).ok().flatten()
    }

    fn load_weights(&self, cfg: &Doc) -> EngagementWeights {
        let mut w = EngagementWeights::default();
        if let Some(Value::Object(wm)) = cfg.get("engagementWeights") {
            if let Some(v) = wm.get("view").and_then(|v| v.as_f64()) { w.view = v; }
            if let Some(v) = wm.get("click").and_then(|v| v.as_f64()) { w.click = v; }
            if let Some(v) = wm.get("like").and_then(|v| v.as_f64()) { w.like = v; }
            if let Some(v) = wm.get("comment").and_then(|v| v.as_f64()) { w.comment = v; }
            if let Some(v) = wm.get("share").and_then(|v| v.as_f64()) { w.share = v; }
            if let Some(v) = wm.get("create").and_then(|v| v.as_f64()) { w.create = v; }
            if let Some(v) = wm.get("purchase").and_then(|v| v.as_f64()) { w.purchase = v; }
        }
        w
    }

    fn publish_event(&self, event_type: &str, data: &Doc) {
        let mut payload: Doc = HashMap::new();
        payload.insert("eventType".into(), to_value(event_type));
        payload.insert("data".into(), serde_json::to_value(data).unwrap_or(Value::Null));
        payload.insert("publishedAt".into(), to_value(&now_iso()));
        let _ = self.queue.publish("analytics-events", &payload);
    }
}
