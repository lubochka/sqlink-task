// XIIGen Analytics Service — Skill 48 | Node.js/TypeScript Alternative
// Event tracking, metric aggregation, engagement scoring, funnel analysis, campaign metrics
// Genie DNA: DNA-1 (Record<string,any>), DNA-2 (buildSearchFilter), DNA-5 (DataProcessResult)

import { IDatabaseService, IQueueService, IObjectProcessor } from '../01-core-interfaces';
import { DataProcessResult } from '../01-core-interfaces';

// ─── Configuration ──────────────────────────────────────────────
export interface AnalyticsConfig {
  eventsIndex: string;
  metricsIndex: string;
  funnelsIndex: string;
  configIndex: string;
  counterPrefix: string;
  defaultPageSize: number;
  maxBatchSize: number;
  rawRetentionDays: number;
  hourlyRetentionDays: number;
  dailyRetentionDays: number;
  defaultAggregationWindows: string[];
}

const DEFAULT_CONFIG: AnalyticsConfig = {
  eventsIndex: 'analytics-events',
  metricsIndex: 'analytics-metrics',
  funnelsIndex: 'analytics-funnels',
  configIndex: 'analytics-config',
  counterPrefix: 'analytics:counter:',
  defaultPageSize: 100,
  maxBatchSize: 1000,
  rawRetentionDays: 30,
  hourlyRetentionDays: 90,
  dailyRetentionDays: 365,
  defaultAggregationWindows: ['1h', '1d', '7d', '30d'],
};

type AnalyticsDoc = Record<string, any>;

// ─── Engagement Weights ─────────────────────────────────────────
interface EngagementWeights {
  view: number; click: number; like: number; comment: number;
  share: number; create: number; purchase: number;
}

const DEFAULT_WEIGHTS: EngagementWeights = {
  view: 1, click: 2, like: 3, comment: 5, share: 7, create: 10, purchase: 15,
};

// ─── Time Window Parser ─────────────────────────────────────────
export class TimeWindowParser {
  static parseMs(window: string): number {
    if (!window) return 3600_000;
    const value = parseInt(window.slice(0, -1), 10) || 1;
    const unit = window.slice(-1);
    switch (unit) {
      case 'h': return value * 3600_000;
      case 'd': return value * 86400_000;
      case 'w': return value * 7 * 86400_000;
      case 'm': return value * 30 * 86400_000;
      default: return value * 3600_000;
    }
  }

  static getWindowKey(timestamp: Date, window: string): string {
    const ms = this.parseMs(window);
    if (ms <= 3600_000) {
      return `${timestamp.getUTCFullYear()}-${pad(timestamp.getUTCMonth()+1)}-${pad(timestamp.getUTCDate())}-${pad(timestamp.getUTCHours())}`;
    }
    if (ms <= 86400_000) {
      return `${timestamp.getUTCFullYear()}-${pad(timestamp.getUTCMonth()+1)}-${pad(timestamp.getUTCDate())}`;
    }
    if (ms <= 7 * 86400_000) {
      const d = new Date(timestamp);
      d.setUTCDate(d.getUTCDate() - d.getUTCDay());
      return `W-${d.getUTCFullYear()}-${pad(d.getUTCMonth()+1)}-${pad(d.getUTCDate())}`;
    }
    return `${timestamp.getUTCFullYear()}-${pad(timestamp.getUTCMonth()+1)}`;
  }
}

function pad(n: number): string { return n.toString().padStart(2, '0'); }

// ─── Service Interface ──────────────────────────────────────────
export interface IAnalyticsService {
  // Event Collection
  trackEvent(eventData: AnalyticsDoc): Promise<DataProcessResult<AnalyticsDoc>>;
  trackBatch(events: AnalyticsDoc[]): Promise<DataProcessResult<number>>;
  incrementCounter(scopeId: string, counterName: string, delta?: number): Promise<DataProcessResult<number>>;
  getCounter(scopeId: string, counterName: string): Promise<DataProcessResult<number>>;

  // Metric Aggregation
  aggregateWindow(scopeId: string, window: string, windowStart: Date): Promise<DataProcessResult<AnalyticsDoc>>;
  getMetrics(scopeId: string, eventType?: string, startDate?: Date, endDate?: Date, dimension?: string, page?: number, pageSize?: number): Promise<DataProcessResult<AnalyticsDoc[]>>;
  getTimeSeries(scopeId: string, metricName: string, window: string, startDate: Date, endDate: Date): Promise<DataProcessResult<AnalyticsDoc[]>>;
  compactMetrics(scopeId: string): Promise<DataProcessResult<number>>;

  // Engagement Scoring
  calculateEngagement(scopeId: string, entityId: string): Promise<DataProcessResult<AnalyticsDoc>>;
  getEngagementScore(scopeId: string, entityId: string): Promise<DataProcessResult<number>>;
  recalculateAllScores(scopeId: string): Promise<DataProcessResult<number>>;

  // Funnel Analysis
  trackFunnelStep(scopeId: string, funnelId: string, entityId: string, stepName: string): Promise<DataProcessResult<AnalyticsDoc>>;
  getFunnelAnalysis(scopeId: string, funnelId: string, startDate?: Date, endDate?: Date): Promise<DataProcessResult<AnalyticsDoc>>;
  getEntityFunnelProgress(scopeId: string, funnelId: string, entityId: string): Promise<DataProcessResult<AnalyticsDoc>>;

  // Campaign Metrics
  trackCampaignEvent(campaignEvent: AnalyticsDoc): Promise<DataProcessResult<AnalyticsDoc>>;
  getCampaignMetrics(scopeId: string, campaignId: string): Promise<DataProcessResult<AnalyticsDoc>>;

  // Configuration (FREEDOM)
  getConfig(scopeId: string): Promise<DataProcessResult<AnalyticsDoc>>;
  updateConfig(scopeId: string, config: AnalyticsDoc): Promise<DataProcessResult<AnalyticsDoc>>;
  defineFunnel(scopeId: string, funnelDef: AnalyticsDoc): Promise<DataProcessResult<AnalyticsDoc>>;
  defineAlert(scopeId: string, alertDef: AnalyticsDoc): Promise<DataProcessResult<AnalyticsDoc>>;
}

// ─── Service Implementation ─────────────────────────────────────
export class AnalyticsService implements IAnalyticsService {
  private db: IDatabaseService;
  private queue: IQueueService;
  private objectProcessor: IObjectProcessor;
  private config: AnalyticsConfig;

  constructor(db: IDatabaseService, queue: IQueueService, objectProcessor: IObjectProcessor, config?: Partial<AnalyticsConfig>) {
    this.db = db;
    this.queue = queue;
    this.objectProcessor = objectProcessor;
    this.config = { ...DEFAULT_CONFIG, ...config };
  }

  // ═══ EVENT COLLECTION ══════════════════════════════════════════

  async trackEvent(eventData: AnalyticsDoc): Promise<DataProcessResult<AnalyticsDoc>> {
    try {
      const doc = this.objectProcessor.parseObjectAlternative(eventData);

      if (!doc.scopeId) return DataProcessResult.error('Missing required field: scopeId (DNA-SCOPE)');
      if (!doc.eventType) return DataProcessResult.error('Missing required field: eventType');

      doc.eventId = doc.eventId || crypto.randomUUID();
      doc.timestamp = doc.timestamp || new Date().toISOString();
      doc.trackedAt = new Date().toISOString();

      await this.db.upsert(this.config.eventsIndex, doc.eventId, doc);
      await this.publishEvent('AnalyticsEventTracked', doc);

      return DataProcessResult.success(doc);
    } catch (err: any) {
      return DataProcessResult.error(err.message);
    }
  }

  async trackBatch(events: AnalyticsDoc[]): Promise<DataProcessResult<number>> {
    try {
      if (events.length > this.config.maxBatchSize)
        return DataProcessResult.error(`Batch size ${events.length} exceeds max ${this.config.maxBatchSize}`);

      let successCount = 0;
      for (const evt of events) {
        const result = await this.trackEvent(evt);
        if (result.isSuccess) successCount++;
      }
      return DataProcessResult.success(successCount);
    } catch (err: any) {
      return DataProcessResult.error(err.message);
    }
  }

  async incrementCounter(scopeId: string, counterName: string, delta = 1): Promise<DataProcessResult<number>> {
    try {
      const key = `${this.config.counterPrefix}${scopeId}:${counterName}`;
      const newValue = await this.queue.increment(key, delta);
      return DataProcessResult.success(newValue);
    } catch (err: any) {
      return DataProcessResult.error(err.message);
    }
  }

  async getCounter(scopeId: string, counterName: string): Promise<DataProcessResult<number>> {
    try {
      const key = `${this.config.counterPrefix}${scopeId}:${counterName}`;
      const value = await this.queue.getCounter(key);
      return DataProcessResult.success(value);
    } catch (err: any) {
      return DataProcessResult.error(err.message);
    }
  }

  // ═══ METRIC AGGREGATION ════════════════════════════════════════

  async aggregateWindow(scopeId: string, window: string, windowStart: Date): Promise<DataProcessResult<AnalyticsDoc>> {
    try {
      const windowMs = TimeWindowParser.parseMs(window);
      const windowEnd = new Date(windowStart.getTime() + windowMs);
      const windowKey = TimeWindowParser.getWindowKey(windowStart, window);

      // DNA-2: BuildSearchFilter
      const eventFilter = this.objectProcessor.buildSearchFilter({
        scopeId,
        timestampGte: windowStart.toISOString(),
        timestampLte: windowEnd.toISOString(),
      });

      const events = await this.db.query(this.config.eventsIndex, eventFilter, this.config.maxBatchSize, 0) || [];

      // Aggregate by eventType
      const countsByType: Record<string, number> = {};
      const sumsByType: Record<string, number> = {};
      const dimensionBreakdowns: Record<string, Record<string, number>> = {};

      const analyticsConfig = await this.loadConfig(scopeId);
      const customDimensions: string[] = analyticsConfig.customDimensions || [];

      for (const evt of events) {
        const eventType = evt.eventType ?? '';
        if (!eventType) continue;

        countsByType[eventType] = (countsByType[eventType] || 0) + 1;

        if (evt.value !== undefined && evt.value !== null) {
          sumsByType[eventType] = (sumsByType[eventType] || 0) + Number(evt.value);
        }

        for (const dim of customDimensions) {
          if (evt[dim] != null) {
            const dimKey = `${eventType}:${dim}`;
            if (!dimensionBreakdowns[dimKey]) dimensionBreakdowns[dimKey] = {};
            const dimVal = String(evt[dim]);
            dimensionBreakdowns[dimKey][dimVal] = (dimensionBreakdowns[dimKey][dimVal] || 0) + 1;
          }
        }
      }

      const metric: AnalyticsDoc = {
        metricId: `${scopeId}:${window}:${windowKey}`,
        scopeId,
        windowSize: window,
        windowStart: windowStart.toISOString(),
        windowEnd: windowEnd.toISOString(),
        windowKey,
        totalEvents: events.length,
        countsByType,
        sumsByType,
        dimensionBreakdowns,
        aggregatedAt: new Date().toISOString(),
      };

      await this.db.upsert(this.config.metricsIndex, metric.metricId, metric);
      await this.publishEvent('MetricAggregated', metric);

      return DataProcessResult.success(metric);
    } catch (err: any) {
      return DataProcessResult.error(err.message);
    }
  }

  async getMetrics(scopeId: string, eventType?: string, startDate?: Date, endDate?: Date, dimension?: string, page = 0, pageSize = 100): Promise<DataProcessResult<AnalyticsDoc[]>> {
    try {
      const filter = this.objectProcessor.buildSearchFilter({
        scopeId,
        eventType: eventType ?? null,
        timestampGte: startDate?.toISOString() ?? null,
        timestampLte: endDate?.toISOString() ?? null,
        dimension: dimension ?? null,
      });

      const results = await this.db.query(this.config.metricsIndex, filter, pageSize, page * pageSize) || [];
      return DataProcessResult.success(results);
    } catch (err: any) {
      return DataProcessResult.error(err.message);
    }
  }

  async getTimeSeries(scopeId: string, metricName: string, window: string, startDate: Date, endDate: Date): Promise<DataProcessResult<AnalyticsDoc[]>> {
    try {
      const filter = this.objectProcessor.buildSearchFilter({
        scopeId,
        windowSize: window,
        windowStartGte: startDate.toISOString(),
        windowStartLte: endDate.toISOString(),
      });

      const results = await this.db.query(this.config.metricsIndex, filter, 1000, 0) || [];
      results.sort((a: any, b: any) => (a.windowStart ?? '').localeCompare(b.windowStart ?? ''));

      const series = results.map((r: any) => ({
        windowStart: r.windowStart,
        windowEnd: r.windowEnd,
        totalEvents: r.totalEvents,
        value: r.countsByType?.[metricName] ?? undefined,
        countsByType: r.countsByType,
      }));

      return DataProcessResult.success(series);
    } catch (err: any) {
      return DataProcessResult.error(err.message);
    }
  }

  async compactMetrics(scopeId: string): Promise<DataProcessResult<number>> {
    try {
      const config = await this.loadConfig(scopeId);
      const rawRetention = config.rawRetentionDays || this.config.rawRetentionDays;
      const hourlyRetention = config.hourlyRetentionDays || this.config.hourlyRetentionDays;

      let compacted = 0;

      // Delete old raw events
      const rawCutoff = new Date(Date.now() - rawRetention * 86400_000);
      const rawFilter = this.objectProcessor.buildSearchFilter({
        scopeId, timestampLte: rawCutoff.toISOString(),
      });
      const oldRaw = await this.db.query(this.config.eventsIndex, rawFilter, 1000, 0) || [];
      for (const evt of oldRaw) {
        if (evt.eventId) { await this.db.delete(this.config.eventsIndex, evt.eventId); compacted++; }
      }

      // Delete old hourly metrics
      const hourlyCutoff = new Date(Date.now() - hourlyRetention * 86400_000);
      const hourlyFilter = this.objectProcessor.buildSearchFilter({
        scopeId, windowSize: '1h', windowStartLte: hourlyCutoff.toISOString(),
      });
      const oldHourly = await this.db.query(this.config.metricsIndex, hourlyFilter, 1000, 0) || [];
      for (const m of oldHourly) {
        if (m.metricId) { await this.db.delete(this.config.metricsIndex, m.metricId); compacted++; }
      }

      return DataProcessResult.success(compacted);
    } catch (err: any) {
      return DataProcessResult.error(err.message);
    }
  }

  // ═══ ENGAGEMENT SCORING ════════════════════════════════════════

  async calculateEngagement(scopeId: string, entityId: string): Promise<DataProcessResult<AnalyticsDoc>> {
    try {
      const config = await this.loadConfig(scopeId);
      const weights = this.loadWeights(config);

      const since = new Date(Date.now() - 30 * 86400_000);
      const filter = this.objectProcessor.buildSearchFilter({
        scopeId, entityId, timestampGte: since.toISOString(),
      });
      const events = await this.db.query(this.config.eventsIndex, filter, 10000, 0) || [];

      const signalCounts: Record<string, number> = {};
      let totalScore = 0;

      for (const evt of events) {
        const signal = (evt.action || evt.eventType || '').toLowerCase();
        signalCounts[signal] = (signalCounts[signal] || 0) + 1;

        const weight = (weights as any)[signal] ?? weights.view;
        totalScore += weight;
      }

      const days = Math.max(1, (Date.now() - since.getTime()) / 86400_000);
      const normalizedScore = +(totalScore / days).toFixed(2);

      const engagement: AnalyticsDoc = {
        engagementId: `${scopeId}:${entityId}`,
        scopeId, entityId,
        totalScore: +totalScore.toFixed(2),
        normalizedScore,
        totalEvents: events.length,
        signalCounts,
        periodDays: 30,
        calculatedAt: new Date().toISOString(),
      };

      await this.db.upsert(this.config.metricsIndex, `engagement:${scopeId}:${entityId}`, engagement);
      await this.publishEvent('EngagementScoreUpdated', engagement);

      return DataProcessResult.success(engagement);
    } catch (err: any) {
      return DataProcessResult.error(err.message);
    }
  }

  async getEngagementScore(scopeId: string, entityId: string): Promise<DataProcessResult<number>> {
    try {
      const doc = await this.db.getById(this.config.metricsIndex, `engagement:${scopeId}:${entityId}`);
      return DataProcessResult.success(doc?.normalizedScore ?? 0);
    } catch (err: any) {
      return DataProcessResult.error(err.message);
    }
  }

  async recalculateAllScores(scopeId: string): Promise<DataProcessResult<number>> {
    try {
      const since = new Date(Date.now() - 30 * 86400_000);
      const filter = this.objectProcessor.buildSearchFilter({
        scopeId, timestampGte: since.toISOString(),
      });
      const allEvents = await this.db.query(this.config.eventsIndex, filter, 10000, 0) || [];
      const entityIds = [...new Set(allEvents.map((e: any) => e.entityId).filter(Boolean))];

      let recalculated = 0;
      for (const entityId of entityIds) {
        const result = await this.calculateEngagement(scopeId, entityId);
        if (result.isSuccess) recalculated++;
      }
      return DataProcessResult.success(recalculated);
    } catch (err: any) {
      return DataProcessResult.error(err.message);
    }
  }

  // ═══ FUNNEL ANALYSIS ═══════════════════════════════════════════

  async trackFunnelStep(scopeId: string, funnelId: string, entityId: string, stepName: string): Promise<DataProcessResult<AnalyticsDoc>> {
    try {
      const funnelDef = await this.loadFunnelDef(scopeId, funnelId);
      if (!funnelDef) return DataProcessResult.error(`Funnel ${funnelId} not defined for scope ${scopeId}`);

      const steps: string[] = funnelDef.steps || [];
      const stepIndex = steps.indexOf(stepName);
      if (stepIndex < 0) return DataProcessResult.error(`Step '${stepName}' not in funnel '${funnelId}'`);

      const windowHours = funnelDef.windowHours || 72;
      const progressId = `funnel:${scopeId}:${funnelId}:${entityId}`;
      let progress = await this.db.getById(this.config.funnelsIndex, progressId);

      if (!progress) {
        progress = {
          progressId, scopeId, funnelId, entityId,
          sessionId: crypto.randomUUID(),
          currentStepIndex: stepIndex, currentStepName: stepName,
          completedSteps: [stepName],
          stepTimestamps: { [stepName]: new Date().toISOString() },
          startedAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          completed: stepIndex === steps.length - 1,
          timedOut: false,
        };
      } else {
        const startedAt = new Date(progress.startedAt || Date.now());
        const hoursSince = (Date.now() - startedAt.getTime()) / 3600_000;

        if (hoursSince > windowHours) {
          progress.sessionId = crypto.randomUUID();
          progress.completedSteps = [stepName];
          progress.stepTimestamps = { [stepName]: new Date().toISOString() };
          progress.startedAt = new Date().toISOString();
          progress.timedOut = false;
        } else {
          const completed: string[] = progress.completedSteps || [];
          if (!completed.includes(stepName)) completed.push(stepName);
          progress.completedSteps = completed;
          const ts = progress.stepTimestamps || {};
          ts[stepName] = new Date().toISOString();
          progress.stepTimestamps = ts;
        }
        progress.currentStepIndex = stepIndex;
        progress.currentStepName = stepName;
        progress.updatedAt = new Date().toISOString();
        progress.completed = stepIndex === steps.length - 1;
      }

      await this.db.upsert(this.config.funnelsIndex, progressId, progress);
      await this.publishEvent('FunnelStepCompleted', progress);
      if (progress.completed) await this.publishEvent('FunnelCompleted', progress);

      return DataProcessResult.success(progress);
    } catch (err: any) {
      return DataProcessResult.error(err.message);
    }
  }

  async getFunnelAnalysis(scopeId: string, funnelId: string, startDate?: Date, endDate?: Date): Promise<DataProcessResult<AnalyticsDoc>> {
    try {
      const funnelDef = await this.loadFunnelDef(scopeId, funnelId);
      if (!funnelDef) return DataProcessResult.error(`Funnel ${funnelId} not defined`);

      const steps: string[] = funnelDef.steps || [];
      const filter = this.objectProcessor.buildSearchFilter({
        scopeId, funnelId,
        startedAtGte: startDate?.toISOString() ?? null,
        startedAtLte: endDate?.toISOString() ?? null,
      });

      const allProgress = await this.db.query(this.config.funnelsIndex, filter, 10000, 0) || [];

      const stepResults = steps.map((stepName, i) => {
        const reached = allProgress.filter((p: any) => (p.completedSteps || []).includes(stepName)).length;
        const prev = i === 0 ? allProgress.length :
          allProgress.filter((p: any) => (p.completedSteps || []).includes(steps[i-1])).length;
        const rate = prev > 0 ? +((reached / prev) * 100).toFixed(1) : 0;
        return { stepName, stepIndex: i, enteredCount: prev, completedCount: reached, completionRate: rate, dropOffRate: +(100 - rate).toFixed(1) };
      });

      const totalCompleted = allProgress.filter((p: any) => p.completed).length;
      const overallRate = allProgress.length > 0 ? +((totalCompleted / allProgress.length) * 100).toFixed(1) : 0;

      return DataProcessResult.success({
        funnelId, scopeId, totalSessions: allProgress.length,
        totalCompleted, overallCompletionRate: overallRate,
        steps: stepResults, analyzedAt: new Date().toISOString(),
      });
    } catch (err: any) {
      return DataProcessResult.error(err.message);
    }
  }

  async getEntityFunnelProgress(scopeId: string, funnelId: string, entityId: string): Promise<DataProcessResult<AnalyticsDoc>> {
    try {
      const doc = await this.db.getById(this.config.funnelsIndex, `funnel:${scopeId}:${funnelId}:${entityId}`);
      return DataProcessResult.success(doc || { funnelId, entityId, status: 'not_started', completedSteps: [] });
    } catch (err: any) {
      return DataProcessResult.error(err.message);
    }
  }

  // ═══ CAMPAIGN METRICS ══════════════════════════════════════════

  async trackCampaignEvent(campaignEvent: AnalyticsDoc): Promise<DataProcessResult<AnalyticsDoc>> {
    try {
      const doc = this.objectProcessor.parseObjectAlternative(campaignEvent);
      if (!doc.campaignId || !doc.scopeId) return DataProcessResult.error('Missing: campaignId, scopeId');

      doc.eventId = doc.eventId || crypto.randomUUID();
      doc.eventType = `campaign_${doc.action || 'unknown'}`;
      doc.timestamp = doc.timestamp || new Date().toISOString();

      await this.db.upsert(this.config.eventsIndex, doc.eventId, doc);

      const metricId = `campaign:${doc.scopeId}:${doc.campaignId}`;
      let existing = await this.db.getById(this.config.metricsIndex, metricId);

      if (!existing) {
        existing = { metricId, scopeId: doc.scopeId, campaignId: doc.campaignId,
          sent: 0, delivered: 0, opened: 0, clicked: 0, converted: 0, unsubscribed: 0 };
      }

      const action = (doc.action || '').toLowerCase();
      if (action in existing) existing[action] = (existing[action] || 0) + 1;
      existing.updatedAt = new Date().toISOString();

      const sent = existing.sent || 0;
      if (sent > 0) {
        existing.openRate = +((existing.opened / sent) * 100).toFixed(2);
        existing.clickRate = +((existing.clicked / sent) * 100).toFixed(2);
        existing.conversionRate = +((existing.converted / sent) * 100).toFixed(2);
      }

      await this.db.upsert(this.config.metricsIndex, metricId, existing);
      await this.publishEvent('CampaignMetricsUpdated', existing);

      return DataProcessResult.success(existing);
    } catch (err: any) {
      return DataProcessResult.error(err.message);
    }
  }

  async getCampaignMetrics(scopeId: string, campaignId: string): Promise<DataProcessResult<AnalyticsDoc>> {
    try {
      const doc = await this.db.getById(this.config.metricsIndex, `campaign:${scopeId}:${campaignId}`);
      return DataProcessResult.success(doc || { campaignId, scopeId, status: 'no_data' });
    } catch (err: any) {
      return DataProcessResult.error(err.message);
    }
  }

  // ═══ CONFIGURATION (FREEDOM) ═══════════════════════════════════

  async getConfig(scopeId: string): Promise<DataProcessResult<AnalyticsDoc>> {
    try {
      const config = await this.loadConfig(scopeId);
      return DataProcessResult.success(config);
    } catch (err: any) {
      return DataProcessResult.error(err.message);
    }
  }

  async updateConfig(scopeId: string, config: AnalyticsDoc): Promise<DataProcessResult<AnalyticsDoc>> {
    try {
      const doc = this.objectProcessor.parseObjectAlternative(config);
      doc.configId = `analytics-config:${scopeId}`;
      doc.scopeId = scopeId;
      doc.updatedAt = new Date().toISOString();
      await this.db.upsert(this.config.configIndex, doc.configId, doc);
      return DataProcessResult.success(doc);
    } catch (err: any) {
      return DataProcessResult.error(err.message);
    }
  }

  async defineFunnel(scopeId: string, funnelDef: AnalyticsDoc): Promise<DataProcessResult<AnalyticsDoc>> {
    try {
      const doc = this.objectProcessor.parseObjectAlternative(funnelDef);
      if (!doc.funnelId || !doc.steps) return DataProcessResult.error('Missing: funnelId, steps');
      doc.scopeId = scopeId; doc.type = 'funnel_definition'; doc.updatedAt = new Date().toISOString();
      await this.db.upsert(this.config.configIndex, `funnel-def:${scopeId}:${doc.funnelId}`, doc);
      return DataProcessResult.success(doc);
    } catch (err: any) {
      return DataProcessResult.error(err.message);
    }
  }

  async defineAlert(scopeId: string, alertDef: AnalyticsDoc): Promise<DataProcessResult<AnalyticsDoc>> {
    try {
      const doc = this.objectProcessor.parseObjectAlternative(alertDef);
      if (!doc.alertId || !doc.metric || doc.threshold === undefined)
        return DataProcessResult.error('Missing: alertId, metric, threshold');
      doc.scopeId = scopeId; doc.type = 'alert_definition'; doc.updatedAt = new Date().toISOString();
      await this.db.upsert(this.config.configIndex, `alert-def:${scopeId}:${doc.alertId}`, doc);
      return DataProcessResult.success(doc);
    } catch (err: any) {
      return DataProcessResult.error(err.message);
    }
  }

  // ═══ PRIVATE HELPERS ═══════════════════════════════════════════

  private async loadConfig(scopeId: string): Promise<AnalyticsDoc> {
    try {
      const doc = await this.db.getById(this.config.configIndex, `analytics-config:${scopeId}`);
      return doc || this.defaultConfig(scopeId);
    } catch { return this.defaultConfig(scopeId); }
  }

  private defaultConfig(scopeId: string): AnalyticsDoc {
    return {
      configId: `analytics-config:${scopeId}`, scopeId,
      aggregationWindows: this.config.defaultAggregationWindows,
      rawRetentionDays: this.config.rawRetentionDays,
      hourlyRetentionDays: this.config.hourlyRetentionDays,
      dailyRetentionDays: this.config.dailyRetentionDays,
      engagementWeights: { ...DEFAULT_WEIGHTS },
      customDimensions: ['platform', 'region', 'userTier'],
      alerts: [],
    };
  }

  private async loadFunnelDef(scopeId: string, funnelId: string): Promise<AnalyticsDoc | null> {
    try { return await this.db.getById(this.config.configIndex, `funnel-def:${scopeId}:${funnelId}`); }
    catch { return null; }
  }

  private loadWeights(config: AnalyticsDoc): EngagementWeights {
    const w = config.engagementWeights || {};
    return { ...DEFAULT_WEIGHTS, ...w };
  }

  private async publishEvent(eventType: string, data: AnalyticsDoc): Promise<void> {
    try {
      await this.queue.publish('analytics-events', { eventType, data, publishedAt: new Date().toISOString() });
    } catch { /* non-critical */ }
  }
}
