// XIIGen Analytics Service — Skill 48 | Java Alternative
// Event tracking, metric aggregation, engagement scoring, funnel analysis, campaign metrics
// Genie DNA: DNA-1 (Map<String,Object>), DNA-2 (buildSearchFilter), DNA-5 (DataProcessResult)

package com.xiigen.services.analytics;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import java.util.stream.Collectors;

// ─── Configuration ──────────────────────────────────────────────
class AnalyticsConfig {
    String eventsIndex = "analytics-events";
    String metricsIndex = "analytics-metrics";
    String funnelsIndex = "analytics-funnels";
    String configIndex = "analytics-config";
    String counterPrefix = "analytics:counter:";
    int defaultPageSize = 100;
    int maxBatchSize = 1000;
    int rawRetentionDays = 30;
    int hourlyRetentionDays = 90;
    int dailyRetentionDays = 365;
    List<String> defaultAggregationWindows = List.of("1h", "1d", "7d", "30d");
}

// ─── DataProcessResult ─────────────────────────────────────────
class DataProcessResult<T> {
    private final boolean success;
    private final T data;
    private final String errorMessage;

    private DataProcessResult(boolean success, T data, String errorMessage) {
        this.success = success; this.data = data; this.errorMessage = errorMessage;
    }
    static <T> DataProcessResult<T> success(T data) { return new DataProcessResult<>(true, data, null); }
    static <T> DataProcessResult<T> error(String msg) { return new DataProcessResult<>(false, null, msg); }
    boolean isSuccess() { return success; }
    T getData() { return data; }
    String getErrorMessage() { return errorMessage; }
}

// ─── Engagement Weights ─────────────────────────────────────────
class EngagementWeights {
    double view = 1.0, click = 2.0, like = 3.0, comment = 5.0;
    double share = 7.0, create = 10.0, purchase = 15.0;

    double getWeight(String signal) {
        return switch (signal.toLowerCase()) {
            case "view", "page_view" -> view;
            case "click" -> click;
            case "like" -> like;
            case "comment" -> comment;
            case "share" -> share;
            case "create", "post_create" -> create;
            case "purchase", "payment" -> purchase;
            default -> view;
        };
    }
}

// ─── TimeWindowParser ───────────────────────────────────────────
class TimeWindowParser {
    static Duration parse(String window) {
        if (window == null || window.isEmpty()) return Duration.ofHours(1);
        int value;
        try { value = Integer.parseInt(window.substring(0, window.length() - 1)); }
        catch (NumberFormatException e) { value = 1; }
        char unit = window.charAt(window.length() - 1);
        return switch (unit) {
            case 'h' -> Duration.ofHours(value);
            case 'd' -> Duration.ofDays(value);
            case 'w' -> Duration.ofDays(value * 7L);
            case 'm' -> Duration.ofDays(value * 30L);
            default -> Duration.ofHours(value);
        };
    }

    static String getWindowKey(Instant timestamp, String window) {
        var zdt = timestamp.atZone(ZoneOffset.UTC);
        var dur = parse(window);
        if (dur.toHours() <= 1) return DateTimeFormatter.ofPattern("yyyy-MM-dd-HH").format(zdt);
        if (dur.toDays() <= 1) return DateTimeFormatter.ofPattern("yyyy-MM-dd").format(zdt);
        if (dur.toDays() <= 7) {
            var start = zdt.minusDays(zdt.getDayOfWeek().getValue() % 7);
            return "W-" + DateTimeFormatter.ofPattern("yyyy-MM-dd").format(start);
        }
        return DateTimeFormatter.ofPattern("yyyy-MM").format(zdt);
    }
}

// ─── Service Interfaces ─────────────────────────────────────────
interface IDatabaseService {
    void upsert(String index, String id, Map<String, Object> doc);
    Map<String, Object> getById(String index, String id);
    List<Map<String, Object>> query(String index, Map<String, Object> filter, int size, int offset);
    void delete(String index, String id);
}

interface IQueueService {
    void publish(String channel, Map<String, Object> data);
    long increment(String key, long delta);
    long getCounter(String key);
}

interface IObjectProcessor {
    Map<String, Object> parseObjectAlternative(Object obj);
    Map<String, Object> buildSearchFilter(Map<String, Object> criteria);
}

// ─── Analytics Service ──────────────────────────────────────────
public class AnalyticsService {
    private static final Logger log = Logger.getLogger(AnalyticsService.class.getName());
    private final IDatabaseService db;
    private final IQueueService queue;
    private final IObjectProcessor op;
    private final AnalyticsConfig config;

    public AnalyticsService(IDatabaseService db, IQueueService queue, IObjectProcessor op) {
        this(db, queue, op, new AnalyticsConfig());
    }
    public AnalyticsService(IDatabaseService db, IQueueService queue, IObjectProcessor op, AnalyticsConfig config) {
        this.db = db; this.queue = queue; this.op = op; this.config = config;
    }

    // ═══ EVENT COLLECTION ════════════════════════════════════════

    public DataProcessResult<Map<String, Object>> trackEvent(Map<String, Object> eventData) {
        try {
            var doc = op.parseObjectAlternative(eventData);
            if (!doc.containsKey("scopeId")) return DataProcessResult.error("Missing: scopeId (DNA-SCOPE)");
            if (!doc.containsKey("eventType")) return DataProcessResult.error("Missing: eventType");

            doc.putIfAbsent("eventId", UUID.randomUUID().toString());
            doc.putIfAbsent("timestamp", Instant.now().toString());
            doc.put("trackedAt", Instant.now().toString());

            db.upsert(config.eventsIndex, str(doc, "eventId"), doc);
            publishEvent("AnalyticsEventTracked", doc);
            return DataProcessResult.success(doc);
        } catch (Exception ex) {
            log.severe("Failed to track event: " + ex.getMessage());
            return DataProcessResult.error(ex.getMessage());
        }
    }

    public DataProcessResult<Integer> trackBatch(List<Map<String, Object>> events) {
        try {
            if (events.size() > config.maxBatchSize)
                return DataProcessResult.error("Batch size " + events.size() + " exceeds max " + config.maxBatchSize);
            int ok = 0;
            for (var evt : events) { if (trackEvent(evt).isSuccess()) ok++; }
            return DataProcessResult.success(ok);
        } catch (Exception ex) { return DataProcessResult.error(ex.getMessage()); }
    }

    public DataProcessResult<Long> incrementCounter(String scopeId, String name, long delta) {
        try {
            var key = config.counterPrefix + scopeId + ":" + name;
            return DataProcessResult.success(queue.increment(key, delta));
        } catch (Exception ex) { return DataProcessResult.error(ex.getMessage()); }
    }

    public DataProcessResult<Long> getCounter(String scopeId, String name) {
        try {
            var key = config.counterPrefix + scopeId + ":" + name;
            return DataProcessResult.success(queue.getCounter(key));
        } catch (Exception ex) { return DataProcessResult.error(ex.getMessage()); }
    }

    // ═══ METRIC AGGREGATION ══════════════════════════════════════

    @SuppressWarnings("unchecked")
    public DataProcessResult<Map<String, Object>> aggregateWindow(String scopeId, String window, Instant windowStart) {
        try {
            var dur = TimeWindowParser.parse(window);
            var windowEnd = windowStart.plus(dur);
            var windowKey = TimeWindowParser.getWindowKey(windowStart, window);

            var filter = op.buildSearchFilter(Map.of(
                "scopeId", scopeId,
                "timestampGte", windowStart.toString(),
                "timestampLte", windowEnd.toString()
            ));
            var events = db.query(config.eventsIndex, filter, config.maxBatchSize, 0);
            if (events == null) events = List.of();

            var countsByType = new HashMap<String, Long>();
            var sumsByType = new HashMap<String, Double>();
            var dimBreakdowns = new HashMap<String, Map<String, Long>>();

            var cfg = loadConfig(scopeId);
            var customDims = getStringList(cfg, "customDimensions");

            for (var evt : events) {
                var et = str(evt, "eventType");
                if (et.isEmpty()) continue;
                countsByType.merge(et, 1L, Long::sum);
                if (evt.containsKey("value") && evt.get("value") != null)
                    sumsByType.merge(et, toDouble(evt.get("value")), Double::sum);
                for (var dim : customDims) {
                    if (evt.containsKey(dim) && evt.get(dim) != null) {
                        var dk = et + ":" + dim;
                        dimBreakdowns.computeIfAbsent(dk, k -> new HashMap<>())
                            .merge(evt.get(dim).toString(), 1L, Long::sum);
                    }
                }
            }

            var metric = new HashMap<String, Object>();
            metric.put("metricId", scopeId + ":" + window + ":" + windowKey);
            metric.put("scopeId", scopeId);
            metric.put("windowSize", window); metric.put("windowStart", windowStart.toString());
            metric.put("windowEnd", windowEnd.toString()); metric.put("windowKey", windowKey);
            metric.put("totalEvents", events.size()); metric.put("countsByType", countsByType);
            metric.put("sumsByType", sumsByType); metric.put("dimensionBreakdowns", dimBreakdowns);
            metric.put("aggregatedAt", Instant.now().toString());

            db.upsert(config.metricsIndex, str(metric, "metricId"), metric);
            publishEvent("MetricAggregated", metric);
            return DataProcessResult.success(metric);
        } catch (Exception ex) { return DataProcessResult.error(ex.getMessage()); }
    }

    public DataProcessResult<List<Map<String, Object>>> getMetrics(
            String scopeId, String eventType, Instant start, Instant end,
            String dimension, int page, int pageSize) {
        try {
            var criteria = new HashMap<String, Object>();
            criteria.put("scopeId", scopeId);
            if (eventType != null) criteria.put("eventType", eventType);
            if (start != null) criteria.put("timestampGte", start.toString());
            if (end != null) criteria.put("timestampLte", end.toString());
            if (dimension != null) criteria.put("dimension", dimension);
            var filter = op.buildSearchFilter(criteria);
            var results = db.query(config.metricsIndex, filter, pageSize, page * pageSize);
            return DataProcessResult.success(results != null ? results : List.of());
        } catch (Exception ex) { return DataProcessResult.error(ex.getMessage()); }
    }

    // ═══ ENGAGEMENT SCORING ══════════════════════════════════════

    public DataProcessResult<Map<String, Object>> calculateEngagement(String scopeId, String entityId) {
        try {
            var cfg = loadConfig(scopeId);
            var weights = loadWeights(cfg);
            var since = Instant.now().minus(Duration.ofDays(30));

            var filter = op.buildSearchFilter(Map.of(
                "scopeId", scopeId, "entityId", entityId,
                "timestampGte", since.toString()
            ));
            var events = db.query(config.eventsIndex, filter, 10000, 0);
            if (events == null) events = List.of();

            var signalCounts = new HashMap<String, Long>();
            double totalScore = 0;
            for (var evt : events) {
                var action = str(evt, "action");
                var signal = action.isEmpty() ? str(evt, "eventType") : action;
                signalCounts.merge(signal.toLowerCase(), 1L, Long::sum);
                totalScore += weights.getWeight(signal);
            }

            double days = Math.max(1, Duration.between(since, Instant.now()).toDays());
            double norm = Math.round(totalScore / days * 100.0) / 100.0;

            var engagement = new HashMap<String, Object>();
            engagement.put("engagementId", scopeId + ":" + entityId);
            engagement.put("scopeId", scopeId); engagement.put("entityId", entityId);
            engagement.put("totalScore", Math.round(totalScore * 100.0) / 100.0);
            engagement.put("normalizedScore", norm); engagement.put("totalEvents", events.size());
            engagement.put("signalCounts", signalCounts); engagement.put("periodDays", 30);
            engagement.put("calculatedAt", Instant.now().toString());

            db.upsert(config.metricsIndex, "engagement:" + scopeId + ":" + entityId, engagement);
            publishEvent("EngagementScoreUpdated", engagement);
            return DataProcessResult.success(engagement);
        } catch (Exception ex) { return DataProcessResult.error(ex.getMessage()); }
    }

    public DataProcessResult<Double> getEngagementScore(String scopeId, String entityId) {
        try {
            var doc = db.getById(config.metricsIndex, "engagement:" + scopeId + ":" + entityId);
            return DataProcessResult.success(doc != null ? toDouble(doc.get("normalizedScore")) : 0.0);
        } catch (Exception ex) { return DataProcessResult.error(ex.getMessage()); }
    }

    public DataProcessResult<Integer> recalculateAllScores(String scopeId) {
        try {
            var since = Instant.now().minus(Duration.ofDays(30));
            var filter = op.buildSearchFilter(Map.of("scopeId", scopeId, "timestampGte", since.toString()));
            var events = db.query(config.eventsIndex, filter, 10000, 0);
            if (events == null) events = List.of();
            var ids = events.stream().map(e -> str(e, "entityId")).filter(s -> !s.isEmpty())
                .distinct().collect(Collectors.toList());
            int count = 0;
            for (var id : ids) { if (calculateEngagement(scopeId, id).isSuccess()) count++; }
            return DataProcessResult.success(count);
        } catch (Exception ex) { return DataProcessResult.error(ex.getMessage()); }
    }

    // ═══ FUNNEL ANALYSIS ═════════════════════════════════════════

    @SuppressWarnings("unchecked")
    public DataProcessResult<Map<String, Object>> trackFunnelStep(
            String scopeId, String funnelId, String entityId, String stepName) {
        try {
            var fdef = loadFunnelDef(scopeId, funnelId);
            if (fdef == null) return DataProcessResult.error("Funnel " + funnelId + " not defined");
            var steps = getStringList(fdef, "steps");
            int idx = steps.indexOf(stepName);
            if (idx < 0) return DataProcessResult.error("Step '" + stepName + "' not in funnel");
            int windowHours = toInt(fdef.getOrDefault("windowHours", 72));

            var pid = "funnel:" + scopeId + ":" + funnelId + ":" + entityId;
            var progress = db.getById(config.funnelsIndex, pid);
            var now = Instant.now().toString();

            if (progress == null) {
                progress = new HashMap<>();
                progress.put("progressId", pid); progress.put("scopeId", scopeId);
                progress.put("funnelId", funnelId); progress.put("entityId", entityId);
                progress.put("sessionId", UUID.randomUUID().toString());
                progress.put("currentStepIndex", idx); progress.put("currentStepName", stepName);
                progress.put("completedSteps", new ArrayList<>(List.of(stepName)));
                progress.put("stepTimestamps", new HashMap<>(Map.of(stepName, now)));
                progress.put("startedAt", now); progress.put("updatedAt", now);
                progress.put("completed", idx == steps.size() - 1);
            } else {
                var started = Instant.parse(str(progress, "startedAt"));
                long hours = Duration.between(started, Instant.now()).toHours();
                if (hours > windowHours) {
                    progress.put("sessionId", UUID.randomUUID().toString());
                    progress.put("completedSteps", new ArrayList<>(List.of(stepName)));
                    progress.put("stepTimestamps", new HashMap<>(Map.of(stepName, now)));
                    progress.put("startedAt", now);
                } else {
                    var cs = (List<String>) progress.getOrDefault("completedSteps", new ArrayList<>());
                    if (!cs.contains(stepName)) cs.add(stepName);
                    progress.put("completedSteps", cs);
                    var ts = (Map<String, String>) progress.getOrDefault("stepTimestamps", new HashMap<>());
                    ts.put(stepName, now);
                    progress.put("stepTimestamps", ts);
                }
                progress.put("currentStepIndex", idx); progress.put("currentStepName", stepName);
                progress.put("updatedAt", now); progress.put("completed", idx == steps.size() - 1);
            }

            db.upsert(config.funnelsIndex, pid, progress);
            publishEvent("FunnelStepCompleted", progress);
            if (Boolean.TRUE.equals(progress.get("completed")))
                publishEvent("FunnelCompleted", progress);
            return DataProcessResult.success(progress);
        } catch (Exception ex) { return DataProcessResult.error(ex.getMessage()); }
    }

    @SuppressWarnings("unchecked")
    public DataProcessResult<Map<String, Object>> getFunnelAnalysis(
            String scopeId, String funnelId, Instant start, Instant end) {
        try {
            var fdef = loadFunnelDef(scopeId, funnelId);
            if (fdef == null) return DataProcessResult.error("Funnel " + funnelId + " not defined");
            var steps = getStringList(fdef, "steps");
            var criteria = new HashMap<String, Object>();
            criteria.put("scopeId", scopeId); criteria.put("funnelId", funnelId);
            if (start != null) criteria.put("startedAtGte", start.toString());
            if (end != null) criteria.put("startedAtLte", end.toString());
            var filter = op.buildSearchFilter(criteria);
            var allP = db.query(config.funnelsIndex, filter, 10000, 0);
            if (allP == null) allP = List.of();

            var stepResults = new ArrayList<Map<String, Object>>();
            for (int i = 0; i < steps.size(); i++) {
                var sn = steps.get(i);
                int fi = i;
                long reached = allP.stream().filter(p -> {
                    var cs = (List<String>) p.getOrDefault("completedSteps", List.of());
                    return cs.contains(sn);
                }).count();
                long prev = i == 0 ? allP.size() : allP.stream().filter(p -> {
                    var cs = (List<String>) p.getOrDefault("completedSteps", List.of());
                    return cs.contains(steps.get(fi - 1));
                }).count();
                double rate = prev > 0 ? Math.round(reached * 1000.0 / prev) / 10.0 : 0;
                stepResults.add(Map.of("stepName", sn, "stepIndex", i, "enteredCount", prev,
                    "completedCount", reached, "completionRate", rate, "dropOffRate", Math.round((100 - rate) * 10.0) / 10.0));
            }

            long totalCompleted = allP.stream().filter(p -> Boolean.TRUE.equals(p.get("completed"))).count();
            double overall = !allP.isEmpty() ? Math.round(totalCompleted * 1000.0 / allP.size()) / 10.0 : 0;

            return DataProcessResult.success(Map.of(
                "funnelId", funnelId, "scopeId", scopeId, "totalSessions", allP.size(),
                "totalCompleted", totalCompleted, "overallCompletionRate", overall,
                "steps", stepResults, "analyzedAt", Instant.now().toString()
            ));
        } catch (Exception ex) { return DataProcessResult.error(ex.getMessage()); }
    }

    // ═══ CAMPAIGN METRICS ════════════════════════════════════════

    public DataProcessResult<Map<String, Object>> trackCampaignEvent(Map<String, Object> event) {
        try {
            var doc = op.parseObjectAlternative(event);
            if (!doc.containsKey("campaignId") || !doc.containsKey("scopeId"))
                return DataProcessResult.error("Missing: campaignId, scopeId");
            doc.putIfAbsent("eventId", UUID.randomUUID().toString());
            doc.put("eventType", "campaign_" + str(doc, "action"));
            doc.putIfAbsent("timestamp", Instant.now().toString());
            db.upsert(config.eventsIndex, str(doc, "eventId"), doc);

            var mid = "campaign:" + str(doc, "scopeId") + ":" + str(doc, "campaignId");
            var existing = db.getById(config.metricsIndex, mid);
            if (existing == null) {
                existing = new HashMap<>(Map.of("metricId", mid, "scopeId", str(doc, "scopeId"),
                    "campaignId", str(doc, "campaignId"), "sent", 0L, "delivered", 0L,
                    "opened", 0L, "clicked", 0L, "converted", 0L));
                existing.put("unsubscribed", 0L);
            }
            var action = str(doc, "action").toLowerCase();
            if (existing.containsKey(action))
                existing.put(action, toLong(existing.get(action)) + 1);
            existing.put("updatedAt", Instant.now().toString());

            long sent = toLong(existing.get("sent"));
            if (sent > 0) {
                existing.put("openRate", Math.round(toLong(existing.get("opened")) * 10000.0 / sent) / 100.0);
                existing.put("clickRate", Math.round(toLong(existing.get("clicked")) * 10000.0 / sent) / 100.0);
                existing.put("conversionRate", Math.round(toLong(existing.get("converted")) * 10000.0 / sent) / 100.0);
            }
            db.upsert(config.metricsIndex, mid, existing);
            publishEvent("CampaignMetricsUpdated", existing);
            return DataProcessResult.success(existing);
        } catch (Exception ex) { return DataProcessResult.error(ex.getMessage()); }
    }

    public DataProcessResult<Map<String, Object>> getCampaignMetrics(String scopeId, String campaignId) {
        try {
            var doc = db.getById(config.metricsIndex, "campaign:" + scopeId + ":" + campaignId);
            return DataProcessResult.success(doc != null ? doc : Map.of("campaignId", campaignId, "status", "no_data"));
        } catch (Exception ex) { return DataProcessResult.error(ex.getMessage()); }
    }

    // ═══ CONFIGURATION (FREEDOM) ═════════════════════════════════

    public DataProcessResult<Map<String, Object>> getConfig(String scopeId) {
        try { return DataProcessResult.success(loadConfig(scopeId)); }
        catch (Exception ex) { return DataProcessResult.error(ex.getMessage()); }
    }

    public DataProcessResult<Map<String, Object>> updateConfig(String scopeId, Map<String, Object> cfg) {
        try {
            var doc = op.parseObjectAlternative(cfg);
            doc.put("configId", "analytics-config:" + scopeId);
            doc.put("scopeId", scopeId); doc.put("updatedAt", Instant.now().toString());
            db.upsert(config.configIndex, str(doc, "configId"), doc);
            return DataProcessResult.success(doc);
        } catch (Exception ex) { return DataProcessResult.error(ex.getMessage()); }
    }

    public DataProcessResult<Map<String, Object>> defineFunnel(String scopeId, Map<String, Object> funnelDef) {
        try {
            var doc = op.parseObjectAlternative(funnelDef);
            if (!doc.containsKey("funnelId") || !doc.containsKey("steps"))
                return DataProcessResult.error("Missing: funnelId, steps");
            doc.put("scopeId", scopeId); doc.put("type", "funnel_definition");
            doc.put("updatedAt", Instant.now().toString());
            db.upsert(config.configIndex, "funnel-def:" + scopeId + ":" + str(doc, "funnelId"), doc);
            return DataProcessResult.success(doc);
        } catch (Exception ex) { return DataProcessResult.error(ex.getMessage()); }
    }

    public DataProcessResult<Map<String, Object>> defineAlert(String scopeId, Map<String, Object> alertDef) {
        try {
            var doc = op.parseObjectAlternative(alertDef);
            if (!doc.containsKey("alertId") || !doc.containsKey("metric") || !doc.containsKey("threshold"))
                return DataProcessResult.error("Missing: alertId, metric, threshold");
            doc.put("scopeId", scopeId); doc.put("type", "alert_definition");
            doc.put("updatedAt", Instant.now().toString());
            db.upsert(config.configIndex, "alert-def:" + scopeId + ":" + str(doc, "alertId"), doc);
            return DataProcessResult.success(doc);
        } catch (Exception ex) { return DataProcessResult.error(ex.getMessage()); }
    }

    // ═══ PRIVATE HELPERS ═════════════════════════════════════════

    private Map<String, Object> loadConfig(String scopeId) {
        try { var d = db.getById(config.configIndex, "analytics-config:" + scopeId); return d != null ? d : defaultConfig(scopeId); }
        catch (Exception e) { return defaultConfig(scopeId); }
    }
    private Map<String, Object> defaultConfig(String scopeId) {
        var m = new HashMap<String, Object>();
        m.put("configId", "analytics-config:" + scopeId); m.put("scopeId", scopeId);
        m.put("aggregationWindows", config.defaultAggregationWindows);
        m.put("rawRetentionDays", config.rawRetentionDays);
        m.put("hourlyRetentionDays", config.hourlyRetentionDays);
        m.put("engagementWeights", Map.of("view", 1.0, "click", 2.0, "like", 3.0, "comment", 5.0, "share", 7.0, "create", 10.0, "purchase", 15.0));
        m.put("customDimensions", List.of("platform", "region", "userTier"));
        m.put("alerts", List.of());
        return m;
    }
    private Map<String, Object> loadFunnelDef(String scopeId, String funnelId) {
        try { return db.getById(config.configIndex, "funnel-def:" + scopeId + ":" + funnelId); }
        catch (Exception e) { return null; }
    }
    private EngagementWeights loadWeights(Map<String, Object> cfg) {
        var w = new EngagementWeights();
        if (cfg.get("engagementWeights") instanceof Map<?, ?> wm) {
            if (wm.get("view") != null) w.view = toDouble(wm.get("view"));
            if (wm.get("click") != null) w.click = toDouble(wm.get("click"));
            if (wm.get("like") != null) w.like = toDouble(wm.get("like"));
            if (wm.get("comment") != null) w.comment = toDouble(wm.get("comment"));
            if (wm.get("share") != null) w.share = toDouble(wm.get("share"));
            if (wm.get("create") != null) w.create = toDouble(wm.get("create"));
            if (wm.get("purchase") != null) w.purchase = toDouble(wm.get("purchase"));
        }
        return w;
    }
    private void publishEvent(String type, Map<String, Object> data) {
        try { queue.publish("analytics-events", Map.of("eventType", type, "data", data, "publishedAt", Instant.now().toString())); }
        catch (Exception e) { /* non-critical */ }
    }
    @SuppressWarnings("unchecked")
    private List<String> getStringList(Map<String, Object> doc, String key) {
        var v = doc.get(key);
        if (v instanceof List<?> list) return list.stream().map(Object::toString).collect(Collectors.toList());
        return List.of();
    }
    private static String str(Map<String, Object> doc, String key) {
        var v = doc.get(key); return v != null ? v.toString() : "";
    }
    private static double toDouble(Object v) {
        if (v instanceof Number n) return n.doubleValue();
        try { return Double.parseDouble(v.toString()); } catch (Exception e) { return 0; }
    }
    private static long toLong(Object v) {
        if (v instanceof Number n) return n.longValue();
        try { return Long.parseLong(v.toString()); } catch (Exception e) { return 0; }
    }
    private static int toInt(Object v) {
        if (v instanceof Number n) return n.intValue();
        try { return Integer.parseInt(v.toString()); } catch (Exception e) { return 0; }
    }
}
