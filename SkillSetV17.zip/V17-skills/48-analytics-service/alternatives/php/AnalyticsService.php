<?php
// XIIGen Analytics Service — Skill 48 | PHP/Laravel Alternative
// Multi-signal analytics engine: event tracking, aggregation, engagement scoring,
// funnel analysis, campaign metrics, real-time counters, alert engine
// Genie DNA: DNA-1 (array), DNA-2 (buildSearchFilter), DNA-5 (DataProcessResult)

namespace XIIGen\Services\Analytics;

use Illuminate\Support\Str;
use Carbon\Carbon;

// ─── Configuration ──────────────────────────────────────────────
class AnalyticsConfig
{
    public function __construct(
        public string $eventsIndex = 'analytics-events',
        public string $metricsIndex = 'analytics-metrics',
        public string $engagementIndex = 'analytics-engagement',
        public string $funnelsIndex = 'analytics-funnels',
        public string $configIndex = 'analytics-config',
        public int $rawRetentionDays = 30,
        public int $hourlyRetentionDays = 90,
        public int $dailyRetentionDays = 365,
        public int $defaultBatchSize = 500,
        public string $counterPrefix = 'analytics:counter:',
    ) {}
}

// ─── Engagement Weights ─────────────────────────────────────────
class EngagementWeights
{
    public function __construct(
        public float $view = 1.0,
        public float $click = 2.0,
        public float $like = 3.0,
        public float $comment = 5.0,
        public float $share = 7.0,
        public float $create = 10.0,
        public float $purchase = 15.0,
    ) {}

    public function toArray(): array
    {
        return [
            'view' => $this->view, 'click' => $this->click, 'like' => $this->like,
            'comment' => $this->comment, 'share' => $this->share,
            'create' => $this->create, 'purchase' => $this->purchase,
        ];
    }

    public static function fromArray(array $data): self
    {
        return new self(
            view: (float) ($data['view'] ?? 1.0),
            click: (float) ($data['click'] ?? 2.0),
            like: (float) ($data['like'] ?? 3.0),
            comment: (float) ($data['comment'] ?? 5.0),
            share: (float) ($data['share'] ?? 7.0),
            create: (float) ($data['create'] ?? 10.0),
            purchase: (float) ($data['purchase'] ?? 15.0),
        );
    }
}

// ─── Time Window Parser ─────────────────────────────────────────
class TimeWindowParser
{
    private const MULTIPLIERS = [
        'h' => 3600,
        'd' => 86400,
        'w' => 604800,
        'm' => 2592000, // 30 days
    ];

    public static function parseSeconds(string $window): int
    {
        $unit = substr($window, -1);
        $value = (int) substr($window, 0, -1);
        if ($value <= 0 || !isset(self::MULTIPLIERS[$unit])) {
            return 3600; // fallback 1h
        }
        return $value * self::MULTIPLIERS[$unit];
    }

    public static function getWindowKey(string $window, \DateTimeInterface $dt): string
    {
        $unit = substr($window, -1);
        $y = $dt->format('Y');
        $m = $dt->format('m');
        $d = $dt->format('d');
        $h = $dt->format('H');

        return match ($unit) {
            'h' => "{$y}-{$m}-{$d}T{$h}",
            'd' => "{$y}-{$m}-{$d}",
            'w' => "{$y}-W" . $dt->format('W'),
            'm' => "{$y}-{$m}",
            default => "{$y}-{$m}-{$d}T{$h}",
        };
    }

    public static function getWindowStart(string $window, \DateTimeInterface $dt): \DateTimeImmutable
    {
        $unit = substr($window, -1);
        $imm = \DateTimeImmutable::createFromInterface($dt);

        return match ($unit) {
            'h' => $imm->setTime((int) $imm->format('H'), 0, 0),
            'd' => $imm->setTime(0, 0, 0),
            'w' => $imm->modify('monday this week')->setTime(0, 0, 0),
            'm' => $imm->setDate((int) $imm->format('Y'), (int) $imm->format('m'), 1)->setTime(0, 0, 0),
            default => $imm->setTime((int) $imm->format('H'), 0, 0),
        };
    }
}

// ─── Data Process Result (DNA-5) ────────────────────────────────
class DataProcessResult
{
    public function __construct(
        public bool $success,
        public mixed $data = null,
        public string $message = '',
    ) {}

    public static function ok(mixed $data, string $message = ''): self
    {
        return new self(true, $data, $message);
    }

    public static function error(string $message): self
    {
        return new self(false, null, $message);
    }
}

// ─── Interfaces (Genie DNA) ────────────────────────────────────
interface IDatabaseService
{
    public function upsert(string $index, string $id, array $doc): void;
    public function getById(string $index, string $id): ?array;
    public function query(string $index, array $filter, int $limit, int $offset): array;
    public function count(string $index, array $filter): int;
    public function delete(string $index, string $id): void;
}

interface IQueueService
{
    public function publish(string $channel, array $message): void;
}

interface IObjectProcessor
{
    public function parseObjectAlternative(mixed $obj): array;
    public function buildSearchFilter(array $filter): array;
}

interface ICacheService
{
    public function increment(string $key, int $delta = 1): int;
    public function get(string $key): ?string;
}

// ─── Analytics Service Interface ────────────────────────────────
interface IAnalyticsService
{
    // Event Collection
    public function trackEvent(array $eventData): DataProcessResult;
    public function trackBatch(array $events): DataProcessResult;
    public function incrementCounter(string $scopeId, string $counterName, int $delta = 1): DataProcessResult;
    public function getCounter(string $scopeId, string $counterName): DataProcessResult;

    // Metric Aggregation
    public function aggregateWindow(string $scopeId, string $window, \DateTimeInterface $windowStart): DataProcessResult;
    public function getMetrics(string $scopeId, ?string $eventType = null, ?\DateTimeInterface $startDate = null, ?\DateTimeInterface $endDate = null, ?string $dimension = null, int $page = 0, int $pageSize = 100): DataProcessResult;
    public function getTimeSeries(string $scopeId, string $metricName, string $window, \DateTimeInterface $startDate, \DateTimeInterface $endDate): DataProcessResult;
    public function compactMetrics(string $scopeId): DataProcessResult;

    // Engagement Scoring
    public function calculateEngagement(string $scopeId, string $entityId): DataProcessResult;
    public function getEngagementScore(string $scopeId, string $entityId): DataProcessResult;
    public function recalculateAllScores(string $scopeId): DataProcessResult;

    // Funnel Analysis
    public function trackFunnelStep(string $scopeId, string $funnelId, string $entityId, string $stepName): DataProcessResult;
    public function getFunnelAnalysis(string $scopeId, string $funnelId, ?\DateTimeInterface $startDate = null, ?\DateTimeInterface $endDate = null): DataProcessResult;
    public function getEntityFunnelProgress(string $scopeId, string $funnelId, string $entityId): DataProcessResult;

    // Campaign Metrics
    public function trackCampaignEvent(array $campaignEvent): DataProcessResult;
    public function getCampaignMetrics(string $scopeId, string $campaignId): DataProcessResult;

    // Configuration (FREEDOM)
    public function getConfig(string $scopeId): DataProcessResult;
    public function updateConfig(string $scopeId, array $config): DataProcessResult;
    public function defineFunnel(string $scopeId, array $funnelDef): DataProcessResult;
    public function defineAlert(string $scopeId, array $alertDef): DataProcessResult;
}

// ─── Analytics Service Implementation ───────────────────────────
class AnalyticsService implements IAnalyticsService
{
    public function __construct(
        private IDatabaseService $db,
        private IQueueService $queue,
        private IObjectProcessor $processor,
        private ICacheService $cache,
        private AnalyticsConfig $config = new AnalyticsConfig(),
    ) {}

    // ── Event Collection ────────────────────────────────────────

    public function trackEvent(array $eventData): DataProcessResult
    {
        try {
            $scopeId = $eventData['scopeId'] ?? null;
            $eventType = $eventData['eventType'] ?? null;
            if (!$scopeId || !$eventType) {
                return DataProcessResult::error('scopeId and eventType are required');
            }

            $eventId = $eventData['eventId'] ?? (string) Str::uuid();
            $now = Carbon::now()->toIso8601String();

            $doc = array_merge($eventData, [
                'eventId' => $eventId,
                'scopeId' => $scopeId,
                'eventType' => $eventType,
                'timestamp' => $eventData['timestamp'] ?? $now,
                'createdAt' => $now,
            ]);

            $this->db->upsert($this->config->eventsIndex, $eventId, $doc);
            $this->publishEvent('AnalyticsEventTracked', $doc);
            $this->checkAlerts($scopeId, $doc);

            return DataProcessResult::ok($doc, 'Event tracked');
        } catch (\Throwable $e) {
            return DataProcessResult::error("TrackEvent failed: {$e->getMessage()}");
        }
    }

    public function trackBatch(array $events): DataProcessResult
    {
        try {
            $tracked = 0;
            foreach ($events as $event) {
                $result = $this->trackEvent($event);
                if ($result->success) {
                    $tracked++;
                }
            }
            return DataProcessResult::ok($tracked, "Tracked {$tracked}/{$count} events" . ($count = count($events)) ? '' : '');
        } catch (\Throwable $e) {
            return DataProcessResult::error("TrackBatch failed: {$e->getMessage()}");
        }
    }

    public function incrementCounter(string $scopeId, string $counterName, int $delta = 1): DataProcessResult
    {
        try {
            $key = $this->config->counterPrefix . $scopeId . ':' . $counterName;
            $newVal = $this->cache->increment($key, $delta);
            return DataProcessResult::ok($newVal, 'Counter incremented');
        } catch (\Throwable $e) {
            return DataProcessResult::error("IncrementCounter failed: {$e->getMessage()}");
        }
    }

    public function getCounter(string $scopeId, string $counterName): DataProcessResult
    {
        try {
            $key = $this->config->counterPrefix . $scopeId . ':' . $counterName;
            $val = $this->cache->get($key);
            return DataProcessResult::ok((int) ($val ?? 0), 'Counter retrieved');
        } catch (\Throwable $e) {
            return DataProcessResult::error("GetCounter failed: {$e->getMessage()}");
        }
    }

    // ── Metric Aggregation (MACHINE) ────────────────────────────

    public function aggregateWindow(
        string $scopeId,
        string $window,
        \DateTimeInterface $windowStart,
    ): DataProcessResult {
        try {
            $seconds = TimeWindowParser::parseSeconds($window);
            $windowEnd = \DateTimeImmutable::createFromInterface($windowStart)
                ->modify("+{$seconds} seconds");

            $filter = $this->processor->buildSearchFilter([
                'scopeId' => $scopeId,
                'timestamp' => [
                    'gte' => $windowStart->format('c'),
                    'lt' => $windowEnd->format('c'),
                ],
            ]);

            $events = $this->db->query($this->config->eventsIndex, $filter, 10000, 0);
            $windowKey = TimeWindowParser::getWindowKey($window, $windowStart);

            // Group by eventType
            $groups = [];
            foreach ($events as $evt) {
                $type = $evt['eventType'] ?? 'unknown';
                if (!isset($groups[$type])) {
                    $groups[$type] = ['count' => 0, 'entities' => []];
                }
                $groups[$type]['count']++;
                $entityId = $evt['entityId'] ?? null;
                if ($entityId && !in_array($entityId, $groups[$type]['entities'], true)) {
                    $groups[$type]['entities'][] = $entityId;
                }
            }

            // Group by custom dimensions
            $dimensions = [];
            foreach (['platform', 'region', 'userTier'] as $dim) {
                $dimGroups = [];
                foreach ($events as $evt) {
                    $dimVal = $evt[$dim] ?? null;
                    if ($dimVal !== null) {
                        $dimGroups[$dimVal] = ($dimGroups[$dimVal] ?? 0) + 1;
                    }
                }
                if (!empty($dimGroups)) {
                    $dimensions[$dim] = $dimGroups;
                }
            }

            $metricId = "{$scopeId}:{$window}:{$windowKey}";
            $metricDoc = [
                'metricId' => $metricId,
                'scopeId' => $scopeId,
                'window' => $window,
                'windowKey' => $windowKey,
                'windowStart' => $windowStart->format('c'),
                'windowEnd' => $windowEnd->format('c'),
                'totalEvents' => count($events),
                'eventTypes' => $groups,
                'dimensions' => $dimensions,
                'aggregatedAt' => Carbon::now()->toIso8601String(),
            ];

            $this->db->upsert($this->config->metricsIndex, $metricId, $metricDoc);
            $this->publishEvent('MetricAggregated', $metricDoc);

            return DataProcessResult::ok($metricDoc, "Aggregated {$window} window: " . count($events) . ' events');
        } catch (\Throwable $e) {
            return DataProcessResult::error("AggregateWindow failed: {$e->getMessage()}");
        }
    }

    public function getMetrics(
        string $scopeId,
        ?string $eventType = null,
        ?\DateTimeInterface $startDate = null,
        ?\DateTimeInterface $endDate = null,
        ?string $dimension = null,
        int $page = 0,
        int $pageSize = 100,
    ): DataProcessResult {
        try {
            $filterData = ['scopeId' => $scopeId];
            if ($eventType) {
                $filterData['window'] = $eventType;
            }
            if ($startDate) {
                $filterData['windowStart'] = ['gte' => $startDate->format('c')];
            }
            if ($endDate) {
                $filterData['windowEnd'] = ['lte' => $endDate->format('c')];
            }

            $filter = $this->processor->buildSearchFilter($filterData);
            $metrics = $this->db->query($this->config->metricsIndex, $filter, $pageSize, $page * $pageSize);

            return DataProcessResult::ok($metrics, 'Metrics retrieved: ' . count($metrics));
        } catch (\Throwable $e) {
            return DataProcessResult::error("GetMetrics failed: {$e->getMessage()}");
        }
    }

    public function getTimeSeries(
        string $scopeId,
        string $metricName,
        string $window,
        \DateTimeInterface $startDate,
        \DateTimeInterface $endDate,
    ): DataProcessResult {
        try {
            // Generate expected window keys between start and end
            $seconds = TimeWindowParser::parseSeconds($window);
            $points = [];
            $current = \DateTimeImmutable::createFromInterface($startDate);
            $end = \DateTimeImmutable::createFromInterface($endDate);

            while ($current <= $end) {
                $key = TimeWindowParser::getWindowKey($window, $current);
                $metricId = "{$scopeId}:{$window}:{$key}";
                $doc = $this->db->getById($this->config->metricsIndex, $metricId);

                $value = 0;
                if ($doc) {
                    if ($metricName === 'totalEvents') {
                        $value = (int) ($doc['totalEvents'] ?? 0);
                    } else {
                        $value = (int) ($doc['eventTypes'][$metricName]['count'] ?? 0);
                    }
                }

                $points[] = [
                    'windowKey' => $key,
                    'timestamp' => $current->format('c'),
                    'metric' => $metricName,
                    'value' => $value,
                ];

                $current = $current->modify("+{$seconds} seconds");
            }

            return DataProcessResult::ok($points, 'Time series: ' . count($points) . ' points');
        } catch (\Throwable $e) {
            return DataProcessResult::error("GetTimeSeries failed: {$e->getMessage()}");
        }
    }

    public function compactMetrics(string $scopeId): DataProcessResult
    {
        try {
            $now = Carbon::now();
            $compacted = 0;

            // Remove raw events older than retention
            $rawCutoff = $now->copy()->subDays($this->config->rawRetentionDays);
            $filter = $this->processor->buildSearchFilter([
                'scopeId' => $scopeId,
                'timestamp' => ['lt' => $rawCutoff->toIso8601String()],
            ]);
            $oldEvents = $this->db->query($this->config->eventsIndex, $filter, 10000, 0);
            foreach ($oldEvents as $evt) {
                $this->db->delete($this->config->eventsIndex, $evt['eventId'] ?? '');
                $compacted++;
            }

            // Remove hourly metrics older than retention
            $hourlyCutoff = $now->copy()->subDays($this->config->hourlyRetentionDays);
            $hFilter = $this->processor->buildSearchFilter([
                'scopeId' => $scopeId,
                'window' => '1h',
                'windowStart' => ['lt' => $hourlyCutoff->toIso8601String()],
            ]);
            $oldHourly = $this->db->query($this->config->metricsIndex, $hFilter, 10000, 0);
            foreach ($oldHourly as $m) {
                $this->db->delete($this->config->metricsIndex, $m['metricId'] ?? '');
                $compacted++;
            }

            // Remove daily metrics older than retention
            $dailyCutoff = $now->copy()->subDays($this->config->dailyRetentionDays);
            $dFilter = $this->processor->buildSearchFilter([
                'scopeId' => $scopeId,
                'window' => '1d',
                'windowStart' => ['lt' => $dailyCutoff->toIso8601String()],
            ]);
            $oldDaily = $this->db->query($this->config->metricsIndex, $dFilter, 10000, 0);
            foreach ($oldDaily as $m) {
                $this->db->delete($this->config->metricsIndex, $m['metricId'] ?? '');
                $compacted++;
            }

            return DataProcessResult::ok($compacted, "Compacted {$compacted} records");
        } catch (\Throwable $e) {
            return DataProcessResult::error("CompactMetrics failed: {$e->getMessage()}");
        }
    }

    // ── Engagement Scoring ──────────────────────────────────────

    public function calculateEngagement(string $scopeId, string $entityId): DataProcessResult
    {
        try {
            // Load weights from config (FREEDOM)
            $configDoc = $this->loadConfig($scopeId);
            $weightsData = $configDoc['engagementWeights'] ?? [];
            $weights = !empty($weightsData)
                ? EngagementWeights::fromArray($weightsData)
                : new EngagementWeights();

            // Query events for this entity in last 30 days
            $since = Carbon::now()->subDays(30);
            $filter = $this->processor->buildSearchFilter([
                'scopeId' => $scopeId,
                'entityId' => $entityId,
                'timestamp' => ['gte' => $since->toIso8601String()],
            ]);
            $events = $this->db->query($this->config->eventsIndex, $filter, 10000, 0);

            // Calculate weighted score with time decay
            $now = Carbon::now();
            $totalScore = 0.0;
            $eventCounts = [];
            $weightMap = $weights->toArray();

            foreach ($events as $evt) {
                $type = $evt['eventType'] ?? 'view';
                $weight = $weightMap[$type] ?? 1.0;

                // Time decay: events lose value over 30 days
                $evtTime = Carbon::parse($evt['timestamp'] ?? $now);
                $daysAgo = max(0, $now->diffInDays($evtTime));
                $decayFactor = max(0.1, 1.0 - ($daysAgo / 30.0));

                $totalScore += $weight * $decayFactor;
                $eventCounts[$type] = ($eventCounts[$type] ?? 0) + 1;
            }

            // Normalize by days active
            $firstEvent = !empty($events) ? Carbon::parse($events[0]['timestamp'] ?? $now) : $now;
            $daysActive = max(1, $now->diffInDays($firstEvent) + 1);
            $normalizedScore = round($totalScore / $daysActive, 4);

            $engagementDoc = [
                'engagementId' => "{$scopeId}:{$entityId}",
                'scopeId' => $scopeId,
                'entityId' => $entityId,
                'score' => $normalizedScore,
                'rawScore' => round($totalScore, 4),
                'totalEvents' => count($events),
                'eventBreakdown' => $eventCounts,
                'daysActive' => $daysActive,
                'periodDays' => 30,
                'calculatedAt' => $now->toIso8601String(),
            ];

            $this->db->upsert(
                $this->config->engagementIndex,
                "{$scopeId}:{$entityId}",
                $engagementDoc
            );
            $this->publishEvent('EngagementScoreUpdated', $engagementDoc);

            return DataProcessResult::ok($engagementDoc, "Engagement score: {$normalizedScore}");
        } catch (\Throwable $e) {
            return DataProcessResult::error("CalculateEngagement failed: {$e->getMessage()}");
        }
    }

    public function getEngagementScore(string $scopeId, string $entityId): DataProcessResult
    {
        try {
            $doc = $this->db->getById($this->config->engagementIndex, "{$scopeId}:{$entityId}");
            if (!$doc) {
                return DataProcessResult::ok(0.0, 'No engagement data found');
            }
            return DataProcessResult::ok((float) ($doc['score'] ?? 0.0), 'Score retrieved');
        } catch (\Throwable $e) {
            return DataProcessResult::error("GetEngagementScore failed: {$e->getMessage()}");
        }
    }

    public function recalculateAllScores(string $scopeId): DataProcessResult
    {
        try {
            $filter = $this->processor->buildSearchFilter(['scopeId' => $scopeId]);
            $existing = $this->db->query($this->config->engagementIndex, $filter, 10000, 0);

            $recalculated = 0;
            foreach ($existing as $eng) {
                $entityId = $eng['entityId'] ?? null;
                if ($entityId) {
                    $result = $this->calculateEngagement($scopeId, $entityId);
                    if ($result->success) {
                        $recalculated++;
                    }
                }
            }

            return DataProcessResult::ok($recalculated, "Recalculated {$recalculated} scores");
        } catch (\Throwable $e) {
            return DataProcessResult::error("RecalculateAllScores failed: {$e->getMessage()}");
        }
    }

    // ── Funnel Analysis ─────────────────────────────────────────

    public function trackFunnelStep(
        string $scopeId,
        string $funnelId,
        string $entityId,
        string $stepName,
    ): DataProcessResult {
        try {
            // Load funnel definition (FREEDOM)
            $funnelDef = $this->loadFunnelDef($scopeId, $funnelId);
            if (!$funnelDef) {
                return DataProcessResult::error("Funnel '{$funnelId}' not defined");
            }

            $steps = $funnelDef['steps'] ?? [];
            $timeoutHours = (int) ($funnelDef['timeoutHours'] ?? 72);
            $stepIndex = array_search($stepName, $steps, true);
            if ($stepIndex === false) {
                return DataProcessResult::error("Step '{$stepName}' not found in funnel '{$funnelId}'");
            }

            // Load or create progress document
            $progressId = "{$scopeId}:{$funnelId}:{$entityId}";
            $progress = $this->db->getById($this->config->funnelsIndex, $progressId);
            $now = Carbon::now();

            if (!$progress) {
                $progress = [
                    'progressId' => $progressId,
                    'scopeId' => $scopeId,
                    'funnelId' => $funnelId,
                    'entityId' => $entityId,
                    'completedSteps' => [],
                    'stepTimestamps' => [],
                    'startedAt' => $now->toIso8601String(),
                    'status' => 'in_progress',
                ];
            }

            // Check timeout — restart if expired
            $startedAt = Carbon::parse($progress['startedAt'] ?? $now);
            $hoursSinceStart = $now->diffInHours($startedAt);
            if ($hoursSinceStart > $timeoutHours && $stepIndex === 0) {
                // Restart funnel
                $progress['completedSteps'] = [];
                $progress['stepTimestamps'] = [];
                $progress['startedAt'] = $now->toIso8601String();
                $progress['status'] = 'in_progress';
            } elseif ($hoursSinceStart > $timeoutHours) {
                return DataProcessResult::error('Funnel timed out — restart from step 0');
            }

            // Validate step ordering: must complete previous steps first
            $completedSteps = $progress['completedSteps'] ?? [];
            for ($i = 0; $i < $stepIndex; $i++) {
                if (!in_array($steps[$i], $completedSteps, true)) {
                    return DataProcessResult::error(
                        "Must complete step '{$steps[$i]}' before '{$stepName}'"
                    );
                }
            }

            // Skip if already completed
            if (in_array($stepName, $completedSteps, true)) {
                return DataProcessResult::ok($progress, 'Step already completed');
            }

            // Record step
            $completedSteps[] = $stepName;
            $progress['completedSteps'] = $completedSteps;
            $stepTimestamps = $progress['stepTimestamps'] ?? [];
            $stepTimestamps[$stepName] = $now->toIso8601String();
            $progress['stepTimestamps'] = $stepTimestamps;

            $this->publishEvent('FunnelStepCompleted', [
                'scopeId' => $scopeId,
                'funnelId' => $funnelId,
                'entityId' => $entityId,
                'stepName' => $stepName,
                'stepIndex' => $stepIndex,
                'totalSteps' => count($steps),
            ]);

            // Check if funnel is complete
            if (count($completedSteps) >= count($steps)) {
                $progress['status'] = 'completed';
                $progress['completedAt'] = $now->toIso8601String();

                // Calculate duration
                $started = Carbon::parse($progress['startedAt']);
                $progress['durationSeconds'] = $now->diffInSeconds($started);

                $this->publishEvent('FunnelCompleted', [
                    'scopeId' => $scopeId,
                    'funnelId' => $funnelId,
                    'entityId' => $entityId,
                    'durationSeconds' => $progress['durationSeconds'],
                ]);
            }

            $this->db->upsert($this->config->funnelsIndex, $progressId, $progress);

            return DataProcessResult::ok($progress, "Step '{$stepName}' recorded");
        } catch (\Throwable $e) {
            return DataProcessResult::error("TrackFunnelStep failed: {$e->getMessage()}");
        }
    }

    public function getFunnelAnalysis(
        string $scopeId,
        string $funnelId,
        ?\DateTimeInterface $startDate = null,
        ?\DateTimeInterface $endDate = null,
    ): DataProcessResult {
        try {
            $funnelDef = $this->loadFunnelDef($scopeId, $funnelId);
            if (!$funnelDef) {
                return DataProcessResult::error("Funnel '{$funnelId}' not defined");
            }

            $filterData = ['scopeId' => $scopeId, 'funnelId' => $funnelId];
            if ($startDate) {
                $filterData['startedAt'] = ['gte' => $startDate->format('c')];
            }
            if ($endDate) {
                $filterData['startedAt'] = array_merge(
                    $filterData['startedAt'] ?? [],
                    ['lte' => $endDate->format('c')]
                );
            }

            $filter = $this->processor->buildSearchFilter($filterData);
            $allProgress = $this->db->query($this->config->funnelsIndex, $filter, 10000, 0);

            $steps = $funnelDef['steps'] ?? [];
            $stepCounts = [];
            foreach ($steps as $step) {
                $stepCounts[$step] = 0;
            }

            $totalStarted = count($allProgress);
            $totalCompleted = 0;
            $totalDuration = 0;

            foreach ($allProgress as $p) {
                $completed = $p['completedSteps'] ?? [];
                foreach ($completed as $cs) {
                    if (isset($stepCounts[$cs])) {
                        $stepCounts[$cs]++;
                    }
                }
                if (($p['status'] ?? '') === 'completed') {
                    $totalCompleted++;
                    $totalDuration += (int) ($p['durationSeconds'] ?? 0);
                }
            }

            // Build step-by-step conversion rates
            $stepAnalysis = [];
            $prevCount = $totalStarted;
            foreach ($steps as $i => $step) {
                $count = $stepCounts[$step];
                $conversionFromPrev = $prevCount > 0 ? round($count / $prevCount, 4) : 0;
                $conversionFromStart = $totalStarted > 0 ? round($count / $totalStarted, 4) : 0;

                $stepAnalysis[] = [
                    'step' => $step,
                    'stepIndex' => $i,
                    'reached' => $count,
                    'conversionFromPrevious' => $conversionFromPrev,
                    'conversionFromStart' => $conversionFromStart,
                    'dropoff' => $prevCount - $count,
                ];
                $prevCount = $count;
            }

            $analysis = [
                'funnelId' => $funnelId,
                'scopeId' => $scopeId,
                'totalStarted' => $totalStarted,
                'totalCompleted' => $totalCompleted,
                'overallConversion' => $totalStarted > 0 ? round($totalCompleted / $totalStarted, 4) : 0,
                'avgDurationSeconds' => $totalCompleted > 0 ? round($totalDuration / $totalCompleted) : 0,
                'steps' => $stepAnalysis,
                'analyzedAt' => Carbon::now()->toIso8601String(),
            ];

            return DataProcessResult::ok($analysis, 'Funnel analysis complete');
        } catch (\Throwable $e) {
            return DataProcessResult::error("GetFunnelAnalysis failed: {$e->getMessage()}");
        }
    }

    public function getEntityFunnelProgress(
        string $scopeId,
        string $funnelId,
        string $entityId,
    ): DataProcessResult {
        try {
            $progressId = "{$scopeId}:{$funnelId}:{$entityId}";
            $doc = $this->db->getById($this->config->funnelsIndex, $progressId);
            if (!$doc) {
                return DataProcessResult::ok(null, 'No progress found');
            }
            return DataProcessResult::ok($doc, 'Progress retrieved');
        } catch (\Throwable $e) {
            return DataProcessResult::error("GetEntityFunnelProgress failed: {$e->getMessage()}");
        }
    }

    // ── Campaign Metrics ────────────────────────────────────────

    public function trackCampaignEvent(array $campaignEvent): DataProcessResult
    {
        try {
            $scopeId = $campaignEvent['scopeId'] ?? null;
            $campaignId = $campaignEvent['campaignId'] ?? null;
            $action = $campaignEvent['action'] ?? null;

            if (!$scopeId || !$campaignId || !$action) {
                return DataProcessResult::error('scopeId, campaignId, and action are required');
            }

            $validActions = ['sent', 'opened', 'clicked', 'converted'];
            if (!in_array($action, $validActions, true)) {
                return DataProcessResult::error("Invalid action: {$action}. Valid: " . implode(', ', $validActions));
            }

            // Increment campaign counter
            $counterKey = "campaign:{$campaignId}:{$action}";
            $this->incrementCounter($scopeId, $counterKey);

            // Load or create campaign metrics doc
            $metricsId = "{$scopeId}:campaign:{$campaignId}";
            $metrics = $this->db->getById($this->config->metricsIndex, $metricsId);

            if (!$metrics) {
                $metrics = [
                    'metricsId' => $metricsId,
                    'scopeId' => $scopeId,
                    'campaignId' => $campaignId,
                    'type' => 'campaign',
                    'sent' => 0,
                    'opened' => 0,
                    'clicked' => 0,
                    'converted' => 0,
                    'createdAt' => Carbon::now()->toIso8601String(),
                ];
            }

            $metrics[$action] = (int) ($metrics[$action] ?? 0) + 1;
            $metrics['updatedAt'] = Carbon::now()->toIso8601String();

            // Calculate rates
            $sent = max(1, (int) ($metrics['sent'] ?? 1));
            $metrics['openRate'] = round((int) ($metrics['opened'] ?? 0) / $sent, 4);
            $metrics['clickRate'] = round((int) ($metrics['clicked'] ?? 0) / $sent, 4);
            $metrics['conversionRate'] = round((int) ($metrics['converted'] ?? 0) / $sent, 4);

            $this->db->upsert($this->config->metricsIndex, $metricsId, $metrics);
            $this->publishEvent('CampaignMetricsUpdated', $metrics);

            return DataProcessResult::ok($metrics, "Campaign event '{$action}' tracked");
        } catch (\Throwable $e) {
            return DataProcessResult::error("TrackCampaignEvent failed: {$e->getMessage()}");
        }
    }

    public function getCampaignMetrics(string $scopeId, string $campaignId): DataProcessResult
    {
        try {
            $metricsId = "{$scopeId}:campaign:{$campaignId}";
            $doc = $this->db->getById($this->config->metricsIndex, $metricsId);
            if (!$doc) {
                return DataProcessResult::ok(null, 'No campaign metrics found');
            }
            return DataProcessResult::ok($doc, 'Campaign metrics retrieved');
        } catch (\Throwable $e) {
            return DataProcessResult::error("GetCampaignMetrics failed: {$e->getMessage()}");
        }
    }

    // ── Configuration (FREEDOM) ─────────────────────────────────

    public function getConfig(string $scopeId): DataProcessResult
    {
        try {
            $config = $this->loadConfig($scopeId);
            return DataProcessResult::ok($config, 'Config retrieved');
        } catch (\Throwable $e) {
            return DataProcessResult::error("GetConfig failed: {$e->getMessage()}");
        }
    }

    public function updateConfig(string $scopeId, array $config): DataProcessResult
    {
        try {
            $existing = $this->loadConfig($scopeId);
            $merged = array_merge($existing, $config, [
                'scopeId' => $scopeId,
                'updatedAt' => Carbon::now()->toIso8601String(),
            ]);
            $this->db->upsert($this->config->configIndex, "config:{$scopeId}", $merged);
            return DataProcessResult::ok($merged, 'Config updated');
        } catch (\Throwable $e) {
            return DataProcessResult::error("UpdateConfig failed: {$e->getMessage()}");
        }
    }

    public function defineFunnel(string $scopeId, array $funnelDef): DataProcessResult
    {
        try {
            $funnelId = $funnelDef['funnelId'] ?? null;
            if (!$funnelId) {
                return DataProcessResult::error('funnelId is required');
            }
            if (empty($funnelDef['steps']) || !is_array($funnelDef['steps'])) {
                return DataProcessResult::error('steps array is required');
            }

            $doc = array_merge($funnelDef, [
                'scopeId' => $scopeId,
                'type' => 'funnel_definition',
                'createdAt' => $funnelDef['createdAt'] ?? Carbon::now()->toIso8601String(),
                'updatedAt' => Carbon::now()->toIso8601String(),
            ]);

            $this->db->upsert($this->config->configIndex, "funnel:{$scopeId}:{$funnelId}", $doc);
            return DataProcessResult::ok($doc, "Funnel '{$funnelId}' defined");
        } catch (\Throwable $e) {
            return DataProcessResult::error("DefineFunnel failed: {$e->getMessage()}");
        }
    }

    public function defineAlert(string $scopeId, array $alertDef): DataProcessResult
    {
        try {
            $alertId = $alertDef['alertId'] ?? (string) Str::uuid();
            $metric = $alertDef['metric'] ?? null;
            $threshold = $alertDef['threshold'] ?? null;
            $condition = $alertDef['condition'] ?? null;

            if (!$metric || $threshold === null || !$condition) {
                return DataProcessResult::error('metric, threshold, and condition are required');
            }

            $validConditions = ['gt', 'lt', 'gte', 'lte', 'eq'];
            if (!in_array($condition, $validConditions, true)) {
                return DataProcessResult::error("Invalid condition: {$condition}. Valid: " . implode(', ', $validConditions));
            }

            $doc = array_merge($alertDef, [
                'alertId' => $alertId,
                'scopeId' => $scopeId,
                'type' => 'alert_definition',
                'metric' => $metric,
                'threshold' => $threshold,
                'condition' => $condition,
                'enabled' => $alertDef['enabled'] ?? true,
                'createdAt' => Carbon::now()->toIso8601String(),
            ]);

            $this->db->upsert($this->config->configIndex, "alert:{$scopeId}:{$alertId}", $doc);
            return DataProcessResult::ok($doc, "Alert '{$alertId}' defined");
        } catch (\Throwable $e) {
            return DataProcessResult::error("DefineAlert failed: {$e->getMessage()}");
        }
    }

    // ── Private Helpers ─────────────────────────────────────────

    private function loadConfig(string $scopeId): array
    {
        $doc = $this->db->getById($this->config->configIndex, "config:{$scopeId}");
        if ($doc) {
            return $doc;
        }
        // Return defaults
        return [
            'scopeId' => $scopeId,
            'aggregationWindows' => ['1h', '1d', '7d', '30d'],
            'engagementWeights' => (new EngagementWeights())->toArray(),
            'defaultFunnelTimeoutHours' => 72,
            'retentionDays' => [
                'raw' => 30,
                'hourly' => 90,
                'daily' => 365,
            ],
        ];
    }

    private function loadFunnelDef(string $scopeId, string $funnelId): ?array
    {
        return $this->db->getById($this->config->configIndex, "funnel:{$scopeId}:{$funnelId}");
    }

    private function publishEvent(string $eventType, array $data): void
    {
        try {
            $this->queue->publish($eventType, array_merge($data, [
                'eventType' => $eventType,
                'publishedAt' => Carbon::now()->toIso8601String(),
            ]));
        } catch (\Throwable $e) {
            // Log but don't fail the operation
        }
    }

    private function checkAlerts(string $scopeId, array $event): void
    {
        try {
            $filter = $this->processor->buildSearchFilter([
                'scopeId' => $scopeId,
                'type' => 'alert_definition',
                'enabled' => true,
            ]);
            $alerts = $this->db->query($this->config->configIndex, $filter, 100, 0);

            foreach ($alerts as $alert) {
                $metric = $alert['metric'] ?? null;
                $threshold = (float) ($alert['threshold'] ?? 0);
                $condition = $alert['condition'] ?? 'gt';

                // Get current value for the metric from event or counter
                $currentValue = (float) ($event[$metric] ?? 0);
                if ($currentValue === 0.0) {
                    $counterResult = $this->getCounter($scopeId, $metric);
                    if ($counterResult->success) {
                        $currentValue = (float) $counterResult->data;
                    }
                }

                $triggered = match ($condition) {
                    'gt' => $currentValue > $threshold,
                    'lt' => $currentValue < $threshold,
                    'gte' => $currentValue >= $threshold,
                    'lte' => $currentValue <= $threshold,
                    'eq' => abs($currentValue - $threshold) < 0.001,
                    default => false,
                };

                if ($triggered) {
                    $this->publishEvent('AlertTriggered', [
                        'alertId' => $alert['alertId'] ?? 'unknown',
                        'scopeId' => $scopeId,
                        'metric' => $metric,
                        'condition' => $condition,
                        'threshold' => $threshold,
                        'currentValue' => $currentValue,
                    ]);
                }
            }
        } catch (\Throwable $e) {
            // Alerts are best-effort, don't fail the main operation
        }
    }
}
