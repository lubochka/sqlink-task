---
skill_id: "48"
name: "analytics-service"
title: "Analytics Service"
layer: "L9: Social Engine"
version: "17.0"
status: "active"
dependencies:
  - "01-core-interfaces"
  - "02-object-processor"
  - "03-elasticsearch-datastore"
  - "04-redis-queue-service"
  - "43-calculator-metrics"
dotnet_namespace: "XIIGen.Services.Analytics"
di_registration: "services.AddXIIGenAnalyticsService()"
es_indices:
  - "analytics-events"
  - "analytics-metrics"
  - "analytics-funnels"
  - "analytics-config"
genie_dna:
  - "DNA-1: All events, metrics, funnels stored as Dictionary<string,object> — any event type, any dimension"
  - "DNA-2: BuildSearchFilter for all queries — eventType, entityId, dateRange, dimensions — skip empty"
  - "DNA-3: Inherits MicroserviceBase with all 19 architectural components"
  - "DNA-5: All operations return DataProcessResult<T>"
  - "DNA-SCOPE: Events scoped by tenantId; users see own metrics; admins see all; system sees aggregate"
  - "DNA-FREEDOM: Aggregation windows, funnel definitions, score weights, retention policies are dynamic documents — admins configure without code changes"
  - "DNA-7: Event-driven — publishes EngagementScoreUpdated, MetricAggregated, FunnelStepCompleted, AlertTriggered; subscribes to ALL service events for tracking"
component_classification:
  machine_parts:
    - "Time-windowed aggregation engine (hourly/daily/weekly/monthly rollups)"
    - "Engagement score calculation (weighted multi-signal formula)"
    - "Funnel progression tracker (ordered step completion with timeout)"
    - "Real-time counter increment/decrement (Redis-backed)"
    - "Metric retention and compaction (downsample old data)"
  freedom_parts:
    - "Aggregation window definitions (admin-configurable time buckets)"
    - "Funnel step definitions (admin-defined conversion paths)"
    - "Engagement score weights (admin-tunable signal importance)"
    - "Alert thresholds (admin-defined metric boundaries)"
    - "Retention policies (admin-managed data lifecycle)"
    - "Custom dimension definitions (admin-added grouping fields)"
---

# Skill 48: Analytics Service

## Purpose
Tracks, aggregates, and analyzes platform activity across all XIIGen services. The Analytics
Service is the observability backbone of the social platform — it collects raw events from
every service, computes time-windowed metric aggregations, tracks multi-step funnels, calculates
engagement scores, and provides campaign performance analysis. It appears in 7 of 8 UML diagrams,
making it alongside Feed and Matching one of the three most critical services in the platform.

Unlike traditional analytics that require predefined schemas, this service follows the Genie DNA
philosophy: every event, metric, and funnel is a dynamic document. New event types, dimensions,
and funnels can be created by admins without code changes.

## Architecture

```
┌──────────────┐     ┌──────────────────────────┐     ┌─────────────────┐
│ Feed Service │────▶│                          │     │  Elasticsearch  │
│ (Skill 46)   │     │   Analytics Service      │────▶│  "analytics-*"  │
├──────────────┤     │                          │     └─────────────────┘
│ Matching     │────▶│  ┌────────────────────┐  │            │
│ (Skill 47)   │     │  │ Event Collector    │  │◀───────────┘
├──────────────┤     │  │ Metric Aggregator  │  │     ┌─────────────────┐
│ Post Service │────▶│  │ Funnel Tracker     │  │────▶│  Redis Cache    │
│ (Skill 52)   │     │  │ Engagement Scorer  │  │     │  counters/cache │
├──────────────┤     │  │ Campaign Analyzer  │  │     └─────────────────┘
│ Auth Service │────▶│  │ Alert Engine       │  │            │
│ (Skill 20)   │     │  └────────────────────┘  │     ┌──────▼──────────┐
├──────────────┤     │                          │     │  Event Bus      │
│ All Services │────▶│                          │     │  Metric events  │
│ (via events) │     └──────────────────────────┘     └─────────────────┘
                              │
                     ┌────────▼────────┐
                     │ Analytics Config│
                     │ (dynamic docs)  │
                     │ windows, funnel │
                     │ weights, alerts │
                     └─────────────────┘
```

## Key Concepts

- **Event Collection** — Every significant platform action (page views, clicks, matches, feed interactions, posts, payments) is captured as a dynamic document with arbitrary metadata. No predefined schema required.
- **Time-Windowed Aggregation** — Raw events are rolled up into configurable time windows (hourly, daily, weekly, monthly). Each aggregation groups by configurable dimensions (eventType, entityId, sourceService). Window definitions are FREEDOM components.
- **Engagement Scoring** — Computes per-entity engagement scores using a weighted multi-signal formula. Signals include: view duration, interaction frequency, content creation rate, response time. Weights are admin-configurable dynamic documents.
- **Funnel Analysis** — Tracks ordered sequences of events (e.g., registration → onboarding → first post → first connection). Funnels have configurable step definitions and timeout windows. Drop-off rates calculated automatically.
- **Campaign Metrics** — Tracks performance of notification campaigns, event promotions, and content distribution with reach, engagement, and conversion metrics.
- **Real-Time Counters** — Redis-backed atomic counters for high-frequency metrics (active users, concurrent sessions, events/second) with periodic flush to Elasticsearch for persistence.
- **Alert Engine** — Monitors metric thresholds and triggers alerts when values cross admin-defined boundaries (e.g., error rate > 5%, engagement drop > 20%).

## Core Operations

### 1. Event Collection
| Method | Description | Returns |
|--------|-------------|---------|
| `TrackEventAsync` | Record a single analytics event | DataProcessResult<Dictionary> |
| `TrackBatchAsync` | Record multiple events atomically | DataProcessResult<int> (count) |
| `IncrementCounterAsync` | Atomic Redis counter increment | DataProcessResult<long> (new value) |
| `GetCounterAsync` | Read current counter value | DataProcessResult<long> |

### 2. Metric Aggregation
| Method | Description | Returns |
|--------|-------------|---------|
| `AggregateWindowAsync` | Run aggregation for a time window | DataProcessResult<Dictionary> |
| `GetMetricsAsync` | Query aggregated metrics with filters | DataProcessResult<List<Dictionary>> |
| `GetTimeSeriesAsync` | Get metric values over time range | DataProcessResult<List<Dictionary>> |
| `CompactMetricsAsync` | Downsample old fine-grained metrics | DataProcessResult<int> (compacted) |

### 3. Engagement Scoring
| Method | Description | Returns |
|--------|-------------|---------|
| `CalculateEngagementAsync` | Compute engagement score for entity | DataProcessResult<Dictionary> |
| `GetEngagementScoreAsync` | Retrieve cached engagement score | DataProcessResult<double> |
| `RecalculateAllScoresAsync` | Batch recalculate all entity scores | DataProcessResult<int> (count) |

### 4. Funnel Analysis
| Method | Description | Returns |
|--------|-------------|---------|
| `TrackFunnelStepAsync` | Record entity completing a funnel step | DataProcessResult<Dictionary> |
| `GetFunnelAnalysisAsync` | Get funnel completion/dropoff rates | DataProcessResult<Dictionary> |
| `GetEntityFunnelProgressAsync` | Get specific entity's funnel state | DataProcessResult<Dictionary> |

### 5. Campaign Metrics
| Method | Description | Returns |
|--------|-------------|---------|
| `TrackCampaignEventAsync` | Record a campaign interaction | DataProcessResult<Dictionary> |
| `GetCampaignMetricsAsync` | Get campaign performance summary | DataProcessResult<Dictionary> |

### 6. Configuration (FREEDOM)
| Method | Description | Returns |
|--------|-------------|---------|
| `GetConfigAsync` | Retrieve analytics configuration | DataProcessResult<Dictionary> |
| `UpdateConfigAsync` | Admin updates windows, weights, alerts | DataProcessResult<Dictionary> |
| `DefineFunnelAsync` | Create/update a funnel definition | DataProcessResult<Dictionary> |
| `DefineAlertAsync` | Create/update an alert threshold | DataProcessResult<Dictionary> |

## DNA Integration

### DNA-1: Dynamic Documents
All analytics data stored as `Dictionary<string, object>` — any event type with any metadata:
```csharp
var analyticsEvent = ObjectProcessor.ParseObjectAlternative(new {
    eventId = Guid.NewGuid().ToString(),
    scopeId = tenantId,
    eventType = "post_interaction",
    entityId = userId,
    targetId = postId,
    action = "like",
    metadata = new { source = "feed", position = 3, sessionDuration = 45.2 },
    dimensions = new { platform = "mobile", region = "us-east", userTier = "premium" },
    timestamp = DateTime.UtcNow
});
await _db.UpsertAsync("analytics-events", analyticsEvent["eventId"].ToString(), analyticsEvent);
```

### DNA-2: BuildSearchFilter
All queries use empty-field skipping:
```csharp
var filter = ObjectProcessor.BuildSearchFilter(new {
    scopeId = tenantId,          // always set (scope isolation)
    eventType = eventTypeFilter, // null if "all types" → skipped
    entityId = entityFilter,     // null if "all entities" → skipped
    timestampGte = startDate,    // null if no start → skipped
    timestampLte = endDate       // null if no end → skipped
});
```

### DNA-5: DataProcessResult
Every operation returns success/failure with data:
```csharp
public async Task<DataProcessResult<Dictionary<string, object>>> TrackEventAsync(
    Dictionary<string, object> eventData, CancellationToken ct)
{
    try {
        // validate, enrich, store
        return DataProcessResult<Dictionary<string, object>>.Success(stored);
    } catch (Exception ex) {
        return DataProcessResult<Dictionary<string, object>>.Error(ex.Message);
    }
}
```

### DNA-SCOPE: Scope Isolation
All queries include scopeId. Users see their own metrics. Admins see tenant-wide. System sees cross-tenant aggregates.

### DNA-FREEDOM: Dynamic Configuration
Analytics configuration stored as dynamic documents in "analytics-config" index:
```json
{
  "configId": "analytics-main",
  "scopeId": "tenant-123",
  "aggregationWindows": ["1h", "1d", "7d", "30d"],
  "engagementWeights": {
    "view": 1.0, "click": 2.0, "like": 3.0, "comment": 5.0,
    "share": 7.0, "create": 10.0, "purchase": 15.0
  },
  "retentionDays": { "raw": 30, "hourly": 90, "daily": 365, "monthly": 1825 },
  "alerts": [
    { "metric": "error_rate", "operator": "gt", "threshold": 0.05, "window": "1h" },
    { "metric": "engagement_drop", "operator": "gt", "threshold": 0.20, "window": "1d" }
  ],
  "customDimensions": ["platform", "region", "userTier", "contentType"]
}
```

## Events

### Published
- `AnalyticsEventTracked` — raw event stored
- `MetricAggregated` — time-window aggregation completed
- `EngagementScoreUpdated` — entity engagement score recalculated
- `FunnelStepCompleted` — entity advanced in a funnel
- `FunnelCompleted` — entity completed all funnel steps
- `AlertTriggered` — metric crossed threshold
- `CampaignMetricsUpdated` — campaign stats refreshed

### Subscribed (from other services)
- `PostCreated`, `PostInteraction` (from Skill 52) → track content events
- `FeedItemIngested`, `FeedItemHidden` (from Skill 46) → track feed engagement
- `MatchScoreUpdated`, `MatchCreated` (from Skill 47) → track matching events
- `UserRegistered`, `UserLoggedIn` (from Skill 20) → track auth events
- `EventRegistered` (from Skill 53) → track event participation
- `PaymentCompleted` (from Skill 56) → track commerce events
- `NotificationSent`, `NotificationClicked` (from Skill 24) → track campaign engagement

## Anti-Patterns

```csharp
// ❌ BAD: Fixed event model class
public class AnalyticsEvent { public string Type; public string UserId; public DateTime Time; }

// ❌ BAD: Hardcoded dimensions
var metrics = events.GroupBy(e => e.Type).Select(g => new { Type = g.Key, Count = g.Count() });

// ❌ BAD: Hardcoded funnel steps
if (step == "register") nextStep = "onboard"; // Should be dynamic config

// ❌ BAD: No scope isolation
var allEvents = await _db.QueryAsync("analytics-events", new {}); // ALL tenants!

// ❌ BAD: Synchronous aggregation blocking request
var result = ComputeHeavyAggregation(); // Should be async background job

// ❌ BAD: Hardcoded engagement weights
double score = views * 1 + clicks * 2 + shares * 5; // Should be dynamic config
```

## Test Scenarios

1. **Track + Query**: Track 100 events of various types → GetMetrics returns correct counts per type
2. **Time-Window Aggregation**: Track events over 3 hours → AggregateWindow("1h") produces 3 hourly rollups
3. **Engagement Score**: Track mixed interactions for user → CalculateEngagement returns weighted score matching config weights
4. **Funnel Progression**: Track steps in order → GetFunnelAnalysis shows correct completion rates
5. **Funnel Timeout**: Track step 1, wait past timeout, track step 2 → new funnel session started
6. **Scope Isolation**: Tenant A events never visible in Tenant B queries
7. **Real-Time Counters**: 1000 concurrent IncrementCounter calls → final value is exactly 1000
8. **Alert Trigger**: Set threshold at 5%, push error_rate to 6% → AlertTriggered event published
9. **Config Update**: Admin changes engagement weights → next CalculateEngagement uses new weights
10. **Metric Compaction**: Raw events older than retention → downsampled to daily granularity
11. **Campaign Tracking**: Track campaign send/open/click events → GetCampaignMetrics returns CTR, open rate
12. **Custom Dimensions**: Add "region" dimension → aggregations automatically group by region
