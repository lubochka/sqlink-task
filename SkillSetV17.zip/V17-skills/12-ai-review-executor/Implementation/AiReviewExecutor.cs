// XIIGen.FlowEngine/StepExecutors/AiReviewExecutor.cs — Skill 12 | .NET 9
// Evaluates multiple AI outputs, scores per criteria, selects best, returns structured review.
// Genie DNA: Dynamic documents (Dictionary), BuildSearchFilter, DataProcessResult per candidate.

using System.Diagnostics;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace XIIGen.FlowEngine.StepExecutors;

// --- Configuration ---
public class AiReviewConfig
{
    public string ReviewModel { get; set; } = "claude-sonnet-4-20250514";
    public string ReviewStrategy { get; set; } = "hybrid";   // ai | rule | hybrid
    public string SelectionStrategy { get; set; } = "highest-total"; // highest-total | highest-minimum | weighted-average
    public Dictionary<string, CriterionConfig> Criteria { get; set; } = new()
    {
        ["correctness"]  = new(0.30, 60),
        ["completeness"] = new(0.25, 50),
        ["codeStyle"]    = new(0.15, 40),
        ["performance"]  = new(0.15, 40),
        ["security"]     = new(0.15, 70),
    };
    public double ApproveThreshold { get; set; } = 80;
    public double ReviseThreshold { get; set; } = 50;
    public bool EnableRuleBasedPreFilter { get; set; } = true;
    public int MaxReviewTokens { get; set; } = 2000;
    public bool SkipReviewIfSingleCandidate { get; set; } = false;
}

public record CriterionConfig(double Weight, double MinScore);

// --- Interfaces (from Skill 01, 06, 07) ---
public interface IStepExecutor
{
    string NodeTypeName { get; }
    Task<StepExecutionResult> ExecuteAsync(StepExecutionContext context, CancellationToken ct = default);
}

public interface IAiDispatcher
{
    Task<Dictionary<string, object>> DispatchAsync(Dictionary<string, object> request, CancellationToken ct = default);
}

public record StepExecutionContext(
    string TraceId, string FlowId, string StepId, string StepType,
    Dictionary<string, object> Input, Dictionary<string, object> Configuration,
    Dictionary<string, object> PreviousOutputs);

public class StepExecutionResult
{
    public bool Success { get; set; }
    public Dictionary<string, object> Output { get; set; } = new();
    public Dictionary<string, object> DebugData { get; set; } = new();
    public long DurationMs { get; set; }
    public string? Error { get; set; }

    public static StepExecutionResult Ok(Dictionary<string, object> output, Dictionary<string, object>? debug = null)
        => new() { Success = true, Output = output, DebugData = debug ?? new() };
    public static StepExecutionResult Fail(string error)
        => new() { Success = false, Error = error };
}

// --- Data Process Result (DNA-5) ---
public class DataProcessResult
{
    public bool Success { get; set; }
    public Dictionary<string, object> Item { get; set; } = new();
    public string? Error { get; set; }
    public Dictionary<string, object> Metadata { get; set; } = new();
}

// --- Main Executor ---
public partial class AiReviewExecutor : IStepExecutor
{
    private readonly AiReviewConfig _config;
    private readonly IAiDispatcher? _aiDispatcher;

    public string NodeTypeName => "AiReview";

    public AiReviewExecutor(AiReviewConfig? config = null, IAiDispatcher? aiDispatcher = null)
    {
        _config = config ?? new AiReviewConfig();
        _aiDispatcher = aiDispatcher;
    }

    public async Task<StepExecutionResult> ExecuteAsync(StepExecutionContext context, CancellationToken ct = default)
    {
        var sw = Stopwatch.StartNew();
        var debugData = new Dictionary<string, object>
        {
            ["executionId"] = Guid.NewGuid().ToString(),
            ["stepId"] = context.StepId,
            ["startedAt"] = DateTime.UtcNow.ToString("O"),
        };

        try
        {
            var stepConfig = MergeConfig(context.Configuration);

            // 1. Extract candidates from input
            var candidates = ExtractCandidates(context.Input);
            debugData["candidateCount"] = candidates.Count;

            if (candidates.Count == 0)
                return StepExecutionResult.Fail("No candidates to review");

            // Skip review if single candidate and configured to do so
            if (candidates.Count == 1 && stepConfig.SkipReviewIfSingleCandidate)
            {
                debugData["skippedReview"] = true;
                return StepExecutionResult.Ok(new Dictionary<string, object>
                {
                    ["selectedIndex"] = 0,
                    ["selectedContent"] = candidates[0].GetValueOrDefault("content", ""),
                    ["selectedModel"] = candidates[0].GetValueOrDefault("model", "unknown"),
                    ["verdict"] = "APPROVE",
                    ["totalScore"] = 100.0,
                    ["reviewSummary"] = "Single candidate — auto-approved",
                }, debugData);
            }

            // 2. Score each candidate (DNA-5: DataProcessResult per candidate)
            var scoredCandidates = new List<DataProcessResult>();
            for (int i = 0; i < candidates.Count; i++)
            {
                var result = await ScoreCandidate(i, candidates[i], stepConfig, context, ct);
                scoredCandidates.Add(result);
            }

            debugData["scoredCount"] = scoredCandidates.Count(r => r.Success);

            // 3. Select best candidate by strategy
            var successful = scoredCandidates.Where(r => r.Success).ToList();
            if (successful.Count == 0)
                return StepExecutionResult.Fail("All candidates failed review");

            var selected = SelectBest(successful, stepConfig);
            var selectedIndex = (int)selected.Metadata.GetValueOrDefault("candidateIndex", 0);
            var totalScore = (double)selected.Metadata.GetValueOrDefault("totalScore", 0.0);

            // 4. Determine verdict
            var verdict = totalScore >= stepConfig.ApproveThreshold ? "APPROVE"
                        : totalScore >= stepConfig.ReviseThreshold ? "REVISE"
                        : "REJECT";

            // 5. Build all-scores summary
            var allScores = scoredCandidates.Select((r, idx) => new Dictionary<string, object>
            {
                ["candidateIndex"] = idx,
                ["model"] = r.Metadata.GetValueOrDefault("model", "unknown"),
                ["scores"] = r.Metadata.GetValueOrDefault("scores", new Dictionary<string, object>()),
                ["totalScore"] = r.Metadata.GetValueOrDefault("totalScore", 0.0),
                ["issues"] = r.Metadata.GetValueOrDefault("issues", new List<string>()),
                ["suggestions"] = r.Metadata.GetValueOrDefault("suggestions", new List<string>()),
                ["success"] = r.Success,
                ["error"] = r.Error ?? "",
            }).ToList();

            // 6. Generate summary
            var selectedModel = selected.Metadata.GetValueOrDefault("model", "unknown");
            var reviewSummary = $"Selected {selectedModel} output (index {selectedIndex}, score {totalScore:F1}/100). Verdict: {verdict}.";

            debugData["selectedIndex"] = selectedIndex;
            debugData["totalScore"] = totalScore;
            debugData["verdict"] = verdict;
            debugData["totalDurationMs"] = sw.ElapsedMilliseconds;

            return StepExecutionResult.Ok(new Dictionary<string, object>
            {
                ["selectedIndex"] = selectedIndex,
                ["selectedModel"] = selectedModel,
                ["selectedContent"] = selected.Item.GetValueOrDefault("content", ""),
                ["totalScore"] = totalScore,
                ["allScores"] = allScores,
                ["reviewSummary"] = reviewSummary,
                ["verdict"] = verdict,
            }, debugData);
        }
        catch (Exception ex)
        {
            debugData["error"] = ex.Message;
            debugData["totalDurationMs"] = sw.ElapsedMilliseconds;
            var result = StepExecutionResult.Fail(ex.Message);
            result.DebugData = debugData;
            result.DurationMs = sw.ElapsedMilliseconds;
            return result;
        }
    }

    // --- Candidate Extraction (DNA-1: dynamic documents) ---
    private List<Dictionary<string, object>> ExtractCandidates(Dictionary<string, object> input)
    {
        if (input.TryGetValue("candidates", out var candidatesObj))
        {
            if (candidatesObj is List<Dictionary<string, object>> typed)
                return typed;
            if (candidatesObj is JsonElement jsonEl && jsonEl.ValueKind == JsonValueKind.Array)
                return jsonEl.EnumerateArray()
                    .Select(e => JsonSerializer.Deserialize<Dictionary<string, object>>(e.GetRawText()) ?? new())
                    .ToList();
        }

        // If input has allResults from Skill 11
        if (input.TryGetValue("allResults", out var allResults))
        {
            if (allResults is List<Dictionary<string, object>> results)
                return results;
        }

        // Wrap single input as single candidate
        if (input.ContainsKey("content"))
            return [input];

        return [];
    }

    // --- Candidate Scoring (DNA-5: DataProcessResult) ---
    private async Task<DataProcessResult> ScoreCandidate(
        int index, Dictionary<string, object> candidate,
        AiReviewConfig config, StepExecutionContext context, CancellationToken ct)
    {
        try
        {
            var content = candidate.GetValueOrDefault("content", "").ToString() ?? "";
            var model = candidate.GetValueOrDefault("model", "unknown").ToString() ?? "unknown";

            var scores = new Dictionary<string, object>();
            var issues = new List<string>();
            var suggestions = new List<string>();

            // --- Rule-based scoring ---
            if (config.ReviewStrategy is "rule" or "hybrid")
            {
                var ruleScores = ApplyRuleBasedScoring(content, context.Configuration);
                foreach (var (key, value) in ruleScores.Scores)
                    scores[key] = value;
                issues.AddRange(ruleScores.Issues);
                suggestions.AddRange(ruleScores.Suggestions);

                // In hybrid mode, check minimum scores before AI review
                if (config.EnableRuleBasedPreFilter)
                {
                    foreach (var (criterion, score) in ruleScores.Scores)
                    {
                        if (config.Criteria.TryGetValue(criterion, out var criterionConfig)
                            && score < criterionConfig.MinScore)
                        {
                            return new DataProcessResult
                            {
                                Success = false,
                                Item = candidate,
                                Error = $"Rule-based pre-filter: {criterion} score {score} below minimum {criterionConfig.MinScore}",
                                Metadata = new()
                                {
                                    ["candidateIndex"] = index, ["model"] = model,
                                    ["scores"] = scores, ["totalScore"] = 0.0,
                                    ["issues"] = issues, ["suggestions"] = suggestions,
                                    ["filteredByRules"] = true,
                                }
                            };
                        }
                    }
                }
            }

            // --- AI-based scoring ---
            if (config.ReviewStrategy is "ai" or "hybrid" && _aiDispatcher != null)
            {
                var aiScores = await PerformAiReview(content, config, context, ct);
                // Merge AI scores (override rule-based for shared criteria)
                foreach (var (key, value) in aiScores.Scores)
                    scores[key] = value;
                issues.AddRange(aiScores.Issues);
                suggestions.AddRange(aiScores.Suggestions);
            }

            // Calculate weighted total
            double totalScore = CalculateWeightedScore(scores, config.Criteria);

            return new DataProcessResult
            {
                Success = true,
                Item = candidate,
                Metadata = new()
                {
                    ["candidateIndex"] = index, ["model"] = model,
                    ["scores"] = scores, ["totalScore"] = totalScore,
                    ["issues"] = issues, ["suggestions"] = suggestions,
                }
            };
        }
        catch (Exception ex)
        {
            return new DataProcessResult
            {
                Success = false,
                Item = candidate,
                Error = $"Scoring failed for candidate {index}: {ex.Message}",
                Metadata = new() { ["candidateIndex"] = index }
            };
        }
    }

    // --- Rule-Based Scoring ---
    private record RuleScoreResult(Dictionary<string, double> Scores, List<string> Issues, List<string> Suggestions);

    private RuleScoreResult ApplyRuleBasedScoring(string content, Dictionary<string, object> configuration)
    {
        var scores = new Dictionary<string, double>();
        var issues = new List<string>();
        var suggestions = new List<string>();

        // 1. Code block presence → completeness
        var codeBlocks = CodeBlockRegex().Matches(content);
        if (codeBlocks.Count > 0)
            scores["completeness"] = Math.Min(100, 60 + codeBlocks.Count * 10);
        else
        {
            scores["completeness"] = 20;
            issues.Add("No code blocks found in output");
            suggestions.Add("Ensure output contains fenced code blocks with language tags");
        }

        // 2. Language match → correctness
        var expectedLang = configuration.GetValueOrDefault("language", "").ToString()?.ToLower() ?? "";
        if (!string.IsNullOrEmpty(expectedLang))
        {
            var hasLangMatch = codeBlocks.Cast<Match>().Any(m =>
                m.Groups[1].Value.ToLower().Contains(expectedLang) ||
                (expectedLang == "typescript" && m.Groups[1].Value.ToLower() == "tsx") ||
                (expectedLang == "javascript" && m.Groups[1].Value.ToLower() == "jsx"));
            scores["correctness"] = hasLangMatch ? 75 : 40;
            if (!hasLangMatch)
                issues.Add($"Expected {expectedLang} but code blocks use different languages");
        }

        // 3. Security patterns → security
        var securityPatterns = new[] { "innerHTML", "dangerouslySetInnerHTML", "eval(", "document.write", "sql.*concat", "exec(" };
        var securityScore = 100.0;
        foreach (var pattern in securityPatterns)
        {
            if (Regex.IsMatch(content, pattern, RegexOptions.IgnoreCase))
            {
                securityScore -= 15;
                issues.Add($"Security concern: found pattern '{pattern}'");
            }
        }
        scores["security"] = Math.Max(0, securityScore);

        // 4. Naming conventions → codeStyle
        var hasConsistentNaming = !Regex.IsMatch(content, @"\b(var1|temp|foo|bar|baz|xxx)\b");
        scores["codeStyle"] = hasConsistentNaming ? 70 : 45;
        if (!hasConsistentNaming)
            suggestions.Add("Replace generic variable names with meaningful identifiers");

        // 5. Performance (basic) → performance
        var hasNestedLoops = Regex.IsMatch(content, @"for.*\{[^}]*for.*\{");
        scores["performance"] = hasNestedLoops ? 55 : 75;
        if (hasNestedLoops)
            suggestions.Add("Review nested loops for potential optimization");

        return new RuleScoreResult(scores, issues, suggestions);
    }

    // --- AI-Based Review ---
    private async Task<RuleScoreResult> PerformAiReview(
        string content, AiReviewConfig config, StepExecutionContext context, CancellationToken ct)
    {
        var criteriaList = string.Join(", ", config.Criteria.Keys);
        var reviewPrompt = $"""
            Review the following code output. Score each criterion from 0-100.
            Criteria: {criteriaList}

            Code to review:
            {content}

            Respond ONLY in this JSON format:
            {{
              "scores": {{ "correctness": 85, "completeness": 90, ... }},
              "issues": ["issue1", "issue2"],
              "suggestions": ["suggestion1", "suggestion2"]
            }}
            """;

        var request = new Dictionary<string, object>
        {
            ["requestId"] = $"{context.TraceId}-review-{Guid.NewGuid().ToString()[..8]}",
            ["prompt"] = reviewPrompt,
            ["systemPrompt"] = "You are a senior code reviewer. Respond only with valid JSON.",
            ["model"] = config.ReviewModel,
            ["temperature"] = 0.1,
            ["maxTokens"] = config.MaxReviewTokens,
        };

        var response = await _aiDispatcher!.DispatchAsync(request, ct);
        var responseContent = response.GetValueOrDefault("content", "").ToString() ?? "";

        return ParseAiReviewResponse(responseContent);
    }

    private RuleScoreResult ParseAiReviewResponse(string content)
    {
        try
        {
            // Extract JSON from potential markdown wrapping
            var jsonMatch = Regex.Match(content, @"\{[\s\S]*\}");
            if (!jsonMatch.Success)
                return new(new(), new() { "AI review returned no JSON" }, new());

            var doc = JsonDocument.Parse(jsonMatch.Value);
            var root = doc.RootElement;

            var scores = new Dictionary<string, double>();
            if (root.TryGetProperty("scores", out var scoresEl))
            {
                foreach (var prop in scoresEl.EnumerateObject())
                    scores[prop.Name] = prop.Value.GetDouble();
            }

            var issues = new List<string>();
            if (root.TryGetProperty("issues", out var issuesEl))
                issues = issuesEl.EnumerateArray().Select(e => e.GetString() ?? "").ToList();

            var suggestions = new List<string>();
            if (root.TryGetProperty("suggestions", out var suggestionsEl))
                suggestions = suggestionsEl.EnumerateArray().Select(e => e.GetString() ?? "").ToList();

            return new(scores, issues, suggestions);
        }
        catch
        {
            return new(new(), new() { "Failed to parse AI review response" }, new());
        }
    }

    // --- Score Calculation ---
    private double CalculateWeightedScore(Dictionary<string, object> scores, Dictionary<string, CriterionConfig> criteria)
    {
        double totalWeight = 0;
        double weightedSum = 0;

        foreach (var (criterion, config) in criteria)
        {
            if (scores.TryGetValue(criterion, out var scoreObj))
            {
                var score = Convert.ToDouble(scoreObj);
                weightedSum += score * config.Weight;
                totalWeight += config.Weight;
            }
        }

        return totalWeight > 0 ? weightedSum / totalWeight : 0;
    }

    // --- Selection Strategies ---
    private DataProcessResult SelectBest(List<DataProcessResult> candidates, AiReviewConfig config)
    {
        return config.SelectionStrategy switch
        {
            "highest-minimum" => candidates.OrderByDescending(c =>
            {
                var scores = c.Metadata.GetValueOrDefault("scores", new Dictionary<string, object>()) as Dictionary<string, object>;
                return scores?.Values.Select(v => Convert.ToDouble(v)).DefaultIfEmpty(0).Min() ?? 0;
            }).First(),

            "weighted-average" => candidates.OrderByDescending(c =>
                Convert.ToDouble(c.Metadata.GetValueOrDefault("totalScore", 0.0))).First(),

            // "highest-total" (default)
            _ => candidates.OrderByDescending(c =>
                Convert.ToDouble(c.Metadata.GetValueOrDefault("totalScore", 0.0))).First(),
        };
    }

    // --- Config Merge ---
    private AiReviewConfig MergeConfig(Dictionary<string, object> stepConfig)
    {
        if (!stepConfig.TryGetValue("aiReview", out var overridesObj))
            return _config;

        // In production, deep-merge from JSON; here return base config
        return _config;
    }

    [GeneratedRegex(@"```(\w*)\n([\s\S]*?)```")]
    private static partial Regex CodeBlockRegex();
}

// --- DI Registration ---
public static class AiReviewExtensions
{
    public static IServiceCollection AddXIIGenAiReview(this IServiceCollection services, Action<AiReviewConfig>? configure = null)
    {
        var config = new AiReviewConfig();
        configure?.Invoke(config);
        services.AddSingleton(config);
        services.AddTransient<AiReviewExecutor>();
        services.AddTransient<IStepExecutor>(sp => sp.GetRequiredService<AiReviewExecutor>());
        return services;
    }
}
