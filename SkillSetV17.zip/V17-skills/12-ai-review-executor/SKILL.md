---
name: ai-review-executor
description: Evaluates multiple AI-generated outputs using configurable scoring criteria, selects the best result, and provides structured review feedback for continuous improvement
triggers: ai review, code review, evaluate outputs, score results, quality check, select best, multi-model comparison
dependencies: [01-core-interfaces, 02-object-processor, 06-ai-providers, 07-ai-dispatcher]
layer: L4-StepExecutors
genie-dna: Review results stored as dynamic documents. Scoring criteria queries use BuildSearchFilter with empty-field skipping. Per-candidate scoring uses DataProcessResult.
phase: 3
---

# Skill 12: AI Review Executor
## The Quality Inspector — Scores Multiple Outputs, Selects the Best

When Skill 11 (AI Transform) dispatches to multiple AI models in parallel, each returns a different code result. The AI Review Executor evaluates all candidates against configurable quality criteria, assigns scores, selects the best one, and produces structured review feedback that feeds back into the system.

---

## Architecture

```
FlowOrchestrator (Skill 09) calls ExecuteAsync(context)
       ↓
  AiReviewExecutor
       ↓ 1. Extract candidate outputs from step input
       ↓    └─ Input: { candidates: [ {content, model, tokens} ... ] }
       ↓ 2. Load scoring criteria (from config or custom rubric)
       ↓    └─ Default: correctness, completeness, style, performance, security
       ↓ 3. For each candidate:
       ↓    ├─ Option A: AI-based review (send to reviewer model)
       ↓    ├─ Option B: Rule-based scoring (regex, AST, lint)
       ↓    └─ Option C: Hybrid (rules first, AI for subjective criteria)
       ↓ 4. Aggregate scores per candidate
       ↓ 5. Select best candidate by strategy
       ↓    └─ highest-total | highest-minimum | weighted-average
       ↓ 6. Generate review summary with improvement suggestions
       ↓
  StepExecutionResult { selectedOutput, allScores, reviewSummary }
```

## Key Features

### 1. Multi-Criteria Scoring
Each candidate is evaluated against configurable criteria:

| Criterion | Weight | Description |
|-----------|--------|-------------|
| correctness | 0.30 | Does the code implement the requirement correctly? |
| completeness | 0.25 | Are all components/features present? |
| codeStyle | 0.15 | Naming, formatting, idiomatic patterns |
| performance | 0.15 | Efficient algorithms, no unnecessary operations |
| security | 0.15 | No XSS, injection, or data exposure risks |

Weights are configurable per flow. Custom criteria can be added.

### 2. Review Strategies

**AI-Based Review:** Sends each candidate + rubric to a reviewer model (can be different from generation model). Returns structured scores and explanations per criterion.

**Rule-Based Review:** Applies automated checks:
- Code block presence validation
- Language detection match (requested vs actual)
- Import/dependency completeness
- Naming convention adherence (regex-based)
- Security pattern scanning (innerHTML, eval, SQL concat)

**Hybrid Review:** Rule-based scores first (fast, deterministic), then AI review for subjective criteria (style, correctness). Rules can veto candidates before AI review.

### 3. Selection Strategies
- `highest-total`: Sum of all weighted scores — best overall
- `highest-minimum`: Candidate with highest minimum score across all criteria — most balanced
- `weighted-average`: Custom weight profile applied per criterion
- `consensus`: If multiple reviewers, select candidate approved by majority

### 4. Review Output Structure
Every review produces a standardized document:
```json
{
  "selectedIndex": 0,
  "selectedModel": "claude-sonnet-4-20250514",
  "selectedContent": "...",
  "totalScore": 87.5,
  "allScores": [
    {
      "candidateIndex": 0,
      "model": "claude-sonnet-4-20250514",
      "scores": { "correctness": 90, "completeness": 85, "codeStyle": 88, "performance": 82, "security": 95 },
      "totalScore": 87.5,
      "issues": ["Missing error boundary component"],
      "suggestions": ["Add try-catch wrapper for async operations"]
    }
  ],
  "reviewSummary": "Selected Claude output (87.5/100). Strong security and correctness.",
  "verdict": "APPROVE"
}
```

### 5. Verdict System
- **APPROVE** (score ≥ 80): Output accepted, proceed to next step
- **REVISE** (score 50-79): Output needs improvement, can trigger re-generation with feedback
- **REJECT** (score < 50): Output unacceptable, skip to fallback or fail step

## Configuration

```json
{
  "aiReview": {
    "reviewModel": "claude-sonnet-4-20250514",
    "reviewStrategy": "hybrid",
    "selectionStrategy": "highest-total",
    "criteria": {
      "correctness": { "weight": 0.30, "minScore": 60 },
      "completeness": { "weight": 0.25, "minScore": 50 },
      "codeStyle": { "weight": 0.15, "minScore": 40 },
      "performance": { "weight": 0.15, "minScore": 40 },
      "security": { "weight": 0.15, "minScore": 70 }
    },
    "approveThreshold": 80,
    "reviseThreshold": 50,
    "enableRuleBasedPreFilter": true,
    "maxReviewTokens": 2000,
    "skipReviewIfSingleCandidate": false
  }
}
```

## Genie DNA Integration
- DNA-1: Review results stored as dynamic documents — no fixed ReviewResult class
- DNA-2: Criteria queries use BuildSearchFilter — custom criteria loaded by name with empty-field skipping
- DNA-5: DataProcessResult per candidate — individual success/failure with scores

## Dependencies
| Skill | Usage |
|---|---|
| 01-core-interfaces | IStepExecutor, DataProcessResult |
| 02-object-processor | Review result parsing, criteria injection |
| 06-ai-providers | IAiProvider for AI-based review |
| 07-ai-dispatcher | Dispatch review prompt to reviewer model |

## Alternatives
| Language | File | Notes |
|---|---|---|
| .NET 9 (primary) | `Implementation/AiReviewExecutor.cs` | Full hybrid review |
| Node.js/TypeScript | `alternatives/nodejs/ai-review-executor.ts` | Async scoring pipeline |
| Python | `alternatives/python/ai_review_executor.py` | ML-friendly scoring |
| Java | `alternatives/java/AiReviewExecutor.java` | Enterprise weighted scoring |
| Rust | `alternatives/rust/ai_review_executor.rs` | High-performance evaluation |
| PHP | `alternatives/php/AiReviewExecutor.php` | CMS quality gate |
