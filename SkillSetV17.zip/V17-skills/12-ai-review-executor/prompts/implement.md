# Implement Skill 12: AI Review Executor

## Context
You are implementing the AI Review Executor for the XIIGen platform.
This service evaluates AI-generated outputs (from Skill 11) using multi-criteria scoring,
selects the best candidate, and produces a structured review with verdict.

## Dependencies
- Skill 01 (Core Interfaces): IStepExecutor, IReviewExecutor, DataProcessResult
- Skill 06 (AI Providers): IAiProvider for AI-based review
- Skill 13 (Feedback Service): Historical feedback for calibration
- Skill 02 (Object Processor): Dynamic document storage for review records

## Required Implementation

### 1. Multi-Criteria Scoring Engine
Implement scoring across 5 criteria with configurable weights:
| Criterion    | Default Weight | Min Score | Purpose                        |
|-------------|---------------|-----------|--------------------------------|
| correctness  | 0.30          | 60        | Implements requirement correctly |
| completeness | 0.25          | 50        | All required components present |
| codeStyle    | 0.15          | 40        | Naming, formatting, idiomatic   |
| performance  | 0.15          | 40        | Efficient algorithms/patterns   |
| security     | 0.15          | 70        | No XSS, injection, data leaks   |

### 2. Three Review Strategies
- **rule-based**: Automated pattern checks (fast, deterministic) — code blocks present, language match, dangerous patterns (eval/innerHTML), naming conventions, nested loops
- **ai-based**: Send candidate + rubric to reviewer AI model, parse structured scores + explanations
- **hybrid** (default): Rule-based pre-filter → AI review for candidates that pass minimum thresholds

### 3. Selection Strategies
- `highest-total`: Sum of weighted scores (default)
- `highest-minimum`: Candidate with highest minimum score across all criteria
- `weighted-average`: Custom weight profile per criterion

### 4. Verdict System
- **APPROVE** (≥80): Proceed to next flow step
- **REVISE** (50-79): Needs improvement, optionally re-trigger transform with feedback
- **REJECT** (<50): Unacceptable, fail or skip to fallback

### 5. Genie DNA Integration
- **DNA-1**: Review results stored as Dictionary<string, object> (no fixed model classes)
- **DNA-2**: Criteria queries use BuildSearchFilter with empty-field auto-skipping
- **DNA-5**: DataProcessResult per candidate with individual success/failure tracking

## Positive Example
```json
{
  "verdict": "APPROVE",
  "totalScore": 87.5,
  "selectedCandidate": "claude-sonnet-4-20250514",
  "scores": {
    "correctness": { "score": 92, "weight": 0.30, "explanation": "All requirements met" },
    "completeness": { "score": 85, "weight": 0.25, "explanation": "Missing loading state" },
    "codeStyle": { "score": 88, "weight": 0.15, "explanation": "Clean, idiomatic React" },
    "performance": { "score": 80, "weight": 0.15, "explanation": "No unnecessary re-renders" },
    "security": { "score": 90, "weight": 0.15, "explanation": "No dangerouslySetInnerHTML" }
  },
  "summary": "Strong implementation with minor completeness gap. Approved for next step."
}
```

## Negative Example
```json
{
  "verdict": "REJECT",
  "totalScore": 38.2,
  "selectedCandidate": null,
  "scores": {
    "correctness": { "score": 30, "explanation": "Wrong component type generated" },
    "security": { "score": 25, "explanation": "Uses eval() and innerHTML" }
  },
  "summary": "All candidates failed minimum thresholds. Triggering re-generation."
}
```

## DI Registration
```csharp
services.AddXIIGenAiReviewExecutor(opts => {
    opts.DefaultStrategy = "hybrid";
    opts.SelectionStrategy = "highest-total";
    opts.MinimumScores = new() { ["security"] = 70, ["correctness"] = 60 };
});
```

## Validation Checklist
- [ ] Multi-criteria scoring with configurable weights
- [ ] Rule-based, AI-based, and hybrid review strategies
- [ ] Three selection strategies (highest-total, highest-minimum, weighted-average)
- [ ] Verdict system (APPROVE/REVISE/REJECT) with configurable thresholds
- [ ] DataProcessResult per candidate (DNA-5)
- [ ] Dynamic documents (DNA-1), BuildSearchFilter (DNA-2)
- [ ] IStepExecutor interface implementation for flow integration
