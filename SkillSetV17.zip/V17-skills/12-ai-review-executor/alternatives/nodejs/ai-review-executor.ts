/**
 * Skill 12: AI Review Executor — Node.js/TypeScript
 * Evaluates multiple AI outputs, scores per criteria, selects best.
 * Genie DNA: Dynamic documents, BuildSearchFilter, DataProcessResult per candidate.
 */

import { randomUUID } from 'crypto';

// --- Types ---
interface CriterionConfig { weight: number; minScore: number; }
interface AiReviewConfig {
  reviewModel: string;
  reviewStrategy: 'ai' | 'rule' | 'hybrid';
  selectionStrategy: 'highest-total' | 'highest-minimum' | 'weighted-average';
  criteria: Record<string, CriterionConfig>;
  approveThreshold: number;
  reviseThreshold: number;
  enableRuleBasedPreFilter: boolean;
  maxReviewTokens: number;
  skipReviewIfSingleCandidate: boolean;
}

interface DataProcessResult {
  success: boolean;
  item: Record<string, any>;
  error?: string;
  metadata: Record<string, any>;
}

interface IAiDispatcher {
  dispatch(request: Record<string, any>): Promise<Record<string, any>>;
}

const DEFAULT_CONFIG: AiReviewConfig = {
  reviewModel: 'claude-sonnet-4-20250514',
  reviewStrategy: 'hybrid',
  selectionStrategy: 'highest-total',
  criteria: {
    correctness:  { weight: 0.30, minScore: 60 },
    completeness: { weight: 0.25, minScore: 50 },
    codeStyle:    { weight: 0.15, minScore: 40 },
    performance:  { weight: 0.15, minScore: 40 },
    security:     { weight: 0.15, minScore: 70 },
  },
  approveThreshold: 80,
  reviseThreshold: 50,
  enableRuleBasedPreFilter: true,
  maxReviewTokens: 2000,
  skipReviewIfSingleCandidate: false,
};

// --- Main Executor ---
export class AiReviewExecutor {
  private config: AiReviewConfig;
  private aiDispatcher?: IAiDispatcher;

  constructor(config?: Partial<AiReviewConfig>, aiDispatcher?: IAiDispatcher) {
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.aiDispatcher = aiDispatcher;
  }

  async executeAsync(context: Record<string, any>): Promise<Record<string, any>> {
    const startTime = Date.now();
    const debugData: Record<string, any> = {
      executionId: randomUUID(),
      stepId: context.stepId || '',
      startedAt: new Date().toISOString(),
    };

    try {
      const config = this.mergeConfig(context.configuration || {});
      const candidates = this.extractCandidates(context.input || {});
      debugData.candidateCount = candidates.length;

      if (candidates.length === 0) throw new Error('No candidates to review');

      if (candidates.length === 1 && config.skipReviewIfSingleCandidate) {
        return {
          success: true,
          output: {
            selectedIndex: 0,
            selectedContent: candidates[0].content || '',
            selectedModel: candidates[0].model || 'unknown',
            verdict: 'APPROVE', totalScore: 100,
            reviewSummary: 'Single candidate — auto-approved',
          },
          debugData, durationMs: Date.now() - startTime,
        };
      }

      // Score each candidate (DNA-5: DataProcessResult per candidate)
      const scored: DataProcessResult[] = [];
      for (let i = 0; i < candidates.length; i++) {
        scored.push(await this.scoreCandidate(i, candidates[i], config, context));
      }

      const successful = scored.filter(r => r.success);
      if (successful.length === 0) throw new Error('All candidates failed review');

      const selected = this.selectBest(successful, config);
      const totalScore = selected.metadata.totalScore as number;
      const verdict = totalScore >= config.approveThreshold ? 'APPROVE'
                    : totalScore >= config.reviseThreshold  ? 'REVISE' : 'REJECT';

      const allScores = scored.map((r, i) => ({
        candidateIndex: i, model: r.metadata.model,
        scores: r.metadata.scores, totalScore: r.metadata.totalScore,
        issues: r.metadata.issues, suggestions: r.metadata.suggestions,
        success: r.success, error: r.error,
      }));

      return {
        success: true,
        output: {
          selectedIndex: selected.metadata.candidateIndex,
          selectedModel: selected.metadata.model,
          selectedContent: selected.item.content || '',
          totalScore, allScores, verdict,
          reviewSummary: `Selected ${selected.metadata.model} (score ${totalScore.toFixed(1)}/100). Verdict: ${verdict}.`,
        },
        debugData: { ...debugData, verdict, totalScore, durationMs: Date.now() - startTime },
        durationMs: Date.now() - startTime,
      };
    } catch (err: any) {
      return {
        success: false, output: {},
        debugData: { ...debugData, error: err.message },
        durationMs: Date.now() - startTime, error: err.message,
      };
    }
  }

  // --- Candidate Extraction ---
  private extractCandidates(input: Record<string, any>): Record<string, any>[] {
    if (Array.isArray(input.candidates)) return input.candidates;
    if (Array.isArray(input.allResults)) return input.allResults;
    if (input.content) return [input];
    return [];
  }

  // --- Scoring per candidate (DNA-5) ---
  private async scoreCandidate(
    index: number, candidate: Record<string, any>,
    config: AiReviewConfig, context: Record<string, any>
  ): Promise<DataProcessResult> {
    try {
      const content = String(candidate.content || '');
      const model = String(candidate.model || 'unknown');
      let scores: Record<string, number> = {};
      const issues: string[] = [];
      const suggestions: string[] = [];

      // Rule-based scoring
      if (config.reviewStrategy === 'rule' || config.reviewStrategy === 'hybrid') {
        const ruleResult = this.applyRuleBasedScoring(content, context.configuration || {});
        Object.assign(scores, ruleResult.scores);
        issues.push(...ruleResult.issues);
        suggestions.push(...ruleResult.suggestions);

        if (config.enableRuleBasedPreFilter) {
          for (const [criterion, score] of Object.entries(ruleResult.scores)) {
            const cConfig = config.criteria[criterion];
            if (cConfig && score < cConfig.minScore) {
              return {
                success: false, item: candidate,
                error: `Pre-filter: ${criterion} score ${score} < min ${cConfig.minScore}`,
                metadata: { candidateIndex: index, model, scores, totalScore: 0, issues, suggestions },
              };
            }
          }
        }
      }

      // AI-based scoring
      if ((config.reviewStrategy === 'ai' || config.reviewStrategy === 'hybrid') && this.aiDispatcher) {
        const aiResult = await this.performAiReview(content, config, context);
        Object.assign(scores, aiResult.scores);
        issues.push(...aiResult.issues);
        suggestions.push(...aiResult.suggestions);
      }

      const totalScore = this.calculateWeightedScore(scores, config.criteria);

      return {
        success: true, item: candidate,
        metadata: { candidateIndex: index, model, scores, totalScore, issues, suggestions },
      };
    } catch (err: any) {
      return {
        success: false, item: candidate,
        error: `Scoring failed: ${err.message}`,
        metadata: { candidateIndex: index },
      };
    }
  }

  // --- Rule-Based Scoring ---
  private applyRuleBasedScoring(content: string, config: Record<string, any>) {
    const scores: Record<string, number> = {};
    const issues: string[] = [];
    const suggestions: string[] = [];

    // Code blocks present
    const codeBlocks = [...content.matchAll(/```(\w*)\n([\s\S]*?)```/g)];
    scores.completeness = codeBlocks.length > 0 ? Math.min(100, 60 + codeBlocks.length * 10) : 20;
    if (codeBlocks.length === 0) {
      issues.push('No code blocks found');
      suggestions.push('Ensure fenced code blocks with language tags');
    }

    // Language match
    const expectedLang = String(config.language || '').toLowerCase();
    if (expectedLang) {
      const hasMatch = codeBlocks.some(m => {
        const lang = m[1].toLowerCase();
        return lang.includes(expectedLang) || (expectedLang === 'typescript' && lang === 'tsx');
      });
      scores.correctness = hasMatch ? 75 : 40;
      if (!hasMatch) issues.push(`Expected ${expectedLang} but got different language`);
    }

    // Security patterns
    const dangerousPatterns = ['innerHTML', 'dangerouslySetInnerHTML', 'eval(', 'document.write'];
    let secScore = 100;
    for (const pattern of dangerousPatterns) {
      if (content.toLowerCase().includes(pattern.toLowerCase())) {
        secScore -= 15;
        issues.push(`Security: found '${pattern}'`);
      }
    }
    scores.security = Math.max(0, secScore);

    // Code style
    scores.codeStyle = /\b(var1|temp|foo|bar|baz)\b/.test(content) ? 45 : 70;

    // Performance
    scores.performance = /for.*\{[^}]*for.*\{/.test(content) ? 55 : 75;

    return { scores, issues, suggestions };
  }

  // --- AI-Based Review ---
  private async performAiReview(content: string, config: AiReviewConfig, context: Record<string, any>) {
    const criteriaList = Object.keys(config.criteria).join(', ');
    const prompt = `Review this code. Score each criterion 0-100: ${criteriaList}\n\nCode:\n${content}\n\nRespond ONLY in JSON: {"scores":{...},"issues":[...],"suggestions":[...]}`;

    const response = await this.aiDispatcher!.dispatch({
      requestId: `${context.traceId || ''}-review-${randomUUID().slice(0, 8)}`,
      prompt, systemPrompt: 'You are a senior code reviewer. Respond with valid JSON only.',
      model: config.reviewModel, temperature: 0.1, maxTokens: config.maxReviewTokens,
    });

    try {
      const jsonMatch = String(response.content || '').match(/\{[\s\S]*\}/);
      if (!jsonMatch) return { scores: {}, issues: ['AI returned no JSON'], suggestions: [] };
      const parsed = JSON.parse(jsonMatch[0]);
      return {
        scores: parsed.scores || {},
        issues: parsed.issues || [],
        suggestions: parsed.suggestions || [],
      };
    } catch {
      return { scores: {}, issues: ['Failed to parse AI review'], suggestions: [] };
    }
  }

  // --- Weighted Score ---
  private calculateWeightedScore(scores: Record<string, number>, criteria: Record<string, CriterionConfig>): number {
    let totalWeight = 0, weightedSum = 0;
    for (const [key, cfg] of Object.entries(criteria)) {
      if (key in scores) {
        weightedSum += scores[key] * cfg.weight;
        totalWeight += cfg.weight;
      }
    }
    return totalWeight > 0 ? weightedSum / totalWeight : 0;
  }

  // --- Selection ---
  private selectBest(candidates: DataProcessResult[], config: AiReviewConfig): DataProcessResult {
    if (config.selectionStrategy === 'highest-minimum') {
      return candidates.sort((a, b) => {
        const aMin = Math.min(...Object.values((a.metadata.scores || {}) as Record<string, number>));
        const bMin = Math.min(...Object.values((b.metadata.scores || {}) as Record<string, number>));
        return bMin - aMin;
      })[0];
    }
    return candidates.sort((a, b) =>
      (b.metadata.totalScore as number) - (a.metadata.totalScore as number)
    )[0];
  }

  private mergeConfig(stepConfig: Record<string, any>): AiReviewConfig {
    return { ...this.config, ...(stepConfig.aiReview || {}) };
  }
}

export default AiReviewExecutor;
