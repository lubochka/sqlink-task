"""
Skill 12: AI Review Executor — Python
Evaluates multiple AI outputs, scores per criteria, selects best.
Genie DNA: Dynamic documents (dicts), BuildSearchFilter, DataProcessResult per candidate.
"""

import re
import json
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Protocol


class IAiDispatcher(Protocol):
    async def dispatch(self, request: dict[str, Any]) -> dict[str, Any]: ...


@dataclass
class CriterionConfig:
    weight: float
    min_score: float


@dataclass
class AiReviewConfig:
    review_model: str = "claude-sonnet-4-20250514"
    review_strategy: str = "hybrid"  # ai | rule | hybrid
    selection_strategy: str = "highest-total"
    criteria: dict[str, CriterionConfig] = field(default_factory=lambda: {
        "correctness":  CriterionConfig(0.30, 60),
        "completeness": CriterionConfig(0.25, 50),
        "codeStyle":    CriterionConfig(0.15, 40),
        "performance":  CriterionConfig(0.15, 40),
        "security":     CriterionConfig(0.15, 70),
    })
    approve_threshold: float = 80
    revise_threshold: float = 50
    enable_rule_pre_filter: bool = True
    max_review_tokens: int = 2000
    skip_if_single: bool = False


class AiReviewExecutor:
    """Evaluates multiple AI outputs, scores each, selects best."""

    def __init__(self, config: AiReviewConfig | None = None, ai_dispatcher: IAiDispatcher | None = None):
        self.config = config or AiReviewConfig()
        self.ai_dispatcher = ai_dispatcher

    async def execute_async(self, context: dict[str, Any]) -> dict[str, Any]:
        start = datetime.now(timezone.utc)
        debug: dict[str, Any] = {"execution_id": str(uuid.uuid4()), "started_at": start.isoformat()}

        try:
            cfg = self.config
            candidates = self._extract_candidates(context.get("input", {}))
            debug["candidate_count"] = len(candidates)

            if not candidates:
                raise ValueError("No candidates to review")

            if len(candidates) == 1 and cfg.skip_if_single:
                return {"success": True, "output": {
                    "selectedIndex": 0, "selectedContent": candidates[0].get("content", ""),
                    "verdict": "APPROVE", "totalScore": 100,
                    "reviewSummary": "Single candidate — auto-approved",
                }, "debugData": debug, "durationMs": self._elapsed(start)}

            # Score each candidate (DNA-5)
            scored = [await self._score_candidate(i, c, cfg, context) for i, c in enumerate(candidates)]
            successful = [r for r in scored if r["success"]]

            if not successful:
                raise RuntimeError("All candidates failed review")

            selected = self._select_best(successful, cfg)
            total = selected["metadata"]["total_score"]
            verdict = "APPROVE" if total >= cfg.approve_threshold else "REVISE" if total >= cfg.revise_threshold else "REJECT"

            all_scores = [{
                "candidateIndex": i, "model": r["metadata"].get("model"),
                "scores": r["metadata"].get("scores", {}), "totalScore": r["metadata"].get("total_score", 0),
                "issues": r["metadata"].get("issues", []), "suggestions": r["metadata"].get("suggestions", []),
                "success": r["success"],
            } for i, r in enumerate(scored)]

            return {"success": True, "output": {
                "selectedIndex": selected["metadata"]["candidate_index"],
                "selectedModel": selected["metadata"]["model"],
                "selectedContent": selected["item"].get("content", ""),
                "totalScore": total, "allScores": all_scores, "verdict": verdict,
                "reviewSummary": f"Selected {selected['metadata']['model']} (score {total:.1f}/100). Verdict: {verdict}.",
            }, "debugData": debug, "durationMs": self._elapsed(start)}

        except Exception as e:
            return {"success": False, "output": {}, "error": str(e),
                    "debugData": {**debug, "error": str(e)}, "durationMs": self._elapsed(start)}

    def _extract_candidates(self, inp: dict) -> list[dict]:
        if isinstance(inp.get("candidates"), list): return inp["candidates"]
        if isinstance(inp.get("allResults"), list): return inp["allResults"]
        if "content" in inp: return [inp]
        return []

    async def _score_candidate(self, index: int, candidate: dict, cfg: AiReviewConfig, ctx: dict) -> dict:
        try:
            content = str(candidate.get("content", ""))
            model = str(candidate.get("model", "unknown"))
            scores: dict[str, float] = {}
            issues: list[str] = []
            suggestions: list[str] = []

            if cfg.review_strategy in ("rule", "hybrid"):
                rule = self._rule_based_scoring(content, ctx.get("configuration", {}))
                scores.update(rule["scores"])
                issues.extend(rule["issues"])
                suggestions.extend(rule["suggestions"])

                if cfg.enable_rule_pre_filter:
                    for crit, score in rule["scores"].items():
                        cc = cfg.criteria.get(crit)
                        if cc and score < cc.min_score:
                            return {"success": False, "item": candidate,
                                    "error": f"Pre-filter: {crit} {score} < {cc.min_score}",
                                    "metadata": {"candidate_index": index, "model": model, "scores": scores,
                                                 "total_score": 0, "issues": issues, "suggestions": suggestions}}

            if cfg.review_strategy in ("ai", "hybrid") and self.ai_dispatcher:
                ai = await self._ai_review(content, cfg, ctx)
                scores.update(ai["scores"])
                issues.extend(ai["issues"])
                suggestions.extend(ai["suggestions"])

            total = self._weighted_score(scores, cfg.criteria)
            return {"success": True, "item": candidate,
                    "metadata": {"candidate_index": index, "model": model, "scores": scores,
                                 "total_score": total, "issues": issues, "suggestions": suggestions}}
        except Exception as e:
            return {"success": False, "item": candidate, "error": str(e),
                    "metadata": {"candidate_index": index}}

    def _rule_based_scoring(self, content: str, config: dict) -> dict:
        scores: dict[str, float] = {}
        issues: list[str] = []
        suggestions: list[str] = []

        blocks = re.findall(r'```(\w*)\n([\s\S]*?)```', content)
        scores["completeness"] = min(100, 60 + len(blocks) * 10) if blocks else 20
        if not blocks:
            issues.append("No code blocks found")

        expected = str(config.get("language", "")).lower()
        if expected:
            has_match = any(expected in b[0].lower() for b in blocks)
            scores["correctness"] = 75 if has_match else 40

        sec = 100.0
        for pat in ["innerHTML", "eval(", "document.write", "dangerouslySetInnerHTML"]:
            if pat.lower() in content.lower():
                sec -= 15
                issues.append(f"Security: found '{pat}'")
        scores["security"] = max(0, sec)
        scores["codeStyle"] = 45 if re.search(r'\b(var1|temp|foo|bar)\b', content) else 70
        scores["performance"] = 55 if re.search(r'for.*\{[^}]*for.*\{', content) else 75

        return {"scores": scores, "issues": issues, "suggestions": suggestions}

    async def _ai_review(self, content: str, cfg: AiReviewConfig, ctx: dict) -> dict:
        criteria_list = ", ".join(cfg.criteria.keys())
        prompt = f'Review this code. Score 0-100 for: {criteria_list}\n\nCode:\n{content}\n\nJSON only: {{"scores":{{...}},"issues":[...],"suggestions":[...]}}'
        resp = await self.ai_dispatcher.dispatch({
            "requestId": f"{ctx.get('traceId', '')}-review-{uuid.uuid4().hex[:8]}",
            "prompt": prompt, "systemPrompt": "Senior code reviewer. JSON only.",
            "model": cfg.review_model, "temperature": 0.1, "maxTokens": cfg.max_review_tokens,
        })
        try:
            match = re.search(r'\{[\s\S]*\}', str(resp.get("content", "")))
            if not match: return {"scores": {}, "issues": ["No JSON"], "suggestions": []}
            parsed = json.loads(match.group())
            return {"scores": parsed.get("scores", {}), "issues": parsed.get("issues", []),
                    "suggestions": parsed.get("suggestions", [])}
        except Exception:
            return {"scores": {}, "issues": ["Parse failed"], "suggestions": []}

    def _weighted_score(self, scores: dict[str, float], criteria: dict[str, CriterionConfig]) -> float:
        total_w, weighted = 0.0, 0.0
        for k, cc in criteria.items():
            if k in scores:
                weighted += scores[k] * cc.weight
                total_w += cc.weight
        return weighted / total_w if total_w > 0 else 0

    def _select_best(self, candidates: list[dict], cfg: AiReviewConfig) -> dict:
        if cfg.selection_strategy == "highest-minimum":
            return max(candidates, key=lambda c: min(c["metadata"].get("scores", {}).values(), default=0))
        return max(candidates, key=lambda c: c["metadata"].get("total_score", 0))

    def _elapsed(self, start: datetime) -> int:
        return int((datetime.now(timezone.utc) - start).total_seconds() * 1000)
