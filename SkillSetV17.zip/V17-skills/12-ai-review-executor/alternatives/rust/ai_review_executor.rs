/// Skill 12: AI Review Executor — Rust
/// Evaluates multiple AI outputs, scores per criteria, selects best.
/// Genie DNA: Dynamic docs (serde_json::Value), DataProcessResult per candidate.

use regex::Regex;
use serde_json::{json, Value};
use std::collections::HashMap;
use std::time::Instant;
use uuid::Uuid;

// --- Configuration ---
#[derive(Clone, Debug)]
pub struct CriterionConfig {
    pub weight: f64,
    pub min_score: f64,
}

#[derive(Clone, Debug)]
pub struct AiReviewConfig {
    pub review_model: String,
    pub review_strategy: String,
    pub selection_strategy: String,
    pub criteria: HashMap<String, CriterionConfig>,
    pub approve_threshold: f64,
    pub revise_threshold: f64,
    pub enable_rule_pre_filter: bool,
    pub max_review_tokens: u32,
    pub skip_if_single: bool,
}

impl Default for AiReviewConfig {
    fn default() -> Self {
        let mut criteria = HashMap::new();
        criteria.insert("correctness".into(),  CriterionConfig { weight: 0.30, min_score: 60.0 });
        criteria.insert("completeness".into(), CriterionConfig { weight: 0.25, min_score: 50.0 });
        criteria.insert("codeStyle".into(),    CriterionConfig { weight: 0.15, min_score: 40.0 });
        criteria.insert("performance".into(),  CriterionConfig { weight: 0.15, min_score: 40.0 });
        criteria.insert("security".into(),     CriterionConfig { weight: 0.15, min_score: 70.0 });
        Self {
            review_model: "claude-sonnet-4-20250514".into(),
            review_strategy: "hybrid".into(),
            selection_strategy: "highest-total".into(),
            criteria,
            approve_threshold: 80.0,
            revise_threshold: 50.0,
            enable_rule_pre_filter: true,
            max_review_tokens: 2000,
            skip_if_single: false,
        }
    }
}

// --- Trait ---
#[async_trait::async_trait]
pub trait AiDispatcher: Send + Sync {
    async fn dispatch(&self, request: &Value) -> Result<Value, Box<dyn std::error::Error + Send + Sync>>;
}

// --- Result structures ---
struct RuleResult {
    scores: HashMap<String, f64>,
    issues: Vec<String>,
    suggestions: Vec<String>,
}

struct CandidateResult {
    success: bool,
    item: Value,
    error: Option<String>,
    candidate_index: usize,
    model: String,
    scores: HashMap<String, f64>,
    total_score: f64,
    issues: Vec<String>,
    suggestions: Vec<String>,
}

// --- Main Executor ---
pub struct AiReviewExecutor {
    config: AiReviewConfig,
    ai_dispatcher: Option<Box<dyn AiDispatcher>>,
}

impl AiReviewExecutor {
    pub fn new(config: AiReviewConfig, ai_dispatcher: Option<Box<dyn AiDispatcher>>) -> Self {
        Self { config, ai_dispatcher }
    }

    pub async fn execute_async(&self, context: &Value) -> Value {
        let start = Instant::now();
        let debug_id = Uuid::new_v4().to_string();

        match self.execute_inner(context).await {
            Ok(output) => json!({
                "success": true,
                "output": output,
                "debugData": { "executionId": debug_id, "durationMs": start.elapsed().as_millis() as u64 },
                "durationMs": start.elapsed().as_millis() as u64,
            }),
            Err(e) => json!({
                "success": false, "output": {},
                "error": e.to_string(),
                "debugData": { "executionId": debug_id, "error": e.to_string() },
                "durationMs": start.elapsed().as_millis() as u64,
            }),
        }
    }

    async fn execute_inner(&self, context: &Value) -> Result<Value, Box<dyn std::error::Error + Send + Sync>> {
        let input = context.get("input").unwrap_or(&json!({}));
        let candidates = extract_candidates(input);

        if candidates.is_empty() {
            return Err("No candidates to review".into());
        }

        if candidates.len() == 1 && self.config.skip_if_single {
            return Ok(json!({
                "selectedIndex": 0,
                "selectedContent": candidates[0].get("content").and_then(|v| v.as_str()).unwrap_or(""),
                "verdict": "APPROVE", "totalScore": 100.0,
                "reviewSummary": "Single candidate — auto-approved",
            }));
        }

        // Score each candidate
        let config_val = context.get("configuration").unwrap_or(&json!({}));
        let mut scored: Vec<CandidateResult> = Vec::new();
        for (i, cand) in candidates.iter().enumerate() {
            scored.push(self.score_candidate(i, cand, config_val).await);
        }

        let successful: Vec<&CandidateResult> = scored.iter().filter(|r| r.success).collect();
        if successful.is_empty() {
            return Err("All candidates failed review".into());
        }

        let selected = select_best(&successful, &self.config);
        let verdict = if selected.total_score >= self.config.approve_threshold { "APPROVE" }
                     else if selected.total_score >= self.config.revise_threshold { "REVISE" }
                     else { "REJECT" };

        let all_scores: Vec<Value> = scored.iter().map(|r| json!({
            "candidateIndex": r.candidate_index,
            "model": r.model,
            "scores": r.scores.iter().map(|(k,v)| (k.clone(), json!(v))).collect::<serde_json::Map<String, Value>>(),
            "totalScore": r.total_score,
            "issues": r.issues,
            "success": r.success,
        })).collect();

        Ok(json!({
            "selectedIndex": selected.candidate_index,
            "selectedModel": selected.model,
            "selectedContent": selected.item.get("content").and_then(|v| v.as_str()).unwrap_or(""),
            "totalScore": selected.total_score,
            "allScores": all_scores,
            "verdict": verdict,
            "reviewSummary": format!("Selected {} (score {:.1}/100). Verdict: {}.", selected.model, selected.total_score, verdict),
        }))
    }

    async fn score_candidate(&self, index: usize, candidate: &Value, config: &Value) -> CandidateResult {
        let content = candidate.get("content").and_then(|v| v.as_str()).unwrap_or("");
        let model = candidate.get("model").and_then(|v| v.as_str()).unwrap_or("unknown").to_string();
        let mut scores = HashMap::new();
        let mut issues = Vec::new();
        let mut suggestions = Vec::new();

        if self.config.review_strategy == "rule" || self.config.review_strategy == "hybrid" {
            let rule = rule_based_scoring(content, config);
            scores.extend(rule.scores);
            issues.extend(rule.issues);
            suggestions.extend(rule.suggestions);

            if self.config.enable_rule_pre_filter {
                for (crit, score) in &scores {
                    if let Some(cc) = self.config.criteria.get(crit) {
                        if *score < cc.min_score {
                            return CandidateResult {
                                success: false, item: candidate.clone(),
                                error: Some(format!("{crit} {score} < min {}", cc.min_score)),
                                candidate_index: index, model, scores, total_score: 0.0,
                                issues, suggestions,
                            };
                        }
                    }
                }
            }
        }

        let total = weighted_score(&scores, &self.config.criteria);
        CandidateResult {
            success: true, item: candidate.clone(), error: None,
            candidate_index: index, model, scores, total_score: total,
            issues, suggestions,
        }
    }
}

// --- Standalone functions ---
fn extract_candidates(input: &Value) -> Vec<Value> {
    if let Some(arr) = input.get("candidates").and_then(|v| v.as_array()) { return arr.clone(); }
    if let Some(arr) = input.get("allResults").and_then(|v| v.as_array()) { return arr.clone(); }
    if input.get("content").is_some() { return vec![input.clone()]; }
    vec![]
}

fn rule_based_scoring(content: &str, config: &Value) -> RuleResult {
    let mut scores = HashMap::new();
    let mut issues = Vec::new();
    let suggestions = Vec::new();

    let re = Regex::new(r"```(\w*)\n([\s\S]*?)```").unwrap();
    let blocks: Vec<_> = re.captures_iter(content).collect();
    scores.insert("completeness".into(),
        if blocks.is_empty() { 20.0 } else { f64::min(100.0, 60.0 + blocks.len() as f64 * 10.0) });

    let expected = config.get("language").and_then(|v| v.as_str()).unwrap_or("").to_lowercase();
    if !expected.is_empty() {
        let has_match = blocks.iter().any(|c| c[1].to_lowercase().contains(&expected));
        scores.insert("correctness".into(), if has_match { 75.0 } else { 40.0 });
    }

    let mut sec = 100.0_f64;
    for pat in &["innerHTML", "eval(", "document.write"] {
        if content.to_lowercase().contains(&pat.to_lowercase()) {
            sec -= 15.0;
            issues.push(format!("Security: found '{pat}'"));
        }
    }
    scores.insert("security".into(), sec.max(0.0));

    let generic = Regex::new(r"\b(var1|temp|foo|bar)\b").unwrap();
    scores.insert("codeStyle".into(), if generic.is_match(content) { 45.0 } else { 70.0 });

    let nested = Regex::new(r"(?s)for.*\{[^}]*for.*\{").unwrap();
    scores.insert("performance".into(), if nested.is_match(content) { 55.0 } else { 75.0 });

    RuleResult { scores, issues, suggestions }
}

fn weighted_score(scores: &HashMap<String, f64>, criteria: &HashMap<String, CriterionConfig>) -> f64 {
    let (mut total_w, mut weighted) = (0.0, 0.0);
    for (k, cc) in criteria {
        if let Some(&s) = scores.get(k) {
            weighted += s * cc.weight;
            total_w += cc.weight;
        }
    }
    if total_w > 0.0 { weighted / total_w } else { 0.0 }
}

fn select_best<'a>(candidates: &'a [&CandidateResult], config: &AiReviewConfig) -> &'a CandidateResult {
    match config.selection_strategy.as_str() {
        "highest-minimum" => candidates.iter()
            .max_by(|a, b| {
                let a_min = a.scores.values().copied().fold(f64::INFINITY, f64::min);
                let b_min = b.scores.values().copied().fold(f64::INFINITY, f64::min);
                a_min.partial_cmp(&b_min).unwrap()
            }).unwrap(),
        _ => candidates.iter()
            .max_by(|a, b| a.total_score.partial_cmp(&b.total_score).unwrap())
            .unwrap(),
    }
}
