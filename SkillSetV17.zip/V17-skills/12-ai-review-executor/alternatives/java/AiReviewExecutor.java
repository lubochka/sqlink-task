/**
 * Skill 12: AI Review Executor — Java 21
 * Evaluates multiple AI outputs, scores per criteria, selects best.
 * Genie DNA: Dynamic docs (Map), BuildSearchFilter, DataProcessResult per candidate.
 */
package com.xiigen.skills.aireview;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;
import java.util.stream.*;

// --- Configuration ---
record CriterionConfig(double weight, double minScore) {}

record AiReviewConfig(
    String reviewModel,
    String reviewStrategy,
    String selectionStrategy,
    Map<String, CriterionConfig> criteria,
    double approveThreshold,
    double reviseThreshold,
    boolean enableRulePreFilter,
    int maxReviewTokens,
    boolean skipIfSingle
) {
    static AiReviewConfig defaults() {
        return new AiReviewConfig(
            "claude-sonnet-4-20250514", "hybrid", "highest-total",
            Map.of(
                "correctness",  new CriterionConfig(0.30, 60),
                "completeness", new CriterionConfig(0.25, 50),
                "codeStyle",    new CriterionConfig(0.15, 40),
                "performance",  new CriterionConfig(0.15, 40),
                "security",     new CriterionConfig(0.15, 70)
            ),
            80, 50, true, 2000, false
        );
    }
}

// --- Interfaces ---
interface IAiDispatcher {
    CompletableFuture<Map<String, Object>> dispatch(Map<String, Object> request);
}

// --- Main Executor ---
public class AiReviewExecutor {

    private final AiReviewConfig config;
    private final IAiDispatcher aiDispatcher;

    public AiReviewExecutor(AiReviewConfig config, IAiDispatcher aiDispatcher) {
        this.config = config != null ? config : AiReviewConfig.defaults();
        this.aiDispatcher = aiDispatcher;
    }

    public Map<String, Object> execute(Map<String, Object> context) {
        long startTime = System.currentTimeMillis();
        var debug = new LinkedHashMap<String, Object>();
        debug.put("executionId", UUID.randomUUID().toString());
        debug.put("startedAt", Instant.now().toString());

        try {
            var candidates = extractCandidates(asMap(context.get("input")));
            debug.put("candidateCount", candidates.size());

            if (candidates.isEmpty()) throw new RuntimeException("No candidates to review");

            if (candidates.size() == 1 && config.skipIfSingle()) {
                return Map.of("success", true, "output", Map.of(
                    "selectedIndex", 0, "selectedContent", candidates.getFirst().getOrDefault("content", ""),
                    "verdict", "APPROVE", "totalScore", 100.0,
                    "reviewSummary", "Single candidate — auto-approved"
                ), "debugData", debug, "durationMs", elapsed(startTime));
            }

            // Score candidates (DNA-5: DataProcessResult)
            var scored = new ArrayList<Map<String, Object>>();
            for (int i = 0; i < candidates.size(); i++) {
                scored.add(scoreCandidate(i, candidates.get(i), context));
            }

            var successful = scored.stream()
                .filter(r -> Boolean.TRUE.equals(r.get("success")))
                .toList();

            if (successful.isEmpty()) throw new RuntimeException("All candidates failed review");

            var selected = selectBest(successful);
            var meta = asMap(selected.get("metadata"));
            double totalScore = ((Number) meta.getOrDefault("totalScore", 0.0)).doubleValue();
            String verdict = totalScore >= config.approveThreshold() ? "APPROVE"
                           : totalScore >= config.reviseThreshold() ? "REVISE" : "REJECT";

            var allScores = scored.stream().map(r -> {
                var m = asMap(r.get("metadata"));
                return Map.<String, Object>of(
                    "candidateIndex", m.getOrDefault("candidateIndex", 0),
                    "model", m.getOrDefault("model", "unknown"),
                    "scores", m.getOrDefault("scores", Map.of()),
                    "totalScore", m.getOrDefault("totalScore", 0.0),
                    "success", r.getOrDefault("success", false)
                );
            }).toList();

            return Map.of("success", true, "output", Map.of(
                "selectedIndex", meta.getOrDefault("candidateIndex", 0),
                "selectedModel", meta.getOrDefault("model", "unknown"),
                "selectedContent", asMap(selected.get("item")).getOrDefault("content", ""),
                "totalScore", totalScore, "allScores", allScores, "verdict", verdict,
                "reviewSummary", "Selected %s (score %.1f/100). Verdict: %s.".formatted(
                    meta.getOrDefault("model", "unknown"), totalScore, verdict)
            ), "debugData", debug, "durationMs", elapsed(startTime));

        } catch (Exception e) {
            debug.put("error", e.getMessage());
            return Map.of("success", false, "output", Map.of(),
                "error", e.getMessage(), "debugData", debug, "durationMs", elapsed(startTime));
        }
    }

    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> extractCandidates(Map<String, Object> input) {
        if (input.get("candidates") instanceof List<?> l) return (List<Map<String, Object>>) l;
        if (input.get("allResults") instanceof List<?> l) return (List<Map<String, Object>>) l;
        if (input.containsKey("content")) return List.of(input);
        return List.of();
    }

    private Map<String, Object> scoreCandidate(int index, Map<String, Object> candidate, Map<String, Object> context) {
        try {
            String content = String.valueOf(candidate.getOrDefault("content", ""));
            String model = String.valueOf(candidate.getOrDefault("model", "unknown"));
            var scores = new LinkedHashMap<String, Double>();
            var issues = new ArrayList<String>();

            if (config.reviewStrategy().equals("rule") || config.reviewStrategy().equals("hybrid")) {
                var rule = ruleBasedScoring(content, asMap(context.get("configuration")));
                scores.putAll(rule.scores());
                issues.addAll(rule.issues());

                if (config.enableRulePreFilter()) {
                    for (var entry : rule.scores().entrySet()) {
                        var cc = config.criteria().get(entry.getKey());
                        if (cc != null && entry.getValue() < cc.minScore()) {
                            return Map.of("success", false, "item", candidate,
                                "error", "%s score %.0f < min %.0f".formatted(entry.getKey(), entry.getValue(), cc.minScore()),
                                "metadata", Map.of("candidateIndex", index, "model", model, "scores", scores, "totalScore", 0.0));
                        }
                    }
                }
            }

            double total = weightedScore(scores, config.criteria());
            return Map.of("success", true, "item", candidate,
                "metadata", Map.<String, Object>of(
                    "candidateIndex", index, "model", model,
                    "scores", scores, "totalScore", total,
                    "issues", issues, "suggestions", List.of()));
        } catch (Exception e) {
            return Map.of("success", false, "item", candidate,
                "error", e.getMessage(), "metadata", Map.of("candidateIndex", index));
        }
    }

    record RuleResult(Map<String, Double> scores, List<String> issues) {}

    private RuleResult ruleBasedScoring(String content, Map<String, Object> config) {
        var scores = new LinkedHashMap<String, Double>();
        var issues = new ArrayList<String>();

        var pattern = Pattern.compile("```(\\w*)\\n([\\s\\S]*?)```");
        var matcher = pattern.matcher(content);
        int blockCount = 0;
        var langs = new ArrayList<String>();
        while (matcher.find()) { blockCount++; langs.add(matcher.group(1).toLowerCase()); }

        scores.put("completeness", blockCount > 0 ? Math.min(100, 60 + blockCount * 10.0) : 20.0);

        String expected = String.valueOf(config.getOrDefault("language", "")).toLowerCase();
        if (!expected.isEmpty()) {
            boolean match = langs.stream().anyMatch(l -> l.contains(expected) ||
                (expected.equals("typescript") && l.equals("tsx")));
            scores.put("correctness", match ? 75.0 : 40.0);
        }

        double sec = 100.0;
        for (var pat : List.of("innerHTML", "eval(", "document.write")) {
            if (content.toLowerCase().contains(pat.toLowerCase())) { sec -= 15; issues.add("Security: " + pat); }
        }
        scores.put("security", Math.max(0, sec));
        scores.put("codeStyle", content.matches(".*\\b(var1|temp|foo|bar)\\b.*") ? 45.0 : 70.0);
        scores.put("performance", content.matches("(?s)for.*\\{[^}]*for.*\\{") ? 55.0 : 75.0);

        return new RuleResult(scores, issues);
    }

    private double weightedScore(Map<String, Double> scores, Map<String, CriterionConfig> criteria) {
        double totalW = 0, weighted = 0;
        for (var e : criteria.entrySet()) {
            if (scores.containsKey(e.getKey())) {
                weighted += scores.get(e.getKey()) * e.getValue().weight();
                totalW += e.getValue().weight();
            }
        }
        return totalW > 0 ? weighted / totalW : 0;
    }

    private Map<String, Object> selectBest(List<Map<String, Object>> candidates) {
        return switch (config.selectionStrategy()) {
            case "highest-minimum" -> candidates.stream()
                .max(Comparator.comparingDouble(c -> {
                    var s = asMap(asMap(c.get("metadata")).get("scores"));
                    return s.values().stream().mapToDouble(v -> ((Number) v).doubleValue()).min().orElse(0);
                })).orElseThrow();
            default -> candidates.stream()
                .max(Comparator.comparingDouble(c ->
                    ((Number) asMap(c.get("metadata")).getOrDefault("totalScore", 0.0)).doubleValue()
                )).orElseThrow();
        };
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> asMap(Object o) {
        return o instanceof Map ? (Map<String, Object>) o : Map.of();
    }

    private long elapsed(long start) { return System.currentTimeMillis() - start; }
}
