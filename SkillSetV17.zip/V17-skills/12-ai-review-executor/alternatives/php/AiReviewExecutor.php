<?php
/**
 * Skill 12: AI Review Executor — PHP 8.3
 * Evaluates multiple AI outputs, scores per criteria, selects best.
 * Genie DNA: Dynamic docs (arrays), DataProcessResult per candidate.
 */

declare(strict_types=1);

namespace XIIGen\Skills\AiReview;

interface AiDispatcherInterface
{
    /** @return array{success: bool, content?: string, model?: string, error?: string} */
    public function dispatch(array $request): array;
}

readonly class CriterionConfig
{
    public function __construct(public float $weight, public float $minScore) {}
}

readonly class AiReviewConfig
{
    public function __construct(
        public string $reviewModel = 'claude-sonnet-4-20250514',
        public string $reviewStrategy = 'hybrid',
        public string $selectionStrategy = 'highest-total',
        public array $criteria = [],
        public float $approveThreshold = 80,
        public float $reviseThreshold = 50,
        public bool $enableRulePreFilter = true,
        public int $maxReviewTokens = 2000,
        public bool $skipIfSingle = false,
    ) {}

    public static function defaults(): self
    {
        return new self(criteria: [
            'correctness'  => new CriterionConfig(0.30, 60),
            'completeness' => new CriterionConfig(0.25, 50),
            'codeStyle'    => new CriterionConfig(0.15, 40),
            'performance'  => new CriterionConfig(0.15, 40),
            'security'     => new CriterionConfig(0.15, 70),
        ]);
    }
}

class AiReviewExecutor
{
    private readonly AiReviewConfig $config;

    public function __construct(
        ?AiReviewConfig $config = null,
        private readonly ?AiDispatcherInterface $aiDispatcher = null,
    ) {
        $this->config = $config ?? AiReviewConfig::defaults();
    }

    public function execute(array $context): array
    {
        $startTime = hrtime(true);
        $debug = ['executionId' => $this->uuid(), 'startedAt' => date('c')];

        try {
            $candidates = $this->extractCandidates($context['input'] ?? []);
            $debug['candidateCount'] = count($candidates);

            if (empty($candidates)) throw new \RuntimeException('No candidates to review');

            if (count($candidates) === 1 && $this->config->skipIfSingle) {
                return ['success' => true, 'output' => [
                    'selectedIndex' => 0, 'selectedContent' => $candidates[0]['content'] ?? '',
                    'verdict' => 'APPROVE', 'totalScore' => 100.0,
                    'reviewSummary' => 'Single candidate — auto-approved',
                ], 'debugData' => $debug, 'durationMs' => $this->elapsed($startTime)];
            }

            // Score candidates (DNA-5: DataProcessResult)
            $scored = [];
            foreach ($candidates as $i => $candidate) {
                $scored[] = $this->scoreCandidate($i, $candidate, $context);
            }

            $successful = array_filter($scored, fn($r) => $r['success']);
            if (empty($successful)) throw new \RuntimeException('All candidates failed review');

            $selected = $this->selectBest(array_values($successful));
            $total = $selected['metadata']['totalScore'];
            $verdict = match (true) {
                $total >= $this->config->approveThreshold => 'APPROVE',
                $total >= $this->config->reviseThreshold  => 'REVISE',
                default => 'REJECT',
            };

            $allScores = array_map(fn($r, $i) => [
                'candidateIndex' => $i,
                'model' => $r['metadata']['model'] ?? 'unknown',
                'scores' => $r['metadata']['scores'] ?? [],
                'totalScore' => $r['metadata']['totalScore'] ?? 0,
                'issues' => $r['metadata']['issues'] ?? [],
                'success' => $r['success'],
            ], $scored, array_keys($scored));

            return ['success' => true, 'output' => [
                'selectedIndex' => $selected['metadata']['candidateIndex'],
                'selectedModel' => $selected['metadata']['model'],
                'selectedContent' => $selected['item']['content'] ?? '',
                'totalScore' => $total, 'allScores' => $allScores, 'verdict' => $verdict,
                'reviewSummary' => sprintf('Selected %s (score %.1f/100). Verdict: %s.',
                    $selected['metadata']['model'], $total, $verdict),
            ], 'debugData' => $debug, 'durationMs' => $this->elapsed($startTime)];

        } catch (\Throwable $e) {
            return ['success' => false, 'output' => [], 'error' => $e->getMessage(),
                'debugData' => [...$debug, 'error' => $e->getMessage()],
                'durationMs' => $this->elapsed($startTime)];
        }
    }

    private function extractCandidates(array $input): array
    {
        if (isset($input['candidates']) && is_array($input['candidates'])) return $input['candidates'];
        if (isset($input['allResults']) && is_array($input['allResults'])) return $input['allResults'];
        if (isset($input['content'])) return [$input];
        return [];
    }

    private function scoreCandidate(int $index, array $candidate, array $context): array
    {
        try {
            $content = (string)($candidate['content'] ?? '');
            $model = (string)($candidate['model'] ?? 'unknown');
            $scores = [];
            $issues = [];
            $suggestions = [];

            if (in_array($this->config->reviewStrategy, ['rule', 'hybrid'])) {
                $rule = $this->ruleBasedScoring($content, $context['configuration'] ?? []);
                $scores = array_merge($scores, $rule['scores']);
                $issues = array_merge($issues, $rule['issues']);
                $suggestions = array_merge($suggestions, $rule['suggestions']);

                if ($this->config->enableRulePreFilter) {
                    foreach ($rule['scores'] as $crit => $score) {
                        $cc = $this->config->criteria[$crit] ?? null;
                        if ($cc && $score < $cc->minScore) {
                            return ['success' => false, 'item' => $candidate,
                                'error' => "{$crit} score {$score} < min {$cc->minScore}",
                                'metadata' => ['candidateIndex' => $index, 'model' => $model,
                                    'scores' => $scores, 'totalScore' => 0.0, 'issues' => $issues, 'suggestions' => $suggestions]];
                        }
                    }
                }
            }

            $total = $this->weightedScore($scores, $this->config->criteria);
            return ['success' => true, 'item' => $candidate,
                'metadata' => ['candidateIndex' => $index, 'model' => $model,
                    'scores' => $scores, 'totalScore' => $total, 'issues' => $issues, 'suggestions' => $suggestions]];
        } catch (\Throwable $e) {
            return ['success' => false, 'item' => $candidate, 'error' => $e->getMessage(),
                'metadata' => ['candidateIndex' => $index]];
        }
    }

    private function ruleBasedScoring(string $content, array $config): array
    {
        $scores = [];
        $issues = [];
        $suggestions = [];

        preg_match_all('/```(\w*)\n([\s\S]*?)```/', $content, $matches, PREG_SET_ORDER);
        $blockCount = count($matches);
        $scores['completeness'] = $blockCount > 0 ? min(100, 60 + $blockCount * 10) : 20;
        if ($blockCount === 0) $issues[] = 'No code blocks found';

        $expected = strtolower($config['language'] ?? '');
        if ($expected) {
            $hasMatch = false;
            foreach ($matches as $m) {
                if (str_contains(strtolower($m[1]), $expected)) { $hasMatch = true; break; }
            }
            $scores['correctness'] = $hasMatch ? 75 : 40;
        }

        $sec = 100.0;
        foreach (['innerHTML', 'eval(', 'document.write'] as $pat) {
            if (stripos($content, $pat) !== false) { $sec -= 15; $issues[] = "Security: found '{$pat}'"; }
        }
        $scores['security'] = max(0, $sec);
        $scores['codeStyle'] = preg_match('/\b(var1|temp|foo|bar)\b/', $content) ? 45 : 70;
        $scores['performance'] = preg_match('/for.*\{[^}]*for.*\{/s', $content) ? 55 : 75;

        return ['scores' => $scores, 'issues' => $issues, 'suggestions' => $suggestions];
    }

    private function weightedScore(array $scores, array $criteria): float
    {
        $totalW = 0;
        $weighted = 0;
        foreach ($criteria as $key => $cc) {
            if (isset($scores[$key])) {
                $weighted += $scores[$key] * $cc->weight;
                $totalW += $cc->weight;
            }
        }
        return $totalW > 0 ? $weighted / $totalW : 0;
    }

    private function selectBest(array $candidates): array
    {
        return match ($this->config->selectionStrategy) {
            'highest-minimum' => $this->maxBy($candidates, function ($c) {
                $scores = $c['metadata']['scores'] ?? [];
                return empty($scores) ? 0 : min($scores);
            }),
            default => $this->maxBy($candidates, fn($c) => $c['metadata']['totalScore'] ?? 0),
        };
    }

    private function maxBy(array $items, callable $fn): array
    {
        return array_reduce($items, fn($best, $item) =>
            $best === null || $fn($item) > $fn($best) ? $item : $best
        );
    }

    private function uuid(): string
    {
        return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000, mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff));
    }

    private function elapsed(int $start): int
    {
        return (int)((hrtime(true) - $start) / 1_000_000);
    }
}
