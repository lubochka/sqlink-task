# How to Continue XIIGen V17

## Quick Resume
Say: `Continue XIIGen V17 — alternatives sprint` (biggest gap to close)

## Current Reality (2026-02-08)
```
✅ 49 skill directories with SKILL.md + prompts
✅ 46/49 skills have quality SKILL.md (>3KB, DNA-compliant)
❌ 0/49 skills have complete language alternatives (5 per skill)
❌ 18 new skills (46-63) not yet created
Overall: ~30% complete
```

## Recommended Sprint Order
```
Sprint 1: Alternatives for Foundation    (00a-09)  — 50 files
Sprint 2: Alternatives for Pipeline      (09-16)   — 40 files
Sprint 3: Alternatives for Platform      (17-24)   — 40 files
Sprint 4: Alternatives for QA+Specialty  (28-45)   — 89 files
Sprint 5: Enhance + Alts for Clients     (25-27)   — 18 files
Sprint 6: New UML Skills                 (46-63)   — 144 files
Sprint 7: Flow Defs + Final Assembly     (—)       — 13 files
```

## Per-Skill Standard
1. SKILL.md (>3KB) — YAML frontmatter + DNA + component classification
2. .NET Implementation (>3KB) — interfaces, DI, DataProcessResult
3. 5 Language Alternatives (>2KB each) — Node.js, Python, Java, Rust, PHP
4. prompts/implement.md — step-by-step with DNA checklist

## Key Files
- `V17_COMPLETION_PLAN.md` — Full corrected plan
- `V17_STATE.md` — Honest current status
- `GENIE_DNA_GUIDE.md` — DNA patterns every skill must follow
- `FREEDOM_MACHINE_GUIDE.md` — MACHINE vs FREEDOM philosophy
- `ROUTING_GUIDE.md` — Which skills for which scenario
- `SKILL_FACTORY.md` — Template for creating new skills
- `UML_COVERAGE_ANALYSIS.md` — Gap analysis driving skills 46-63

## Critical Context
- **The alternatives gap is the #1 blocker** — SKILL.md quality is already good
- All alternative empty directories already exist — just need README.md content
- Each alternative should implement same interface as .NET primary
- Use framework-appropriate patterns per language
- Previous session created 1 alternative (skill 35 nodejs) as template
