# XIIGen V16 — Skill Factory Template
## Copy this structure for every new skill. Fill in the [PLACEHOLDERS].

---

## SKILL.md Template

```markdown
# Skill [XX]: [Skill Name]
## [One-line description of what this skill does]

**Status:** Ready to Generate  
**Priority:** [P0-P3]  
**Dependencies:** [Skill XX (Name), Skill YY (Name)]  
**Layer:** [L1-L9: Layer Name]  
**Phase:** [4-9]  
**Estimated LOC:** ~[number]  

---

## Overview

[2-3 sentences explaining WHAT this service does and WHY it exists in XIIGen.
Include the business value and how it connects to the flow engine.]

## Key Concepts

- **[Concept 1]** — [Explanation]
- **[Concept 2]** — [Explanation]

---

## Primary Implementation (.NET 9)

### Models

\```csharp
// File: XIIGen.[Project]/Models/[ModelName].cs
namespace XIIGen.[Project].Models;

public record [ModelName](
    string Id,
    [properties with types],
    DateTime CreatedAt = default
);
\```

### Service Interface

\```csharp
// File: XIIGen.[Project]/Interfaces/I[ServiceName].cs
namespace XIIGen.[Project].Interfaces;

public interface I[ServiceName]
{
    Task<DataProcessResult<[ReturnType]>> [Method1]Async([params], CancellationToken ct = default);
    Task<DataProcessResult<[ReturnType]>> [Method2]Async([params], CancellationToken ct = default);
}
\```

### Service Implementation

\```csharp
// File: XIIGen.[Project]/Services/[ServiceName].cs
namespace XIIGen.[Project].Services;

public class [ServiceName] : I[ServiceName]
{
    private readonly IDatabaseService _db;
    private readonly ILogger<[ServiceName]> _logger;
    private const string IndexName = "[es-index-name]";

    public [ServiceName](IDatabaseService db, ILogger<[ServiceName]> logger)
    {
        _db = db;
        _logger = logger;
    }

    public async Task<DataProcessResult<[ReturnType]>> [Method1]Async([params], CancellationToken ct = default)
    {
        try
        {
            // Implementation
            return DataProcessResult<[ReturnType]>.Success(result);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[ServiceName].[Method1] failed");
            return DataProcessResult<[ReturnType]>.Error(ex.Message);
        }
    }
}
\```

### DI Registration

\```csharp
// File: XIIGen.[Project]/Extensions/[ServiceName]Extensions.cs
namespace XIIGen.[Project].Extensions;

public static class [ServiceName]Extensions
{
    public static IServiceCollection AddXIIGen[FeatureName](this IServiceCollection services)
    {
        services.AddSingleton<I[ServiceName], [ServiceName]>();
        return services;
    }
}
\```

### API Endpoints (if applicable)

\```csharp
// File: XIIGen.Api/Endpoints/[Feature]Endpoints.cs
app.MapGroup("/api/[feature]")
    .MapGet("/", async (I[ServiceName] svc, CancellationToken ct) =>
        Results.Ok(await svc.[Method1]Async(ct)))
    .MapPost("/", async ([RequestType] req, I[ServiceName] svc, CancellationToken ct) =>
        Results.Ok(await svc.[Method2]Async(req, ct)));
\```

### Elasticsearch Index

\```json
{
  "mappings": {
    "properties": {
      "id": { "type": "keyword" },
      [field mappings]
    }
  }
}
\```

---

## Tests

\```csharp
public class [ServiceName]Tests
{
    private readonly Mock<IDatabaseService> _mockDb = new();
    private readonly [ServiceName] _svc;

    public [ServiceName]Tests()
    {
        _svc = new [ServiceName](_mockDb.Object, Mock.Of<ILogger<[ServiceName]>>());
    }

    [Fact]
    public async Task [Method1]_ValidInput_ReturnsSuccess()
    {
        // Arrange
        // Act
        // Assert
    }

    [Fact]
    public async Task [Method1]_InvalidInput_ReturnsError()
    {
        // Arrange
        // Act
        // Assert
    }
}
\```

---

## Alternatives

| Language | File | Framework | Key Differences |
|----------|------|-----------|-----------------|
| Node.js | `alternatives/nodejs/[file].ts` | Fastify + TypeScript | [diff] |
| Python | `alternatives/python/[file].py` | FastAPI + Pydantic | [diff] |
| Java | `alternatives/java/[File].java` | Spring Boot 3 | [diff] |
| Rust | `alternatives/rust/[file].rs` | Axum + Serde | [diff] |
| PHP | `alternatives/php/[File].php` | Laravel 11 | [diff] |
```

---

## alternatives/nodejs/[file].ts Template

```typescript
// XIIGen Skill [XX] — [Name] (Node.js/Fastify)
import Fastify from 'fastify';

interface [ModelName] {
  id: string;
  [properties]: [types];
  createdAt: Date;
}

interface I[ServiceName] {
  [method1](params): Promise<DataProcessResult<[ReturnType]>>;
}

class [ServiceName] implements I[ServiceName] {
  constructor(private db: IDatabaseService, private logger: Logger) {}
  
  async [method1](params): Promise<DataProcessResult<[ReturnType]>> {
    try {
      // Implementation
      return { status: 'Success', data: result };
    } catch (error) {
      return { status: 'Error', message: error.message };
    }
  }
}

// Fastify plugin registration
export default async function [featureName]Plugin(app: FastifyInstance) {
  const svc = new [ServiceName](app.db, app.log);
  app.get('/api/[feature]', async (req, reply) => reply.send(await svc.[method1]()));
  app.post('/api/[feature]', async (req, reply) => reply.send(await svc.[method2](req.body)));
}
```

---

## alternatives/python/[file].py Template

```python
# XIIGen Skill [XX] — [Name] (Python/FastAPI)
from fastapi import APIRouter, Depends
from pydantic import BaseModel
from datetime import datetime

class [ModelName](BaseModel):
    id: str
    # [properties]
    created_at: datetime = datetime.utcnow()

class [ServiceName]:
    def __init__(self, db, logger):
        self.db = db
        self.logger = logger
    
    async def [method1](self, params) -> dict:
        try:
            # Implementation
            return {"status": "Success", "data": result}
        except Exception as e:
            self.logger.error(f"[ServiceName].[method1] failed: {e}")
            return {"status": "Error", "message": str(e)}

router = APIRouter(prefix="/api/[feature]")

@router.get("/")
async def get_[feature](svc: [ServiceName] = Depends()):
    return await svc.[method1]()
```

---

## alternatives/java/[File].java Template

```java
// XIIGen Skill [XX] — [Name] (Java/Spring Boot)
package com.xiigen.[feature];

@Service
public class [ServiceName] {
    private final DatabaseService db;
    private final Logger logger = LoggerFactory.getLogger([ServiceName].class);
    
    public [ServiceName](DatabaseService db) { this.db = db; }
    
    public DataProcessResult<[ReturnType]> [method1]([params]) {
        try {
            // Implementation
            return DataProcessResult.success(result);
        } catch (Exception e) {
            logger.error("[ServiceName].[method1] failed", e);
            return DataProcessResult.error(e.getMessage());
        }
    }
}

@RestController @RequestMapping("/api/[feature]")
public class [Feature]Controller {
    @Autowired private [ServiceName] svc;
    @GetMapping public ResponseEntity<?> get() { return ResponseEntity.ok(svc.[method1]()); }
}
```

---

## alternatives/rust/[file].rs Template

```rust
// XIIGen Skill [XX] — [Name] (Rust/Axum)
use axum::{Router, routing::{get, post}, Json, extract::State};
use serde::{Serialize, Deserialize};

#[derive(Serialize, Deserialize, Clone)]
pub struct [ModelName] {
    pub id: String,
    // [properties]
    pub created_at: chrono::DateTime<chrono::Utc>,
}

pub struct [ServiceName] {
    db: Arc<dyn DatabaseService>,
}

impl [ServiceName] {
    pub fn new(db: Arc<dyn DatabaseService>) -> Self { Self { db } }
    
    pub async fn [method1](&self, params) -> DataProcessResult<[ReturnType]> {
        match self.db.query(/* */).await {
            Ok(result) => DataProcessResult::success(result),
            Err(e) => DataProcessResult::error(e.to_string()),
        }
    }
}

pub fn routes() -> Router<AppState> {
    Router::new()
        .route("/api/[feature]", get([method1]_handler))
        .route("/api/[feature]", post([method2]_handler))
}
```

---

## alternatives/php/[File].php Template

```php
<?php
// XIIGen Skill [XX] — [Name] (PHP/Laravel)
namespace App\Services;

class [ServiceName] {
    public function __construct(
        private DatabaseService $db,
        private \Psr\Log\LoggerInterface $logger
    ) {}
    
    public function [method1]($params): array {
        try {
            // Implementation
            return ['status' => 'Success', 'data' => $result];
        } catch (\Exception $e) {
            $this->logger->error("[ServiceName].[method1] failed: " . $e->getMessage());
            return ['status' => 'Error', 'message' => $e->getMessage()];
        }
    }
}

// Routes (routes/api.php)
Route::prefix('api/[feature]')->group(function () {
    Route::get('/', [[Feature]Controller::class, 'index']);
    Route::post('/', [[Feature]Controller::class, 'store']);
});
```

---

## prompts/implement.md Template

```markdown
# Implement Skill [XX]: [Name]

## Context
Read `skills/[XX]-[name]/SKILL.md` for the complete specification.
Dependencies: [list skills with file paths]

## Steps
1. Create models in `XIIGen.[Project]/Models/[ModelName].cs`
2. Create interface in `XIIGen.[Project]/Interfaces/I[ServiceName].cs`
3. Create service in `XIIGen.[Project]/Services/[ServiceName].cs`
4. Create DI extension in `XIIGen.[Project]/Extensions/[ServiceName]Extensions.cs`
5. Add API endpoints in `XIIGen.Api/Endpoints/[Feature]Endpoints.cs`
6. Register in `Program.cs`: `builder.Services.AddXIIGen[FeatureName]();`
7. Create tests in `XIIGen.Tests/[ServiceName]Tests.cs`

## Verification
- [ ] All methods return DataProcessResult<T>
- [ ] Elasticsearch index created on first write
- [ ] DI registration works
- [ ] Tests pass with `dotnet test`
```

---

## CHECKLIST — Before Marking a Skill Complete

- [ ] SKILL.md has 200+ lines of actual code (not comments)
- [ ] All public methods documented with XML comments
- [ ] All methods return DataProcessResult<T>
- [ ] Error handling with try/catch and logging
- [ ] DI registration extension method
- [ ] ES index definition with proper mappings
- [ ] 5 alternative implementations (nodejs, python, java, rust, php)
- [ ] Each alternative has complete, runnable code (not stubs)
- [ ] Implementation prompt in prompts/implement.md
- [ ] At least 2 test cases (happy path + error path)
