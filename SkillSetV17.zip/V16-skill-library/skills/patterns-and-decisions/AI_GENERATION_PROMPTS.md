# AI Generation Prompts
## Teaching AI Agents to Think Dynamically

> These prompts are designed to be fed to AI agents (Claude, GPT, Gemini, Copilot)
> when they need to generate new implementations of the Genie DNA patterns.
> Each prompt encodes the PHILOSOPHY, not just the code pattern.

---

## Meta-Prompt: The Thinking Framework

Use this before any specific pattern prompt to set the AI's mindset:

```
CONTEXT: You are building on a platform whose core philosophy is:
"Free business users from depending on developers."

Every design decision follows one rule:
If a business user might want to define, change, or extend something → it MUST be dynamic.
Only the machine that ENABLES that freedom is static.

THINKING FRAMEWORK:
Before writing any code, classify each component:
- MACHINE (static): Infrastructure that enables freedom. Build once, generic, interface-based.
- FREEDOM (dynamic): Anything users define. No fixed models, no entity-specific code, 
  config-driven.

THE TEST for every component:
1. Can a business user change this without a developer? (YES = correct)
2. Does it work for entity types that don't exist yet? (YES = correct)
3. Can I swap the database/service/UI without changing this? (YES = correct)
```

---

## Prompt 1: Schema-Free Document Processing

### Use When
AI needs to build a data ingestion/storage layer in any technology stack.

### The Prompt
```
BUILD: A schema-free document processing layer for [DOMAIN/TECHNOLOGY].

PHILOSOPHY: Business users define data structures at runtime. The system
accepts ANY JSON shape without predefined models. Adding a new entity type
requires ZERO code changes — only a new name parameter.

REQUIREMENTS:
1. Accept arbitrary JSON input (unknown fields, unknown nesting depth)
2. Recursively process the document tree:
   - If array → process each element recursively
   - If object → process each property recursively
   - If leaf value → auto-detect type in this priority: 
     integer → decimal/float → date/datetime → boolean → string
3. Store the processed result using a generic interface:
   store(entityName, document, id?) → returns id
4. The SAME processing code handles ALL entity types
5. The caller specifies entity type via a NAME parameter, not separate endpoints/functions

MUST NOT:
- Create model/class per entity type (defeats the purpose)
- Use typed deserialization that drops unknown fields
- Require schema registration before accepting data
- Create separate storage endpoints per entity type
- Store all values as strings (kills sorting and filtering)

INTERFACE SHAPE:
  storeDocument(indexName: string, document: any, id?: string): string
  getDocument(indexName: string, id: string): any
  processDocument(rawInput: any): ProcessedDocument  // recursive type detection

POSITIVE EXAMPLE:
  Input:  { "Full name": "Dan", "amount": "1500.50", "approved": "true", "items": [{"qty": "3"}] }
  Output: { "Full name": "Dan", "amount": 1500.50, "approved": true, "items": [{"qty": 3}] }
  → Types auto-detected. No model class. Works for any entity.

NEGATIVE EXAMPLE:
  class InvoiceModel { string FullName; decimal Amount; bool Approved; }
  JsonSerializer.Deserialize<InvoiceModel>(input);
  → WRONG. User can't add fields. New entity types need new classes.

Generate the implementation in [LANGUAGE/FRAMEWORK].
Include the recursive processor, type detection chain, and storage interface.
```

---

## Prompt 2: Dynamic Query Building

### Use When
AI needs to build search/filter functionality against a document store.

### The Prompt
```
BUILD: A dynamic query builder for [DATABASE/TECHNOLOGY].

PHILOSOPHY: Users can search across ANY combination of fields. With N fields,
there are 2^N possible filter combinations. ONE builder handles ALL of them.
No entity-specific query code. No predefined query templates.

REQUIREMENTS:
1. Accept a filter object where fields may or may not be present
2. For each field in the filter:
   - If value is empty/null/undefined → SKIP IT entirely (do NOT add to query)
   - If value is present → create appropriate query clause
3. Support these query operations:
   - CONTAINS (partial text match, case-insensitive)
   - EQUAL (exact match)
   - GREATER_THAN, LESS_THAN, RANGE (numeric/date comparisons)
   - IN, NOT_IN (set membership)
4. Support nested fields via dot-notation: "address.city" → nested query path
5. Combine all non-empty clauses with AND logic
6. Accept a user-scope parameter that gets INJECTED automatically:
   - If user is not admin → add mandatory filter: userId == currentUser
   - This injection happens IN the builder, not in calling code
   - It CANNOT be bypassed or forgotten

MUST NOT:
- Write different query code per entity type
- Require callers to manually skip empty fields
- Build queries with hardcoded field names
- Allow queries to execute without scope injection

INTERFACE SHAPE:
  buildQuery(filter: Record<string, any>, userScope?: UserScope): DatabaseQuery
  
  Where UserScope = { userId: string, isAdmin: boolean }
  If not admin → userId filter automatically added to every query

POSITIVE EXAMPLE:
  Input filter: { "Full name": "Dan", "Id number": "", "status": "active" }
  Built query:  MUST(match("Full name", "*Dan*"), exact("status", "active"))
  → "Id number" skipped because empty. No code needed for this specific combination.

NEGATIVE EXAMPLE:
  if (filter.fullName) { query.add(matchName(filter.fullName)); }
  if (filter.idNumber) { query.add(matchId(filter.idNumber)); }
  if (filter.status) { query.add(matchStatus(filter.status)); }
  → WRONG. Every new field requires new code. Doesn't scale to user-defined fields.

Generate for [DATABASE_TYPE]. Include the empty-field skip logic, 
query type detection, dot-notation support, and automatic scope injection.
```

---

## Prompt 3: Client-Side Filter Assembly

### Use When
AI needs to build dynamic search forms that connect to the query builder.

### The Prompt
```
BUILD: A dynamic filter/search form for [UI_FRAMEWORK].

PHILOSOPHY: Search forms are GENERATED from entity definitions, not hardcoded. 
The user fills whichever fields they want. Only non-empty fields are sent to the server. 
Adding a searchable field = updating the definition, not updating code.

REQUIREMENTS:
1. Read field definitions from a configuration source (API endpoint, JSON, registry)
   Each field definition has: name, type (text/number/date/select/boolean), label, options
2. Render form inputs dynamically from these definitions
3. Track user input:
   - When user enters a value → set field in filter state
   - When user clears a field → REMOVE the key entirely (not set to empty string)
4. On search submit: send only the keys that have values (sparse object)
5. Support field types: text (free input), date range, dropdown (with options), number, boolean

MUST NOT:
- Hardcode field names in components (e.g., <input name="fullName" />)
- Send empty fields to the server
- Require component changes when entity definitions change
- Create separate form components per entity type

INTERFACE SHAPE:
  // Input: field definitions from config
  FieldDefinition = { name: string, type: FieldType, label: string, options?: string[] }
  
  // Output: sparse filter object
  buildFilter(formState) → { [fieldName]: value }  // only non-empty fields
  
  // The same component renders ANY entity type's search form
  <DynamicFilterForm entityName="invoices" onSearch={handleSearch} />

POSITIVE EXAMPLE:
  Definitions: [{ name: "Full name", type: "text" }, { name: "status", type: "select", options: ["active","closed"] }]
  User fills: "Full name" = "Dan", leaves "status" empty
  Sent to server: { "Full name": "Dan" }  ← only the filled field

NEGATIVE EXAMPLE:
  <input name="fullName" value={state.fullName} />
  <input name="idNumber" value={state.idNumber} />
  <select name="status">{hardcodedOptions}</select>
  → WRONG. Adding "branch office" field requires changing the component.

Generate for [FRAMEWORK]. Include the definition reader, dynamic renderer,
sparse filter builder, and server submission.
```

---

## Prompt 4: Entity Definition Registry

### Use When
AI needs to build the entity management backbone — the "single source of truth" that drives forms, tables, queries, and validation.

### The Prompt
```
BUILD: An entity definition registry for [DOMAIN/TECHNOLOGY].

PHILOSOPHY: Entity types are DEFINED, not CODED. Definitions live in configuration.
The definition is the PRODUCT — it IS the user's system. The runtime reads definitions
and derives everything: forms, tables, search, validation, relationships.
Adding a new entity type = adding a definition. ZERO code changes.

REQUIREMENTS:
1. Entity definition structure:
   - name: unique identifier (like "invoices", "requests", "clients")
   - fields: array of field definitions, each with:
     - name, type (text/number/date/boolean/select/relation)
     - validation rules (required, min, max, pattern)
     - display rules (visible in form, visible in table, column order)
     - relation rules (linked entity, display field)
   - metadata: created_by, created_at, version
   
2. Registry operations:
   - Register new entity definition (admin/system action)
   - Get definition by entity name
   - List all entity definitions
   - Update definition (versioned — don't break existing data)
   
3. Integration points — the definition feeds into:
   - Form rendering (Pattern 3): which inputs to show, what validation to apply
   - Table rendering: which columns to display, sort options
   - Query building (Pattern 2): which fields are searchable
   - Document processing (Pattern 1): knows what types to expect
   - Export: which fields to include in Excel/PDF
   
4. Storage: definitions stored as documents themselves (eating our own dog food)
   — use the same schema-free storage as user data

MUST NOT:
- Require code changes to add/modify entity types
- Store definitions in code (classes, enums, constants)
- Have entity-specific logic anywhere in the system (no switch/case on entity name)
- Break existing data when definitions are updated (backward compatible)

POSITIVE EXAMPLE:
  Admin creates definition: { name: "vendor_invoices", fields: [
    { name: "vendor", type: "text", required: true, showInTable: true },
    { name: "amount", type: "number", validation: { min: 0 }, showInTable: true },
    { name: "due_date", type: "date", showInTable: true },
    { name: "status", type: "select", options: ["pending","paid","overdue"], showInTable: true }
  ]}
  → Form auto-renders 4 fields. Table shows 4 columns. Search accepts any combination.
  → User starts entering invoices IMMEDIATELY. No developer involved.

  Next week: admin adds field { name: "department", type: "text" }
  → Form now has 5 fields. Table has 5 columns. Search includes department.
  → Existing invoices still work (they just don't have "department" — which is fine because
    the query builder skips empty/missing fields).

Generate for [TECHNOLOGY]. Include the definition schema, CRUD operations,
version management, and integration hooks for forms/tables/queries.
```

---

## Prompt 5: Automatic Scope Isolation

### Use When
AI needs to build multi-tenant access control that's impossible to bypass.

### The Prompt
```
BUILD: Automatic scope isolation layer for [TECHNOLOGY/FRAMEWORK].

PHILOSOPHY: Data scoping is not a feature — it's a GUARANTEE. Every query that
returns user data MUST be scoped. This happens at the query level, not in application
code. A developer adding a new endpoint CANNOT accidentally expose other users' data
because the scoping is built into the query infrastructure itself.

REQUIREMENTS:
1. User identification:
   - Extract user identity from every request (JWT, session, API key)
   - Look up user in system to verify they exist (token valid ≠ user exists)
   - Determine scope level: admin (see all) / user (see own) / role-based (see granted)

2. Query-level injection:
   - The query builder (Pattern 2) AUTOMATICALLY adds user scope filter
   - For non-admin: inject filter "userId == currentUser" on EVERY query
   - This applies to: search, list, aggregate, count, export, report — EVERYTHING
   - Admin: no filter added (sees all data)
   - Role-based: filter based on granted resource permissions

3. Document-level tagging:
   - When documents are created, they MUST include userId
   - The store flow (Pattern 1) should automatically inject userId from current user
   - Documents without userId are invisible to non-admin users

4. Audit trail:
   - Log: who queried what entity type, with what filters, at what time
   - Flag: any query that returned 0 results (possible access probe)

MUST NOT:
- Check permissions in application code per endpoint (will be forgotten)
- Allow query execution without scope check (no bypass path)
- Trust client-provided userId (always extract from verified JWT)
- Expose the fact that other users' data exists (don't return "access denied" — return empty results)

ARCHITECTURE:
  Request → Auth middleware (verify JWT) → Extract userId
  → Controller calls queryBuilder.search(filter)
  → queryBuilder.search INTERNALLY calls scopeInjector(filter, currentUser)
  → scopeInjector adds userId filter if not admin
  → Database query executes with scope already embedded
  → Results returned — already filtered, guaranteed scoped

  A new developer adds a new endpoint:
  → Uses queryBuilder.search(filter) ← same builder
  → Scope injection happens AUTOMATICALLY
  → They CANNOT forget it because it's in the infrastructure

Generate for [TECHNOLOGY]. Include the auth middleware, scope injector, 
query builder integration, document tagging, and audit logging.
```

---

## Prompt 6: Generic Interface Abstraction

### Use When
AI needs to make any component swappable — databases, queues, AI providers, notification channels.

### The Prompt
```
BUILD: A generic interface with swappable implementations for [COMPONENT_TYPE].

PHILOSOPHY: The platform never locks into a specific technology. Every external
dependency hides behind a generic interface. Swapping the implementation = changing
configuration. ZERO code changes in the consuming services.

PATTERN (from DatabaseFabric):
1. Define an INTERFACE with operations (not technology-specific methods):
   - IDatabaseProvider: connect, storeDocument, getDocuments, deleteDocument
   - IQueueProvider: push, pop, subscribe, acknowledge  
   - IAIProvider: complete, embed, classify
   - INotificationProvider: sendToUser, sendToAll, sendEmail

2. Create a FACTORY that creates the right implementation from config:
   - DatabaseFactory.createProvider(config) → MongoDBProvider | ElasticsearchProvider | RedisProvider
   - Config says which implementation. Factory creates it. Consumer doesn't know or care.

3. Create a FACADE that wraps the interface for convenience:
   - DatabaseFabric wraps IDatabaseProvider with simpler API
   - Handles connection lifecycle, error wrapping, retry logic

4. Multi-tenant via naming convention:
   - getFullIndexName(siteName, indexName) → "site1_invoices"
   - Same interface, same code, different tenant = different namespace

REQUIREMENTS for [COMPONENT_TYPE]:
1. Interface with ALL operations needed (not technology-specific)
2. At least 2 concrete implementations
3. Factory that creates correct implementation from config
4. Facade that adds: connection management, error handling, retry
5. Configuration type that specifies: implementation type, connection string, options

MUST NOT:
- Import technology-specific libraries in consuming code
- Have if/switch statements on implementation type in consuming code
- Expose technology-specific errors to consumers
- Require code changes when adding a new implementation

POSITIVE EXAMPLE (Database):
  // Consumer code — same regardless of database technology:
  const db = await DatabaseFabric.create({ type: "elasticsearch", connectionString: "..." });
  await db.storeDocument("invoices", "site1", document);
  const results = await db.getDocuments("invoices", "site1", searchOptions);
  
  // Change config to MongoDB → ZERO code changes:
  const db = await DatabaseFabric.create({ type: "mongodb", connectionString: "..." });
  // Exact same API calls work.

Generate the interface, factory, facade, and at least 2 implementations for [COMPONENT_TYPE].
```

---

## Prompt 7: Event-Driven Service Composition

### Use When
AI needs to build or extend the microservice orchestration layer.

### The Prompt
```
BUILD: An event-driven service composition layer for [DOMAIN].

PHILOSOPHY: Services don't call each other directly. They communicate through events.
This means: adding a new service = subscribing to existing events. Existing services
don't change. New capabilities emerge from composition, not modification.

ARCHITECTURE (from Gen 3 Base Core):
Each microservice has:
- Queues: Main (incoming), Consumed (processed), Created (outgoing), Archive (history)
- Orchestration: [subscribe to events], [actions], [data sources], [trigger events],
  [initial trace id], [participating processes], [notifications]
- Internal orchestrator agent: knows when to start executing based on event sequence

THE ORCHESTRATOR PATTERN:
1. A FLOW is a sequence of events between services
2. Each flow has a TRACE ID that tracks the entire journey
3. The flow structure contains: active nodes, next actions, completion status
4. It works like "a heap and shared memory for commands for internal threads"
5. Each service's internal agent checks the structure to know when it's their turn

REQUIREMENTS:
1. Event definition: { type, sourceService, traceId, payload, timestamp, version }
2. Service base class with: subscribe(eventType), publish(event), getTraceHistory(traceId)
3. Orchestrator that: defines flows as event sequences, tracks progress per traceId,
   handles failures/retries, supports branching (parallel events), provides visual status
4. Each service inherits base and gets: DB interface, Queue, Auth, Cache, Logger for free

MUST NOT:
- Services call each other via HTTP directly (events only for workflow)
- Hardcode service dependencies (subscribe to events, not to services)
- Lose events (queue with archive for replay)
- Allow flows without trace IDs (every action is traceable)

Generate the event bus, service base class, orchestrator flow engine, 
and example flow for [SPECIFIC_WORKFLOW].
```

---

## Prompt 8: The Abstraction Extraction Prompt

### Use When
AI encounters MULTIPLE similar implementations and needs to extract the common pattern — this is the "meta-prompt" for recognizing new opportunities for dynamic patterns.

### The Prompt
```
ANALYZE these [N] implementations and extract the ABSTRACTION:

[PASTE 2-4 similar code blocks or descriptions]

INSTRUCTIONS:
1. Identify what VARIES between implementations (= dynamic layer)
2. Identify what STAYS THE SAME (= machine layer)
3. Design a GENERIC INTERFACE that captures the stable parts
4. The varying parts should be: configuration, not code
5. Apply the Freedom Machine test:
   - Can a user add a new variant without code changes?
   - Does the interface work for variants that don't exist yet?
   - Can implementations be swapped via configuration?

OUTPUT:
1. The INTERFACE (generic contract)
2. The FACTORY (creates correct implementation from config)
3. A CONFIGURATION SCHEMA (what users/admins specify to get what they want)
4. At least 2 IMPLEMENTATIONS that prove the interface works
5. An AI PROMPT that would regenerate this abstraction in a different context

The goal is: NEVER solve the same problem twice in different code.
Solve it ONCE in the interface. Variations are configuration.
```

---

## How to Use These Prompts

### For AI Coding Assistants (Cursor, Copilot, Claude Code, Cline)
1. Set the Meta-Prompt as system instructions or project context
2. When generating a new feature, prepend the relevant Pattern Prompt
3. The AI will generate code that follows the freedom-machine philosophy

### For Claude AI Projects
1. Upload the entire skill library as project knowledge
2. Add Meta-Prompt to project instructions
3. Use Pattern Prompts when asking Claude to generate specific components

### For XIIGen Pipeline
1. Pattern Prompts become STAGES in the generation pipeline
2. Each stage's prompt slot gets the appropriate Pattern Prompt
3. User's description fills in the [DOMAIN], [TECHNOLOGY], [SPECIFIC] placeholders
4. Feedback from users improves the prompts over time (inject feedback into future runs)

### For Future AI Agents
When an AI agent needs to generate an entire system:
1. Start with Prompt 4 (Entity Definitions) — define what exists
2. Then Prompt 1 (Document Processing) — how to store it
3. Then Prompt 2 (Query Building) — how to find it
4. Then Prompt 3 (Filter Assembly) — how users interact with it
5. Then Prompt 5 (Scope Isolation) — who can see what
6. Then Prompt 6 (Generic Interfaces) — for any external dependencies
7. Then Prompt 7 (Event Composition) — how services talk
8. Use Prompt 8 whenever you see repetition — extract the abstraction

This sequence mirrors the generation ladder: define → store → query → display → secure → compose → abstract.
