# Design Patterns in Genie DNA — Detailed Reference
## All 20 GoF Patterns Mapped to Real Genie Code + Similar Simulations

> **How to read this file:** Each pattern shows (1) how Genie ALREADY uses it, (2) which file to look at, (3) a simulation you can build following the same approach.

---

## Creational Patterns

### 1. Singleton — One Instance, Shared Everywhere

**Genie uses it for:** ElasticClient, MappService, JWT configuration

```csharp
// DynamicServer — Startup.cs
// ElasticClient as Singleton: one connection pool for the whole app
services.AddSingleton<IElasticClient>(sp => {
    var settings = new ConnectionSettings(new Uri(config["ElasticSearch:Url"]))
        .DefaultIndex("default");
    return new ElasticClient(settings);
});

// MappService as Singleton: loads /Mapps/*.json once, caches forever
services.AddSingleton<IMappService, MappService>();
```

**Similar simulation:** Configuration service that loads environment settings once and serves them to all microservices.

**When to use in Genie context:** Any shared resource that's expensive to create and safe to share — database clients, config loaders, logging services.

---

### 2. Factory — Create by Type Without Hardcoding

**Genie uses it for:** MappService.Documents(), DF_DynamicForms.createForm()

```csharp
// MappService.cs — Factory creates entity definitions from JSON files
public Dictionary<string, string> Documents() {
    var files = Directory.GetFiles(Path.Combine(Environment.CurrentDirectory, "Mapps"));
    foreach (var file in files) {
        if (!documents.ContainsKey(Path.GetFileName(file)))
            documents.Add(Path.GetFileName(file), File.ReadAllText(file));
    }
    return documents;
}
// Adding new entity type = just add a JSON file. Factory handles the rest.
```

```php
// DF_DynamicForms.php — Factory creates HTML forms from entity definitions
class DF_DynamicForms implements IDF_DynamicForms {
    public function createForm($systemTableName, $formType, $FormNum) {
        // Factory decides which form to render based on entity type
        // No hardcoded form HTML — all generated from definitions
    }
}
```

**Similar simulation:** Notification factory — create email/SMS/push notification based on user preference stored in ES document. 

**When to use in Genie context:** Any time you need to create different objects based on runtime data — entity forms, export formats, report types.

---

### 3. Builder — Complex Objects Step by Step

**Genie uses it for:** CreateQueryContainerList (query builder), filterBody (filter builder)

```csharp
// DynamicController.cs — CreateQueryContainerList IS a Builder
// Recursively builds an ES bool-filter from JSON, one property at a time
public List<QueryContainer> CreateQueryContainerList(string prefix, string Document, List<QueryContainer> qlist) {
    var result = qlist;  // Accumulator — builds step by step
    // ... processes each JSON property
    // Each non-empty field ADDS a query to the list (builder step)
    if (value != "") {  // Skip empty — the key innovation
        MatchPhrasePrefixQuery queryM = new MatchPhrasePrefixQuery() 
        { Field = newPrefix, Query = value };
        result.Add(queryM);  // Builder adds one more piece
    }
    return result;  // Return the built query
}
```

```javascript
// filterBody.js — Client-side Builder
export const filterBody = (fieldArr, searchWord, searchDateWord) => {
    // Builds the filter object field by field
    for (let i = 0; i < searchWord.length; i++) {
        if (searchWord[i] !== null) {
            originObj[fieldArr[i]] = searchWord[i];  // Add field
        } else {
            delete originObj[fieldArr[i]];  // Remove empty
        }
    }
    return originObj;  // Return built filter
};
```

**Similar simulation:** Report builder — step-by-step construction of complex PDF reports with optional sections, charts, and data tables.

**When to use in Genie context:** Complex query construction, multi-step document assembly, configuration objects with many optional fields.

---

### 4. Prototype — Clone Instead of Create

**Genie uses it for:** Document templates, entity definition copying

```csharp
// DynamicServer — when creating a new document from a template:
// 1. GET existing document from ES
// 2. Clone its structure 
// 3. Modify specific fields
// 4. Store as new document with new ID

// This is Prototype — clone + modify is cheaper than building from scratch
var templateDoc = await _client.GetAsync<object>(templateIndex, templateId);
var newDoc = JsonSerializer.Deserialize<Dictionary<string, object>>(
    JsonSerializer.Serialize(templateDoc.Source)  // Deep clone via serialization
);
newDoc["docId"] = newId;
newDoc["createdAt"] = DateTime.UtcNow;
await _client.IndexAsync(new IndexRequest<object>(newDoc, targetIndex, newId));
```

**Similar simulation:** Game level template — clone a base game board configuration and customize for different difficulty levels.

**When to use in Genie context:** Document templates, form presets, game board configurations, user profile defaults.

---

## Structural Patterns

### 5. Adapter — Make Incompatible Interfaces Work Together

**Genie uses it for:** PHP→.NET migration, cross-stack alternatives

```
// The ENTIRE alternatives/ system is an Adapter pattern:
// Original Genie DNA (.NET):    CreateQueryContainerList(prefix, Document, qlist)
// Node.js Adapter:              createQueryContainerList(filterDoc)
// Python Adapter:               create_query_container_list(filter_doc)
// Rust Adapter:                 create_query_container_list(&filter_doc)
// PHP Adapter:                  createQueryContainerList($filterDoc)
//
// Same BEHAVIOR, adapted to each language's idioms and ES client API
```

```php
// DF_DataBase.php → DynamicController.cs is a historical Adapter:
// PHP MySQL dynamic tables → .NET Elasticsearch dynamic documents
// Different interface (SQL vs REST), same concept (store any structure)
```

**Similar simulation:** Payment adapter — wrap Stripe, PayPal, and local payment gateways behind a unified `PaymentProcessor` interface.

**When to use in Genie context:** Integrating third-party services, migrating between technologies, wrapping legacy code with modern interfaces.

---

### 6. Decorator — Add Features Without Changing Code

**Genie uses it for:** [Authorize] JWT, i18n middleware, CORS

```csharp
// DynamicController.cs — [Authorize] decorates the controller
[Authorize]  // ← Decorator: adds auth checking without touching endpoint logic
[Route("api/[controller]")]
public class DynamicController : ControllerBase {
    // All endpoints get auth for free — decorator pattern
    
    [HttpPost("storeDocument/{index_name}/{id}")]
    public async Task<IActionResult> StoreDocument(...) {
        // Business logic only — auth is handled by decorator
        var users = GetStatUserByClaim(currentUser);
        // ...
    }
}
```

```javascript
// React — i18n as decorator (HOC / Provider wrapper)
// Wraps ALL components with translation context
<I18nextProvider i18n={i18n}>
    <App />  {/* Every child component gets i18n without code changes */}
</I18nextProvider>
```

**Similar simulation:** Logging decorator — wrap any service method to automatically log input/output without changing the method. Caching decorator — wrap any API call to cache results.

**When to use in Genie context:** Cross-cutting concerns (auth, logging, caching, i18n, rate limiting) that apply to many endpoints/components.

---

### 7. Facade — Simple Interface to Complex System

**Genie uses it for:** DynamicController (the PRIMARY facade)

```csharp
// DynamicController IS a Facade over 5+ complex subsystems:
public class DynamicController : ControllerBase {
    private readonly IElasticClient _client;          // ES queries
    private readonly IMappService _mappService;       // Entity definitions
    private readonly IBlobStorageService _blobService; // Azure files
    private readonly IConfiguration _config;          // App settings
    // + ObjectProcess (parsing), JWT (auth), NotificationService (push)
    
    // Simple facade methods:
    [HttpPost("storeDocument/{index_name}/{id}")]     // Store anything
    [HttpPost("searchDocuments/{index_name}")]         // Search anything
    [HttpGet("getDocument/{index_name}/{id}")]         // Get anything
    [HttpPost("getExcel/{index_name}")]                // Export anything
    
    // Caller doesn't know about ObjectProcess, ES queries, userId injection...
    // Just POST JSON, get results. THAT'S Facade.
}
```

**Similar simulation:** Order processing facade — one `processOrder()` method that handles inventory check, payment, shipping, email notification, and analytics tracking.

**When to use in Genie context:** Any controller/handler that coordinates multiple services. Keep the API surface simple, hide complexity inside.

---

### 8. Composite — Tree Structures Processed Recursively

**Genie uses it for:** ParseObjectAlternative (nested documents), CreateQueryContainerList (nested queries)

```csharp
// ParseObjectAlternative IS the Composite pattern:
// It processes a tree of JSON nodes — objects contain objects, arrays contain objects...
// Each node is processed uniformly regardless of depth

public static object ParseObjectAlternative(object Document) {
    if (Document.ToString().IndexOf("[") == 0) {
        // ARRAY node → process each child (Composite: collection of components)
        var results = new List<object>();
        var documents = JsonSerializer.Deserialize<object[]>(Document.ToString());
        for (var i = 0; i < documents.Length; i++)
            results.Add(ParseObjectAlternative(documents[i]));  // Recursive!
        return results.ToArray();
    }
    else if (Document.ToString().IndexOf("{") == 0) {
        // OBJECT node → process each property (Composite: container with children)
        Dictionary<string, object> myObject = new Dictionary<string, object>();
        dynamic stuff = JObject.Parse(Document.ToString());
        foreach (JProperty jproperty in stuff) {
            myObject[jproperty.Name] = ParseObjectAlternative(jproperty.Value); // Recursive!
        }
        return myObject;
    }
    else {
        // LEAF node → parse value (Composite: leaf component)
        return ParseSimpleObject(Document);
    }
}
```

**Similar simulation:** File system processor — recursively process directories (composites) and files (leaves) for backup, search, or analysis.

**When to use in Genie context:** Any recursive data structure — nested documents, category trees, org charts, game board hierarchies.

---

## Behavioral Patterns

### 9. Observer — Subscribe to Changes

**Genie uses it for:** SignalR hub, Redux store, React Context

```csharp
// PushNotificationHub.cs — Server-side Observer (Subject)
public class PushNotificationHub : Hub {
    public async Task SendNotification(string userId, string message) {
        // Notify all SUBSCRIBED clients for this user
        await Clients.User(userId).SendAsync("ReceiveNotification", message);
    }
}
```

```javascript
// Redux store — Observer pattern in DynamicApp
// Actions dispatched → ALL subscribed components re-render
store.dispatch({ type: 'FETCH_TABLE_SUCCESS', payload: data });
// Every component using useSelector(state => state.table) gets notified

// React Native — Context as Observer
dispatch({ type: 'SET_DATA', payload: tickets });
// Every component inside <GlobalContext.Provider> gets updated
```

**Similar simulation:** Live dashboard — when ES document changes, all connected dashboard widgets update in real-time via WebSocket observer.

**When to use in Genie context:** Real-time UI updates, event-driven processing, any "when X changes, Y should react" scenario.

---

### 10. Strategy — Swappable Algorithms

**Genie uses it for:** ParseObjectAlternative type detection, AI provider selection

```csharp
// ObjectProcess.cs — ParseJpropertyObject uses Strategy to detect types
// Tries each strategy in order: int → decimal → DateTime → bool → string
private static object ParseJpropertyObject(JProperty jproperty) {
    var value = jproperty.Value.ToString();
    
    // Strategy 1: Is it an integer?
    if (int.TryParse(value, out int intResult)) return intResult;
    
    // Strategy 2: Is it a decimal?
    if (decimal.TryParse(value, out decimal decResult)) return decResult;
    
    // Strategy 3: Is it a DateTime?
    if (DateTime.TryParse(value, out DateTime dateResult)) return dateResult;
    
    // Strategy 4: Is it a boolean?
    if (bool.TryParse(value, out bool boolResult)) return boolResult;
    
    // Default strategy: treat as string
    return value;
}
```

```
// XIIGen — AI provider as Strategy
interface IAIProvider {
    Task<string> GenerateAsync(string prompt);
}

class ClaudeProvider : IAIProvider { ... }
class GPTProvider : IAIProvider { ... }
class GeminiProvider : IAIProvider { ... }

// Swap at runtime without changing orchestration code
```

**Similar simulation:** Document export strategy — same data exported as PDF, Excel, CSV, or JSON depending on user selection. Same interface, different algorithm.

**When to use in Genie context:** Multiple algorithms for the same task, provider selection, format conversion, pricing calculation strategies.

---

### 11. State — Behavior Changes with State

**Genie uses it for:** GameHelpers state machine, task lifecycle

```csharp
// GameHelpers.cs — Game state machine
// Actions are only valid in certain states
public class GameHelpers {
    public DataProcessResult ProcessAction(GameAction action, GameState currentState) {
        // State determines which actions are valid
        switch (currentState) {
            case GameState.Setup:
                // Only setup actions allowed
                if (action.Type != ActionType.Configure) 
                    return DataProcessResult.Error("Invalid in Setup state");
                break;
            case GameState.Active:
                // Game actions allowed (move, score, use item)
                break;
            case GameState.Paused:
                // Only resume or quit
                break;
            case GameState.Completed:
                // Read-only — view scores, export results
                break;
        }
        return ExecuteAction(action, currentState);
    }
}
```

**Similar simulation:** Document workflow state machine — Draft→Review→Approved→Published, with different actions available at each state.

**When to use in Genie context:** Workflow management, game logic, order processing, any entity with lifecycle stages.

---

### 12. Command — Encapsulate Requests as Objects

**Genie uses it for:** Redux actions, mobile Context dispatch

```javascript
// DynamicApp — Redux actions ARE Commands
// table.action.js
export const fetchTableData = (indexName, filterBody) => ({
    type: 'FETCH_TABLE_DATA',
    payload: { indexName, filterBody }
});

export const storeDocument = (indexName, id, document) => ({
    type: 'STORE_DOCUMENT', 
    payload: { indexName, id, document }
});

// Commands can be: dispatched, logged, replayed, undone
store.dispatch(fetchTableData('requests', filter));
```

```javascript
// DynamicMobile — Context actions as Commands
// actions_mobile.js
export const setTicketData = (data) => ({
    type: 'SET_TICKET_DATA',
    payload: data
});

dispatch(setTicketData(response.data));
```

**Similar simulation:** Undo/redo system — each user action is a Command object that can be stored, reversed, and replayed.

**When to use in Genie context:** State management, action logging/auditing, undo functionality, queued operations.

---

### 13. Mediator — Central Communication Hub

**Genie uses it for:** SignalR Hub, React Navigation

```csharp
// PushNotificationHub.cs — Mediator between clients
// Clients don't communicate directly — all goes through the hub
public class PushNotificationHub : Hub {
    public async Task JoinGroup(string groupId) {
        await Groups.AddToGroupAsync(Context.ConnectionId, groupId);
    }
    
    public async Task SendToGroup(string groupId, string message) {
        // Hub mediates: sender → hub → all group members
        await Clients.Group(groupId).SendAsync("ReceiceMessage", message);
    }
}
```

```javascript
// React Navigation as Mediator (DynamicMobile)
// Screens don't call each other directly — Navigation mediates
navigation.navigate('TicketDetail', { ticketId: 123 });
// Navigation decides which screen to show, passes params, manages stack
```

**Similar simulation:** Microservice event bus — services publish events to a central bus (Redis Streams/Kafka), other services subscribe without knowing each other.

**When to use in Genie context:** Chat systems, notification routing, screen navigation, microservice orchestration.

---

### 14. Template Method — Algorithm Skeleton with Custom Steps

**Genie uses it for:** MicroserviceBase (XIIGen), data processing pipelines

```
// XIIGen — MicroserviceBase defines the service lifecycle template:
abstract class MicroserviceBase {
    // Template method — defines the skeleton
    public async Task RunAsync() {
        await Initialize();        // Step 1: Set up connections
        await RegisterHandlers();  // Step 2: Subscribe to queues
        await StartProcessing();   // Step 3: Begin consuming messages
        await HealthCheckLoop();   // Step 4: Continuous health monitoring
    }
    
    // Concrete services override specific steps:
    protected abstract Task RegisterHandlers();   // MUST override
    protected virtual Task Initialize() { ... }   // CAN override
}

// Concrete service:
class AIOrchestrator : MicroserviceBase {
    protected override Task RegisterHandlers() {
        // Custom: subscribe to AI-related Redis Streams
    }
}
```

**Similar simulation:** Document processing pipeline — base class defines: receive → validate → transform → store → notify. Each document type overrides the transform step.

**When to use in Genie context:** Any processing pipeline where the overall flow is fixed but specific steps vary.

---

## Summary: Pattern Frequency in Genie Codebase

| Pattern | Usage Frequency | Primary Location |
|---------|----------------|-----------------|
| **Facade** | ⭐⭐⭐⭐⭐ | Every controller |
| **Builder** | ⭐⭐⭐⭐⭐ | Query construction, filter building |
| **Observer** | ⭐⭐⭐⭐⭐ | SignalR, Redux, Context |
| **Strategy** | ⭐⭐⭐⭐ | Type detection, provider selection |
| **Decorator** | ⭐⭐⭐⭐ | Auth, i18n, middleware |
| **Singleton** | ⭐⭐⭐⭐ | ES client, config, services |
| **Command** | ⭐⭐⭐⭐ | Redux/Context actions |
| **Factory** | ⭐⭐⭐ | MappService, dynamic forms |
| **Composite** | ⭐⭐⭐ | Nested document processing |
| **State** | ⭐⭐⭐ | Game logic, task lifecycle |
| **Mediator** | ⭐⭐ | SignalR hub, navigation |
| **Adapter** | ⭐⭐ | Cross-stack alternatives, migrations |
| **Template Method** | ⭐⭐ | XIIGen base classes |
| **Prototype** | ⭐ | Document cloning |
