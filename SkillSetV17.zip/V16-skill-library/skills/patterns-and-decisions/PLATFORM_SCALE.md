# Platform Scale Map
## How Each Pattern Evolves from Genie DNA to Full Platform

> This document maps the 5 core patterns from their Gen 1 origin (DynamicController, ObjectProcess)
> through every future scale: Database Fabric, Microservice Architecture, Networking App, and XIIGen.
> Each section shows: what stays the same, what changes, and what NEW abstraction emerges.

---

## Pattern 1: Schema-Free Document Processing — At Every Scale

### Gen 1: ObjectProcess.cs
```
INPUT:   Raw JSON from HTTP body
PROCESS: ParseObjectAlternative → recursive tree walk → type detection
OUTPUT:  Dictionary<string, object> → Elasticsearch IndexRequest
SCOPE:   Single server, single database
```

### Gen 2: Database Fabric
```
INPUT:   Raw JSON (same as Gen 1)
PROCESS: Same recursive processing OR direct JSON passthrough (MongoDB/Redis accept raw JSON natively)
OUTPUT:  IDatabaseProvider.storeDocument(indexName, siteName, document, id?)
SCOPE:   Any database — ES, MongoDB, Redis, PostgreSQL, MySQL
NEW:     siteName parameter → multi-tenant at database level
         Same document, multiple database types simultaneously
         getFullIndexName(siteName, indexName) → "site1_invoices"
```

**What changed:** The processing is the same. The storage interface became generic. The document doesn't care where it goes.

### Gen 3: Microservice Architecture
```
INPUT:   Event payload from queue (not HTTP anymore)
PROCESS: Entity microservice validates + processes
         Queues: Main → process → Consumed (done) / Created (new events) / Archive (history)
OUTPUT:  Stored via DB interface (generic, from Base Core component #1)
SCOPE:   Distributed — multiple services, multiple databases, event-sourced
NEW:     Entity as "original source of truth" with states
         Events on entity changes → trigger downstream services
         Data Requests service → combines data from multiple sources
         Validation service → compares internal state with external sources
```

**What changed:** Processing moved from synchronous HTTP to async events. The entity gained lifecycle (states, events, validation). Storage became distributed across services.

### Gen 4: Networking App
```
INPUT:   Profile data, questionnaire answers, event registrations, group posts, chat messages
PROCESS: Each is a document type — profiles in MongoDB (flexible schema), 
         events in PostgreSQL (structured), messages in MongoDB, analytics in InfluxDB
OUTPUT:  Multiple databases chosen PER USE CASE — not one-size-fits-all
SCOPE:   Product-specific but still schema-free where it matters
NEW:     Dynamic questionnaires → questions AND answers are documents
         AI-powered matching → match criteria stored as documents
         Gamification metrics → activity records as documents
```

**What changed:** Database selection became per-use-case strategic (MongoDB for flexible profiles, PostgreSQL for relational events, InfluxDB for time-series gamification, Neo4j for social graph). But the PATTERN is the same — schema-free where users define structure.

### Gen 5: XIIGen + AI
```
INPUT:   AI-generated documents from pipeline stages
PROCESS: Pipeline engine processes outputs from multiple AI models
OUTPUT:  Stored with trace ID → feedback loop → improved next time
SCOPE:   AI generates the documents AND the definitions
NEW:     Documents include: generated code, design specs, test cases, feedback records
         The AI itself creates entity definitions (not just data)
         Feedback documents feed back into prompts (self-improving)
```

**What changed:** The AI became both the PRODUCER and CONSUMER of dynamic documents. Documents now include code, not just data.

---

## Pattern 2: Dynamic Query Building — At Every Scale

### Gen 1: CreateQueryContainerList
```
INPUT:   Filter JSON with empty fields removed
PROCESS: Recursive walk → skip empty → MatchPhrasePrefixQuery per non-empty field
OUTPUT:  List<QueryContainer> → Elasticsearch bool-filter
SCOPE:   Elasticsearch only, MatchPhrasePrefixQuery for everything
```

### Gen 2: Database Fabric
```
INPUT:   SearchCondition[] with explicit QueryType enum
PROCESS: buildMongoQuery() / buildElasticsearchQuery() / applyFilters() (Redis)
OUTPUT:  SearchResult<T> with pagination, total count, searchId
SCOPE:   Any database — each provider translates conditions to native query
NEW:     QueryType enum: EQUAL, CONTAINS, GT, LT, GTE, LTE, RANGE, IN, NOT_IN
         Pagination built-in: pageSize, pageNum, hasNext, searchId
         Sorting built-in: sortBy, sortOrder
         Empty field handling: if conditions array is empty → match_all
```

**What changed:** Query types became explicit (not just "prefix match for everything"). Pagination and sorting became first-class. The interface works across databases.

### Gen 3: Microservice Architecture
```
INPUT:   Query events from orchestrator
PROCESS: Reports/Queries service manages cache + db queries + permissions
         Data Requests service: "require data from several sources — deliver as fast 
         as possible as long as trust rank is higher than required"
OUTPUT:  Aggregated results from multiple services/databases
SCOPE:   Cross-service queries, federated data
NEW:     Trust rank → results can be partial (from cache) with lower trust,
         then upgraded when source-of-truth responds
         Calculator service → complex metrics across entities
         Feeds service → ranked results by calculated scores
```

**What changed:** Queries span multiple services and databases. Results have trust levels. Caching and federation became first-class.

### Gen 4: Networking App
```
EXAMPLES:
  Profile search → Elasticsearch (full-text + AI matching)
  Event search → PostgreSQL (date ranges, capacity, price)
  Connection recommendations → Neo4j (graph traversal + scoring)
  Leaderboard → InfluxDB (time-series aggregation)
  Feed ranking → Redis (cached) + Elasticsearch (search)
NEW:     AI-powered matching adds SCORING to query results
         A/B testing for matching algorithms
         Content ranking based on user behavior
```

**What changed:** Different databases serve different query strengths. The query builder adapts per database. AI adds scoring/ranking on top.

### Gen 5: XIIGen + AI
```
INPUT:   Natural language query → AI translates to structured search
PROCESS: Similarity matching against past jobs (RAG)
         AI selects best approach based on learned patterns
OUTPUT:  Ranked results with confidence scores
NEW:     AI generates the QUERY from description
         Feedback loop: successful queries improve future query generation
```

---

## Pattern 3: Client-Side Filter Assembly — At Every Scale

### Gen 1: filterBody.js
```
UI:      Hardcoded originObj with entity-specific fields
PROCESS: Delete empty keys, set non-empty values
OUTPUT:  Sparse JSON posted to /searchDocuments
```

### Gen 4: Networking App Frontend
```
UI:      Micro-frontends (Feed MFE, Events MFE, Members MFE, Groups MFE)
         React + Redux Toolkit, each MFE independent
PROCESS: RTK Query manages filter state per entity type
         Filters driven by entity definitions from Profile/Events/Groups services
OUTPUT:  API Gateway (Next.js BFF) routes to correct microservice
NEW:     Micro-frontends → each domain has its own filter UI
         API Gateway → Backend-for-Frontend assembles cross-service results
         Real-time filter updates via WebSocket
```

### Gen 5: XIIGen + AI
```
UI:      React Native with n8n-style visual flow builder
PROCESS: User DESCRIBES what they want to find → AI builds the filter
OUTPUT:  Pipeline stage that generates search parameters
NEW:     Natural language → structured filter (AI-powered)
         Visual flow → shows what the filter does graphically
         Feedback → user corrects AI's filter interpretation
```

---

## Pattern 4: Entity Definition Registry — At Every Scale

### Gen 0: df_sys_definitions (MySQL table)
```
STORE:   MySQL table rows: entity_id, system_name, name, type, input_type
SCOPE:   Per WordPress site
DRIVES:  DF_DynamicForms creates forms from definitions
```

### Gen 1: MappService + /Mapps/*.json
```
STORE:   JSON files on disk, loaded by MappService.Documents()
SCOPE:   Per deployment
DRIVES:  Frontend renders forms/tables from definitions
```

### Gen 3: Entity Microservice
```
STORE:   Database (via generic DB interface)
SCOPE:   Platform-wide, event-replicated to consuming services
DRIVES:  EVERYTHING. From Architecture.docx:
         "Manages the definitions and the states of entities — 
          the original source of truth"
         Fields, Events, Create, Upsert, Delete, Validate, Queries
         "Possible that some of the entities will be managed or extended 
          by extra resources"
NEW:     Entity STATES → lifecycle management
         Entity EVENTS → trigger downstream services
         Entity CONNECTIONS → relationships between entity types
         Entity VALIDATION → rules checked on create/update
         Views microservice → "Html Editor with tag insert — fields, views, 
         transforms, queries" → visual entity definition editor
         Moderation → "moderate entity data requests with human/AI agent"
```

**What changed:** Definitions gained lifecycle (states), relationships (connections), events (triggers), and validation (rules). They became the central nervous system of the platform.

### Gen 4: Networking App Entities
```
ENTITIES DEFINED:
  User Profile → dynamic questionnaires (questions + answers as nested documents)
  Events → dynamic registration fields, capacity rules, approval workflow
  Groups → dynamic membership rules, permission matrices, content types
  Connections → dynamic relationship types, network graph properties
  Achievements → dynamic criteria, reward rules, progression tiers
  
ALL driven by configuration:
  Admin defines a new questionnaire → Profile service adds it
  Admin defines new event type → Events service handles it
  Admin defines achievement criteria → Gamification service tracks it
  → No code. No deployment. Configuration is the product.
```

### Gen 5: XIIGen Entity Generation
```
USER SAYS: "I need to track vendor invoices with approval workflow"
AI GENERATES:
  Entity definition: vendor_invoices
  Fields: vendor, amount, due_date, status, approver, notes, attachments
  States: draft → submitted → under_review → approved / rejected → paid
  Events: on_submit → notify_approver, on_approve → notify_vendor, on_due_date → alert
  Views: submission form, approval queue, dashboard with totals
  Connections: vendor_invoices → vendors (relation), vendor_invoices → payments (lifecycle)
  
→ Entity definition created by AI, executed by the machine.
→ User refines via feedback: "add 'department' field" → definition updated.
```

---

## Pattern 5: Automatic Scope Isolation — At Every Scale

### Gen 1: userId injection in CreateQueryContainerList
```
WHO:     Single user identity from JWT claims
HOW:     if (!users.IsAdmin) → inject userId filter into query
SCOPE:   Binary: admin (see all) / user (see own)
LEVEL:   Query injection in DynamicController
```

### Gen 3: Permissions Microservice
```
WHO:     Users, roles, groups, services (all are principals)
HOW:     "Manages access layer relations between entities, views, data"
         Permissions "replicated in all services by specific event"
         Each service has local permission copy for fast validation
SCOPE:   RBAC with resource-level granularity
LEVEL:   Query injection + event-level authorization + data-level masking
NEW:     Role-based: user sees data based on their role(s)
         Resource-level: permission per entity per record
         Replicated: each service validates locally (no cross-service call for every request)
         Audit: Security service "analyzes security performance, manage event types, trigger alerts"
```

### Gen 4: Networking App Permissions
```
LAYERS:
  Auth Service: OAuth2/OpenID Connect (Google, Facebook, LinkedIn)
  Permissions Service: RBAC with: check, grant, roles, audit-log
  Profile Service: privacy settings per user
  Groups Service: group-level permissions (owner, moderator, member)
  Events Service: event-level access (public, members-only, invite-only)
  Relations Service: blocking and privacy controls

PERMISSION MATRIX (from spec):
  Resource          | Owner | Admin | Moderator | Member | Public
  Profile (view)    | full  | full  | partial   | basic  | minimal
  Profile (edit)    | yes   | yes   | no        | no     | no
  Group (post)      | yes   | yes   | yes       | yes    | no
  Group (manage)    | yes   | yes   | yes       | no     | no
  Event (create)    | yes   | yes   | yes       | no     | no
  Chat (message)    | yes   | -     | -         | yes    | no
```

### Gen 5: XIIGen Scope
```
NEW:     AI agents have their own scope (what data they can access)
         Pipeline stages have scope (which previous results they can see)
         Feedback has scope (user's feedback only affects their future results)
         Trust ranks determine data quality/freshness in queries
```

---

## The Base Core: 19 Components That Exist Once

From Architecture.docx — these form the MACHINE that every microservice inherits:

| # | Component | What It Is | Which Pattern It Enables |
|---|-----------|-----------|-------------------------|
| 1 | DB interface | Generic by db type, index name | Pattern 1 (Document Processing) + Pattern 2 (Query Building) |
| 2 | Queue Interface | Generic by queue type | Pattern 7 (Event Composition) |
| 3 | PermissionsCheck | Replicated to all services by event | Pattern 5 (Scope Isolation) |
| 4 | QueryRequest to queue | Subscribe to result, with trust rank | Pattern 2 (Federated Queries) |
| 5 | Authenticate validation | Replicated by specific event | Pattern 5 (Identity Verification) |
| 6 | Queues: Main, Consumed, Created, Archive | For restore/history | Event Sourcing + Recovery |
| 7 | Get endpoints | Source of truth, fast response | Pattern 2 (Query) + Caching |
| 8 | Cache | Fast data response | Performance layer |
| 9 | Update endpoints | Forced/admin/event-driven | Pattern 1 (Store) + Events |
| 10 | Kubernetes orchestrator | Scalability | Infrastructure |
| 11 | Logger | Logging and data | Observability |
| 12 | Data Validation | Compare internal with external | Data integrity |
| 13 | Orchestration | Events, actions, data sources, triggers, trace ID | Pattern 7 (Flow Management) |
| 14 | 3rd party communications | External integrations | Connector pattern |
| 15 | Sanity check | System health | Reliability |
| 16 | Test data generator | Test data | Quality assurance |
| 17 | Test Scenarios | Automated testing | Quality assurance |
| 18 | Safe Shutdown | Graceful termination | Reliability |
| 19 | Orchestration Events Mgmt | Register/update/delete actions+events | Pattern 7 (Dynamic Flows) |

**Every microservice gets ALL 19 for free.** A new service = inherit Base Core + define which events to subscribe to + define which actions to perform.

---

## The Microservices: What Each One Does

From Architecture.docx — these are the DYNAMIC layer that composes on top of the Base Core:

| Service | Purpose | Key Patterns Used |
|---------|---------|-------------------|
| **Entity** | Source of truth for all entity definitions and states | Pattern 1, 4 (the heart) |
| **Views** | HTML editor, visual builders, view transforms | Pattern 3, 4 (UI generation) |
| **Permissions** | Access layer between entities, views, data | Pattern 5 (scope) |
| **Connections** | Relations between entities | Pattern 4 (entity relationships) |
| **Feeds** | Calculated rankings from entities + connections + scores | Pattern 2 (ranked queries) |
| **Notifications** | Internal socket, push, email, SMS, WhatsApp | Real-time (SignalR evolution) |
| **Reports/Queries** | Cached queries with permissions | Pattern 2 (optimized queries) |
| **AI** | Translation, matching, grading, cloud of interests | Pattern 6 (generic AI interface) |
| **Connectors** | WhatsApp, WordPress, CRM integrations | Pattern 6 (generic connector) |
| **Financial** | Payments, cancellations, refunds, bonuses | Static (trust boundary) |
| **Gamification** | Activity tracking, performance matrix | Pattern 1 (activity records) |
| **Data Requests** | Federated queries across sources with trust rank | Pattern 2 (federated) |
| **Orchestrator** | Visual flow management, event sequence execution | Pattern 7 (composition) |
| **Chat** | Entity-to-entity messaging with sessions | Pattern 1 (messages as documents) |
| **Calculator** | Metrics from entities + connections + weights | Pattern 2 (computed queries) |
| **Authentication** | Register, authenticate, revoke, block | Static (machine) |
| **Logger** | Log gathering, 3rd party, AI analysis | Observability |
| **Moderation** | Human/AI review of entity data | Pattern 5 (approval scope) |
| **Analyze** | System behavior, performance, metrics, alerts | Observability |
| **Validation/Sanity** | System state validation, alerts | Reliability |
| **Security** | Security analysis, event management, alerts | Pattern 5 (security) |

---

## From Networking App: How A Product Uses The Platform

The Networking App demonstrates how a specific product maps to the generic platform:

| App Feature | Platform Service(s) | Pattern(s) |
|-------------|---------------------|------------|
| User profiles + dynamic questionnaires | Entity + Views | Patterns 1, 3, 4 |
| AI-powered matching | AI + Calculator + Feeds | Patterns 2, 6 |
| Friend connections + network graph | Connections (Neo4j) | Pattern 4 (relationships) |
| Real-time chat with AI translation | Chat + AI + Notifications | Patterns 1, 6 |
| Event creation + registration + approval | Entity + Orchestrator + Permissions | Patterns 4, 5, 7 |
| Group management + discussions | Entity + Permissions + Views | Patterns 3, 4, 5 |
| Gamification + leaderboards | Gamification + Calculator | Patterns 1, 2 |
| Payments + subscriptions | Financial | Static (trust boundary) |
| Role-based access control | Permissions + Authentication | Pattern 5 |
| Personalized feeds + content ranking | Feeds + Reports + AI | Patterns 2, 6 |

The product is 100% DYNAMIC content on top of the STATIC platform machine.

---

## Summary: One Pattern, Every Scale

The same abstraction repeats at every level:

```
LEVEL 1 (code):     ParseObjectAlternative → accepts any JSON shape
LEVEL 2 (database): IDatabaseProvider → accepts any database type  
LEVEL 3 (service):  Base Core → accepts any microservice definition
LEVEL 4 (product):  Entity definitions → accepts any business domain
LEVEL 5 (AI):       Pipeline prompts → accepts any user description

At every level: generic machine + dynamic composition = user freedom.
```
