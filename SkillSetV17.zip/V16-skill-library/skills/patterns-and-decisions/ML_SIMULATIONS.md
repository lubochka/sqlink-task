# ML-Enhanced Genie Features — Simulation Blueprints
## How ML Algorithms Integrate with Existing Genie Architecture

> **Purpose:** Show concrete ways to add ML intelligence to the Genie platform,
> using the same architectural DNA (dynamic documents, ES, builder pattern, etc.)

---

## Simulation 1: Smart Document Classification (Naive Bayes)

### What It Does
Auto-classifies incoming documents into entity types (requests, clients, invoices) based on content — no manual index_name selection needed.

### Genie DNA Connection
- **Input:** Same JSON documents going through `ParseObjectAlternative`
- **Training data:** Existing ES documents grouped by index_name
- **Output:** Predicted index_name for automatic routing
- **Pattern:** STRATEGY — classifier is a swappable algorithm behind an interface

### Architecture
```
Client → POST /api/dynamic/autoStore
    → [Authorize] (Decorator pattern — unchanged)
    → ParseObjectAlternative (existing DNA — unchanged)  
    → NaiveBayesClassifier.predict(document) → predicted_index_name (NEW)
    → ES.index(predicted_index_name, document) (existing DNA — unchanged)
    → Return { index_name: predicted, confidence: 0.87 }
```

### Implementation Sketch (Python microservice)
```python
# Naive Bayes trained on existing ES data
class DocumentClassifier:
    def __init__(self, es_client):
        self.classifier = NaiveBayes()
        self.es = es_client
    
    async def train(self):
        """Train on all existing documents across all indices"""
        for index_name in await self.es.get_all_indices():
            docs = await self.es.search(index=index_name, size=1000)
            for doc in docs:
                text = ' '.join(str(v) for v in doc['_source'].values())
                self.classifier.fit([text], [index_name])
    
    def predict(self, document: dict) -> tuple[str, float]:
        """Predict index_name for a new document"""
        text = ' '.join(str(v) for v in document.values())
        prediction = self.classifier.predict(text)
        return prediction, self.classifier.confidence
```

### Design Pattern Integration
- **Strategy:** `IDocumentClassifier` interface — can swap Naive Bayes for Neural Network
- **Decorator:** Wraps existing `storeDocument` without changing it
- **Observer:** Classifier retrains when new documents are stored (feedback loop)

---

## Simulation 2: Search Result Ranking (Linear Regression)

### What It Does
Re-ranks search results by predicted relevance based on user click history.

### Genie DNA Connection
- **Input:** Results from `CreateQueryContainerList` search
- **Training data:** User interaction logs (which results they clicked/opened)
- **Output:** Same results, reordered by predicted relevance score
- **Pattern:** DECORATOR — wraps search without changing the query pipeline

### Architecture
```
Client → POST /api/dynamic/searchDocuments/{index_name}
    → CreateQueryContainerList (existing DNA — unchanged)
    → ES.search(query) → raw_results (existing DNA — unchanged)
    → LinearRegression.predict(user, results) → relevance_scores (NEW)
    → Sort results by relevance_score (NEW)
    → Return sorted results
```

### Implementation Sketch
```python
class SearchRanker:
    def __init__(self):
        self.model = LinearRegression()
    
    def train(self, interaction_logs):
        """
        Features: field match count, recency, user's past clicks on similar docs
        Target: click probability (0.0 - 1.0)
        """
        X = [self.extract_features(log) for log in interaction_logs]
        Y = [log['was_clicked'] for log in interaction_logs]
        self.model.fit(X, Y)
    
    def rerank(self, results, user_context):
        """Rerank ES results by predicted relevance"""
        scored = []
        for result in results:
            features = self.extract_features_for_prediction(result, user_context)
            score = self.model.predict(features)
            scored.append((result, score))
        return sorted(scored, key=lambda x: x[1], reverse=True)
```

---

## Simulation 3: Adaptive AI Model Selection (Q-Learning)

### What It Does
Learns which AI model (Claude, GPT, Gemini) produces the best results for each task type in XIIGen pipelines.

### Genie DNA Connection
- **States:** Task types (code_gen, design_review, content_write, bug_fix)
- **Actions:** Model selection (claude, gpt, gemini, deepseek)
- **Rewards:** User feedback scores (positive=+1, neutral=0, negative=-1)
- **Pattern:** STATE + STRATEGY — Q-table optimizes the state→action mapping

### Architecture
```
User → Submit task to XIIGen
    → Q-Learning agent observes task_type (STATE)
    → Agent selects optimal model (ACTION via STRATEGY)
    → Model generates result
    → User rates result → reward signal
    → Agent updates Q-table (learns)
    → Next time same task_type → better model selection
```

### Implementation Sketch
```python
class AIModelSelector:
    def __init__(self):
        self.q_agent = QLearning(
            states=['code_gen', 'design_review', 'content_write', 'bug_fix'],
            actions=['claude', 'gpt', 'gemini', 'deepseek'],
            lr=0.1, gamma=0.9, epsilon=0.15  # 15% exploration
        )
    
    def select_model(self, task_type: str) -> str:
        """Select best model for task type based on learned Q-values"""
        return self.q_agent.choose_action(task_type)
    
    def learn_from_feedback(self, task_type: str, model: str, rating: int):
        """Update Q-table based on user feedback"""
        # rating: -1 (bad), 0 (ok), +1 (good) → reward
        reward = rating * 10  # Scale to -10, 0, +10
        self.q_agent.update(task_type, model, reward, task_type)
```

### Design Pattern Integration
- **State:** Task types as states with different optimal actions
- **Strategy:** Model selection as swappable strategy driven by Q-table
- **Observer:** Feedback events trigger learning updates
- **Command:** Each (task_type, model, rating) triple is a command stored for replay

---

## Simulation 4: Document Clustering (K-Means)

### What It Does
Automatically groups similar documents within an ES index — suggests "related documents" in the UI.

### Genie DNA Connection
- **Input:** Documents from any ES index (via existing search pipeline)
- **Feature extraction:** Field values converted to numerical vectors
- **Output:** Cluster labels added to documents, "similar documents" API endpoint
- **Pattern:** FACTORY — cluster assignment as a factory that categorizes documents

### Architecture
```
Background job (runs periodically):
    → Fetch all docs from ES index
    → Extract features (field values → numerical vectors)
    → K-Means clustering → assign cluster_id to each doc
    → Update ES documents with cluster_id field

Client → GET /api/dynamic/similar/{index_name}/{doc_id}
    → Get document's cluster_id
    → Search ES for same cluster_id (via CreateQueryContainerList!)
    → Return similar documents
```

### Implementation Sketch
```python
class DocumentClusterer:
    def __init__(self, n_clusters=5):
        self.kmeans = KMeans(n_clusters)
    
    def cluster_index(self, es_client, index_name):
        """Cluster all documents in an ES index"""
        docs = es_client.search(index=index_name, size=10000)
        
        # Extract features from dynamic documents
        features = [self.doc_to_features(doc) for doc in docs]
        
        # Run K-Means
        labels = self.kmeans.fit(features)
        
        # Update ES documents with cluster labels
        for doc, label in zip(docs, labels):
            es_client.update(index=index_name, id=doc['_id'], 
                           body={'doc': {'_cluster_id': label}})
    
    def doc_to_features(self, doc):
        """Convert dynamic document fields to numerical vector"""
        features = []
        for key, value in doc['_source'].items():
            if isinstance(value, (int, float)):
                features.append(value)
            elif isinstance(value, str):
                features.append(len(value))  # Simple: string length
        return features
```

---

## Simulation 5: Smart Form Field Prediction (Neural Network)

### What It Does
Predicts which form fields a user will likely fill next, pre-populating or highlighting them.

### Genie DNA Connection
- **Input:** User's partially filled filterBody (existing client pattern)
- **Training data:** Historical filterBody submissions from ES logs
- **Output:** Predicted next fields + values
- **Pattern:** BUILDER enhanced — suggests next builder steps

### Architecture
```
Client → User starts filling filterBody
    → After 2-3 fields filled
    → POST /api/dynamic/predictFields/{index_name}
    → Neural network predicts remaining fields
    → Return { predicted_fields: { "insurance company": "Maccabi", ... } }
    → Client auto-fills/highlights predicted fields
```

---

## Simulation 6: Field Co-occurrence Rules (Apriori)

### What It Does
Discovers which fields are commonly filled together — "users who fill Field X also fill Field Y".

### Genie DNA Connection
- **Input:** Stored documents in ES (which fields are non-empty)
- **Mining:** Apriori finds frequent field combinations
- **Output:** Rules like "If 'insurance company' is filled, 85% also fill 'program name'"
- **Pattern:** OBSERVER — when user fills a field, suggest associated fields

### Implementation Sketch
```python
class FieldAssociationMiner:
    def __init__(self, min_support=0.3, min_confidence=0.7):
        self.apriori = Apriori(min_support, min_confidence)
    
    def mine_associations(self, es_client, index_name):
        """Find field co-occurrence patterns"""
        docs = es_client.search(index=index_name, size=10000)
        
        # Each document → set of non-empty field names (transaction)
        transactions = []
        for doc in docs:
            non_empty_fields = {k for k, v in doc['_source'].items() 
                              if v is not None and v != ''}
            transactions.append(non_empty_fields)
        
        # Mine association rules
        rules = self.apriori.find_rules(transactions)
        return rules
        # Example output:
        # {'insurance company'} → {'program name'} (conf: 0.85)
        # {'Full name', 'Id number'} → {'phone'} (conf: 0.92)
```

---

## Integration Architecture

All ML simulations follow the same integration pattern with existing Genie DNA:

```
┌──────────────────────────────────────────────────────┐
│ Existing Genie Stack (unchanged)                      │
│                                                       │
│  Client → filterBody → POST /api/dynamic/...          │
│       → [Authorize] → CreateQueryContainerList         │
│       → ES query → results → Client                   │
│                                                       │
└──────────────┬───────────────────────────┬────────────┘
               │                           │
               ▼                           ▼
┌──────────────────────┐   ┌──────────────────────────┐
│ ML Microservice       │   │ Feedback Collector        │
│ (Python FastAPI)      │   │ (any stack)               │
│                       │   │                           │
│ - Naive Bayes         │   │ - User ratings            │
│ - K-Means             │   │ - Click tracking          │
│ - Linear Regression   │   │ - Field usage patterns    │
│ - Neural Network      │   │                           │
│ - Q-Learning          │   │ Stores feedback in ES     │
│ - Apriori             │   │ (same dynamic documents!) │
│                       │   │                           │
│ Exposes REST API      │   │ ML service reads feedback │
│ OR processes via       │   │ for retraining            │
│ Redis Streams queue   │   │                           │
└──────────────────────┘   └──────────────────────────┘

Key principle: ML is a DECORATOR on existing architecture.
It enhances without modifying the core Genie DNA.
```

---

## When to Add ML (Decision Guide)

| Scenario | ML Algorithm | Worth Adding? | Complexity |
|----------|-------------|---------------|------------|
| 100+ docs per index, users search frequently | Search Ranking (LinReg) | ✅ Yes | Low |
| 5+ entity types, new docs need manual routing | Classification (Naive Bayes) | ✅ Yes | Low |
| Users fill 3-5 fields on average, forms have 15+ | Field Prediction (NN) | ⚠️ Maybe | Medium |
| XIIGen runs 50+ tasks/day across models | Model Selection (Q-Learning) | ✅ Yes | Medium |
| 1000+ docs, need "related items" feature | Clustering (K-Means) | ✅ Yes | Low |
| Want "users also fill..." suggestions | Field Rules (Apriori) | ⚠️ Maybe | Medium |
| < 50 docs, simple CRUD | Any ML | ❌ Overkill | — |
