# Cloud Infrastructure — .NET Modern (8/9) with Azure.Storage.Blobs v12

> **Genie DNA:** Same file pipeline (upload→blob→metadata in ES), same dual ES config
> (cloud+local), same MappService entity definitions, same DI registration pattern.
> Upgraded to Azure.Storage.Blobs v12, Elastic.Clients.Elasticsearch v8, minimal API.

## Core Principle

Modern .NET equivalents of all Genie infrastructure services. Key upgrades: async-first blob operations (no Task.Run wrapping), Elastic v8 client, minimal API DI, options pattern for config.

## Azure Blob Storage (v12 — Replaces WindowsAzure.Storage)

```csharp
// Services/BlobStorageService.cs
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;

public interface IBlobStorageService
{
    Task<string> UploadAsync(string fileName, Stream content, string contentType);
    Task<Stream> DownloadAsync(string fileUrl);
    Task DeleteAsync(string fileUrl);
}

public class BlobStorageService : IBlobStorageService
{
    private readonly BlobContainerClient _container;

    public BlobStorageService(IConfiguration config)
    {
        var connectionString = config.GetConnectionString("AccessKey");
        var containerName = config["BlobStorage:ContainerName"] ?? "uploads";
        _container = new BlobContainerClient(connectionString, containerName);
        _container.CreateIfNotExists(PublicAccessType.Blob);
    }

    /// <summary>
    /// Upload file to blob — returns public URL.
    /// Modern async (no Task.Run wrapping like legacy).
    /// </summary>
    public async Task<string> UploadAsync(string fileName, Stream content, string contentType)
    {
        // Generate unique blob name to avoid collisions
        var blobName = $"{Guid.NewGuid()}/{fileName}";
        var blobClient = _container.GetBlobClient(blobName);

        await blobClient.UploadAsync(content, new BlobHttpHeaders
        {
            ContentType = contentType
        });

        return blobClient.Uri.ToString();
    }

    /// <summary>
    /// Download blob to stream — mirrors legacy GetBlobData.
    /// </summary>
    public async Task<Stream> DownloadAsync(string fileUrl)
    {
        var blobName = ExtractBlobName(fileUrl);
        var blobClient = _container.GetBlobClient(blobName);
        var response = await blobClient.DownloadStreamingAsync();
        return response.Value.Content;
    }

    /// <summary>
    /// Delete blob by URL — mirrors legacy DeleteBlobData.
    /// </summary>
    public async Task DeleteAsync(string fileUrl)
    {
        var blobName = ExtractBlobName(fileUrl);
        var blobClient = _container.GetBlobClient(blobName);
        await blobClient.DeleteIfExistsAsync(DeleteSnapshotsOption.IncludeSnapshots);
    }

    private static string ExtractBlobName(string fileUrl)
    {
        var uri = new Uri(fileUrl);
        // Remove container name from path
        return uri.AbsolutePath.TrimStart('/').Substring(
            uri.AbsolutePath.TrimStart('/').IndexOf('/') + 1);
    }
}
```

## Elasticsearch v8 Configuration

```csharp
// Extensions/ElasticsearchExtensions.cs
using Elastic.Clients.Elasticsearch;
using Elastic.Transport;

public static class ElasticsearchExtensions
{
    /// <summary>
    /// Same dual-config pattern as legacy Genie:
    /// - If username is set → cloud deployment with auth
    /// - If no username → local dev (no auth)
    /// Auto-detects mode from appsettings.
    /// </summary>
    public static IServiceCollection AddElasticsearch(
        this IServiceCollection services, IConfiguration config)
    {
        var esConfig = config.GetSection("elasticsearch");

        ElasticsearchClientSettings settings;

        if (!string.IsNullOrEmpty(esConfig["username"]))
        {
            // Cloud deployment with authentication
            if (!string.IsNullOrEmpty(esConfig["cloudId"]))
            {
                // Elastic Cloud
                settings = new ElasticsearchClientSettings(esConfig["cloudId"],
                    new BasicAuthentication(esConfig["username"]!, esConfig["password"]!));
            }
            else
            {
                // Self-hosted with auth
                settings = new ElasticsearchClientSettings(new Uri(esConfig["url"]!))
                    .Authentication(new BasicAuthentication(esConfig["username"]!, esConfig["password"]!));
            }
        }
        else
        {
            // Local development — no auth
            settings = new ElasticsearchClientSettings(new Uri(esConfig["url"] ?? "http://localhost:9200"));
        }

        settings.DefaultIndex(esConfig["index"] ?? "documents");

        services.AddSingleton(new ElasticsearchClient(settings));
        return services;
    }
}
```

### appsettings.json (Same Structure as Legacy)

```json
{
  "elasticsearch": {
    "index": "documents",
    "url": "https://your-cluster.elastic-cloud.com:9243/",
    "username": "elastic",
    "password": "your-password",
    "cloudId": "your-cloud-id-base64"
  },
  "ConnectionStrings": {
    "AccessKey": "DefaultEndpointsProtocol=https;AccountName=...;AccountKey=...;EndpointSuffix=core.windows.net"
  },
  "BlobStorage": {
    "ContainerName": "uploads"
  }
}
```

## File Processing Pipeline

```csharp
// Services/FileProcessingService.cs
using Elastic.Clients.Elasticsearch;

public record FileProcessingData
{
    public string Id { get; init; } = Guid.NewGuid().ToString();
    public string FileName { get; init; } = "";
    public string BlobUrl { get; init; } = "";
    public string UserName { get; init; } = "";
    public string ContentType { get; init; } = "";
    public DateTime UploadedAt { get; init; } = DateTime.UtcNow;
    public string Status { get; init; } = "uploaded"; // uploaded → processing → complete
}

public class FileProcessingService
{
    private readonly ElasticsearchClient _client;
    private const string IndexName = "file-processing";

    public FileProcessingService(ElasticsearchClient client) => _client = client;

    public async Task<string> CreateAsync(FileProcessingData data)
    {
        var response = await _client.IndexAsync(data, i => i.Index(IndexName).Id(data.Id));
        return data.Id;
    }

    public async Task<List<FileProcessingData>> GetByUserNameAsync(string userName)
    {
        var response = await _client.SearchAsync<FileProcessingData>(s => s
            .Index(IndexName)
            .Query(q => q.Match(m => m.Field(f => f.UserName).Query(userName))));

        return response.Documents.ToList();
    }
}
```

## MappService (Entity Definitions — Same Pattern)

```csharp
// Services/MappService.cs
public interface IMappService
{
    Dictionary<string, string> Documents();
    string? GetMapping(string name);
}

public class MappService : IMappService
{
    private readonly Dictionary<string, string> _documents = new();

    public MappService(IWebHostEnvironment env)
    {
        // Load JSON mapping files from /Mapps/ folder (same as legacy)
        var mappsPath = Path.Combine(env.ContentRootPath, "Mapps");
        if (Directory.Exists(mappsPath))
        {
            foreach (var file in Directory.GetFiles(mappsPath, "*.json"))
            {
                _documents[Path.GetFileName(file)] = File.ReadAllText(file);
            }
        }
    }

    public Dictionary<string, string> Documents() => _documents;
    public string? GetMapping(string name) => _documents.GetValueOrDefault(name);
}
```

## File Upload Endpoint

```csharp
// Program.cs — File upload route
app.MapPost("/api/files/upload", async (
    IFormFile file,
    IBlobStorageService blobService,
    FileProcessingService fileProcessing,
    HttpContext ctx) =>
{
    var userName = ctx.User.FindFirst("UserId")?.Value ?? "anonymous";

    // Upload to blob
    using var stream = file.OpenReadStream();
    var blobUrl = await blobService.UploadAsync(file.FileName, stream, file.ContentType);

    // Track in Elasticsearch
    var record = new FileProcessingData
    {
        FileName = file.FileName,
        BlobUrl = blobUrl,
        UserName = userName,
        ContentType = file.ContentType
    };
    var id = await fileProcessing.CreateAsync(record);

    return Results.Ok(new { id, url = blobUrl });
}).DisableAntiforgery();
```

## DI Registration (Minimal API — Program.cs)

```csharp
// Program.cs — All infrastructure services
var builder = WebApplication.CreateBuilder(args);

builder.Services.AddElasticsearch(builder.Configuration);           // ES client (singleton)
builder.Services.AddSingleton<IMappService, MappService>();          // Entity definitions
builder.Services.AddScoped<IBlobStorageService, BlobStorageService>(); // File storage (scoped!)
builder.Services.AddScoped<FileProcessingService>();                  // File pipeline

// CORS with credentials (required for SignalR)
builder.Services.AddCors(options =>
{
    options.AddPolicy("CorsPolicy", policy =>
    {
        policy.WithOrigins(builder.Configuration.GetSection("AllowedOrigins").Get<string[]>()
                ?? ["http://localhost:3000"])
            .AllowAnyMethod()
            .AllowAnyHeader()
            .AllowCredentials();
    });
});

var app = builder.Build();
app.UseCors("CorsPolicy");
app.UseAuthentication();
app.UseAuthorization();
```

## Pipeline Order (Critical — Same as Legacy)

```
app.UseRouting();         // (implicit in minimal API)
app.UseAuthentication();  // JWT validation FIRST
app.UseAuthorization();   // Claims check SECOND
app.UseCors("CorsPolicy"); // CORS THIRD
app.MapHub<...>("/push"); // SignalR hub
```

## Dependencies

```xml
<PackageReference Include="Azure.Storage.Blobs" Version="12.21.0" />
<PackageReference Include="Elastic.Clients.Elasticsearch" Version="8.16.0" />
<PackageReference Include="Microsoft.AspNetCore.Authentication.JwtBearer" Version="8.0.0" />
```

## Genie DNA Checklist

- [x] BlobStorageService: upload, download, delete (async-first)
- [x] Dual ES config: cloud (cloudId+auth) vs local (url only)
- [x] Auto-detect mode from appsettings.json (username check)
- [x] MappService loading JSON from /Mapps/ folder
- [x] File processing pipeline tracked in ES
- [x] BlobStorageService is Scoped (not Singleton)
- [x] ElasticsearchClient is Singleton
- [x] Same appsettings.json structure
- [x] CORS with AllowCredentials for SignalR
- [x] Auth before Authorization in pipeline
