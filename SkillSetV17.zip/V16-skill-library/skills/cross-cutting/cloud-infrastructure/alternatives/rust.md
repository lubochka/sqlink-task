# Cloud Infrastructure — Rust (Axum + azure_storage_blobs + ES 8)

> **Genie DNA:** Same file pipeline, dual ES config, entity mappings.
> Zero-cost async with tokio. Azure SDK for Rust or S3 via aws-sdk-rust.

## Core Principle

Rust equivalent of Genie infrastructure. Uses azure_storage_blobs crate for file storage, elasticsearch-rs for ES, and JSON files for entity mappings. Fully async with tokio.

## Blob Storage Service

```rust
// src/services/blob_storage.rs
use azure_storage::prelude::*;
use azure_storage_blobs::prelude::*;
use uuid::Uuid;

#[derive(Clone)]
pub struct BlobStorageService {
    container_client: ContainerClient,
}

impl BlobStorageService {
    pub fn new(connection_string: &str, container_name: &str) -> Self {
        let storage_client = StorageClient::new_connection_string(connection_string)
            .expect("Invalid connection string");
        let container_client = storage_client.container_client(container_name);

        Self { container_client }
    }

    /// Upload file to blob — returns public URL.
    /// Mirrors .NET UploadFileToBlob.
    pub async fn upload(
        &self,
        file_name: &str,
        data: Vec<u8>,
        content_type: &str,
    ) -> Result<String, Box<dyn std::error::Error>> {
        let blob_name = format!("{}/{}", Uuid::new_v4(), file_name);
        let blob_client = self.container_client.blob_client(&blob_name);

        blob_client
            .put_block_blob(data)
            .content_type(content_type)
            .await?;

        Ok(blob_client.url()?.to_string())
    }

    /// Download blob — mirrors GetBlobData.
    pub async fn download(&self, file_url: &str) -> Result<Vec<u8>, Box<dyn std::error::Error>> {
        let blob_name = Self::extract_blob_name(file_url)?;
        let blob_client = self.container_client.blob_client(&blob_name);
        let response = blob_client.get_content().await?;
        Ok(response.data.to_vec())
    }

    /// Delete blob — mirrors DeleteBlobData.
    pub async fn delete(&self, file_url: &str) -> Result<(), Box<dyn std::error::Error>> {
        let blob_name = Self::extract_blob_name(file_url)?;
        let blob_client = self.container_client.blob_client(&blob_name);
        blob_client.delete().await?;
        Ok(())
    }

    fn extract_blob_name(file_url: &str) -> Result<String, Box<dyn std::error::Error>> {
        let url = url::Url::parse(file_url)?;
        let path = url.path().trim_start_matches('/');
        // Remove container name from path
        let parts: Vec<&str> = path.splitn(2, '/').collect();
        Ok(parts.get(1).unwrap_or(&"").to_string())
    }
}
```

### S3-Compatible Alternative

```rust
// src/services/s3_storage.rs
use aws_sdk_s3::Client as S3Client;

#[derive(Clone)]
pub struct S3StorageService {
    client: S3Client,
    bucket: String,
}

impl S3StorageService {
    pub async fn new(config: &S3Config) -> Self {
        let sdk_config = aws_config::defaults(aws_config::BehaviorVersion::latest())
            .region(aws_config::Region::new(config.region.clone()))
            .endpoint_url(&config.endpoint) // MinIO: http://localhost:9000
            .load()
            .await;
        Self {
            client: S3Client::new(&sdk_config),
            bucket: config.bucket.clone(),
        }
    }

    pub async fn upload(&self, file_name: &str, data: Vec<u8>, content_type: &str)
        -> Result<String, Box<dyn std::error::Error>>
    {
        let key = format!("{}/{}", Uuid::new_v4(), file_name);
        self.client.put_object()
            .bucket(&self.bucket)
            .key(&key)
            .body(data.into())
            .content_type(content_type)
            .send().await?;
        Ok(format!("{}/{}/{}", self.client.config().endpoint_url().unwrap_or_default(), self.bucket, key))
    }
}
```

## Elasticsearch Configuration

```rust
// src/config/elasticsearch.rs
use elasticsearch::{
    auth::Credentials,
    http::transport::{SingleNodeConnectionPool, Transport, TransportBuilder},
    Elasticsearch,
};

/// Same dual-config pattern as Genie .NET:
/// - If username → authenticated ES
/// - If no username → local dev
pub fn create_elastic_client(config: &EsConfig) -> Elasticsearch {
    if let Some(ref username) = config.username {
        let url = url::Url::parse(&config.url).expect("Invalid ES URL");
        let pool = SingleNodeConnectionPool::new(url);
        let transport = TransportBuilder::new(pool)
            .auth(Credentials::Basic(username.clone(), config.password.clone().unwrap_or_default()))
            .build()
            .expect("Failed to build ES transport");
        Elasticsearch::new(transport)
    } else {
        // Local development — no auth
        let url = url::Url::parse(config.url.as_deref().unwrap_or("http://localhost:9200"))
            .expect("Invalid ES URL");
        let pool = SingleNodeConnectionPool::new(url);
        let transport = Transport::single_node(pool).expect("Failed to build ES transport");
        Elasticsearch::new(transport)
    }
}

#[derive(Clone, serde::Deserialize)]
pub struct EsConfig {
    pub index: Option<String>,
    pub url: Option<String>,
    pub username: Option<String>,
    pub password: Option<String>,
    pub cloud_id: Option<String>,
}
```

## File Processing Pipeline

```rust
// src/services/file_processing.rs
use serde::{Deserialize, Serialize};
use chrono::Utc;
use uuid::Uuid;

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct FileProcessingData {
    pub id: String,
    pub file_name: String,
    pub blob_url: String,
    pub user_name: String,
    pub content_type: String,
    pub uploaded_at: String,
    pub status: String, // "uploaded" → "processing" → "complete"
}

impl FileProcessingData {
    pub fn new(file_name: String, blob_url: String, user_name: String, content_type: String) -> Self {
        Self {
            id: Uuid::new_v4().to_string(),
            file_name,
            blob_url,
            user_name,
            content_type,
            uploaded_at: Utc::now().to_rfc3339(),
            status: "uploaded".to_string(),
        }
    }
}

#[derive(Clone)]
pub struct FileProcessingService {
    client: Elasticsearch,
    index_name: String,
}

impl FileProcessingService {
    pub fn new(client: Elasticsearch) -> Self {
        Self { client, index_name: "file-processing".to_string() }
    }

    pub async fn create(&self, data: &FileProcessingData) -> Result<String, Box<dyn std::error::Error>> {
        self.client.index(elasticsearch::IndexParts::IndexId(&self.index_name, &data.id))
            .body(data)
            .refresh(elasticsearch::params::Refresh::WaitFor)
            .send().await?;
        Ok(data.id.clone())
    }

    pub async fn get_by_user_name(&self, user_name: &str) -> Result<Vec<FileProcessingData>, Box<dyn std::error::Error>> {
        let response = self.client.search(elasticsearch::SearchParts::Index(&[&self.index_name]))
            .body(serde_json::json!({
                "query": { "match": { "user_name": user_name } }
            }))
            .send().await?;

        let body = response.json::<serde_json::Value>().await?;
        let hits = body["hits"]["hits"].as_array().unwrap_or(&vec![]);
        Ok(hits.iter().filter_map(|h| serde_json::from_value(h["_source"].clone()).ok()).collect())
    }
}
```

## MappService

```rust
// src/services/mapp_service.rs
use std::collections::HashMap;
use std::fs;
use std::path::Path;

#[derive(Clone)]
pub struct MappService {
    documents: HashMap<String, String>,
}

impl MappService {
    pub fn new(mapps_dir: &str) -> Self {
        let mut documents = HashMap::new();
        let path = Path::new(mapps_dir);
        if path.exists() {
            if let Ok(entries) = fs::read_dir(path) {
                for entry in entries.flatten() {
                    if entry.path().extension().map_or(false, |e| e == "json") {
                        if let Ok(content) = fs::read_to_string(entry.path()) {
                            documents.insert(entry.file_name().to_string_lossy().to_string(), content);
                        }
                    }
                }
            }
        }
        Self { documents }
    }

    pub fn get_all(&self) -> &HashMap<String, String> { &self.documents }
    pub fn get_mapping(&self, name: &str) -> Option<&str> { self.documents.get(name).map(|s| s.as_str()) }
}
```

## File Upload Route

```rust
// src/routes/files.rs
use axum::{extract::{Multipart, State}, Json};

pub async fn upload_file(
    State(state): State<AppState>,
    mut multipart: Multipart,
) -> Result<Json<serde_json::Value>, (axum::http::StatusCode, String)> {
    while let Some(field) = multipart.next_field().await.map_err(|e| (axum::http::StatusCode::BAD_REQUEST, e.to_string()))? {
        let file_name = field.file_name().unwrap_or("upload").to_string();
        let content_type = field.content_type().unwrap_or("application/octet-stream").to_string();
        let data = field.bytes().await.map_err(|e| (axum::http::StatusCode::BAD_REQUEST, e.to_string()))?;

        let blob_url = state.blob_service.upload(&file_name, data.to_vec(), &content_type).await
            .map_err(|e| (axum::http::StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;

        let record = FileProcessingData::new(file_name, blob_url.clone(), "user".to_string(), content_type);
        let id = state.file_processing.create(&record).await
            .map_err(|e| (axum::http::StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;

        return Ok(Json(serde_json::json!({ "id": id, "url": blob_url })));
    }

    Err((axum::http::StatusCode::BAD_REQUEST, "No file provided".to_string()))
}
```

## Dependencies

```toml
[dependencies]
axum = { version = "0.8", features = ["multipart"] }
tokio = { version = "1", features = ["full"] }
serde = { version = "1", features = ["derive"] }
serde_json = "1"
elasticsearch = "8.15"
azure_storage = "0.20"
azure_storage_blobs = "0.20"
uuid = { version = "1", features = ["v4"] }
chrono = { version = "0.4", features = ["serde"] }
url = "2"
```

## Genie DNA Checklist

- [x] BlobStorageService: upload, download, delete (async)
- [x] Dual ES config: authenticated vs local (no auth)
- [x] MappService loading JSON from /Mapps/ folder
- [x] File processing pipeline tracked in ES
- [x] S3/MinIO alternative provided
- [x] Upload flow: multipart → blob → ES metadata → return URL
- [x] Struct for FileProcessingData (like .NET record)
- [x] Arc-compatible Clone for all services
