# Cloud Infrastructure — Node.js (Fastify + @azure/storage-blob + ES 8)

> **Genie DNA:** Same file pipeline (upload→blob→metadata in ES), dual ES config,
> entity mapping files, DI-like service pattern. Native Node.js async.

## Core Principle

Node.js equivalent of all Genie infrastructure services: Azure Blob Storage (or S3-compatible), Elasticsearch 8.x, entity mapping files, file processing pipeline.

## Azure Blob Storage Service

```javascript
// src/services/blobStorageService.js
import { BlobServiceClient } from '@azure/storage-blob';
import { randomUUID } from 'crypto';

/**
 * Mirrors .NET BlobStorageService: upload, download, delete.
 * Uses @azure/storage-blob v12 (same API as .NET SDK).
 */
export class BlobStorageService {
  constructor(connectionString, containerName = 'uploads') {
    const blobService = BlobServiceClient.fromConnectionString(connectionString);
    this.container = blobService.getContainerClient(containerName);
    // Create container if not exists (async — call in init)
    this.container.createIfNotExists({ access: 'blob' });
  }

  /**
   * Upload file to blob — returns public URL.
   * Mirrors .NET UploadFileToBlob.
   */
  async upload(fileName, stream, contentType) {
    const blobName = `${randomUUID()}/${fileName}`;
    const blockBlob = this.container.getBlockBlobClient(blobName);

    await blockBlob.uploadStream(stream, undefined, undefined, {
      blobHTTPHeaders: { blobContentType: contentType }
    });

    return blockBlob.url;
  }

  /**
   * Upload from Buffer (for multipart file uploads).
   */
  async uploadBuffer(fileName, buffer, contentType) {
    const blobName = `${randomUUID()}/${fileName}`;
    const blockBlob = this.container.getBlockBlobClient(blobName);

    await blockBlob.uploadData(buffer, {
      blobHTTPHeaders: { blobContentType: contentType }
    });

    return blockBlob.url;
  }

  /**
   * Download blob to readable stream — mirrors GetBlobData.
   */
  async download(fileUrl) {
    const blobName = this.extractBlobName(fileUrl);
    const blockBlob = this.container.getBlockBlobClient(blobName);
    const response = await blockBlob.download(0);
    return response.readableStreamBody;
  }

  /**
   * Delete blob by URL — mirrors DeleteBlobData.
   */
  async delete(fileUrl) {
    const blobName = this.extractBlobName(fileUrl);
    const blockBlob = this.container.getBlockBlobClient(blobName);
    await blockBlob.deleteIfExists({ deleteSnapshots: 'include' });
  }

  extractBlobName(fileUrl) {
    const url = new URL(fileUrl);
    // Remove container from path: /uploads/uuid/file.pdf → uuid/file.pdf
    return url.pathname.split('/').slice(2).join('/');
  }
}
```

### S3-Compatible Alternative

```javascript
// For AWS S3 or MinIO — swap provider, same API
import { S3Client, PutObjectCommand, GetObjectCommand, DeleteObjectCommand } from '@aws-sdk/client-s3';

export class S3StorageService {
  constructor(config) {
    this.client = new S3Client({
      region: config.region || 'us-east-1',
      endpoint: config.endpoint, // MinIO: http://localhost:9000
      credentials: { accessKeyId: config.accessKey, secretAccessKey: config.secretKey }
    });
    this.bucket = config.bucket || 'uploads';
  }

  async upload(fileName, buffer, contentType) {
    const key = `${randomUUID()}/${fileName}`;
    await this.client.send(new PutObjectCommand({
      Bucket: this.bucket, Key: key, Body: buffer, ContentType: contentType
    }));
    return `${this.client.config.endpoint}/${this.bucket}/${key}`;
  }
  // download, delete follow same pattern...
}
```

## Elasticsearch Configuration

```javascript
// src/config/elasticsearch.js
import { Client } from '@elastic/elasticsearch';

/**
 * Same dual-config pattern as Genie .NET:
 * - If username → cloud/authenticated ES
 * - If no username → local dev (no auth)
 */
export function createElasticClient(config) {
  if (config.username) {
    if (config.cloudId) {
      // Elastic Cloud
      return new Client({
        cloud: { id: config.cloudId },
        auth: { username: config.username, password: config.password }
      });
    }
    // Self-hosted with auth
    return new Client({
      node: config.url,
      auth: { username: config.username, password: config.password }
    });
  }

  // Local development — no auth
  return new Client({ node: config.url || 'http://localhost:9200' });
}
```

### Config (env or JSON — mirrors appsettings.json)

```json
{
  "elasticsearch": {
    "index": "documents",
    "url": "http://localhost:9200",
    "username": null,
    "password": null,
    "cloudId": null
  }
}
```

## File Processing Pipeline

```javascript
// src/services/fileProcessingService.js

export class FileProcessingService {
  constructor(esClient, indexName = 'file-processing') {
    this.client = esClient;
    this.indexName = indexName;
  }

  async create(data) {
    const id = data.id || randomUUID();
    await this.client.index({
      index: this.indexName,
      id,
      document: { ...data, id, uploadedAt: new Date().toISOString(), status: 'uploaded' },
      refresh: 'wait_for'
    });
    return id;
  }

  /**
   * Get files by username — mirrors .NET GetAllByUserName.
   */
  async getByUserName(userName) {
    const result = await this.client.search({
      index: this.indexName,
      query: { match: { userName } }
    });
    return result.hits.hits.map(h => ({ id: h._id, ...h._source }));
  }
}
```

## MappService (Entity Definitions)

```javascript
// src/services/mappService.js
import { readFileSync, readdirSync, existsSync } from 'fs';
import path from 'path';

/**
 * Mirrors .NET MappService: loads JSON entity definitions from /Mapps/ folder.
 */
export class MappService {
  constructor(mappsDir = './Mapps') {
    this.documents = new Map();

    if (existsSync(mappsDir)) {
      for (const file of readdirSync(mappsDir).filter(f => f.endsWith('.json'))) {
        this.documents.set(file, readFileSync(path.join(mappsDir, file), 'utf-8'));
      }
    }
  }

  getAll() {
    return Object.fromEntries(this.documents);
  }

  getMapping(name) {
    return this.documents.get(name) || null;
  }
}
```

## File Upload Route

```javascript
// src/routes/files.js
import multipart from '@fastify/multipart';

fastify.register(multipart);

fastify.post('/api/files/upload', async (request) => {
  const data = await request.file();
  const buffer = await data.toBuffer();
  const userName = request.user?.UserId || 'anonymous';

  // Upload to blob
  const blobUrl = await blobService.uploadBuffer(data.filename, buffer, data.mimetype);

  // Track in ES
  const id = await fileProcessingService.create({
    fileName: data.filename,
    blobUrl,
    userName,
    contentType: data.mimetype
  });

  return { id, url: blobUrl };
});
```

## Service Registration (Fastify Decorators — Like .NET DI)

```javascript
// src/server.js
const esClient = createElasticClient(config.elasticsearch);      // Singleton
const blobService = new BlobStorageService(config.connectionStrings.accessKey);  // Per-scope equivalent
const mappService = new MappService('./Mapps');                   // Singleton
const fileProcessing = new FileProcessingService(esClient);       // Singleton

fastify.decorate('es', esClient);
fastify.decorate('blobService', blobService);
fastify.decorate('mappService', mappService);
fastify.decorate('fileProcessing', fileProcessing);
```

## CORS Configuration

```javascript
import cors from '@fastify/cors';

fastify.register(cors, {
  origin: ['http://localhost:3000', 'http://localhost:8081'],
  credentials: true  // Required for SignalR/Socket.IO
});
```

## Dependencies

```json
{
  "dependencies": {
    "fastify": "^5.0",
    "@fastify/multipart": "^9.0",
    "@fastify/cors": "^10.0",
    "@azure/storage-blob": "^12.24",
    "@elastic/elasticsearch": "^8.16"
  }
}
```

## Genie DNA Checklist

- [x] BlobStorageService: upload (stream+buffer), download, delete
- [x] Dual ES config: cloud (cloudId+auth) vs local (url only)
- [x] Auto-detect mode (username check)
- [x] MappService loading JSON from /Mapps/ folder
- [x] File processing pipeline tracked in ES
- [x] Same appsettings.json config structure
- [x] CORS with credentials
- [x] S3-compatible alternative provided
- [x] Upload flow: multipart → blob → ES metadata → return URL
