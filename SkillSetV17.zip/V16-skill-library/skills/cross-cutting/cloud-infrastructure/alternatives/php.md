# Cloud Infrastructure — PHP (Laravel 11 + Filesystem + ES 8)

> **Genie DNA:** Same file pipeline, dual ES config, entity mappings.
> Laravel Filesystem (supports Azure/S3/local) + elasticsearch-php 8.x.

## Core Principle

PHP equivalent of Genie infrastructure using Laravel's Filesystem abstraction (supports Azure Blob, S3, local disk). Elasticsearch-php 8.x for data. JSON entity mapping files loaded from /Mapps/ directory.

## File Storage Service (Laravel Filesystem)

```php
<?php
// app/Services/BlobStorageService.php

namespace App\Services;

use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

/**
 * Mirrors .NET BlobStorageService using Laravel Filesystem.
 * Supports Azure Blob, S3, local — configured via config/filesystems.php.
 */
class BlobStorageService
{
    private string $disk;

    public function __construct(string $disk = 'azure')
    {
        $this->disk = $disk;
    }

    /**
     * Upload file — returns public URL.
     * Mirrors .NET UploadFileToBlob.
     */
    public function upload(string $fileName, string|resource $content, string $contentType): string
    {
        $blobName = Str::uuid() . '/' . $fileName;

        Storage::disk($this->disk)->put($blobName, $content, [
            'ContentType' => $contentType,
            'visibility' => 'public',
        ]);

        return Storage::disk($this->disk)->url($blobName);
    }

    /**
     * Upload from UploadedFile (for multipart form uploads).
     */
    public function uploadFile(\Illuminate\Http\UploadedFile $file): string
    {
        return $this->upload(
            $file->getClientOriginalName(),
            $file->getContent(),
            $file->getMimeType()
        );
    }

    /**
     * Download file content — mirrors GetBlobData.
     */
    public function download(string $fileUrl): string
    {
        $blobName = $this->extractBlobName($fileUrl);
        return Storage::disk($this->disk)->get($blobName);
    }

    /**
     * Download as stream (for large files).
     */
    public function downloadStream(string $fileUrl)
    {
        $blobName = $this->extractBlobName($fileUrl);
        return Storage::disk($this->disk)->readStream($blobName);
    }

    /**
     * Delete file — mirrors DeleteBlobData.
     */
    public function delete(string $fileUrl): bool
    {
        $blobName = $this->extractBlobName($fileUrl);
        return Storage::disk($this->disk)->delete($blobName);
    }

    private function extractBlobName(string $fileUrl): string
    {
        $url = parse_url($fileUrl);
        $path = ltrim($url['path'] ?? '', '/');
        // Remove container name from path
        return implode('/', array_slice(explode('/', $path), 1));
    }
}
```

### Filesystem Configuration

```php
<?php
// config/filesystems.php

'disks' => [
    // Azure Blob Storage
    'azure' => [
        'driver' => 'azure',
        'name' => env('AZURE_STORAGE_NAME'),
        'key' => env('AZURE_STORAGE_KEY'),
        'container' => env('AZURE_STORAGE_CONTAINER', 'uploads'),
        'url' => env('AZURE_STORAGE_URL'),
    ],

    // AWS S3 / MinIO alternative
    's3' => [
        'driver' => 's3',
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
        'bucket' => env('AWS_BUCKET', 'uploads'),
        'endpoint' => env('AWS_ENDPOINT'),  // MinIO: http://localhost:9000
        'use_path_style_endpoint' => env('AWS_USE_PATH_STYLE', true),
    ],

    // Local development
    'local' => [
        'driver' => 'local',
        'root' => storage_path('app/uploads'),
        'url' => env('APP_URL') . '/storage/uploads',
        'visibility' => 'public',
    ],
],
```

## Elasticsearch Configuration

```php
<?php
// app/Services/ElasticsearchFactory.php

namespace App\Services;

use Elastic\Elasticsearch\ClientBuilder;
use Elastic\Elasticsearch\Client;

class ElasticsearchFactory
{
    /**
     * Same dual-config pattern as Genie .NET:
     * - If username → cloud/authenticated ES
     * - If no username → local dev
     */
    public static function create(array $config): Client
    {
        $builder = ClientBuilder::create();

        if (!empty($config['username'])) {
            if (!empty($config['cloud_id'])) {
                // Elastic Cloud
                $builder->setElasticCloudId($config['cloud_id']);
            } else {
                // Self-hosted with auth
                $builder->setHosts([$config['url']]);
            }
            $builder->setBasicAuthentication($config['username'], $config['password'] ?? '');
        } else {
            // Local development — no auth
            $builder->setHosts([$config['url'] ?? 'http://localhost:9200']);
        }

        return $builder->build();
    }
}
```

### ES Config (config/elasticsearch.php)

```php
<?php
// config/elasticsearch.php
return [
    'index' => env('ES_INDEX', 'documents'),
    'url' => env('ES_URL', 'http://localhost:9200'),
    'username' => env('ES_USERNAME'),
    'password' => env('ES_PASSWORD'),
    'cloud_id' => env('ES_CLOUD_ID'),
];
```

## File Processing Pipeline

```php
<?php
// app/Services/FileProcessingService.php

namespace App\Services;

use Elastic\Elasticsearch\Client;
use Illuminate\Support\Str;

class FileProcessingService
{
    private const INDEX = 'file-processing';

    public function __construct(
        private readonly Client $esClient
    ) {}

    /**
     * Create file processing record in ES.
     */
    public function create(array $data): string
    {
        $id = $data['id'] ?? Str::uuid()->toString();
        $document = array_merge($data, [
            'id' => $id,
            'uploaded_at' => now()->toIso8601String(),
            'status' => 'uploaded',
        ]);

        $this->esClient->index([
            'index' => self::INDEX,
            'id' => $id,
            'body' => $document,
            'refresh' => 'wait_for',
        ]);

        return $id;
    }

    /**
     * Get files by username — mirrors .NET GetAllByUserName.
     */
    public function getByUserName(string $userName): array
    {
        $response = $this->esClient->search([
            'index' => self::INDEX,
            'body' => [
                'query' => [
                    'match' => ['user_name' => $userName],
                ],
            ],
        ]);

        return array_map(
            fn($hit) => array_merge(['id' => $hit['_id']], $hit['_source']),
            $response['hits']['hits']
        );
    }
}
```

## MappService (Entity Definitions)

```php
<?php
// app/Services/MappService.php

namespace App\Services;

class MappService
{
    private array $documents = [];

    /**
     * Load JSON entity definitions from /Mapps/ folder.
     * Mirrors .NET MappService exactly.
     */
    public function __construct(string $mappsDir = null)
    {
        $basePath = $mappsDir ?? base_path('Mapps');

        if (is_dir($basePath)) {
            foreach (glob($basePath . '/*.json') as $file) {
                $this->documents[basename($file)] = file_get_contents($file);
            }
        }
    }

    public function documents(): array
    {
        return $this->documents;
    }

    public function getMapping(string $name): ?string
    {
        return $this->documents[$name] ?? null;
    }
}
```

## Service Provider

```php
<?php
// app/Providers/InfrastructureServiceProvider.php

namespace App\Providers;

use App\Services\{BlobStorageService, ElasticsearchFactory, FileProcessingService, MappService};
use Illuminate\Support\ServiceProvider;

class InfrastructureServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        // ES Client — Singleton (thread-safe, one connection pool)
        $this->app->singleton('elasticsearch', function ($app) {
            return ElasticsearchFactory::create(config('elasticsearch'));
        });

        // MappService — Singleton
        $this->app->singleton(MappService::class);

        // BlobStorageService — Scoped (like .NET: not Singleton)
        $this->app->bind(BlobStorageService::class, function () {
            return new BlobStorageService(config('filesystems.default', 'azure'));
        });

        // FileProcessingService
        $this->app->bind(FileProcessingService::class, function ($app) {
            return new FileProcessingService($app->make('elasticsearch'));
        });
    }
}
```

## File Upload Controller

```php
<?php
// app/Http/Controllers/FileController.php

namespace App\Http\Controllers;

use App\Services\{BlobStorageService, FileProcessingService};
use Illuminate\Http\{JsonResponse, Request};

class FileController extends Controller
{
    public function __construct(
        private readonly BlobStorageService $blobService,
        private readonly FileProcessingService $fileProcessing,
    ) {}

    /**
     * POST /api/files/upload — multipart file upload.
     * Flow: receive file → upload to blob → track in ES → return URL.
     */
    public function upload(Request $request): JsonResponse
    {
        $request->validate(['file' => 'required|file|max:51200']); // 50MB max

        $file = $request->file('file');
        $userName = $request->user()->id ?? 'anonymous';

        // Upload to blob storage
        $blobUrl = $this->blobService->uploadFile($file);

        // Track in Elasticsearch
        $id = $this->fileProcessing->create([
            'file_name' => $file->getClientOriginalName(),
            'blob_url' => $blobUrl,
            'user_name' => $userName,
            'content_type' => $file->getMimeType(),
        ]);

        return response()->json(['id' => $id, 'url' => $blobUrl]);
    }
}
```

### Routes

```php
// routes/api.php
Route::post('files/upload', [FileController::class, 'upload'])->middleware('auth:api');
```

## CORS Configuration

```php
<?php
// config/cors.php
return [
    'paths' => ['api/*', 'broadcasting/auth'],
    'allowed_origins' => explode(',', env('CORS_ORIGINS', 'http://localhost:3000')),
    'allowed_methods' => ['*'],
    'allowed_headers' => ['*'],
    'supports_credentials' => true,  // Required for WebSocket/SignalR
];
```

## Dependencies

```json
{
    "require": {
        "php": "^8.3",
        "laravel/framework": "^11.0",
        "elastic/elasticsearch-php": "^8.16",
        "league/flysystem-azure-blob-storage": "^3.0",
        "league/flysystem-aws-s3-v3": "^3.0"
    }
}
```

## Genie DNA Checklist

- [x] BlobStorageService: upload, download, delete (via Filesystem)
- [x] Dual ES config: cloud (cloud_id+auth) vs local
- [x] Auto-detect mode (username check)
- [x] MappService loading JSON from /Mapps/ folder
- [x] File processing pipeline tracked in ES
- [x] BlobStorageService is Scoped (bind, not singleton)
- [x] ES Client is Singleton
- [x] CORS with credentials
- [x] Azure, S3, and local disk all supported via Filesystem
- [x] Upload flow: multipart → blob → ES metadata → return URL
