---
name: dynamic-documents
description: >
  Schema-free dynamic document processing — the core Genie platform pattern.
  Originated as PHP WordPress dynamic forms (2013), evolved to .NET Core + Elasticsearch (2020).
  Use when building APIs that store/query arbitrary JSON without predefined models,
  creating dynamic CRUD endpoints, building search/filter UIs, or working with any
  schema-less data pattern. Triggers: dynamic CRUD, schema-less storage, Elasticsearch,
  ParseObjectAlternative, CreateQueryContainerList, filterBody, storeDocument, searchDocuments,
  MappService, entity definitions, dynamic forms, index_name.
---

# Dynamic Documents Pattern

The foundational pattern of the entire Genie platform. Every project inherits this DNA.

## The Core Innovation

**Any data type can be defined at runtime.** No model classes, no migrations, no schema changes. Send JSON → store in Elasticsearch → query back with automatic empty-field skipping.

## Evolution: PHP → .NET

### Generation 0: WordPress Plugin (2013)
Entities defined in MySQL `df_sys_definitions` table. Forms auto-generated from definitions.

```php
// DF_DataBase.php — Dynamic table creation per entity type
$query = "INSERT INTO df_sys_definitions SET
    entity_id={$_SESSION['entity_id']},
    system_name='{$Definition->system_name}',
    name='{$Definition->name}',
    type='{$Definition->type}',
    input_type='{$Definition->input_type}'";

// DF_DynamicForms.php — Forms rendered from definitions, never hardcoded
class DF_DynamicForms implements IDF_DynamicForms {
    public function createForm($systemTableName, $formType, $FormNum) { ... }
    public function processForm($systemTableName, $formType, $randomNumber, ...) { ... }
}
```

### Generation 1: .NET Core + Elasticsearch (2020)
MySQL tables per entity → single Elasticsearch index, any JSON structure. Entity definitions → JSON mapping files in `/Mapps/` folder.

## Key Methods

### 1. ParseObjectAlternative (C# — ObjectProcess.cs)

Recursively converts ANY incoming JSON into a `Dictionary<string, object>` that Elasticsearch can index. Handles nested objects, arrays, and auto-detects types (int, decimal, DateTime, bool, string).

```csharp
// ObjectProcess.cs — THE core method
public static object ParseObjectAlternative(object Document)
{
    if (Document.ToString().IndexOf("[") == 0)
    {
        // Array: recursively parse each element
        var results = new List<object>();
        var documents = System.Text.Json.JsonSerializer.Deserialize<object[]>(Document.ToString());
        for (var i = 0; i < documents.Length; i++)
            results.Add(ParseObjectAlternative(documents[i]));
        return results.ToArray();
    }
    else if (Document.ToString().IndexOf("{") == 0)
    {
        // Object: recursively parse each property
        Dictionary<string, object> myObject = new Dictionary<string, object>();
        dynamic stuff = JObject.Parse(Document.ToString());
        foreach (JProperty jproperty in stuff)
        {
            if (jproperty.Value.ToString().IndexOf("[") >= 0 || 
                jproperty.Value.ToString().IndexOf("{") >= 0)
                myObject[jproperty.Name] = ParseObjectAlternative(jproperty.Value);
            else
                myObject[jproperty.Name] = ParseJpropertyObject(jproperty);
        }
        return myObject;
    }
    else
    {
        return ParseSimpleObject(Document); // Auto-detect: int, decimal, DateTime, bool, string
    }
}
```

### 2. CreateQueryContainerList (C# — DynamicController.cs)

Builds Elasticsearch bool-filter queries dynamically from JSON. **The key innovation: automatically skips empty fields.** Only non-empty values become query filters.

```csharp
// DynamicController.cs — Dynamic query builder
public List<QueryContainer> CreateQueryContainerList(string prefix, string Document, List<QueryContainer> qlist)
{
    var result = qlist;
    if (Document.IndexOf("[") == 0)
    {
        // Array: recurse into each element
        var documents = System.Text.Json.JsonSerializer.Deserialize<object[]>(Document);
        for (var i = 0; i < documents.Length; i++)
            result = CreateQueryContainerList(prefix, documents[i].ToString(), result);
        return result;
    }
    else if (Document.IndexOf("{") == 0)
    {
        // Object: process each property
        dynamic stuff = JObject.Parse(Document.ToString());
        foreach (JProperty jproperty in stuff)
        {
            var newPrefix = prefix != "" ? prefix + "." + jproperty.Name : jproperty.Name;
            
            if (jproperty.Value.ToString().IndexOf("[") >= 0 || 
                jproperty.Value.ToString().IndexOf("{") >= 0)
            {
                result = CreateQueryContainerList(newPrefix, jproperty.Value.ToString(), result);
            }
            else
            {
                var value = jproperty.Value.ToString();
                if (value != "") // ← THE KEY: empty fields are SKIPPED
                {
                    MatchPhrasePrefixQuery queryM = new MatchPhrasePrefixQuery() 
                    { 
                        Field = newPrefix, 
                        Query = jproperty.Value.Type == JTokenType.String ? $"*{value}*" : $"{value}" 
                    };
                    result.Add(queryM);
                }
            }
        }
        return result;
    }
    else
    {
        if (Document != "")
        {
            result.Add(new MatchPhrasePrefixQuery() { Field = prefix, Query = $"{Document}" });
        }
        return result;
    }
}
```

### 3. filterBody (JavaScript — React Frontend)

Client-side counterpart: builds a filter object from form fields, **deletes empty fields** before sending to the server.

```javascript
// filterBody.js — Client-side filter builder
export const originObj = {
  "Full name": "",
  "Id number": "",
  "insurance company": "",
  "program name": "",
  // ... more fields defined per entity
};

export const filterBody = (fieldArr, searchWord, searchDateWord) => {
  for (let i = 0; i < searchWord.length; i++) {
    let j = fieldArr[i];
    if (searchWord[i] !== null) {
      originObj[j] = searchWord[i];
    } else {
      delete originObj[j]; // ← Empty fields REMOVED before sending
    }
  }
  for (let i = 0; i < searchDateWord.length; i++) {
    let j = fieldArr[i];
    if (searchDateWord[i] !== null) {
      originObj[j] = searchDateWord[i];
    } else {
      if (originObj[j] == null) delete originObj[j];
    }
  }
  return originObj;
};
```

## API Endpoints (DynamicController)

All endpoints require JWT `[Authorize]` and validate user via claims.

| Method | Route | Purpose |
|--------|-------|---------|
| POST | `/api/Dynamic/storeDocument/{index_name}/{id}` | Store/update any document |
| POST | `/api/Dynamic/searchDocuments/{index_name}` | Search with filter body |
| GET | `/api/Dynamic/getDocument/{index_name}/{id}` | Get single document |
| GET | `/api/Dynamic/getFilters/{index_name}/{fieldName}` | Get distinct values (aggregation) |
| POST | `/api/Dynamic/getFilters/{index_name}/{fieldName}` | Filtered aggregation |
| POST | `/api/Dynamic/getExcel/{index_name}` | Export filtered results to Excel |

### Store Document Flow
```
Client → POST /storeDocument/requests/doc123 + JSON body
  → [Authorize] validates JWT
  → GetStatUserByClaim(currentUser) checks permissions
  → ObjectProcess.ParseObjectAlternative(document) converts JSON
  → IndexRequest<object>(myDocument, index_name, id) stores in ES
  → Returns { status: true }
```

### Search Documents Flow
```
Client → POST /searchDocuments/requests + filter JSON (empty fields removed)
  → [Authorize] validates JWT
  → CreateQueryContainerList("", document, []) builds ES bool-filter
  → Non-admin users get automatic userId filter injected
  → SearchDescriptor<object>(index_name).Query(q => q.Bool(b => b.Filter(filters)))
  → Returns array of matching documents
```

## Entity Definitions (MappService)

Instead of PHP's `df_sys_definitions` database table, .NET uses JSON mapping files in `/Mapps/`:

```csharp
// MappService.cs — Loads entity definitions from JSON files
public class MappService : IMappService {
    public Dictionary<string, string> Documents() {
        var files = Directory.GetFiles(Path.Combine(Environment.CurrentDirectory, "Mapps"));
        foreach (var file in files) {
            if (!documents.ContainsKey(Path.GetFileName(file)))
                documents.Add(Path.GetFileName(file), File.ReadAllText(file));
        }
        return documents;
    }
}
```

Example mapping file (`firstdocument.json`): defines which fields appear in forms and tables for that entity type.

## Multi-Tenant Security Pattern

Non-admin users automatically get a userId filter injected into every query:
```csharp
if (!users.IsAdmin) {
    MatchPhrasePrefixQuery query = new MatchPhrasePrefixQuery() 
    { Field = "userId", Query = $"*{users.UserName}*" };
    queryContainerList.Add(query);
}
```

## When to Use This Pattern

- **Adding a new data type:** Just use a new `index_name` — ZERO model changes needed
- **Building a search/filter UI:** Use filterBody on client → CreateQueryContainerList on server
- **Dynamic CRUD:** ParseObjectAlternative handles any JSON structure
- **Export to Excel:** Same query pipeline → Excel via `/getExcel/` endpoint

## Alternative Implementations

For implementations in other tech stacks, see:
- `alternatives/dotnet-modern.md` — .NET 7/8/9 with Elastic.Clients.Elasticsearch
- `alternatives/nodejs.md` — Node.js + @elastic/elasticsearch 8.x
- `alternatives/python.md` — FastAPI + elasticsearch-py
- `alternatives/rust.md` — Axum + elasticsearch-rs
- `alternatives/php.md` — PHP 8 + elasticsearch-php
- `alternatives/angular.md` — Angular 17+ HTTP client pattern
- `alternatives/react-modern.md` — React 19 + RTK Query
- `alternatives/react-native.md` — Expo + React Native

## References

- `references/object-process-full.md` — Complete ObjectProcess.cs source with all helper methods
- `references/dynamic-controller-full.md` — Complete DynamicController.cs with all endpoints
