# Dynamic Documents — Rust (Axum + elasticsearch-rs)

> **Genie DNA:** Schema-free storage, recursive flattening, auto-skip empty fields.
> Idiomatic Rust — serde_json for dynamic data, tower middleware, strong typing where possible but `Value` for schema-free docs.

## Core Principle

Rust doesn't have "dynamic objects" like .NET/JS/Python, but `serde_json::Value` serves the same purpose. The key insight: we DON'T define structs for stored data — we work with `Value` throughout, preserving schema-freedom.

## ParseObjectAlternative

```rust
use serde_json::Value;
use chrono::NaiveDateTime;

/// Recursively flatten ANY JSON into ES-indexable key-value structure.
/// Mirrors .NET ObjectProcess.ParseObjectAlternative exactly.
pub fn parse_object_alternative(document: &Value) -> Value {
    match document {
        Value::Array(arr) => {
            Value::Array(arr.iter().map(parse_object_alternative).collect())
        }
        Value::Object(map) => {
            let mut result = serde_json::Map::new();
            for (key, value) in map {
                match value {
                    Value::Object(_) | Value::Array(_) => {
                        result.insert(key.clone(), parse_object_alternative(value));
                    }
                    _ => {
                        result.insert(key.clone(), parse_value(value));
                    }
                }
            }
            Value::Object(result)
        }
        _ => parse_value(document),
    }
}

/// Auto-detect type — mirrors ParseJpropertyObject.
/// Order: int → float → datetime → bool → string
fn parse_value(value: &Value) -> Value {
    match value {
        Value::Number(_) | Value::Bool(_) | Value::Null => value.clone(),
        Value::String(s) => {
            // Try integer
            if let Ok(i) = s.parse::<i64>() {
                return Value::Number(i.into());
            }
            // Try float
            if let Ok(f) = s.parse::<f64>() {
                if let Some(n) = serde_json::Number::from_f64(f) {
                    return Value::Number(n);
                }
            }
            // Try datetime
            if NaiveDateTime::parse_from_str(s, "%Y-%m-%dT%H:%M:%S").is_ok() {
                return value.clone(); // Keep as string, ES handles date detection
            }
            // Try bool
            match s.to_lowercase().as_str() {
                "true" => Value::Bool(true),
                "false" => Value::Bool(false),
                _ => value.clone(),
            }
        }
        _ => value.clone(),
    }
}
```

## CreateQueryContainerList

```rust
/// Build ES bool-filter query from partial document.
/// KEY INNOVATION: automatically skips empty/null fields.
pub fn create_query_container_list(document: &Value, prefix: &str) -> Vec<Value> {
    let mut queries = Vec::new();

    match document {
        Value::Array(arr) => {
            for item in arr {
                queries.extend(create_query_container_list(item, prefix));
            }
        }
        Value::Object(map) => {
            for (key, value) in map {
                let field_name = if prefix.is_empty() {
                    key.clone()
                } else {
                    format!("{}.{}", prefix, key)
                };

                match value {
                    Value::Object(_) | Value::Array(_) => {
                        queries.extend(create_query_container_list(value, &field_name));
                    }
                    _ => {
                        // ← THE KEY: skip null and empty strings
                        if !is_empty(value) {
                            let query_value = match value {
                                Value::String(s) => format!("*{}*", s),
                                other => other.to_string(),
                            };
                            queries.push(serde_json::json!({
                                "match_phrase_prefix": { &field_name: query_value }
                            }));
                        }
                    }
                }
            }
        }
        _ => {
            if !is_empty(document) {
                queries.push(serde_json::json!({
                    "match_phrase_prefix": { prefix: document.to_string() }
                }));
            }
        }
    }

    queries
}

fn is_empty(value: &Value) -> bool {
    matches!(value, Value::Null) || matches!(value, Value::String(s) if s.is_empty())
}
```

## Full CRUD API (Axum)

```rust
use axum::{
    extract::{Path, State, Json},
    routing::{get, post},
    Router, middleware,
    http::StatusCode,
};
use reqwest::Client as HttpClient;
use serde_json::{json, Value};
use std::sync::Arc;

#[derive(Clone)]
struct AppState {
    es_url: String,
    http: HttpClient,
}

#[tokio::main]
async fn main() {
    let state = Arc::new(AppState {
        es_url: std::env::var("ES_URL").unwrap_or_else(|_| "http://localhost:9200".into()),
        http: HttpClient::new(),
    });

    let app = Router::new()
        .route("/api/dynamic/:index_name/:doc_id", post(store_document).get(get_document))
        .route("/api/dynamic/search/:index_name", post(search_documents))
        .route("/api/dynamic/filters/:index_name/:field_name", get(get_filters))
        .layer(middleware::from_fn_with_state(state.clone(), auth_middleware))
        .with_state(state);

    let listener = tokio::net::TcpListener::bind("0.0.0.0:3000").await.unwrap();
    axum::serve(listener, app).await.unwrap();
}

/// Store/update any document — same route as .NET original
async fn store_document(
    State(state): State<Arc<AppState>>,
    Path((index_name, doc_id)): Path<(String, String)>,
    claims: Claims,
    Json(body): Json<Value>,
) -> Result<Json<Value>, StatusCode> {
    let parsed = parse_object_alternative(&body);

    state.http
        .put(format!("{}/{}/_doc/{}?refresh=wait_for", state.es_url, index_name, doc_id))
        .json(&parsed)
        .send()
        .await
        .map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)?;

    Ok(Json(json!({ "success": true, "id": doc_id })))
}

/// Search with filter body — multi-tenant isolation
async fn search_documents(
    State(state): State<Arc<AppState>>,
    Path(index_name): Path<String>,
    claims: Claims,
    Json(body): Json<Value>,
) -> Result<Json<Value>, StatusCode> {
    let mut filters = create_query_container_list(&body, "");

    // Multi-tenant: non-admins only see own data
    if !claims.is_admin {
        filters.push(json!({
            "match_phrase_prefix": { "userId": format!("*{}*", claims.user_id) }
        }));
    }

    let query = json!({
        "query": { "bool": { "filter": filters } }
    });

    let resp = state.http
        .post(format!("{}/{}/_search", state.es_url, index_name))
        .json(&query)
        .send()
        .await
        .map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)?
        .json::<Value>()
        .await
        .map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)?;

    let hits = resp["hits"]["hits"]
        .as_array()
        .unwrap_or(&vec![])
        .iter()
        .map(|h| {
            let mut doc = h["_source"].clone();
            if let Value::Object(ref mut map) = doc {
                map.insert("id".into(), h["_id"].clone());
            }
            doc
        })
        .collect::<Vec<_>>();

    Ok(Json(json!(hits)))
}

/// Get single document by ID
async fn get_document(
    State(state): State<Arc<AppState>>,
    Path((index_name, doc_id)): Path<(String, String)>,
    claims: Claims,
) -> Result<Json<Value>, StatusCode> {
    let resp = state.http
        .get(format!("{}/{}/_doc/{}", state.es_url, index_name, doc_id))
        .send()
        .await
        .map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)?
        .json::<Value>()
        .await
        .map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)?;

    if resp["found"].as_bool() == Some(true) {
        Ok(Json(json!({ "id": resp["_id"], "source": resp["_source"] })))
    } else {
        Err(StatusCode::NOT_FOUND)
    }
}

/// Get distinct values for aggregation
async fn get_filters(
    State(state): State<Arc<AppState>>,
    Path((index_name, field_name)): Path<(String, String)>,
    claims: Claims,
) -> Result<Json<Value>, StatusCode> {
    let query = json!({
        "size": 0,
        "aggs": { "distinct": { "terms": { "field": field_name, "size": 500 } } }
    });

    let resp = state.http
        .post(format!("{}/{}/_search", state.es_url, index_name))
        .json(&query)
        .send()
        .await
        .map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)?
        .json::<Value>()
        .await
        .map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)?;

    Ok(Json(resp["aggregations"]["distinct"]["buckets"].clone()))
}
```

## Dependencies (Cargo.toml)

```toml
[dependencies]
axum = "0.8"
tokio = { version = "1", features = ["full"] }
serde = { version = "1", features = ["derive"] }
serde_json = "1"
reqwest = { version = "0.12", features = ["json"] }
jsonwebtoken = "9"
chrono = { version = "0.4", features = ["serde"] }
tower = "0.5"
tower-http = { version = "0.6", features = ["cors"] }
```

## Genie DNA Checklist

- [x] parse_object_alternative recursive flattening (serde_json::Value)
- [x] create_query_container_list with empty-field skip
- [x] Multi-tenant userId injection for non-admins
- [x] Same API route structure: /api/dynamic/{index}/{id}
- [x] JWT auth via tower middleware
- [x] Aggregation endpoint
- [x] Schema-free: no data structs, all Value-based
- [x] Async throughout (tokio)
