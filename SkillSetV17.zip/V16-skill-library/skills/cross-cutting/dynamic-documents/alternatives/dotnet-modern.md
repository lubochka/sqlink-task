# Dynamic Documents — .NET Modern (7/8/9 + Elastic.Clients.Elasticsearch v8)

> **Genie DNA:** Schema-free storage, recursive flattening, auto-skip empty fields.
> This is the UPGRADED version — uses Elastic.Clients.Elasticsearch v8 (not NEST), minimal APIs, records, async/await throughout.

## Core Principle

Same Genie innovation, modern .NET idioms. The original used NEST + Newtonsoft.Json. This version uses the official Elastic v8 client + System.Text.Json.

## ParseObjectAlternative — Modernized

```csharp
using System.Text.Json;

public static class ObjectProcessor
{
    /// <summary>
    /// Recursively flatten ANY JSON into a Dictionary that Elasticsearch can index.
    /// Mirrors the original ObjectProcess.ParseObjectAlternative exactly in behavior.
    /// </summary>
    public static object ParseObjectAlternative(JsonElement element) => element.ValueKind switch
    {
        JsonValueKind.Object => ParseObject(element),
        JsonValueKind.Array  => element.EnumerateArray()
                                       .Select(ParseObjectAlternative)
                                       .ToArray(),
        _                    => ParseValue(element)
    };

    private static Dictionary<string, object> ParseObject(JsonElement element)
    {
        var result = new Dictionary<string, object>();
        foreach (var prop in element.EnumerateObject())
        {
            result[prop.Name] = prop.Value.ValueKind switch
            {
                JsonValueKind.Object or JsonValueKind.Array => ParseObjectAlternative(prop.Value),
                _ => ParseValue(prop.Value)
            };
        }
        return result;
    }

    /// <summary>
    /// Auto-detect type — mirrors ParseJpropertyObject behavior.
    /// Order: int → decimal → DateTime → bool → string
    /// </summary>
    private static object ParseValue(JsonElement element) => element.ValueKind switch
    {
        JsonValueKind.Number when element.TryGetInt64(out var l)       => l,
        JsonValueKind.Number when element.TryGetDecimal(out var d)     => d,
        JsonValueKind.True                                              => true,
        JsonValueKind.False                                             => false,
        JsonValueKind.String when DateTime.TryParse(element.GetString(), out var dt) => dt,
        JsonValueKind.String                                            => element.GetString()!,
        JsonValueKind.Null                                              => null!,
        _ => element.ToString()
    };
}
```

## CreateQueryContainerList — Modernized

```csharp
using Elastic.Clients.Elasticsearch;
using Elastic.Clients.Elasticsearch.QueryDsl;

public static class QueryBuilder
{
    /// <summary>
    /// Build ES bool-filter query from partial document.
    /// KEY INNOVATION: automatically skips empty/null fields.
    /// Uses Elastic.Clients.Elasticsearch v8 (not NEST).
    /// </summary>
    public static List<Query> CreateQueryContainerList(JsonElement element, string prefix = "")
    {
        var queries = new List<Query>();

        if (element.ValueKind == JsonValueKind.Object)
        {
            foreach (var prop in element.EnumerateObject())
            {
                var fieldName = string.IsNullOrEmpty(prefix) ? prop.Name : $"{prefix}.{prop.Name}";

                if (prop.Value.ValueKind is JsonValueKind.Object or JsonValueKind.Array)
                {
                    queries.AddRange(CreateQueryContainerList(prop.Value, fieldName));
                }
                else
                {
                    var value = prop.Value.ToString();
                    if (!string.IsNullOrEmpty(value)) // ← THE KEY: skip empties
                    {
                        queries.Add(new MatchPhrasePrefixQuery(fieldName)
                        {
                            Query = prop.Value.ValueKind == JsonValueKind.String
                                ? $"*{value}*"
                                : value
                        });
                    }
                }
            }
        }
        else if (element.ValueKind == JsonValueKind.Array)
        {
            foreach (var item in element.EnumerateArray())
                queries.AddRange(CreateQueryContainerList(item, prefix));
        }
        else
        {
            var value = element.ToString();
            if (!string.IsNullOrEmpty(value))
                queries.Add(new MatchPhrasePrefixQuery(prefix) { Query = value });
        }

        return queries;
    }
}
```

## Minimal API Endpoints (.NET 8/9)

```csharp
using Elastic.Clients.Elasticsearch;
using Microsoft.AspNetCore.Authorization;

var builder = WebApplication.CreateBuilder(args);

// Elastic v8 client registration
builder.Services.AddSingleton(sp =>
{
    var settings = new ElasticsearchClientSettings(
        new Uri(builder.Configuration["Elasticsearch:Url"] ?? "http://localhost:9200"));
    return new ElasticsearchClient(settings);
});

var app = builder.Build();

// Store document — same route pattern as original
app.MapPost("/api/dynamic/{indexName}/{docId}", [Authorize] async (
    string indexName, string docId, JsonElement body,
    ElasticsearchClient client, HttpContext ctx) =>
{
    var user = UserHelper.GetFromClaims(ctx.User, client);
    if (user is null) return Results.Unauthorized();

    var parsed = ObjectProcessor.ParseObjectAlternative(body);
    var response = await client.IndexAsync(new IndexRequest<object>(parsed, indexName, docId));
    return response.IsValidResponse
        ? Results.Ok(new { success = true, id = docId })
        : Results.Problem("Elasticsearch indexing failed");
});

// Search documents — same route + multi-tenant injection
app.MapPost("/api/dynamic/search/{indexName}", [Authorize] async (
    string indexName, JsonElement body,
    ElasticsearchClient client, HttpContext ctx) =>
{
    var user = UserHelper.GetFromClaims(ctx.User, client);
    if (user is null) return Results.Unauthorized();

    var filters = QueryBuilder.CreateQueryContainerList(body);

    // Multi-tenant isolation — non-admins only see own data
    if (!user.IsAdmin)
    {
        filters.Add(new MatchPhrasePrefixQuery("userId")
        {
            Query = $"*{user.UserId}*"
        });
    }

    var response = await client.SearchAsync<Dictionary<string, object>>(s => s
        .Index(indexName)
        .Query(q => q.Bool(b => b.Filter(filters.ToArray())))
    );

    var results = response.Hits.Select(h => new { id = h.Id, source = h.Source });
    return Results.Ok(results);
});

// Get single document
app.MapGet("/api/dynamic/{indexName}/{docId}", [Authorize] async (
    string indexName, string docId,
    ElasticsearchClient client, HttpContext ctx) =>
{
    var response = await client.GetAsync<Dictionary<string, object>>(docId, g => g.Index(indexName));
    return response.Found
        ? Results.Ok(new { id = response.Id, source = response.Source })
        : Results.NotFound();
});

// Aggregation (distinct values)
app.MapGet("/api/dynamic/filters/{indexName}/{fieldName}", [Authorize] async (
    string indexName, string fieldName,
    ElasticsearchClient client) =>
{
    var response = await client.SearchAsync<object>(s => s
        .Index(indexName)
        .Size(0)
        .Aggregations(a => a.Add("distinct", agg => agg.Terms(t => t.Field(fieldName))))
    );
    return Results.Ok(response.Aggregations);
});

app.Run();
```

## MappService — Modernized

```csharp
// Entity definitions from JSON files in /Mapps folder — same concept
public class MappService
{
    private readonly string _mappsPath;
    private readonly ConcurrentDictionary<string, JsonDocument> _cache = new();

    public MappService(IWebHostEnvironment env) =>
        _mappsPath = Path.Combine(env.ContentRootPath, "Mapps");

    public Dictionary<string, JsonDocument> GetDocuments()
    {
        foreach (var file in Directory.GetFiles(_mappsPath, "*.json"))
        {
            var name = Path.GetFileName(file);
            _cache.GetOrAdd(name, _ => JsonDocument.Parse(File.ReadAllText(file)));
        }
        return new(_cache);
    }
}
```

## Dependencies (csproj)

```xml
<PackageReference Include="Elastic.Clients.Elasticsearch" Version="8.15.*" />
<PackageReference Include="Microsoft.AspNetCore.Authentication.JwtBearer" Version="8.0.*" />
```

## Key Differences from Original .NET 5 Code

| Aspect | Original (NEST) | Modern (.NET 8/9) |
|--------|-----------------|-------------------|
| JSON parsing | Newtonsoft JObject | System.Text.Json JsonElement |
| ES client | NEST 7.x | Elastic.Clients.Elasticsearch 8.x |
| API style | Controllers + [HttpPost] | Minimal APIs + app.MapPost |
| Hosting | Startup.cs + Configure | WebApplication.CreateBuilder |
| Type detection | string.IndexOf checks | ValueKind pattern matching |
| Async | Mixed sync/async | Fully async |

## Genie DNA Checklist

- [x] ParseObjectAlternative recursive flattening (System.Text.Json)
- [x] CreateQueryContainerList with empty-field skip
- [x] Multi-tenant userId injection for non-admins
- [x] Same API route structure: /api/dynamic/{index}/{id}
- [x] MappService for entity definitions from JSON files
- [x] JWT [Authorize] on all endpoints
- [x] Aggregation endpoint for distinct values
- [x] Works with Elastic.Clients.Elasticsearch v8 (NOT NEST)
