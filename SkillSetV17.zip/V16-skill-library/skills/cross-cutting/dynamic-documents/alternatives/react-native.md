# Dynamic Documents — React Native / Expo (Latest)

> Genie DNA: schema-free CRUD, filterBody with empty-field skipping, dynamic form rendering on mobile, FlatList-based dynamic tables.

## Core: filterBody (Same Logic, Mobile Context)

```typescript
// utils/filterBody.ts
/**
 * Genie DNA filterBody — identical logic to web, used in mobile search screens.
 * Mirrors OpendTickets_Mobile.js search pattern.
 */
export function filterBodyFromState(formState: Record<string, unknown>): Record<string, unknown> {
  return Object.fromEntries(
    Object.entries(formState).filter(([_, v]) => v !== null && v !== '' && v !== undefined)
  );
}
```

## API Service with Axios

```typescript
// services/dynamicApi.ts
import axios, { AxiosInstance } from 'axios';
import * as SecureStore from 'expo-secure-store';

const API_URL = process.env.EXPO_PUBLIC_API_URL ?? 'https://your-server.azurewebsites.net';

class DynamicApiService {
  private client: AxiosInstance;

  constructor() {
    this.client = axios.create({ baseURL: API_URL });

    // Genie DNA: Bearer token on every request
    this.client.interceptors.request.use(async (config) => {
      const token = await SecureStore.getItemAsync('token');
      if (token) config.headers.Authorization = `Bearer ${token}`;
      return config;
    });
  }

  /** Search — POST with filterBody (partial doc → filtered results) */
  async searchDocuments(indexName: string, filter: Record<string, unknown>) {
    const { data } = await this.client.post(`/api/Dynamic/searchDocuments/${indexName}`, filter);
    return data as Array<{ id: string; [key: string]: unknown }>;
  }

  /** Store — POST single document */
  async storeDocument(indexName: string, docId: string, body: Record<string, unknown>) {
    const { data } = await this.client.post(`/api/Dynamic/storeDocument/${indexName}/${docId}`, body);
    return data;
  }

  /** Get single document */
  async getDocument(indexName: string, docId: string) {
    const { data } = await this.client.get(`/api/Dynamic/getDocument/${indexName}/${docId}`);
    return data;
  }

  /** Delete */
  async deleteDocument(indexName: string, docId: string) {
    await this.client.delete(`/api/Dynamic/deleteDocument/${indexName}/${docId}`);
  }

  /** Get filter options (aggregation values for a field) */
  async getFilters(indexName: string, fieldName: string, filter: Record<string, unknown>) {
    const { data } = await this.client.post(`/api/Dynamic/getFilters/${indexName}/${fieldName}`, filter);
    return data as string[];
  }
}

export const dynamicApi = new DynamicApiService();
```

## Context + Reducer (Genie Mobile Pattern)

Mirrors the original `GlobalContext.js` + `reducer_mobile.js` + `actions_mobile.js` pattern.

```typescript
// context/DynamicContext.tsx
import React, { createContext, useReducer, useContext, Dispatch } from 'react';

// Genie DNA: same action types from original actions_mobile.js
const SET_TABLE_DATA = 'SET_TABLE_DATA';
const SET_LOADING = 'SET_LOADING';
const SET_FILTERS = 'SET_FILTERS';
const CLEAR_FILTERS = 'CLEAR_FILTERS';

interface DynamicState {
  tableData: Record<string, unknown>[];
  loading: boolean;
  filters: Record<string, string>;
}

type DynamicAction =
  | { type: typeof SET_TABLE_DATA; payload: Record<string, unknown>[] }
  | { type: typeof SET_LOADING; payload: boolean }
  | { type: typeof SET_FILTERS; payload: Record<string, string> }
  | { type: typeof CLEAR_FILTERS };

const initialState: DynamicState = {
  tableData: [],
  loading: false,
  filters: {},
};

function reducer(state: DynamicState, action: DynamicAction): DynamicState {
  switch (action.type) {
    case SET_TABLE_DATA:
      return { ...state, tableData: action.payload, loading: false };
    case SET_LOADING:
      return { ...state, loading: action.payload };
    case SET_FILTERS:
      return { ...state, filters: action.payload };
    case CLEAR_FILTERS:
      return { ...state, filters: {} };
    default:
      return state;
  }
}

const DynamicContext = createContext<{ state: DynamicState; dispatch: Dispatch<DynamicAction> } | null>(null);

export function DynamicProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initialState);
  return (
    <DynamicContext.Provider value={{ state, dispatch }}>
      {children}
    </DynamicContext.Provider>
  );
}

export function useDynamic() {
  const ctx = useContext(DynamicContext);
  if (!ctx) throw new Error('useDynamic must be inside DynamicProvider');
  return ctx;
}

// Action creators
export const actions = {
  setTableData: (data: Record<string, unknown>[]) => ({ type: SET_TABLE_DATA, payload: data } as const),
  setLoading: (val: boolean) => ({ type: SET_LOADING, payload: val } as const),
  setFilters: (filters: Record<string, string>) => ({ type: SET_FILTERS, payload: filters } as const),
  clearFilters: () => ({ type: CLEAR_FILTERS } as const),
};
```

## Ticket List Screen (Mirrors OpendTickets_Mobile.js)

```tsx
// screens/TicketList.tsx
import React, { useEffect, useCallback, useState } from 'react';
import { View, FlatList, TouchableOpacity, Text, ActivityIndicator, RefreshControl, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useTranslation } from 'react-i18next';
import { dynamicApi } from '../services/dynamicApi';
import { filterBodyFromState } from '../utils/filterBody';
import { useDynamic, actions } from '../context/DynamicContext';

const INDEX_NAME = 'requests'; // Genie DNA: same index name

export default function TicketList() {
  const { t } = useTranslation();
  const navigation = useNavigation();
  const { state, dispatch } = useDynamic();
  const [refreshing, setRefreshing] = useState(false);

  const loadData = useCallback(async () => {
    dispatch(actions.setLoading(true));
    try {
      const filterDoc = filterBodyFromState(state.filters);
      const data = await dynamicApi.searchDocuments(INDEX_NAME, filterDoc);
      dispatch(actions.setTableData(data));
    } catch (err) {
      console.error('Search failed:', err);
    }
  }, [state.filters, dispatch]);

  useEffect(() => { loadData(); }, [loadData]);

  const onRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  };

  const renderItem = ({ item }: { item: Record<string, unknown> }) => (
    <TouchableOpacity
      style={styles.row}
      onPress={() => navigation.navigate('TicketDetail' as never, { docId: item.id } as never)}
    >
      <Text style={styles.name}>{String(item['Full name'] ?? '')}</Text>
      <Text style={styles.status}>{String(item['Pending notes'] ?? '')}</Text>
    </TouchableOpacity>
  );

  if (state.loading && !refreshing) return <ActivityIndicator size="large" style={styles.center} />;

  return (
    <View style={styles.container}>
      <FlatList
        data={state.tableData}
        keyExtractor={(item) => String(item.id)}
        renderItem={renderItem}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
        ListEmptyComponent={<Text style={styles.empty}>{t('tickets.no_results')}</Text>}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  center: { flex: 1, justifyContent: 'center' },
  row: { padding: 16, borderBottomWidth: 1, borderBottomColor: '#eee' },
  name: { fontSize: 16, fontWeight: '600' },
  status: { fontSize: 14, color: '#666', marginTop: 4 },
  empty: { textAlign: 'center', padding: 32, color: '#999' },
});
```

## Dynamic Form (Mobile)

```tsx
// components/DynamicForm.tsx
import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import DateTimePicker from '@react-native-community/datetimepicker';

interface FieldDefinition {
  name: string;
  label: string;
  type: 'text' | 'number' | 'date' | 'select' | 'textarea';
  required?: boolean;
  options?: string[];
}

interface Props {
  fields: FieldDefinition[];
  initialValues?: Record<string, unknown>;
  onSubmit: (data: Record<string, unknown>) => void;
}

export function DynamicForm({ fields, initialValues = {}, onSubmit }: Props) {
  const [values, setValues] = useState<Record<string, unknown>>(initialValues);

  const handleSubmit = () => {
    // Genie DNA: only send non-empty fields
    const cleaned = Object.fromEntries(
      Object.entries(values).filter(([_, v]) => v !== null && v !== '' && v !== undefined)
    );
    onSubmit(cleaned);
  };

  return (
    <ScrollView style={styles.form}>
      {fields.map((field) => (
        <View key={field.name} style={styles.field}>
          <Text style={styles.label}>{field.label}{field.required ? ' *' : ''}</Text>
          {field.type === 'select' ? (
            <Picker
              selectedValue={values[field.name] as string}
              onValueChange={(v) => setValues({ ...values, [field.name]: v })}
            >
              <Picker.Item label="Select..." value="" />
              {field.options?.map((opt) => (
                <Picker.Item key={opt} label={opt} value={opt} />
              ))}
            </Picker>
          ) : (
            <TextInput
              style={styles.input}
              value={String(values[field.name] ?? '')}
              onChangeText={(text) => setValues({ ...values, [field.name]: text })}
              keyboardType={field.type === 'number' ? 'numeric' : 'default'}
              multiline={field.type === 'textarea'}
              numberOfLines={field.type === 'textarea' ? 3 : 1}
              placeholder={field.label}
            />
          )}
        </View>
      ))}
      <TouchableOpacity style={styles.button} onPress={handleSubmit}>
        <Text style={styles.buttonText}>Save</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  form: { flex: 1, padding: 16 },
  field: { marginBottom: 16 },
  label: { fontSize: 14, fontWeight: '600', marginBottom: 4 },
  input: { borderWidth: 1, borderColor: '#ddd', borderRadius: 8, padding: 12, fontSize: 16 },
  button: { backgroundColor: '#007AFF', padding: 16, borderRadius: 8, alignItems: 'center', marginTop: 16 },
  buttonText: { color: '#fff', fontSize: 16, fontWeight: '600' },
});
```

## Navigation Setup (Mirrors mainNavigator.js)

```tsx
// navigation/MainNavigator.tsx
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import TicketList from '../screens/TicketList';
import TicketDetail from '../screens/TicketDetail';
import AddTicket from '../screens/AddTicket';
import Filters from '../screens/Filters';

const Stack = createNativeStackNavigator();

export function MainNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="TicketList" component={TicketList} />
      <Stack.Screen name="TicketDetail" component={TicketDetail} />
      <Stack.Screen name="AddTicket" component={AddTicket} />
      <Stack.Screen name="Filters" component={Filters} />
    </Stack.Navigator>
  );
}
```

## Dependencies

```json
{
  "expo": "~52.0",
  "react-native": "0.76+",
  "axios": "^1.7",
  "expo-secure-store": "~14.0",
  "i18next": "^24.0",
  "react-i18next": "^15.0",
  "@react-navigation/native": "^7.0",
  "@react-navigation/native-stack": "^7.0",
  "@react-native-picker/picker": "^2.10"
}
```

## Genie DNA Checklist
- [x] filterBody with empty-field removal (same logic as web)
- [x] Same API routes: `/api/Dynamic/{index}/{id}`
- [x] Context + useReducer pattern (mirrors GlobalContext + reducer_mobile)
- [x] FlatList with pull-to-refresh (mirrors OpendTickets_Mobile.js)
- [x] Dynamic form from entity definitions (runtime rendering)
- [x] Expo SecureStore for token (not AsyncStorage — more secure)
- [x] Axios interceptor for Bearer token injection
- [x] Navigation stack matching original mainNavigator.js screens
