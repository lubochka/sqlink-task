# Dynamic Documents — Node.js (Fastify + @elastic/elasticsearch 8.x)

> **Genie DNA:** Schema-free storage, recursive flattening, auto-skip empty fields.
> Idiomatic Node.js translation — Fastify for speed, native ES modules, async/await.

## Core Principle

Same Genie innovation in JavaScript: any JSON in, flattened for ES, query with auto-empty-skip. Uses `@elastic/elasticsearch` v8 (not v7).

## ParseObjectAlternative

```javascript
/**
 * Recursively flatten ANY JSON into ES-indexable key-value structure.
 * Mirrors .NET ObjectProcess.ParseObjectAlternative exactly.
 */
export function parseObjectAlternative(document) {
  if (Array.isArray(document)) {
    return document.map(item => parseObjectAlternative(item));
  }

  if (document !== null && typeof document === 'object') {
    const result = {};
    for (const [key, value] of Object.entries(document)) {
      if (Array.isArray(value) || (value !== null && typeof value === 'object')) {
        result[key] = parseObjectAlternative(value);
      } else {
        result[key] = parseValue(value);
      }
    }
    return result;
  }

  return parseValue(document);
}

/**
 * Auto-detect type — mirrors ParseJpropertyObject.
 * Order: int → float → date → bool → string
 */
function parseValue(value) {
  if (value === null || value === undefined) return null;
  if (typeof value === 'number' || typeof value === 'boolean') return value;

  const str = String(value);

  // Try integer
  if (/^-?\d+$/.test(str)) return parseInt(str, 10);
  // Try float
  if (/^-?\d+\.\d+$/.test(str)) return parseFloat(str);
  // Try date (ISO format)
  const date = new Date(str);
  if (!isNaN(date.getTime()) && /\d{4}-\d{2}/.test(str)) return date.toISOString();
  // Try bool
  if (str.toLowerCase() === 'true') return true;
  if (str.toLowerCase() === 'false') return false;

  return str;
}
```

## CreateQueryContainerList

```javascript
/**
 * Build ES bool-filter query from partial document.
 * KEY INNOVATION: automatically skips empty/null fields.
 * Returns array of ES query clauses for bool.filter.
 */
export function createQueryContainerList(document, prefix = '') {
  const queries = [];

  if (Array.isArray(document)) {
    for (const item of document) {
      queries.push(...createQueryContainerList(item, prefix));
    }
    return queries;
  }

  if (document !== null && typeof document === 'object') {
    for (const [key, value] of Object.entries(document)) {
      const fieldName = prefix ? `${prefix}.${key}` : key;

      if (value !== null && typeof value === 'object') {
        queries.push(...createQueryContainerList(value, fieldName));
      } else {
        // ← THE KEY: skip empty/null/undefined
        if (value !== null && value !== undefined && value !== '') {
          queries.push({
            match_phrase_prefix: {
              [fieldName]: typeof value === 'string' ? `*${value}*` : `${value}`
            }
          });
        }
      }
    }
    return queries;
  }

  // Primitive at root level
  if (document !== null && document !== undefined && document !== '') {
    queries.push({ match_phrase_prefix: { [prefix]: `${document}` } });
  }
  return queries;
}
```

## filterBody (Client-Side — shared with React frontend)

```javascript
/**
 * Build filter object from form fields.
 * Deletes empty fields before sending — client-side counterpart.
 */
export function filterBody(fields, values, dateValues = []) {
  const filter = {};
  for (let i = 0; i < fields.length; i++) {
    if (values[i] !== null && values[i] !== undefined && values[i] !== '') {
      filter[fields[i]] = values[i];
    }
    // Date overrides
    if (dateValues[i] !== null && dateValues[i] !== undefined) {
      filter[fields[i]] = dateValues[i];
    }
  }
  return filter;
}
```

## Full CRUD API (Fastify)

```javascript
import Fastify from 'fastify';
import { Client } from '@elastic/elasticsearch';
import { parseObjectAlternative, createQueryContainerList } from './dynamic-processor.js';
import { verifyJwt, getUserFromClaims } from './auth.js';

const fastify = Fastify({ logger: true });
const es = new Client({ node: process.env.ES_URL || 'http://localhost:9200' });

// JWT auth hook — all routes protected
fastify.addHook('onRequest', verifyJwt);

// Store document — same route pattern as .NET original
fastify.post('/api/dynamic/:indexName/:docId', async (req, reply) => {
  const { indexName, docId } = req.params;
  const user = await getUserFromClaims(req.user, es);
  if (!user) return reply.code(401).send({ error: 'Unauthorized' });

  const parsed = parseObjectAlternative(req.body);

  await es.index({
    index: indexName,
    id: docId,
    document: parsed,
    refresh: 'wait_for'
  });

  return { success: true, id: docId };
});

// Search documents — multi-tenant isolation
fastify.post('/api/dynamic/search/:indexName', async (req, reply) => {
  const { indexName } = req.params;
  const user = await getUserFromClaims(req.user, es);
  if (!user) return reply.code(401).send({ error: 'Unauthorized' });

  const filters = createQueryContainerList(req.body);

  // Multi-tenant: non-admins only see own data
  if (!user.isAdmin) {
    filters.push({
      match_phrase_prefix: { userId: `*${user.userId}*` }
    });
  }

  const result = await es.search({
    index: indexName,
    query: { bool: { filter: filters } }
  });

  return result.hits.hits.map(hit => ({
    id: hit._id,
    ...hit._source
  }));
});

// Get single document
fastify.get('/api/dynamic/:indexName/:docId', async (req, reply) => {
  const { indexName, docId } = req.params;
  try {
    const result = await es.get({ index: indexName, id: docId });
    return { id: result._id, ...result._source };
  } catch (e) {
    if (e.meta?.statusCode === 404) return reply.code(404).send({ error: 'Not found' });
    throw e;
  }
});

// Aggregation — distinct values for a field
fastify.get('/api/dynamic/filters/:indexName/:fieldName', async (req) => {
  const { indexName, fieldName } = req.params;
  const result = await es.search({
    index: indexName,
    size: 0,
    aggs: { distinct: { terms: { field: fieldName, size: 500 } } }
  });
  return result.aggregations.distinct.buckets.map(b => b.key);
});

// Filtered aggregation (POST variant)
fastify.post('/api/dynamic/filters/:indexName/:fieldName', async (req) => {
  const { indexName, fieldName } = req.params;
  const filters = createQueryContainerList(req.body);
  const result = await es.search({
    index: indexName,
    size: 0,
    query: { bool: { filter: filters } },
    aggs: { distinct: { terms: { field: fieldName, size: 500 } } }
  });
  return result.aggregations.distinct.buckets.map(b => b.key);
});

await fastify.listen({ port: 3000, host: '0.0.0.0' });
```

## MappService Equivalent

```javascript
import { readdir, readFile } from 'fs/promises';
import path from 'path';

const mappsDir = path.join(process.cwd(), 'Mapps');
const cache = new Map();

/**
 * Load entity definitions from JSON files in /Mapps folder.
 * Same concept as .NET MappService — define entities via JSON, not code.
 */
export async function getEntityDefinitions() {
  const files = await readdir(mappsDir);
  for (const file of files.filter(f => f.endsWith('.json'))) {
    if (!cache.has(file)) {
      cache.set(file, JSON.parse(await readFile(path.join(mappsDir, file), 'utf8')));
    }
  }
  return Object.fromEntries(cache);
}
```

## Dependencies (package.json)

```json
{
  "type": "module",
  "dependencies": {
    "fastify": "^5.0.0",
    "@elastic/elasticsearch": "^8.15.0",
    "@fastify/jwt": "^9.0.0",
    "@fastify/cors": "^10.0.0"
  }
}
```

## Genie DNA Checklist

- [x] parseObjectAlternative recursive flattening
- [x] createQueryContainerList with empty-field skip
- [x] filterBody client-side empty deletion
- [x] Multi-tenant userId injection for non-admins
- [x] Same API route structure: /api/dynamic/{index}/{id}
- [x] MappService equivalent for entity definitions
- [x] JWT auth on all endpoints
- [x] Aggregation endpoints (GET + filtered POST)
- [x] @elastic/elasticsearch v8 (NOT v7)
