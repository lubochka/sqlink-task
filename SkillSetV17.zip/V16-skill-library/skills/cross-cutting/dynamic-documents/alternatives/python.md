# Dynamic Documents — Python (FastAPI + elasticsearch-py 8.x)

> **Genie DNA:** Schema-free storage, recursive flattening, auto-skip empty fields.
> Idiomatic Python — type hints, async/await, Pydantic for config, no fixed models for data.

## Core Principle

Same Genie innovation: any JSON in, recursively flattened, auto-skip empties on query. FastAPI chosen for async + auto-docs. Elasticsearch-py 8.x async client.

## ParseObjectAlternative

```python
from datetime import datetime
from typing import Any

def parse_object_alternative(document: Any) -> Any:
    """
    Recursively flatten ANY JSON into ES-indexable key-value pairs.
    Mirrors .NET ObjectProcess.ParseObjectAlternative exactly.
    """
    if isinstance(document, list):
        return [parse_object_alternative(item) for item in document]

    if isinstance(document, dict):
        result = {}
        for key, value in document.items():
            if isinstance(value, (dict, list)):
                result[key] = parse_object_alternative(value)
            else:
                result[key] = _parse_value(value)
        return result

    return _parse_value(document)


def _parse_value(value: Any) -> Any:
    """
    Auto-detect type — mirrors ParseJpropertyObject.
    Order: int → float → datetime → bool → string
    """
    if value is None:
        return None
    if isinstance(value, (int, float, bool)):
        return value

    s = str(value)

    # Try int
    try:
        return int(s)
    except (ValueError, TypeError):
        pass
    # Try float
    try:
        return float(s)
    except (ValueError, TypeError):
        pass
    # Try datetime (ISO format)
    try:
        return datetime.fromisoformat(s).isoformat()
    except (ValueError, TypeError):
        pass
    # Try bool
    if s.lower() in ("true", "false"):
        return s.lower() == "true"

    return s
```

## CreateQueryContainerList

```python
def create_query_container_list(
    document: Any, prefix: str = ""
) -> list[dict]:
    """
    Build ES bool-filter query from partial document.
    KEY INNOVATION: automatically skips empty/None fields.
    Returns list of ES query clauses for bool.filter.
    """
    queries = []

    if isinstance(document, list):
        for item in document:
            queries.extend(create_query_container_list(item, prefix))
        return queries

    if isinstance(document, dict):
        for key, value in document.items():
            field_name = f"{prefix}.{key}" if prefix else key

            if isinstance(value, (dict, list)):
                queries.extend(create_query_container_list(value, field_name))
            else:
                # ← THE KEY: skip None and empty strings
                if value is not None and value != "":
                    query_value = (
                        f"*{value}*" if isinstance(value, str) else str(value)
                    )
                    queries.append(
                        {"match_phrase_prefix": {field_name: query_value}}
                    )
        return queries

    # Primitive at root
    if document is not None and document != "":
        queries.append({"match_phrase_prefix": {prefix: str(document)}})
    return queries
```

## Full CRUD API (FastAPI)

```python
import os
from pathlib import Path
from fastapi import FastAPI, Depends, HTTPException
from elasticsearch import AsyncElasticsearch
from .auth import get_current_user, UserStore
from .dynamic_processor import parse_object_alternative, create_query_container_list

app = FastAPI(title="Genie Dynamic Documents")

es = AsyncElasticsearch(
    hosts=[os.getenv("ES_URL", "http://localhost:9200")]
)


@app.post("/api/dynamic/{index_name}/{doc_id}")
async def store_document(
    index_name: str,
    doc_id: str,
    body: dict,
    user: UserStore = Depends(get_current_user),
):
    """Store/update any document — same route as .NET original."""
    parsed = parse_object_alternative(body)
    await es.index(index=index_name, id=doc_id, document=parsed, refresh="wait_for")
    return {"success": True, "id": doc_id}


@app.post("/api/dynamic/search/{index_name}")
async def search_documents(
    index_name: str,
    body: dict,
    user: UserStore = Depends(get_current_user),
):
    """Search with filter body — multi-tenant isolation."""
    filters = create_query_container_list(body)

    # Multi-tenant: non-admins only see own data
    if not user.is_admin:
        filters.append(
            {"match_phrase_prefix": {"userId": f"*{user.user_id}*"}}
        )

    result = await es.search(
        index=index_name,
        query={"bool": {"filter": filters}},
    )
    return [
        {"id": hit["_id"], **hit["_source"]}
        for hit in result["hits"]["hits"]
    ]


@app.get("/api/dynamic/{index_name}/{doc_id}")
async def get_document(
    index_name: str,
    doc_id: str,
    user: UserStore = Depends(get_current_user),
):
    """Get single document by ID."""
    try:
        result = await es.get(index=index_name, id=doc_id)
        return {"id": result["_id"], **result["_source"]}
    except Exception:
        raise HTTPException(status_code=404, detail="Document not found")


@app.get("/api/dynamic/filters/{index_name}/{field_name}")
async def get_filters(
    index_name: str,
    field_name: str,
    user: UserStore = Depends(get_current_user),
):
    """Get distinct values for aggregation dropdown."""
    result = await es.search(
        index=index_name,
        size=0,
        aggs={"distinct": {"terms": {"field": field_name, "size": 500}}},
    )
    return [
        bucket["key"]
        for bucket in result["aggregations"]["distinct"]["buckets"]
    ]


@app.post("/api/dynamic/filters/{index_name}/{field_name}")
async def get_filtered_filters(
    index_name: str,
    field_name: str,
    body: dict,
    user: UserStore = Depends(get_current_user),
):
    """Filtered aggregation — apply filter then aggregate."""
    filters = create_query_container_list(body)
    result = await es.search(
        index=index_name,
        size=0,
        query={"bool": {"filter": filters}},
        aggs={"distinct": {"terms": {"field": field_name, "size": 500}}},
    )
    return [
        bucket["key"]
        for bucket in result["aggregations"]["distinct"]["buckets"]
    ]
```

## MappService Equivalent

```python
import json
from functools import lru_cache

MAPPS_DIR = Path("Mapps")

@lru_cache(maxsize=None)
def get_entity_definitions() -> dict[str, dict]:
    """
    Load entity definitions from JSON files in /Mapps folder.
    Same concept as .NET MappService.
    """
    definitions = {}
    for file in MAPPS_DIR.glob("*.json"):
        definitions[file.name] = json.loads(file.read_text())
    return definitions
```

## Dependencies (requirements.txt)

```
fastapi>=0.115
elasticsearch[async]>=8.15
python-jose[cryptography]>=3.3
uvicorn>=0.32
pydantic>=2.9
passlib[bcrypt]>=1.7
```

## Genie DNA Checklist

- [x] parse_object_alternative recursive flattening
- [x] create_query_container_list with empty-field skip
- [x] Multi-tenant userId injection for non-admins
- [x] Same API route structure: /api/dynamic/{index}/{id}
- [x] MappService equivalent (JSON file entity definitions)
- [x] JWT auth via Depends(get_current_user)
- [x] Aggregation endpoints (GET + filtered POST)
- [x] elasticsearch-py async v8
