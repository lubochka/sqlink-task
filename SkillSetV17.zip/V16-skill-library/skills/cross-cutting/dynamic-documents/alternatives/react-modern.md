# Dynamic Documents — React 19 + Redux Toolkit Query

> Genie DNA: schema-free CRUD, filterBody with empty-field skipping, dynamic form generation, dynamic table rendering.

## Core: filterBody (Modern Implementation)

```typescript
// features/dynamic/filterBody.ts
/**
 * Genie DNA filterBody — builds search payload with automatic empty-field removal.
 * Improved from original: generic, type-safe, no mutable global state.
 */
export function filterBody(
  fieldArr: string[],
  searchWord: (string | null)[],
  searchDateWord: (string | null)[] = []
): Record<string, unknown> {
  const body: Record<string, unknown> = {};

  fieldArr.forEach((field, i) => {
    if (searchWord[i] !== null && searchWord[i] !== '') {
      body[field] = searchWord[i];
    }
    if (searchDateWord[i] !== null && searchDateWord[i] !== '') {
      body[field] = searchDateWord[i];
    }
  });

  return body; // Only non-empty fields — server's CreateQueryContainerList skips the rest
}

/**
 * Modern variant: build filter from form state object directly.
 * Eliminates the need for separate fieldArr/searchWord arrays.
 */
export function filterBodyFromState(formState: Record<string, unknown>): Record<string, unknown> {
  return Object.fromEntries(
    Object.entries(formState).filter(([_, v]) => v !== null && v !== '' && v !== undefined)
  );
}
```

## RTK Query API Slice

```typescript
// features/dynamic/dynamicApi.ts
import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import type { RootState } from '../../store';

interface DynamicDoc {
  id: string;
  [key: string]: unknown;
}

export const dynamicApi = createApi({
  reducerPath: 'dynamicApi',
  baseQuery: fetchBaseQuery({
    baseUrl: import.meta.env.VITE_API_URL,
    prepareHeaders: (headers, { getState }) => {
      const token = (getState() as RootState).auth.token;
      if (token) headers.set('Authorization', `Bearer ${token}`);
      return headers;
    },
  }),
  tagTypes: ['Document'],
  endpoints: (builder) => ({
    // Search — POST with filterBody (Genie DNA: partial doc → filtered results)
    searchDocuments: builder.query<DynamicDoc[], { indexName: string; filter: Record<string, unknown> }>({
      query: ({ indexName, filter }) => ({
        url: `/api/Dynamic/searchDocuments/${indexName}`,
        method: 'POST',
        body: filter,
      }),
      providesTags: (result, _err, { indexName }) =>
        result
          ? [...result.map(({ id }) => ({ type: 'Document' as const, id })), { type: 'Document', id: indexName }]
          : [{ type: 'Document', id: indexName }],
    }),

    // Store — POST single document
    storeDocument: builder.mutation<void, { indexName: string; docId: string; body: Record<string, unknown> }>({
      query: ({ indexName, docId, body }) => ({
        url: `/api/Dynamic/storeDocument/${indexName}/${docId}`,
        method: 'POST',
        body,
      }),
      invalidatesTags: (_res, _err, { indexName }) => [{ type: 'Document', id: indexName }],
    }),

    // Get single document
    getDocument: builder.query<DynamicDoc, { indexName: string; docId: string }>({
      query: ({ indexName, docId }) => `/api/Dynamic/getDocument/${indexName}/${docId}`,
      providesTags: (_res, _err, { docId }) => [{ type: 'Document', id: docId }],
    }),

    // Delete
    deleteDocument: builder.mutation<void, { indexName: string; docId: string }>({
      query: ({ indexName, docId }) => ({
        url: `/api/Dynamic/deleteDocument/${indexName}/${docId}`,
        method: 'DELETE',
      }),
      invalidatesTags: (_res, _err, { indexName, docId }) => [
        { type: 'Document', id: indexName },
        { type: 'Document', id: docId },
      ],
    }),

    // Get filter options for a field (aggregation)
    getFilters: builder.query<string[], { indexName: string; fieldName: string; filter: Record<string, unknown> }>({
      query: ({ indexName, fieldName, filter }) => ({
        url: `/api/Dynamic/getFilters/${indexName}/${fieldName}`,
        method: 'POST',
        body: filter,
      }),
    }),

    // Entity definitions (mirrors MappService)
    getDefinition: builder.query<FieldDefinition[], string>({
      query: (entityName) => `/api/Dynamic/getDefinition/${entityName}`,
    }),
  }),
});

export const {
  useSearchDocumentsQuery,
  useStoreDocumentMutation,
  useGetDocumentQuery,
  useDeleteDocumentMutation,
  useGetFiltersQuery,
  useGetDefinitionQuery,
} = dynamicApi;
```

## Dynamic Form Component

```tsx
// components/DynamicForm.tsx
import { useForm, Controller } from 'react-hook-form';

export interface FieldDefinition {
  name: string;
  label: string;
  type: 'text' | 'number' | 'date' | 'select' | 'textarea';
  required?: boolean;
  options?: string[];
}

interface DynamicFormProps {
  fields: FieldDefinition[];
  initialValues?: Record<string, unknown>;
  onSubmit: (data: Record<string, unknown>) => void;
}

export function DynamicForm({ fields, initialValues = {}, onSubmit }: DynamicFormProps) {
  const { control, handleSubmit, formState: { errors } } = useForm({
    defaultValues: initialValues,
  });

  const submitHandler = (data: Record<string, unknown>) => {
    // Genie DNA: strip empty fields before sending
    const cleaned = Object.fromEntries(
      Object.entries(data).filter(([_, v]) => v !== null && v !== '' && v !== undefined)
    );
    onSubmit(cleaned);
  };

  return (
    <form onSubmit={handleSubmit(submitHandler)}>
      {fields.map((field) => (
        <div key={field.name} className="form-field">
          <label htmlFor={field.name}>{field.label}</label>
          <Controller
            name={field.name}
            control={control}
            rules={{ required: field.required ? 'Required' : false }}
            render={({ field: formField }) => {
              switch (field.type) {
                case 'select':
                  return (
                    <select {...formField}>
                      <option value="">Select...</option>
                      {field.options?.map((opt) => (
                        <option key={opt} value={opt}>{opt}</option>
                      ))}
                    </select>
                  );
                case 'textarea':
                  return <textarea {...formField} rows={3} />;
                case 'date':
                  return <input type="date" {...formField} />;
                case 'number':
                  return <input type="number" {...formField} />;
                default:
                  return <input type="text" {...formField} />;
              }
            }}
          />
          {errors[field.name] && <span className="error">{String(errors[field.name]?.message)}</span>}
        </div>
      ))}
      <button type="submit">Save</button>
    </form>
  );
}
```

## Dynamic Table with Search (Tickets Page Pattern)

```tsx
// components/DynamicTable.tsx
import { useState, useMemo, useTransition } from 'react';
import { useSearchDocumentsQuery } from '../features/dynamic/dynamicApi';
import { filterBodyFromState } from '../features/dynamic/filterBody';

interface DynamicTableProps {
  indexName: string;
  columns: string[];
  onRowClick?: (row: Record<string, unknown>) => void;
}

export function DynamicTable({ indexName, columns, onRowClick }: DynamicTableProps) {
  const [filters, setFilters] = useState<Record<string, string>>({});
  const [isPending, startTransition] = useTransition();

  const filterDoc = useMemo(() => filterBodyFromState(filters), [filters]);
  const { data: rows = [], isLoading, isFetching } = useSearchDocumentsQuery({ indexName, filter: filterDoc });

  const updateFilter = (field: string, value: string) => {
    startTransition(() => {
      setFilters((prev) => {
        const next = { ...prev };
        if (value === '') delete next[field];
        else next[field] = value;
        return next;
      });
    });
  };

  return (
    <div>
      {/* Filter row — mirrors Genie's search inputs per column */}
      <div className="filter-row">
        {columns.map((col) => (
          <input
            key={col}
            placeholder={`Search ${col}...`}
            value={filters[col] ?? ''}
            onChange={(e) => updateFilter(col, e.target.value)}
          />
        ))}
      </div>

      {(isLoading || isPending) && <div className="loading">Loading...</div>}

      <table>
        <thead>
          <tr>{columns.map((col) => <th key={col}>{col}</th>)}</tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row.id} onClick={() => onRowClick?.(row)}>
              {columns.map((col) => <td key={col}>{String(row[col] ?? '')}</td>)}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
```

## Store Setup

```typescript
// store.ts
import { configureStore } from '@reduxjs/toolkit';
import { dynamicApi } from './features/dynamic/dynamicApi';
import authReducer from './features/auth/authSlice';

export const store = configureStore({
  reducer: {
    auth: authReducer,
    [dynamicApi.reducerPath]: dynamicApi.reducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware().concat(dynamicApi.middleware),
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
```

## Dependencies

```json
{
  "react": "^19.0",
  "react-dom": "^19.0",
  "@reduxjs/toolkit": "^2.5",
  "react-redux": "^9.2",
  "react-hook-form": "^7.54"
}
```

## Genie DNA Checklist
- [x] filterBody with automatic empty-field removal (both array and object variants)
- [x] RTK Query endpoints matching `/api/Dynamic/{index}/{id}` routes
- [x] Dynamic form from entity definitions (runtime, no hardcoded models)
- [x] Dynamic table with per-column search filters
- [x] JWT injected via prepareHeaders (token from Redux auth slice)
- [x] RTK Query cache invalidation on mutations
- [x] React 19 useTransition for non-blocking filter updates
- [x] MappService equivalent via getDefinition endpoint
