# Dynamic Documents — Angular 17+ (Standalone Components + Signals)

> Genie DNA: schema-free CRUD, filterBody with empty-field skipping, dynamic form generation from entity definitions.

## Core: filterBody Equivalent (Angular Service)

```typescript
// services/dynamic-document.service.ts
import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../environments/environment';

@Injectable({ providedIn: 'root' })
export class DynamicDocumentService {
  private http = inject(HttpClient);
  private baseUrl = environment.apiUrl;

  /**
   * filterBody — Genie DNA: builds a search payload, auto-removes empty fields.
   * Mirrors React's filterBody.js + server's CreateQueryContainerList empty-skip logic.
   */
  filterBody(fieldArr: string[], searchWord: (string | null)[], searchDateWord: (string | null)[]): Record<string, unknown> {
    const body: Record<string, unknown> = {};

    for (let i = 0; i < searchWord.length; i++) {
      const key = fieldArr[i];
      if (searchWord[i] !== null && searchWord[i] !== '') {
        body[key] = searchWord[i];
      }
      // No else — simply don't include the field (empty-skip)
    }

    for (let i = 0; i < searchDateWord.length; i++) {
      const key = fieldArr[i];
      if (searchDateWord[i] !== null && searchDateWord[i] !== '') {
        body[key] = searchDateWord[i];
      }
    }

    return body; // Only non-empty fields — server does the rest
  }

  /** CRUD Operations — matching Genie's /api/Dynamic/{index}/{id} routes */

  searchDocuments(indexName: string, filterDoc: Record<string, unknown>): Observable<any[]> {
    return this.http.post<any[]>(`${this.baseUrl}/api/Dynamic/searchDocuments/${indexName}`, filterDoc);
  }

  storeDocument(indexName: string, docId: string, body: Record<string, unknown>): Observable<any> {
    return this.http.post(`${this.baseUrl}/api/Dynamic/storeDocument/${indexName}/${docId}`, body);
  }

  getDocument(indexName: string, docId: string): Observable<any> {
    return this.http.get(`${this.baseUrl}/api/Dynamic/getDocument/${indexName}/${docId}`);
  }

  deleteDocument(indexName: string, docId: string): Observable<any> {
    return this.http.delete(`${this.baseUrl}/api/Dynamic/deleteDocument/${indexName}/${docId}`);
  }

  getFilters(indexName: string, fieldName: string, filterDoc: Record<string, unknown>): Observable<string[]> {
    return this.http.post<string[]>(`${this.baseUrl}/api/Dynamic/getFilters/${indexName}/${fieldName}`, filterDoc);
  }
}
```

## Dynamic Form Generator (Standalone Component)

Mirrors Genie's `DynamicFormComponent` — generates forms from entity definitions at runtime.

```typescript
// components/dynamic-form/dynamic-form.component.ts
import { Component, input, output, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormGroup, FormControl, Validators } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';

export interface FieldDefinition {
  name: string;
  label: string;
  type: 'text' | 'number' | 'date' | 'select' | 'textarea';
  required?: boolean;
  options?: string[]; // For select fields
}

@Component({
  selector: 'app-dynamic-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, MatFormFieldModule, MatInputModule, MatSelectModule, MatDatepickerModule],
  template: `
    <form [formGroup]="form" (ngSubmit)="onSubmit()">
      @for (field of fields(); track field.name) {
        <mat-form-field appearance="outline" class="full-width">
          <mat-label>{{ field.label }}</mat-label>
          @switch (field.type) {
            @case ('text') {
              <input matInput [formControlName]="field.name" />
            }
            @case ('number') {
              <input matInput type="number" [formControlName]="field.name" />
            }
            @case ('date') {
              <input matInput [matDatepicker]="picker" [formControlName]="field.name" />
              <mat-datepicker-toggle matSuffix [for]="picker" />
              <mat-datepicker #picker />
            }
            @case ('select') {
              <mat-select [formControlName]="field.name">
                @for (opt of field.options; track opt) {
                  <mat-option [value]="opt">{{ opt }}</mat-option>
                }
              </mat-select>
            }
            @case ('textarea') {
              <textarea matInput [formControlName]="field.name" rows="3"></textarea>
            }
          }
          @if (form.get(field.name)?.hasError('required')) {
            <mat-error>Required</mat-error>
          }
        </mat-form-field>
      }
      <button mat-raised-button color="primary" type="submit" [disabled]="form.invalid">Save</button>
    </form>
  `
})
export class DynamicFormComponent implements OnInit {
  fields = input.required<FieldDefinition[]>();
  values = input<Record<string, unknown>>({});
  formSubmit = output<Record<string, unknown>>();

  form = new FormGroup({});

  ngOnInit() {
    for (const field of this.fields()) {
      const validators = field.required ? [Validators.required] : [];
      this.form.addControl(
        field.name,
        new FormControl(this.values()[field.name] ?? '', validators)
      );
    }
  }

  onSubmit() {
    if (this.form.valid) {
      // Genie DNA: emit only non-empty fields
      const cleaned: Record<string, unknown> = {};
      for (const [key, value] of Object.entries(this.form.value)) {
        if (value !== null && value !== '') cleaned[key] = value;
      }
      this.formSubmit.emit(cleaned);
    }
  }
}
```

## Entity Definitions from MappService

```typescript
// services/mapp.service.ts — loads entity field definitions (mirrors /Mapps/ folder)
import { Injectable, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FieldDefinition } from '../components/dynamic-form/dynamic-form.component';
import { environment } from '../environments/environment';

@Injectable({ providedIn: 'root' })
export class MappService {
  private http = inject(HttpClient);

  // Cache loaded definitions in a signal
  private definitionsCache = signal<Map<string, FieldDefinition[]>>(new Map());

  /** Load entity definition — mirrors MappService.cs GetEntityDefinition */
  async loadDefinition(entityName: string): Promise<FieldDefinition[]> {
    const cached = this.definitionsCache().get(entityName);
    if (cached) return cached;

    const fields = await this.http
      .get<FieldDefinition[]>(`${environment.apiUrl}/api/Dynamic/getDefinition/${entityName}`)
      .toPromise();

    this.definitionsCache.update(map => {
      const newMap = new Map(map);
      newMap.set(entityName, fields ?? []);
      return newMap;
    });

    return fields ?? [];
  }
}
```

## Search Table with Dynamic Columns (Standalone)

```typescript
// components/dynamic-table/dynamic-table.component.ts
import { Component, input, output, computed, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatSortModule, Sort } from '@angular/material/sort';

@Component({
  selector: 'app-dynamic-table',
  standalone: true,
  imports: [CommonModule, MatTableModule, MatPaginatorModule, MatSortModule],
  template: `
    <mat-table [dataSource]="data()" matSort (matSortChange)="sortChange.emit($event)">
      @for (col of columns(); track col) {
        <ng-container [matColumnDef]="col">
          <mat-header-cell *matHeaderCellDef mat-sort-header>{{ col }}</mat-header-cell>
          <mat-cell *matCellDef="let row">{{ row[col] }}</mat-cell>
        </ng-container>
      }
      <mat-header-row *matHeaderRowDef="columns()" />
      <mat-row *matRowDef="let row; columns: columns()" (click)="rowClick.emit(row)" />
    </mat-table>
    <mat-paginator [length]="data().length" [pageSize]="10" [pageSizeOptions]="[5, 10, 25]" />
  `
})
export class DynamicTableComponent {
  data = input.required<Record<string, unknown>[]>();
  columns = input.required<string[]>();
  rowClick = output<Record<string, unknown>>();
  sortChange = output<Sort>();
}
```

## Dependencies

```json
{
  "@angular/core": "^17.0 || ^18.0 || ^19.0",
  "@angular/material": "^17.0 || ^18.0 || ^19.0",
  "@angular/cdk": "^17.0 || ^18.0 || ^19.0",
  "@angular/forms": "^17.0 || ^18.0 || ^19.0"
}
```

## Genie DNA Checklist
- [x] filterBody with automatic empty-field removal
- [x] Dynamic form generated from entity definitions at runtime
- [x] Same API routes: `/api/Dynamic/{index}/{id}`
- [x] Dynamic table with runtime columns (mirrors react_table_dynamic)
- [x] MappService for entity definition loading
- [x] Standalone components (Angular 17+ best practice)
- [x] Signal-based state management
- [x] JWT handled by HttpInterceptor (see auth-jwt/angular.md)
