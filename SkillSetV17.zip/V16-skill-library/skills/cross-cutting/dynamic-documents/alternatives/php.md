# Dynamic Documents — PHP 8.3 (Laravel + elasticsearch-php 8.x)

> **Genie DNA:** Schema-free storage, recursive flattening, auto-skip empty fields.
> Comes full circle: Genie started as a WordPress PHP plugin. This modernizes that origin story with Laravel + ES v8.

## Core Principle

The Genie platform **originated in PHP** (DF_DynamicForms, DF_DataBase, DF_DefineEntities). The original used MySQL dynamic tables per entity type. This modern version keeps the PHP DNA but upgrades to Elasticsearch + Laravel, matching the .NET evolution.

## ParseObjectAlternative

```php
<?php

namespace App\Services;

class DynamicProcessor
{
    /**
     * Recursively flatten ANY JSON into ES-indexable structure.
     * Mirrors .NET ObjectProcess.ParseObjectAlternative exactly.
     * Also mirrors the original PHP DF_DataBase dynamic field processing.
     */
    public static function parseObjectAlternative(mixed $document): mixed
    {
        if (is_array($document) && array_is_list($document)) {
            return array_map([self::class, 'parseObjectAlternative'], $document);
        }

        if (is_array($document) || is_object($document)) {
            $result = [];
            foreach ((array) $document as $key => $value) {
                if (is_array($value) || is_object($value)) {
                    $result[$key] = self::parseObjectAlternative($value);
                } else {
                    $result[$key] = self::parseValue($value);
                }
            }
            return $result;
        }

        return self::parseValue($document);
    }

    /**
     * Auto-detect type — mirrors ParseJpropertyObject.
     * Order: int → float → datetime → bool → string
     */
    private static function parseValue(mixed $value): mixed
    {
        if ($value === null) return null;
        if (is_int($value) || is_float($value) || is_bool($value)) return $value;

        $str = (string) $value;

        // Try integer
        if (ctype_digit($str) || (str_starts_with($str, '-') && ctype_digit(substr($str, 1)))) {
            return (int) $str;
        }
        // Try float
        if (is_numeric($str) && str_contains($str, '.')) {
            return (float) $str;
        }
        // Try datetime
        $date = \DateTimeImmutable::createFromFormat(\DateTimeInterface::ATOM, $str)
            ?: \DateTimeImmutable::createFromFormat('Y-m-d\TH:i:s', $str)
            ?: \DateTimeImmutable::createFromFormat('Y-m-d', $str);
        if ($date !== false) {
            return $date->format(\DateTimeInterface::ATOM);
        }
        // Try bool
        if (strtolower($str) === 'true') return true;
        if (strtolower($str) === 'false') return false;

        return $str;
    }
}
```

## CreateQueryContainerList

```php
<?php

namespace App\Services;

class QueryBuilder
{
    /**
     * Build ES bool-filter query from partial document.
     * KEY INNOVATION: automatically skips empty/null fields.
     */
    public static function createQueryContainerList(mixed $document, string $prefix = ''): array
    {
        $queries = [];

        if (is_array($document) && array_is_list($document)) {
            foreach ($document as $item) {
                $queries = array_merge($queries, self::createQueryContainerList($item, $prefix));
            }
            return $queries;
        }

        if (is_array($document) || is_object($document)) {
            foreach ((array) $document as $key => $value) {
                $fieldName = $prefix !== '' ? "{$prefix}.{$key}" : $key;

                if (is_array($value) || is_object($value)) {
                    $queries = array_merge($queries, self::createQueryContainerList($value, $fieldName));
                } else {
                    // ← THE KEY: skip null and empty strings
                    if ($value !== null && $value !== '') {
                        $queryValue = is_string($value) ? "*{$value}*" : (string) $value;
                        $queries[] = ['match_phrase_prefix' => [$fieldName => $queryValue]];
                    }
                }
            }
            return $queries;
        }

        // Primitive at root
        if ($document !== null && $document !== '') {
            $queries[] = ['match_phrase_prefix' => [$prefix => (string) $document]];
        }
        return $queries;
    }
}
```

## Full CRUD API (Laravel)

```php
<?php

// routes/api.php
use App\Http\Controllers\DynamicController;

Route::middleware('auth:api')->group(function () {
    Route::post('/dynamic/{indexName}/{docId}', [DynamicController::class, 'store']);
    Route::post('/dynamic/search/{indexName}', [DynamicController::class, 'search']);
    Route::get('/dynamic/{indexName}/{docId}', [DynamicController::class, 'show']);
    Route::get('/dynamic/filters/{indexName}/{fieldName}', [DynamicController::class, 'filters']);
    Route::post('/dynamic/filters/{indexName}/{fieldName}', [DynamicController::class, 'filteredFilters']);
});
```

```php
<?php

namespace App\Http\Controllers;

use App\Services\DynamicProcessor;
use App\Services\QueryBuilder;
use Elastic\Elasticsearch\ClientBuilder;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class DynamicController extends Controller
{
    private $es;

    public function __construct()
    {
        $this->es = ClientBuilder::create()
            ->setHosts([config('services.elasticsearch.url', 'http://localhost:9200')])
            ->build();
    }

    /**
     * Store/update any document — same route pattern as .NET original.
     */
    public function store(Request $request, string $indexName, string $docId): JsonResponse
    {
        $parsed = DynamicProcessor::parseObjectAlternative($request->all());

        $this->es->index([
            'index' => $indexName,
            'id'    => $docId,
            'body'  => $parsed,
            'refresh' => 'wait_for',
        ]);

        return response()->json(['success' => true, 'id' => $docId]);
    }

    /**
     * Search with filter body — multi-tenant isolation.
     */
    public function search(Request $request, string $indexName): JsonResponse
    {
        $filters = QueryBuilder::createQueryContainerList($request->all());
        $user = auth()->user();

        // Multi-tenant: non-admins only see own data
        if (!$user->is_admin) {
            $filters[] = [
                'match_phrase_prefix' => ['userId' => "*{$user->user_id}*"]
            ];
        }

        $result = $this->es->search([
            'index' => $indexName,
            'body'  => [
                'query' => ['bool' => ['filter' => $filters]]
            ],
        ]);

        $hits = array_map(fn($hit) => array_merge(
            ['id' => $hit['_id']],
            $hit['_source']
        ), $result['hits']['hits']);

        return response()->json($hits);
    }

    /**
     * Get single document by ID.
     */
    public function show(Request $request, string $indexName, string $docId): JsonResponse
    {
        try {
            $result = $this->es->get(['index' => $indexName, 'id' => $docId]);
            return response()->json([
                'id' => $result['_id'],
                ...$result['_source']
            ]);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Not found'], 404);
        }
    }

    /**
     * Get distinct values for aggregation dropdown.
     */
    public function filters(string $indexName, string $fieldName): JsonResponse
    {
        $result = $this->es->search([
            'index' => $indexName,
            'body'  => [
                'size' => 0,
                'aggs' => [
                    'distinct' => ['terms' => ['field' => $fieldName, 'size' => 500]]
                ],
            ],
        ]);

        return response()->json(
            array_column($result['aggregations']['distinct']['buckets'], 'key')
        );
    }

    /**
     * Filtered aggregation.
     */
    public function filteredFilters(Request $request, string $indexName, string $fieldName): JsonResponse
    {
        $filters = QueryBuilder::createQueryContainerList($request->all());
        $result = $this->es->search([
            'index' => $indexName,
            'body'  => [
                'size'  => 0,
                'query' => ['bool' => ['filter' => $filters]],
                'aggs'  => [
                    'distinct' => ['terms' => ['field' => $fieldName, 'size' => 500]]
                ],
            ],
        ]);

        return response()->json(
            array_column($result['aggregations']['distinct']['buckets'], 'key')
        );
    }
}
```

## MappService (Evolution from DF_DefineEntities)

```php
<?php

namespace App\Services;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\File;

/**
 * Loads entity definitions from JSON files.
 * Evolved from original DF_DefineEntities.php MySQL-based definitions.
 *
 * Original PHP (2013): entity_id, system_name, name, type, input_type in MySQL
 * Modern PHP (2024+): JSON files in /Mapps folder, same concept, no database
 */
class MappService
{
    public function getDefinitions(): array
    {
        return Cache::rememberForever('mapps_definitions', function () {
            $definitions = [];
            foreach (File::glob(base_path('Mapps/*.json')) as $file) {
                $definitions[basename($file)] = json_decode(File::get($file), true);
            }
            return $definitions;
        });
    }
}
```

## Dependencies (composer.json)

```json
{
    "require": {
        "php": "^8.3",
        "laravel/framework": "^11.0",
        "elasticsearch/elasticsearch": "^8.15",
        "firebase/php-jwt": "^6.10"
    }
}
```

## Evolution: Original PHP → Modern PHP

| Aspect | Original (2013 WordPress) | Modern (2024 Laravel) |
|--------|--------------------------|----------------------|
| Storage | MySQL dynamic tables per entity | Elasticsearch (any JSON) |
| Definitions | df_sys_definitions MySQL table | JSON files in /Mapps |
| Forms | DF_DynamicForms PHP class | JSON-driven, client-rendered |
| Query | SQL WHERE clauses | ES bool-filter with auto-skip |
| Auth | WordPress session | JWT Bearer tokens |
| Framework | WordPress plugin | Laravel 11 |

## Genie DNA Checklist

- [x] parseObjectAlternative recursive flattening
- [x] createQueryContainerList with empty-field skip
- [x] Multi-tenant userId injection for non-admins
- [x] Same API route structure: /api/dynamic/{index}/{id}
- [x] MappService evolution from DF_DefineEntities
- [x] JWT auth middleware
- [x] Aggregation endpoints (GET + filtered POST)
- [x] elasticsearch-php v8
- [x] PHP origin story documented (came full circle!)
