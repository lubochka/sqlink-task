﻿using ExcelReader.BusinessLogic;
using ExcelReader.Converter;
using ExcelReader.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Nest;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Threading.Tasks;

namespace ExcelReader.Controllers
{   [Authorize] //REMOVE THIS TO DISABLE AUTHORIZE
    [Route("api/[controller]")]
    [ApiController]
    public class DynamicController : ControllerBase
    {
        private readonly ElasticClient _client;
        public DynamicController(ElasticClient client)
        {
            _client = client;
        }
        // GET: api/<DynamicController>
        [HttpPost("storeDocument/{index_name}/{id}")]
        public ActionResult StoreDocument(string index_name, string id, [FromBody] object document)
        {
            ActionResult response = Unauthorized();
            var currentUser = HttpContext.User;

            UserStore users = LoginController.GetStatUserByClaim(currentUser, _client);

            if (users != null)
            {
                try
                {
                    object myDocument = ObjectProcess.ParseObjectAlternative(document);
                    if (index_name == "userstore")
                    {
                        if (users.IsAdmin)
                        {
                            UserStore usr = new UserStore(document);
                            usr.Password = ProcessLogic.ComputeHash(usr.Password, new SHA256CryptoServiceProvider());
                            IndexRequest<object> request = new IndexRequest<object>(usr, index_name, id);


                            var result = _client.Index<object>(request);
                            return Ok(new { status = result.ApiCall.Success });
                        }
                        else
                        {
                            return Ok(new { status = false, error = "invalid index" });
                        }
                    }
                    else
                    {                  //  dynamic json =  JsonConvert.DeserializeObject<dynamic>(document.ToString());
                        if (index_name == "greetings" || index_name == "requests")
                        {
                            if (users.IsAdmin)
                            {
                                IndexRequest<object> request = new IndexRequest<object>(myDocument, index_name, id);


                                var result = _client.Index<object>(request);
                                return Ok(new { status = result.ApiCall.Success });
                            }
                            else
                            {
                                return Ok(new { status = false, error = "invalid index" });
                            }
                        }
                        else
                        {
                            return Ok(new { status = false, error = "invalid index"});
                        }
                    }

                    
                }
                catch (Exception ex)
                {
                    return Ok(new { status = false, error = ex.Message });
                }
            }
            return response;
        }


        [HttpGet("getFilters/{index_name}/{fieldName}")]
        public ActionResult GetFilters(string index_name, string fieldName)
        {
            ActionResult response = Unauthorized();
            var currentUser = HttpContext.User;

            UserStore users = LoginController.GetStatUserByClaim(currentUser, _client);

            if (users != null)
            {
                try
                {
                    if (index_name == "userstore" || index_name == "greetings" || index_name == "requests")
                    {
                        //  dynamic json =  JsonConvert.DeserializeObject<dynamic>(document.ToString());

                        SearchDescriptor<object> searchDescriptor = new SearchDescriptor<object>(index_name);
                        List<QueryContainer> queryContainerList = new List<QueryContainer>();
                        if (!users.IsAdmin)
                        {
                            if(index_name=="userstore")
                            {
                                return Ok(new { status = false, error = "invalid index" });
                            }
                            MatchPhrasePrefixQuery query = new MatchPhrasePrefixQuery() { Field = "userId", Query = $"*{users.UserName}*" };
                            queryContainerList.Add(query);
                        }
                       
                        searchDescriptor = searchDescriptor.Query(q => q.Bool(b => b.Filter(queryContainerList.ToArray()))).Aggregations(a => a.Terms(fieldName, f => f.Field(fieldName + ".keyword").Size(50)));




                        var result = _client.Search<object>(searchDescriptor);
                        if (result.Aggregations.Count > 0)
                        {

                            var fieldRes = result.Aggregations.Terms(fieldName);
                            Dictionary<string, long> filters = new Dictionary<string, long>();
                            foreach (var item in fieldRes.Buckets)
                            {
                                filters.Add(item.Key, item.DocCount ?? 0);
                            }

                            return Ok(new { filters });
                        }
                        else
                        {
                            return Ok(new { status = false, error = result.ServerError });
                        }
                    }
                    else
                    {
                        return Ok(new { status = false, error = "invalid index" });
                    }


                }
                catch (Exception ex)
                {
                    return Ok(new { status = false, error = ex.Message });
                }
            }
            return response;
        }


        [HttpPost("getFilters/{index_name}/{fieldName}")]
        public ActionResult GetFiltersFiltered(string index_name, string fieldName, [FromBody] object document)
        {
            ActionResult response = Unauthorized();
            var currentUser = HttpContext.User;

            UserStore users = LoginController.GetStatUserByClaim(currentUser, _client);

            if (users != null)
            {
                try
                {

                    //  dynamic json =  JsonConvert.DeserializeObject<dynamic>(document.ToString());

                    //SearchDescriptor<object> searchDescriptor = new SearchDescriptor<object>(index_name);
                    //List<QueryContainer> queryContainerList = new List<QueryContainer>();
                    //if (!users.IsAdmin)
                    //{
                    //    MatchPhrasePrefixQuery query = new MatchPhrasePrefixQuery() { Field = "userId", Query = $"*{users.UserName}*" };
                    //    queryContainerList.Add(query);
                    //}
                    //searchDescriptor = searchDescriptor.Query(q => q.Bool(b => b.Filter(queryContainerList.ToArray()))).Aggregations(a => a.Terms(fieldName, f => f.Field(fieldName + ".keyword").Size(50)));


                    if (index_name == "userstore" || index_name == "greetings" || index_name == "requests")
                    {
                        SearchDescriptor<object> searchDescriptor = new SearchDescriptor<object>(index_name);
                        List<QueryContainer> queryContainerList = new List<QueryContainer>();
                        queryContainerList = CreateQueryContainerList("", document.ToString(), queryContainerList);
                        if (!users.IsAdmin)
                        {
                            if (index_name == "userstore")
                            {
                                return Ok(new { status = false, error = "invalid index" });
                            }
                            MatchPhrasePrefixQuery query = new MatchPhrasePrefixQuery() { Field = "userId", Query = $"*{users.UserName}*" };
                            queryContainerList.Add(query);
                        }
                       
                        searchDescriptor = searchDescriptor.Query(q => q.Bool(b => b.Filter(queryContainerList.ToArray()))).Aggregations(a => a.Terms(fieldName, f => f.Field(fieldName + ".keyword").Size(255)));
                        ISearchResponse<object> responseInternal = _client.Search<object>(searchDescriptor);


                        var result = _client.Search<object>(searchDescriptor);
                        if (result.Aggregations.Count > 0)
                        {

                            var fieldRes = result.Aggregations.Terms(fieldName);
                            Dictionary<string, long> filters = new Dictionary<string, long>();
                            foreach (var item in fieldRes.Buckets)
                            {
                                filters.Add(item.Key, item.DocCount ?? 0);
                            }

                            return Ok(new { filters });
                        }
                        else
                        {
                            return Ok(new { status = false, error = result.ServerError });
                        }

                    }
                    else
                    {
                        return Ok(new { status = "invalid index name" });
                    }
                }
                catch (Exception ex)
                {
                    return Ok(new { status = false, error = ex.Message });
                }
            }
            return response;
        }

        [HttpPost("searchDocuments/{index_name}")]
        public ActionResult GetDocuments(string index_name, [FromBody] object document)
        {
            ActionResult response = Unauthorized();
            var currentUser = HttpContext.User;

            UserStore users = LoginController.GetStatUserByClaim(currentUser, _client);

            if (users != null)
            {

                if (index_name == "userstore" || index_name == "greetings" || index_name == "requests")
                {
                    QueryContainer queryContainer = new QueryContainer();

                    SearchDescriptor<object> searchDescriptor = new SearchDescriptor<object>(index_name);
                    List<QueryContainer> queryContainerList = new List<QueryContainer>();
                    queryContainerList = CreateQueryContainerList("", document.ToString(), queryContainerList);
                    if (!users.IsAdmin)
                    {
                        if (index_name == "userstore")
                        {
                            return Ok(new { status = false, error = "invalid index" });
                        }
                        if (index_name == "greetings")
                        {
                            MatchPhrasePrefixQuery query = new MatchPhrasePrefixQuery() { Field = "UserId", Query = $"*{users.UserName}*" };
                            queryContainerList.Add(query);
                        }
                        else
                        {
                            MatchPhrasePrefixQuery query = new MatchPhrasePrefixQuery() { Field = "userId", Query = $"*{users.UserName}*" };
                            queryContainerList.Add(query);
                        }
                    }
                   
                    searchDescriptor = searchDescriptor.Query(q => q.Bool(b => b.Filter(queryContainerList.ToArray()))).Size(255);
                    if(index_name=="requests")
                    {
                       
                        
                            searchDescriptor.Sort(so => so.Field("submission date date", SortOrder.Descending));
                    }
                    ISearchResponse<object> responseInternal = _client.Search<object>(searchDescriptor);
                    if (responseInternal.Hits.Count > 0)
                    {
                        return Ok(responseInternal.Hits.Select(a => a.Source).ToList());
                    }
                    else
                    {
                        return Ok(new { status = "no results" });
                    }
                }
                else
                {
                    return Ok(new { status = "invalid index name" });
                }
            }
            return response;
        }


        [HttpPost("getExcel/{index_name}")]
        public ActionResult GetExcel(string index_name, [FromBody] object document)
        {
            ActionResult response = Unauthorized();
            var currentUser = HttpContext.User;

            UserStore users = LoginController.GetStatUserByClaim(currentUser, _client);

            if (users != null)
            {
                if (index_name == "userstore" || index_name == "greetings" || index_name == "requests")
                {
                    QueryContainer queryContainer = new QueryContainer();

                    SearchDescriptor<object> searchDescriptor = new SearchDescriptor<object>(index_name);
                    List<QueryContainer> queryContainerList = new List<QueryContainer>();
                    queryContainerList = CreateQueryContainerList("", document.ToString(), queryContainerList);
                    if (!users.IsAdmin)
                    {
                        if (index_name == "userstore")
                        {
                            return Ok(new { status = false, error = "invalid index" });
                        }
                        MatchPhrasePrefixQuery query = new MatchPhrasePrefixQuery() { Field = "userId", Query = $"*{users.UserName}*" };
                        queryContainerList.Add(query);
                    }
                    searchDescriptor = searchDescriptor.Query(q => q.Bool(b => b.Filter(queryContainerList.ToArray()))).Size(255);
                    ISearchResponse<object> responseInternal = _client.Search<object>(searchDescriptor);
                    if (responseInternal.Hits.Count > 0)
                    {
                        List<object> responseObjects = responseInternal.Hits.Select(a => a.Source).ToList();

                        List<Dictionary<string, string>> rows = new List<Dictionary<string, string>>();

                        foreach (object obj in responseObjects)
                        {
                            rows.Add(ObjectProcess.ParseElasticResult(obj));
                        }


                        if (rows.Count > 0)
                        {
                            int Column = 1, Row = 1;
                            List<CellExport> cells = new List<CellExport>();
                            foreach (var key in rows[0].Keys)
                            {
                                cells.Add(new CellExport() { column = Column, row = Row, value = key });
                                Column++;
                            }

                            Row = 2;
                            foreach (var row in rows)
                            {
                                Column = 1;
                                foreach (var key in row.Keys)
                                {
                                    cells.Add(new CellExport() { column = Column, row = Row, value = row[key] });
                                    Column++;
                                }
                                Row++;
                            }
                            var file = JsonToExcelConverter.JsonToExcelByte(cells);
                            return File(file, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "data.xlsx");
                        }
                        else
                        {
                            return Ok(new { status = "no results" });
                        }
                    }
                    else
                    {
                        return Ok(new { status = "no results" });
                    }
                }
                else
                {
                    return Ok(new { status = "invalid index" });
                }
            }
            return response;
        }

        public List<QueryContainer> CreateQueryContainerList(string prefix, string Document, List<QueryContainer> qlist)
        {
            var result = qlist;
            if (Document.IndexOf("[") == 0)
            {
                var results = new List<object>();
                var documents = System.Text.Json.JsonSerializer.Deserialize<object[]>(Document);
                for (var i = 0; i < documents.Length; i++)
                {
                    result = CreateQueryContainerList(prefix, documents[i].ToString(), result);
                }
                return result;
            }
            else
            {
                if (Document.IndexOf("{") == 0)
                {
                    Dictionary<string, object> myObject = new Dictionary<string, object>();
                    dynamic stuff = JObject.Parse(Document.ToString());
                    foreach (Newtonsoft.Json.Linq.JProperty jproperty in stuff)
                    {
                        if (jproperty.Value.ToString().IndexOf("[") >= 0 || jproperty.Value.ToString().IndexOf("{") >= 0)
                        {

                            var newPrefix = prefix + jproperty.Name;
                            if (prefix != "")
                            {
                                newPrefix = prefix + "." + jproperty.Name;
                            }
                            result = CreateQueryContainerList(newPrefix, jproperty.Value.ToString(), result);

                        }
                        else
                        {
                            var newPrefix = prefix + jproperty.Name;
                            if (prefix != "")
                            {
                                newPrefix = prefix + "." + jproperty.Name;
                            }
                            var value = jproperty.Value.ToString();
                            if (jproperty.Value.Type == JTokenType.String)
                            {
                                if (value != "")
                                {
                                   
                                    MatchPhrasePrefixQuery queryM = new MatchPhrasePrefixQuery() { Field = newPrefix, Query = $"*{value}*" };
                                    result.Add(queryM);
                                }
                                
                            }
                            else
                            {

                                if (value != "")
                                {
                                 
                                    MatchPhrasePrefixQuery queryM = new MatchPhrasePrefixQuery() { Field = newPrefix, Query = $"{value}" };
                                   
                                    result.Add(queryM);
                                }
                            }
                        }
                    }
                    return result;
                }
                else
                {
                    if (Document != "")
                    {
                        MatchPhrasePrefixQuery queryM = new MatchPhrasePrefixQuery() { Field = prefix, Query = $"{Document}" };
                        result.Add(queryM);
                    }
                    
                   
                    return result;
                }
            }
        }

   

        [HttpGet("getDocument/{index_name}/{id}")]
        public ActionResult GetDocument(string index_name, string id)
        {
            ActionResult response = Unauthorized();
            var currentUser = HttpContext.User;

            UserStore users = LoginController.GetStatUserByClaim(currentUser, _client);

            if (users != null)
            {
                QueryContainer queryContainer = new QueryContainer();
                SearchDescriptor<object> searchDescriptor = new SearchDescriptor<object>(index_name).Query(q =>
                q.Match(a => a.Field("_id").Query(id)));

                // SearchDescriptor<object> searchDescriptor = new SearchDescriptor<object>(index_name).QueryOnQueryString("{'query':{'match':{'_id':'" + id + "'}}}");
                ISearchResponse<object> responseInternal = _client.Search<object>(searchDescriptor);
                if (responseInternal.Hits.Count > 0)
                {
                    return Ok(responseInternal.Hits.Where(a => true).FirstOrDefault().Source);
                }
                else
                {
                    return Ok(new { status = "no results" });
                }
            }
            return response;
        }

       
    }
}
