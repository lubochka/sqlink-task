﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;


namespace ExcelReader.BusinessLogic
{
    public class ObjectValue
    {
        public string value;
        public Dictionary<string, ObjectValue> values;
        public List<ObjectValue> kids;
    }

    public class ObjectProcess
    {
        public static object ParseObjectAlternative(object Document)
        {
            if (Document.ToString().IndexOf("[") == 0)
            {
                var results = new List<object>();
                var documents = System.Text.Json.JsonSerializer.Deserialize<object[]>(Document.ToString());
                for (var i = 0; i < documents.Length; i++)
                {
                    results.Add(ParseObjectAlternative(documents[i]));
                }
                return results.ToArray();
            }
            else
            {
                if (Document.ToString().IndexOf("{") == 0)
                {
                    Dictionary<string, object> myObject = new Dictionary<string, object>();
                    dynamic stuff = JObject.Parse(Document.ToString());
                    foreach (Newtonsoft.Json.Linq.JProperty jproperty in stuff)
                    {
                        if (jproperty.Value.ToString().IndexOf("[") >= 0 || jproperty.Value.ToString().IndexOf("{") >= 0)
                        {
                            myObject[jproperty.Name] = ParseObjectAlternative(jproperty.Value);
                        }
                        else
                        {
                            myObject[jproperty.Name] = ParseJpropertyObject(jproperty);
                        }
                    }
                    return myObject;
                }
                else
                {

                    return ParseSimpleObject(Document);
                }
            }
        }


        public static ObjectValue ParseObjectAlternativeObjectValue(object Document)
        {
            var resultObj = new ObjectValue();
            if (Document.ToString().IndexOf("[") == 0)
            {
                var results = new List<ObjectValue>();
                var documents = System.Text.Json.JsonSerializer.Deserialize<object[]>(Document.ToString());
                for (var i = 0; i < documents.Length; i++)
                {
                    results.Add(ParseObjectAlternativeObjectValue(documents[i]));
                }
                resultObj.kids = results.ToList();
            }
            else
            {
                if (Document.ToString().IndexOf("{") == 0)
                {
                    Dictionary<string, object> myObject = new Dictionary<string, object>();
                    dynamic stuff = JObject.Parse(Document.ToString());
                    foreach (Newtonsoft.Json.Linq.JProperty jproperty in stuff)
                    {
                        if (jproperty.Value.ToString().IndexOf("[") >= 0 || jproperty.Value.ToString().IndexOf("{") >= 0)
                        {
                            resultObj.values[jproperty.Name] = ParseObjectAlternativeObjectValue(jproperty.Value);
                        }
                        else
                        {
                            resultObj.values[jproperty.Name] = ParseObjectAlternativeObjectValue(jproperty);
                        }
                    }

                }
                else
                {

                    resultObj.value = ParseSimpleObject(Document).ToString();
                }
            }
            return resultObj;
        }



        public static Dictionary<string, string> ParseElasticResult(object elasticRow)
        {
            var res = new Dictionary<string, string>();
            var work = ((Dictionary<string, object>)elasticRow);

            foreach(var key in work.Keys )
            {
                res[key] = work[key].ToString();
            }
            return res;


        }


        public static object ParseJpropertyObject(JProperty jproperty)
        {
            switch (jproperty.Value.Type)
            {
                case JTokenType.String:
                    return jproperty.Value.ToString();
                case JTokenType.Date:
                    return DateTime.Parse(jproperty.Value.ToString());
                case JTokenType.Boolean:
                    return bool.Parse(jproperty.Value.ToString());
                case JTokenType.Float:
                    return float.Parse(jproperty.Value.ToString());
                case JTokenType.Integer:
                    return int.Parse(jproperty.Value.ToString());
                case JTokenType.Guid:
                    return Guid.Parse(jproperty.Value.ToString());



            }
            return jproperty.Value.ToString();
        }

        public static object ParseSimpleObject(object Document)
        {

            var value = Document.ToString();
            try
            {
                var res = int.Parse(value);

                return res;
            }
            catch (Exception ex2)
            {
                try
                {
                    var res = decimal.Parse(value);
                    return res;
                }
                catch (Exception ex3)
                {

                    try
                    {
                        var res = DateTime.Parse(value);
                        return res;
                    }
                    catch (Exception ex4)
                    {
                        try
                        {
                            var res = bool.Parse(value);
                            return res;

                        }
                        catch (Exception ex5)
                        {
                            return value;
                        }
                    }

                }
            }

        }

        public static object ParseObject(object Document)
        {
            try
            {
                var result = System.Text.Json.JsonSerializer.Deserialize<Dictionary<string, string>>(Document.ToString());
                return result;
            }
            catch (Exception ex)
            {
                if (Document.ToString().Contains("{"))
                {
                    try
                    {
                        var result = new Dictionary<string, object>();
                        var workingDoc = System.Text.Json.JsonSerializer.Deserialize<Dictionary<string, object>>(Document.ToString());
                        var workingKeys = workingDoc.Keys.Where(a => true).ToList();
                        foreach (var key in workingKeys)
                        {
                            result[key] = ParseObject(workingDoc[key]);
                        }
                        return result;



                    }
                    catch (Exception exarr)
                    {

                        try
                        {
                            var results = new Dictionary<string, object[]>();
                            var workingDoc = System.Text.Json.JsonSerializer.Deserialize<Dictionary<string, object[]>>(Document.ToString());

                            var workingKeys = workingDoc.Keys.Where(a => true).ToList();
                            foreach (var key in workingKeys)
                            {

                                var temp = new List<object>();
                                for (var i = 0; i < workingDoc[key].Length; i++)
                                {
                                    temp.Add(ParseObject(workingDoc[key][i]));
                                }
                                results[key] = temp.ToArray();


                            }

                            return results;
                        }
                        catch (Exception exarr2)
                        {
                            var result = new Dictionary<string, object>();
                            var workingDocs = System.Text.Json.JsonSerializer.Deserialize<object[]>(Document.ToString());
                            var key = "controls";
                            var temp = new List<object>();
                            for (var ind = 0; ind < workingDocs.Length; ind++)
                            {
                                temp.Add(ParseObject(workingDocs[ind]));
                            }
                            return temp.ToArray();


                        }
                    }
                }
                else
                {
                    return ParseSimpleObject(Document);

                }
            }
        }

    }
}
