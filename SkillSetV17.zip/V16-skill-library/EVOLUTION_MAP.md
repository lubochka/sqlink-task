# Genie Platform — Evolution & Dependency Map

## The Big Picture: How 8 Projects Connect

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        ORIGIN STORY (Generation 0)                      │
│                                                                         │
│   WordPress Dynamic Plugin (PHP/MySQL/jQuery)                           │
│   ├── DF_DefineEntities.php  → Define "entities" (data types)           │
│   ├── DF_DataBase.php        → Create tables dynamically per entity     │
│   ├── DF_DynamicForms.php    → Render forms from entity definitions     │
│   └── DF_MakeActions.js      → Client-side CRUD via AJAX               │
│                                                                         │
│   KEY INSIGHT: Any data type can be defined at runtime, forms are       │
│   generated from definitions, not hardcoded. This DNA persists in       │
│   every later project.                                                  │
└──────────────────────────────┬──────────────────────────────────────────┘
                               │ evolved to
┌──────────────────────────────▼──────────────────────────────────────────┐
│                     GENERATION 1: Dynamic Platform                       │
│                                                                         │
│   Same concept, modern stack: PHP→.NET, MySQL→Elasticsearch,            │
│   jQuery→React, hardcoded entities→schema-free JSON                     │
│                                                                         │
│   ┌─────────────────────────────────────────────────────┐               │
│   │  GenieDynamicServer (.NET Core 3.1 + Elasticsearch)  │               │
│   │  ├── ParseObjectAlternative → replaced DF_DataBase   │               │
│   │  ├── CreateQueryContainerList → replaced SQL queries  │               │
│   │  ├── MappService → replaced DF_DefineEntities        │               │
│   │  ├── Azure Blob → file storage                       │               │
│   │  ├── SignalR → real-time push                        │               │
│   │  └── JWT auth → session management                   │               │
│   └──────────────────────┬──────────┬──────────┬────────┘               │
│                          │          │          │                         │
│                  ┌───────▼───┐  ┌───▼──────┐  ┌▼──────────────┐         │
│                  │DynamicApp │  │ Mobile   │  │ReactTableDyn  │         │
│                  │(React 17) │  │(RN 0.64) │  │(React 17)     │         │
│                  │           │  │          │  │               │         │
│                  │Same Redux │  │Same API  │  │Fork of        │         │
│                  │Same i18n  │  │Context+  │  │DynamicApp     │         │
│                  │Same filter│  │Redux     │  │+dropdown ext  │         │
│                  └───────────┘  └──────────┘  └───────────────┘         │
└─────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────┐
│                  GENERATION 1B: Gamification Platform                    │
│                                                                         │
│  Parallel development using same auth and dynamic doc patterns          │
│                                                                         │
│   ┌──────────────────────────────────────────┐                          │
│   │  WizGameServer (.NET Core 3.1 + EF Core)  │                          │
│   │  ├── EF Core (SQL Server) for game models  │                          │
│   │  ├── Elasticsearch for dynamic queries     │                          │
│   │  ├── Shared: JWT auth, ParseObject*        │                          │
│   │  ├── Unique: GameHelpers state machine     │                          │
│   │  └── Unique: DataBase.cs dynamic SQL       │                          │
│   └──────────────────────┬───────────────────┘                          │
│                          │                                              │
│                  ┌───────▼──────────┐                                   │
│                  │  GenieGameMVP    │                                   │
│                  │  (Angular 10)    │                                   │
│                  │                  │                                   │
│                  │  ECharts graphs  │                                   │
│                  │  Material UI     │                                   │
│                  │  i18n HE/EN     │                                   │
│                  │  Dynamic forms   │                                   │
│                  └──────────────────┘                                   │
└─────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────┐
│                  GENERATION 0.5: Legacy Task Management                  │
│                                                                         │
│  Built between Plugin and DynamicServer. Uses older patterns but        │
│  shares JWT auth concept and multi-tenant (MainUserId) approach.        │
│                                                                         │
│   ┌──────────────────────────────────────────┐                          │
│   │  GenieTasks (ASP.NET 4.6 + EF6 + SQL)    │                          │
│   │  ├── Breeze.js for OData-like queries     │                          │
│   │  ├── EF6 with fixed models (not dynamic)  │                          │
│   │  ├── JWT auth (custom JwtManager.cs)       │                          │
│   │  ├── Azure Blob for attachments            │                          │
│   │  ├── Multi-tenant via MainUserId           │                          │
│   │  └── Frontend: AngularJS 1.x              │                          │
│   └──────────────────────────────────────────┘                          │
└─────────────────────────────────────────────────────────────────────────┘
```

## Shared Pattern Matrix

| Pattern | Plugin (PHP) | Tasks (.NET 4.6) | DynServer (.NET Core) | WizGame (.NET Core) | DynApp (React) | Mobile (RN) | GameMVP (Angular) | ReactTable (React) |
|---------|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| Dynamic entity definitions | ✅ via DB tables | ❌ fixed EF models | ✅ JSON mappings | ⚠️ partial (ES only) | ✅ reads from server | ✅ reads from server | ✅ dynamic forms | ✅ same as DynApp |
| Schema-free storage | ❌ dynamic MySQL tables | ❌ SQL Server fixed | ✅ Elasticsearch | ✅ ES + SQL Server | — | — | — | — |
| JWT authentication | ❌ PHP sessions | ✅ custom JwtManager | ✅ ASP.NET JWT | ✅ same pattern | ✅ Redux token | ✅ AsyncStorage token | ✅ HTTP interceptor | ✅ same as DynApp |
| Dynamic query building | ❌ raw SQL | ✅ Breeze.js OData | ✅ CreateQueryContainerList | ✅ same + dynamic SQL | ✅ filterBody.js | ✅ same filter pattern | ✅ via board.service | ✅ same as DynApp |
| i18n (HE/EN) | ❌ basic translate() | ❌ none | ❌ backend only | ❌ backend only | ✅ i18next | ✅ StringsOfLanguages | ✅ ngx-translate | ✅ same as DynApp |
| Real-time push | ❌ none | ❌ none | ✅ SignalR | ❌ none | ✅ SignalR client | ✅ local notifications | ❌ polling | ✅ same as DynApp |
| File handling | ❌ WP uploads | ✅ Azure Blob | ✅ Azure Blob + OCR | ❌ none | ✅ upload UI | ✅ upload UI | ❌ none | ✅ same as DynApp |
| Multi-tenant | ❌ single-tenant | ✅ MainUserId | ✅ claims-based | ✅ per-game isolation | — | — | — | — |
| State machine | ❌ none | ✅ task stages | ❌ none | ✅ GameHelpers | ❌ none | ❌ none | ✅ board states | ❌ none |

## Communication Flow

```
DynamicApp ─── HTTP+SignalR ──→ GenieDynamicServer ──→ Elasticsearch
                                                   ──→ Azure Blob Storage
Mobile     ─── HTTP ──────────→ GenieDynamicServer ──→ (same)

GameMVP    ─── HTTP ──────────→ WizGameServer ─────→ SQL Server (EF Core)
                                               ────→ Elasticsearch (NEST)

Tasks UI   ─── Breeze.js ────→ GenieTasks Server ──→ SQL Server (EF6)
                                                  ──→ Azure Blob

ReactTable ─── HTTP+SignalR ──→ GenieDynamicServer ──→ (same as DynamicApp)
```

## Key API Endpoints per Backend

### GenieDynamicServer (used by DynamicApp, Mobile, ReactTable)
- `POST /api/Dynamic/storeDocument/{index}/{id}` — Create/update any doc
- `POST /api/Dynamic/searchDocuments/{index}` — Search with filter body
- `POST /api/Dynamic/getFilters/{index}/{field}` — Get distinct values
- `POST /api/Login` — JWT authentication
- `POST /api/Files/upload` — Azure Blob upload
- `GET /api/Files/download/{id}` — Download file
- Hub: `/pushNotification` — SignalR real-time

### WizGameServer (used by GenieGameMVP)
- `GET /api/Board/...` — Board state, cards, subjects
- `POST /api/Board/MakeAction/{gameId}` — Execute game action
- `GET /api/Tournirs/...` — Tournament management
- `POST /api/Login` — JWT auth (same pattern)
- `GET /api/Data/GetDynamic?sql=...` — Dynamic SQL queries
- `POST /api/Dynamic/Store/{index}/{id}` — ES dynamic docs

### GenieTasks (used by Tasks AngularJS UI)
- `GET /breeze/a1/Metadata` — Breeze metadata endpoint
- `POST /breeze/a1/SaveChanges` — Breeze batch save
- `GET /breeze/a1/Tasks`, `/Jobs`, `/Clients`, `/Members` — Entity queries
- `POST /breeze/a1/Login` — JWT auth

## Technology Timeline

```
2013-2015  WordPress Plugin (PHP 5.x, MySQL, jQuery)
    │       └── "Dynamic Forms" concept proven
    │
2018-2019  GenieTasks (ASP.NET 4.6, EF6, AngularJS 1.x)
    │       └── Added JWT auth, Azure Blob, multi-tenant
    │
2020-2021  GenieDynamicServer (.NET Core 3.1, Elasticsearch)
    │       └── Schema-free evolution: MySQL tables → ES documents
    │       └── ParseObjectAlternative replaces entity definitions
    │
2020-2021  GenieDynamicApp (React 17, Redux)
    │       └── filterBody.js pattern established
    │
2021       GenieDynamicMobile (React Native 0.64)
    │       └── Same patterns adapted for iOS
    │
2021       ReactTableDynamic (React 17, fork of DynamicApp)
    │       └── Added dropdown enhancements
    │
2020-2021  WizGameServer (.NET Core 3.1, EF Core + Elasticsearch)
    │       └── Dual storage: SQL for models, ES for dynamic data
    │
2020-2021  GenieGameMVP (Angular 10)
            └── Gamification UI with ECharts, dynamic forms
```
