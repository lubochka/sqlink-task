# Genie Platform — Unified AI Skill Library V6
## The Complete Guide to 8 Projects, 5 Server Stacks, 3 Client Stacks

---

## 30-Second Orientation

You're looking at the **Genie Platform Skill Library** — a structured documentation set that any AI coding assistant or human developer can use to understand, build, extend, and maintain the Genie ecosystem.

**What's inside:**
- **5 cross-cutting skills** × 8 stack alternatives = 45 implementation files
- **4 backend + 5 frontend** project-specific skills
- **8 integration recipes** — full-stack wiring per stack combination
- **4 use-case templates** — organized by what you're building (CRM, gamification, tasks, headless API)
- **5 AI tool configs** — pre-built configurations for Cursor, Claude Code, Claude AI, Copilot, Cline
- **14 design patterns** mapped to real Genie code
- **6 ML simulation blueprints** for adding intelligence
- **28,500+ lines** of documentation across **128 files**

---

## The Core Philosophy

> **"Free business users from depending on developers."**

Every design decision follows one rule: if a business user might want to define, change, or extend something — it MUST be dynamic. Only the machine that enables that freedom is static.

This means: no fixed database models for business data. No per-entity REST endpoints. No hardcoded field lists. Everything flows through a generic dynamic document pipeline that stores, queries, and renders schema-free JSON documents.

Read `DECISION_GUIDE.md` for the full philosophy.

---

## Skill-by-Skill Summary: When & Why

| # | Skill | WHEN to Use | WHY This Approach | What Goes Wrong Without It |
|---|-------|-------------|-------------------|---------------------------|
| 1 | **dynamic-documents** | Any business entity that users define, change, or extend at runtime | Schema-free = zero migrations, zero dev bottleneck. New entity types in minutes, not sprints | Fixed schemas → every new entity needs DB migration + model + endpoint + form = weeks |
| 2 | **auth-jwt** | Any multi-tenant system with role-based access control | Stateless JWT scales horizontally across pods. Claims carry identity without server sessions | Session-based auth → sticky sessions, can't scale, single point of failure |
| 3 | **i18n-multilingual** | Any app serving Hebrew + English (or more languages) | RTL/LTR built into architecture from day one. Adding a language = adding a JSON file | Bolted-on i18n → broken layouts, inconsistent translations, RTL as afterthought |
| 4 | **realtime-push** | Any feature needing instant updates — chat, notifications, live tables, dashboards | WebSocket reduces server load 12×. Auto-reconnection built into the pattern | Polling every 5s → massive server load, stale data, poor user experience |
| 5 | **cloud-infrastructure** | Any deployment beyond localhost — staging, production, multi-region | Abstracted provider interfaces = swap Azure↔AWS↔GCP without changing application code | Hardcoded cloud SDK calls → vendor lock-in, expensive migration when requirements change |

---

## Reading Order by Persona

### 🆕 "I'm new — show me the architecture"
1. **This file** (README-UNIFIED.md) — you're here
2. `DECISION_GUIDE.md` — the philosophy: when dynamic vs static
3. `EVOLUTION_MAP.md` — how 8 projects connect, generation by generation
4. `PATTERNS_IN_GENIE_DNA.md` — 14 GoF design patterns mapped to real code
5. `MASTER_PLAN.md` — what the library contains and how it was built

### 🔧 "I need to build a new microservice in [stack]"
1. `templates/use-cases/{your-use-case}.md` — understand what you're building and which entities
2. `templates/servers/{your-stack}` + `templates/clients/{your-variant}` — copy boilerplate
3. `skills/recipes/{your-stack-combo}.md` — full wiring guide showing how all 5 skills connect
4. `skills/cross-cutting/*/SKILL.md` — understand each pattern
5. `skills/cross-cutting/*/alternatives/{your-stack}.md` — idiomatic implementation for your stack

### 🔄 "I'm migrating from one stack to another"
1. `MIGRATION_PATHS.md` — step-by-step migration guides
2. Compare side-by-side: `alternatives/{old-stack}.md` vs `alternatives/{new-stack}.md` (per skill)
3. `skills/recipes/{new-stack-combo}.md` — target architecture wiring
4. `templates/servers/{new-stack}` — new server boilerplate

### 🤖 "I'm an AI tool being set up for this project"
1. `ai-tool-configs/{your-config-file}` — your specific instructions with decision routing
2. `RAG_INDEX.md` — quick pattern lookup table
3. `DECISION_GUIDE.md` — decision framework for dynamic vs static
4. `STACK_COMPARISON.md` — when user specifies a stack

### 📱 "I'm building a mobile app"
1. `skills/frontends/genie-dynamic-mobile/SKILL.md` — existing React Native patterns
2. `skills/cross-cutting/*/alternatives/react-native.md` — all 5 skills in React Native
3. `skills/recipes/nodejs-react-native.md` — full-stack wiring with Node.js backend
4. `templates/servers/nodejs.mjs` + `templates/clients/react-native.tsx` — copy-paste starter

### 🎮 "I'm building a gamification feature"
1. `skills/backends/wiz-game-server/SKILL.md` — game logic patterns (State pattern)
2. `skills/frontends/genie-game-mvp/SKILL.md` — Angular game frontend
3. `templates/use-cases/gamification.md` — game-specific entity guide and pattern map
4. `PATTERNS_IN_GENIE_DNA.md` → State pattern section

### 🧠 "I want to add ML/AI intelligence"
1. `skills/patterns-and-decisions/ML_SIMULATIONS.md` — 6 algorithm blueprints
2. `skills/patterns-and-decisions/PLATFORM_SCALE.md` — how patterns scale
3. `skills/patterns-and-decisions/AI_GENERATION_PROMPTS.md` — meta-prompts for AI code gen

---

## Complete File Map

### Root Documents (11)
| File | Purpose | Read When |
|------|---------|-----------|
| `README-UNIFIED.md` | **This file** — master entry point | First time, navigation |
| `DECISION_GUIDE.md` | Philosophy: dynamic vs static, the one rule | Understanding WHY |
| `STACK_COMPARISON.md` | Per-stack deep dive (8 stacks compared) | Choosing a stack |
| `EVOLUTION_MAP.md` | How 8 projects connect across generations | Understanding history |
| `MASTER_PLAN.md` | What was built and how | Library overview |
| `RAG_INDEX.md` | Quick pattern → file lookup | Fast reference |
| `EXECUTION_PLAN_V4.md` | Original build plan for the library | Build process reference |
| `STATE.md` | Phase completion tracking | Recovery / status |
| `MIGRATION_PATHS.md` | Stack-to-stack migration guides | Switching stacks |
| `VALIDATION_REPORT.md` | Cross-reference verification results | Quality assurance |
| `README-AI.md` | Original AI entry point (kept for compatibility) | Legacy reference |

### Cross-Cutting Skills (5 skills × 9 files + 4 references = 49 files)
Each skill has: `SKILL.md` + 8 alternatives (dotnet-modern, nodejs, python, rust, php, angular, react-modern, react-native)

| Skill | Directory | Core Pattern | Reference Files |
|-------|-----------|-------------|-----------------|
| **dynamic-documents** | `skills/cross-cutting/dynamic-documents/` | ParseObjectAlternative, CreateQueryContainerList | `object-process-full.md`, `dynamic-controller-full.md` |
| **auth-jwt** | `skills/cross-cutting/auth-jwt/` | JWT generation, middleware, claims | `login-controller-full.md`, `startup-jwt-config.md` |
| **i18n-multilingual** | `skills/cross-cutting/i18n-multilingual/` | Translations, RTL/LTR, hebrew convention | — |
| **realtime-push** | `skills/cross-cutting/realtime-push/` | SignalR/WebSocket, /push, ReceiceMessage | — |
| **cloud-infrastructure** | `skills/cross-cutting/cloud-infrastructure/` | Azure Blob, Elasticsearch, deployment | — |

### Backend Project Skills (4 files)
| Project | File | Stack | Key Patterns |
|---------|------|-------|-------------|
| GenieDynamicServer | `skills/backends/genie-dynamic-server/SKILL.md` | .NET Core + ES | Facade, Builder, Strategy, Singleton |
| WizGameServer | `skills/backends/wiz-game-server/SKILL.md` | .NET Core + EF + ES | State, Factory, dual-storage |
| GenieTasksServer | `skills/backends/genie-tasks-server/SKILL.md` | ASP.NET 4.6 + EF | Legacy Breeze.js, EF migrations |
| GenieDynamicPlugin | `skills/backends/genie-dynamic-plugin/SKILL.md` | PHP + WordPress | Gen 0 origin, df_sys_definitions |

### Frontend Project Skills (5 files)
| Project | File | Stack | Key Patterns |
|---------|------|-------|-------------|
| GenieDynamicApp | `skills/frontends/genie-dynamic-app/SKILL.md` | React 17 + Redux | Command, Observer, filterBody |
| GenieDynamicMobile | `skills/frontends/genie-dynamic-mobile/SKILL.md` | React Native 0.64 | Navigator, AsyncStorage, push |
| GenieGameMVP | `skills/frontends/genie-game-mvp/SKILL.md` | Angular 10 + Material | State, i18n HE/EN, ECharts |
| GenieReactTable | `skills/frontends/genie-react-table/SKILL.md` | React 17 + Redux | Dynamic columns, dropdown CRUD |
| GenieTasksFrontend | `skills/frontends/genie-tasks-frontend/SKILL.md` | AngularJS 1.x + Breeze | Legacy, two-way binding |

### Patterns & Decisions (4 files)
| File | Purpose |
|------|---------|
| `PATTERNS_IN_GENIE_DNA.md` | 14 GoF design patterns mapped to actual Genie code with simulations |
| `ML_SIMULATIONS.md` | 6 ML algorithm blueprints (Naive Bayes, Linear Regression, Q-Learning, K-Means, NN, Apriori) |
| `PLATFORM_SCALE.md` | How each pattern evolves from Gen 1 → Database Fabric → XIIGen |
| `AI_GENERATION_PROMPTS.md` | Meta-prompts for teaching AI tools the Genie thinking framework |

### Integration Recipes (8 files)
| Recipe | Server | Client | File |
|--------|--------|--------|------|
| .NET + React | .NET 9 Minimal API | React 19 + RTK | `skills/recipes/dotnet-react.md` |
| .NET + Angular | .NET 9 | Angular 17+ | `skills/recipes/dotnet-angular.md` |
| Node.js + React | Fastify | React 19 + RTK | `skills/recipes/nodejs-react.md` |
| Node.js + Angular | Fastify | Angular 17+ | `skills/recipes/nodejs-angular.md` |
| Node.js + React Native | Fastify | RN + Expo | `skills/recipes/nodejs-react-native.md` |
| Python + React | FastAPI | React 19 + RTK | `skills/recipes/python-react.md` |
| Rust + Angular | Axum | Angular 17+ | `skills/recipes/rust-angular.md` |
| PHP + React | Laravel 11 | React 19 + RTK | `skills/recipes/php-react.md` |

### Quick-Start Templates (18 files)
Organized usage-first: understand WHAT you're building, then pick HOW.

| Directory | Contents | Purpose |
|-----------|----------|---------|
| `templates/use-cases/` | 4 `.md` guides | Dynamic CRM, Gamification, Task Management, Headless API — entities, patterns, deeper skill refs |
| `templates/servers/` | 5 server files | `dotnet.cs`, `nodejs.mjs`, `python.py`, `rust.rs`, `php.php` — all implement identical Genie DNA |
| `templates/clients/` | 5 client files | `react-signalr.tsx`, `react-websocket.tsx`, `angular-signalr.ts`, `angular-websocket.ts`, `react-native.tsx` |
| `templates/infra/` | 2 infra files | `docker-compose.yml` + `env.example` — Elasticsearch + Redis |

### AI Tool Configurations (5 files)
| File | For Tool | Location |
|------|----------|----------|
| `.cursorrules` | Cursor IDE | `ai-tool-configs/.cursorrules` → copy to project root |
| `CLAUDE.md` | Claude Code | `ai-tool-configs/CLAUDE.md` → copy to project root |
| `copilot-instructions.md` | GitHub Copilot | `ai-tool-configs/copilot-instructions.md` → copy to `.github/` |
| `claude-project-instructions.md` | Claude AI Projects | `ai-tool-configs/claude-project-instructions.md` → paste into Project |
| `.clinerules` | Cline | `ai-tool-configs/.clinerules` → copy to project root |

All configs include: decision routing tables, pattern recognition triggers, when/why per skill, ML awareness, template awareness, stack-specific reading orders.

---

## The 8 Supported Stack Combinations

| # | Server | Client | Best For | Recipe | Template Files |
|---|--------|--------|----------|--------|---------------|
| 1 | **.NET 9** (Minimal API) | **React 19** (RTK) | Enterprise, existing .NET teams | `dotnet-react.md` | `servers/dotnet.cs` + `clients/react-signalr.tsx` |
| 2 | **.NET 9** | **Angular 17+** | Enterprise Angular shops | `dotnet-angular.md` | `servers/dotnet.cs` + `clients/angular-signalr.ts` |
| 3 | **Node.js** (Fastify) | **React 19** (RTK) | Startups, JS-only teams | `nodejs-react.md` | `servers/nodejs.mjs` + `clients/react-websocket.tsx` |
| 4 | **Node.js** | **Angular 17+** | Full-stack JS + Angular | `nodejs-angular.md` | `servers/nodejs.mjs` + `clients/angular-websocket.ts` |
| 5 | **Node.js** | **React Native** (Expo) | Mobile-first apps | `nodejs-react-native.md` | `servers/nodejs.mjs` + `clients/react-native.tsx` |
| 6 | **Python** (FastAPI) | **React 19** (RTK) | Data teams, ML integration | `python-react.md` | `servers/python.py` + `clients/react-websocket.tsx` |
| 7 | **Rust** (Axum) | **Angular 17+** | High-performance, safety-critical | `rust-angular.md` | `servers/rust.rs` + `clients/angular-websocket.ts` |
| 8 | **PHP** (Laravel 11) | **React 19** (RTK) | WordPress migration, PHP teams | `php-react.md` | `servers/php.php` + `clients/react-websocket.tsx` |

> All template files are in `templates/`. Use-case guides in `templates/use-cases/`.

---

## Genie DNA Quick Reference

These rules apply to ALL code across ALL stacks:

| Rule | Pattern | Key Detail |
|------|---------|------------|
| **Schema-free storage** | `ParseObjectAlternative` | Recursively flatten JSON, auto-detect types. NEVER use ORM for business data |
| **Smart query building** | `CreateQueryContainerList` | Build ES filters. SKIP empty/null fields automatically |
| **Client-side filtering** | `filterBody` | Same skip-empty concept on frontend |
| **Multi-tenant isolation** | userId injection | Non-admin users always filtered by their userId |
| **JWT auth** | Claims: Sub, id, UserId, role | 30-min expiry, SHA256 hash, Bearer + query string |
| **Hebrew convention** | Folder: `hebrew` not `he` | Dot-notation keys, RTL/LTR toggle |
| **Real-time event** | `ReceiceMessage` | This typo is intentional — NEVER "fix" it |
| **Dynamic routing** | `/api/dynamic/{indexName}/{id?}` | One endpoint for ALL entity types |
| **Return type** | `DataProcessResult` | Status: 0=Success, 1=Error, 2=Warning |

---

## How This Library Was Built

The library evolved through 12 phases:

| Phase | What Was Created |
|-------|-----------------|
| 0 | RAG extraction from 8 source projects |
| 1 | 5 cross-cutting core skills (SKILL.md files) |
| 2A | Server alternatives for dynamic-documents + auth-jwt (10 files) |
| 2B | Server alternatives for i18n + realtime + cloud (15 files) |
| 3 | Client alternatives — Angular, React, React Native (15 files) |
| 4 | Backend project skills (4 files) |
| 5 | Frontend project skills (5 files) |
| 6-orig | AI tool configurations (5 files) |
| 6A | Decision Guide + Patterns + ML Simulations (4 files) |
| 6B | Integration Recipes — 8 full-stack wiring guides |
| 6C | Quick-Start Templates — 4 use-case-based template sets |
| 6D | Enhanced AI Tool Configs with decision routing + when/why |
| 6E | Final validation + this unified README + migration paths |

Total: **104 files, 27,200+ lines**
